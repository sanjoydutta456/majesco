PROMPT
PROMPT ==============================================
PROMPT Executing check_database_connectivity.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT
exit 