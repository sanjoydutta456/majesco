PROMPT
PROMPT ==============================================
PROMPT Executing check_sysdba_connectivity.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
exit