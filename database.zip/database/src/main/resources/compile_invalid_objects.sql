PROMPT
PROMPT ==============================================
PROMPT Executing compile_invalid_objects.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 

EXIT SUCCESS