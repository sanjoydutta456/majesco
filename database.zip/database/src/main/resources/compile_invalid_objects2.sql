PROMPT
PROMPT ==============================================
PROMPT Executing compile_invalid_objects2.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 

EXIT SUCCESS