#!/bin/bash

##  Eric Beuscher
##  install_mic_customer_schema.sh

## Change the current directory to where the batch script exists
olddir=`pwd`
shdir=`dirname $0`
cd $shdir

trap 'onexit' EXIT

function onexit() {
    cd $olddir
}


echo "====================="
echo "Preparing common environment"
echo "====================="
envfile1=$shdir/setCommonDatabaseEnv.sh
## Checking Environment scripts exist or not
if [ ! -e $envfile1 ]; then
    echo "ERROR: $envfile1 does not exist"
    exit 1;
fi
source $envfile1

echo "====================="
echo "Preparing environment"
echo "====================="
envfile=$shdir/setCustomerDatabaseEnv.sh
## Checking Environment scripts exist or not
if [ ! -e $envfile ]; then
    echo "ERROR: $envfile does not exist"
    exit 1;
fi
source $envfile

## Create a temporary subdirectory in case it's missing
tmpdir=$INSTALL_PATH/logs/MIC_Logs    
if [ ! -d $tmpdir ]; then
    mkdir $tmpdir
fi

if [ ! -x "$SQLPLUS_BIN" ]; then
    SQLPLUS_BIN=$INSTALLER_SQL_CLIENT_HOME
fi

export ORACLE_HOME=$SQLPLUS_BIN
export LD_LIBRARY_PATH=$ORACLE_HOME
export PATH=$PATH:$ORACLE_HOME

TWO_TASK=$MICConnectString

errorlog=$tmpdir

is_licensed_nexgen_mic=is.licensed.nexgen.mic
is_licensed_nexgen_ri=is.licensed.nexgen.ri
is_licensed_bi=is.licensed.bi
is_dual_env=dualEnvironment.nextgen.flag

## is_licensed_nexgen_mic='true'
## is_licensed_nexgen_ri='true'
## is_licensed_bi='true'
## is_dual_env='true'


mic_imaging_username=${imaging.ifs.schema.username}
mic_imaging_password=${imaging.ifs.schema.password}

MicCustomerdomain=${customer.domain}

## Change the LOCAL to use the supplied connect string

## Load license-based properties for use by installer/MIC.
## This needs to be among the first steps done, for use by other steps.

# TODO - uncomment the below once issue is resolved
# echo "Licence File."
# sqlplus -s $MICAdminUserName/$MICAdminPassword@$MICConnectString @mic_admin/mic_admin_customer_properties_license.dat $MICCustomerCode $is_licensed_nexgen_mic $is_licensed_nexgen_ri $is_licensed_bi $is_dual_env
# if [ $? != 0 ]; then
   # echo "ERROR: could not run @mic_admin/mic_admin_customer_properties_license.dat"
    # exit 1
# fi

echo "Executing Clean Up For MIS_QUOTE_POLICIES..."
echo "mic_policy_cont_post.sql..."
sqlplus -s $MICPolicyUserName/$MICPolicyPassword@$MICConnectString @mic_policy/mic_policy_cont_post.sql $MICPolicydUserName $MICCustomerCode > $errorlog/mic_policy_cont_post_sql.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_policy/mic_policy_cont_post.sql"
    exit 1
fi

echo "**"
echo "=================================================="
echo "MIC Customer Clean Up completed successfully"
echo "=================================================="
echo "."
