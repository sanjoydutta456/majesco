#!/bin/bash

##  Eric Beuscher
##  create_mic_common_schema.sh

echo "create_mic_common_schema.sh"

#exit
## Change the current directory to where the batch script exists
olddir=`pwd`
shdir=`dirname $0`
cd $shdir

trap 'onexit' EXIT

function onexit() {
    cd $olddir
}


envfile=$shdir/setCommonDatabaseEnv.sh
## Checking Environment scripts exist or not
if [ ! -e $envfile ]; then
    echo "ERROR: $envfile does not exist"
    exit 1;
fi
source $envfile

## Create a temporary subdirectory in case it's missing
tmpdir=$INSTALL_PATH/logs/MIC_Logs    
if [ ! -d $tmpdir ]; then
    mkdir $tmpdir
fi

if [ ! -x "$SQLPLUS_BIN" ]; then
    SQLPLUS_BIN=$INSTALLER_SQL_CLIENT_HOME
fi

export ORACLE_HOME=$SQLPLUS_BIN
export LD_LIBRARY_PATH=$ORACLE_HOME
export PATH=$PATH:$ORACLE_HOME

errorlog=$tmpdir

TWO_TASK=$MICConnectString

## Creating MIC_CONNECT Role
echo "Creating MIC_CONNECT Role" >> $errorlog/create_mic_schema.log
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @create_mic_connect_role > $errorlog/create_mic_connect_role.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @create_mic_common_role"
    exit 1
fi

## Creating MIC MESSAGING Schema
echo "Creating MIC MESSAGING schema" >> $errorlog/create_mic_schema.log
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @mic_messaging/create_mic_messaging_user $MICMessagingUserName $MICMessagingPassword $MICMessagingDataTablespace $MICMessagingIndexTablespace > $errorlog/create_mic_messaging_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_messaging/create_mic_messaging_user"
    exit 1
fi

## Creating MIC ADMIN Schema
echo "Creating MIC ADMIN schema" >> $errorlog/create_mic_schema.log
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @mic_admin/create_mic_admin_user $MICAdminUserName $MICAdminPassword $MICAdminDataTablespace $MICAdminIndexTablespace > $errorlog/create_mic_admin_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_admin/create_mic_admin_user"
    exit 1
fi

echo "**"
echo "MIC Common schemas are created successfully. "
echo "Logfiles are created in $tmpdir/MIC_Logs"
echo "."
