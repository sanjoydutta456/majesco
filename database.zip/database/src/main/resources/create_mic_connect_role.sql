PROMPT
PROMPT ==============================================
PROMPT Executing create_mic_connect_role.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
exit