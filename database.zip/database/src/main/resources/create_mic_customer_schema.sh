#!/bin/bash

##  Eric Beuscher
##  create_mic_customer_schema.sh

## Change the current directory to where the batch script exists
olddir=`pwd`
shdir=`dirname $0`
cd $shdir

trap 'onexit' EXIT

function onexit() {
    cd $olddir
}

envfile=$shdir/setCustomerDatabaseEnv.sh
## Checking Environment scripts exist or not
if [ ! -e $envfile ]; then
    echo "ERROR: $envfile does not exist"
    exit 1;
fi
source $envfile

## Create a temporary subdirectory in case it's missing
tmpdir=$INSTALL_PATH/logs/MIC_Logs    
if [ ! -d $tmpdir ]; then
    mkdir $tmpdir
fi

if [ ! -x "$SQLPLUS_BIN" ]; then
    SQLPLUS_BIN=$INSTALLER_SQL_CLIENT_HOME
fi

export ORACLE_HOME=$SQLPLUS_BIN
export LD_LIBRARY_PATH=$ORACLE_HOME
export PATH=$PATH:$ORACLE_HOME

errorlog=$tmpdir
## Change the LOCAL to use the supplied connect string

TWO_TASK=$MICConnectString

## Creating MIC COMMON Schema
echo "Creating MIC COMMON schema" >> $errorlog/create_mic_schema.log
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString '@mic_common/create_mic_common_user' $MICCommonUserName $MICCommonPassword $MICCommonDataTablespace $MICCommonIndexTablespace $MICCustomerCode > $errorlog/create_mic_common_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_common/create_mic_common_user"
    exit 1
fi

## Creating MIC CRM Schema
echo "Creating MIC CRM schema" >> $errorlog/create_mic_schema.log
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString '@mic_crm/create_mic_crm_user' $MICCRMUserName $MICCRMPassword $MICCRMDataTablespace $MICCRMIndexTablespace > $errorlog/create_mic_crm_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_crm/create_mic_crm_user"
    exit 1
fi

## Creating MIC billing Schema
echo "Creating MIC billing schema" >> $errorlog/create_mic_schema.log
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString '@mic_billing/create_mic_billing_user' $MICBillingUserName $MICBillingPassword $MICBillingDataTablespace $MICBillingIndexTablespace > $errorlog/create_mic_billing_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_billing/create_mic_billing_user"
    exit 1
fi


## Creating MIC POLICY DOLLAR Schema
echo "Creating MIC POLICY DOLLAR schema" >> $errorlog/create_mic_schema.log

cmd='SET ESCCHAR $;'
echo $cmd  >> d_create_mic_policyd_user.sql
echo '@mic_policy_dl/create_mic_policyd_user' $MICPolicydUserName $MICPolicydPassword $MICPolicydDataTablespace $MICPolicydIndexTablespace >> d_create_mic_policyd_user.sql
chmod +rwx d_create_mic_policyd_user.sql


sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString d_create_mic_policyd_user.sql  > $errorlog/create_mic_policydollar_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_policy$/create_mic_policyd_user"
    exit 1
fi

rm d_create_mic_policyd_user.sql

## Creating MIC POLICY Schema
echo "Creating MIC POLICY schema" >> $errorlog/create_mic_schema.log
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @mic_policy/create_mic_policy_user $MICPolicyUserName $MICPolicyPassword $MICPolicyDataTablespace $MICPolicyIndexTablespace $MICCustomerCode > $errorlog/create_mic_policy_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_policy/create_mic_policy_user"
    exit 1
fi

## Creating MIC REPOSITORY Schema
echo "Creating MIC REPOSITORY schema" >> $errorlog/create_mic_schema.log
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @mic_repository/create_mic_repository_user $MICRepositoryUserName $MICRepositoryPassword $MICRepositoryDataTablespace $MICRepositoryIndexTablespace $MICCustomerCode > $errorlog/create_mic_repository_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_repository/create_mic_repository_user"
    exit 1
fi

## Creating MIC USER Schema
echo "Creating MIC USER schema" >> $errorlog/create_mic_schema.log
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @mic_user/create_mic_user $MICUserName $MICUserPassword $MICUserDataTablespace $MICUserIndexTablespace $MICCustomerCode > $errorlog/create_mic_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_user/create_mic_user"
    exit 1
fi

## Creating MIC CLAIM Schema
echo "Creating MIC CLAIM schema" >> $errorlog/create_mic_schema.log
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @mic_claim/create_mic_claim_user $MICClaimUserName $MICClaimPassword $MICClaimDataTablespace $MICClaimIndexTablespace $MICCustomerCode > $errorlog/create_mic_schema.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_claim/create_mic_claim_user"
    exit 1
fi

echo "**"
echo "MIC Customer schemas are created successfully. "
echo "Logfiles are created in $tmpdir/MIC_Logs"
echo "."

