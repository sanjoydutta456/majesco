PROMPT
PROMPT ==============================================
PROMPT Executing drop_mic_common_schema.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT

EXIT 