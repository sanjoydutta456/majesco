PROMPT
PROMPT ==============================================
PROMPT Executing drop_mic_customer_schemas.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 

EXIT