PROMPT
PROMPT ==============================================
PROMPT Executing grant_ca_installer.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT

EXIT SUCCESS