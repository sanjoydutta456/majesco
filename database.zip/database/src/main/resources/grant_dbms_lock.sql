PROMPT
PROMPT ==============================================
PROMPT Executing grant_dbms_lock.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 

EXIT SUCCESS