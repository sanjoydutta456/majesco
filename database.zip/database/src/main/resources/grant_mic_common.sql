PROMPT
PROMPT ==============================================
PROMPT Executing grant_mic_common.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT

EXIT SUCCESS