PROMPT
PROMPT ==============================================
PROMPT Executing grant_mic_policy.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 

EXIT SUCCESS