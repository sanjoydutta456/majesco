PROMPT
PROMPT ==============================================
PROMPT Executing grant_sys_privileges.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT

EXIT