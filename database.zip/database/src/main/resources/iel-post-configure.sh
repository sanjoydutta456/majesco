#!/bin/bash

##  Eric Beuscher
##  patch_mic_common_schema.sh

## Change the current directory to where the batch script exists
olddir=`pwd`
shdir=`dirname $0`
cd $shdir

## Create a temporary subdirectory in case it's missing
tmpdir=$INSTALL_PATH/logs/MIC_Logs    
if [ ! -d $tmpdir ]; then
    mkdir $tmpdir
fi

if [ ! -x "$SQLPLUS_BIN" ]; then
    SQLPLUS_BIN=$INSTALLER_SQL_CLIENT_HOME
fi

export ORACLE_HOME=$SQLPLUS_BIN
export LD_LIBRARY_PATH=$ORACLE_HOME
export PATH=$PATH:$ORACLE_HOME

errorlog=$tmpdir


MICConnectString=$1
MICPolicyUsername=$2
MICPolicyTablespace=$3

echo "Execute iel-post-configure"
sqlplus -l -s $MICConnectString @upgrade/mic_policy/iel-post-configure $MICPolicyUsername $MICPolicyTablespace >> $errorlog/iel-post-configure.log
if [ $? != 0 ]; then
    echo 'ERROR: could not run @iel-post-configure.sql'
    exit 1
fi

echo "**"
echo "iel-post-configure executed. "
echo "Logfiles are created in $tmpdir/MIC_Logs"
echo "."
