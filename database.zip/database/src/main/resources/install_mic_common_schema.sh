#!/bin/bash

##  Eric Beuscher
##  install_mic_common_schema.sh

## Change the current directory to where the batch script exists
olddir=`pwd`
shdir=`dirname $0`
cd $shdir

trap 'onexit' EXIT

function onexit() {
    cd $olddir
}

echo "====================="
echo "Preparing environment"
echo "====================="
envfile=$shdir/setCommonDatabaseEnv.sh
## Checking Environment scripts exist or not
if [ ! -e $envfile ]; then
    echo "ERROR: $envfile does not exist"
    exit 1;
fi
source $envfile

## Create a temporary subdirectory in case it's missing
tmpdir=$INSTALL_PATH/logs/MIC_Logs    
if [ ! -d $tmpdir ]; then
    mkdir $tmpdir
fi

if [ ! -x "$SQLPLUS_BIN" ]; then
    SQLPLUS_BIN=$INSTALLER_SQL_CLIENT_HOME
fi

export ORACLE_HOME=$SQLPLUS_BIN
export LD_LIBRARY_PATH=$ORACLE_HOME
export PATH=$PATH:$ORACLE_HOME

errorlog=$tmpdir
## Change the LOCAL to use the supplied connect string

TWO_TASK=$MICConnectString

echo "Cleanup recyclebin for mic_admin..."
sqlplus -s $MICAdminUserName/$MICAdminPassword@$MICConnectString @purge_recyclebin > $errorlog/purge_recyclebin.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @purge_recyclebin"
    exit 1
fi

echo "Cleanup recyclebin for mic_messaging..."
sqlplus -s $MICMessagingUserName/$MICMessagingPassword@$MICConnectString @purge_recyclebin > $errorlog/purge_recyclebin.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @purge_recyclebin"
    exit 1
fi


echo "==================="
echo "Creating DB Objects"
echo "==================="
echo "Creating MIC_ADMIN DB Objects..."
## Creating MIC POLICY$ database objects
sqlplus -s $MICAdminUserName/$MICAdminPassword@$MICConnectString @mic_admin/install_mic_admin $MICAdminIndexTablespace > $errorlog/install_mic_admin.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_admin/install_mic_admin"
    exit 1
fi

echo "Creating MIC_MESSAGING DB Objects..."
sqlplus -s $MICMessagingUserName/$MICMessagingPassword@$MICConnectString @mic_messaging/install_mic_messaging $MICMessagingIndexTablespace > $errorlog/install_mic_messaging.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_messaging/install_mic_messaging"
    exit 1
fi


echo "Installing mic admin public..."
sqlplus -s $MICAdminUserName/$MICAdminPassword@$MICConnectString @mic_admin/mic_admin_public > $errorlog/mic_admin.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_admin/mic_admin_public"
    exit 1
fi

echo "Installing mic admin public int..."
sqlplus -s $MICAdminUserName/$MICAdminPassword@$MICConnectString @mic_admin/mic_admin_public.int $MICSystemPassword > $errorlog/mic_admin.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_admin/mic_admin_public.int"
    exit 1
fi

echo "Installing mic admin int..."
sqlplus -s $MICAdminUserName/$MICAdminPassword@$MICConnectString @mic_admin/mic_admin.int $MICSystemPassword > $errorlog/mic_admin.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_admin/mic_admin.int"
    exit 1
fi


echo "Add WM_CONCAT for 12c databases..."
sqlplus -s $MICAdminUserName/$MICAdminPassword@$MICConnectString @wm_concat.sql $MICAdminUserName $MICAdminPassword system $MICSystemPassword > $errorlog/wm_concat.log
if [ $? != 0 ]; then
	if [ $? = 20007 ]; then
		echo "INFO: wm_concat not run for non-12c databases"
	else
		echo "ERROR: could not run @wm_concat.sql"
		exit 1
	fi
    
fi

echo "Compiling mic_admin DB Objects..."
sqlplus -s $MICAdminUserName/$MICAdminPassword@$MICConnectString @compile_invalid_objects.sql > $errorlog/mic_admin.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @compile_invalid_objects.sql"
    exit 1
fi

echo "Compiling mic_messaging DB Objects..."
sqlplus -s $MICMessagingUserName/$MICMessagingPassword@$MICConnectString @compile_invalid_objects.sql > $errorlog/mic_messaging.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @compile_invalid_objects.sql"
    exit 1
fi


echo "**"
echo "MIC Common schemas objects are installed successfully. "
echo "Logfiles are created in $tmdir/MIC_Logs"
echo "."
