#!/bin/bash

##  Eric Beuscher
##  install_mic_customer_schema.sh

## Change the current directory to where the batch script exists
olddir=`pwd`
shdir=`dirname $0`
cd $shdir

trap 'onexit' EXIT

function onexit() {
    cd $olddir
}


echo "====================="
echo "Preparing common environment"
echo "====================="
envfile1=$shdir/setCommonDatabaseEnv.sh
## Checking Environment scripts exist or not
if [ ! -e $envfile1 ]; then
    echo "ERROR: $envfile1 does not exist"
    exit 1;
fi
source $envfile1

echo "====================="
echo "Preparing environment"
echo "====================="
envfile=$shdir/setCustomerDatabaseEnv.sh
## Checking Environment scripts exist or not
if [ ! -e $envfile ]; then
    echo "ERROR: $envfile does not exist"
    exit 1;
fi
source $envfile

## Create a temporary subdirectory in case it's missing
tmpdir=$INSTALL_PATH/logs/MIC_Logs    
if [ ! -d $tmpdir ]; then
    mkdir $tmpdir
fi

if [ ! -x "$SQLPLUS_BIN" ]; then
    SQLPLUS_BIN=$INSTALLER_SQL_CLIENT_HOME
fi

export ORACLE_HOME=$SQLPLUS_BIN
export LD_LIBRARY_PATH=$ORACLE_HOME
export PATH=$PATH:$ORACLE_HOME

TWO_TASK=$MICConnectString

errorlog=$tmpdir

is_licensed_nexgen_mic=is.licensed.nexgen.mic
is_licensed_nexgen_ri=is.licensed.nexgen.ri
is_licensed_bi=is.licensed.bi
is_dual_env=dualEnvironment.nextgen.flag

## is_licensed_nexgen_mic='true'
## is_licensed_nexgen_ri='true'
## is_licensed_bi='true'
## is_dual_env='true'


mic_imaging_username=${imaging.ifs.schema.username}
mic_imaging_password=${imaging.ifs.schema.password}

MicCustomerdomain=${customer.domain}

## Change the LOCAL to use the supplied connect string

## Load license-based properties for use by installer/MIC.
## This needs to be among the first steps done, for use by other steps.

# TODO - uncomment the below once issue is resolved
# echo "Licence File."
# sqlplus -s $MICAdminUserName/$MICAdminPassword@$MICConnectString @mic_admin/mic_admin_customer_properties_license.dat $MICCustomerCode $is_licensed_nexgen_mic $is_licensed_nexgen_ri $is_licensed_bi $is_dual_env
# if [ $? != 0 ]; then
   # echo "ERROR: could not run @mic_admin/mic_admin_customer_properties_license.dat"
    # exit 1
# fi

echo "Create user mic_policy$ user" $MICPolicydUserName $MICPolicydPassword
##currDir=$pwd
##cd mic_policy\$

cmd='SET ESCCHAR $;'
echo $cmd  >> d_create_mic_policyd_user.sql
echo '@mic_policy_dl/create_mic_policyd_user.sql' $MICPolicydUserName $MICPolicydPassword $MICPolicydDataTablespace $MICPolicydIndexTablespace >> d_create_mic_policyd_user.sql
chmod +rwx d_create_mic_policyd_user.sql

sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @d_create_mic_policyd_user.sql $MICPolicydUserName $MICPolicydPassword $MICPolicydDataTablespace $MICPolicydIndexTablespace > $errorlog/create_mic_policydollar_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_policy_dl/create_mic_policyd_user.sql"
    exit 1
fi

rm d_create_mic_policyd_user.sql


echo "Creating User MIC COMMON" >> $errorlog/create_mic_user.log
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString '@mic_common/create_mic_common_user' $MICCommonUserName $MICCommonPassword $MICCommonDataTablespace $MICCommonIndexTablespace $MICCustomerCode > $errorlog/create_mic_common_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_common/create_mic_common_user"
    exit 1
fi


echo "Creating User MIC POLICY" >> $errorlog/create_mic_user.log
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @mic_policy/create_mic_policy_user $MICPolicyUserName $MICPolicyPassword $MICPolicyDataTablespace $MICPolicyIndexTablespace $MICCustomerCode > $errorlog/create_mic_policy_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_policy/create_mic_policy_user"
    exit 1
fi


echo "Creating user MIC billing" >> $errorlog/create_mic_user.log
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString '@mic_billing/create_mic_billing_user' $MICBillingUserName $MICBillingPassword $MICBillingDataTablespace $MICBillingIndexTablespace > $errorlog/create_mic_billing_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_billing/create_mic_billing_user"
    exit 1
fi

echo "Creating User MIC CRM" >> $errorlog/create_mic_user.log
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString '@mic_crm/create_mic_crm_user' $MICCRMUserName $MICCRMPassword $MICCRMDataTablespace $MICCRMIndexTablespace > $errorlog/create_mic_crm_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_crm/create_mic_crm_user"
    exit 1
fi


echo "Creating User MIC REPOSITORY" >> $errorlog/create_mic_user.log
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @mic_repository/create_mic_repository_user $MICRepositoryUserName $MICRepositoryPassword $MICRepositoryDataTablespace $MICRepositoryIndexTablespace $MICCustomerCode > $errorlog/create_mic_repository_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_repository/create_mic_repository_user"
    exit 1
fi

echo "Creating User MIC CLAIM" >> $errorlog/create_mic_user.log
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @mic_claim/create_mic_claim_user $MICClaimUserName $MICClaimPassword $MICClaimDataTablespace $MICClaimIndexTablespace $MICCustomerCode > $errorlog/create_mic_schema.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_claim/create_mic_claim_user"
    exit 1
fi

echo "Creating User MIC USER " >> $errorlog/create_mic_user.log
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @mic_user/create_mic_user $MICUserName $MICUserPassword $MICUserDataTablespace $MICUserIndexTablespace $MICCustomerCode > $errorlog/create_mic_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_user/create_mic_user"
    exit 1
fi


## TODO-somil uncomment later SPECIAL for mic_admin_customer.grt"
echo "mic_admin_customer.grt"
sqlplus -s $MICAdminUserName/$MICAdminPassword@$MICConnectString @mic_admin/mic_admin_customer.grt $MICCustomerCode > $errorlog/mic_admin_customer.log
if [ $? != 0 ]; then
   echo "ERROR: could not run @mic_admin/mic_admin_customer.grt"
    exit 1
fi

## "Changes are made to provide handling for decoupling PAS, BILLING and CLAIMS system based on the LICENSE"
echo "Integrating ca_installer objects to mic_common"
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @grant_ca_installer.sql $MICCustomerCode mic_common_$MICCustomerCode  > $errorlog/grant_ca_installer.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @grant_ca_installer.sql"
    exit 1
fi



## "Changes are made to provide handling for decoupling PAS, BILLING and CLAIMS system based on the LICENSE"
echo "Integrating ca_installer objects to mic_admin"
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @grant_ca_installer.sql $MICCustomerCode mic_admin  > $errorlog/grant_ca_installer.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @grant_ca_installer.sql"
    exit 1
fi


echo "Create user mic_policy$ user"
##currDir=$pwd
##cd mic_policy\$

cmd='SET ESCCHAR $;'
echo $cmd  >> d_install_mic_policyd.sql
echo '@mic_policy_dl/install_mic_policy_dl.sql' $MICPolicydIndexTablespace $MICCustomerCode >> d_install_mic_policyd.sql
chmod +rwx d_install_mic_policyd.sql

echo "==================="
echo "Creating DB Objects"
echo "==================="
echo "Installing MIC_POLICY$ DB Objects..."
sqlplus -s $MICPolicydUserName/$MICPolicydPassword@$MICConnectString @d_install_mic_policyd.sql >> $errorlog/create_mic_policydollar_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_policy_dl/install_mic_policy_dl.sql"
    exit 1
fi

rm d_install_mic_policyd.sql

echo "Installing MIC_COMMON DB Objects..."
sqlplus -s $MICCommonUserName/$MICCommonPassword@$MICConnectString '@mic_common/install_mic_common' $MICCommonIndexTablespace $MICCustomerCode > $errorlog/install_mic_common.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_common/install_mic_common"
    exit 1
fi

echo "Installing mic_policy DB Objects..."
sqlplus -s $MICPolicyUserName/$MICPolicyPassword@$MICConnectString '@mic_policy/install_mic_policy' $MICPolicyIndexTablespace $MICCustomerCode > $errorlog/install_mic_policy.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_policy/install_mic_policy"
    exit 1
fi

echo "Installing MIC_billing DB Objects"
sqlplus -s $MICBillingUserName/$MICBillingPassword@$MICConnectString @mic_billing/install_mic_billing.sql $MICBillingIndexTablespace $MICCustomerCode > $errorlog/install_mic_billing.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_billing/install_mic_billing.sql"
    exit 1
fi

echo "Installing MIC_CRM DB Objects..."
sqlplus -s $MICCRMUserName/$MICCRMPassword@$MICConnectString '@mic_crm/install_mic_crm' $MICCRMIndexTablespace $MICCustomerCode > $errorlog/install_mic_crm.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_crm/install_mic_crm"
    exit 1
fi

echo "Installing mic_repository DB Objects..."
sqlplus -s $MICRepositoryUserName/$MICRepositoryPassword@$MICConnectString @mic_repository/install_mic_repository $MICRepositoryIndexTablespace $MICCustomerCode > $errorlog/install_mic_repository.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_repository/install_mic_repository"
    exit 1
fi

echo Installing mic_claim DB Objects
sqlplus -s $MICClaimUserName/$MICClaimPassword@$MICConnectString @mic_claim/install_mic_claim.sql $MICClaimIndexTablespace $MICCustomerCode > $errorlog/install_mic_claim.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_claim/install_mic_claim.sql"
    exit 1
fi

## Install db objects for mic_user schema.
echo "Install db objects for mic_user schema"
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_user/mic_user.typ  > $errorlog/mic_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_user/mic_user.typ"
    exit 1
fi


##  currDir=$pwd
## cd mic_policy\$

cmd='SET ESCCHAR $;'
echo $cmd  >> d_mic_policydgrt.sql
echo '@mic_policy_dl/mic_policy_dl.grt' $MICCustomerCode >> d_mic_policydgrt.sql
chmod +rwx d_mic_policydgrt.sql

 echo "Integrating mic_policy$ DB Objects..."
 sqlplus -s $MICPolicydUserName/$MICPolicydPassword@$MICConnectString @d_mic_policydgrt.sql $MICCustomerCode >> $errorlog/install_mic_policydollar.log
 if [ $? != 0 ]; then
     echo 'ERROR: could not run @mic_policy_dl/mic_policy_dl.grt'
     exit 1
 fi

rm d_mic_policydgrt.sql

cmd='SET ESCCHAR $;'
echo $cmd  >> d_mic_policydint.sql
echo '@mic_policy_dl/mic_policy_dl.int' $MICPolicydUserName $MICPolicydPassword $MICCommonUserName $MICCommonPassword $MICPolicyUserName $MICPolicyPassword $MICBillingUserName $MICBillingPassword $MICCRMUserName $MICCRMPassword $MICRepositoryUserName $MICRepositoryPassword $MICClaimUserName $MICClaimPassword system $MICSystemPassword $MICCustomerCode >> d_mic_policydint.sql
chmod +rwx d_mic_policydint.sql
 
echo "@mic_policy/mic_policy_dl.int"
sqlplus -s $MICPolicydUserName/$MICPolicydPassword@$MICConnectString @d_mic_policydint.sql  >> $errorlog/install_mic_policydollar.log
 if [ $? != 0 ]; then
     echo 'ERROR: could not run @mic_policy/mic_policy_dl.int'
     exit 1
 fi

rm d_mic_policydint.sql


echo "Integrating mic_common DB Objects..."
sqlplus -s $MICCommonUserName/$MICCommonPassword@$MICConnectString @mic_common/mic_common.grt $MICCustomerCode > $errorlog/mic_common_grt.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_common/mic_common.grt"
    exit 1
fi

##commented .int TODO-somil
echo "mic_common.int..."
sqlplus -s $MICCommonUserName/$MICCommonPassword@$MICConnectString @mic_common/mic_common.int $MICPolicydUserName $MICPolicydPassword $MICCommonUserName $MICCommonPassword $MICPolicyUserName $MICPolicyPassword $MICBillingUserName $MICBillingPassword $MICCRMUserName $MICCRMPassword $MICRepositoryUserName $MICRepositoryPassword $MICClaimUserName $MICClaimPassword $MICAdminUserName $MICAdminPassword $MICCustomerCode >> $errorlog/mic_common_int.log
if [ $? != 0 ]; then
   echo "ERROR: could not run @mic_common/mic_common.int"
    exit 1
fi


echo "Integrating MIC_POLICY DB Objects..."
sqlplus -s $MICPolicyUserName/$MICPolicyPassword@$MICConnectString @mic_policy/mic_policy.grt $MICCustomerCode > $errorlog/mic_policy_grt.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_policy/mic_policy.grt"
    exit 1
fi

##commented .int TODO-somil
echo "mic_policy.int..."
sqlplus -s $MICPolicyUserName/$MICPolicyPassword@$MICConnectString @mic_policy/mic_policy.int $MICPolicydUserName $MICPolicydPassword $MICCommonUserName $MICCommonPassword $MICPolicyUserName $MICPolicyPassword $MICBillingUserName $MICBillingPassword $MICCRMUserName $MICCRMPassword $MICRepositoryUserName $MICRepositoryPassword $MICClaimUserName $MICClaimPassword $MICAdminUserName $MICAdminPassword $MICCustomerCode system $MICSystemPassword >> $errorlog/mic_policy_int.log
if [ $? != 0 ]; then
   echo "ERROR: could not run @mic_policy/mic_policy.int"
    exit 1
fi

echo "Integrating mic_billing DB Objects..."
sqlplus -s $MICBillingUserName/$MICBillingPassword@$MICConnectString @mic_billing/mic_billing.grt $MICCustomerCode > $errorlog/mic_billing.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_billing/mic_billing.grt"
    exit 1
fi

##commented .int TODO-somil
echo "mic_billing.int  ..."
sqlplus -s $MICBillingUserName/$MICBillingPassword@$MICConnectString @mic_billing/mic_billing.int $MICPolicydUserName $MICPolicydPassword $MICCommonUserName $MICCommonPassword $MICPolicyUserName $MICPolicyPassword $MICBillingUserName $MICBillingPassword $MICCRMUserName $MICCRMPassword $MICRepositoryUserName $MICRepositoryPassword $MICClaimUserName $MICClaimPassword system $MICSystemPassword $MICCustomerCode >> $errorlog/install_mic_billing.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_billing/mic_billing.int"
    exit 1
fi

echo "Integrating mic_crm DB Objects..."
sqlplus -s $MICCRMUserName/$MICCRMPassword@$MICConnectString @mic_crm/mic_crm.grt $MICCustomerCode > $errorlog/mic_crm.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_crm/mic_crm.grt"
    exit 1
fi

echo "mic_crm.int  ..."
sqlplus -s $MICCRMUserName/$MICCRMPassword@$MICConnectString @mic_crm/mic_crm.int $MICPolicydUserName $MICPolicydPassword $MICCommonUserName $MICCommonPassword $MICPolicyUserName $MICPolicyPassword $MICBillingUserName $MICBillingPassword $MICCRMUserName $MICCRMPassword $MICRepositoryUserName $MICRepositoryPassword $MICClaimUserName $MICClaimPassword system $MICSystemPassword $MICCustomerCode >> $errorlog/mic_crm.log
if [ $? != 0 ]; then
   echo "ERROR: could not run @mic_crm/mic_crm.int"
    exit 1
fi


echo "Integrating mic_repository DB Objects..."
sqlplus -s $MICRepositoryUserName/$MICRepositoryPassword@$MICConnectString @mic_repository/mic_repository.grt $MICCustomerCode > $errorlog/mic_repository.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_repository/mic_repository.grt"
    exit 1
fi


echo "mic_repository.int..."
sqlplus -s $MICRepositoryUserName/$MICRepositoryPassword@$MICConnectString @mic_repository/mic_repository.int $MICPolicydUserName $MICPolicydPassword $MICCommonUserName $MICCommonPassword $MICPolicyUserName $MICPolicyPassword $MICBillingUserName $MICBillingPassword $MICCRMUserName $MICCRMPassword $MICRepositoryUserName $MICRepositoryPassword $MICClaimUserName $MICClaimPassword system $MICSystemPassword $MICCustomerCode > $errorlog/mic_repository_int.log
if [ $? != 0 ]; then
   echo "ERROR: could not run @mic_repository/mic_repository.int"
    exit 1
fi

echo "Integrating mic_claim DB Objects  ..."
sqlplus -s $MICClaimUserName/$MICClaimPassword@$MICConnectString @mic_claim/mic_claim.grt $MICCustomerCode > $errorlog/mic_claim.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_claim/mic_claim.grt"
    exit 1
fi

echo "mic_claim.int..."
sqlplus -s $MICClaimUserName/$MICClaimPassword@$MICConnectString @mic_claim/mic_claim.int $MICPolicydUserName $MICPolicydPassword $MICCommonUserName $MICCommonPassword $MICPolicyUserName $MICPolicyPassword $MICBillingUserName $MICBillingPassword $MICCRMUserName $MICCRMPassword $MICRepositoryUserName $MICRepositoryPassword $MICClaimUserName $MICClaimPassword system $MICSystemPassword $MICCustomerCode >> $errorlog/install_mic_claim.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_claim/mic_claim.int"
    exit 1
fi

echo "Compiling mic_policy_dl DB Objects"
sqlplus -s $MICPolicydUserName/$MICPolicydPassword@$MICConnectString @compile_invalid_objects.sql >> $errorlog/compiling_mic_policyd.log
if [ $? != 0 ]; then
    echo "ERROR: could not run mic_policy_dl @compile_invalid_objects.sql"
    exit 1
fi



echo "Compiling mic_common DB Objects"
sqlplus -s $MICCommonUserName/$MICCommonPassword@$MICConnectString @compile_invalid_objects.sql >> $errorlog/compiling_mic_common.log
if [ $? != 0 ]; then
    echo "ERROR: could not run mic_common @compile_invalid_objects.sql"
    exit 1
fi

echo "Compiling mic_policy DB Objects"
sqlplus -s $MICPolicyUserName/$MICPolicyPassword@$MICConnectString @compile_invalid_objects.sql >> $errorlog/compiling_mic_policy.log
if [ $? != 0 ]; then
    echo "ERROR: could not run mic_policy @compile_invalid_objects.sql"
    exit 1
fi


echo "Compiling mic_billing DB Objects"
sqlplus -s $MICBillingUserName/$MICBillingPassword@$MICConnectString @compile_invalid_objects.sql >> $errorlog/compiling_mic_billing.log
if [ $? != 0 ]; then
    echo "ERROR: could not run mic_billing @compile_invalid_objects.sql"
    exit 1
fi

echo "Compiling mic_crm DB Objects"
sqlplus -s $MICCRMUserName/$MICCRMPassword@$MICConnectString @compile_invalid_objects.sql >> $errorlog/compiling_mic_crm.log
if [ $? != 0 ]; then
    echo "ERROR: could not run mic_crm @compile_invalid_objects.sql"
    exit 1
fi

echo "Compiling mic_repository DB Objects"
sqlplus -s $MICRepositoryUserName/$MICRepositoryPassword@$MICConnectString @compile_invalid_objects.sql >> $errorlog/compiling_mic_repository.log
if [ $? != 0 ]; then
    echo "ERROR: could not run mic_repository @compile_invalid_objects.sql"
    exit 1
fi


echo "Compiling mic_claim DB Objects"
sqlplus -s $MICClaimUserName/$MICClaimPassword@$MICConnectString @compile_invalid_objects.sql >> $errorlog/compiling_mic_claim.log
if [ $? != 0 ]; then
    echo "ERROR: could not run mic_claim @compile_invalid_objects.sql"
    exit 1
fi

cmd='SET ESCCHAR $;'
echo $cmd  >> d_mic_policysdat.sql
echo '@mic_policy_dl/mic_policy_dl.dat' $MICCustomerCode $MicCustomerdomain >> d_mic_policysdat.sql
chmod +rwx d_mic_policysdat.sql

echo "Loading mic_policy$ DB Objects..."
sqlplus -s $MICPolicydUserName/$MICPolicydPassword@$MICConnectString @d_mic_policysdat.sql  >> $errorlog/loading_mic_policyd.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_policy_dl/mic_policy_dl.dat"
    exit 1
fi

rm d_mic_policysdat.sql

##commented TODO-somil below because packaged not found in mic_common.dat somil
echo "Loading mic_common DB Objects..."
sqlplus -s $MICCommonUserName/$MICCommonPassword@$MICConnectString @mic_common/mic_common.dat $MICCustomerCode $MicCustomerdomain >> $errorlog/loading_mic_common.log
if [ $? != 0 ]; then
   echo "ERROR: could not run @mic_common/mic_common.dat"
    exit 1
fi

##commented TODO-somil below because packaged not found in mic_common.dat somil
echo "Loading mic_policy DB Objects..."
sqlplus -s $MICPolicyUserName/$MICPolicyPassword@$MICConnectString @mic_policy/mic_policy.dat $MICCustomerCode $MicCustomerdomain >> $errorlog/loading_mic_policy.log
if [ $? != 0 ]; then
   echo "ERROR: could not run @mic_policy/mic_policy.dat"
    exit 1
fi


# TODO-somil
echo "Loading mic_billing DB Objects..."
sqlplus -s $MICBillingUserName/$MICBillingPassword@$MICConnectString @mic_billing/mic_billing.dat $MICCustomerCode $MicCustomerdomain >> $errorlog/loading_mic_billing.log
if [ $? != 0 ]; then
   echo "ERROR: could not run @mic_billing/mic_billing.dat"
    exit 1
fi

# TODO-somil
echo "Loading mic_crm DB Objects..."
sqlplus -s $MICCRMUserName/$MICCRMPassword@$MICConnectString @mic_crm/mic_crm.dat $MICCustomerCode $MicCustomerdomain >> $errorlog/loading_mic_crm.log
if [ $? != 0 ]; then
   echo "ERROR: could not run @mic_crm/mic_crm.dat"
    exit 1
fi

# TODO-somil
echo "Loading mic_repository DB Objects..."
sqlplus -s $MICRepositoryUserName/$MICRepositoryPassword@$MICConnectString @mic_repository/mic_repository.dat $MICCustomerCode $MicCustomerdomain >> $errorlog/loading_mic_repository.log
if [ $? != 0 ]; then
   echo "ERROR: could not run @mic_repository/mic_repository.dat"
    exit 1
fi

echo "Loading mic_claim DB Objects..."
sqlplus -s $MICClaimUserName/$MICClaimPassword@$MICConnectString @mic_claim/mic_claim.dat $MICCustomerCode $MicCustomerdomain>> $errorlog/loading_mic_claim.log
if [ $? != 0 ]; then
   echo "ERROR: could not run @mic_claim/mic_claim.dat"
    exit 1
fi


cmd='SET ESCCHAR $;'
echo $cmd  >> d_mic_policydsyn.sql
echo '@mic_user/mic_policy_dl.syn' $MICPolicydUserName >> d_mic_policydsyn.sql
chmod +rwx d_mic_policydsyn.sql


echo "Creating mic_policy$ Synonyms..."
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @d_mic_policydsyn.sql >> $errorlog/create_Synonyms.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_user/mic_policy\$.syn"
    exit 1
fi

rm d_mic_policydsyn.sql

echo "Creating mic_common Synonyms..."
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_user/mic_common.syn $MICCommonUserName >> $errorlog/create_Synonyms.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_user/mic_common.syn"
    exit 1
fi

echo "Creating mic_policy Synonyms..."
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_user/mic_policy.syn $MICPolicyUserName >> $errorlog/create_Synonyms.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_user/mic_policy.syn"
    exit 1
fi

echo "Creating mic_billing Synonyms..."
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_user/mic_billing.syn $MICBillingUserName >> $errorlog/create_Synonyms.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_user/mic_billing.syn"
    exit 1
fi

echo "Creating mic_crm Synonyms..."
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_user/mic_crm.syn $MICCRMUserName >> $errorlog/create_Synonyms.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_user/mic_crm.syn"
    exit 1
fi

echo "Creating mic_repository Synonyms..."
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_user/mic_repository.syn $MICRepositoryUserName >> $errorlog/create_Synonyms.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_user/mic_repository.syn"
    exit 1
fi

echo "Creating mic_claim Synonyms..."
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_user/mic_claim.syn $MICClaimUserName >> $errorlog/create_Synonyms.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_user/mic_claim.syn"
    exit 1
fi

echo "Creating mic_messaging Synonyms..."
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_user/mic_messaging.syn $MICMessagingUserName >> $errorlog/create_Synonyms.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_user/mic_messaging.syn"
    exit 1
fi

echo "Creating mic_imaging Synonyms..."
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_user/mic_imaging.syn $mic_imaging_username >> $errorlog/create_Synonyms.log
if [ $? != 0 ]; then
    echo "Customer does not have the Imaging module.  Skipping..."
    ##exit 1
fi

echo "Interface Views for LX..."
if [ $MICCustomerCode = "LX" ]; then
    sqlplus -s $MICPolicyUserName/$MICPolicyPassword@$MICConnectString @mic_policy/lx_interface_views.sql >> $errorlog/interface_view.log
		if [ $? != 0 ]; then
			echo "ERROR: could not run @mic_policy/lx_interface_views.sql"
			exit 1
		fi
fi

echo "Interface Views for GM..."
if [ $MICCustomerCode = "GM" ]; then
    sqlplus -s $MICPolicyUserName/$MICPolicyPassword@$MICConnectString @mic_policy/gm_interface_views.sql >> $errorlog/interface_view.log
		if [ $? != 0 ]; then
			echo "ERROR: could not run @mic_policy\gm_interface_views.sql"
			exit 1
		fi
fi

echo "Interface Views for SB..."
if [ $MICCustomerCode = "SB" ]; then
    sqlplus -s $MICPolicyUserName/$MICPolicyPassword@$MICConnectString @mic_policy/sb_interface_views.sql >> $errorlog/interface_view.log
		if [ $? != 0 ]; then
			echo "ERROR: could not run @mic_policy\gm_interface_views.sql"
			exit 1
		fi
fi

echo "Interface Views for PI..."
if [ $MICCustomerCode = "PI" ]; then
    sqlplus -s $MICPolicyUserName/$MICPolicyPassword@$MICConnectString @mic_policy/pi_interface_views.sql >> $errorlog/interface_view.log
		if [ $? != 0 ]; then
			echo "ERROR: could not run @mic_policy\pi_interface_views.sql"
			exit 1
		fi
fi

echo ======================================================
echo Mic_Imaging grant...
echo ======================================================
	sqlplus -s $MICUserName/$MICUserPassword @mic_user/mic_user.int $MICImagingUserName $MICImagingPassword $MICUserName >> $errorlog/mic_user_int.log
		if [ $? != 0 ]; then
			echo "ERROR: could not run @mic_policy/mic_user.int"
			exit 1
		fi
echo .


echo "Creating MIC_RO_ User..."
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @create_mic_ro_user.sql $MICCustomerCode $MICAdminDataTablespace $MICAdminIndexTablespace >> $errorlog/MIC_RO.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @create_mic_ro_user.sql"
    exit 1
fi


echo "Granting Privs to MIC_COMMON User..."
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @grant_mic_common.sql $MICCustomerCode >> $errorlog/Granting_Privs.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @grant_mic_common.sql"
    exit 1
fi


echo "Granting Privs to MIC_POLICY User..."
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @grant_mic_policy.sql $MICCustomerCode >> $errorlog/Granting_Privs.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @grant_mic_policy.sql"
    exit 1
fi

echo "Integrate policy_studio objects to mic_common"
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @grant_mic_policy.sql $MICCustomerCode mic_common_$MICCustomerCode >> $errorlog/Integrate_policy.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @grant_mic_policy.sql"
    exit 1
fi

echo "Integrate policy_studio objects to mic_policy"
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @grant_mic_policy.sql $MICCustomerCode mic_policy_$MICCustomerCode >> $errorlog/Integrate_policy.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @grant_mic_policy.sql"
    exit 1
fi

echo "Integrate policy_studio objects to mic"
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @grant_mic_policy.sql $MICCustomerCode mic_$MICCustomerCode >> $errorlog/Integrate_policy.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @grant_mic_policy.sql"
    exit 1
fi


echo "Compiling all DB Objects..."
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @compile_invalid_objects2.sql 1 $MICCustomerCode >> $errorlog/compile.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @compile_invalid_objects2.sql"
    exit 1
fi

echo "Compiling all DB Objects..."
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @compile_invalid_objects2.sql 2 $MICCustomerCode >> $errorlog/compile.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @compile_invalid_objects2.sql"
    exit 1
fi

echo "Compiling all DB Objects..."
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @compile_invalid_objects2.sql 3 $MICCustomerCode >> $errorlog/compile.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @compile_invalid_objects2.sql"
    exit 1
fi


echo "@mic_policy/mic_policy_cleanup.sql..."
sqlplus -l -s $MICPolicyUserName/$MICPolicyPassword@$MICConnectString @mic_policy/mic_policy_cleanup.sql >> $errorlog/compile.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_policy/mic_policy_cleanup.sql"
    exit 1
fi


echo "**"
echo "=================================================="
echo "MIC DB objects installation completed successfully"
echo "=================================================="
echo "."
