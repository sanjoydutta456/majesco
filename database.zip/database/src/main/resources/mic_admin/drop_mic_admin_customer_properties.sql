PROMPT
PROMPT ===========================================================
PROMPT Executing drop_mic_admin_customer_properties.sql 
PROMPT ===========================================================


PROMPT =====================================
PROMPT 
EXIT