PROMPT
PROMPT =============================================================
PROMPT Executing drop_mic_service_machine_properties.sql 
PROMPT =============================================================


PROMPT =====================================
PROMPT 
EXIT