PROMPT
PROMPT ===================================================
PROMPT Executing insert_mic_admin_instance.sql
PROMPT ===================================================


PROMPT =====================================
PROMPT 
EXIT