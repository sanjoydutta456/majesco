PROMPT
PROMPT ===================================================
PROMPT Executing insert_mic_customer.sql
PROMPT ===================================================


EXIT

PROMPT =====================================
PROMPT 