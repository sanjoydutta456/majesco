PROMPT
PROMPT =============================================
PROMPT Executing install_mic_admin.sql
PROMPT =============================================

SET VERIFY OFF
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
WHENEVER OSERROR EXIT OSCODE

DEFINE indextbsp=&1

@@mic_admin.tab
@@mic_admin.ind
@@mic_admin.seq
@@mic_admin.prc
@@mic_admin.con
@@mic_admin.trg
@@mic_admin_common.dat
@@mic_admin_param_exceptions.dat
@@mic_admin_customer_keys.dat

PROMPT =====================================
PROMPT 
EXIT SUCCESS
