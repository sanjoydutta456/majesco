PROMPT
PROMPT ==============================================
PROMPT Executing mic_admin_customer_cleanup.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
EXIT