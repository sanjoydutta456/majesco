PROMPT
PROMPT ================================================
PROMPT Executing create_mic_agency_user.sql
PROMPT ================================================



PROMPT =====================================
PROMPT 

EXIT
