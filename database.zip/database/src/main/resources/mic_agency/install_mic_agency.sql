PROMPT
PROMPT ==============================================
PROMPT Executing install_mic_agency.sql
PROMPT ==============================================

Set Verify Off
WhenEver SqlError Exit Sql.SqlCode
WHENEVER OSERROR EXIT SQL.OSCODE

DEFINE INDEXTBSP=&1

@@MIC_AGENCY.TAB
@@MIC_AGENCY.CON
@@MIC_AGENCY.IND
@@MIC_AGENCY.PRC
@@MIC_AGENCY.TRG
@@MIC_AGENCY.GRT

PROMPT =====================================
PROMPT 
Exit Success