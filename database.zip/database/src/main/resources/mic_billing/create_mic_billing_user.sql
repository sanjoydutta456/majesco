PROMPT
PROMPT ===================================================
PROMPT Executing create_mic_billing_user.sql
PROMPT ===================================================


PROMPT =====================================
PROMPT 
EXIT SUCCESS