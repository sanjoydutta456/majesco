PROMPT
PROMPT =====================================
PROMPT Executing create_mic_client_user.sql
PROMPT =====================================


PROMPT =====================================
PROMPT 
EXIT SUCCESS