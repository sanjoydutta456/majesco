PROMPT
PROMPT =====================================
PROMPT Executing install_mic_client.sql
PROMPT =====================================

Set Verify Off
WhenEver SqlError Exit Sql.SqlCode
WHENEVER OSERROR EXIT SQL.OSCODE

DEFINE indextbsp=&1

@@mic_client.tab
@@mic_client.seq
@@mic_client.con
@@mic_client.ind
@@mic_client.trg
@@mic_client.vw
@@mic_client.grt

PROMPT =====================================
PROMPT 
Exit Success