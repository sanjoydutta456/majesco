PROMPT
PROMPT ====================================================
PROMPT Executing create_mic_common_user.sql
PROMPT =====================================================


PROMPT =====================================
PROMPT
EXIT SUCCESS