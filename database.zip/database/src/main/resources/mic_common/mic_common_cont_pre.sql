PROMPT
PROMPT ========================================
PROMPT Executing mic_common_cont_pre.sql from install path
PROMPT =======================================
DEFINE mic_policy_user=&1
DEFINE customercode=&2

PROMPT *** In install path, need grts/syns to MQP
CREATE OR REPLACE SYNONYM MIS_QUOTE_POLICIES FOR &&mic_policy_user..MIS_QUOTE_POLICIES;
CREATE OR REPLACE SYNONYM EV_MIS_QUOTE_POLICIES FOR &&mic_policy_user..EV_MIS_QUOTE_POLICIES;
CREATE OR REPLACE SYNONYM VW_MIS_QUOTE_POLICIES FOR &&mic_policy_user..VW_MIS_QUOTE_POLICIES;

PROMPT ===========================
PROMPT 

UNDEFINE mic_policy_user
UNDEFINE customercode

EXIT SUCCESS