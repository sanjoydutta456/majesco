PROMPT
PROMPT ===============================================
PROMPT Executing install_mic_imaging.sql
PROMPT ===============================================
SET VERIFY OFF
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
WHENEVER OSERROR EXIT OSCODE

DEFINE indextbsp=&1

@@mic_imaging.ind

PROMPT =====================================
PROMPT 
EXIT SUCCESS
