PROMPT
PROMPT ==============================================
PROMPT Executing create_mic_messaging_user.sql
PROMPT ==============================================


PROMPT =====================================
PROMPT 
EXIT SUCCESS