PROMPT
PROMPT ==============================================
PROMPT Executing install_mic_messaging.sql
PROMPT ==============================================

SET VERIFY OFF
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
WHENEVER OSERROR EXIT OSCODE

DEFINE indextbsp=&1

@@mic_messaging.tab
@@mic_messaging.seq
@@mic_messaging.con
@@mic_messaging.ind
@@mic_messaging.prc
@@mic_messaging.trg
@@mic_messaging.qta
@@mic_messaging.vw
@@mic_messaging.grt

PROMPT =====================================
PROMPT 
EXIT SUCCESS