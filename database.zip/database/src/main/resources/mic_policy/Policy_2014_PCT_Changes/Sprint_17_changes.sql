PROMPT ================================
PROMPT Executing mic_policy_common.dtab
PROMPT ================================
SET VERIFY OFF SERVEROUTPUT ON SIZE 1000000
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
WHENEVER OSERROR EXIT OSCODE
 
SET ESCAPE \

DECLARE 
   p_error         LONG;
   p_id            NUMBER;
   v_return        NUMBER;
   user_exception  EXCEPTION;
BEGIN


	k_pct_management_new.G_DEBUG_MODE := 'Y' ;

v_return := k_pct_management_new.f_set_query('',p_id,'VALIDATE_IF_RC_IS_PERFORMED','','SELECT (
  CASE 
    WHEN 
 (
 
 INSURED.BUSINESS_NAME IS NULL
 OR 
 PRODUCER.PRODUCER_CODE IS NULL
 OR 
 (
  UNDERWRITER.COVERAGE_EFFECTIVE_DATE IS NULL
 
  )
 OR
 UNDERWRITER.UNDERWRITER_NAME IS NULL
 OR
 (
  (
   INSURED.FEIN IS NULL 
   OR
   ((SELECT DECODE(COUNT(1),0,''N'',''Y'') FROM DUAL
   WHERE  LENGTH(REGEXP_REPLACE(INSURED.FEIN,''[-]'',''''))  = 9) = ''N'')
  )
  AND 
  (
   CONTACT.PHONE_1 IS NULL 
  OR
   ((SELECT DECODE(COUNT(1),0,''N'',''Y'') FROM DUAL
    WHERE  LENGTH(REGEXP_REPLACE(REGEXP_REPLACE(REGEXP_REPLACE(CONTACT.PHONE_1,''[-]'',''''), ''[(]'', ''''), ''[)]'', '''')) = 13) =''N'')
  )
 )
 OR
  (
    ADDRESS.LINE_1 IS NULL
  OR
    ADDRESS.CITY IS NULL
  OR
    ADDRESS.STATE_DESC IS NULL
  OR
    ADDRESS.ZIP_CODE IS NULL
   )
 )  
  THEN ''N''
  ELSE ''Y''
  END) 
FROM EV_MIS_INSUREDS INSURED, VW_MIS_ADDRESSES ADDRESS, VW_MIS_CONTACTS CONTACT, VW_MIS_PRODUCERS PRODUCER, VW_MIS_UNDERWRITING_DETAILS UNDERWRITER
  WHERE INSURED.GID = ADDRESS.INSURED_ADDRESS
   AND INSURED.GID = CONTACT.INSURED_CONTACT
   AND INSURED.GID = PRODUCER.INSURED_PRODUCER
   AND INSURED.GID = UNDERWRITER.IN_UNDERWRITING_DETAILS
   AND INSURED.GID = ''{field:ENTITY_REFERENCE}''
   AND ADDRESS.FK_COLUMN_NAME = ''INSURED_ADDRESS''
   AND CONTACT.FK_COLUMN_NAME = ''INSURED_CONTACT''
   AND UNDERWRITER.FK_COLUMN_NAME = ''IN_UNDERWRITING_DETAILS''','Y','This Query validates Risk Clearance is performed or not.','','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;


	v_return := k_pct_management_new.f_set_criteria('',p_id,'ZNK-COM-0042','1','','','param:ENTITY_TYPE','=','''INSURED''','','AND','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'ZNK-COM-0042','2','','NVL(','queryvalue:CHK_IF_RC_IS_TURNED_ON',', ''Y'') =','''Y''','','','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_object_field_valns('',p_id,'ZKN-COM-0003',k_pct_management_new.f_get_object_field_id('INSURED','FEIN') ,k_pct_management_new.f_get_object_field_id('INSURED','FEIN') ,'SE','ZNK-COM-0042',k_pct_management_new.f_get_query_id('VALIDATE_IF_RC_IS_PERFORMED'),k_pct_management_new.f_get_validator_id(''),'ON_FULL_SAVE','Insufficient Data, Enter all the required fields.
','','admin@cover-all.com','Y',p_error,'','BLOCKED', '', '', '400', '700', '', '', '', '', '', '', '', '', '', '', '','', '');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

	--changes for : don't display RC success popup when editing insured through Insured dashboard
	
v_return := k_pct_management_new.f_set_criteria('',p_id,'19856','1','','','param:ENTITY_TYPE','=','''INSURED''','','AND','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'19856','2','','','field:INSURED_SEARCH_COMPLETE','=','''Y''','','AND','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'19856','3','','','queryvalue:GET_RISK_CLEARANCE_STATUS','=','''Y''','','AND','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('D',p_id,'19856','4','','NVL(','ack:/'||k_pct_management_new.f_get_object_field_id('INSURED','INSURED_RISK_CLEAR_SUCCESS')||'/(RESPONSE/@value)',', ''@'') NOT IN','(''Y'', ''N'')','','','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'19856','4','','NVL(','queryvalue:CHK_IF_RC_IS_TURNED_ON',', ''Y'') =','''Y''','','AND','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'19856','5','','NVL(','queryvalue:GET_RISK_CLEARANCE_OVERRIDE_STATUS',', ''N'') =','''N''','','AND','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'19856','6','','NVL(','param:displayRCSuccessPopup',', ''true'') <>','''false''','','','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'13178',k_pct_management_new.f_get_object_field_id('Insured','INSURED_RISK_CLEAR_SUCCESS'),'SE','19856','','','','','','N','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',NULL,'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

--Changes for TRC-100 ("Do we need a cancel option when similar accounts found?")

v_return := k_pct_management_new.f_set_operation('',p_id,'20835','1','com.coverall.pct.client.operations.CancelRCPopup','Exact / Similar Popup Cancel','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_operation_param('',p_id,k_pct_management_new.f_get_operation_id('20835', '1'),'response','CAN','','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_toolbar('',p_id,'Similar Account Cancel',NULL,'SE','','','',20835,'2','Cancel popup','CANCEL','FORM','','','RIGHT','admin@cover-all.com','Y',p_error,'N','','Y','','','','','','','','','','21237','','','',k_pct_management_new.f_get_object_field_id('Insured','INSURED_SIMILAR_ACCOUNTS'));  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_toolbar('',p_id,'Exact Account Cancel',NULL,'SE','','','',20835,'2','Cancel popup','CANCEL','FORM','','','RIGHT','admin@cover-all.com','Y',p_error,'N','','Y','','','','','','','','','','21236','','','',k_pct_management_new.f_get_object_field_id('Insured','INSURED_EXACT_ACCOUNTS'));  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


-----------------------
--Below changes to resolve issue of autogenerate error when Underwriter overides RC failure.

v_return := k_pct_management_new.f_set_query('',p_id,'GET_RISK_LOCK_KEY_FOR_UNDERWRITER','','     SELECT RISK_LOCK_KEY FROM (SELECT TO_NUMBER(CASE 
             --USE THE SAME ROW IF THE ROW IS RECENTLY ADDED (WITHIN 10 SEC)
            WHEN (SELECT COUNT(1) FROM VW_MIS_RISK_LOCKING WHERE entity_reference =''{field:ENTITY_REFERENCE}'' AND DATE_MODIFIED > (SYSDATE - 10/86400))>0
            THEN (1)
            --USE THE SAME ROW ,IF THE ROW IS ADDED BY OVERRIDING RC FAILURE.
            WHEN (
                (SELECT RISK_CLEAR_OVERIDE_STATUS FROM VW_MIS_RISK_CLEARANCE WHERE ENTITY_REFERENCE=''{field:ENTITY_REFERENCE}'')=''Y''
                AND
                (SELECT RISK_LOCK_ACQUIRED FROM VW_MIS_RISK_LOCKING WHERE ENTITY_REFERENCE=''{field:ENTITY_REFERENCE}'')=''N''
                )
                
            THEN (1)
       
            WHEN ( select count(1) FROM VW_MIS_RISK_LOCKING
                where ENTITY_REFERENCE = ''{field:ENTITY_REFERENCE}''
                AND RISK_LOCK_ACQUIRED = ''Y''
                AND SYSDATE < NVL(RISK_LOCK_EXPIRATION_DATE,''31-DEC-2099'')  AND SYSDATE > RISK_LOCK_ACQUIRED_DATE )=''0'' 
            THEN ((SELECT RISK_LOCK_KEY FROM
  (select (NVL(MAX(RISK_LOCK_KEY),0)+1) RISK_LOCK_KEY from VW_MIS_RISK_LOCKING
    WHERE entity_reference = ''{field:ENTITY_REFERENCE}'' AND entity_type =  ''{field:ENTITY_TYPE}'')))
    ELSE (1)
END ) RISK_LOCK_KEY FROM DUAL)','N','Get Risk Lock Config','','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;



v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'SPD-COM-0048',k_pct_management_new.f_get_object_field_id('Insured','INSURED_RISK_LOCK'),'SE','SPD-COM-0032','*','','','','','','Y','','','',k_pct_management_new.f_get_query_id('GET_RISK_LOCK_KEY_FOR_UNDERWRITER'),'','','','','','','','','','','','','','','','','U','','','',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_RISK_LOCK'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'IN(allow_risk_clearance_override)','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

--END of "changes to resolve issue of autogenerate error when Underwriter overides RC failure".	


-- for TRC-87
	v_return := k_pct_management_new.f_set_query('',p_id,'SIMILAR_ACCOUNTS_CUSTOMIZATION','','SELECT (
  CASE 
    WHEN 
 (
 
 INSURED.BUSINESS_NAME IS NULL
 OR 
 PRODUCER.PRODUCER_CODE IS NULL
 OR 
 (
  UNDERWRITER.COVERAGE_EFFECTIVE_DATE IS NULL
 OR (
            UNDERWRITER.COVERAGE_EFFECTIVE_DATE < trunc(SYSDATE)
                    and
           ''{user:role(allow_risk_clearance_override)}'' = ''N'' 
        )
  )
 OR
 UNDERWRITER.UNDERWRITER_NAME IS NULL
 OR
 (
  (
   INSURED.FEIN IS NULL 
   OR
   ((SELECT DECODE(COUNT(1),0,''N'',''Y'') FROM DUAL
   WHERE  LENGTH(REGEXP_REPLACE(INSURED.FEIN,''[-]'',''''))  = 9) = ''N'')
  )
  AND 
  (
   CONTACT.PHONE_1 IS NULL 
  OR
   ((SELECT DECODE(COUNT(1),0,''N'',''Y'') FROM DUAL
    WHERE  LENGTH(REGEXP_REPLACE(REGEXP_REPLACE(REGEXP_REPLACE(CONTACT.PHONE_1,''[-]'',''''), ''[(]'', ''''), ''[)]'', '''')) = 13) =''N'')
  )
 )
 OR
  (
    ADDRESS.LINE_1 IS NULL
  OR
    ADDRESS.CITY IS NULL
  OR
    ADDRESS.STATE_DESC IS NULL
  OR
    ADDRESS.ZIP_CODE IS NULL
   )
 )  
  THEN ''N''
 
 WHEN (
k_risk_clearance_management.GET_EXACT_ACCOUNT_COUNT( ''{field:ENTITY_TYPE}'' ,  ''{field:ENTITY_REFERENCE}'' )  >0
) THEN
      ''N''
   
   WHEN (
 k_risk_clearance_management.GET_SIMILAR_ACCOUNT_COUNT( ''{field:ENTITY_TYPE}'' ,  ''{field:ENTITY_REFERENCE}'' )> 0
) THEN
      ''Y''
    ELSE 
      ''N''
  END) 
FROM EV_MIS_INSUREDS INSURED, VW_MIS_ADDRESSES ADDRESS, VW_MIS_CONTACTS CONTACT, VW_MIS_PRODUCERS PRODUCER, VW_MIS_UNDERWRITING_DETAILS UNDERWRITER
  WHERE INSURED.GID = ADDRESS.INSURED_ADDRESS
   AND INSURED.GID = CONTACT.INSURED_CONTACT
   AND INSURED.GID = PRODUCER.INSURED_PRODUCER
   AND INSURED.GID = UNDERWRITER.IN_UNDERWRITING_DETAILS
   AND INSURED.GID = ''{field:ENTITY_REFERENCE}''
   AND ADDRESS.FK_COLUMN_NAME = ''INSURED_ADDRESS''
   AND CONTACT.FK_COLUMN_NAME = ''INSURED_CONTACT''
   AND UNDERWRITER.FK_COLUMN_NAME = ''IN_UNDERWRITING_DETAILS''','N','Similar account customization','','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;


v_return := k_pct_management_new.f_set_query('',p_id,'EXACT_ACCOUNTS_CUSTOMIZATION','','SELECT (
  CASE 
    WHEN
 (
 
 INSURED.BUSINESS_NAME IS NULL
 OR 
 PRODUCER.PRODUCER_CODE IS NULL
 OR 
(
  UNDERWRITER.COVERAGE_EFFECTIVE_DATE IS NULL
 OR (
            UNDERWRITER.COVERAGE_EFFECTIVE_DATE < trunc(SYSDATE)
                    and
           ''{user:role(allow_risk_clearance_override)}'' = ''N'' 
        )
  )
 OR
 UNDERWRITER.UNDERWRITER_NAME IS NULL
 OR
 (
  (
   INSURED.FEIN IS NULL 
   OR
   ((SELECT DECODE(COUNT(1),0,''N'',''Y'') FROM DUAL
   WHERE  LENGTH(REGEXP_REPLACE(INSURED.FEIN,''[-]'',''''))  = 9) = ''N'')
  )
  AND 
  (
   CONTACT.PHONE_1 IS NULL 
  OR
   ((SELECT DECODE(COUNT(1),0,''N'',''Y'') FROM DUAL
    WHERE  LENGTH(REGEXP_REPLACE(REGEXP_REPLACE(REGEXP_REPLACE(CONTACT.PHONE_1,''[-]'',''''), ''[(]'', ''''), ''[)]'', '''')) = 13) =''N'')
  )
 )
 OR
  (
    ADDRESS.LINE_1 IS NULL
  OR
    ADDRESS.CITY IS NULL
  OR
    ADDRESS.STATE_DESC IS NULL
  OR
    ADDRESS.ZIP_CODE IS NULL
   )
 )
  THEN ''N''
   
 WHEN (
k_risk_clearance_management.GET_EXACT_ACCOUNT_COUNT( ''{field:ENTITY_TYPE}'' ,  ''{field:ENTITY_REFERENCE}'' ) >0
) THEN
      ''Y''
    ELSE 
      ''N''
  END) 
FROM EV_MIS_INSUREDS INSURED, VW_MIS_ADDRESSES ADDRESS, VW_MIS_CONTACTS CONTACT, VW_MIS_PRODUCERS PRODUCER, VW_MIS_UNDERWRITING_DETAILS UNDERWRITER
  WHERE INSURED.GID = ADDRESS.INSURED_ADDRESS
   AND INSURED.GID = CONTACT.INSURED_CONTACT
   AND INSURED.GID = PRODUCER.INSURED_PRODUCER
   AND INSURED.GID = UNDERWRITER.IN_UNDERWRITING_DETAILS
   AND INSURED.GID = ''{field:ENTITY_REFERENCE}''
   AND ADDRESS.FK_COLUMN_NAME = ''INSURED_ADDRESS''
   AND CONTACT.FK_COLUMN_NAME = ''INSURED_CONTACT''
   AND UNDERWRITER.FK_COLUMN_NAME = ''IN_UNDERWRITING_DETAILS''
','N','Exact account customization','','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;


v_return := k_pct_management_new.f_set_query('',p_id,'NO_MATCH_CUSTOMIZATION','','SELECT (
  CASE 
    WHEN 
   (
 
 INSURED.BUSINESS_NAME IS NULL
 OR 
 PRODUCER.PRODUCER_CODE IS NULL
 OR 
(
  UNDERWRITER.COVERAGE_EFFECTIVE_DATE IS NULL
 OR (
            UNDERWRITER.COVERAGE_EFFECTIVE_DATE < trunc(SYSDATE)
                    and
           ''{user:role(allow_risk_clearance_override)}'' = ''N'' 
        )
  )
 OR
 UNDERWRITER.UNDERWRITER_NAME IS NULL
 OR
 (
  (
   INSURED.FEIN IS NULL 
   OR
   ((SELECT DECODE(COUNT(1),0,''N'',''Y'') FROM DUAL
   WHERE  LENGTH(REGEXP_REPLACE(INSURED.FEIN,''[-]'',''''))  = 9) = ''N'')
  )
  AND 
  (
   CONTACT.PHONE_1 IS NULL 
  OR
   ((SELECT DECODE(COUNT(1),0,''N'',''Y'') FROM DUAL
    WHERE  LENGTH(REGEXP_REPLACE(REGEXP_REPLACE(REGEXP_REPLACE(CONTACT.PHONE_1,''[-]'',''''), ''[(]'', ''''), ''[)]'', '''')) = 13) =''N'')
  )
 )
 OR
  (
    ADDRESS.LINE_1 IS NULL
  OR
    ADDRESS.CITY IS NULL
  OR
    ADDRESS.STATE_DESC IS NULL
  OR
    ADDRESS.ZIP_CODE IS NULL
   )
 )
  THEN ''N''
 
 WHEN ( 
k_risk_clearance_management.GET_EXACT_ACCOUNT_COUNT( ''{field:ENTITY_TYPE}'' ,  ''{field:ENTITY_REFERENCE}'' )= 0
   AND
   k_risk_clearance_management.GET_SIMILAR_ACCOUNT_COUNT( ''{field:ENTITY_TYPE}'' ,  ''{field:ENTITY_REFERENCE}'' ) = 0
) THEN
      ''Y''
    ELSE 
      ''N''
  END) 
FROM EV_MIS_INSUREDS INSURED, VW_MIS_ADDRESSES ADDRESS, VW_MIS_CONTACTS CONTACT, VW_MIS_PRODUCERS PRODUCER, VW_MIS_UNDERWRITING_DETAILS UNDERWRITER
  WHERE INSURED.GID = ADDRESS.INSURED_ADDRESS
   AND INSURED.GID = CONTACT.INSURED_CONTACT
   AND INSURED.GID = PRODUCER.INSURED_PRODUCER
   AND INSURED.GID = UNDERWRITER.IN_UNDERWRITING_DETAILS
   AND INSURED.GID = ''{field:ENTITY_REFERENCE}''
   AND ADDRESS.FK_COLUMN_NAME = ''INSURED_ADDRESS''
   AND CONTACT.FK_COLUMN_NAME = ''INSURED_CONTACT''
   AND UNDERWRITER.FK_COLUMN_NAME = ''IN_UNDERWRITING_DETAILS''','N','No account match customization','','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;


v_return := k_pct_management_new.f_set_criteria('',p_id,'ZNK-COM-0047','1','',' to_date(','field:COVERAGE_EFFECTIVE_DATE',', ''MM/DD/YYYY'') >= trunc(','SYSDATE',')','OR','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'ZNK-COM-0047','2','','','field:INSURED_SEARCH_COMPLETE','=','''Y''','','','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;



v_return := k_pct_management_new.f_set_object_field_valns('',p_id,'ZNK-COM-0005',k_pct_management_new.f_get_object_field_id('Underwriter Details','COVERAGE_EFFECTIVE_DATE'),k_pct_management_new.f_get_object_field_id('Underwriter Details','COVERAGE_EFFECTIVE_DATE'),'SE','ZNK-COM-0047',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_validator_id(''),'ON_FULL_SAVE','Enter valid Coverage Effective Date','','admin@cover-all.com','Y',p_error,'','BLOCKED', '', '', '', '', 'IN(agent_role)', '', '', '', '', '', '', '', '', '', '','', '');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;




--end for TRC-87
	
	v_return := k_pct_management_new.f_set_query('',p_id,'GET_RISK_LOCK_KEY','','  SELECT RISK_LOCK_KEY
FROM
  (SELECT TO_NUMBER(DECODE(
    (SELECT COUNT(1) FROM VW_MIS_RISK_LOCKING WHERE ENTITY_REFERENCE =  ''{field:ENTITY_REFERENCE}''
    AND RISK_LOCK_ACQUIRED                                           = ''Y''
    AND SYSDATE                                                      < NVL(RISK_LOCK_EXPIRATION_DATE,''31-DEC-2099'')
    AND SYSDATE                                                      > RISK_LOCK_ACQUIRED_DATE
    ) ,''0'',(
    CASE
      WHEN ( (SELECT COUNT(1)
        FROM vw_mis_risk_locking
        WHERE risk_lock_acquired       =''N''
        AND RISK_LOCK_ACQUIRED_DATE   IS NULL
        AND RISK_LOCK_EXPIRATION_DATE IS NULL
        AND PERMANENT_LOCK             = ''N''
        AND gid                       IN
          (SELECT MAX(gid)
          FROM vw_mis_risk_locking
          WHERE entity_reference= ''{field:ENTITY_REFERENCE}''
          AND entity_type       =''{field:ENTITY_TYPE}''
          ))                    >0 )
      THEN 1 --if insured contains empty rown then return use same row
      ELSE
        (SELECT RISK_LOCK_KEY
        FROM
          (SELECT (NVL(MAX(RISK_LOCK_KEY),0)+1) RISK_LOCK_KEY
          FROM VW_MIS_RISK_LOCKING
          WHERE entity_reference =  ''{field:ENTITY_REFERENCE}''
          AND entity_type        = ''{field:ENTITY_TYPE}''
          )
        ) -- else original
    END ),''1'') ) RISK_LOCK_KEY
  FROM DUAL
  ) 
    ','N','Get Risk Lock Config','','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;


	
  v_return := k_pct_management_new.f_set_qualifier('',p_id,'26007','','SE','','','','','endorsePolicy','For RCReleaseLock for Non-Renewed Policy transaction ','admin@cover-all.com','Y',p_error,NULL,NULL,'','');
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

  v_return := k_pct_management_new.f_set_rh_processors('',p_id,'26009','1','26007','FINALIZE_TRANSACTION','POST','com.coverall.pctv2.server.rh.processors.RCReleaseLockProcessor','admin@cover-all.com','Y',p_error);
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

  v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Policy',''),p_id,'LOSE_REASON_DESC',k_pct_management_new.f_get_object_id('Policy'),k_pct_management_new.f_get_primitive_id('Long Description'),k_pct_management_new.f_get_object_id(''),NULL,'LOSE_REASON_DESC','NA','','','','','Lost Reason Description','N','Y','N','','2010','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Policy',''),p_id,'LOSE_CARRIER',k_pct_management_new.f_get_object_id('Policy'),k_pct_management_new.f_get_primitive_id('Short Description'),k_pct_management_new.f_get_object_id(''),NULL,'LOSE_CARRIER','NA','','','','','Lost Carrier','N','Y','N','','2115','',k_pct_management_new.f_get_query_id('GET_LOSE_CARRIER'),'','N','N',NULL,'N','Y','Y','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Policy',''),p_id,'LOSE_PREMIUM_AMOUNT',k_pct_management_new.f_get_object_id('Policy'),k_pct_management_new.f_get_primitive_id('SIGNED USD'),k_pct_management_new.f_get_object_id(''),NULL,'LOSE_PREMIUM_AMOUNT','NA','','','','','Lost Premium Amount','N','Y','N','','2215','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Policy',''),p_id,'NOT_WRITTEN_REASON_DESC',k_pct_management_new.f_get_object_id('Policy'),k_pct_management_new.f_get_primitive_id('Long Description'),k_pct_management_new.f_get_object_id(''),NULL,'NOT_WRITTEN_REASON_DESC','NA','','','','','Not Written Reason Description','N','Y','N','','2445','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Policy',''),p_id,'NOT_WRITTEN_LOSE_CARRIER',k_pct_management_new.f_get_object_id('Policy'),k_pct_management_new.f_get_primitive_id('Short Description'),k_pct_management_new.f_get_object_id(''),NULL,'NOT_WRITTEN_LOSE_CARRIER','NA','','','','','Not Written Carrier','N','Y','N','','2645','',k_pct_management_new.f_get_query_id('GET_NOT_WRITTEN_CARRIER'),'','N','N',NULL,'N','Y','Y','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Policy',''),p_id,'NW_LOST_PREMIUM_AMOUNT',k_pct_management_new.f_get_object_id('Policy'),k_pct_management_new.f_get_primitive_id('SIGNED USD'),k_pct_management_new.f_get_object_id(''),NULL,'NW_LOST_PREMIUM_AMOUNT','NA','','','','','Premium Amount Lost','N','Y','N','','2685','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Policy',''),p_id,'DECLINATION_REASON_DESC',k_pct_management_new.f_get_object_id('Policy'),k_pct_management_new.f_get_primitive_id('Long Description'),k_pct_management_new.f_get_object_id(''),NULL,'DECLINATION_REASON_DESC','NA','','','','','Declination Reason Description','N','Y','N','','2150','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_query('',p_id,'GET_QUOTES_FOR_PROPOSAL_SECURA_ROLE','','SELECT  PROPOSAL_QUOTE_NUMBER, PROPOSAL_QUOTE_REVISION ,PROPOSAL_QUOTE_STATUS,PROPOSAL_QUOTE_PREMIUM,PROPOSAL_LAST_MODIFIED,PROPOSAL_MODIFIED_BY, QUOTE_ENTITY_REFERENCE FROM ( SELECT qp.DISPLAY_POLICY_NUMBER PROPOSAL_QUOTE_NUMBER,
  qp.REVISION_NUMBER PROPOSAL_QUOTE_REVISION ,
 K_Workflow_Activity_Management.F_GET_STATUS(qp.entity_type, qp.entity_reference) PROPOSAL_QUOTE_STATUS ,
  qp.ANNUAL_PREMIUM PROPOSAL_QUOTE_PREMIUM,
  qp.DATE_MODIFIED PROPOSAL_LAST_MODIFIED,
  qp.USER_MODIFIED PROPOSAL_MODIFIED_BY,
  qp.entity_reference QUOTE_ENTITY_REFERENCE
FROM vw_mis_insureds ins ,
  vw_mis_quote_policies qp
WHERE ins.entity_reference = qp.entity_reference
AND ins.entity_type = qp.entity_type AND ins.master_record_gid = ''{param:INSUREDGID}'' AND  k_risk_clearance_management.f_get_proposal_eligible_quotes(qp.entity_reference,qp.entity_type) = ''Y'' and qp.ENTITY_VIEW_MODE is null )','N','Get Quotes for Proposal for Secura role','','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;



v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'NSK-COM-0011',k_pct_management_new.f_get_object_field_id('Proposed Quotes','PROPOSAL_QUOTE_NUMBER'),'SE','','','','','','','','','','','',k_pct_management_new.f_get_query_id('GET_QUOTES_FOR_PROPOSAL_SECURA_ROLE'),'','','','','','','','','','','','','','','','','','','','',NULL,'','','','','','','','','','admin@cover-all.com','Y',p_error,'IN(allow_risk_clearance_override)','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


--Added changes for replacing table names IEL_MIC_RISK_CLEARANCE_PAS_WT_ and IEL_MIC_RISK_CLEARANCE_RULES_ with IEL_MIC_RC_PAS_WT_ and IEL_MIC_RC_RULES_ respt
v_return := k_pct_management_new.f_set_query('',p_id,'GET_RC_RULE_FAILURE_WEIGHTAGE_MSG_FOR_SECURA_USER','','SELECT (RISK_CL_RULE_FAIL_MSG ||''. <br> ''||k_risk_clearance_management.GET_RC_FAIL_EXACT_ACC_DATA_MSG(''{field:ENTITY_TYPE}'',''{field:ENTITY_REFERENCE}'') ) RISK_CL_RULE_FAIL_MSG, 0 RISK_CLRNCE_RULE_WEIGHT from IEL_MIC_RC_RULES where RULE_KEY = ''{field:RISK_RULE_KEY}''','N','Get Risk Clearance Failure Message and Weight for Secura User','','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;
  

--Added changes for policy number search issue  
v_return := k_pct_management_new.f_set_query('',p_id,'POLICY_PRODUCER_AUTO_GENERATE','','SELECT producer_code, display_producer_code, name, producer_of_record, distinguished_field_uw, surplus_lines, good_standing, license_producer_code, license_no, license_states, primary, commission, override_commission, direct_bill_indicator, sub_agent, application_producer, market_manager  FROM (SELECT
  p.producer_code producer_code,
  p.display_producer_code display_producer_code,
  p.name name,
  p.producer_of_record producer_of_record,
  p.distinguished_field_uw distinguished_field_uw,
  p.surplus_lines surplus_lines,
  p.good_standing good_standing,
  p.license_producer_code license_producer_code,
  p.license_no license_no,
  p.license_states license_states,
  ''Y'' primary,
  p.commission commission,
  p.override_commission override_commission,
  p.direct_bill_indicator direct_bill_indicator,
  p.sub_agent sub_agent,
  p.application_producer application_producer,
  p.market_manager market_manager
FROM
  vw_mis_producers p
WHERE
  p.insured_producer = ''{param:INSUREDGID}'')','N','Defaulting of Producer','','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;
  
v_return := k_pct_management_new.f_set_qualifier_criteria('',p_id,'MIG-DATA-0011093','SELECT CASE WHEN    (  (''{global:PRODUCT_CODE}'' = ''WK''   OR     ''{param:product_code}'' = ''WK'')    AND ''{field:ENTITY_STATUS}'' <> ''AUTO'' ) THEN  ''Y'' ELSE ''N'' END FROM vw_mis_producers
 where entity_reference =  ''{field:ENTITY_REFERENCE}''
  AND entity_type= ''QUOTE''','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

-- BILLING CHANGES BEGIN
v_return := k_pct_management_new.f_set_query('',p_id,'BILL_TYPE_LOOKUP','','SELECT ''Direct Bill'' BILL_TYPE FROM DUAL UNION SELECT ''Agency Bill'' BILL_TYPE FROM DUAL','N','Bill type lookup query','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_query('',p_id,'BILL_PLAN_LOOKUP','','SELECT ''10 Pay'' BILL_PLAN, 1 display_order FROM DUAL UNION SELECT ''12 Pay'' BILL_PLAN , 2 display_order FROM DUAL','N','Bill plan lookup query','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_query('',p_id,'BILL_POLICY_ASSIGN_LOOKUP','','SELECT 
    p.POLICY_NUMBER POLICY_NUMBER
  , to_char(p.EFFECTIVE_DATE, ''mm/dd/yyyy'') EFFECTIVE_DATE
  , to_char(p.EXPIRATION_DATE, ''mm/dd/yyyy'') EXPIRATION_DATE
  , p.ORG_ENTITY_REFERENCE POLICY_ORG_ENTITY_REF 
  , p.product_code LOB
  , p.product_name product_name
  , pol_pr.producer_code AGENCY_CODE
  , p.written_premium policy_premium
FROM VW_MIS_QUOTE_POLICIES p, VW_MIS_PRODUCERS pol_pr, VW_MIS_INSUREDS pol_ins
, VW_MIS_INSUREDS ins, VW_MIS_PRODUCERS ins_pr
where 1 = 1
and p.gid = pol_pr.policy_producer
and p.gid = pol_ins.policy_insured
and p.ENTITY_TYPE = ''POLICY''
and p.POLICY_NUMBER is not null
and p.revision_number = 0
and pol_pr.producer_of_record = ''Y''
and ins.gid = {GLOBAL:INSURED_GID}
and ins.gid = ins_pr.insured_producer
and ins_pr.producer_code = pol_pr.producer_code
and pol_ins.master_record_gid = ins.gid
and (p.ORG_ENTITY_REFERENCE) not in (
  select NVL(ba.POLICY_ORG_ENTITY_REF, ''-1'')
  from ev_mis_billing_account bacc
  , (
        SELECT id, renewal_counter, MAX(gid) max_gid
        FROM ev_mis_billing_account
        where insured_gid = {GLOBAL:INSURED_GID}
        GROUP BY id, renewal_counter
  ) bacc_max, vw_mis_billing_account_assign ba
  where bacc.gid = bacc_max.max_gid
  and bacc.gid = ba.bill_acc_pol_assignment
)
and k_transaction_management.f_is_policy_ready_for_booking(p.entity_type,p.entity_reference) = ''Y''','N','Bill policy assignment lookup query','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_query('',p_id,'BILL_TYPE_LOOKUP_SE','','SELECT bill_type bill_type, bill_type_code bill_type_code
FROM iel_mic_bill_types lookup_tab
WHERE 1 = 1
AND  {tl:iel_mic_bill_types~lookup_tab~bill_type,bill_type_code~N~TO_DATE(''01-JAN-1970'',''DD-MON-YYYY'')}
AND lookup_tab.bill_type_code not in (
  select ''A'' from dual where k_billing_utilities.producer_set_for_agency_bill({GLOBAL:INSURED_GID}) = ''N''
  )','N','Bill type lookup query','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_query('',p_id,'BILL_PLAN_LOOKUP_SE','','{PLSQL:
DECLARE
  v_lookup_empty_query         VARCHAR2(32767);
  v_lookup_query               VARCHAR2(32767);
  v_selected_policies_exp      PLSQL_EXP;
  v_lookup_query_exp           PLSQL_EXP;

  v_bill_type_code             MIS_BILLING_ACCOUNT.IBL_BILL_TYPE_CODE%TYPE;
  TYPE type_ref_cur            IS REF CURSOR;  
  v_table_name_cursor          TYPE_REF_CUR;
  
  v_program_code               VARCHAR2(4000);
  v_market_segment_code        VARCHAR2(4000);
  v_premium                    MIS_QUOTE_POLICIES.MQP_WRITTEN_PREMIUM%TYPE;

  v_entity_reference_curr      MIS_QUOTE_POLICIES.MQP_ENTITY_REFERENCE%TYPE;
  v_program_code_curr          MIS_QUOTE_POLICIES.MQP_PROGRAM_CODE%TYPE;
  v_market_segment_code_curr   MIS_QUOTE_POLICIES.MQP_MARKET_SEGMENT_CODE%TYPE;
  
  v_selected_policies_query    VARCHAR2(4000);
  v_sql_max_revisions          VARCHAR2(4000);
  v_sql_threshold_data         VARCHAR2(4000);

  v_lookup_query_bill_plan_exp PLSQL_EXP;
  v_query_bill_plan_temp       VARCHAR2(4000);
  
  v_lookup_query_threshold_exp PLSQL_EXP;
  v_query_threshold_temp       VARCHAR2(32000);
  
  -- TableName holders
  v_tname_iel_bill_plan        VARCHAR2(3000);
  v_tname_bill_acc_assign      VARCHAR2(3000);
  v_tname_mis_quote_policies   VARCHAR2(3000);
  v_tname_iel_bill_threshold   VARCHAR2(32000);
  v_tname_iel_bill_type        VARCHAR2(32000);
  v_user_role                  VARCHAR2(512) := '''';
  is_debugging                 BOOLEAN := false;
  v_policy_org_entity_ref      VARCHAR2(3000);
BEGIN
  v_bill_type_code := ''{FIELD:BILL_TYPE_CODE}'';

  v_user_role := ''xx'';
  if ''{user:role(agent_role)}'' = ''Y'' then
    v_user_role := v_user_role || '',agent_role'';
  end if;
  if ''{user:role(underwriter_role)}'' = ''Y'' then
    v_user_role := v_user_role || '',underwriter_role'';
  end if;
  
  v_user_role := replace(v_user_role, '','', '''''',''''''); -- replace , with '',''
  v_user_role := '''''''' || v_user_role || ''''''''; -- add single quote in beginning and end
  
  v_tname_bill_acc_assign := '''';
  v_tname_mis_quote_policies := ''vw_mis_quote_policies'';
  v_tname_iel_bill_plan := ''iel_mic_bill_plans'';
  v_tname_iel_bill_threshold := '''';

  v_lookup_empty_query := ''SELECT bp.bill_plan bill_plan, bp.bill_plan_code bill_plan_code, bp.is_eft bill_plan_eft, bp.display_order FROM '' || v_tname_iel_bill_plan || '' bp where 1 = 2'';
  v_bill_type_code := ltrim(v_bill_type_code);
  v_bill_type_code := rtrim(v_bill_type_code);
  
  v_lookup_query := v_lookup_empty_query;
  if v_bill_type_code is null then
    v_lookup_query := v_lookup_empty_query;
    if is_debugging then DBMS_OUTPUT.PUT_LINE(''Exit 1. Bill type is not selected. v_lookup_query='' || v_lookup_query); end if;
    RETURN plsql_exp_result(k_plsql_exp_util.prepare_plsql_exp(v_lookup_query));
  end if;

  v_selected_policies_exp := PLSQL_EXP(''{CP:
    o1=/BILL_ACC_POL_ASSIGNMENT/;
    s1=o1.policy_org_entity_ref;
    s2=o1.policy_premium;
    cond=o1.policy_org_entity_ref is not null;
    }''
  );
  
  if v_selected_policies_exp.has_records() = ''N'' then
    v_lookup_query := v_lookup_empty_query;
    if is_debugging then DBMS_OUTPUT.PUT_LINE(''Exit 2. No policies selected. v_lookup_query='' || v_lookup_query); end if;
    RETURN plsql_exp_result(k_plsql_exp_util.prepare_plsql_exp(v_lookup_query));
  end if;
  
  v_policy_org_entity_ref := ''xx'';
  while( v_selected_policies_exp.has_records() = ''Y'' ) loop
    v_selected_policies_exp.next_record();
    v_policy_org_entity_ref := v_policy_org_entity_ref || '','' || v_selected_policies_exp.get_rec_value(''policy_org_entity_ref'');
  end loop;
  v_policy_org_entity_ref := replace(v_policy_org_entity_ref, '','', '''''',''''''); -- replace , with '',''
  v_policy_org_entity_ref := '''''''' || v_policy_org_entity_ref || ''''''''; -- add single quote in beginning and end

  if is_debugging then DBMS_OUTPUT.PUT_LINE(''v_policy_org_entity_ref='' || v_policy_org_entity_ref); end if;

  v_selected_policies_exp := PLSQL_EXP(''{CP:
    o1=/BILL_ACC_POL_ASSIGNMENT/;
    s1=sum(o1.policy_premium)~ alias=policy_premium_total;
    cond=o1.policy_org_entity_ref is not null;
    }''
  );
  
  v_premium := v_selected_policies_exp.get_value();
  if is_debugging then DBMS_OUTPUT.PUT_LINE(''v_premium='' || v_premium); end if;
  
  v_sql_threshold_data := ''
      select p.entity_reference, p.program_code, p.market_segment_code
      from '' || v_tname_mis_quote_policies || '' p 
      where p.entity_reference in ('' || v_policy_org_entity_ref || '')
      and p.entity_type = ''''POLICY'''' 
  '';
  if is_debugging then DBMS_OUTPUT.PUT_LINE(''v_sql_threshold_data='' || v_sql_threshold_data); end if;

  --compute distinct program code, market_segment_codes and written_premium
  v_program_code := '',@@,'';
  v_market_segment_code := '',@@,'';
  OPEN v_table_name_cursor FOR v_sql_threshold_data;
  LOOP
    FETCH v_table_name_cursor INTO v_entity_reference_curr, v_program_code_curr, v_market_segment_code_curr;
    EXIT WHEN v_table_name_cursor%NOTFOUND;
    
    if v_program_code_curr is not null then
      if INSTR(v_program_code, '','' || v_program_code_curr || '','') = 0 then
        v_program_code := v_program_code || '','' || v_program_code_curr || '','';
      end if;
    end if;
    
    if v_market_segment_code_curr is not null then
      if INSTR(v_market_segment_code, '','' || v_market_segment_code_curr || '','') = 0 then
        v_market_segment_code := v_market_segment_code || '','' || v_market_segment_code_curr || '','';
      end if;
    end if;
  END LOOP;
  CLOSE v_table_name_cursor;
  
  if is_debugging then DBMS_OUTPUT.PUT_LINE(''v_program_code='' || v_program_code); end if;
  if is_debugging then DBMS_OUTPUT.PUT_LINE(''v_market_segment_code='' || v_market_segment_code); end if;
  
  --,ab,,pc,,st,
  --,ab,pc,st, -- replace ,, with ,
  --''ab,pc,st'' -- remove first and last comma with single quote
  --''ab'',''pc'',''st'' -- replace , with '',''
  if v_program_code is not null then
    v_program_code := replace(v_program_code, '',,'', '',''); -- replace ,, with ,
    v_program_code := '''''''' || substr(v_program_code, 2, length(v_program_code)-2) || ''''''''; -- replace first and last comma with single quote
    v_program_code := replace(v_program_code, '','', '''''',''''''); -- replace , with '',''
  end if;
  
  if v_market_segment_code is not null then
    v_market_segment_code := replace(v_market_segment_code, '',,'', '',''); -- replace ,, with ,
    v_market_segment_code := '''''''' || substr(v_market_segment_code, 2, length(v_market_segment_code)-2) || ''''''''; -- replace first and last comma with single quote
    v_market_segment_code := replace(v_market_segment_code, '','', '''''',''''''); -- replace , with '',''
  end if;

  if is_debugging then DBMS_OUTPUT.PUT_LINE(''After manipulation v_program_code='' || v_program_code); end if;
  if is_debugging then DBMS_OUTPUT.PUT_LINE(''After manipulation v_market_segment_code='' || v_market_segment_code); end if;
  
  v_lookup_query_bill_plan_exp := PLSQL_EXP(''{TABLE:
    o1=iel_mic_bill_plans~keyColumns=bill_plan,bill_plan_code,is_eft~effDt=01/01/1970~useRateAdoption=N;
    s1=o1.bill_plan;
    s2=o1.bill_plan_code;
    s3=o1.is_eft;
    s4=o1.display_order;
  }''
  );
  
  v_query_bill_plan_temp := plsql_exp_result(v_lookup_query_bill_plan_exp).get_query();
  if is_debugging then DBMS_OUTPUT.PUT_LINE(''v_query_bill_plan_temp='' || v_query_bill_plan_temp); end if;

  v_lookup_query_threshold_exp := PLSQL_EXP(''{TABLE:
    o1=iel_mic_bill_plan_threshold~keyColumns=program_code,market_segment_code,bill_type_code,user_role,cust_acc_threshold,~effDt=01/01/1970~useRateAdoption=N~useTL=N;
    s1=o1.program_code;
    s2=o1.market_segment_code;
    s3=o1.bill_type_code;
    s4=o1.user_role;
    s5=o1.cust_acc_threshold;
    s6=o1.bill_plan_code;
  }''
  );
  v_query_threshold_temp := plsql_exp_result(v_lookup_query_threshold_exp).get_query();
  if is_debugging then DBMS_OUTPUT.PUT_LINE(''v_query_threshold_temp='' || v_query_threshold_temp); end if;
  
  v_lookup_query := ''
    SELECT distinct bp.bill_plan bill_plan, bp.bill_plan_code bill_plan_code, bp.is_eft bill_plan_eft, bp.display_order
    --, bpt.program_code, bpt.market_segment_code, bpt.bill_type_code, bpt.user_role, bpt.cust_acc_threshold
    FROM ('' || v_query_bill_plan_temp || '') bp , ('' || v_query_threshold_temp || '') bpt
    WHERE 1 = 1
    and bpt.bill_type_code = '''''' || v_bill_type_code || ''''''
    and bp.bill_plan_code = bpt.bill_plan_code
    and (bpt.program_code is null or nvl(bpt.program_code, ''''@@'''') in ('' || v_program_code || ''))
    and (bpt.market_segment_code is null or nvl(bpt.market_segment_code, ''''@@'''') in ('' || v_market_segment_code || ''))
    and nvl(bpt.cust_acc_threshold, 0) <= '' || v_premium || ''
    and (bpt.user_role is null OR bpt.user_role in ('' || v_user_role || ''))
    ORDER BY bp.display_order
  '';
  
  if is_debugging then DBMS_OUTPUT.PUT_LINE(''v_lookup_query='' || v_lookup_query); end if;
  RETURN plsql_exp_result(k_plsql_exp_util.prepare_plsql_exp(v_lookup_query));
END;
}
','N','Bill plan lookup query SE','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_query('D',p_id,'BILL_POLICY_ASSIGN_LOOKUP_SE','','SELECT 
    p.POLICY_NUMBER POLICY_NUMBER
  , to_char(p.EFFECTIVE_DATE, ''mm/dd/yyyy'') EFFECTIVE_DATE
  , to_char(p.EXPIRATION_DATE, ''mm/dd/yyyy'') EXPIRATION_DATE
  , p.ORG_ENTITY_REFERENCE POLICY_ORG_ENTITY_REF 
  , p.product_code LOB
  , p.product_name product_name
  , pol_pr.producer_code AGENCY_CODE
  , p.written_premium policy_premium
FROM VW_MIS_QUOTE_POLICIES p, VW_MIS_PRODUCERS pol_pr, VW_MIS_INSUREDS pol_ins
, VW_MIS_INSUREDS ins, VW_MIS_PRODUCERS ins_pr
where 1 = 1
and p.gid = pol_pr.policy_producer
and p.gid = pol_ins.policy_insured
and p.ENTITY_TYPE = ''POLICY''
and p.POLICY_NUMBER is not null
and p.revision_number = 0
and pol_pr.producer_of_record = ''Y''
and ins.gid = {GLOBAL:INSURED_GID}
and ins.gid = ins_pr.insured_producer
and ins_pr.producer_code = pol_pr.producer_code
and pol_ins.master_record_gid = ins.gid
and (p.ORG_ENTITY_REFERENCE) not in (
  select NVL(ba.POLICY_ORG_ENTITY_REF, ''-1'')
  from ev_mis_billing_account bacc
  , (
        SELECT id, renewal_counter, MAX(gid) max_gid
        FROM ev_mis_billing_account
        where insured_gid = {GLOBAL:INSURED_GID}
        GROUP BY id, renewal_counter
  ) bacc_max, vw_mis_billing_account_assign ba
  where bacc.gid = bacc_max.max_gid
  and bacc.gid = ba.bill_acc_pol_assignment
)
and k_transaction_management.f_is_policy_ready_for_booking(p.entity_type,p.entity_reference) = ''Y''','N','Bill policy assignment lookup query','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_query('',p_id,'BILL_ACCOUNT_HAVE_BOOKED_POLICIES','','select decode(count(1), 0, ''N'', ''Y'') is_policy_booked
from vw_mis_billing_account_assign ap, vw_mis_billing_account a
where 1 = 1
and a.gid = {field:GID}
and a.gid = ap.bill_acc_pol_assignment
and k_billing_utilities.is_policy_booked(ap.POLICY_ORG_ENTITY_REF) = ''Y''','N','Billing Account whether it has any booked policies','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_query('',p_id,'VALIDATE_BILL_ASSIGNED_POLICIES_SAME_EXP_DT','','{CP: 
 o1=/BILL_ACC_POL_ASSIGNMENT/;
 o2=/;
 s1=decode(count(distinct o1.EXPIRATION_DATE), 0, ''Y'', 1, ''Y'', ''N'')~ alias=exp_dt_count; 
 cond=o1.POLICY_NUMBER is not null;
 cond=o2.BILL_TYPE_CODE = ''D'';
 startingPoint=parent~reason=Need to check all the expiration dates;
}','N','Query to check whether all the policies under a billing account number have same expiration date','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_query('',p_id,'VALIDATE_BILL_ONE_POLICY_FOR_AGENCY_BILL','','{CP: 
 o1=/BILL_ACC_POL_ASSIGNMENT/;
 s1=decode(count(o1.POLICY_NUMBER), 0, ''Y'', 1, ''Y'', ''N'')~ alias=pol_count_agency_bill; 
 cond=''{field:BILL_TYPE_CODE}'' = ''A'';
}','N','Query to validate that there is only one policy for Agency Billing','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_query('',p_id,'VALIDATE_BILL_BAN_LENGTH','','SELECT 
  decode( ''{field:BILL_ACC_NUMBER_IS_MANUAL}''
   , ''Y'', decode(NVL(LENGTH({field:BILL_ACCOUNT_NUMBER}), 0), 0, ''Y'', 7, ''Y'', ''N'')
   , ''Y''
  ) length_val 
FROM dual','N','Validate length of billing account number','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_query('',p_id,'VALIDATE_BILL_CANNOT_REMOVE_POL_ASSOCIATION','','SELECT 
  DECODE(
     ''{field:POLICY_NUMBER}''
     , '''', ''Y''
     , DECODE(k_billing_utilities.is_policy_booked({field:POLICY_ORG_ENTITY_REF})
       , ''Y'', ''N'', ''Y''
     )
  ) can_delete
FROM DUAL','N','Validate to check if policy association can be removed','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_query('',p_id,'VALIDATE_BILL_BAN_SHOULD_BE_UNIQUE','','{PLSQL:
DECLARE
 v_is_valid                    CHAR(1) := ''Y'';
 v_bill_acc_numbers_exp        PLSQL_EXP;
 v_bill_acc_number_curr        MIS_BILLING_ACCOUNT.IBL_BILL_ACCOUNT_NUMBER%TYPE;
 v_bill_acc_number             MIS_BILLING_ACCOUNT.IBL_BILL_ACCOUNT_NUMBER%TYPE;
BEGIN
  v_bill_acc_number_curr := ''{FIELD:BILL_ACCOUNT_NUMBER}'';
  
  if v_bill_acc_number_curr is null then
    -- no need to validate as user has not entered the billing account number
    v_is_valid := ''Y'';
  else
    v_bill_acc_numbers_exp := PLSQL_EXP(''{TABLE:
      o1=vw_mis_billing_account;
      s1=distinct o1.bill_account_number~alias=bill_account_number;
      cond=o1.insured_gid = {FIELD:INSURED_GID};
      cond=o1.bill_account_number is not null;
      cond=o1.id <> {FIELD:ID};
      }''
    );
  
    while( v_bill_acc_numbers_exp.has_records() = ''Y'' ) loop
      v_bill_acc_numbers_exp.next_record();
      v_bill_acc_number := v_bill_acc_numbers_exp.get_rec_value(''bill_account_number'');
      
      if v_bill_acc_number = v_bill_acc_number_curr then
        v_is_valid := ''N'';
        EXIT;
      end if;
    end loop; 
  end if;
  
  RETURN plsql_exp_result(v_is_valid);
END;
}','N','Validation to check that billing account number is unique','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_query('',p_id,'VALIDATE_BILL_BAN_ON_DB_CANNOT_BE_A_POL_NR','','{CP: 
 o1=/;
 s1=decode(count(o1.BILL_ACCOUNT_NUMBER), 0, ''Y'', ''N'')~ alias=is_valid; 
 cond=o1.BILL_TYPE_CODE = ''D'';
 cond=''{field:POLICY_NUMBER}'' IS NOT NULL;
 cond=o1.BILL_ACCOUNT_NUMBER IS NOT NULL;
 cond=o1.BILL_ACCOUNT_NUMBER = ''{field:POLICY_NUMBER}'';
}','N','Direct bill account number cannot be the same as the policy number','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_query('',p_id,'VALIDATE_CAN_HAVE_MORE_THAN_ONE_BILL_TYPE','','{PLSQL:
DECLARE
 v_is_valid                    CHAR(1) := ''Y'';
 v_one_bill_type_per_cust      CHAR(1);
 v_bill_type_codes_exp         PLSQL_EXP;
 v_bill_type_code_curr         MIS_BILLING_ACCOUNT.IBL_BILL_PLAN_CODE%TYPE;
 v_bill_type_code              MIS_BILLING_ACCOUNT.IBL_BILL_PLAN_CODE%TYPE;
 v_counter                     NUMBER;
BEGIN
  if ''{user:role(agent_role)}'' = ''N'' AND ''{user:role(underwriter_role)}'' = ''N'' then
    RETURN plsql_exp_result(''N''); -- cannot add
  end if;

  if ''{user:role(underwriter_role)}'' = ''Y'' then
    RETURN plsql_exp_result(''Y''); -- underwriter can add any number of bill types
  end if;
  
  v_bill_type_code_curr := ''{FIELD:BILL_TYPE_CODE}'';
  v_bill_type_code_curr := trim(v_bill_type_code_curr);
  if v_bill_type_code_curr is null then
    RETURN plsql_exp_result(''Y''); -- too early to check
  end if;

  v_one_bill_type_per_cust := ''Y'';
  v_counter := 0;
  if v_bill_type_code_curr is not null then
    v_counter := v_counter + 1;
  end if;
  
  if v_one_bill_type_per_cust = ''Y'' then
    v_bill_type_codes_exp := PLSQL_EXP(''{TABLE:
      o1=vw_mis_billing_account;
      s1=distinct o1.bill_type_code~alias=bill_type_code;
      cond=o1.insured_gid = {field:INSURED_GID};
      cond=o1.bill_type_code is not null;
      }''
    );
  
    while( v_bill_type_codes_exp.has_records() = ''Y'' ) loop
      v_bill_type_codes_exp.next_record();
      v_bill_type_code := v_bill_type_codes_exp.get_rec_value(''bill_type_code'');
      
      if v_bill_type_code = v_bill_type_code_curr then
        NULL;
      else 
        v_counter := v_counter + 1;
      end if;
    end loop; 

    IF v_counter > 1 THEN
      v_is_valid := ''N'';
    END IF;    
  end if;  

  RETURN plsql_exp_result(v_is_valid);
END;
}','N','Validation to check if more than one bill type are allowed','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_query('',p_id,'VALIDATE_CAN_HAVE_MORE_THAN_ONE_DIRECT_BILL_ACC','','{PLSQL:
DECLARE
 v_one_direct_bill_per_cust    CHAR(1);
 v_bill_acc_numbers_exp        PLSQL_EXP;
 v_other_db_count              NUMBER;
BEGIN
  if ''{user:role(agent_role)}'' = ''N'' AND ''{user:role(underwriter_role)}'' = ''N'' then
    return plsql_exp_result(''N''); -- user is neither agent nor underwriter, do not allow adding of billing account
  end if;

  if ''{user:role(underwriter_role)}'' = ''Y'' then
    return plsql_exp_result(''Y''); -- underwriter can add as many direct bill accounts
  end if;
  
  if NVL(''{FIELD:BILL_TYPE_CODE}'', ''X'') <> ''D'' then
    return plsql_exp_result(''Y''); -- is not direct bill, so cannot validate
  end if;
  
  -- for agent, if no other direct bills are present, then it is valid
  v_bill_acc_numbers_exp := PLSQL_EXP(''{TABLE:
    o1=vw_mis_billing_account;
    s1=count(distinct o1.bill_type_code)~alias=other_db_count;
    cond=o1.insured_gid = {FIELD:INSURED_GID};
    cond=o1.BILL_TYPE_CODE = ''D'';
    cond=o1.id <> {FIELD:ID};
    }''
  );
  
  v_other_db_count := v_bill_acc_numbers_exp.get_value();
  if v_other_db_count = 0 then
    return plsql_exp_result(''Y''); -- this is the first direct bill, so allowed
  end if;
  
  return plsql_exp_result(''N''); -- invalid in other scenarios
END;
}','N','Validation to check if more than one direct bill are allowed','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_query('',p_id,'VALIDATE_USER_NOT_CONFIGURED_FOR_AGENCY_BILL','','select decode(count(1), 0, ''Y'', ''N'')  from dual 
where k_billing_utilities.producer_set_for_agency_bill({GLOBAL:INSURED_GID}) = ''N''
and ''{field:BILL_TYPE_CODE}'' = ''A''','N','Validation to check if user is configured for agency bill','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_query('',p_id,'VALIDATE_PROGRAM_CODE_NOT_ALLOWING_AGENCY_BILL','','{PLSQL:
DECLARE
 v_is_valid                   CHAR(1) := ''Y'';
 v_bill_type_code_exp         PLSQL_EXP;
 v_bill_type_code_curr        MIS_BILLING_ACCOUNT.IBL_BILL_TYPE_CODE%TYPE; 
 v_policy_org_entity_ref      MIS_BILLING_ACCOUNT_ASSIGN.BAA_POLICY_ORG_ENTITY_REF%TYPE;
 v_entity_reference           MIS_QUOTE_POLICIES.MQP_ENTITY_REFERENCE%TYPE;
 v_program_code               MIS_QUOTE_POLICIES.MQP_PROGRAM_CODE%TYPE;
BEGIN
  v_is_valid := ''Y'';
  v_policy_org_entity_ref := ''{field:POLICY_ORG_ENTITY_REF}'';
  if v_policy_org_entity_ref is null then
    RETURN plsql_exp_result(v_is_valid); -- policy not selected, so is valid
  end if;
  
  v_bill_type_code_exp := PLSQL_EXP(''{CP:
    o1=/;
    s1=o1.BILL_TYPE_CODE~ alias=BILL_TYPE_CODE;
    }''
  );
  
  v_bill_type_code_curr := v_bill_type_code_exp.get_value();
  if v_bill_type_code_curr is null OR v_bill_type_code_curr <> ''A'' then
    RETURN plsql_exp_result(v_is_valid); -- bill type not selected, so is valid
  end if;

  -- find latest version
  select entity_reference, program_code
  into v_entity_reference, v_program_code
  from (
    select entity_reference, program_code
    from vw_mis_quote_policies
    where org_entity_reference = NVL(v_policy_org_entity_ref, ''-1'')
    order by revision_number desc
  ) where rownum < 2;
  
  if v_program_code = ''SPE'' then --or use the condition CUSTOM_PROGRAM_CODE=0500
    v_is_valid := ''N'';
  end if;
  
  RETURN plsql_exp_result(v_is_valid);
END;
}','N','Validate Agency Bill cannot be selected when one of the policies have program code of 0500','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_query('',p_id,'VALIDATE_BILL_ACC_NUMBER_IS_REQUIRED','','select DECODE(''{field:BILL_ACCOUNT_NUMBER}'', NULL, ''N'', ''Y'')  from dual where 1 = 1','N','Billing account number should not be empty','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_query('',p_id,'BILL_CAN_UPDATE_BILL_PLAN','','{PLSQL:
DECLARE
 v_insured_gid                 NUMBER;
 v_selected_policies_exp       PLSQL_EXP;
 v_temp_exp                    PLSQL_EXP;
 v_policy_org_entity_ref       MIS_BILLING_ACCOUNT_ASSIGN.BAA_POLICY_ORG_ENTITY_REF%TYPE;       
 
 v_can_update_bill_plan        CHAR(1);
 v_have_new_business_policies  CHAR(1);
 v_have_booked_active_policies CHAR(1);
 
 v_is_booked                   CHAR(1);
 v_is_active                   CHAR(1);
 v_can_change_plan_mid_term    CHAR(1);
 v_custom_exception            EXCEPTION;
BEGIN
  -- Logic:
  -- if no policies booked, it can be changed
  -- if any of the policy is booked, then bill plan can be changed when:
  --    - agent is set-up for mid-term endorsement
  --    - and 
  --    - at least one of the booked policy is active
  
  v_insured_gid := {GLOBAL:INSURED_GID};

  v_selected_policies_exp := PLSQL_EXP(''{CP:
    o1=/BILL_ACC_POL_ASSIGNMENT/;
    s1=o1.policy_org_entity_ref~ alias=policy_org_entity_ref;
    }''
  );
  
  if v_selected_policies_exp.has_records() = ''N'' then
    RETURN plsql_exp_result(''N''); -- no policies selected, cannot update the bill plan as bill plan is based on data from selected policies.
  end if;

  -- check if this policy is booked or not
  v_have_new_business_policies := ''N'';
  v_have_booked_active_policies := ''N'';
  while( v_selected_policies_exp.has_records() = ''Y'' ) loop
    v_selected_policies_exp.next_record();
    v_policy_org_entity_ref := v_selected_policies_exp.get_rec_value(''policy_org_entity_ref'');
    
    if v_policy_org_entity_ref is null then
      CONTINUE;
    end if;
    
    -- is this policy booked
    v_is_booked := k_billing_utilities.is_policy_booked(v_policy_org_entity_ref);
    if v_is_booked = ''Y'' then
      v_is_active := k_billing_utilities.is_policy_active(v_policy_org_entity_ref);
      if v_is_active = ''Y'' then
        v_have_booked_active_policies := ''Y'';
        EXIT;
      else 
        NULL; -- this is inactive policy, ignore
      end if;
    else
      v_have_new_business_policies := ''Y'';
    end if;
  end loop;

  
  v_can_update_bill_plan := ''N'';
  if v_have_booked_active_policies = ''Y'' then
    -- check if the user have mid-term endorsement permission
    if ''{user:role(underwriter_role)}'' = ''Y'' then
      v_can_update_bill_plan := ''Y'';
    else
      v_can_change_plan_mid_term := k_billing_utilities.can_change_bill_plan_mid_term(v_insured_gid);
      if v_can_change_plan_mid_term = ''Y'' then
        -- cannot update bill plan, if the customer account has different bill types
        v_temp_exp := PLSQL_EXP(''{TABLE:
          o1=vw_mis_billing_account;
          s1=decode(count(distinct(o1.bill_type_code)), 0, ''N'', 1, ''N'', ''Y'')~ alias=have_diff_bill_types;
          cond=o1.insured_gid = ''{FIELD:INSURED_GID}'';
          }''
        );
        
        if v_temp_exp.get_value() = ''N'' then
          -- cannot update bill plan, if the only bill type is direct bill but more than one billing account number applies
          v_temp_exp := PLSQL_EXP(''{TABLE:
            o1=vw_mis_billing_account;
            s1=decode(count(distinct(o1.bill_account_number)), 0, ''N'', 1, ''N'', ''Y'')~ alias=have_multiple_db_acc;
            cond=o1.insured_gid = ''{FIELD:INSURED_GID}'';
            cond=o1.BILL_TYPE_CODE = ''D'';
            }''
          );
          if v_temp_exp.get_value() = ''N'' then
            v_can_update_bill_plan := ''Y'';
          end if;
        end if;
      end if;
    end if;
  else 
    if v_have_new_business_policies = ''Y'' then
      v_can_update_bill_plan := ''Y'';
    end if;
  end if;  

  RETURN plsql_exp_result(v_can_update_bill_plan);
END;
}','N','Can update bill plan','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_query('',p_id,'VALIDATE_BILL_AGENCY_BILL_CANNOT_SELECT_MANUAL','','select decode(count(1), 0, ''Y'', ''N'')  from dual 
where ''{field:BILL_TYPE_CODE}'' = ''A'' and ''{field:BILL_ACC_NUMBER_IS_MANUAL}'' = ''Y''','N','Billing Account Number cannot be manual for Agency Bill','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_query('',p_id,'VALIDATE_BILL_POLICIES_ASSOCIATED','','{CP: 
 o1=/BILL_ACC_POL_ASSIGNMENT/;
 s1=decode(count(o1.POLICY_NUMBER), 0, ''N'', ''Y'')~ alias=is_valid; 
 cond=''{field:REVISION_NUMBER}'' = ''0'';
}','N','Atleast one policy should be selected','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_query('',p_id,'VALIDATE_BILL_POLICY_NO_SHOULD_BE_SAME_AS_BAN_FOR_ABILL','','{CP: 
 o1=/;
 s1=decode(count(o1.BILL_ACCOUNT_NUMBER), 0, ''Y'', ''N'')~ alias=is_valid; 
 cond=o1.REVISION_NUMBER > 0;
 cond=o1.BILL_TYPE_CODE = ''A'';
 cond=''{field:POLICY_NUMBER}'' IS NOT NULL;
 cond=o1.BILL_ACCOUNT_NUMBER != ''{field:POLICY_NUMBER}'';
}','N','On Revision greator than 0, for Agency Bill, cannot add a policy not equal to BAN','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_query('',p_id,'VALIDATE_BILL_DIRECT_BILL_COULD_NOT_BE_GENERATED','','SELECT DECODE(COUNT(1), 0, ''Y'', ''N'') FROM DUAL
WHERE 1 = 1
AND ''{FIELD:BILL_TYPE_CODE}'' = ''D''
AND ''{FIELD:BILL_ACC_NUMBER_GENERATED}'' = ''Y''
AND TRIM(''{FIELD:BILL_ACCOUNT_NUMBER}'') IS NULL
AND NVL(''{FIELD:BILL_ACC_NUMBER_IS_MANUAL}'', ''N'') = ''N''','N','Validation to prompt that the Billing Account Number could not be generated, so that the user can enter manually.','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_query('',p_id,'BILL_HAVE_ATLEAST_ONE_BILLING_ACCOUNT','','select k_billing_utilities.f_has_atleast_one_bill_account(''{param:INSUREDGID}'', ''{FIELD:GID}'') from dual','N','To check whether a billing account already exists or not','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_query('',p_id,'BILL_POLICY_PREMIUM_LOOKUP','','select k_billing_utilities.get_policy_premium(''{FIELD:POLICY_ORG_ENTITY_REF}'') policy_premium from dual','N','Fetch policy premium','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_lookup_headings('D',p_id,k_pct_management_new.f_get_query_id('BILL_POLICY_ASSIGN_LOOKUP_SE'),'LOB','S','Line Of Business','Line Of Business','1','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_lookup_headings('D',p_id,k_pct_management_new.f_get_query_id('BILL_POLICY_ASSIGN_LOOKUP_SE'),'PRODUCT_NAME','S','Line Of Business','Line Of Business','1','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_lookup_headings('D',p_id,k_pct_management_new.f_get_query_id('BILL_POLICY_ASSIGN_LOOKUP_SE'),'POLICY_NUMBER','S','Policy #','Policy #','2','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_lookup_headings('D',p_id,k_pct_management_new.f_get_query_id('BILL_POLICY_ASSIGN_LOOKUP_SE'),'AGENCY_CODE','S','Agency Code','Agency Code','3','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_lookup_headings('D',p_id,k_pct_management_new.f_get_query_id('BILL_POLICY_ASSIGN_LOOKUP_SE'),'EFFECTIVE_DATE','S','Effective Date','Effective Date','4','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_lookup_headings('D',p_id,k_pct_management_new.f_get_query_id('BILL_POLICY_ASSIGN_LOOKUP_SE'),'EXPIRATION_DATE','S','Expiration Date','Expiration Date','5','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_lookup_headings('',p_id,k_pct_management_new.f_get_query_id('BILL_POLICY_ASSIGN_LOOKUP'),'PRODUCT_NAME','S','Line Of Business','Line Of Business','1','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_lookup_headings('',p_id,k_pct_management_new.f_get_query_id('BILL_POLICY_ASSIGN_LOOKUP'),'POLICY_NUMBER','S','Policy #','Policy #','2','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_lookup_headings('',p_id,k_pct_management_new.f_get_query_id('BILL_POLICY_ASSIGN_LOOKUP'),'AGENCY_CODE','S','Agency Code','Agency Code','3','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_lookup_headings('',p_id,k_pct_management_new.f_get_query_id('BILL_POLICY_ASSIGN_LOOKUP'),'EFFECTIVE_DATE','S','Effective Date','Effective Date','4','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_lookup_headings('',p_id,k_pct_management_new.f_get_query_id('BILL_POLICY_ASSIGN_LOOKUP'),'EXPIRATION_DATE','S','Expiration Date','Expiration Date','5','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_lookup_headings('',p_id,k_pct_management_new.f_get_query_id('BILL_POLICY_ASSIGN_LOOKUP'),'POLICY_PREMIUM','S','Premium','Premium','6','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_primitive('',p_id,'NUMBER LENGTH 20','NUMBER','20','','NUMBER LENGTH 20','','','', k_pct_management_new.f_get_query_id(''),'','','','','','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_object('',p_id,'Billing_Account','Billing Account','MIS_BILLING_ACCOUNT','IBL','NA','Y','Y','Billing Account Number','','ENTITY','N','','','admin@cover-all.com','Y',p_error,'','','','','');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object('',p_id,'Billing Account Number Assignment','Billing Account Number Assignment','MIS_BILLING_ACCOUNT_ASSIGN','BAA','NA','Y','N','Billing Account Number Assignment','','OBJECT','N','','','admin@cover-all.com','Y',p_error,'','','','','');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing_Account',''),p_id,'INSURED_GID',k_pct_management_new.f_get_object_id('Billing_Account'),k_pct_management_new.f_get_primitive_id('NUMBER LENGTH 20'),k_pct_management_new.f_get_object_id(''),NULL,'INSURED_GID','NA','','','param:INSUREDGID','','Insured','N','Y','Y','','100','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','INSURED_GID','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing_Account',''),p_id,'EFFECTIVE_DATE',k_pct_management_new.f_get_object_id('Billing_Account'),k_pct_management_new.f_get_primitive_id('Date'),k_pct_management_new.f_get_object_id(''),NULL,'EFFECTIVE_DATE','NA','','','select to_char(sysdate, ''mm/dd/yyyy'') EFFECTIVE_DATE from dual','','Effective Date','N','Y','N','','150','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing_Account',''),p_id,'TRANSACTION_ACTION',k_pct_management_new.f_get_object_id('Billing_Account'),k_pct_management_new.f_get_primitive_id('Transaction Action'),k_pct_management_new.f_get_object_id(''),NULL,'TRANSACTION_ACTION','NA','','','param:action','','Transaction Action','N','Y','N','','180','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','Y','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing_Account',''),p_id,'TRANSACTION_CODE',k_pct_management_new.f_get_object_id('Billing_Account'),k_pct_management_new.f_get_primitive_id('Transaction Code'),k_pct_management_new.f_get_object_id(''),NULL,'TRANSACTION_CODE','NA','','','param:classicTransactionCode','','Transaction Code','N','Y','N','','185','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','TRANSACTION_CODE','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','Y','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing_Account',''),p_id,'BILL_TYPE',k_pct_management_new.f_get_object_id('Billing_Account'),k_pct_management_new.f_get_primitive_id('Short Description'),k_pct_management_new.f_get_object_id(''),NULL,'BILL_TYPE','NA','','','','','Bill Type','Y','N','Y','','200','',k_pct_management_new.f_get_query_id('BILL_TYPE_LOOKUP'),'','N','N',NULL,'N','Y','','Y','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing_Account',''),p_id,'BILL_TYPE_CODE',k_pct_management_new.f_get_object_id('Billing_Account'),k_pct_management_new.f_get_primitive_id('Short Description'),k_pct_management_new.f_get_object_id(''),NULL,'BILL_TYPE_CODE','NA','','','','','Bill Type Code','Y','Y','N','','250','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing_Account',''),p_id,'BILL_PLAN',k_pct_management_new.f_get_object_id('Billing_Account'),k_pct_management_new.f_get_primitive_id('Short Description'),k_pct_management_new.f_get_object_id(''),NULL,'BILL_PLAN','NA','','','','','Bill Plan','Y','N','Y','','300','',k_pct_management_new.f_get_query_id('BILL_PLAN_LOOKUP'),'','N','N',NULL,'N','Y','','Y','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','DISPLAY_ORDER','ASC','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing_Account',''),p_id,'BILL_PLAN_CODE',k_pct_management_new.f_get_object_id('Billing_Account'),k_pct_management_new.f_get_primitive_id('Short Description'),k_pct_management_new.f_get_object_id(''),NULL,'BILL_PLAN_CODE','NA','','','','','Bill Plan Code','Y','Y','N','','350','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing_Account',''),p_id,'BILL_PLAN_EFT',k_pct_management_new.f_get_object_id('Billing_Account'),k_pct_management_new.f_get_primitive_id('Short Description'),k_pct_management_new.f_get_object_id(''),NULL,'BILL_PLAN_EFT','NA','','','','','Is EFT','Y','Y','N','','400','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing_Account',''),p_id,'BILL_ACCOUNT_NUMBER',k_pct_management_new.f_get_object_id('Billing_Account'),k_pct_management_new.f_get_primitive_id('NUMBER LENGTH 20'),k_pct_management_new.f_get_object_id(''),NULL,'BILL_ACCOUNT_NUMBER','NA','','','','','Billing Account Number','Y','N','N','','550','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('D',k_pct_management_new.f_get_object_field_id('Billing_Account','BILL_ACC_NUMBER_MANUAL'),p_id,'BILL_ACC_NUMBER_MANUAL',k_pct_management_new.f_get_object_id('Billing_Account'),k_pct_management_new.f_get_primitive_id('Boolean'),k_pct_management_new.f_get_object_id(''),NULL,'BILL_ACC_NUMBER_MANUAL','NA','','','','','Is Billing Account Number Manual','N','N','Y','','500','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing_Account',''),p_id,'BILL_ACC_NUMBER_IS_MANUAL',k_pct_management_new.f_get_object_id('Billing_Account'),k_pct_management_new.f_get_primitive_id('TRI_STATE_CHECKBOX'),k_pct_management_new.f_get_object_id(''),NULL,'BILL_ACC_NUMBER_IS_MANUAL','NA','','','','','Is Billing Account Number Manual','N','N','Y','','450','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing_Account',''),p_id,'REVISION_NUMBER',k_pct_management_new.f_get_object_id('Billing_Account'),k_pct_management_new.f_get_primitive_id('NUMBER LENGTH 20'),k_pct_management_new.f_get_object_id(''),NULL,'REVISION_NUMBER','NA','','','0','','Revision Number','N','Y','N','','600','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing_Account',''),p_id,'RENEWAL_COUNTER',k_pct_management_new.f_get_object_id('Billing_Account'),k_pct_management_new.f_get_primitive_id('NUMBER LENGTH 20'),k_pct_management_new.f_get_object_id(''),NULL,'RENEWAL_COUNTER','NA','','','0','','Renewal Counter','N','Y','N','','650','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing_Account',''),p_id,'BILL_ACC_POL_ASSIGNMENT',k_pct_management_new.f_get_object_id('Billing_Account'),k_pct_management_new.f_get_primitive_id(''),k_pct_management_new.f_get_object_id('Billing Account Number Assignment'),NULL,'BILL_ACC_POL_ASSIGNMENT','BillingAccountPolicyAssignment','*','','','','Policies','N','N','Y','','700','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','Y','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing_Account',''),p_id,'OLD_ENTITY_TYPE',k_pct_management_new.f_get_object_id('Billing_Account'),k_pct_management_new.f_get_primitive_id('Entity Type'),k_pct_management_new.f_get_object_id(''),NULL,'OLD_ENTITY_TYPE','NA','','','','','Old Entity Type','N','Y','N','','800','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing_Account',''),p_id,'OLD_ENTITY_REFERENCE',k_pct_management_new.f_get_object_id('Billing_Account'),k_pct_management_new.f_get_primitive_id('Entity Reference'),k_pct_management_new.f_get_object_id(''),NULL,'OLD_ENTITY_REFERENCE','NA','','','','','Old Entity Reference','N','Y','N','','900','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing_Account',''),p_id,'NEW_ENTITY_TYPE',k_pct_management_new.f_get_object_id('Billing_Account'),k_pct_management_new.f_get_primitive_id('Entity Type'),k_pct_management_new.f_get_object_id(''),NULL,'NEW_ENTITY_TYPE','NA','','','','','New Entity Type','N','Y','N','','1000','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing_Account',''),p_id,'NEW_ENTITY_REFERENCE',k_pct_management_new.f_get_object_id('Billing_Account'),k_pct_management_new.f_get_primitive_id('Entity Reference'),k_pct_management_new.f_get_object_id(''),NULL,'NEW_ENTITY_REFERENCE','NA','','','','','New Entity Reference','N','Y','N','','1100','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing_Account',''),p_id,'RENEWAL_INDICATOR',k_pct_management_new.f_get_object_id('Billing_Account'),k_pct_management_new.f_get_primitive_id('Renewal Indicator'),k_pct_management_new.f_get_object_id(''),NULL,'RENEWAL_INDICATOR','NA','','','N','','Renewal Indicator','Y','Y','N','','1200','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','RENEWAL_INDICATOR','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing_Account',''),p_id,'ORG_ENTITY_REFERENCE',k_pct_management_new.f_get_object_id('Billing_Account'),k_pct_management_new.f_get_primitive_id('Entity Reference'),k_pct_management_new.f_get_object_id(''),NULL,'ORG_ENTITY_REFERENCE','NA','','','','','Original Entity Reference ','N','Y','Y','','1300','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','For Maintaning revisions','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing_Account',''),p_id,'RENEWAL_OF_NUMBER',k_pct_management_new.f_get_object_id('Billing_Account'),k_pct_management_new.f_get_primitive_id('Entity Reference'),k_pct_management_new.f_get_object_id(''),NULL,'RENEWAL_OF_NUMBER','NA','','','','','Renewal of Reference','N','Y','N','','1400','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','RENEWAL_OF_NUMBER','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing_Account',''),p_id,'BILL_ACC_NUMBER_GENERATED',k_pct_management_new.f_get_object_id('Billing_Account'),k_pct_management_new.f_get_primitive_id('TRI_STATE_CHECKBOX'),k_pct_management_new.f_get_object_id(''),NULL,'BILL_ACC_NUMBER_GENERATED','NA','','','','','Is Billing Account Number Generated','N','Y','Y','','1500','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing Account Number Assignment',''),p_id,'LOB',k_pct_management_new.f_get_object_id('Billing Account Number Assignment'),k_pct_management_new.f_get_primitive_id('Short Description'),k_pct_management_new.f_get_object_id(''),NULL,'LOB','NA','','','','','LOB Code','N','Y','N','','100','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing Account Number Assignment',''),p_id,'PRODUCT_NAME',k_pct_management_new.f_get_object_id('Billing Account Number Assignment'),k_pct_management_new.f_get_primitive_id('Short Description'),k_pct_management_new.f_get_object_id(''),NULL,'PRODUCT_NAME','NA','','','','','Line of Business','N','N','N','','150','20',k_pct_management_new.f_get_query_id(''),'','Y','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing Account Number Assignment',''),p_id,'POLICY_NUMBER',k_pct_management_new.f_get_object_id('Billing Account Number Assignment'),k_pct_management_new.f_get_primitive_id('NUMBER LENGTH 20'),k_pct_management_new.f_get_object_id(''),NULL,'POLICY_NUMBER','NA','','','','','Policy Number','Y','N','Y','','200','10',k_pct_management_new.f_get_query_id('BILL_POLICY_ASSIGN_LOOKUP'),'','Y','N',NULL,'N','Y','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('D',k_pct_management_new.f_get_object_field_id('Billing Account Number Assignment','POLICY_RENEWAL_COUNTER_2'),p_id,'POLICY_RENEWAL_COUNTER_2',k_pct_management_new.f_get_object_id('Billing Account Number Assignment'),k_pct_management_new.f_get_primitive_id('NUMBER LENGTH 20'),k_pct_management_new.f_get_object_id(''),NULL,'POLICY_RENEWAL_COUNTER_2','NA','','','','','Renewal Counter','N','Y','N','','250','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing Account Number Assignment',''),p_id,'POLICY_ORG_ENTITY_REF',k_pct_management_new.f_get_object_id('Billing Account Number Assignment'),k_pct_management_new.f_get_primitive_id('Entity Reference'),k_pct_management_new.f_get_object_id(''),NULL,'POLICY_ORG_ENTITY_REF','NA','','','','','Policy Original Entity Reference','N','Y','N','','250','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing Account Number Assignment',''),p_id,'AGENCY_CODE',k_pct_management_new.f_get_object_id('Billing Account Number Assignment'),k_pct_management_new.f_get_primitive_id('Short Description'),k_pct_management_new.f_get_object_id(''),NULL,'AGENCY_CODE','NA','','','','','Agency Code','N','N','N','','300','10',k_pct_management_new.f_get_query_id(''),'','Y','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing Account Number Assignment',''),p_id,'EFFECTIVE_DATE',k_pct_management_new.f_get_object_id('Billing Account Number Assignment'),k_pct_management_new.f_get_primitive_id('Date'),k_pct_management_new.f_get_object_id(''),NULL,'EFFECTIVE_DATE','NA','','','','','Effective Date','N','N','N','','400','10',k_pct_management_new.f_get_query_id(''),'','Y','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing Account Number Assignment',''),p_id,'EXPIRATION_DATE',k_pct_management_new.f_get_object_id('Billing Account Number Assignment'),k_pct_management_new.f_get_primitive_id('Date'),k_pct_management_new.f_get_object_id(''),NULL,'EXPIRATION_DATE','NA','','','','','Expiration Date','N','N','N','','500','10',k_pct_management_new.f_get_query_id(''),'','Y','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing Account Number Assignment',''),p_id,'POLICY_PREMIUM',k_pct_management_new.f_get_object_id('Billing Account Number Assignment'),k_pct_management_new.f_get_primitive_id('SIGNED USD'),k_pct_management_new.f_get_object_id(''),NULL,'POLICY_PREMIUM','NA','','','','','Premium','N','N','N','','600','10',k_pct_management_new.f_get_query_id('BILL_POLICY_PREMIUM_LOOKUP'),'','Y','N',NULL,'N','','','','','','','','','Y','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'VS-CRIT-001','1','','','param:ENTITY_TYPE','=','''BILLING_ACCOUNT''','','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_criteria('',p_id,'VS-CRIT-002','1','','NVL(','field:BILL_ACC_NUMBER_IS_MANUAL',', ''N'') =','''Y''','','AND','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_criteria('',p_id,'VS-CRIT-002','2','','NVL(','field:REVISION_NUMBER',', ''0'') =','0','','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_criteria('',p_id,'VS-CRIT-003','1','','','oi:viewMode','=','''N''','','AND','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_criteria('',p_id,'VS-CRIT-003','2','','','param:ENTITY_TYPE','=','''BILLING_ACCOUNT''','','AND','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_criteria('D',p_id,'VS-CRIT-003','3','','NVL(','queryvalue:BILL_ACCOUNT_HAVE_BOOKED_POLICIES',', ''N'') =','''N''','','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_criteria('',p_id,'VS-CRIT-003','3','','','queryvalue:BILL_HAVE_ATLEAST_ONE_BILLING_ACCOUNT','=','''Y''','','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_criteria('',p_id,'VS-CRIT-004','1','','NVL(','queryvalue:VALIDATE_BILL_CANNOT_REMOVE_POL_ASSOCIATION',', ''N'') =','''N''','','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_criteria('',p_id,'VS-CRIT-005','1','','NVL(','queryvalue:BILL_ACCOUNT_HAVE_BOOKED_POLICIES',', ''N'') =','''Y''','','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_criteria('',p_id,'VS-CRIT-006','1','','NVL(','field:REVISION_NUMBER',', ''0'') =','0','','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_criteria('',p_id,'VS-CRIT-007','1','','NVL(','field:REVISION_NUMBER',', ''0'') >','0','','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_criteria('',p_id,'VS-CRIT-008','1','','NVL(','queryvalue:BILL_CAN_UPDATE_BILL_PLAN',', ''N'') =','''N''','','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_criteria('',p_id,'VS-CRIT-009','1','','NVL(','field:BILL_ACC_NUMBER_IS_MANUAL',', ''N'') =','''N''','','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_criteria('',p_id,'VS-CRIT-010','1','','','oi:viewMode','=','''N''','','AND','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_criteria('',p_id,'VS-CRIT-010','2','','','param:ENTITY_TYPE','=','''BILLING_ACCOUNT''','','AND','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_criteria('',p_id,'VS-CRIT-010','3','','','queryvalue:BILL_HAVE_ATLEAST_ONE_BILLING_ACCOUNT','=','''N''','','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_qualifier_criteria('',p_id,'13002','SELECT CASE WHEN NVL(''{param:ENTITY_TYPE}'', ''{field:ENTITY_TYPE}'') IN (''QUOTE'', ''POLICY'') THEN
''Y'' ELSE ''N''  END FROM dual','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_object_field_valns('',p_id,'VS-VAL-BILL-001',k_pct_management_new.f_get_object_field_id('Billing Account Number Assignment', 'POLICY_NUMBER'),NULL,'SE','',k_pct_management_new.f_get_query_id('VALIDATE_BILL_ASSIGNED_POLICIES_SAME_EXP_DT'),k_pct_management_new.f_get_validator_id(''),'ON_FULL_SAVE','Policies assigned should have same expiration date.','','admin@cover-all.com','Y',p_error,'','', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','', '');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field_valns('',p_id,'VS-VAL-BILL-002',k_pct_management_new.f_get_object_field_id('Billing_Account', 'BILL_TYPE'),NULL,'SE','',k_pct_management_new.f_get_query_id('VALIDATE_BILL_ONE_POLICY_FOR_AGENCY_BILL'),k_pct_management_new.f_get_validator_id(''),'ON_FULL_SAVE','For agency bill, only one policy can be selected.','','admin@cover-all.com','Y',p_error,'','', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','', '');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field_valns('',p_id,'VS-VAL-BILL-003',k_pct_management_new.f_get_object_field_id('Billing_Account', 'BILL_ACCOUNT_NUMBER'),NULL,'SE','',k_pct_management_new.f_get_query_id('VALIDATE_BILL_BAN_LENGTH'),k_pct_management_new.f_get_validator_id(''),'ON_FULL_SAVE','Invalid Bill Account Number (should be 7 digits)','','admin@cover-all.com','Y',p_error,'','', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','', '');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field_valns('',p_id,'VS-VAL-BILL-004',k_pct_management_new.f_get_object_field_id('Billing Account Number Assignment', 'POLICY_NUMBER'),NULL,'SE','',k_pct_management_new.f_get_query_id('VALIDATE_BILL_CANNOT_REMOVE_POL_ASSOCIATION'),k_pct_management_new.f_get_validator_id(''),'ON_DELETE','Booked policy cannot be removed','','admin@cover-all.com','Y',p_error,'','', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','', '');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field_valns('',p_id,'VS-VAL-BILL-005',k_pct_management_new.f_get_object_field_id('Billing_Account', 'BILL_TYPE'),NULL,'SE','',k_pct_management_new.f_get_query_id('VALIDATE_BILL_BAN_SHOULD_BE_UNIQUE'),k_pct_management_new.f_get_validator_id(''),'ON_FULL_SAVE','Billing Account Number should be unique.','','admin@cover-all.com','Y',p_error,'','', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','', '');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field_valns('',p_id,'VS-VAL-BILL-006',k_pct_management_new.f_get_object_field_id('Billing Account Number Assignment', 'POLICY_NUMBER'),NULL,'SE','',k_pct_management_new.f_get_query_id('VALIDATE_BILL_BAN_ON_DB_CANNOT_BE_A_POL_NR'),k_pct_management_new.f_get_validator_id(''),'ON_FULL_SAVE','Policy number cannot be same as billing account number','','admin@cover-all.com','Y',p_error,'','', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','', '');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field_valns('',p_id,'VS-VAL-BILL-007',k_pct_management_new.f_get_object_field_id('Billing_Account', 'BILL_TYPE'),NULL,'SE','',k_pct_management_new.f_get_query_id('VALIDATE_CAN_HAVE_MORE_THAN_ONE_BILL_TYPE'),k_pct_management_new.f_get_validator_id(''),'ON_FULL_SAVE','Cannot have more than one bill type for a customer account.','','admin@cover-all.com','Y',p_error,'','', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','', '');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field_valns('',p_id,'VS-VAL-BILL-008',k_pct_management_new.f_get_object_field_id('Billing_Account', 'BILL_TYPE'),NULL,'SE','',k_pct_management_new.f_get_query_id('VALIDATE_CAN_HAVE_MORE_THAN_ONE_DIRECT_BILL_ACC'),k_pct_management_new.f_get_validator_id(''),'ON_FULL_SAVE','Cannot have more than one direct bill account.','','admin@cover-all.com','Y',p_error,'','', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','', '');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field_valns('',p_id,'VS-VAL-BILL-009',k_pct_management_new.f_get_object_field_id('Billing_Account', 'BILL_TYPE'),NULL,'SE','',k_pct_management_new.f_get_query_id('VALIDATE_USER_NOT_CONFIGURED_FOR_AGENCY_BILL'),k_pct_management_new.f_get_validator_id(''),'ON_FULL_SAVE','User is not configured for Agency Bill.','','admin@cover-all.com','Y',p_error,'','', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','', '');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field_valns('',p_id,'VS-VAL-BILL-010',k_pct_management_new.f_get_object_field_id('Billing Account Number Assignment', 'POLICY_NUMBER'),NULL,'SE','',k_pct_management_new.f_get_query_id('VALIDATE_PROGRAM_CODE_NOT_ALLOWING_AGENCY_BILL'),k_pct_management_new.f_get_validator_id(''),'ON_FULL_SAVE','Policy with a program code of 0500 cannot be added for Agency Bill.','','admin@cover-all.com','Y',p_error,'','', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','', '');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field_valns('D',p_id,'VS-VAL-BILL-011',k_pct_management_new.f_get_object_field_id('Billing_Account', 'BILL_TYPE'),NULL,'SE','VS-CRIT-009',k_pct_management_new.f_get_query_id('VALIDATE_BILL_ACC_NUMBER_IS_REQUIRED'),k_pct_management_new.f_get_validator_id(''),'ON_FULL_SAVE','Billing Account Number is required. Please select bill plan and atleast one policy.','','admin@cover-all.com','Y',p_error,'','', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','', '');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field_valns('',p_id,'VS-VAL-BILL-012',k_pct_management_new.f_get_object_field_id('Billing_Account', 'BILL_ACC_NUMBER_IS_MANUAL'),NULL,'SE','',k_pct_management_new.f_get_query_id('VALIDATE_BILL_AGENCY_BILL_CANNOT_SELECT_MANUAL'),k_pct_management_new.f_get_validator_id(''),'ON_FULL_SAVE','Billing Account Number cannot be manual for Agency Bill','','admin@cover-all.com','Y',p_error,'','', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','', '');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field_valns('',p_id,'VS-VAL-BILL-013',k_pct_management_new.f_get_object_field_id('Billing_Account', 'BILL_TYPE'),NULL,'SE','',k_pct_management_new.f_get_query_id('VALIDATE_BILL_POLICIES_ASSOCIATED'),k_pct_management_new.f_get_validator_id(''),'ON_FULL_SAVE','Please assign a policy','','admin@cover-all.com','Y',p_error,'','', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','', '');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field_valns('',p_id,'VS-VAL-BILL-014',k_pct_management_new.f_get_object_field_id('Billing Account Number Assignment', 'POLICY_NUMBER'),NULL,'SE','',k_pct_management_new.f_get_query_id('VALIDATE_BILL_POLICY_NO_SHOULD_BE_SAME_AS_BAN_FOR_ABILL'),k_pct_management_new.f_get_validator_id(''),'ON_FULL_SAVE','Policy number should be same as billing account number','','admin@cover-all.com','Y',p_error,'','', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','', '');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field_valns('',p_id,'VS-VAL-BILL-015',k_pct_management_new.f_get_object_field_id('Billing_Account', 'BILL_TYPE'),NULL,'SE','',k_pct_management_new.f_get_query_id('VALIDATE_BILL_DIRECT_BILL_COULD_NOT_BE_GENERATED'),k_pct_management_new.f_get_validator_id(''),'ON_FULL_SAVE','Billing Account Number could not be generated. Kindly enter manually.','','admin@cover-all.com','Y',p_error,'','', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','', '');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'VS-BILL-0001',k_pct_management_new.f_get_object_field_id('Billing_Account', 'BILL_TYPE'),'SE','VS-CRIT-006','','Direct Bill','','','Y','','','','','25',k_pct_management_new.f_get_query_id('BILL_TYPE_LOOKUP_SE'),'','','','','','','','','','','','','','','','','','','','',NULL,'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'VS-BILL-0002',k_pct_management_new.f_get_object_field_id('Billing_Account', 'BILL_PLAN'),'SE','','','','','','','','','','','25',k_pct_management_new.f_get_query_id('BILL_PLAN_LOOKUP_SE'),'','','','','','','','','','','','','','','','','','','','',NULL,'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_fields_cust('D',p_id,'VS-BILL-0003',k_pct_management_new.f_get_object_field_id('Billing Account Number Assignment', 'POLICY_NUMBER'),'SE','','','','','','','','','','','',k_pct_management_new.f_get_query_id('BILL_POLICY_ASSIGN_LOOKUP_SE'),'','','','','','','','','','','','','','','','','','','','',NULL,'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'VS-BILL-0004',k_pct_management_new.f_get_object_field_id('Billing_Account', 'BILL_ACCOUNT_NUMBER'),'','VS-CRIT-002','','','','','','','Y','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',NULL,'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'VS-BILL-0005',k_pct_management_new.f_get_object_field_id('Billing_Account', 'BILL_TYPE_CODE'),'SE','','','D','','','','','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',NULL,'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'VS-BILL-0006',k_pct_management_new.f_get_object_field_id('Billing Account Number Assignment', 'POLICY_NUMBER'),'SE','VS-CRIT-004','','','','','','','N','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',NULL,'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'VS-BILL-0007',k_pct_management_new.f_get_object_field_id('Billing_Account', 'BILL_TYPE'),'SE','VS-CRIT-007','','','','','','','N','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',NULL,'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'VS-BILL-0008',k_pct_management_new.f_get_object_field_id('Billing_Account', 'BILL_ACCOUNT_NUMBER'),'SE','VS-CRIT-007','','','','','','','N','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',NULL,'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'VS-BILL-0009',k_pct_management_new.f_get_object_field_id('Billing_Account', 'BILL_ACC_NUMBER_IS_MANUAL'),'SE','VS-CRIT-007','','','','','','','N','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',NULL,'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'VS-BILL-0010',k_pct_management_new.f_get_object_field_id('Billing_Account','ORG_ENTITY_REFERENCE'),'','','','field:ENTITY_REFERENCE','','','','','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',NULL,'','','','','','Y','','','','admin@cover-all.com','Y',p_error,'','','','','11518','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'VS-BILL-0011',k_pct_management_new.f_get_object_field_id('Billing_Account','RENEWAL_OF_NUMBER'),'','','','field:OLD_ENTITY_REFERENCE','','','','','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',NULL,'','','','','','Y','','','','admin@cover-all.com','Y',p_error,'','','','IN(RenewBillingAccount)','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'VS-BILL-0012',k_pct_management_new.f_get_object_field_id('Billing_Account', 'BILL_ACCOUNT_NUMBER'),'SE','VS-CRIT-006','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',NULL,'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','{external_source:BillingAccNumberExternalSource~on_full_save}','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'VS-BILL-0013',k_pct_management_new.f_get_object_field_id('Billing_Account', 'BILL_PLAN'),'SE','VS-CRIT-008','','','','','','','N','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',NULL,'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'VS-BILL-0014',k_pct_management_new.f_get_object_field_id('Billing_Account', 'BILL_ACC_NUMBER_IS_MANUAL'),'SE','','','','','','','Y','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',NULL,'','','','','','','','','','admin@cover-all.com','Y',p_error,'IN(agent_role)','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_operation('',p_id,'13002','1','com.coverall.pct.client.operations.ExitApplicationOperation','Exit the application','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_operation('',p_id,'13003','1','com.coverall.pct.client.operations.CancelOperation','Cancel the Operation','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_operation('',p_id,'13004','1','com.coverall.pct.client.operations.SaveWithoutValidationOperation','Save the Billing Account Number Manual Field on click','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_operation('',p_id,'13004','2','com.coverall.pct.client.operations.SetValueOperation','Set the billing account number to null','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_operation('',p_id,'13005','1','com.coverall.pct.client.operations.SaveWithoutValidationOperation','Save data after selection from Policy select lookup','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_operation('',p_id,'13006','1','com.coverall.pct.client.operations.CancelOperation','Cancel the Operation','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_operation_param('',p_id,k_pct_management_new.f_get_operation_id('13004', '2'),'condition','true','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_operation_param('',p_id,k_pct_management_new.f_get_operation_id('13004', '2'),'BILL_ACCOUNT_NUMBER','','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_operation_param('',p_id,k_pct_management_new.f_get_operation_id('13006', '1'),'NAVIGATE_TO_BILLING_REPORT_POPUP','N','','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_object_field_lsn('',p_id,'VS-BILL-0001',k_pct_management_new.f_get_object_field_id('Billing_Account', 'BILL_ACC_NUMBER_IS_MANUAL'),NULL,'','','ON_CLICK','13004','Save the Billing Account Number Manual Field on click','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_object_field_lsn('',p_id,'VS-BILL-0002',k_pct_management_new.f_get_object_field_id('Billing Account Number Assignment', 'POLICY_NUMBER'),NULL,'','','ON_CHANGE','13005','Save data after selection from Policy select lookup','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','');
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_toolbar('',p_id,'Billing Account Ok',NULL,'SE','VS-CRIT-001','','',13002,'1','Show always for BillingAccount entity','Ok','FORM','','','RIGHT','admin@cover-all.com','Y',p_error,'N','','Y','','','','','','','','','','13004','','','',NULL);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_toolbar('',p_id,'Billing Account Cancel',NULL,'SE','VS-CRIT-003','','',13003,'2','Show always for BillingAccount entity','Cancel','FORM','','','RIGHT','admin@cover-all.com','Y',p_error,'N','','Y','','','','','','','','','','13005','','','',NULL);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_toolbar('',p_id,'Billing Account Cancel',NULL,'SE','VS-CRIT-010','','',13006,'2','Show always for BillingAccount entity','Cancel Issuing','FORM','','','RIGHT','admin@cover-all.com','Y',p_error,'N','','Y','','','','','','','','','','13012','','','',NULL);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_toolbar('',p_id,'Copy Button',k_pct_management_new.f_get_object_field_id('Billing_Account','BILL_ACC_POL_ASSIGNMENT'),'','','','',NULL,'','Do not show for Billing Account Number Assignment','','TABLE','','','','admin@cover-all.com','Y',p_error,'Y','','','','','','','','','','','','13006','','','',NULL);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_toolbar('',p_id,'Edit Button',k_pct_management_new.f_get_object_field_id('Billing_Account','BILL_ACC_POL_ASSIGNMENT'),'','','','',NULL,'','Do not show for Billing Account Number Assignment','','TABLE','','','','admin@cover-all.com','Y',p_error,'Y','','','','','','','','','','','','13007','','','',NULL);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_toolbar('',p_id,'Mass Update',k_pct_management_new.f_get_object_field_id('Billing_Account','BILL_ACC_POL_ASSIGNMENT'),'','','','',NULL,'','Do not show for Billing Account Number Assignment','','TABLE','','','','admin@cover-all.com','Y',p_error,'Y','','','','','','','','','','','','13008','','','',NULL);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_toolbar('',p_id,'Export',k_pct_management_new.f_get_object_field_id('Billing_Account','BILL_ACC_POL_ASSIGNMENT'),'','','','',NULL,'','Do not show for Billing Account Number Assignment','','TABLE','','','','admin@cover-all.com','Y',p_error,'Y','','','','','','','','','','','','13009','','','',NULL);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_toolbar('',p_id,'Import',k_pct_management_new.f_get_object_field_id('Billing_Account','BILL_ACC_POL_ASSIGNMENT'),'','','','',NULL,'','Do not show for Billing Account Number Assignment','','TABLE','','','','admin@cover-all.com','Y',p_error,'Y','','','','','','','','','','','','13010','','','',NULL);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_toolbar('',p_id,'Add Multiple',k_pct_management_new.f_get_object_field_id('Billing_Account','BILL_ACC_POL_ASSIGNMENT'),'','','','',NULL,'','Do not show for Billing Account Number Assignment','','TABLE','','','','admin@cover-all.com','Y',p_error,'Y','','','','','','','','','','','','13011','','','',NULL);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_external_sources_object('',p_id,'BillingAccNumberExternalSource','com.coverall.pctv2.server.expression.es.BillingAccNumberExternalSource','','SE','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_external_sources_params('',p_id,'BillingAccNumberExternalSource','OUT','BillAccountNumber','/' ||k_pct_management_new.f_get_object_field_id('Billing_Account','BILL_ACCOUNT_NUMBER') || '','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_external_sources_params('',p_id,'BillingAccNumberExternalSource','OUT','BillAccountNumberGenerated','/' ||k_pct_management_new.f_get_object_field_id('Billing_Account','BILL_ACC_NUMBER_GENERATED') || '','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_external_sources_params('',p_id,'BillingAccNumberExternalSource','IN','BillAccountNumber','{field:BILL_ACCOUNT_NUMBER}','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_external_sources_params('',p_id,'BillingAccNumberExternalSource','IN','BillTypeCode','{field:BILL_TYPE_CODE}','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_external_sources_params('',p_id,'BillingAccNumberExternalSource','IN','BillPlanCode','{field:BILL_PLAN_CODE}','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_external_sources_params('',p_id,'BillingAccNumberExternalSource','IN','IsBillingAccountNumberManual','{field:BILL_ACC_NUMBER_IS_MANUAL}','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_external_sources_params('',p_id,'BillingAccNumberExternalSource','IN','RevisionNumber','{field:REVISION_NUMBER}','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_external_sources_params('',p_id,'BillingAccNumberExternalSource','IN','RenewalCounter','{field:RENEWAL_COUNTER}','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_external_sources_params('',p_id,'BillingAccNumberExternalSource','IN','PolicyNumber','{'||'/'||k_pct_management_new.f_get_object_field_id('Billing_Account','BILL_ACC_POL_ASSIGNMENT')||'/'||k_pct_management_new.f_get_object_field_id('Billing Account Number Assignment', 'POLICY_NUMBER')|| '}','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_external_sources_params('',p_id,'BillingAccNumberExternalSource','IN','InsuredGid','{field:INSURED_GID}','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_external_sources_params('',p_id,'BillingAccNumberExternalSource','IN','Id','{field:ID}','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
v_return := k_pct_management_new.f_set_external_sources_params('',p_id,'BillingAccNumberExternalSource','IN','BillAccountNumberGenerated','{field:BILL_ACC_NUMBER_GENERATED}','admin@cover-all.com','Y',p_error);
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

-- BILLING CHANGES END

	k_pct_management_new.G_DEBUG_MODE := 'N' ;


EXCEPTION
   WHEN user_exception THEN
       ROLLBACK;
       DBMS_OUTPUT.PUT_LINE('Error is: ' || substr(p_error,1,240));
       DBMS_OUTPUT.PUT_LINE('Return code is: ' || v_return);
       RAISE;
   WHEN OTHERS THEN
       ROLLBACK;
       DBMS_OUTPUT.PUT_LINE('Error is: ' || substr(p_error,1,240));
       DBMS_OUTPUT.PUT_LINE('Return code is: ' || v_return);
       RAISE;
END;
/


SET ESCAPE OFF

PROMPT =====================================
PROMPT