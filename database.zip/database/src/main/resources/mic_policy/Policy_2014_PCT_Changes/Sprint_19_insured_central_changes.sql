PROMPT ================================
PROMPT Executing mic_policy_common.dtab
PROMPT ================================
SET VERIFY OFF SERVEROUTPUT ON SIZE 1000000
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
WHENEVER OSERROR EXIT OSCODE
 
SET ESCAPE \

DECLARE 
   p_error         LONG;
   p_id            NUMBER;
   v_return        NUMBER;
   user_exception  EXCEPTION;
BEGIN


k_pct_management_new.G_DEBUG_MODE := 'Y' ;

v_return := k_pct_management_new.f_set_query('',p_id,'CHK_LOCKED_QUOTES_FOR_AGENTS','','SELECT k_insured_central_management.allow_account_change_for_agent(''{field:ENTITY_REFERENCE}'')   FROM DUAL','N','Checks if account level changes are allowed for agents','','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_query('',p_id,'CHK_LOCKED_QUOTES_FOR_SECURA_USER','','SELECT k_insured_central_management.allow_accnt_change_underwriter(''{field:ENTITY_REFERENCE}'')   FROM DUAL','N','Checks if account level changes are allowed for secura user','','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;


v_return := k_pct_management_new.f_set_primitive('',p_id,'Locked quotes Label','STRING','250','','Label','TEXTFIELD','','', k_pct_management_new.f_get_query_id(''),'','','','','','','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_object('',p_id,'Quote Locked','Account editing not allowed','MIS_LOCKED_QUOTES','MLQ','NA','Y','N','Cannot open account in edit mode','','OBJECT','N','','','admin@cover-all.com','Y',p_error,'','','','','');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Insured',''),p_id,'INSURED_LOCKED_QUOTES',k_pct_management_new.f_get_object_id('Insured'),k_pct_management_new.f_get_primitive_id(''),k_pct_management_new.f_get_object_id('Quote Locked'),NULL,'INSURED_LOCKED_QUOTES','NA','','','','','Insured Edit Not Permitted','N','Y','N','','700','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'Y','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'Y','POPUP','','','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Quote Locked',''),p_id,'QUOTE_LOCKED_MSG',k_pct_management_new.f_get_object_id('Quote Locked'),k_pct_management_new.f_get_primitive_id('Locked quotes Label'),k_pct_management_new.f_get_object_id(''),NULL,'QUOTE_LOCKED_MSG','NA','','','Account is not available for editing,<br>Either some of the quotes are being modified or workflow is in progress or<br>one or more unbooked policies exists for the account.','','','N','N','N','','101','200',k_pct_management_new.f_get_query_id(''),'','Y','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_criteria('',p_id,'19700','1','','','param:ENTITY_TYPE','=','''INSURED''','','AND','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'19700','2','','','field:INSURED_SEARCH_COMPLETE','=','''Y''','','AND','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'19700','3','','','queryvalue:CHK_LOCKED_QUOTES_FOR_AGENTS','=','''N''','','AND','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'19700','4','','NVL(','queryvalue:CHK_IF_RC_IS_TURNED_ON',', ''Y'') =','''N''','','','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_criteria('',p_id,'19701','1','','','param:ENTITY_TYPE','=','''INSURED''','','AND','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'19701','2','','','field:INSURED_SEARCH_COMPLETE','=','''Y''','','AND','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'19701','3','','','queryvalue:CHK_LOCKED_QUOTES_FOR_SECURA_USER','=','''N''','','AND','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'19701','4','','NVL(','queryvalue:CHK_IF_RC_IS_TURNED_ON',', ''Y'') =','''N''','','','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'14178',k_pct_management_new.f_get_object_field_id('Insured','INSURED_LOCKED_QUOTES'),'SE','19700','','','','','','N','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',NULL,'','','','','','','','','','admin@cover-all.com','Y',p_error,'IN(agent_role)','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'14179',k_pct_management_new.f_get_object_field_id('Insured','INSURED_LOCKED_QUOTES'),'SE','19701','','','','','','N','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',NULL,'','','','','','','','','','admin@cover-all.com','Y',p_error,'IN(allow_risk_clearance_override)','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'14180',k_pct_management_new.f_get_object_field_id('Quote Locked','QUOTE_LOCKED_MSG'),'SE','','','Account is not available for editing.<br>Either some of the quotes/policies are being modified or their workflow is in progress or<br>one or more unbooked policies exists for the account.','','','','','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',NULL,'','','','','','','','','','admin@cover-all.com','Y',p_error,'IN(agent_role)','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'14181',k_pct_management_new.f_get_object_field_id('Quote Locked','QUOTE_LOCKED_MSG'),'SE','','','Account is not available for editing.<br>Either some of the quotes/policies are being modified or their workflow is in progress.','','','','','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',NULL,'','','','','','','','','','admin@cover-all.com','Y',p_error,'IN(allow_risk_clearance_override)','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_operation('',p_id,'20001','1','com.coverall.pct.client.operations.RCContinueOperation','RC success continue','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_operation_param('',p_id,k_pct_management_new.f_get_operation_id('20001', '1'),'response','Y','','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_operation('',p_id,'20000','1','com.coverall.pct.client.operations.ExitApplicationOperation','Navigate to insured dashboard','admin@cover-all.com','Y',p_error);

v_return := k_pct_management_new.f_set_operation_param('',p_id,k_pct_management_new.f_get_operation_id('20000', '1'),'exitTo','insuredDashboard','','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_RC.f_set_toolbar('',p_id,'Risk Clearance Success',NULL,'SE','','','',20001,'0','Risk Clearance success','CONTINUE','FORM','','','RIGHT','admin@cover-all.com','Y',p_error,'N','','Y','','','','','','','','','','19989','','','',k_pct_management_new.f_get_object_field_id('Insured','INSURED_RISK_CLEAR_SUCCESS'));  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_RC.f_set_toolbar('',p_id,'Risk Clearance Fail',NULL,'SE','','','',20001,'0','Risk Clearance Fail','CONTINUE','FORM','','','RIGHT','admin@cover-all.com','Y',p_error,'N','','Y','','','','IN(allow_risk_clearance_override)','','','','','','19990','','','',k_pct_management_new.f_get_object_field_id('Insured','INSURED_RISK_CLEAR_FAIL'));  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_toolbar('',p_id,'LOCKED QUOTE',NULL,'SE','','','',20000,'0','naviagte to insured dashboard','CONTINUE','FORM','','','RIGHT','admin@cover-all.com','Y',p_error,'N','','Y','','','','','','','','','','20000','','','',k_pct_management_new.f_get_object_field_id('Insured','INSURED_LOCKED_QUOTES'));  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_query('',p_id,'LOCATION_DELETE_VALIDATION','','SELECT DECODE(COUNT(1),0,''Y'',''N'') FROM VW_MIS_LOCATIONS LOC WHERE LOC.FK_COLUMN_NAME=''POLICY_LOCATION''
AND LOC.FK_COLUMN_VALUE IN (
SELECT gid 
            FROM VW_MIS_QUOTE_POLICIES
            WHERE ENTITY_REFERENCE IN
            (   SELECT ENTITY_REFERENCE
                FROM VW_MIS_INSUREDS
                WHERE MASTER_RECORD_GID = ''{field:ENTITY_REFERENCE}''
            )) AND LOC.MASTER_RECORD_GID = ''{field:GID}''','N','checks if any quotes exist with the location added on insured','','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;


v_return := k_pct_management_new.f_set_object_field_valns('',p_id,'200002',k_pct_management_new.f_get_object_field_id('LOCATION','LOCATION_NO'),k_pct_management_new.f_get_object_field_id('INSURED','INSURED_LOCATION'),'SE','',k_pct_management_new.f_get_query_id('LOCATION_DELETE_VALIDATION'),k_pct_management_new.f_get_validator_id(''),'ON_DELETE','Cannot delete a location, already added on quotes','','admin@cover-all.com','Y',p_error,'','', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','', '');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

k_pct_management_new.G_DEBUG_MODE := 'N' ;


EXCEPTION
   WHEN user_exception THEN
       ROLLBACK;
       DBMS_OUTPUT.PUT_LINE('Error is: ' || substr(p_error,1,240));
       DBMS_OUTPUT.PUT_LINE('Return code is: ' || v_return);
       RAISE;
   WHEN OTHERS THEN
       ROLLBACK;
       DBMS_OUTPUT.PUT_LINE('Error is: ' || substr(p_error,1,240));
       DBMS_OUTPUT.PUT_LINE('Return code is: ' || v_return);
       RAISE;
END;
/


SET ESCAPE OFF

PROMPT =====================================
PROMPT