set serveroutput on
set escape \
set define off

DECLARE 
   p_error         LONG;
   p_id            NUMBER;
   v_return        NUMBER;
   user_exception  EXCEPTION;
BEGIN


v_return := k_pct_management_new.f_set_toolbar('',p_id,'Rate Button - Next Gen',NULL,'','','','rate-white.png',30,'200','Rating next gen button','Calculate Premium','TREE','','','CENTER','admin@cover-all.com','Y',p_error,'N','','Y','','','','','','','','','','10030','','','',NULL);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_toolbar('',p_id,'Suspend Button - Next Gen',NULL,'','','','save-white.png',11002,'300','Save and Resume Later','Save & Resume Later','TREE','','','LEFT','admin@cover-all.com','Y',p_error,'N','','Y','','','','','','','','','','10110','','','',NULL);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_toolbar('',p_id,'Suspend Button - Next Gen',NULL,'','11044','','save-white.png',11002,'300','Disable button for unsaved policy when policy number is zero or no company code is present','Save & Resume Later','TREE','','','LEFT','admin@cover-all.com','Y',p_error,'','','N','','','','','','','','','','20043','','','',NULL);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_toolbar('',p_id,'Complete Button - Next Gen',NULL,'','','','save-proceed-white.png',11003,'400','Rate and exit','Save & Proceed Further','TREE','','','LEFT','admin@cover-all.com','Y',p_error,'N','','Y','','','','','','','','','','10070','','','',NULL);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;



v_return := k_pct_management_new.f_set_toolbar('',p_id,'Continue',NULL,'','','','next.png',19888,'11','Continue','Next','TREE','','','RIGHT','admin@cover-all.com','Y',p_error,'N','','Y','','com.coverall.pctv2.server.toolbar.ContinueButtonImplementor','','','','','','','','20029','','','',NULL);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_toolbar('',p_id,'Continue',NULL,'','19854','','next.png',19888,'11','Continue','Next','TREE','','','RIGHT','admin@cover-all.com','Y',p_error,'Y','','N','','com.coverall.pctv2.server.toolbar.ContinueButtonImplementor','','IN(allow_risk_clearance_override)','','','','','','20045','','','',NULL);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_toolbar('',p_id,'CONTINUE_ON_RC_FAILURE',NULL,'','19854','','next.png',19906,'11','Continue','Next','TREE','','','RIGHT','admin@cover-all.com','Y',p_error,'N','','Y','','com.coverall.pctv2.server.toolbar.ContinueButtonImplementor','','IN(allow_risk_clearance_override)','','','','','','20047','','','',NULL);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


EXCEPTION
   WHEN user_exception THEN
       ROLLBACK;
       DBMS_OUTPUT.PUT_LINE('Error is: ' || substr(p_error,1,240));
       DBMS_OUTPUT.PUT_LINE('Return code is: ' || v_return);
       RAISE;
   WHEN OTHERS THEN
       ROLLBACK;
       DBMS_OUTPUT.PUT_LINE('Error is: ' || substr(p_error,1,240));
       DBMS_OUTPUT.PUT_LINE('Return code is: ' || v_return);
       RAISE;
END;
/
set escape off;


