PROMPT ================================
PROMPT Executing mic_policy_common.dtab
PROMPT ================================
SET VERIFY OFF SERVEROUTPUT ON SIZE 1000000
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
WHENEVER OSERROR EXIT OSCODE
 
SET ESCAPE \

DECLARE 
   p_error         LONG;
   p_id            NUMBER;
   v_return        NUMBER;
   user_exception  EXCEPTION;
BEGIN


k_pct_management_new.G_DEBUG_MODE := 'Y' ;

v_return := k_pct_management_new.f_set_query('',p_id,'LOCATION_DELETE_VALIDATION','','SELECT DECODE(COUNT(1),0,''Y'',''N'') FROM VW_MIS_LOCATIONS LOC 
            WHERE ENTITY_REFERENCE IN
            (   SELECT ENTITY_REFERENCE
                FROM VW_MIS_INSUREDS
                WHERE MASTER_RECORD_GID = ''{field:ENTITY_REFERENCE}''
            ) AND LOC.MASTER_RECORD_GID = ''{field:GID}''','N','checks if any quotes exist with the location added on insured','','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_query('',p_id,'UNDERWRITER_DISABLE','','SELECT DECODE(COUNT(1),0,''N'',''Y'') FROM VW_MIS_QUOTE_POLICIES MQP            
WHERE ENTITY_REFERENCE IN
            (   SELECT ENTITY_REFERENCE
                FROM VW_MIS_INSUREDS
                WHERE MASTER_RECORD_GID = ''{field:ENTITY_REFERENCE}''
            )','N','Disable the underwriter field for agent if atleast one quote or policy exists','','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'19702','1','','','param:ENTITY_TYPE','=','''QUOTE''','','AND','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'19702','2','','','field:MASTER_RECORD_GID','IS','NULL','','','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'19703','1','','','param:ENTITY_TYPE','IN','(''QUOTE'',''POLICY'')','','AND','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'19703','2','','NVL(','param:ISBACKGROUND',', ''N'') =','''Y''','','','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'19704','1','','','param:ENTITY_TYPE','=','''INSURED''','','AND','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'19704','2','','','queryvalue:UNDERWRITER_DISABLE','=','''Y''','','','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_object_field_valns('',p_id,'200002',k_pct_management_new.f_get_object_field_id('LOCATION','LOCATION_NO'),k_pct_management_new.f_get_object_field_id('INSURED','INSURED_LOCATION'),'SE','',k_pct_management_new.f_get_query_id('LOCATION_DELETE_VALIDATION'),k_pct_management_new.f_get_validator_id(''),'ON_DELETE','Cannot delete a location, already added on quotes','','admin@cover-all.com','Y',p_error,'','', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','', '');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'14184',k_pct_management_new.f_get_object_field_id('Underwriter Details','UNDERWRITER_NAME'),'SE','19704','','','','','','','N','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',k_pct_management_new.f_get_object_field_id('INSURED','IN_UNDERWRITING_DETAILS'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'IN(agent_role)','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_reusable_object(p_id,'','POLICY_INSURED_SE','SE','',NULL,'','POLICY',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,'INSURED',NULL,'Y',k_pct_management_new.f_get_object_field_id('INSURED','BUSINESS_NAME') ,'',k_pct_management_new.f_get_query_id('REUSABLE INSUREDS'),'INSURED','<?xml version=""1.0"" encoding=""UTF-8""?>
<xsl:stylesheet version=""1.0"" xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"">
    <xsl:template match=""Result"">
                <div>
                <div class=""SuggestBox-Bold-Content"">
                    <xsl:if test=""sugg_business_name != ''''"">
                        <u><xsl:value-of select=""sugg_business_name""/></u>
                    </xsl:if>
                </div>
                <div class=""SuggestBox-Content"">                    
                    <xsl:if test=""sugg_line_1 != ''''"">
                        \&#160; <xsl:value-of select=""sugg_line_1""/>
                    </xsl:if>
                    <xsl:if test=""sugg_line_2 != ''''""> 
                       \&#160; <xsl:value-of select=""sugg_line_2""/>
                    </xsl:if>
                    <xsl:if test=""sugg_city != ''''"">
                        \&#160; <xsl:value-of select=""sugg_city""/>
                    </xsl:if>
                    <xsl:if test=""sugg_state_desc != ''''"">
                        \&#160; <xsl:value-of select=""sugg_state_desc""/>
                    </xsl:if>
                    <xsl:if test=""sugg_zip_code != ''''"">
                        \&#160; <xsl:value-of select=""sugg_zip_code""/>
                    </xsl:if>
                </div>
                <div class=""SuggestBox-Content"">
                    <xsl:if test=""sugg_fein != ''''""> 
                        \&#160; FEIN: <b><xsl:value-of select=""sugg_fein""/></b>
                    </xsl:if>
                    <xsl:if test=""sugg_sic_code != ''''"">
                        \&#160; SIC: <b><xsl:value-of select=""sugg_sic_code""/></b>
                    </xsl:if>
                    <xsl:if test=""sugg_naics_code != ''''"">
                        \&#160; NAICS: <b><xsl:value-of select=""sugg_naics_code""/></b>
                    </xsl:if>
                </div>
                <div class=""SuggestBox-Content"">
                    <xsl:if test=""sugg_account_number != ''''"">
                        \&#160; Account#: <b><xsl:value-of select=""sugg_account_number""/></b>
                    </xsl:if>
                </div>
                </div>
    </xsl:template>
</xsl:stylesheet>','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object(p_id,'','INSURED_ADDRESS_SE','SE','','/'|| k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED'),'','POLICY',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_ADDRESS') ,'INSURED',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_ADDRESS') ,'Y',NULL,'',k_pct_management_new.f_get_query_id(''),'INSURED','','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;
  
v_return := k_pct_management_new.f_set_reusable_object(p_id,'','INSURED_CONTACT_SE','SE','','/'|| k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED'),'','POLICY',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_CONTACT') ,'INSURED',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_CONTACT') ,'N',NULL,'',k_pct_management_new.f_get_query_id(''),'INSURED','','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;


v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','NAME_TYPE_SE','SE','','N',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('INSURED','NAME_TYPE'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','NAME_TYPE_STAT_CODE_SE','SE','','N',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('INSURED','NAME_TYPE_STAT_CODE'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','FIRST_NAME_SE','SE','','N',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('INSURED','FIRST_NAME'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','MIDDLE_NAME_SE','SE','','N',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('INSURED','MIDDLE_NAME'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','SURNAME_SE','SE','','N',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('INSURED','SURNAME'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','INSURED_TYPE_SE','SE','','N',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('INSURED','INSURED_TYPE'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','INSURED_TYPE_DESCRIPTION_SE','SE','','N',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('INSURED','INSURED_TYPE_DESCRIPTION'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','INSURED_TYPE_CODE_SE','SE','','N',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('INSURED','INSURED_TYPE_CODE'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','BUSINESS_DESCRIPTION_SE','SE','','N',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('INSURED','BUSINESS_DESCRIPTION'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','SIC_CODE_SE','SE','','N',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('INSURED','SIC_CODE'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','NAICS_CODE_SE','SE','','N',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('INSURED','NAICS_CODE'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','DOING_BUSINESS_AS_SE','SE','','N',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('INSURED','DOING_BUSINESS_AS'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','STATE_OF_INCORPORATION_SE','SE','','N',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('INSURED','STATE_OF_INCORPORATION'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','YEARS_OF_OPERATION_SE','SE','','N',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('INSURED','YEARS_OF_OPERATION'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','SEARCH_KEY_WORDS_SE','SE','','N',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('INSURED','SEARCH_KEY_WORDS'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','ACCOUNT_NUMBER_SE','SE','','Y',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('INSURED','ACCOUNT_NUMBER'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','DB_NUMBER_SE','SE','','Y',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('INSURED','DB_NUMBER'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','IS_CHARITABLE_ORG_SE','SE','','N',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('INSURED','IS_CHARITABLE_ORG'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','SOCIAL_SECURITY_NUMBER_SE','SE','','Y',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('INSURED','SOCIAL_SECURITY_NUMBER'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','DESCRIPTION_OF_OPERATIONS_SE','SE','','N',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('INSURED','DESCRIPTION_OF_OPERATIONS'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','PROVINCE_SE','SE','','Y',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('ADDRESS','PROVINCE'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','POSTAL_CODE_SE','SE','','Y',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('ADDRESS','POSTAL_CODE'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','COUNTY_SE','SE','','Y',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('ADDRESS','COUNTY'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','GEO_REF_ID_SE','SE','','N',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('ADDRESS','GEO_REF_ID'),'Location Verification','N','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','CONTACT_NAME_SE','SE','','N',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('CONTACT','CONTACT_NAME'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','E_MAIL_SE','SE','','N',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('CONTACT','E_MAIL'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','TITLE_SE','SE','','N',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('CONTACT','TITLE'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','PHONE_2_SE','SE','','N',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('CONTACT','PHONE_2'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','FAX_SE','SE','','N',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('CONTACT','FAX'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','WEB_SITE_SE','SE','','N',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('CONTACT','WEB_SITE'),'','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

k_pct_management_new.G_DEBUG_MODE := 'N' ;


EXCEPTION
   WHEN user_exception THEN
       ROLLBACK;
       DBMS_OUTPUT.PUT_LINE('Error is: ' || substr(p_error,1,240));
       DBMS_OUTPUT.PUT_LINE('Return code is: ' || v_return);
       RAISE;
   WHEN OTHERS THEN
       ROLLBACK;
       DBMS_OUTPUT.PUT_LINE('Error is: ' || substr(p_error,1,240));
       DBMS_OUTPUT.PUT_LINE('Return code is: ' || v_return);
       RAISE;
END;
/


SET ESCAPE OFF

PROMPT =====================================
PROMPT