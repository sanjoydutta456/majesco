set serveroutput on
set escape \
set define off

DECLARE 
   p_error         LONG;
   p_id            NUMBER;
   v_return        NUMBER;
   user_exception  EXCEPTION;
BEGIN

v_return := k_pct_management_new.f_set_criteria('',p_id,'SPD-COM-0034','1','','','queryvalue:CHK_RISK_LOCK_ALREADY_ACQUIRED','IN','(''Y'', ''N'')','','AND','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'SPD-COM-0034','2','','','queryvalue:GET_INSURED_SEARCH_COMPLETE_STATUS','=','''Y''','','AND','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'SPD-COM-0034','3','','','param:ENTITY_TYPE','=','''INSURED''','','','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'SPD-COM-0057',k_pct_management_new.f_get_object_field_id('Risk Clearance','RISK_CLEARANCE_RULE'),'SE','SPD-COM-0034','*','','','','','','','','','',k_pct_management_new.f_get_query_id('LOAD_RISK_CLEARANCE_RULES'),'','','','','','','','','','','','','','','','','Y','','','',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_RISK_CLEARANCE') || '/' || k_pct_management_new.f_get_object_field_id('RISK CLEARANCE','RISK_CLEARANCE_RULE'),'','','RISK_RULE_ORDER','ASC','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

EXCEPTION
   WHEN user_exception THEN
       ROLLBACK;
       DBMS_OUTPUT.PUT_LINE('Error is: ' || substr(p_error,1,240));
       DBMS_OUTPUT.PUT_LINE('Return code is: ' || v_return);
       RAISE;
   WHEN OTHERS THEN
       ROLLBACK;
       DBMS_OUTPUT.PUT_LINE('Error is: ' || substr(p_error,1,240));
       DBMS_OUTPUT.PUT_LINE('Return code is: ' || v_return);
       RAISE;
END;
/
set escape off;


