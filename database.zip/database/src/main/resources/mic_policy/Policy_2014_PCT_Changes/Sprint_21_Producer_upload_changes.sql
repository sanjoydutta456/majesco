set serveroutput on
set escape \
set define off

DECLARE 
   p_error         LONG;
   p_id            NUMBER;
   v_return        NUMBER;
   user_exception  EXCEPTION;
BEGIN


k_pct_management_new.g_debug_mode:='Y';


  v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'NSK-COM-0058',k_pct_management_new.f_get_object_field_id('PRODUCER','PRODUCER_NAME'),'SE','NSK-COM-0004','','Name Not Found','','','','','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_PRODUCER'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'IN(allow_risk_clearance_override)','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;
  
 v_return := k_pct_management_new.f_set_query('',p_id,'PRODUCER_NAME_LOOKUP','','select  NAME PRODUCER_NAME ,F_NAME F_NAME ,
  M_NAME M_NAME,
  L_NAME L_NAME,
  AGENT_CODE SUB_AGENT_CODE,
CONTACT_id  PRODUCER_CONTACT_ID from 
(select    SCS.SCO_FIRST_NAME || '' ''|| SCS.SCO_MIDDLE_NAME||'' ''|| SCS.SCO_LAST_NAME NAME,
SCS.SCO_FIRST_NAME F_NAME,
  SCS.SCO_MIDDLE_NAME M_NAME,
  SCS.SCO_LAST_NAME L_NAME ,
  scs.SCO_CODE AGENT_CODE,
mfo.mfc_id CONTACT_id
FROM mis_folder_obj_contacts_assn mfo,
  sdb_contacts scs,
  SHL_PRODUCERS SPS
  where sps.spr_producer_code  = (select nvl(mro_producer_code, mro_display_producer_code) from mis_producers where mro_entity_reference = ''{field:ENTITY_REFERENCE}''  )
and scs.sco_id = mfo.mfc_contact_id
and sps.spr_producer_id = mfo.mfc_entity_reference
and mfo.mfc_role             =  ''Broker''
union
select ''Name Not Found'' NAME,''Name Not Found'' F_NAME,null M_NAME,null L_NAME,
'' '' AGENT_CODE,
null CONTACT_id
from DUAL)
where 1=1
','N','Producer Name Lookup','','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF; 
 
  
k_pct_management_new.g_debug_mode:='N';


EXCEPTION
   WHEN user_exception THEN
       ROLLBACK;
       DBMS_OUTPUT.PUT_LINE('Error is: ' || substr(p_error,1,240));
       DBMS_OUTPUT.PUT_LINE('Return code is: ' || v_return);
       RAISE;
   WHEN OTHERS THEN
       ROLLBACK;
       DBMS_OUTPUT.PUT_LINE('Error is: ' || substr(p_error,1,240));
       DBMS_OUTPUT.PUT_LINE('Return code is: ' || v_return);
       RAISE;
END;
/
set escape off;


