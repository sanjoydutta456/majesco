PROMPT ================================
PROMPT Executing mic_policy_common.dtab
PROMPT ================================
SET VERIFY OFF SERVEROUTPUT ON SIZE 1000000
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
WHENEVER OSERROR EXIT OSCODE
 
SET ESCAPE \

DECLARE 
   p_error         LONG;
   p_id            NUMBER;
   v_return        NUMBER;
   user_exception  EXCEPTION;
BEGIN


	k_pct_management_new.G_DEBUG_MODE := 'Y' ;

	--Adding Column 'ROLE_CREATED' in 'Risk Clearance' to add support to determine if the row was added by Underwriter
	
	v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Risk Clearance',''),p_id,'ROLE_CREATED',k_pct_management_new.f_get_object_id('Risk Clearance'),k_pct_management_new.f_get_primitive_id('Business Name'),k_pct_management_new.f_get_object_id(''),NULL,'ROLE_CREATED','NA','','','','','User Created Role','N','Y','Y','','535','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','Y','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','FULL_QUOTE_ONLY','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


	
		
	v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'ZNK-COM-0056',k_pct_management_new.f_get_object_field_id('Risk Clearance','ROLE_CREATED'),'SE','','','SELECT ''allow_risk_clearance_override'' FROM DUAL ','','','','','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_RISK_CLEARANCE') || '/' || k_pct_management_new.f_get_object_field_id('RISK CLEARANCE','ROLE_CREATED'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'IN(allow_risk_clearance_override)','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
	
	

	k_pct_management_new.G_DEBUG_MODE := 'N' ;


EXCEPTION
   WHEN user_exception THEN
       ROLLBACK;
       DBMS_OUTPUT.PUT_LINE('Error is: ' || substr(p_error,1,240));
       DBMS_OUTPUT.PUT_LINE('Return code is: ' || v_return);
       RAISE;
   WHEN OTHERS THEN
       ROLLBACK;
       DBMS_OUTPUT.PUT_LINE('Error is: ' || substr(p_error,1,240));
       DBMS_OUTPUT.PUT_LINE('Return code is: ' || v_return);
       RAISE;
END;
/


SET ESCAPE OFF

PROMPT =====================================
PROMPT