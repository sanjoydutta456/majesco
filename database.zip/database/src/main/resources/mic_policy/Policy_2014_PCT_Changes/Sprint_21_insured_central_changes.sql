PROMPT ================================
PROMPT Executing mic_policy_common.dtab
PROMPT ================================
SET VERIFY OFF SERVEROUTPUT ON SIZE 1000000
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
WHENEVER OSERROR EXIT OSCODE
 
SET ESCAPE \

DECLARE 
   p_error         LONG;
   p_id            NUMBER;
   v_return        NUMBER;
   user_exception  EXCEPTION;
BEGIN


k_pct_management_new.G_DEBUG_MODE := 'Y' ;


-- Changes for location delete on insured
v_return := k_pct_management_new.f_set_object_field_valns('',p_id,'200002',k_pct_management_new.f_get_object_field_id('LOCATION','LOCATION_NO'),k_pct_management_new.f_get_object_field_id('INSURED','INSURED_LOCATION'),'SE','',k_pct_management_new.f_get_query_id('LOCATION_DELETE_VALIDATION'),k_pct_management_new.f_get_validator_id(''),'ON_DELETE','Location is already added on quote/policy. Cannot delete the location.','','admin@cover-all.com','Y',p_error,'','', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','', '');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


-- Changes for underwriter flooding
v_return := k_pct_management_new.f_set_query('',p_id,'UW_MASTER_GID_AUTO_GENERATE','','SELECT gid master_record_gid, 
UNDERWRITER_NAME UNDERWRITER_NAME,
UNDERWRITER_CODE UNDERWRITER_CODE
FROM VW_MIS_UNDERWRITING_DETAILS
WHERE entity_reference = ''''||
  (SELECT master_record_gid
  FROM vw_mis_insureds
  WHERE entity_reference = ''{field:ENTITY_REFERENCE}''
  ) ||''''','N','Auto generate master record gid of policy underwriter','','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_query('',p_id,'UW_AUTO_LOOKUP','','SELECT
  underwriter_code underwriter_code,
  underwriter_name underwriter_name
FROM
  vw_mis_underwriting_details u
WHERE
u.entity_reference = ''{field:ENTITY_REFERENCE}''','N','Defaulting of underwriter','','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;


v_return := k_pct_management_new.f_set_criteria('',p_id,'19702','1','','','param:ENTITY_TYPE','=','''QUOTE''','','AND','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'19702','2','','','field:MASTER_RECORD_GID','IS','NULL','','','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'19703','1','','','param:ENTITY_TYPE','IN','(''QUOTE'',''POLICY'')','','AND','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'19703','2','','NVL(','param:ISBACKGROUND',', ''N'') =','''Y''','','','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'19705','1','','','param:ENTITY_TYPE','IN','(''QUOTE'',''POLICY'')','','','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'14183',k_pct_management_new.f_get_object_field_id('POLICY','UNDERWRITER_CODE'),'SE','19703','','','','','','','','','','',k_pct_management_new.f_get_query_id('UW_AUTO_LOOKUP'),'','','','','','','','','','','','','','','M','','','','','',k_pct_management_new.f_get_object_field_id('POLICY','UNDERWRITER_CODE'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'14185',k_pct_management_new.f_get_object_field_id('Insured','IN_UNDERWRITING_DETAILS'),'SE','19705','','','','','','','Y','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','N','','','','',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') || '/' ||k_pct_management_new.f_get_object_field_id('INSURED','IN_UNDERWRITING_DETAILS'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'14186',k_pct_management_new.f_get_object_field_id('Underwriter Details','UNDERWRITER_CODE'),'SE','19702','','','','','','','','','','',k_pct_management_new.f_get_query_id('UW_MASTER_GID_AUTO_GENERATE'),'','','','','','','','','','','','','','','M','','','','','',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') || '/' ||k_pct_management_new.f_get_object_field_id('INSURED','IN_UNDERWRITING_DETAILS'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_reusable_object(p_id,'','INSURED_UNDERWRITER','SE','','/'|| k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED'),'','POLICY',k_pct_management_new.f_get_object_field_id('INSURED','IN_UNDERWRITING_DETAILS') ,'INSURED',k_pct_management_new.f_get_object_field_id('INSURED','IN_UNDERWRITING_DETAILS') ,'N',NULL,'',k_pct_management_new.f_get_query_id(''),'INSURED','','Y','Y','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','IN_UNDERWRITER_CODE_SE','SE','','N',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('Underwriter Details','UNDERWRITER_CODE'),'','Y','','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_reusable_object_fld(p_id,'','IN_UNDERWRITER_NAME_SE','SE','','N',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_INSURED') ,k_pct_management_new.f_get_object_field_id('Underwriter Details','UNDERWRITER_NAME'),'','Y','','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;
  
k_pct_management_new.G_DEBUG_MODE := 'N' ;


EXCEPTION
   WHEN user_exception THEN
       ROLLBACK;
       DBMS_OUTPUT.PUT_LINE('Error is: ' || substr(p_error,1,240));
       DBMS_OUTPUT.PUT_LINE('Return code is: ' || v_return);
       RAISE;
   WHEN OTHERS THEN
       ROLLBACK;
       DBMS_OUTPUT.PUT_LINE('Error is: ' || substr(p_error,1,240));
       DBMS_OUTPUT.PUT_LINE('Return code is: ' || v_return);
       RAISE;
END;
/


SET ESCAPE OFF

PROMPT =====================================
PROMPT