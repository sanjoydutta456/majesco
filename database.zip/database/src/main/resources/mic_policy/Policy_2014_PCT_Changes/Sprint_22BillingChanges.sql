set serveroutput on
set escape \
set define off

DECLARE 
   p_error         LONG;
   p_id            NUMBER;
   v_return        NUMBER;
   user_exception  EXCEPTION;
BEGIN

k_pct_management_new.g_debug_mode:='Y';

v_return := k_pct_management_new.f_set_query('',p_id,'BILL_POLICY_ASSIGN_AUTO_GEN','','select 
  POLICY_NUMBER, EFFECTIVE_DATE, EXPIRATION_DATE, POLICY_ORG_ENTITY_REF, LOB, PRODUCT_NAME, AGENCY_CODE, POLICY_PREMIUM
from (
  SELECT 
      p.POLICY_NUMBER POLICY_NUMBER
    , p.EFFECTIVE_DATE EFFECTIVE_DATE
    , p.EXPIRATION_DATE EXPIRATION_DATE
    , p.ORG_ENTITY_REFERENCE POLICY_ORG_ENTITY_REF 
    , p.product_code LOB
    , p.product_name product_name
    , pol_pr.producer_code AGENCY_CODE
    , p.written_premium policy_premium
  FROM VW_MIS_QUOTE_POLICIES p, VW_MIS_PRODUCERS pol_pr, VW_MIS_INSUREDS pol_ins, VW_MIS_INSUREDS ins, VW_MIS_PRODUCERS ins_pr
  where 1 = 1
  and p.gid = pol_pr.policy_producer
  and p.gid = pol_ins.policy_insured
  and p.ENTITY_TYPE = ''POLICY''
  and p.POLICY_NUMBER is not null
  and p.revision_number = 0
  and pol_pr.producer_of_record = ''Y''
  and ins.gid = {GLOBAL:INSURED_GID}
  and ins.gid = ins_pr.insured_producer
  and ins_pr.producer_code = pol_pr.producer_code
  and pol_ins.master_record_gid = ins.gid
  and k_transaction_management.f_is_policy_ready_for_booking(p.entity_type,p.entity_reference) = ''Y''
  and p.ORG_ENTITY_REFERENCE not in (
    select baa_policy_org_entity_ref
    from mis_billing_account_assign
    where baa_entity_reference = ''{field:entity_reference}''
    and baa_delete_link = ''Y''
  ) 
  and p.ORG_ENTITY_REFERENCE not in (
    select ''XXXX'' 
    from vw_mis_billing_account_assign 
    where entity_reference = ''{field:entity_reference}''
    and delete_link = ''Y''
  ) 
)','N','Auto generate query for billing account number policies','','admin@cover-all.com','Y',p_error);
dbms_output.put_line('p_error=' || p_error);

v_return := k_pct_management_new.f_set_query('',p_id,'BILL_POLICY_ASSIGN_AUTO_GEN_ENDORSEMENT','','{CP:
o1=/BILL_ACC_POL_ASSIGNMENT/;
s1=o1.POLICY_NUMBER;
s2=o1.EFFECTIVE_DATE;
s3=o1.EXPIRATION_DATE;
s4=o1.POLICY_ORG_ENTITY_REF;
s5=o1.LOB;
s6=o1.PRODUCT_NAME;
s7=o1.AGENCY_CODE;
s8=o1.POLICY_PREMIUM;
cond=o1.DELETE_LINK = ''N'';
cond=o1.ENTITY_STATUS = ''AUTO''
}','N','Auto generate query for billing account number policies for endorsement','','admin@cover-all.com','Y',p_error);
dbms_output.put_line('p_error=' || p_error);

v_return := k_pct_management_new.f_set_query('',p_id,'BILL_POLICY_ASSIGN_AUTO_GEN_RENEWAL','','{CP:
o1=/BILL_ACC_POL_ASSIGNMENT/;
s1=o1.POLICY_NUMBER;
s2=o1.EFFECTIVE_DATE;
s3=o1.EXPIRATION_DATE;
s4=o1.POLICY_ORG_ENTITY_REF;
s5=o1.LOB;
s6=o1.PRODUCT_NAME;
s7=o1.AGENCY_CODE;
s8=o1.POLICY_PREMIUM;
cond=o1.DELETE_LINK = ''N'';
cond=o1.ENTITY_STATUS = ''AUTO''
}','N','Auto generate query for billing account number policies for renewal','','admin@cover-all.com','Y',p_error);
dbms_output.put_line('p_error=' || p_error);

v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing Account Number Assignment',''),p_id,'DELETE_LINK',k_pct_management_new.f_get_object_id('Billing Account Number Assignment'),k_pct_management_new.f_get_primitive_id('TRI_STATE_CHECKBOX'),k_pct_management_new.f_get_object_id(''),NULL,'DELETE_LINK','NA','','','N','','Delete Link','N','Y','Y','','80','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
dbms_output.put_line('p_error=' || p_error);


v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Billing Account Number Assignment',''),p_id,'POLICY_ORG_ENTITY_REF',k_pct_management_new.f_get_object_id('Billing Account Number Assignment'),k_pct_management_new.f_get_primitive_id('Entity Reference'),k_pct_management_new.f_get_object_id(''),NULL,'POLICY_ORG_ENTITY_REF','NA','','','','','Policy Original Entity Reference','N','Y','N','','250','',k_pct_management_new.f_get_query_id(''),'','N','N',1,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');

v_return := k_pct_management_new.f_set_criteria('',p_id,'VS-CRIT-011','1','','NVL(','field:ENTITY_STATUS',', ''XX'') !=','''AUTO''','','','admin@cover-all.com','Y',p_error);
dbms_output.put_line('p_error=' || p_error);

v_return := k_pct_management_new.f_set_criteria('',p_id,'VS-CRIT-012','1','','NVL(','field:RENEWAL_COUNTER',', ''0'') =','0','','AND','admin@cover-all.com','Y',p_error);
dbms_output.put_line('p_error=' || p_error);
v_return := k_pct_management_new.f_set_criteria('',p_id,'VS-CRIT-012','2','','NVL(','field:REVISION_NUMBER',', ''0'') =','0','','','admin@cover-all.com','Y',p_error);
dbms_output.put_line('p_error=' || p_error);
v_return := k_pct_management_new.f_set_criteria('',p_id,'VS-CRIT-013','1','','NVL(','field:RENEWAL_COUNTER',', ''0'') >','0','','AND','admin@cover-all.com','Y',p_error);
dbms_output.put_line('p_error=' || p_error);
v_return := k_pct_management_new.f_set_criteria('',p_id,'VS-CRIT-013','2','','NVL(','field:REVISION_NUMBER',', ''0'') =','0','','','admin@cover-all.com','Y',p_error);
dbms_output.put_line('p_error=' || p_error);

v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'VS-BILL-0015',k_pct_management_new.f_get_object_field_id('Billing_Account', 'BILL_ACC_POL_ASSIGNMENT'),'SE','VS-CRIT-012','','','','','','','','','','',k_pct_management_new.f_get_query_id('BILL_POLICY_ASSIGN_AUTO_GEN'),'','','','','','','','','','','','','','','','','U','','','',NULL,'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
dbms_output.put_line('p_error=' || p_error);

v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'VS-BILL-0016',k_pct_management_new.f_get_object_field_id('Billing Account Number Assignment', 'DELETE_LINK'),'SE','','','','','','','N','','','','',k_pct_management_new.f_get_query_id(''),'','Y','','','','','','','','','','','','','','','','','','',NULL,'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','N','','','','N');
dbms_output.put_line('p_error=' || p_error);

v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'VS-BILL-0017',k_pct_management_new.f_get_object_field_id('Billing Account Number Assignment', 'DELETE_LINK'),'SE','VS-CRIT-011','','','','','','Y','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',NULL,'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');

v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'VS-BILL-0018',k_pct_management_new.f_get_object_field_id('Billing_Account', 'BILL_ACC_POL_ASSIGNMENT'),'SE','VS-CRIT-007','','','','','','','','','','',k_pct_management_new.f_get_query_id('BILL_POLICY_ASSIGN_AUTO_GEN_ENDORSEMENT'),'','','','','','','','','','','','','','','','','U','','','',NULL,'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
dbms_output.put_line('p_error=' || p_error);

v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'VS-BILL-0019',k_pct_management_new.f_get_object_field_id('Billing_Account', 'BILL_ACC_POL_ASSIGNMENT'),'SE','VS-CRIT-013','','','','','','','','','','',k_pct_management_new.f_get_query_id('BILL_POLICY_ASSIGN_AUTO_GEN_RENEWAL'),'','','','','','','','','','','','','','','','','U','','','',NULL,'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
dbms_output.put_line('p_error=' || p_error);

v_return := k_pct_management_new.f_set_operation('',p_id,'13007','1','com.coverall.pct.client.operations.SaveWithoutValidationOperation','Billing Account Delete Link','admin@cover-all.com','Y',p_error);
dbms_output.put_line('p_error=' || p_error);

v_return := k_pct_management_new.f_set_object_field_lsn('',p_id,'VS-BILL-0003',k_pct_management_new.f_get_object_field_id('Billing Account Number Assignment', 'DELETE_LINK'),NULL,'','','ON_CLICK','13007','Save data after selection of delete link','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','');

  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;


k_pct_management_new.g_debug_mode:='N';

EXCEPTION
   WHEN user_exception THEN
       ROLLBACK;
       DBMS_OUTPUT.PUT_LINE('Error is: ' || substr(p_error,1,240));
       DBMS_OUTPUT.PUT_LINE('Return code is: ' || v_return);
       RAISE;
   WHEN OTHERS THEN
       ROLLBACK;
       DBMS_OUTPUT.PUT_LINE('Error is: ' || substr(p_error,1,240));
       DBMS_OUTPUT.PUT_LINE('Return code is: ' || v_return);
       RAISE;
END;
/
set escape off;


