set serveroutput on
set escape \
set define off

DECLARE 
   p_error         LONG;
   p_id            NUMBER;
   v_return        NUMBER;
   user_exception  EXCEPTION;
BEGIN


k_pct_management_new.g_debug_mode:='Y';

--Changes for making grid non-editable in case of Similar account found and exact match found :  Start----

v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Similar Account Grid',''),p_id,'LINE_1',k_pct_management_new.f_get_object_id('Similar Account Grid'),k_pct_management_new.f_get_primitive_id('Address Line'),k_pct_management_new.f_get_object_id(''),NULL,'LINE_1','NA','','','','LABEL1','Street','N','N','Y','','130','',k_pct_management_new.f_get_query_id(''),'','Y','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','FULL_QUOTE_ONLY','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Exact Account Grid',''),p_id,'LINE_1',k_pct_management_new.f_get_object_id('Exact Account Grid'),k_pct_management_new.f_get_primitive_id('Address Line'),k_pct_management_new.f_get_object_id(''),NULL,'LINE_1','NA','','','','LABEL1','Street','N','N','Y','','330','',k_pct_management_new.f_get_query_id(''),'','Y','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','FULL_QUOTE_ONLY','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Similar Account Grid',''),p_id,'BUSINESS_NAME',k_pct_management_new.f_get_object_id('Similar Account Grid'),k_pct_management_new.f_get_primitive_id('Business Name'),k_pct_management_new.f_get_object_id(''),NULL,'BUSINESS_NAME','NA','','','','LABEL1','Name','N','N','Y','','110','',k_pct_management_new.f_get_query_id('SIMILAR_ACCOUNTS_AUTOGENERATE'),'','Y','N',1,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','FULL_QUOTE_ONLY','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_object_field('D',k_pct_management_new.f_get_object_field_id('Similar Account Grid','INSURED_TYPE'),p_id,'INSURED_TYPE',k_pct_management_new.f_get_object_id('Similar Account Grid'),k_pct_management_new.f_get_primitive_id('Legal Entity'),k_pct_management_new.f_get_object_id(''),NULL,'INSURED_TYPE','NA','','','','LABEL1','Insured Type','N','N','Y','','120','',k_pct_management_new.f_get_query_id(''),'','Y','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','FULL_QUOTE_ONLY','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Similar Account Grid',''),p_id,'CITY',k_pct_management_new.f_get_object_id('Similar Account Grid'),k_pct_management_new.f_get_primitive_id('Short Description'),k_pct_management_new.f_get_object_id(''),NULL,'CITY','NA','','','','LABEL1','City','N','N','Y','','140','',k_pct_management_new.f_get_query_id(''),'','Y','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','FULL_QUOTE_ONLY','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Similar Account Grid',''),p_id,'STATE_DESC',k_pct_management_new.f_get_object_id('Similar Account Grid'),k_pct_management_new.f_get_primitive_id('State'),k_pct_management_new.f_get_object_id(''),NULL,'STATE_DESC','NA','','','','LABEL1','State','N','N','Y','','160','',k_pct_management_new.f_get_query_id(''),'','Y','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','FULL_QUOTE_ONLY','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Similar Account Grid',''),p_id,'ZIP_CODE',k_pct_management_new.f_get_object_id('Similar Account Grid'),k_pct_management_new.f_get_primitive_id('Zip Zip Plus'),k_pct_management_new.f_get_object_id(''),NULL,'ZIP_CODE','NA','','','','LABEL1','Zip','N','N','Y','','170','',k_pct_management_new.f_get_query_id(''),'','Y','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','FULL_QUOTE_ONLY','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Similar Account Grid',''),p_id,'FEIN',k_pct_management_new.f_get_object_id('Similar Account Grid'),k_pct_management_new.f_get_primitive_id('FEIN'),k_pct_management_new.f_get_object_id(''),NULL,'FEIN','NA','','','','LABEL1','FEIN','N','N','Y','','180','',k_pct_management_new.f_get_query_id(''),'','Y','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','FULL_QUOTE_ONLY','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Similar Account Grid',''),p_id,'PHONE_1',k_pct_management_new.f_get_object_id('Similar Account Grid'),k_pct_management_new.f_get_primitive_id('US Phone'),k_pct_management_new.f_get_object_id(''),NULL,'PHONE_1','NA','','','','LABEL1','Phone','N','N','Y','','185','',k_pct_management_new.f_get_query_id(''),'','Y','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','FULL_QUOTE_ONLY','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Similar Account Grid',''),p_id,'SIMILAR_INSURED_GID',k_pct_management_new.f_get_object_id('Similar Account Grid'),k_pct_management_new.f_get_primitive_id('Insured GID'),k_pct_management_new.f_get_object_id(''),NULL,'SIMILAR_INSURED_GID','NA','','','','LABEL1','Insured GID','N','Y','Y','','190','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','FULL_QUOTE_ONLY','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Similar Account Grid',''),p_id,'QUOTE_NUMBER',k_pct_management_new.f_get_object_id('Similar Account Grid'),k_pct_management_new.f_get_primitive_id('Policy Number'),k_pct_management_new.f_get_object_id(''),NULL,'QUOTE_NUMBER','NA','','','','LABEL1','Quote Number','N','N','Y','','195','',k_pct_management_new.f_get_query_id(''),'','Y','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','FULL_QUOTE_ONLY','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Exact Account Grid',''),p_id,'BUSINESS_NAME',k_pct_management_new.f_get_object_id('Exact Account Grid'),k_pct_management_new.f_get_primitive_id('Business Name'),k_pct_management_new.f_get_object_id(''),NULL,'BUSINESS_NAME','NA','','','','LABEL1','Name','N','N','Y','','310','',k_pct_management_new.f_get_query_id('EXACT_ACCOUNTS_AUTOGENERATE'),'','Y','N',1,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','FULL_QUOTE_ONLY','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Exact Account Grid',''),p_id,'CITY',k_pct_management_new.f_get_object_id('Exact Account Grid'),k_pct_management_new.f_get_primitive_id('Short Description'),k_pct_management_new.f_get_object_id(''),NULL,'CITY','NA','','','','LABEL1','City','N','N','Y','','340','',k_pct_management_new.f_get_query_id(''),'','Y','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','FULL_QUOTE_ONLY','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Exact Account Grid',''),p_id,'STATE_DESC',k_pct_management_new.f_get_object_id('Exact Account Grid'),k_pct_management_new.f_get_primitive_id('State'),k_pct_management_new.f_get_object_id(''),NULL,'STATE_DESC','NA','','','','LABEL1','State','N','N','Y','','360','',k_pct_management_new.f_get_query_id(''),'','Y','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','FULL_QUOTE_ONLY','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Exact Account Grid',''),p_id,'ZIP_CODE',k_pct_management_new.f_get_object_id('Exact Account Grid'),k_pct_management_new.f_get_primitive_id('Zip Zip Plus'),k_pct_management_new.f_get_object_id(''),NULL,'ZIP_CODE','NA','','','','LABEL1','Zip','N','N','Y','','370','',k_pct_management_new.f_get_query_id(''),'','Y','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','FULL_QUOTE_ONLY','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Exact Account Grid',''),p_id,'FEIN',k_pct_management_new.f_get_object_id('Exact Account Grid'),k_pct_management_new.f_get_primitive_id('FEIN'),k_pct_management_new.f_get_object_id(''),NULL,'FEIN','NA','','','','LABEL1','FEIN','N','N','Y','','380','',k_pct_management_new.f_get_query_id(''),'','Y','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','FULL_QUOTE_ONLY','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Exact Account Grid',''),p_id,'PHONE_1',k_pct_management_new.f_get_object_id('Exact Account Grid'),k_pct_management_new.f_get_primitive_id('US Phone'),k_pct_management_new.f_get_object_id(''),NULL,'PHONE_1','NA','','','','LABEL1','Phone','N','N','Y','','385','',k_pct_management_new.f_get_query_id(''),'','Y','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','FULL_QUOTE_ONLY','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Exact Account Grid',''),p_id,'SELECTED_EXACT_INS_GID',k_pct_management_new.f_get_object_id('Exact Account Grid'),k_pct_management_new.f_get_primitive_id('Insured GID'),k_pct_management_new.f_get_object_id(''),NULL,'SELECTED_EXACT_INS_GID','NA','','','','LABEL1','Insured GID','N','Y','Y','','390','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','FULL_QUOTE_ONLY','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;


v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Exact Account Grid',''),p_id,'QUOTE_NUMBER',k_pct_management_new.f_get_object_id('Exact Account Grid'),k_pct_management_new.f_get_primitive_id('Policy Number'),k_pct_management_new.f_get_object_id(''),NULL,'QUOTE_NUMBER','NA','','','','LABEL1','Quote Number','N','N','Y','','395','',k_pct_management_new.f_get_query_id(''),'','Y','N',NULL,'N','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','FULL_QUOTE_ONLY','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

--Changes for making grid non-editable in case of Similar account found and exact match found :  End----

--CI-2 Mass Update Feature in PCT, This Change is to stop 'state' coming twice in tree :  Start----

v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('ADDRESS',''),p_id,'STATE_DESC',k_pct_management_new.f_get_object_id('ADDRESS'),k_pct_management_new.f_get_primitive_id('State'),k_pct_management_new.f_get_object_id(''),NULL,'STATE_DESC','NA','','','','','State Desc','N','Y','Y','','161','',k_pct_management_new.f_get_query_id('States lookup'),'19762','N','N',NULL,'N','Y','','Y','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','Y');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

--CI-2 Mass Update Feature in PCT, This Change is to stop 'state' coming twice in tree :  End----

k_pct_management_new.g_debug_mode:='N';

EXCEPTION
   WHEN user_exception THEN
       ROLLBACK;
       DBMS_OUTPUT.PUT_LINE('Error is: ' || substr(p_error,1,240));
       DBMS_OUTPUT.PUT_LINE('Return code is: ' || v_return);
       RAISE;
   WHEN OTHERS THEN
       ROLLBACK;
       DBMS_OUTPUT.PUT_LINE('Error is: ' || substr(p_error,1,240));
       DBMS_OUTPUT.PUT_LINE('Return code is: ' || v_return);
       RAISE;
END;
/
set escape off;


