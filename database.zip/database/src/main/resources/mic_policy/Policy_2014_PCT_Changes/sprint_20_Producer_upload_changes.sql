set serveroutput on
set escape \
set define off

DECLARE 
   p_error         LONG;
   p_id            NUMBER;
   v_return        NUMBER;
   user_exception  EXCEPTION;
BEGIN


k_pct_management_new.g_debug_mode:='Y';



v_return := k_pct_management_new.f_set_query('',p_id,'POLICY_PRODUCER_AUTO_GENERATE','','SELECT producer_code, display_producer_code, name, producer_of_record, distinguished_field_uw, surplus_lines, good_standing, license_producer_code, license_no, license_states, primary, commission, override_commission, direct_bill_indicator, sub_agent, application_producer, market_manager,PRODUCER_NAME,
  AGENCY_CONTACT  FROM (SELECT
  p.producer_code producer_code,
  p.display_producer_code display_producer_code,
  p.name name,
  p.producer_of_record producer_of_record,
  p.distinguished_field_uw distinguished_field_uw,
  p.surplus_lines surplus_lines,
  p.good_standing good_standing,
  p.license_producer_code license_producer_code,
  p.license_no license_no,
  p.license_states license_states,
  ''Y'' primary,
  p.commission commission,
  p.override_commission override_commission,
  p.direct_bill_indicator direct_bill_indicator,
  p.sub_agent sub_agent,
  p.application_producer application_producer,
  p.market_manager market_manager,
  P.PRODUCER_NAME PRODUCER_NAME,
  P.AGENCY_CONTACT AGENCY_CONTACT
FROM
  vw_mis_producers p
WHERE
  p.insured_producer = ''{param:INSUREDGID}'')','N','Defaulting of Producer','','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;
  
  
  
   v_return := k_pct_management_new.f_set_query('',p_id,'PRODUCER_NAME_LOOKUP','','select  NAME PRODUCER_NAME ,F_NAME F_NAME ,
  M_NAME M_NAME,
  L_NAME L_NAME,
  AGENT_CODE SUB_AGENT_CODE,
CONTACT_id  PRODUCER_CONTACT_ID from 
(select    SCS.SCO_FIRST_NAME || '' ''|| SCS.SCO_MIDDLE_NAME||'' ''|| SCS.SCO_LAST_NAME NAME,
SCS.SCO_FIRST_NAME F_NAME,
  SCS.SCO_MIDDLE_NAME M_NAME,
  SCS.SCO_LAST_NAME L_NAME ,
  scs.SCO_SUB_AGENT_CODE AGENT_CODE,
mfo.mfc_id CONTACT_id
FROM mis_folder_obj_contacts_assn mfo,
  sdb_contacts scs,
  SHL_PRODUCERS SPS
  where sps.spr_producer_code  = (select nvl(mro_producer_code, mro_display_producer_code) from mis_producers where mro_entity_reference = ''{field:ENTITY_REFERENCE}''  )
and scs.sco_id = mfo.mfc_contact_id
and sps.spr_producer_id = mfo.mfc_entity_reference
and mfo.mfc_role             =  ''Broker''
union
select ''Name Not Found'' NAME,''Name Not Found'' F_NAME,null M_NAME,null L_NAME,
'' '' AGENT_CODE,
null CONTACT_id
from DUAL)
where 1=1
','N','Producer Name Lookup','','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

  
  
 v_return := k_pct_management_new.f_set_lookup_headings('',p_id,k_pct_management_new.f_get_query_id('PRODUCER_NAME_LOOKUP'),'F_NAME','S','First Name','First name','1','','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_lookup_headings('',p_id,k_pct_management_new.f_get_query_id('PRODUCER_NAME_LOOKUP'),'M_NAME','S','Middle Name','Middle Name','2','','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_lookup_headings('',p_id,k_pct_management_new.f_get_query_id('PRODUCER_NAME_LOOKUP'),'L_NAME','S','Last Name','LAST NAME','3','','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

v_return := k_pct_management_new.f_set_lookup_headings('',p_id,k_pct_management_new.f_get_query_id('PRODUCER_NAME_LOOKUP'),'SUB_AGENT_CODE','S','Sub Agent Code','Sub Agent Code','4','','admin@cover-all.com','Y',p_error);  
    IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;
  
  
    v_return := k_pct_management_new.f_set_primitive('',p_id,'Producer Name Label','STRING','250','','Label','TEXTFIELD','','', k_pct_management_new.f_get_query_id(''),'','','','','','','admin@cover-all.com','Y',p_error);
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

  
    v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('Insured',''),p_id,'INSURED_PRODUCER',k_pct_management_new.f_get_object_id('Insured'),k_pct_management_new.f_get_primitive_id(''),k_pct_management_new.f_get_object_id('Producer'),NULL,'INSURED_PRODUCER','NA','','','','','Agency','N','N','Y','','100','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'Y','','','','','','','','','N','Y','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;
  
   v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('PRODUCER',''),p_id,'PRODUCER_NAME',k_pct_management_new.f_get_object_id('PRODUCER'),k_pct_management_new.f_get_primitive_id('Short Description'),k_pct_management_new.f_get_object_id(''),NULL,'PRODUCER_NAME','NA','','','','','Producer Name','Y','N','Y','','270','',k_pct_management_new.f_get_query_id('PRODUCER_NAME_LOOKUP'),'NSK-COM-0005','N','N',NULL,'Y','Y','N','','','','','','','N','N','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','L_NAME','ASC','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

  v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('PRODUCER',''),p_id,'AGENCY_CONTACT',k_pct_management_new.f_get_object_id('PRODUCER'),k_pct_management_new.f_get_primitive_id('Long Description'),k_pct_management_new.f_get_object_id(''),NULL,'AGENCY_CONTACT','NA','','','','','Agency Contact','Y','N','Y','','280','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'Y','','','','','','','','','N','N','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;
  
  v_return := k_pct_management_new.f_set_object_field('',k_pct_management_new.f_get_object_field_id('PRODUCER',''),p_id,'PRODUCER_CONTACT_ID',k_pct_management_new.f_get_object_id('PRODUCER'),k_pct_management_new.f_get_primitive_id('Insured GID'),k_pct_management_new.f_get_object_id(''),NULL,'PRODUCER_CONTACT_ID','NA','','','','','','N','Y','Y','','290','',k_pct_management_new.f_get_query_id(''),'','N','N',NULL,'Y','','','','','','','','','N','N','N','N','','',k_pct_management_new.f_get_query_id(''),'','N','N','','','','N','','','','','admin@cover-all.com','Y',p_error,'','','','',k_pct_management_new.f_get_query_id(''),'','',k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),k_pct_management_new.f_get_query_id(''),'','','','','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
  
  
   v_return := k_pct_management_new.f_set_criteria('',p_id,'NSK-COM-0004','1','','','param:ENTITY_TYPE','=','''INSURED''','','','admin@cover-all.com','Y',p_error);
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

  v_return := k_pct_management_new.f_set_criteria('',p_id,'NSK-COM-0005','1','','(UPPER(','NAME',') LIKE UPPER(','field:PRODUCER_NAME',')','OR','admin@cover-all.com','Y',p_error);
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

  v_return := k_pct_management_new.f_set_criteria('',p_id,'NSK-COM-0005','2','','','field:PRODUCER_NAME','IS','NULL',')','','admin@cover-all.com','Y',p_error);
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;
  
  
  v_return := k_pct_management_new.f_set_criteria('',p_id,'NSK-COM-0006','1','','','queryvalue:CHK_SINGLE_AGENT_FOR_AGENCY','=','''Y''','','AND','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'NSK-COM-0006','2','','','field:INSURED_SEARCH_COMPLETE','=','''N''','','AND','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

v_return := k_pct_management_new.f_set_criteria('',p_id,'NSK-COM-0006','3','','','param:ENTITY_TYPE','=','''INSURED''','','','admin@cover-all.com','Y',p_error);  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;
  
    v_return := k_pct_management_new.f_set_object_fields_cust('D',p_id,'SPD-COM-0033',k_pct_management_new.f_get_object_field_id('Insured','INSURED_PRODUCER'),'SE','SPD-COM-0027','','','','Agency','','N','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_PRODUCER'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;
  
  
    v_return := k_pct_management_new.f_set_object_fields_cust('D',p_id,'13111',k_pct_management_new.f_get_object_field_id('Insured','INSURED_PRODUCER'),'SE','SPD-COM-0029','','','','','','Y','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','N','','','','',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_PRODUCER'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'IN(agent_role)','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;
  
  v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'NSK-COM-0012',k_pct_management_new.f_get_object_field_id('PRODUCER','PRODUCER_CODE'),'SE','SPD-COM-0027','','','','','','N','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_PRODUCER'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

  v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'NSK-COM-0013',k_pct_management_new.f_get_object_field_id('PRODUCER','PRODUCER_CODE'),'SE','SPD-COM-0029','','','','','','Y','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','N','','','','',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_PRODUCER'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'IN(agent_role)','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;
  
  
   v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'NSK-COM-0016',k_pct_management_new.f_get_object_field_id('PRODUCER','NAME'),'SE','SPD-COM-0027','','','','','','N','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_PRODUCER'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

  v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'NSK-COM-0017',k_pct_management_new.f_get_object_field_id('PRODUCER','NAME'),'SE','SPD-COM-0029','','','','','','Y','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','N','','','','',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_PRODUCER'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'IN(agent_role)','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;
  
  
  v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'NSK-COM-0042',k_pct_management_new.f_get_object_field_id('PRODUCER','MARKET_MANAGER'),'SE','SPD-COM-0027','','','','','','N','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_PRODUCER'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

  v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'NSK-COM-0043',k_pct_management_new.f_get_object_field_id('PRODUCER','MARKET_MANAGER'),'SE','SPD-COM-0029','','','','','','Y','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','N','','','','',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_PRODUCER'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'IN(agent_role)','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

  v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'NSK-COM-0044',k_pct_management_new.f_get_object_field_id('PRODUCER','PRODUCER_NAME'),'SE','PP-COM-0033','','','','','Y','Y','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_PRODUCER'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

  v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'NSK-COM-0045',k_pct_management_new.f_get_object_field_id('PRODUCER','AGENCY_CONTACT'),'SE','PP-COM-0033','','','','','Y','Y','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_PRODUCER'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;
  
  
  
    v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'NSK-COM-0046',k_pct_management_new.f_get_object_field_id('ADDRESS','LINE_1'),'SE','SPD-COM-0027','','','','','','N','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_PRODUCER'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

  v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'NSK-COM-0047',k_pct_management_new.f_get_object_field_id('ADDRESS','LINE_1'),'SE','SPD-COM-0029','','','','','','Y','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','N','','','','',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_PRODUCER'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'IN(agent_role)','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

  v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'NSK-COM-0048',k_pct_management_new.f_get_object_field_id('ADDRESS','CITY'),'SE','SPD-COM-0027','','','','','','N','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_PRODUCER'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

  v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'NSK-COM-0049',k_pct_management_new.f_get_object_field_id('ADDRESS','CITY'),'SE','SPD-COM-0029','','','','','','Y','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','N','','','','',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_PRODUCER'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'IN(agent_role)','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

  v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'NSK-COM-0050',k_pct_management_new.f_get_object_field_id('ADDRESS','ZIP_CODE'),'SE','SPD-COM-0027','','','','','','N','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_PRODUCER'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

  v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'NSK-COM-0051',k_pct_management_new.f_get_object_field_id('ADDRESS','ZIP_CODE'),'SE','SPD-COM-0029','','','','','','Y','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','N','','','','',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_PRODUCER'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'IN(agent_role)','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

  v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'NSK-COM-0052',k_pct_management_new.f_get_object_field_id('ADDRESS','STATE_DESC'),'SE','SPD-COM-0027','','','','','','N','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_PRODUCER'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

  v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'NSK-COM-0053',k_pct_management_new.f_get_object_field_id('ADDRESS','STATE_DESC'),'SE','SPD-COM-0029','','','','','','Y','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','N','','','','',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_PRODUCER'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'IN(agent_role)','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

  v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'NSK-COM-0054',k_pct_management_new.f_get_object_field_id('ADDRESS','LINE_2'),'SE','SPD-COM-0027','','','','','','N','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_PRODUCER'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

  v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'NSK-COM-0055',k_pct_management_new.f_get_object_field_id('ADDRESS','LINE_2'),'SE','SPD-COM-0029','','','','','','Y','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','N','','','','',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_PRODUCER'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'IN(agent_role)','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

  v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'NSK-COM-0056',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_PRODUCER'),'SE','NSK-COM-0002','','','','','','Y','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_PRODUCER'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

 v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'NSK-COM-0057',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_PRODUCER'),'SE','NSK-COM-0006','','','','','','Y','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','N','','','','',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_PRODUCER'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'IN(agent_role)','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');  
IF v_return <> 0 THEN
  RAISE user_exception;
END IF;

  v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'NSK-COM-0058',k_pct_management_new.f_get_object_field_id('PRODUCER','PRODUCER_NAME'),'SE','NSK-COM-0004','','No Data Found','','','','','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','','','','','',k_pct_management_new.f_get_object_field_id('INSURED','INSURED_PRODUCER'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'IN(allow_risk_clearance_override)','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');
  IF v_return <> 0 THEN
    RAISE user_exception;
  END IF;

  v_return := k_pct_management_new.f_set_object_fields_cust('',p_id,'NSK-COM-0059',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_PRODUCER'),'SE','','','','','','','Y','','','','',k_pct_management_new.f_get_query_id(''),'','','','','','','','','','','','','','','','N','','','','',k_pct_management_new.f_get_object_field_id('POLICY','POLICY_PRODUCER'),'','','','','','','','','','admin@cover-all.com','Y',p_error,'IN(agent_role)','','','','','','','','','','','','','','',k_pct_management_new.f_get_query_id(''),'',NULL,'','','','','','','','','','','N');



k_pct_management_new.g_debug_mode:='N';


EXCEPTION
   WHEN user_exception THEN
       ROLLBACK;
       DBMS_OUTPUT.PUT_LINE('Error is: ' || substr(p_error,1,240));
       DBMS_OUTPUT.PUT_LINE('Return code is: ' || v_return);
       RAISE;
   WHEN OTHERS THEN
       ROLLBACK;
       DBMS_OUTPUT.PUT_LINE('Error is: ' || substr(p_error,1,240));
       DBMS_OUTPUT.PUT_LINE('Return code is: ' || v_return);
       RAISE;
END;
/
set escape off;


