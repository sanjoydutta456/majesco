PROMPT
PROMPT ==============================================
PROMPT Executing install_mic_policy.sql
PROMPT ==============================================
SET VERIFY OFF
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
WHENEVER OSERROR EXIT OSCODE

DEFINE indextbsp=&1
DEFINE customercode=&2

@@mic_policy.tab
@@mic_policy.con
@@mic_policy.seq
@@mic_policy.typ
@@mic_policy.prc
@@mic_policy.vw
@@mic_policy_bi.vw
@@mic_policy.trg
SET DEFINE ON
@@mic_policy.ind

PROMPT =====================================
PROMPT 
EXIT SUCCESS