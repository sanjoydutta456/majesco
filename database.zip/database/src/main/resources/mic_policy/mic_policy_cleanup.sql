PROMPT
PROMPT ==============================================
PROMPT Executing mic_policy_cleanup.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
EXIT