PROMPT
PROMPT ==============================================
PROMPT Executing mic_policy_cont_post.sql from install path
PROMPT ==============================================

SET VERIFY OFF
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
WHENEVER OSERROR EXIT OSCODE

DEFINE mic_policy_user=&1
DEFINE customercode=&2

PROMPT *** drop table MIS_QUOTE_POLICIES ***
DECLARE
	vtable		user_tables.table_name%TYPE;
	v_count		NUMBER;
	v_record_count NUMBER;
BEGIN
	vtable	:= upper('MIS_QUOTE_POLICIES');
	SELECT count(*) INTO v_count FROM user_tables
		WHERE table_name = UPPER(vtable);
	IF v_count > 0 then
	
	SELECT count(*) INTO v_record_count FROM mis_quote_policies;
	IF v_record_count > 0 THEN
		dbms_output.put_line('*** Can not drop table MIS_QUOTE_POLICIES as it''s not empty');
		
	ELSE
		SELECT count(*) INTO v_count FROM user_tab_columns
		WHERE table_name = UPPER(vtable)
		AND   column_name = UPPER('MQP_INSTALLER_CREATED');
		
		IF v_count > 0 then
			select count(*) into v_count from user_views
			where view_name = 'EV_MIS_QUOTE_POLICIES';
			IF v_count > 0 then
				dbms_output.put_line('*** drop view : EV_MIS_QUOTE_POLICIES');
				EXECUTE IMMEDIATE 'drop view EV_MIS_QUOTE_POLICIES';
			END IF;
			
			select count(*) into v_count from user_views
			where view_name = 'VW_MIS_QUOTE_POLICIES';
			IF v_count > 0 then
				dbms_output.put_line('*** drop view : VW_MIS_QUOTE_POLICIES');
				EXECUTE IMMEDIATE 'drop view VW_MIS_QUOTE_POLICIES';
			END IF;
			
			dbms_output.put_line('*** drop table MIS_QUOTE_POLICIES');
			EXECUTE IMMEDIATE 'drop table MIS_QUOTE_POLICIES';
		END IF;
	END IF;
	END IF;
END;
/	
========
PROMPT

UNDEFINE mic_policy_user
UNDEFINE customercode

EXIT SUCCESS
