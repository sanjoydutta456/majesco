PROMPT
PROMPT ==============================================
PROMPT Executing script_renaming_changes.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 