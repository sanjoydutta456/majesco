PROMPT
PROMPT ==============================================
PROMPT Executing create_mic_policyd_user.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
EXIT