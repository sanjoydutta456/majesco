PROMPT
PROMPT ==============================================
PROMPT Executing create_mic_repository_user.sql
PROMPT ==============================================


PROMPT =====================================
PROMPT 
EXIT SUCCESS
