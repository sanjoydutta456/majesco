PROMPT
PROMPT ==============================================
PROMPT Executing install_mic_repository.sql
PROMPT ==============================================

SET VERIFY OFF
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
WHENEVER OSERROR EXIT OSCODE

DEFINE indextbsp=&1
DEFINE customercode=&2

@@mic_repository.tab
@@mic_repository.con
@@mic_repository.ind
@@mic_repository.seq
@@mic_repository.prc
@@mic_repository.vw
@@mic_repository.trg

PROMPT =====================================
PROMPT 
EXIT SUCCESS