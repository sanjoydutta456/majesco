#!/bin/bash

##  Eric Beuscher
##  install_mic_user.sh

## Change the current directory to where the batch script exists
olddir=`pwd`
shdir=`dirname $0`
cd $shdir

trap 'onexit' EXIT

function onexit() {
    cd $olddir
}

echo "====================="
echo "Preparing environment"
echo "====================="
envfile=$shdir/setCustomerDatabaseEnv.sh
## Checking Environment scripts exist or not
if [ ! -e $envfile ]; then
    echo "ERROR: $envfile does not exist"
    exit 1;
fi
source $envfile

## Create a temporary subdirectory in case it's missing
tmpdir=$INSTALL_PATH/logs/MIC_Logs    
if [ ! -d $tmpdir ]; then
    mkdir $tmpdir
fi

if [ ! -x "$SQLPLUS_BIN" ]; then
    SQLPLUS_BIN=$INSTALLER_SQL_CLIENT_HOME
fi

export ORACLE_HOME=$SQLPLUS_BIN
export LD_LIBRARY_PATH=$ORACLE_HOME
export PATH=$PATH:$ORACLE_HOME

errorlog=$tmpdir
## Change the LOCAL to use the supplied connect string

TWO_TASK=$MICConnectString

echo "Creating MIC database objects"
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_common.syn $MICCommonUserName >> $errorlog/install_mic_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_common.syn"
    exit 1
fi

echo "mic_crm.syn"
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_crm.syn $MICCRMUserName >> $errorlog/install_mic_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_crm.syn"
    exit 1
fi

echo "mic_policyd.syn"
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_policyd.syn $MICPolicydUserName >> $errorlog/install_mic_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_policyd.syn"
    exit 1
fi

echo "mic_policy.syn"
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_policy.syn $MICPolicyUserName >> $errorlog/install_mic_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_policy.syn"
    exit 1
fi

echo "mic_messaging.syn"
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_messaging.syn $MICMessagingUserName >> $errorlog/install_mic_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_messaging.syn"
    exit 1
fi

echo "mic_repository.syn"
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_repository.syn $MICRepositoryUserName >> $errorlog/install_mic_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_repository.syn"
    exit 1
fi

echo "mic_billing.syn"
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_billing.syn $MICBillingUserName >> $errorlog/install_mic_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_billing.syn"
    exit 1
fi

echo "mic_claim.syn"
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_claim.syn $MICClaimUserName >> $errorlog/install_mic_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_claim.syn"
    exit 1
fi

echo "tiles.syn"
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @tiles.syn $TILESUserName >> $errorlog/install_mic_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @tiles.syn"
    exit 1
fi

echo "site.syn"
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @site.syn $SITEUserName >> $errorlog/install_mic_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @site.syn"
    exit 1
fi


echo "**"
echo "MIC user synonymns are installed successfully. "
echo "Logfiles are created in $TEMP/MIC_Logs"
echo "."
