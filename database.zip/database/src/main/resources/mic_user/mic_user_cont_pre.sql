PROMPT
PROMPT ========================================
PROMPT Executing mic_user_cont_pre.sql from install path
PROMPT =======================================
DEFINE mic_policy_user=&1

PROMPT ***Creating Synonym For MIC_POLICY database objects***
create or replace synonym EV_MIS_QUOTE_POLICIES for &&MIC_POLICY_USER..EV_MIS_QUOTE_POLICIES;

PROMPT ===========================
PROMPT 

UNDEFINE mic_policy_user

EXIT SUCCESS