PROMPT
PROMPT ==============================================
PROMPT Executing install_mic_policy.sql
PROMPT FILE NOT IN USE, SO HARDCODING OF PASSWORDS NOT REMOVED
PROMPT ==============================================

SET VERIFY OFF
SET SERVEROUTPUT ON SIZE 1000000
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
WHENEVER OSERROR EXIT OSCODE

PROMPT ***
PROMPT 1==the_sid ... 2==customercode ... 3==customerdomain
PROMPT ***
DEFINE the_db=&1
DEFINE customercode=&2
DEFINE customerdomain=&3
DEFINE indextbsp=IIPD
DEFINE mic_policy_user=mic_policy_&&customercode
DEFINE mic_policy_password=mic_policy_&&customercode

PROMPT ====================================
PROMPT ===== show for substitutions
PROMPT ====================================
PROMPT the_db : &&the_db
PROMPT customercode : &&customercode
PROMPT customerdomain : &&customerdomain
PROMPT indextbsp : &&indextbsp
PROMPT mic_policy_user : &&mic_policy_user
PROMPT mic_policy_password : &&mic_policy_password
PROMPT ====================================

-- first because ONLY ROWRANK.sql function there
--      ROWRANK used for index build

--PROMPT ***
--PROMPT *** execute policy_studio/mic_policy.prc
--PROMPT ***
--@@mic_policy.prc

--PROMPT ***
--PROMPT *** execute policy_studio/mic_policy.tab
--PROMPT ***
--@@mic_policy.tab

PROMPT ***
PROMPT *** execute policy_studio/mic_policy.ind
PROMPT ***
@@mic_policy.ind

PROMPT ***
PROMPT *** execute policy_studio/mic_policy.con
PROMPT ***
@@mic_policy.con

--PROMPT ***
--PROMPT *** execute policy_studio/mic_policy.grt
--PROMPT ***
--@@mic_policy.grt &&customercode

-- DAT should be run separately and not with this script
--PROMPT ***
--PROMPT *** execute policy_studio/mic_policy.dat
--PROMPT ***
-- @@mic_policy.dat &&customercode &&customerdomain

--PROMPT ***
--PROMPT *** execute policy_studio/mic_policy.vw
--PROMPT ***
--@@mic_policy.vw

--PROMPT ***
--PROMPT *** execute policy_studio/mic_policy.trg
--PROMPT ***
--@@mic_policy.trg


--PROMPT ***
--PROMPT *** log on as mic_&&customercode
--PROMPT ***

-- for when connect string needed
--connect mic_&&customercode/mic_&&customercode@&&the_db

-- for when connect string NOT needed
--connect mic_&&customercode/mic_&&customercode

--PROMPT ***
--PROMPT *** execute policy_studio/mic_policy.syn as mic_&&customercode
--PROMPT *** NOT in mic_user directory
--PROMPT ***
--@@mic_policy.syn

PROMPT =====================================
PROMPT
EXIT SUCCESS