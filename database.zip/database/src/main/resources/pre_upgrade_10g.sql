PROMPT
PROMPT ==============================================
PROMPT Executing pre_upgrade_10g.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
EXIT