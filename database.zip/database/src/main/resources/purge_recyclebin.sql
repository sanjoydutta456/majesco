PROMPT
PROMPT ==============================
PROMPT Executing purge_recyclebin.sql
PROMPT ==============================

SET VERIFY OFF
WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR EXIT SQL.OSCODE

PURGE RECYCLEBIN;

PROMPT =====================================
PROMPT 
EXIT SUCCESS
