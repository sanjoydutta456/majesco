#!/bin/bash

##  Eric Beuscher
##  setCommonDatabaseEnv.sh

export MICConnectString='${oracle.system.tns.alias}'
export TWO_TASK=${oracle.system.sid}
export MICSystemUsername=${oracle.system.username}
export MICSystemPassword=${oracle.system.password}
export MICSysPassword=${oracle.sys.password}
export MICAdminUserName=${schema.mic_admin.username}
export MICAdminPassword=${schema.mic_admin.password}
export MICAdminDataTablespace=${schema.mic_admin.data.tablespace}
export MICAdminIndexTablespace=${schema.mic_admin.index.tablespace}
export MICMessagingUserName=${schema.mic_messaging.username}
export MICMessagingPassword=${schema.mic_messaging.password}
export MICMessagingDataTablespace=${schema.mic_messaging.data.tablespace}
export MICMessagingIndexTablespace=${schema.mic_messaging.index.tablespace}
export IsForceSiteRefresh=${force.site.refresh}
export MICImagingUserName=${imaging.ifs.schema.username}
export MICImagingPassword=${imaging.ifs.schema.password}
