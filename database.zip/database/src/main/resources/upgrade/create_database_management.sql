PROMPT
PROMPT =====================================================
PROMPT Executing create_database_management.sql
PROMPT =====================================================

--
-- to be executed as system
--
SET VERIFY OFF
WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR EXIT SQL.OSCODE

SET SERVEROUTPUT ON SIZE 1000000

-- no longer needed but keeping for substitutions if needed
PROMPT **** 1 == micsystempassword
DEFINE micsystempassword=&1

PROMPT *** drop synonym ... if it already exists
DECLARE
	v_package VARCHAR2(32) := 'K_DATABASE_MANAGEMENT';
	v_sql	varchar2(250);
	v_err	number;
	v_msg	varchar2(100);
BEGIN
FOR ss IN (
	SELECT owner, synonym_name FROM all_synonyms
	WHERE synonym_name = v_package
	)
LOOP
	IF ss.owner = 'PUBLIC' THEN
		v_sql := 'DROP PUBLIC SYNONYM ' || ss.synonym_name;
	ELSE
		v_sql := 'DROP SYNONYM ' || ss.owner || '.' || ss.synonym_name;
	END IF;
	dbms_output.put_line('sql: ' || v_sql );
	EXECUTE IMMEDIATE v_sql;
END LOOP;
--
EXCEPTION
	WHEN OTHERS THEN
        v_err := SQLCODE;
        v_msg := SUBSTR(SQLERRM, 1, 100);
        dbms_output.put_line('ERROR: ' || v_err || ' : ' || v_msg);
        RAISE;
END;
/

PROMPT *** for users ... other than super user
PROMPT *** drop spurious package k_database_management
DECLARE
    v_sql VARCHAR2(250);
    v_package VARCHAR2(32) := 'K_DATABASE_MANAGEMENT';
    v_count NUMBER := 0;
BEGIN
DBMS_OUTPUT.PUT_LINE( 'starting ... drop k_database_manapackages');
FOR s IN (
    SELECT DISTINCT owner, object_name, object_type, status
    FROM dba_objects
    WHERE object_name = v_package
      AND object_type = 'PACKAGE'
      AND owner != user
) LOOP
    v_count := v_count + 1;
    v_sql := 'drop package ' || s.owner || '.' || s.object_name;
    DBMS_OUTPUT.PUT_LINE( 'found extra package: ' || s.owner || ' : ' || s.object_type || ' : ' || s.status );
    DBMS_OUTPUT.PUT_LINE( 'sql: ' || v_sql );
    EXECUTE IMMEDIATE v_sql;
END LOOP;
DBMS_OUTPUT.PUT_LINE( 'dropped packages: ' || v_count || '    complete' );
END;
/

Prompt ***Creating Package Specification***
CREATE OR REPLACE PACKAGE k_database_management AUTHID CURRENT_USER AS

  FUNCTION version RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES ( version,WNDS,RNDS,WNPS,RNPS  );

/** Returns specified table, index, synonym exists or not in the schema **/
  FUNCTION object_exists ( ip_object_name IN user_objects.object_name%TYPE,
                           ip_object_type IN user_objects.object_type%TYPE)
  RETURN BOOLEAN;

/** Returns specified column exists or not in the table **/
  FUNCTION column_exists ( ip_table_name IN user_tab_columns.table_name%TYPE,
                           ip_column_name IN user_tab_columns.column_name%TYPE)
  RETURN BOOLEAN;

/** Returns specified constraint exists or not in the schema **/
  FUNCTION constraint_exists ( ip_constraint_name IN user_constraints.constraint_name%TYPE)
  RETURN BOOLEAN;

/** Returns specified constraint exists or not in the schema **/
  FUNCTION constraint_exists ( ip_constraint_name IN user_constraints.constraint_name%TYPE,
                               ip_table_name IN user_constraints.table_name%TYPE)
  RETURN BOOLEAN;

/** Function takes constraint_name, and a column_name and returns true if a constraint exists with that column in the table **/
  FUNCTION constraint_column_exists ( ip_constraint_name IN user_constraints.constraint_name%TYPE,
                                      ip_column_name     IN user_cons_columns.column_name%TYPE)
  RETURN BOOLEAN;

/** Returns row exists or not in the table using unique/primary key column and its values given **/
  FUNCTION row_exists ( ip_table_name IN VARCHAR2,
                        ip_key_column_1 IN VARCHAR2,
                        ip_key_value_1  IN VARCHAR2,
                        ip_key_column_2 IN VARCHAR2 DEFAULT NULL,
                        ip_key_value_2  IN VARCHAR2 DEFAULT NULL,
                        ip_key_column_3 IN VARCHAR2 DEFAULT NULL,
                        ip_key_value_3  IN VARCHAR2 DEFAULT NULL,
                        ip_key_column_4 IN VARCHAR2 DEFAULT NULL,
                        ip_key_value_4  IN VARCHAR2 DEFAULT NULL,
                        ip_key_column_5 IN VARCHAR2 DEFAULT NULL,
                        ip_key_value_5  IN VARCHAR2 DEFAULT NULL,
                        ip_key_column_6 IN VARCHAR2 DEFAULT NULL,
                        ip_key_value_6  IN VARCHAR2 DEFAULT NULL,
                        ip_key_column_7 IN VARCHAR2 DEFAULT NULL,
                        ip_key_value_7  IN VARCHAR2 DEFAULT NULL)
  RETURN BOOLEAN;

/** Returns datatype of the specified column in a table **/
    FUNCTION f_get_data_type(ip_table_name  IN VARCHAR2,
                             ip_column_name IN VARCHAR2)
    RETURN VARCHAR2;

/** Returns false if the index does not exist,
            false if uniqueness is not correct
            false if total number of index columns is incorrect
            false if order of the index columns is not correct **/
  FUNCTION index_exists (ip_index_name IN VARCHAR2,
                         ip_uniqueness IN VARCHAR2,
                         ip_total_no_of_columns IN NUMBER,
                         ip_key_column_1 IN VARCHAR2,
                         ip_key_column_2 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_3 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_4 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_5 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_6 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_7 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_8 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_9 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_10 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_11 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_12 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_13 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_14 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_15 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_16 IN VARCHAR2 DEFAULT NULL)
  RETURN BOOLEAN;



/** Returns true if the package and package body are both compiled
            false otherwise **/
  FUNCTION package_compiled (
      p_package_name IN user_objects.object_name%TYPE
  ) RETURN BOOLEAN;

/*
   k_drop_constraint
   if constraint dropped and/or extra indexes dropped
      returns true
   otherwise returns false
*/
FUNCTION k_drop_constraint ( p_constraint_name user_constraints.constraint_name%TYPE )
RETURN BOOLEAN;

/*
   procedure k_table_add_field
      adds a column to a table
         optionally disables/enables constraints
         for the table
      outputs appropriate messages
*/
PROCEDURE k_table_add_field ( ptriggers BOOLEAN,
   ptable VARCHAR2, pfield VARCHAR2, psql VARCHAR2, pmsg VARCHAR2 );
/*
    add a standard sequence named p_sequence_name
    start with 1
    increment by 1
    nominvalue
    nomaxvalue
    nocycle
    nocache
*/
PROCEDURE k_add_std_sequence ( p_sequence_name user_sequences.sequence_name%TYPE);
/*
*/
PROCEDURE k_cleanup_tbl_synonym ( ptable user_synonyms.table_name%TYPE );
/*
    procedure: k_cleanup_tbl_synonym
    if an orphaned synonym exists ... drop it
    use prior to a table create to eliminate possible object already exists
    eg.
    if NOT (table X exists) then
        k_database_managemnent.k_cleanup_tbl_synonym( X );
        execute immediate ' create table X
        ...
*/
END;
/

show errors

Prompt ***Creating Package Body***
CREATE OR REPLACE PACKAGE BODY k_database_management AS

-------------------------------------- FUNCTION version

FUNCTION version RETURN VARCHAR2 IS
BEGIN
  RETURN '$Revision:   1.54  $';
END;

-----------------------------------------------------FUNCTION object_exists
--Function takes object name,object type and returns true if the object exists in the schema
FUNCTION object_exists ( ip_object_name IN user_objects.object_name%TYPE,
                         ip_object_type IN user_objects.object_type%TYPE)
RETURN BOOLEAN IS

  CURSOR csr_object_name IS
  SELECT object_name
    FROM user_objects
   WHERE object_name = UPPER(ip_object_name)
     AND object_type = UPPER(ip_object_type);

  v_object_name user_objects.object_name%TYPE;

BEGIN

  OPEN csr_object_name;
  FETCH csr_object_name INTO v_object_name;
  IF csr_object_name%NOTFOUND OR v_object_name IS NULL THEN
      CLOSE csr_object_name;
      RETURN FALSE;
  ELSE
      CLOSE csr_object_name;
      RETURN TRUE;
  END IF;

EXCEPTION
  WHEN others THEN
      RAISE_APPLICATION_ERROR ( -20000, 'Error accessing user_objects table', TRUE );
      RETURN FALSE;
END;

-----------------------------------------------------FUNCTION column_exists
--Function takes table_name, column_name and returns true if the column exists in the table
FUNCTION column_exists ( ip_table_name IN user_tab_columns.table_name%TYPE,
                         ip_column_name IN user_tab_columns.column_name%TYPE)
RETURN BOOLEAN IS

  CURSOR csr_column_name IS
  SELECT column_name
    FROM user_tab_columns
   WHERE table_name = UPPER(ip_table_name)
     AND column_name = UPPER(ip_column_name);

  v_column_name user_objects.object_name%TYPE;

BEGIN

  OPEN csr_column_name;
  FETCH csr_column_name INTO v_column_name;
  IF csr_column_name%NOTFOUND OR v_column_name IS NULL THEN
      CLOSE csr_column_name;
      RETURN FALSE;
  ELSE
      CLOSE csr_column_name;
      RETURN TRUE;
  END IF;

EXCEPTION
  WHEN others THEN
      RAISE_APPLICATION_ERROR ( -20000, 'Error accessing user_tab_columns table', TRUE );
      RETURN FALSE;
END;

-----------------------------------------------------FUNCTION constraint_exists
--Function takes constraint_name and returns true if the constraint exists in the table
FUNCTION constraint_exists ( ip_constraint_name IN user_constraints.constraint_name%TYPE)
RETURN BOOLEAN IS

  CURSOR csr_constraint_name IS
  SELECT constraint_name
    FROM user_constraints
   WHERE constraint_name = UPPER(ip_constraint_name);

  v_constraint_name user_constraints.constraint_name%TYPE;

BEGIN

  OPEN csr_constraint_name;
  FETCH csr_constraint_name INTO v_constraint_name;
  IF csr_constraint_name%NOTFOUND OR v_constraint_name IS NULL THEN
      CLOSE csr_constraint_name;
      RETURN FALSE;
  ELSE
      CLOSE csr_constraint_name;
      RETURN TRUE;
  END IF;

EXCEPTION
  WHEN others THEN
      RAISE_APPLICATION_ERROR ( -20000, 'Error accessing user_constraints table', TRUE );
      RETURN FALSE;
END;

-----------------------------------------------------FUNCTION constraint_exists
--Function takes constraint_name and returns true if the constraint exists in the table
FUNCTION constraint_exists ( ip_constraint_name IN user_constraints.constraint_name%TYPE,
                             ip_table_name IN user_constraints.table_name%TYPE)
RETURN BOOLEAN IS

  CURSOR csr_constraint_name IS
  SELECT constraint_name
    FROM user_constraints
   WHERE constraint_name = UPPER(ip_constraint_name)
     AND table_name = UPPER(ip_table_name);

  v_constraint_name user_constraints.constraint_name%TYPE;

BEGIN

  OPEN csr_constraint_name;
  FETCH csr_constraint_name INTO v_constraint_name;
  IF csr_constraint_name%NOTFOUND OR v_constraint_name IS NULL THEN
      CLOSE csr_constraint_name;
      RETURN FALSE;
  ELSE
      CLOSE csr_constraint_name;
      RETURN TRUE;
  END IF;

EXCEPTION
  WHEN others THEN
      RAISE_APPLICATION_ERROR ( -20000, 'Error accessing user_constraints table', TRUE );
      RETURN FALSE;
END;

-----------------------------------------------------FUNCTION constraint_column_exists
--Function takes constraint_name, and a column_name and returns true if a constraint exists with that column in the table
FUNCTION constraint_column_exists ( ip_constraint_name IN user_constraints.constraint_name%TYPE,
                                    ip_column_name     IN user_cons_columns.column_name%TYPE)
RETURN BOOLEAN IS

  v_count NUMBER;

BEGIN
  SELECT COUNT(*)
  INTO v_count
  FROM user_cons_columns
  WHERE constraint_name = UPPER(ip_constraint_name)
    AND column_name = UPPER(ip_column_name);

  IF v_count > 0 THEN
      RETURN TRUE;
  ELSE
      RETURN FALSE;
  END IF;

EXCEPTION
  WHEN others THEN
      RAISE_APPLICATION_ERROR ( -20000, 'Error accessing user_cons_columns table', TRUE );
      RETURN FALSE;
END;


--------------------------------------------------------FUNCTION row_exists
--Function takes a table name, column(s) and value and returns true if the row exists
FUNCTION row_exists ( ip_table_name IN VARCHAR2,
                      ip_key_column_1 IN VARCHAR2,
                      ip_key_value_1  IN VARCHAR2,
                      ip_key_column_2 IN VARCHAR2 DEFAULT NULL,
                      ip_key_value_2  IN VARCHAR2 DEFAULT NULL,
                      ip_key_column_3 IN VARCHAR2 DEFAULT NULL,
                      ip_key_value_3  IN VARCHAR2 DEFAULT NULL,
                      ip_key_column_4 IN VARCHAR2 DEFAULT NULL,
                      ip_key_value_4  IN VARCHAR2 DEFAULT NULL,
                      ip_key_column_5 IN VARCHAR2 DEFAULT NULL,
                      ip_key_value_5  IN VARCHAR2 DEFAULT NULL,
                      ip_key_column_6 IN VARCHAR2 DEFAULT NULL,
                      ip_key_value_6  IN VARCHAR2 DEFAULT NULL,
                      ip_key_column_7 IN VARCHAR2 DEFAULT NULL,
                      ip_key_value_7  IN VARCHAR2 DEFAULT NULL)
RETURN BOOLEAN IS


  v_sql_statement varchar2(2000);
  TYPE v_cursor_type IS REF CURSOR;
  v_ref_cursor v_cursor_type;

  TYPE rowexistsrec IS RECORD (
  row_exists varchar2(3));

  v_row_exists rowexistsrec;

BEGIN

  v_sql_statement:= 'SELECT ''Y'' value1 FROM '||ip_table_name||' WHERE ';
  v_sql_statement := v_sql_statement||ip_key_column_1||' = '||''''||ip_key_value_1||'''';
  IF ip_key_column_2 IS NOT NULL THEN
        IF ip_key_value_2 Is not null THEN
        v_sql_statement := v_sql_statement||'AND '||ip_key_column_2||' = '||''''||ip_key_value_2||'''';
            ELSE
        v_sql_statement := v_sql_statement||'AND '||ip_key_column_2||' IS NULL ';
            END IF;
  END IF;
  IF ip_key_column_3 IS NOT NULL THEN
        IF ip_key_value_3 Is not null THEN
          v_sql_statement := v_sql_statement||'AND '||ip_key_column_3||' = '||''''||ip_key_value_3||'''';
            ELSE
        v_sql_statement := v_sql_statement||'AND '||ip_key_column_3||' IS NULL ';
            END IF;
  END IF;
  IF ip_key_column_4 IS NOT NULL THEN
        IF ip_key_value_4 Is not null THEN
          v_sql_statement := v_sql_statement||'AND '||ip_key_column_4||' = '||''''||ip_key_value_4||'''';
            ELSE
        v_sql_statement := v_sql_statement||'AND '||ip_key_column_4||' IS NULL ';
            END IF;
  END IF;
  IF ip_key_column_5 IS NOT NULL THEN
        IF ip_key_value_5 Is not null THEN
          v_sql_statement := v_sql_statement||'AND '||ip_key_column_5||' = '||''''||ip_key_value_5||'''';
            ELSE
        v_sql_statement := v_sql_statement||'AND '||ip_key_column_5||' IS NULL ';
            END IF;
  END IF;
  IF ip_key_column_6 IS NOT NULL THEN
        IF ip_key_value_6 Is not null THEN
            v_sql_statement := v_sql_statement||'AND '||ip_key_column_6||' = '||''''||ip_key_value_6||'''';
            ELSE
        v_sql_statement := v_sql_statement||'AND '||ip_key_column_6||' IS NULL ';
            END IF;
    END IF;
  IF ip_key_column_7 IS NOT NULL THEN
        IF ip_key_value_7 Is not null THEN
          v_sql_statement := v_sql_statement||'AND '||ip_key_column_7||' = '||''''||ip_key_value_7||'''';
            ELSE
        v_sql_statement := v_sql_statement||'AND '||ip_key_column_7||' IS NULL ';
            END IF;
  END IF;

 -- v_sql_statement := v_sql_statement||';';

  --dbms_output.put_line('sql statement := '||v_sql_statement);

  OPEN v_ref_cursor FOR v_sql_statement;
  LOOP
  FETCH v_ref_cursor INTO v_row_exists;
  exit when v_ref_cursor%NOTFOUND;

  END LOOP;
  IF v_row_exists.row_exists = 'Y' THEN
     CLOSE v_ref_cursor;
     RETURN TRUE;
  ELSE
     CLOSE v_ref_cursor;
     RETURN FALSE;
  END IF;

EXCEPTION

  WHEN OTHERS THEN
    dbms_output.put_line('Error : '||substr(sqlerrm,1,120));
    RETURN FALSE;
END;

--Function takes a table name, column name and returns data type of the column
--------------------------------------------------------FUNCTION f_get_data_type

FUNCTION f_get_data_type(ip_table_name  IN VARCHAR2,
                                     ip_column_name IN VARCHAR2)
RETURN VARCHAR2 IS

  CURSOR csr_data_type IS
  SELECT data_type
    FROM user_tab_columns
   WHERE table_name = upper(ip_table_name)
     AND column_name = upper(ip_column_name);

  v_data_type user_tab_columns.data_type%TYPE;

BEGIN

  OPEN csr_data_type;
  FETCH csr_data_type INTO v_data_type;
  CLOSE csr_data_type;
  RETURN v_data_type;

EXCEPTION
  WHEN others THEN
      RAISE_APPLICATION_ERROR ( -20000, 'Error accessing user_tab_columns table', TRUE );
      RETURN v_data_type;
END;

--Function takes a index name, index columns and uniqueness and returns false if
--index is not found or index column are not in the right order
----------------------------------------------------------------index_exists
  FUNCTION index_exists (ip_index_name IN VARCHAR2,
                         ip_uniqueness IN VARCHAR2,
                         ip_total_no_of_columns IN NUMBER,
                         ip_key_column_1 IN VARCHAR2,
                         ip_key_column_2 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_3 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_4 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_5 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_6 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_7 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_8 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_9 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_10 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_11 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_12 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_13 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_14 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_15 IN VARCHAR2 DEFAULT NULL,
                         ip_key_column_16 IN VARCHAR2 DEFAULT NULL)
  RETURN BOOLEAN IS

  CURSOR csr_ind_columns IS
  SELECT column_name,column_position
    FROM user_ind_columns
   WHERE index_name = UPPER(ip_index_name)
  ORDER BY column_position;

   CURSOR csr_ind_expressions IS
    SELECT column_expression,column_position
      FROM user_ind_expressions
     WHERE index_name = UPPER(ip_index_name)
  ORDER BY column_position;

  v_column_name     user_ind_columns.column_name%TYPE;
  v_column_position user_ind_columns.column_position%TYPE;
  v_total_no_of_columns NUMBER;
  v_sqlstmt VARCHAR2(500);
  v_uniqueness VARCHAR2(30);
  v_function_index VARCHAR2(20);

BEGIN

  OPEN csr_ind_columns;
  FETCH csr_ind_columns INTO v_column_name,v_column_position;
  IF csr_ind_columns%NOTFOUND THEN
     CLOSE csr_ind_columns;
     RETURN FALSE;
  ELSE
    CLOSE csr_ind_columns;

    v_sqlstmt := 'DROP INDEX '||ip_index_name;
    SELECT uniqueness,funcidx_status
      INTO v_uniqueness,v_function_index
      FROM user_indexes
     WHERE index_name = UPPER(ip_index_name);

    IF v_uniqueness != UPPER(ip_uniqueness) THEN
        EXECUTE IMMEDIATE v_sqlstmt;
      RETURN FALSE;
    END IF;

    v_total_no_of_columns := 0;
    SELECT count(*)
      INTO v_total_no_of_columns
      FROM user_ind_columns
     WHERE index_name = UPPER(ip_index_name);

     IF v_total_no_of_columns != ip_total_no_of_columns THEN
       EXECUTE IMMEDIATE v_sqlstmt;
        RETURN FALSE;
     ELSE
        FOR rec IN csr_ind_columns LOOP
          IF rec.column_position = 1 AND rec.column_name != upper(ip_key_column_1) THEN
            IF v_function_index='ENABLED' THEN
               FOR rec_ind_expressions IN csr_ind_expressions LOOP
                 IF rec_ind_expressions.column_position=1 AND rec_ind_expressions.column_expression != UPPER(ip_key_column_1) THEN
                    EXECUTE IMMEDIATE v_sqlstmt;
                    RETURN FALSE;
                 END IF;
               END LOOP;
            ELSE
              EXECUTE IMMEDIATE v_sqlstmt;
              RETURN FALSE;
            END IF;
          ELSIF rec.column_position = 2 AND rec.column_name != upper(ip_key_column_2) THEN
            IF v_function_index='ENABLED' THEN
               dbms_output.put_line('function index check');
               FOR rec_ind_expressions IN csr_ind_expressions LOOP
                 IF rec_ind_expressions.column_position=2 AND rec_ind_expressions.column_expression != UPPER(ip_key_column_2) THEN
                    dbms_output.put_line('condition does not match');
                    EXECUTE IMMEDIATE v_sqlstmt;
                    RETURN FALSE;
                 END IF;
               END LOOP;
            ELSE
              EXECUTE IMMEDIATE v_sqlstmt;
              RETURN FALSE;
            END IF;
          ELSIF rec.column_position = 3 AND rec.column_name != upper(ip_key_column_3) THEN
            IF v_function_index='ENABLED' THEN
               FOR rec_ind_expressions IN csr_ind_expressions LOOP
                 IF rec_ind_expressions.column_position=3 AND rec_ind_expressions.column_expression != UPPER(ip_key_column_3) THEN
                    EXECUTE IMMEDIATE v_sqlstmt;
                    RETURN FALSE;
                 END IF;
               END LOOP;
            ELSE
              EXECUTE IMMEDIATE v_sqlstmt;
              RETURN FALSE;
            END IF;
          ELSIF rec.column_position = 4 AND rec.column_name != upper(ip_key_column_4) THEN
            IF v_function_index='ENABLED' THEN
               FOR rec_ind_expressions IN csr_ind_expressions LOOP
                 IF rec_ind_expressions.column_position=4 AND rec_ind_expressions.column_expression != UPPER(ip_key_column_4) THEN
                    EXECUTE IMMEDIATE v_sqlstmt;
                    RETURN FALSE;
                 END IF;
               END LOOP;
            ELSE
              EXECUTE IMMEDIATE v_sqlstmt;
              RETURN FALSE;
            END IF;
          ELSIF rec.column_position = 5 AND rec.column_name != upper(ip_key_column_5) THEN
            IF v_function_index='ENABLED' THEN
               FOR rec_ind_expressions IN csr_ind_expressions LOOP
                 IF rec_ind_expressions.column_position=5 AND rec_ind_expressions.column_expression != UPPER(ip_key_column_5) THEN
                    EXECUTE IMMEDIATE v_sqlstmt;
                    RETURN FALSE;
                 END IF;
               END LOOP;
            ELSE
              EXECUTE IMMEDIATE v_sqlstmt;
              RETURN FALSE;
            END IF;
          ELSIF rec.column_position = 6 AND rec.column_name != upper(ip_key_column_6) THEN
            IF v_function_index='ENABLED' THEN
               FOR rec_ind_expressions IN csr_ind_expressions LOOP
                 IF rec_ind_expressions.column_position=6 AND rec_ind_expressions.column_expression != UPPER(ip_key_column_6) THEN
                    EXECUTE IMMEDIATE v_sqlstmt;
                    RETURN FALSE;
                 END IF;
               END LOOP;
            ELSE
              EXECUTE IMMEDIATE v_sqlstmt;
              RETURN FALSE;
            END IF;
          ELSIF rec.column_position = 7 AND rec.column_name != upper(ip_key_column_7) THEN
            IF v_function_index='ENABLED' THEN
               FOR rec_ind_expressions IN csr_ind_expressions LOOP
                 IF rec_ind_expressions.column_position=7 AND rec_ind_expressions.column_expression != UPPER(ip_key_column_7) THEN
                    EXECUTE IMMEDIATE v_sqlstmt;
                    RETURN FALSE;
                 END IF;
               END LOOP;
            ELSE
              EXECUTE IMMEDIATE v_sqlstmt;
              RETURN FALSE;
            END IF;
          ELSIF rec.column_position = 8 AND rec.column_name != upper(ip_key_column_8) THEN
            IF v_function_index='ENABLED' THEN
               FOR rec_ind_expressions IN csr_ind_expressions LOOP
                 IF rec_ind_expressions.column_position=8 AND rec_ind_expressions.column_expression != UPPER(ip_key_column_8) THEN
                    EXECUTE IMMEDIATE v_sqlstmt;
                    RETURN FALSE;
                 END IF;
               END LOOP;
            ELSE
              EXECUTE IMMEDIATE v_sqlstmt;
              RETURN FALSE;
            END IF;
          ELSIF rec.column_position = 9 AND rec.column_name != upper(ip_key_column_9) THEN
            IF v_function_index='ENABLED' THEN
               FOR rec_ind_expressions IN csr_ind_expressions LOOP
                 IF rec_ind_expressions.column_position=9 AND rec_ind_expressions.column_expression != UPPER(ip_key_column_9) THEN
                    EXECUTE IMMEDIATE v_sqlstmt;
                    RETURN FALSE;
                 END IF;
               END LOOP;
            ELSE
              EXECUTE IMMEDIATE v_sqlstmt;
              RETURN FALSE;
            END IF;
          ELSIF rec.column_position = 10 AND rec.column_name != upper(ip_key_column_10) THEN
            IF v_function_index='ENABLED' THEN
               FOR rec_ind_expressions IN csr_ind_expressions LOOP
                 IF rec_ind_expressions.column_position=10 AND rec_ind_expressions.column_expression != UPPER(ip_key_column_10) THEN
                    EXECUTE IMMEDIATE v_sqlstmt;
                    RETURN FALSE;
                 END IF;
               END LOOP;
            ELSE
              EXECUTE IMMEDIATE v_sqlstmt;
              RETURN FALSE;
            END IF;
          ELSIF rec.column_position = 11 AND rec.column_name != upper(ip_key_column_11) THEN
            IF v_function_index='ENABLED' THEN
               FOR rec_ind_expressions IN csr_ind_expressions LOOP
                 IF rec_ind_expressions.column_position=11 AND rec_ind_expressions.column_expression != UPPER(ip_key_column_11) THEN
                    EXECUTE IMMEDIATE v_sqlstmt;
                    RETURN FALSE;
                 END IF;
               END LOOP;
            ELSE
              EXECUTE IMMEDIATE v_sqlstmt;
              RETURN FALSE;
            END IF;
          ELSIF rec.column_position = 12 AND rec.column_name != upper(ip_key_column_12) THEN
            IF v_function_index='ENABLED' THEN
               FOR rec_ind_expressions IN csr_ind_expressions LOOP
                 IF rec_ind_expressions.column_position=12 AND rec_ind_expressions.column_expression != UPPER(ip_key_column_12) THEN
                    EXECUTE IMMEDIATE v_sqlstmt;
                    RETURN FALSE;
                 END IF;
               END LOOP;
            ELSE
              EXECUTE IMMEDIATE v_sqlstmt;
              RETURN FALSE;
            END IF;
          ELSIF rec.column_position = 13 AND rec.column_name != upper(ip_key_column_13) THEN
            IF v_function_index='ENABLED' THEN
               FOR rec_ind_expressions IN csr_ind_expressions LOOP
                 IF rec_ind_expressions.column_position=13 AND rec_ind_expressions.column_expression != UPPER(ip_key_column_13) THEN
                    EXECUTE IMMEDIATE v_sqlstmt;
                    RETURN FALSE;
                 END IF;
               END LOOP;
            ELSE
              EXECUTE IMMEDIATE v_sqlstmt;
              RETURN FALSE;
            END IF;
          ELSIF rec.column_position = 14 AND rec.column_name != upper(ip_key_column_14) THEN
            IF v_function_index='ENABLED' THEN
               FOR rec_ind_expressions IN csr_ind_expressions LOOP
                 IF rec_ind_expressions.column_position=14 AND rec_ind_expressions.column_expression != UPPER(ip_key_column_14) THEN
                    EXECUTE IMMEDIATE v_sqlstmt;
                    RETURN FALSE;
                 END IF;
               END LOOP;
            ELSE
              EXECUTE IMMEDIATE v_sqlstmt;
              RETURN FALSE;
            END IF;
          ELSIF rec.column_position = 15 AND rec.column_name != upper(ip_key_column_15) THEN
            IF v_function_index='ENABLED' THEN
               FOR rec_ind_expressions IN csr_ind_expressions LOOP
                 IF rec_ind_expressions.column_position=15 AND rec_ind_expressions.column_expression != UPPER(ip_key_column_15) THEN
                    EXECUTE IMMEDIATE v_sqlstmt;
                    RETURN FALSE;
                 END IF;
               END LOOP;
            ELSE
              EXECUTE IMMEDIATE v_sqlstmt;
              RETURN FALSE;
            END IF;
          ELSIF rec.column_position = 16 AND rec.column_name != upper(ip_key_column_16) THEN
            IF v_function_index='ENABLED' THEN
               FOR rec_ind_expressions IN csr_ind_expressions LOOP
                 IF rec_ind_expressions.column_position=16 AND rec_ind_expressions.column_expression != UPPER(ip_key_column_16) THEN
                    EXECUTE IMMEDIATE v_sqlstmt;
                    RETURN FALSE;
                 END IF;
               END LOOP;
            ELSE
              EXECUTE IMMEDIATE v_sqlstmt;
              RETURN FALSE;
            END IF;
          END IF;
       END LOOP;
     END IF;
     RETURN TRUE;
   END IF;

EXCEPTION
  WHEN others THEN
      RAISE_APPLICATION_ERROR ( -20000, 'Error accessing user_ind_columns table', TRUE );
      RETURN FALSE;
END;

  -----------------------------------------------------FUNCTION package_compiled
  --Function takes package name and returns true if the package and body are compiled
  FUNCTION package_compiled (
      p_package_name IN user_objects.object_name%TYPE
  ) RETURN BOOLEAN IS
  BEGIN
      DECLARE
          v_count NUMBER := 0;
      BEGIN

        SELECT count(*)
        INTO v_count
        FROM user_objects
        WHERE object_name = UPPER(p_package_name)
          AND object_type IN ('PACKAGE', 'PACKAGE BODY')
          AND status = 'VALID';

        IF v_count = 2 THEN
            RETURN TRUE;
        ELSE
            RETURN FALSE;
        END IF;

      EXCEPTION
        WHEN others THEN
            RAISE_APPLICATION_ERROR ( -20000, 'Error accessing user_objects table', TRUE );
            RETURN FALSE;
      END;
  END package_compiled;

   FUNCTION k_drop_constraint ( p_constraint_name user_constraints.constraint_name%TYPE ) RETURN BOOLEAN
   IS

   l_error_msg    VARCHAR2(100);
   l_table        user_constraints.table_name%TYPE;
   l_return       BOOLEAN;

   BEGIN
      l_return := false;

      IF k_database_management.constraint_exists( p_constraint_name ) THEN

         l_error_msg := 'k_drop_constraint - initial select into - ' || p_constraint_name;
         SELECT table_name INTO l_table FROM user_constraints
            WHERE constraint_name = UPPER(p_constraint_name);

         l_error_msg := 'k_drop_constraint - drop constraint - ' || p_constraint_name;
         EXECUTE IMMEDIATE 'alter table ' || l_table || ' drop constraint ' || p_constraint_name;

         dbms_output.put_line('k_drop_constraint drop constraint:' ||
            l_table || ' / ' || p_constraint_name);
         l_return := TRUE;

      END IF;

      IF k_database_management.object_exists( p_constraint_name, 'INDEX' ) then

         l_error_msg := 'k_drop_constraint - extra index: ' || p_constraint_name;
         EXECUTE IMMEDIATE 'drop index ' || p_constraint_name;
         dbms_output.put_line('k_drop_constraint drop extra index :' ||
            l_table || ' / ' || p_constraint_name);
         l_return := TRUE;

      END IF;

      RETURN l_return;

      EXCEPTION
         WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR( -20000, l_error_msg, TRUE);
            RETURN FALSE;
   END k_drop_constraint;

   PROCEDURE k_table_add_field ( ptriggers BOOLEAN,
      ptable VARCHAR2, pfield VARCHAR2, psql VARCHAR2, pmsg VARCHAR2 ) IS
   BEGIN
      IF NOT k_database_management.column_exists(ptable, pfield) THEN
         IF ptriggers THEN
            EXECUTE IMMEDIATE 'ALTER TABLE ' || ptable || ' DISABLE ALL TRIGGERS';
            DBMS_OUTPUT.PUT_LINE('triggers disabled - ' || ptable);
         END IF;
         EXECUTE IMMEDIATE psql;
         DBMS_OUTPUT.PUT_LINE(pmsg);
         IF ptriggers THEN
            EXECUTE IMMEDIATE 'ALTER TABLE ' || ptable || ' ENABLE ALL TRIGGERS';
            DBMS_OUTPUT.PUT_LINE('triggers enabled - ' || ptable);
         END IF;
       END IF;
   EXCEPTION
       WHEN OTHERS THEN
         IF ptriggers THEN
            EXECUTE IMMEDIATE 'ALTER TABLE ' || ptable || ' ENABLE ALL TRIGGERS';
              DBMS_OUTPUT.PUT_LINE('Error caught: ' || ptable || ' triggers enabled');
           END IF;
           RAISE;
   END k_table_add_field;

   PROCEDURE k_add_std_sequence ( p_sequence_name user_sequences.sequence_name%TYPE) IS
   BEGIN
       IF NOT k_database_management.object_exists(p_sequence_name, 'SEQUENCE') THEN
           EXECUTE IMMEDIATE 'CREATE SEQUENCE ' || p_sequence_name ||
              ' INCREMENT BY 1 START WITH 1 NOMAXVALUE NOMINVALUE NOCYCLE NOCACHE';
           DBMS_OUTPUT.PUT_LINE('Sequence created: ' || p_sequence_name);
       END IF;
   END k_add_std_sequence;

    procedure k_cleanup_tbl_synonym ( ptable user_synonyms.table_name%TYPE )
    as
        v_sql           varchar2(250);
        vc_synonyms     number;
        vc_count        number;
        v_err_num       number;
        v_err_msg       varchar2(100);
        l_drop_synonym  boolean;
        v_location      varchar2(12);
        l_displays      boolean := false; -- true;
    begin

    v_location := 'at start';

 if l_displays then
 dbms_output.put_line('***');
 dbms_output.put_line('*** ' || v_location || ' : table : ' || ptable);
 end if;

    select count(*) into vc_synonyms from user_synonyms
        where synonym_name = upper(ptable);
    if vc_synonyms > 0 then -- oops ... synonym exists
        v_location := 'exists';

 if l_displays then
 dbms_output.put_line('*** ' || v_location || ' : table : ' || ptable);
 end if;

    --
    --  try to select count on the synonym to determine if working 
    --
        begin
            v_location := 'exists blk';

 if l_displays then
 dbms_output.put_line('*** ' || v_location || ' : table : ' || ptable);
 end if;

            --  assume synonym points at something
            l_drop_synonym := false;

            v_sql := 'select count(*) from ' || ptable || ' where rownum < 10';
            execute immediate v_sql into vc_count;

        exception
            when others then    -- guess it is an orphan synonym
                l_drop_synonym := true;
        end;

        v_location := 'b4 drop';

 if l_displays then
 dbms_output.put_line('*** ' || v_location || ' : table : ' || ptable);
 end if;

        if l_drop_synonym then
            v_location := 'in drop';

 if l_displays then
 dbms_output.put_line('*** ' || v_location || ' : table : ' || ptable);
 end if;

            v_sql := 'DROP SYNONYM ' || ptable;
            dbms_output.put_line('*** executing sql: ' || v_sql);
            execute immediate v_sql;
            dbms_output.put_line('*** executed succesfully');
        end if;
    end if;

    v_location := 'at exit';

 if l_displays then
 dbms_output.put_line('*** ' || v_location || ' : table : ' || ptable);
 end if;

    exception
        when others then
            v_err_num := SQLCODE;
            v_err_msg := SUBSTR(SQLERRM, 1, 100);
            dbms_output.put_line('*** during call to k_cleanup_tbl_synonym ***' );
            dbms_output.put_line('*** at: ' || v_location);
            dbms_output.put_line('*** ERROR: ' || v_err_num || ' : ' || v_err_msg);
            rollback;
            raise;

	end k_cleanup_tbl_synonym;

END;
/

show errors

PROMPT *** Creating public synonym for pkg ***
-- logon no longer needed since logged on as system already
--conn system/&&micsystempassword

PROMPT *** Granting pkg access to public***
GRANT EXECUTE ON k_database_management TO PUBLIC;

PROMPT *** Create public synonym for pkg ***
CREATE OR REPLACE PUBLIC SYNONYM k_database_management FOR k_database_management;

UNDEFINE micsystempassword

PROMPT =====================================
PROMPT
EXIT SUCCESS
