PROMPT
PROMPT ==================================================
PROMPT Executing drop_database_management.sql
PROMPT ==================================================


SET VERIFY OFF
WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR EXIT SQL.OSCODE

PROMPT **** 1 == micsystempassword
DEFINE micsystempassword=&1

SET SERVEROUTPUT ON
DECLARE
	v_sql	varchar2(100);
BEGIN
FOR sp in   (SELECT owner, object_name, object_type FROM all_objects 
				WHERE object_type IN ('PROCEDURE','FUNCTION','PACKAGE') 
				AND	object_name in  (   
						'K_DATABASE_MANAGEMENT'
					)
            )
LOOP
	v_sql := 'DROP ' || sp.object_type || ' ' || sp.owner || '.' || sp.object_name;
    dbms_output.put_line('*** dropping temp procedure/function/package: ' || sp.object_name);
    dbms_output.put_line('*** SQL: ' || v_sql);
	EXECUTE IMMEDIATE v_sql;    
END LOOP;
END;
/

-- DROP PACKAGE k_database_management;

PROMPT =====================================
PROMPT 
EXIT SUCCESS
