PROMPT
PROMPT ==============================================
PROMPT Executing grant_policy_studio.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
EXIT SUCCESS