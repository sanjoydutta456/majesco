PROMPT
PROMPT ==============================================
PROMPT Executing mic_admin_public.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT

EXIT SUCCESS