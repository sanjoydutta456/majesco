PROMPT
PROMPT ==============================================
PROMPT Executing patch_mic_admin_customer.sql
PROMPT ==============================================

SET VERIFY OFF
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
WHENEVER OSERROR EXIT OSCODE

DEFINE indextbsp=&1
DEFINE customercode=&2

@@mic_admin_customer.dat
@@mic_admin_customer.grt

PROMPT =====================================
PROMPT 
EXIT SUCCESS