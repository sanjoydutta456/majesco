PROMPT
PROMPT ==============================================
PROMPT Executing upgrade_mic_admin.sql
PROMPT ==============================================

SET VERIFY OFF
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
WHENEVER OSERROR EXIT OSCODE
SET SERVEROUTPUT ON SIZE 1000000

DEFINE indextbsp=&1

@@mic_admin.tab
@@mic_admin.con
@@mic_admin.ind
@@mic_admin.seq
@@mic_admin.prc
@@mic_admin.vw
@@mic_admin.trg
@@mic_admin_common.dat
@@mic_admin_param_exceptions.dat
@@mic_admin_security.dat
@@mic_admin_customer_keys.dat

PROMPT =====================================
PROMPT
EXIT SUCCESS