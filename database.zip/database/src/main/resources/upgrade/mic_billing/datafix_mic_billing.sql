PROMPT
PROMPT ==============================================
PROMPT Executing datafix_mic_billing.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT

EXIT SUCCESS