PROMPT
PROMPT ==============================================
PROMPT Executing upgrade_mic_billing.sql
PROMPT ==============================================

SET VERIFY OFF
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
WHENEVER OSERROR EXIT OSCODE
SET SERVEROUTPUT ON SIZE 1000000

DEFINE indextbsp=&1
DEFINE customercode=&2

@@mic_billing.tab
@@mic_billing.con
@@mic_billing.ind
@@mic_billing.seq
@@mic_billing.prc
@@mic_billing.vw
@@mic_billing.trg

PROMPT =====================================
PROMPT
EXIT SUCCESS