PROMPT
PROMPT ==============================================
PROMPT Executing datafix_mic_claim.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
EXIT SUCCESS