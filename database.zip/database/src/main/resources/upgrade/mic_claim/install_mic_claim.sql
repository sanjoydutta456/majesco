PROMPT
PROMPT ==============================================
PROMPT Executing install_mic_claim.sql
PROMPT ==============================================

SET VERIFY OFF
WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR EXIT SQL.OSCODE

DEFINE indextbsp=&1
DEFINE customercode=&2

@@mic_claim.tab
@@mic_claim.seq
@@mic_claim.trg
@@mic_claim.con
--@@mic_claim.ind
@@mic_claim.prc
@@mic_claim.grt
--@@mic_claim.dat


PROMPT ==============================================
PROMPT 
Exit Success