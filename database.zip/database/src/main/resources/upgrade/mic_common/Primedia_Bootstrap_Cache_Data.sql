PROMPT
PROMPT ==============================================
PROMPT Executing Primedia_Bootstrap_Cache_Data.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
EXIT