PROMPT
PROMPT ==============================================
PROMPT Executing datafix_mic_common.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT

EXIT SUCCESS