PROMPT
PROMPT ==============================================
PROMPT Executing mic_bootstrap.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 

EXIT SUCCESS