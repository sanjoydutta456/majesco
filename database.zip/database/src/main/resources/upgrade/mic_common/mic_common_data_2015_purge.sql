PROMPT
PROMPT ==============================================
PROMPT Executing mic_common_data_2015_purge.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT
EXIT SUCCESS