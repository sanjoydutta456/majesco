PROMPT
PROMPT ==============================================
PROMPT Executing mic_common_drop_old_tables.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT
