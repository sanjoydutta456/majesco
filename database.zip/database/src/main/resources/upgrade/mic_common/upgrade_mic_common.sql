PROMPT
PROMPT ==============================================
PROMPT Executing upgrade_mic_common.sql
PROMPT ==============================================


SET VERIFY OFF
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
WHENEVER OSERROR EXIT OSCODE
SET SERVEROUTPUT ON SIZE 1000000

DEFINE indextbsp=&1
DEFINE customercode=&2

@@mic_common.tab
@@mic_common.con
@@mic_common.ind
@@mic_common.seq
@@mic_common.typ
@@mic_common.prc
@@mic_common.vw
@@mic_common.trg

PROMPT =====================================
PROMPT
EXIT SUCCESS