PROMPT
PROMPT ==============================================
PROMPT Executing datafix_mic_crm.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
EXIT SUCCESS