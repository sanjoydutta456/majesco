PROMPT
PROMPT ==============================================
PROMPT Executing upgrade_mic_crm.sql
PROMPT ==============================================

SET VERIFY OFF
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
WHENEVER OSERROR EXIT OSCODE
SET SERVEROUTPUT ON SIZE 1000000

DEFINE indextbsp=&1
DEFINE customercode=&2

@@mic_crm.tab
@@mic_crm.con
@@mic_crm.ind
@@mic_crm.seq
@@mic_crm.prc
@@mic_crm.vw
@@mic_crm.trg

PROMPT =====================================
PROMPT
EXIT SUCCESS