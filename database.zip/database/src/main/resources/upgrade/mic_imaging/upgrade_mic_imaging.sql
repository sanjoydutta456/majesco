PROMPT
PROMPT ==============================================
PROMPT Executing upgrade_mic_imaging.sql
PROMPT ==============================================

SET VERIFY OFF
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
WHENEVER OSERROR EXIT OSCODE
SET SERVEROUTPUT ON SIZE 1000000

DEFINE indextbsp=&1

@@mic_imaging.ind


PROMPT =====================================
PROMPT
EXIT SUCCESS 