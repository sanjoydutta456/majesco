PROMPT
PROMPT ==============================================
PROMPT Executing patch_mic_messaging.sql
PROMPT ==============================================

SET VERIFY OFF
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
WHENEVER OSERROR EXIT OSCODE

DEFINE indextbsp=&1

--@@mic_messaging.tab
--@@mic_messaging.con
--@@mic_messaging.ind
--@@mic_messaging.seq
--@@mic_messaging.prc
--@@mic_messaging.vw
--@@mic_messaging.trg

PROMPT =====================================
PROMPT 
EXIT SUCCESS