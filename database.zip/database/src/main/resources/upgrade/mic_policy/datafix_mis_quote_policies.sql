PROMPT
PROMPT ==============================================
PROMPT Executing datafix_mis_quote_policies.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
EXIT SUCCESS