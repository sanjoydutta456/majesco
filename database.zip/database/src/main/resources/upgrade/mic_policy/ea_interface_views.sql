PROMPT
PROMPT ==============================================
PROMPT Executing ea_interface_views.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
EXIT SUCCESS