PROMPT
PROMPT ==============================================
PROMPT Executing fin_bootstrap.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
EXIT SUCCESS