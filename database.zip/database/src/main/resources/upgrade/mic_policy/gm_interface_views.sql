PROMPT
PROMPT ==============================================
PROMPT Executing gm_interface_views.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
EXIT SUCCESS