PROMPT
PROMPT ==============================================
PROMPT Executing iel-post-configure.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
EXIT SUCCESS