PROMPT
PROMPT ==============================================
PROMPT Executing lx_interface_views.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
EXIT SUCCESS