PROMPT
PROMPT ==============================================
PROMPT Executing mic_policy_copy_cust_iel_tables.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
-- EXIT SUCCESS