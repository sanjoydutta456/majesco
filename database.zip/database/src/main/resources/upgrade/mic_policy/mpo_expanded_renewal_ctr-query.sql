PROMPT
PROMPT ==============================================
PROMPT Executing mpo_expanded_renewal_ctr-query.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
EXIT