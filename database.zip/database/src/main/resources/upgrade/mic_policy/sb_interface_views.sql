PROMPT
PROMPT ==============================================
PROMPT Executing sb_interface_views.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
EXIT SUCCESS