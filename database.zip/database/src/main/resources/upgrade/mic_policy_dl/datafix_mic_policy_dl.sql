PROMPT
PROMPT ==============================================
PROMPT Executing datafix_mic_policy$.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT
EXIT SUCCESS 