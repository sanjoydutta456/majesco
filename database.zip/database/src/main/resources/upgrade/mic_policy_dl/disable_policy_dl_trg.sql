PROMPT
PROMPT ==============================================
PROMPT Executing disable_policy$_trg.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
EXIT SUCCESS