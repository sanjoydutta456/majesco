PROMPT
PROMPT ==============================================
PROMPT Executing enable_policy$_trg.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
EXIT SUCCESS