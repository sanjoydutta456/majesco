PROMPT
PROMPT ==============================================
PROMPT Executing mh_mrenewal_ctr-query.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
EXIT