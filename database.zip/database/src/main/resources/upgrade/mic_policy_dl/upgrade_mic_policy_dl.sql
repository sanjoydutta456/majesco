PROMPT
PROMPT ==============================================
PROMPT Executing upgrade_mic_policy_dl.sql
PROMPT ==============================================

SET VERIFY OFF
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
WHENEVER OSERROR EXIT OSCODE
SET SERVEROUTPUT ON SIZE 1000000

DEFINE indextbsp=&1
DEFINE customercode=&2

@@mic_policy_dl.tab
@@mic_policy_dl.con
@@mic_policy_dl.ind
@@mic_policy_dl.seq
@@mic_policy_dl.prc
@@mic_policy_dl.vw
@@mic_policy_dl.trg

PROMPT =====================================
PROMPT
EXIT SUCCESS 