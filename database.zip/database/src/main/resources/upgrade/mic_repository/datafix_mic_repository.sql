PROMPT
PROMPT ==============================================
PROMPT Executing datafix_mic_repository.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
EXIT SUCCESS