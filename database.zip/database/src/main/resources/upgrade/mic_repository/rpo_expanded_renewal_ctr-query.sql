PROMPT
PROMPT ==============================================
PROMPT Executing rpo_expanded_renewal_ctr-query.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
EXIT