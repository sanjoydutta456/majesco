PROMPT
PROMPT ==============================================
PROMPT Executing billing_bootstrap.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
EXIT SUCCESS