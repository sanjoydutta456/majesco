PROMPT
PROMPT ==============================================
PROMPT Executing datafix_mic_user.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
EXIT SUCCESS