PROMPT
PROMPT ==============================================
PROMPT Executing mic_nextgen_bootstrap.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
EXIT