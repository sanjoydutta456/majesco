PROMPT
PROMPT ==============================================
PROMPT Executing mic_nextgen_bootstrap_lxeg.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
EXIT