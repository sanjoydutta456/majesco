PROMPT
PROMPT ==============================================
PROMPT Executing pct-cleanup.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
EXIT