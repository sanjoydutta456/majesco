#!/bin/bash

##  Eric Beuscher
##  patch_mic_common_schema.sh

## Change the current directory to where the batch script exists
olddir=`pwd`
shdir=`dirname $0`
cd $shdir

trap 'onexit' EXIT

function onexit() {
    cd $olddir
}

echo "====================="
echo "Preparing environment"
echo "====================="
envfile=$shdir/setCommonDatabaseEnv.sh
## Checking Environment scripts exist or not
if [ ! -e $envfile ]; then
    echo "ERROR: $envfile does not exist"
    exit 1;
fi
source $envfile

envfile1=$shdir/setCustomerDatabaseEnv.sh
## Checking Environment scripts exist or not
if [ ! -e $envfile1 ]; then
    echo "ERROR: $envfile1 does not exist"
    exit 1;
fi
source $envfile1

## Create a temporary subdirectory in case it's missing
tmpdir=$INSTALL_PATH/logs/MIC_Logs    
if [ ! -d $tmpdir ]; then
    mkdir $tmpdir
fi

if [ ! -x "$SQLPLUS_BIN" ]; then
    SQLPLUS_BIN=$INSTALLER_SQL_CLIENT_HOME
fi

export ORACLE_HOME=$SQLPLUS_BIN
export LD_LIBRARY_PATH=$ORACLE_HOME
export PATH=$PATH:$ORACLE_HOME

errorlog=$tmpdir

TWO_TASK=$MICConnectString
## Purge Recyclebin
echo "Purge Recyclebin"
sqlplus -s $MICAdminUserName/$MICAdminPassword@$MICConnectString @purge_recyclebin >> $errorlog/purge_recyclebin.log
if [ $? != 0 ]; then
    echo 'ERROR: could not run @purge_recyclebin.sql'
    exit 1
fi

## Create DB Mgmt pkgs.
echo "Create DB Mgmt pkgs." 
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @create_database_management.sql $MICSystemPassword > $errorlog/create_database_management.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @create_database_management.sql"
    exit 1
fi

## Patch db objects for common schema.

echo "Patching mic_admin DB Objects"
sqlplus -s $MICAdminUserName/$MICAdminPassword@$MICConnectString @mic_admin/patch_mic_admin $MICAdminIndexTablespace $MICCustomerCode >> $errorlog/patch_mic_admin.log
if [ $? != 0 ]; then
    echo 'ERROR: could not run @mic_admin/patch_mic_admin'
    exit 1
fi

echo "Patching mic_messaging DB Objects"
sqlplus -s $MICMessagingUsername/$MICMessagingPassword@$MICConnectString @mic_messaging/patch_mic_messaging $MICMessagingIndexTablespace $MICCustomerCode >> $errorlog/patch_mic_messaging.log
if [ $? != 0 ]; then
    echo 'ERROR: could not run @mic_admin/patch_mic_admin'
    exit 1
fi

echo "Patching mic_imaging DB Objects"
#sqlplus -s -l mic_imaging/mic_imaging@$MICConnectString @mic_imaging/patch_mic_imaging $MicImagingIndexTablespace $MICCustomerCode >> $errorlog/patch_mic_messaging.log
#if [ $? != 0 ]; then
#    echo 'ERROR: could not run @mic_imaging/patch_mic_imaging'
#fi


## Patch mic admin_public
echo "Patching mic admin public..."
sqlplus -s $MICAdminUserName/$MICAdminPassword@$MICConnectString @mic_admin/mic_admin_public.sql >> $errorlog/mic_admin_public.log
if [ $? != 0 ]; then
    echo 'ERROR: could not run @mic_admin/mic_admin_public.sql'
    exit 1
fi

## Patch mic admin_public
echo "Patching mic admin public..."
sqlplus -s $MICAdminUserName/$MICAdminPassword@$MICConnectString @mic_admin/mic_admin_public.int $MICSystemPassword >> $errorlog/mic_admin_public.log
if [ $? != 0 ]; then
    echo 'ERROR: could not run @mic_admin/mic_admin_public.int'
    exit 1
fi


##Compile db objects for common schema.

echo "Compiling mic_admin DB Objects"
sqlplus -s $MICAdminUserName/$MICAdminPassword@$MICConnectString @compile_invalid_objects.sql >> $errorlog/compiling_mic_admin.log
if [ $? != 0 ]; then
    echo "ERROR: could not run mic_admin @compile_invalid_objects.sql"
    exit 1
fi

echo "Compiling mic_messaging DB Objects"
sqlplus -s $MICMessagingUsername/$MICMessagingPassword@$MICConnectString @compile_invalid_objects.sql >> $errorlog/compiling_mic_messaging.log
if [ $? != 0 ]; then
    echo "ERROR: could not run mic_messaging @compile_invalid_objects.sql"
    exit 1
fi

##Drop DB Mgmt pkgs.
echo "Compiling all DB Objects..."
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @drop_database_management.sql $MICSystemPassword >> $errorlog/drop.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @drop_database_management.sql"
    exit 1
fi


echo "**"
echo "MIC Common schemas are updated successfully. "
echo "Logfiles are created in $tmpdir/MIC_Logs"
echo "."
