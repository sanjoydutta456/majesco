PROMPT
PROMPT ==============================================
PROMPT Executing upgrade_policy_studio.sql
PROMPT FILE NOT IN USE, SO HARDCODING OF PASSWORDS NOT REMOVED
PROMPT ==============================================


/*
SET VERIFY OFF
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
WHENEVER OSERROR EXIT OSCODE
SET SERVEROUTPUT ON SIZE 1000000

PROMPT 1==indextbsp ... 2==customercode
DEFINE indextbsp=--1
DEFINE customercode--2

@@policy_studio.prc
@@policy_studio.tab
@@policy_studio.ind
@@policy_studio.vw
@@policy_studio.trg

PROMPT =====================================
PROMPT
EXIT SUCCESS
*/

SET VERIFY OFF
SET SERVEROUTPUT ON SIZE 1000000
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
WHENEVER OSERROR EXIT OSCODE

PROMPT ***
PROMPT 1==the_sid ... 2==customercode ... 3==customerdomain
PROMPT ***
DEFINE the_db=&1
DEFINE customercode=&2
DEFINE customerdomain=&3
DEFINE indextbsp=idevstudio
DEFINE policy_studio_user=policy_studio_&&customercode
DEFINE policy_studio_password=policy_studio_&&customercode

PROMPT ====================================
PROMPT ===== show for substitutions
PROMPT ====================================
PROMPT the_db : &&the_db
PROMPT customercode : &&customercode
PROMPT customerdomain : &&customerdomain
PROMPT indextbsp : &&indextbsp
PROMPT policy_studio_user : &&policy_studio_user
PROMPT policy_studio_password : &&policy_studio_password
PROMPT ====================================

-- first because ONLY ROWRANK.sql function there
--      ROWRANK used for index build

PROMPT ***
PROMPT *** execute policy_studio/policy_studio.prc
PROMPT ***
@@policy_studio.prc

PROMPT ***
PROMPT *** execute policy_studio/policy_studio.tab
PROMPT ***
@@policy_studio.tab

PROMPT ***
PROMPT *** execute policy_studio/policy_studio.con
PROMPT ***
@@policy_studio.con

PROMPT ***
PROMPT *** execute policy_studio/policy_studio.ind
PROMPT ***
@@policy_studio.ind

PROMPT ***
PROMPT *** execute policy_studio/policy_studio.grt
PROMPT ***
@@policy_studio.grt &&customercode

PROMPT ***
PROMPT *** execute policy_studio/policy_studio.dat
PROMPT ***
-- @@policy_studio.dat &&customercode &&customerdomain

PROMPT ***
PROMPT *** execute policy_studio/policy_studio.vw
PROMPT ***
@@policy_studio.vw

PROMPT ***
PROMPT *** execute policy_studio/policy_studio.trg
PROMPT ***
@@policy_studio.trg


PROMPT ***
PROMPT *** log on as mic_&&customercode
PROMPT ***

-- for when connect string needed
connect mic_&&customercode/mic_&&customercode@&&the_db

-- for when connect string NOT needed
--connect mic_&&customercode/mic_&&customercode

PROMPT ***
PROMPT *** execute policy_studio/policy_studio.grt as mic_&&customercode
PROMPT *** NOT in mic_user directory
PROMPT ***
@@policy_studio.syn

PROMPT =====================================
PROMPT
EXIT SUCCESS