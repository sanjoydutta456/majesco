:: ==================================================
:: OVERVIEW
:: ==================================================
::
:: This set of scripts runs the database install path scripts based on a
:: particular version of MIC.  The script allows for the running of both the
:: CD1 and CD3 scripts, along with any database scripts, typically run by the
:: MIC installer that are also needed for database script testing.
::
:: Optionally, in addition to just running the release version of the install
:: path scripts, you can also provide a directory of additional changes to be
:: overlayed onto the release changes.  That directory should be named
:: 'database', and should have any file changes using the same filename(s) and
:: directory structure as the MIC database source tree.
::
:: In general, it is best to try to get the latest version of the script, in
:: case there are changes needed for newer versions of MIC.

:: ==================================================
:: PREPARATION
:: ==================================================
:: 1. This script needs to be run on Windows
:: 2. On the server that this script will be run from, you need to have TNS
::    configured to allow for the database connections.
:: 3. Open run-install-path.cfg in a Text Editor, and configure the properties
::    as appropriate for the environment.  If running for customer 99, the
::    customer* and isLicensed* properties can probably be left alone.
::    The micFullRelease property can be used, when on the Cover-All network,
::    to run the database install scripts from a particular MIC release.

:: ==================================================
:: TO RUN FROM THE COVER-ALL NETWORK
:: ==================================================
:: Notes:
::     When run from the Cover-All network, the script will use the
::     micFullRelease property that is set in the configuration file to get
::     the database install path scripts to be used.  Additionally, it will get
::     the necessary libraries for running the MIC installer.  Once the database
::     and installer directories are retrieved, the script will not get the
::     files again.  To re-retrieve the files, delete the following directories:
::         .\stage
::         .\mic-install\Installer
::
:: 1. Unzip run-install-path.zip to a directory, like d:\temp\run-install-path
:: 2. Open a Command Prompt and go to d:\temp\run-install-path
:: 3a. To run just a base install path:
::        run-install-path.bat CONFIG-FILE-NAME
::     Log locations:
::       - .\CD1.xml.log
::       - .\CD3.xml.log
::       - .\db-cd3-install.log
:: 3b. To run install path, overlaying with additional changes:
::        run-install-path.bat CONFIG-FILE-NAME DATABASE_CHANGES_DIR

:: ==================================================
:: TO RUN FROM OFF OF THE COVER-ALL NETWORK
:: ==================================================
:: Notes:
::     If these scripts are being used for external purposes, like escrow setup,
::     you will need to manually do the following:
::       1. copy the 'database' source tree into .\stage
::       2. copy the CD1 'Installer' tree into .\mic-install
::
:: 1. Unzip run-install-path.zip to a directory, like d:\temp\run-install-path
:: 2. Open a Command Prompt and go to d:\temp\run-install-path
:: 3. To run just a base install path:
::        run-install-path.bat CONFIG-FILE-NAME
::     Log locations:
::       - .\CD1.xml.log
::       - .\CD3.xml.log
::       - .\db-cd3-install.log

