PROMPT
PROMPT ==============================================
PROMPT Executing create-install-path.sql
PROMPT ==============================================

SET VERIFY OFF
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
WHENEVER OSERROR EXIT OSCODE

SET SERVEROUTPUT ON SIZE 1000000

DECLARE
    v_exists NUMBER;
BEGIN
    SELECT COUNT(1)
    INTO v_exists
    FROM user_tables
    WHERE table_name = 'ZZZ_INSTALL_PATH_CAN_CLEANUP';

    IF v_exists = 0 THEN
        EXECUTE IMMEDIATE 'CREATE TABLE ZZZ_INSTALL_PATH_CAN_CLEANUP ( ZIPCC_TYPE VARCHAR2(8), ZIPCC_DATE_CREATED DATE )';

        DBMS_OUTPUT.PUT_LINE('ZZZ_INSTALL_PATH_CAN_CLEANUP created');
    END IF;
END;
/

PROMPT =====================================
PROMPT 
EXIT SUCCESS