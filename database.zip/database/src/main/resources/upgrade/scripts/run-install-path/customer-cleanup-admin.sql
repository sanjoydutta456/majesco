PROMPT
PROMPT ===============================
PROMPT Executing customer-cleanup-admin.sql
PROMPT This file is not used in izpack installation and was used before izpack. Added two parameters MIC_ADMIN_USERNAME and MIC_ADMIN_PASSWORD
PROMPT ===============================

SET SERVEROUTPUT ON SIZE 1000000
SET VERIFY OFF

PROMPT customercode
DEFINE customercode=&1
PROMPT SID
DEFINE SID=&2
PROMPT MIC_ADMIN_USERNAME
DEFINE MIC_ADMIN_USERNAME=&3
PROMPT MIC_ADMIN_PASSWORD
DEFINE MIC_ADMIN_PASSWORD=&4

conn &&MIC_ADMIN_USERNAME/&&MIC_ADMIN_PASSWORD@&&SID

DELETE FROM adm_user_prefs
WHERE aup_realm_id IN (SELECT are_realm_id FROM adm_realms WHERE are_realm_name IN (SELECT acu_domain FROM adm_customers WHERE acu_customer_code IN ('&&customercode')));

commit;

DELETE FROM adm_security_policy
WHERE aso_realm_id IN (SELECT are_realm_id FROM adm_realms WHERE are_realm_name IN (SELECT acu_domain FROM adm_customers WHERE acu_customer_code IN ('&&customercode')));

commit;

DELETE FROM adm_security_providers
WHERE asp_realm_id IN (SELECT are_realm_id FROM adm_realms WHERE are_realm_name IN (SELECT acu_domain FROM adm_customers WHERE acu_customer_code IN ('&&customercode')));

commit;

DELETE FROM adm_privileges
WHERE apr_customer_id IN (SELECT acu_customer_id FROM adm_customers WHERE acu_customer_code IN ('&&customercode'));

commit;


DELETE FROM adm_realms where are_realm_name IN (SELECT acu_domain FROM adm_customers WHERE acu_customer_code IN ('&&customercode'));

commit;

DELETE FROM adm_customer_properties
WHERE acp_customer_id IN (SELECT acu_customer_id FROM adm_customers WHERE acu_customer_code IN ('&&customercode'));

commit;

DELETE FROM adm_software_versions
WHERE UPPER(asv_customer_code) = UPPER('&&customercode');

commit;

DELETE FROM adm_task_parameters
WHERE atp_task_id IN (SELECT ata_task_id FROM adm_tasks WHERE ata_domain IN (SELECT acu_domain FROM adm_customers WHERE acu_customer_code IN ('&&customercode')));

commit;

PROMPT Deleting from ADM_TASKS.  Run count(*) on ATO to monitor if taking long time
DECLARE
    v_max    NUMBER;
    v_iter   NUMBER;
    v_chunk  NUMBER := 500000;
    v_domain VARCHAR2(256);
    v_high   NUMBER;
    v_low    NUMBER;
    v_start  NUMBER := 1;
BEGIN
    SELECT acu_domain
    INTO v_domain
    FROM adm_customers
    WHERE acu_customer_code = '&&customercode';

    DBMS_OUTPUT.PUT_LINE('Deleting from ' || v_domain || ' for &&customercode');

    SELECT MAX(ato_log_id)
    INTO v_max
    FROM adm_task_logs;

    DBMS_OUTPUT.PUT_LINE('v_max=' || v_max);

    v_iter := CEIL(v_max/v_chunk);

    FOR i IN v_start..v_iter LOOP
        v_high := i * v_chunk;
        v_low := (i - 1) * v_chunk;

        DBMS_OUTPUT.PUT_LINE('v_low=' || v_low || ', v_high=' || v_high);

        DELETE FROM adm_task_logs
        WHERE ato_log_id < v_high
          AND ato_log_id >= v_low
          AND ato_task_id IN (SELECT ata_task_id FROM adm_tasks WHERE ata_domain = v_domain);

        DBMS_OUTPUT.PUT_LINE('Deleted ' || SQL%ROWCOUNT || ' rows from &&customercode ATO');

        COMMIT;
    END LOOP;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('Customer &&customercode not present');
END;
/
SET VERIFY ON


DELETE FROM adm_tasks
WHERE ata_domain IN (SELECT acu_domain FROM adm_customers WHERE acu_customer_code IN ('&&customercode'));

commit;

DELETE FROM adm_customers
WHERE acu_customer_code IN ('&&customercode');

commit;

UNDEFINE customercode
UNDEFINE SID



PROMPT ==============================================
PROMPT 
EXIT SUCCESS