PROMPT
PROMPT ==============================================
PROMPT Executing insert-cleanup.sql
PROMPT ==============================================

SET VERIFY OFF

DEFINE type=&&1

INSERT INTO ZZZ_INSTALL_PATH_CAN_CLEANUP(ZIPCC_TYPE, ZIPCC_DATE_CREATED) VALUES('&&type', sysdate);

COMMIT;

PROMPT ==============================================
PROMPT 

EXIT

