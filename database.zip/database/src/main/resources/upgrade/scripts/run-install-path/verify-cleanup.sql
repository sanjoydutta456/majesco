PROMPT
PROMPT ==============================================
PROMPT Executing verify-cleanup.sql
PROMPT ==============================================

SET VERIFY OFF
WHENEVER SQLERROR EXIT FAILURE ROLLBACK
WHENEVER OSERROR EXIT FAILURE
SET SERVEROUTPUT ON SIZE 1000000

DEFINE user=&1
DEFINE type=&2

DECLARE
    v_exists NUMBER;
    v_sql    VARCHAR2(1024);
BEGIN
    SELECT COUNT(1)
    INTO v_exists
    FROM dba_users
    WHERE UPPER(username) = UPPER('&&user');

    IF v_exists = 0 THEN
        DBMS_OUTPUT.PUT_LINE('&&user user not found.  Allow install path cleanup.');
        RETURN;
    ELSE
        SELECT COUNT(1)
        INTO v_exists
        FROM dba_tables
        WHERE owner = 'MIC_ADMIN'
          AND table_name = 'ZZZ_INSTALL_PATH_CAN_CLEANUP';

        IF v_exists = 0 THEN
            RAISE_APPLICATION_ERROR(-20000, 'ZZZ_INSTALL_PATH_CAN_CLEANUP does not exist.  Do not allow install path cleanup.', false);
        ELSE
            v_sql := 'SELECT COUNT(1) FROM MIC_ADMIN.zzz_install_path_can_cleanup WHERE UPPER(zipcc_type)=UPPER(''&&type'')';
            EXECUTE IMMEDIATE v_sql INTO v_exists;

            IF v_exists = 0 THEN
                RAISE_APPLICATION_ERROR(-20001, 'No entry for &&type in ZZZ_INSTALL_PATH_CAN_CLEANUP.  Do not allow install path cleanup.', true);
            ELSE
                DBMS_OUTPUT.PUT_LINE('&&type found in ZZZ_INSTALL_PATH_CAN_CLEANUP.  Allow install path cleanup.');
                RETURN;
            END IF;
        END IF;
    END IF;
END;
/


PROMPT ==============================================
PROMPT 

EXIT SUCCESS
