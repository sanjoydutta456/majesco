Testing:
    STANDARD
        run-debug.bat POLICYSID POLICYSYSTEMPASS CLASSICDBSERVER CLASSICDBPORT CLASSICSID 
    EXAMPLES
        run.bat tmic systemtmic micdb-qmic 1522 qmic > run.log 2>&1
        run-debug.bat splitexp systemsplitexp 10.255.248.53 9801 emic

Cleanup:
        sqlplus system/systemtmic@tmic @del-triggers.sql

If Needed (would also need temporary TNS entry for CLASSIC on NexGen):
        sqlplus mic_admin/mic_admin@CLASSIC @classic-int.sql CLASSICSID CC

To re-evaluate table FK dependencies:
        In g:\USER\public\ericb\projects\Classic-NexGen-split\trigger-tables>
        sqlplus mic_policy_ax/mic_policy_ax@splitexp @table-fk-analysis.sql MIS_POLICIES
        sqlplus mic_policy_ax/mic_policy_ax@splitexp @table-fk-analysis.sql MIS_POLICY_INSTALLMENTS

To verify transaction between environments:
        sqlplus mic_ax/mic_ax@emic @validate Q AIX-WK-0000001 000
        sqlplus mic_ax/mic_ax@splitexp @validate Q AIX-WK-0000001 000
