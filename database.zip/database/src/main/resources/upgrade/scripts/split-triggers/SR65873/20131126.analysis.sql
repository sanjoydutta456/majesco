PROMPT
PROMPT =====================================================
PROMPT Executing 20131126.analysis.sql
PROMPT =====================================================
-- common

SELECT mpo_company_policy_number, mpo_policy_reference
FROM mis_policies
WHERE mpo_company_policy_number IN ('LSR-WK-0010131-4', 'M60-WK-0010004-3')
ORDER BY 1, 2;

SELECT * 
FROM debug_msgs
WHERE dbg_msg LIKE '%MFO%P10WK0292613934000%'
ORDER BY 1 desc;

-- policy

SELECT mpo_company_policy_number, mpo_policy_reference, mfo.*
FROM mis_policies, mis_forms mfo
WHERE mpo_policy_reference = mfo_policy_reference
  AND mpo_company_policy_number IN ('LSR-WK-0010131-4', 'M60-WK-0010004-3')
ORDER BY 1, 2, 3;

SELECT mpo_company_policy_number, mpo_policy_reference, mfv.*
FROM mis_policies, mis_form_vars mfv
WHERE mpo_policy_reference = mfv_policy_reference
  AND mpo_company_policy_number IN ('LSR-WK-0010131-4', 'M60-WK-0010004-3')
ORDER BY 1, 2, 3;

PROMPT =====================================
PROMPT