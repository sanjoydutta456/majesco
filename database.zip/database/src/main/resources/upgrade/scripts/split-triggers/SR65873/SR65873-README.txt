
REM Test Date: 07/22/2013
REM QA Date:   09/01/2013
REM Prod Date: 09/01/2013

REM Load latest sync
run-debug.bat TMIC systemtmic mictestdb 1521 TMIC

REM Pre-run counts and log

REM    MFV.(Policy - MFV/MRV Counts from date)
REM  + MFV.(Policy - MFV Counts for post-split transactions, with pre-split MFV)
REM  ===========================================================================
REM    MFV_COUNT.(Policy - MFV/MRV Counts for post-split transactions)

REM From "Classic - MFV/MRV Counts for post-split transactions", there may be
REM some existing from the split itself.  But the final validation in the
REM datafix log should match up between Classic and Policy

sqlplus mic_common_ax/mic_common_ax@tmic @SR65873-counts.sql 07/22/2013
move SR65873-counts.log SR65873-counts.0.before.log

REM Run datafix and validation
sqlplus mic_common_ax/mic_common_ax@tmic @SR65873-datafix-mfv.sql 07/22/2013

sqlplus mic_common_ax/mic_common_ax@tmic @SR65873-counts.sql 07/22/2013
move SR65873-counts.log SR65873-counts.0.after.log
