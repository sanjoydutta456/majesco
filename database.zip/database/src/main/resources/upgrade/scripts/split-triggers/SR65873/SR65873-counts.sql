PROMPT
PROMPT =====================================================
PROMPT Executing SR65873-counts.sql
PROMPT =====================================================

SPOOL SR65873-counts.log
SET PAGESIZE 50000
SET VERIFY OFF

--DEFINE SPLITDATE=07/22/2013
--DEFINE SPLITDATE=09/01/2013
DEFINE SPLITDATE=&1
DEFINE dblink=SPLITCLA

COLUMN polref FORMAT A20 TRUNCATE
COLUMN company_pol FORMAT A20 TRUNCATE

PROMPT
PROMPT =========================
PROMPT Policy - MFV/MRV Total Counts
PROMPT =========================
SELECT
   (SELECT count(*) mfv FROM mis_form_vars) mfv,
   (SELECT count(*) mfv_trans
    FROM (
        SELECT mfv_policy_reference, count(*)
        FROM mis_form_vars
        GROUP BY mfv_policy_reference)) mfv_trans,
   (SELECT count(*) mrv FROM mis_form_richtext_vars) mrv,
   (SELECT count(*) mrv_trans
    FROM (
        SELECT mfv_policy_reference, count(*)
        FROM mis_form_vars, mis_form_richtext_vars
        WHERE mrv_form_var_id = mfv_id
        GROUP BY mfv_policy_reference)) mrv_trans
FROM dual
;

PROMPT
PROMPT =========================
PROMPT Policy - MFV/MRV Counts from date
PROMPT =========================
SELECT
   (SELECT count(*) mfv FROM mis_form_vars WHERE mfv_date_created > TRUNC(TO_DATE('&&SPLITDATE', 'MM/DD/YYYY'))) mfv,
   (SELECT count(*) mfv_trans
    FROM (
        SELECT mfv_policy_reference, count(*)
        FROM mis_form_vars
        WHERE mfv_date_created > TRUNC(TO_DATE('&&SPLITDATE', 'MM/DD/YYYY'))
        GROUP BY mfv_policy_reference)) mfv_trans,
   (SELECT count(*) mrv FROM mis_form_richtext_vars WHERE mrv_date_created > TRUNC(TO_DATE('&&SPLITDATE', 'MM/DD/YYYY'))) mrv,
   (SELECT count(*) mrv_trans
    FROM (
        SELECT mfv_policy_reference, count(*)
        FROM mis_form_vars, mis_form_richtext_vars
        WHERE mrv_form_var_id = mfv_id
          AND mfv_date_created > TRUNC(TO_DATE('&&SPLITDATE', 'MM/DD/YYYY'))
        GROUP BY mfv_policy_reference)) mrv_trans
FROM dual
;

PROMPT
PROMPT =========================
PROMPT Policy - MFV Counts for post-split transactions, with pre-split MFV
PROMPT =========================
 --distinct mfv_policy_reference
SELECT 
    count(*) mfv
FROM 
    mis_form_vars mfv,
   (
    SELECT distinct wah_entity_reference
    FROM wfl_activity_history
    WHERE wah_task_id = (SELECT wta_id FROM wfl_tasks WHERE wta_name = 'FORMSMANAGEMENT')
      AND wah_date_created > TRUNC(TO_DATE('&&SPLITDATE', 'MM/DD/YYYY'))
     --AND wah_entity_reference IN ('Q10CA0008008530000')
   ) wah
WHERE wah_entity_reference = mfv_policy_reference
  AND mfv_date_created < TRUNC(TO_DATE('&&SPLITDATE', 'MM/DD/YYYY'))
;

PROMPT
PROMPT =========================
PROMPT Policy - MFV/MRV Counts for post-split transactions
PROMPT =========================
SELECT SUM(mfv_count) mfv_count, SUM(mrv_count) mrv_count
FROM 
   (
    SELECT
        wah_entity_reference polref,
        (SELECT mpo_company_policy_number FROM mis_policies WHERE mpo_policy_reference = wah_entity_reference) company_pol,
        (SELECT count(*) FROM mis_form_vars WHERE mfv_policy_reference = wah_entity_reference) mfv_count,
        (SELECT count(*) FROM mis_form_richtext_vars, mis_form_vars WHERE mrv_form_var_id = mfv_id AND mfv_policy_reference = wah_entity_reference) mrv_count
    FROM 
       (
        SELECT distinct wah_entity_reference
        FROM wfl_activity_history
        WHERE wah_task_id = (SELECT wta_id FROM wfl_tasks WHERE wta_name = 'FORMSMANAGEMENT')
          AND wah_date_created > TRUNC(TO_DATE('&&SPLITDATE', 'MM/DD/YYYY'))
         --AND wah_entity_reference IN ('Q10CA0008008530000')
       )
   )
;

PROMPT
PROMPT =========================
PROMPT Classic - MFV/MRV Counts for post-split transactions
PROMPT =========================
SELECT SUM(mfv_count) mfv_count, SUM(mrv_count) mrv_count
FROM 
   (
    SELECT
        wah_entity_reference polref,
        (SELECT mpo_company_policy_number FROM mis_policies@&&dblink WHERE mpo_policy_reference = wah_entity_reference) company_pol,
        (SELECT count(*) FROM mis_form_vars@&&dblink WHERE mfv_policy_reference = wah_entity_reference) mfv_count,
        (SELECT count(*) FROM mis_form_richtext_vars@&&dblink, mis_form_vars@&&dblink WHERE mrv_form_var_id = mfv_id AND mfv_policy_reference = wah_entity_reference) mrv_count
    FROM 
       (
        SELECT distinct wah_entity_reference
        FROM wfl_activity_history
        WHERE wah_task_id = (SELECT wta_id FROM wfl_tasks WHERE wta_name = 'FORMSMANAGEMENT')
          AND wah_date_created > TRUNC(TO_DATE('&&SPLITDATE', 'MM/DD/YYYY'))
         --AND wah_entity_reference IN ('Q10CA0008008530000')
       )
   )
;

PROMPT
PROMPT =========================
PROMPT Policy - MFV/MRV Counts for post-split transactions by transaction
PROMPT =========================
SELECT
    wah_entity_reference polref,
    (SELECT mpo_company_policy_number FROM mis_policies WHERE mpo_policy_reference = wah_entity_reference) company_pol,
    (SELECT count(*) FROM mis_form_vars WHERE mfv_policy_reference = wah_entity_reference) mfv_count,
    (SELECT count(*) FROM mis_form_richtext_vars, mis_form_vars WHERE mrv_form_var_id = mfv_id AND mfv_policy_reference = wah_entity_reference) mrv_count
FROM 
   (
    SELECT distinct wah_entity_reference
    FROM wfl_activity_history
    WHERE wah_task_id = (SELECT wta_id FROM wfl_tasks WHERE wta_name = 'FORMSMANAGEMENT')
      AND wah_date_created > TRUNC(TO_DATE('&&SPLITDATE', 'MM/DD/YYYY'))
     --AND wah_entity_reference IN ('Q10CA0008008530000')
   )
ORDER BY 1;

PROMPT
PROMPT =========================
PROMPT Classic - MFV/MRV Counts for post-split transactions by transaction
PROMPT =========================
SELECT
    wah_entity_reference polref,
    (SELECT mpo_company_policy_number FROM mis_policies@&&dblink WHERE mpo_policy_reference = wah_entity_reference) company_pol,
    (SELECT count(*) FROM mis_form_vars@&&dblink WHERE mfv_policy_reference = wah_entity_reference) mfv_count,
    (SELECT count(*) FROM mis_form_richtext_vars@&&dblink, mis_form_vars@&&dblink WHERE mrv_form_var_id = mfv_id AND mfv_policy_reference = wah_entity_reference) mrv_count
FROM 
   (
    SELECT distinct wah_entity_reference
    FROM wfl_activity_history
    WHERE wah_task_id = (SELECT wta_id FROM wfl_tasks WHERE wta_name = 'FORMSMANAGEMENT')
      AND wah_date_created > TRUNC(TO_DATE('&&SPLITDATE', 'MM/DD/YYYY'))
     --AND wah_entity_reference IN ('Q10CA0008008530000')
   )
ORDER BY 1;

PROMPT =====================================
PROMPT
EXIT
