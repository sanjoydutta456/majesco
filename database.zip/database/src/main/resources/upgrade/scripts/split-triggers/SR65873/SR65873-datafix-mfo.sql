PROMPT
PROMPT =====================================================
PROMPT Executing SR65873-datafix-mfo.sql
PROMPT =====================================================

SET SERVEROUTPUT ON SIZE 1000000
SET LINE 256
SET PAGESIZE 50000
SET VERIFY OFF

COLUMN company_pol FORMAT A20 TRUNCATE
COLUMN polref FORMAT A20 TRUNCATE

SPOOL SR65873-datafix-mfo.log

--DEFINE SPLITDATE=07/22/2013
--DEFINE SPLITDATE=09/01/2013
DEFINE SPLITDATE=&1
DEFINE INDEXTBSP=IIPD
DEFINE LABEL=Datafix_MFO_20131202
DEFINE dblink=SPLITCLA

/*
ANALYSIS:
1. check if any new MFV entries since split
    a. if there are, make sure they are only for Classic

DATAFIX:
1. Loop through Policy WAH.  For each FORMSMANAGEMENT since split:
    a. IF polref does not exist in MPO
        1. DELETE Classic MFV entries for polref
    b. IF polref does exist in MPO
        1. DELETE Classic MFV entries for polref
        2. For each MFV for polref
            a. INSERT INTO Classic MFV
*/


PROMPT
PROMPT =========================
PROMPT BEFORE Policy
PROMPT =========================
SELECT
    mpo_company_policy_number company_pol,
    mpo_policy_reference polref,
    (SELECT count(*) FROM mis_forms WHERE mfo_policy_reference = mpo_policy_reference) mfo,
    (SELECT count(*) FROM mis_form_vars WHERE mfv_policy_reference = mpo_policy_reference) mfv,
    (SELECT count(*) FROM mis_form_richtext_vars WHERE mrv_form_var_id IN (SELECT mfv_id FROM mis_form_vars WHERE mfv_policy_reference = mpo_policy_reference)) mrv
FROM mis_policies
WHERE mpo_policy_reference IN (
        SELECT distinct wah_entity_reference
        FROM wfl_activity_history
        WHERE wah_task_id = (SELECT wta_id FROM wfl_tasks WHERE wta_name = 'FORMSMANAGEMENT')
          AND wah_date_created > TRUNC(TO_DATE('&&SPLITDATE', 'MM/DD/YYYY')))
GROUP BY mpo_company_policy_number, mpo_policy_reference
ORDER BY 2
;

PROMPT
PROMPT =========================
PROMPT BEFORE Classic
PROMPT =========================
SELECT
    mpo_company_policy_number company_pol,
    mpo_policy_reference polref,
    (SELECT count(*) FROM mis_forms@&&dblink WHERE mfo_policy_reference = mpo_policy_reference) mfo,
    (SELECT count(*) FROM mis_form_vars@&&dblink WHERE mfv_policy_reference = mpo_policy_reference) mfv,
    (SELECT count(*) FROM mis_form_richtext_vars@&&dblink WHERE mrv_form_var_id IN (SELECT mfv_id FROM mis_form_vars@&&dblink WHERE mfv_policy_reference = mpo_policy_reference)) mrv
FROM mis_policies@&&dblink
WHERE mpo_policy_reference IN (
        SELECT distinct wah_entity_reference
        FROM wfl_activity_history
        WHERE wah_task_id = (SELECT wta_id FROM wfl_tasks WHERE wta_name = 'FORMSMANAGEMENT')
          AND wah_date_created > TRUNC(TO_DATE('&&SPLITDATE', 'MM/DD/YYYY')))
GROUP BY mpo_company_policy_number, mpo_policy_reference
ORDER BY 2
;

PROMPT
PROMPT =========================
PROMPT BEFORE Classic/Policy differ
PROMPT =========================
SELECT
    policy.company_pol,
    policy.polref,
    policy.mfo,
    classic.mfo,
    policy.mfv,
    classic.mfv,
    policy.mrv,
    classic.mrv
FROM
   (
    SELECT
        mpo_company_policy_number company_pol,
        mpo_policy_reference polref,
        (SELECT count(*) FROM mis_forms WHERE mfo_policy_reference = mpo_policy_reference) mfo,
        (SELECT count(*) FROM mis_form_vars WHERE mfv_policy_reference = mpo_policy_reference) mfv,
        (SELECT count(*) FROM mis_form_richtext_vars WHERE mrv_form_var_id IN (SELECT mfv_id FROM mis_form_vars WHERE mfv_policy_reference = mpo_policy_reference)) mrv
    FROM mis_policies
    WHERE mpo_policy_reference IN (
            SELECT distinct wah_entity_reference
            FROM wfl_activity_history
            WHERE wah_task_id = (SELECT wta_id FROM wfl_tasks WHERE wta_name = 'FORMSMANAGEMENT')
              AND wah_date_created > TRUNC(TO_DATE('&&SPLITDATE', 'MM/DD/YYYY')))
    GROUP BY mpo_company_policy_number, mpo_policy_reference
   ) policy,
   (
    SELECT
        mpo_company_policy_number company_pol,
        mpo_policy_reference polref,
        (SELECT count(*) FROM mis_forms@&&dblink WHERE mfo_policy_reference = mpo_policy_reference) mfo,
        (SELECT count(*) FROM mis_form_vars@&&dblink WHERE mfv_policy_reference = mpo_policy_reference) mfv,
        (SELECT count(*) FROM mis_form_richtext_vars@&&dblink WHERE mrv_form_var_id IN (SELECT mfv_id FROM mis_form_vars@&&dblink WHERE mfv_policy_reference = mpo_policy_reference)) mrv
    FROM mis_policies@&&dblink
    WHERE mpo_policy_reference IN (
            SELECT distinct wah_entity_reference
            FROM wfl_activity_history
            WHERE wah_task_id = (SELECT wta_id FROM wfl_tasks WHERE wta_name = 'FORMSMANAGEMENT')
              AND wah_date_created > TRUNC(TO_DATE('&&SPLITDATE', 'MM/DD/YYYY')))
    GROUP BY mpo_company_policy_number, mpo_policy_reference
   ) classic
WHERE policy.polref = classic.polref
  AND (policy.mfo != classic.mfo
       OR policy.mfv != classic.mfv
       OR policy.mrv != classic.mrv)
ORDER BY 1, 2;

PROMPT
PROMPT =========================
PROMPT Prepare
PROMPT =========================
DECLARE
    v_exists NUMBER;
BEGIN
    SELECT count(*)
    INTO v_exists
    FROM user_tables
    WHERE table_name = 'DEBUG_DATAFIX';

    IF v_exists = 0 THEN
        EXECUTE IMMEDIATE 'CREATE TABLE DEBUG_DATAFIX(dbd_label VARCHAR2(32), dbd_entityref VARCHAR2(20), dbd_msg VARCHAR2(4000), dbd_date_created DATE)';
        DBMS_OUTPUT.PUT_LINE('DEBUG_DATAFIX created');
    END IF;

    SELECT count(*)
    INTO v_exists
    FROM user_indexes
    WHERE index_name = 'DEBUG_DATAFIX_NU1';

    IF v_exists = 0 THEN
        EXECUTE IMMEDIATE 'CREATE INDEX DEBUG_DATAFIX_NU1 ON DEBUG_DATAFIX(dbd_label) TABLESPACE &&INDEXTBSP';
        DBMS_OUTPUT.PUT_LINE('DEBUG_DATAFIX_NU1 created');
    END IF;

    SELECT count(*)
    INTO v_exists
    FROM user_indexes
    WHERE index_name = 'DEBUG_DATAFIX_NU2';

    IF v_exists = 0 THEN
        EXECUTE IMMEDIATE 'CREATE INDEX DEBUG_DATAFIX_NU2 ON DEBUG_DATAFIX(dbd_entityref) TABLESPACE &&INDEXTBSP';
        DBMS_OUTPUT.PUT_LINE('DEBUG_DATAFIX_NU2 created');
    END IF;

END;
/

PROMPT
PROMPT =========================
PROMPT Run
PROMPT =========================
DECLARE
    v_trg_id NUMBER;
    v_mrv_id NUMBER;

    v_status VARCHAR2(4000);
    v_exists_mfo NUMBER;
    v_exists_dbd NUMBER;
    v_count_mrv NUMBER;

    v_processed NUMBER := 0;
    v_skipped NUMBER := 0;
BEGIN
    FOR rec IN
           (SELECT distinct wah_entity_reference
            FROM wfl_activity_history
            WHERE wah_task_id = (SELECT wta_id FROM wfl_tasks WHERE wta_name = 'FORMSMANAGEMENT')
              AND wah_date_created > TRUNC(TO_DATE('&&SPLITDATE', 'MM/DD/YYYY'))
              --AND wah_entity_reference IN ('Q10CA0008008530000')
            ORDER BY 1
           )
    LOOP
        v_status := 'Datafix MFO:' || rec.wah_entity_reference ||':';

        SELECT count(*)
        INTO v_exists_dbd
        FROM debug_datafix
        WHERE dbd_label = '&&LABEL'
          AND dbd_entityref = rec.wah_entity_reference;

        IF v_exists_dbd = 0 THEN
            v_processed := v_processed + 1;

            SELECT count(*)
            INTO v_exists_mfo
            FROM mis_forms
            WHERE mfo_policy_reference = rec.wah_entity_reference;
    
            DELETE FROM mis_forms@&&dblink
            WHERE mfo_policy_reference = rec.wah_entity_reference;
            
            v_status := v_status || CHR(10) ||'D:' || 'mfo:' || SQL%ROWCOUNT ||':';
            
            IF v_exists_mfo > 0 THEN
                INSERT INTO mis_forms@&&dblink
                    (MFO_POLICY_REFERENCE, MFO_COVERAGE_PART_REFERENCE, MFO_FORM_NUMBER, MFO_REVISION_NUMBER, MFO_FORM_EDITION_DATE, MFO_DATE_CREATED, MFO_DATE_MODIFIED, MFO_USER_DELETE_OVERRIDE, MFO_MANUAL_ATTACH, MFO_RANK, MFO_ENTITY_TYPE, MFO_INCLUDE, MFO_OCCURRENCE, MFO_TITLE, MFO_USER_CREATED, MFO_USER_MODIFIED, MFO_CUSTOM_FORM_NUMBER, MFO_CUSTOM_FORM_EDITION_DATE, MFO_ADDED_BY_SHOWALL, MFO_QUALIFYING_LOBS)
                    SELECT
                        MFO_POLICY_REFERENCE, MFO_COVERAGE_PART_REFERENCE, MFO_FORM_NUMBER, MFO_REVISION_NUMBER, MFO_FORM_EDITION_DATE, MFO_DATE_CREATED, MFO_DATE_MODIFIED, MFO_USER_DELETE_OVERRIDE, MFO_MANUAL_ATTACH, MFO_RANK, MFO_ENTITY_TYPE, MFO_INCLUDE, MFO_OCCURRENCE, MFO_TITLE, MFO_USER_CREATED, MFO_USER_MODIFIED, MFO_CUSTOM_FORM_NUMBER, MFO_CUSTOM_FORM_EDITION_DATE, MFO_ADDED_BY_SHOWALL, MFO_QUALIFYING_LOBS
                    FROM mis_forms
                    WHERE mfo_policy_reference = rec.wah_entity_reference;

                v_status := v_status || CHR(10) ||'I:' || 'mfo:' || SQL%ROWCOUNT ||':';

            END IF;
    
            INSERT INTO debug_datafix(dbd_label, dbd_entityref, dbd_msg, dbd_date_created) VALUES('&&LABEL', rec.wah_entity_reference, v_status, sysdate);
    
            COMMIT;
        ELSE
            v_skipped := v_skipped + 1;
        END IF;
    END LOOP;

    DBMS_OUTPUT.PUT_LINE('Processed: ' || v_processed);
    DBMS_OUTPUT.PUT_LINE('Skipped  : ' || v_skipped);
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    DBMS_OUTPUT.PUT_LINE('ERROR: processing:');
    DBMS_OUTPUT.PUT_LINE(SUBSTR(v_status, 1, 255));
    DBMS_OUTPUT.PUT_LINE(SQLCODE);
    DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 255));
END;
/

PROMPT
PROMPT =========================
PROMPT AFTER Policy
PROMPT =========================
SELECT
    (SELECT mpo_company_policy_number FROM mis_policies WHERE mpo_policy_reference = dbd_entityref) company_pol,
    dbd_entityref polref,
    (SELECT count(*) FROM mis_forms WHERE mfo_policy_reference = dbd_entityref) mfo,
    (SELECT count(*) FROM mis_form_vars WHERE mfv_policy_reference = dbd_entityref) mfv,
    (SELECT count(*) FROM mis_form_richtext_vars WHERE mrv_form_var_id IN (SELECT mfv_id FROM mis_form_vars WHERE mfv_policy_reference = dbd_entityref)) mrv
FROM debug_datafix
WHERE dbd_label = '&&LABEL'
ORDER BY 2
;

PROMPT
PROMPT =========================
PROMPT AFTER Classic
PROMPT =========================
SELECT
    (SELECT mpo_company_policy_number FROM mis_policies@&&dblink WHERE mpo_policy_reference = dbd_entityref) company_pol,
    dbd_entityref polref,
    (SELECT count(*) FROM mis_forms@&&dblink WHERE mfo_policy_reference = dbd_entityref) mfo,
    (SELECT count(*) FROM mis_form_vars@&&dblink WHERE mfv_policy_reference = dbd_entityref) mfv,
    (SELECT count(*) FROM mis_form_richtext_vars@&&dblink WHERE mrv_form_var_id IN (SELECT mfv_id FROM mis_form_vars@&&dblink WHERE mfv_policy_reference = dbd_entityref)) mrv
FROM debug_datafix
WHERE dbd_label = '&&LABEL'
ORDER BY 2
;

PROMPT
PROMPT =========================
PROMPT AFTER Classic/Policy differ
PROMPT =========================
SELECT
    policy.company_pol,
    policy.polref,
    policy.mfo,
    classic.mfo,
    policy.mfv,
    classic.mfv,
    policy.mrv,
    classic.mrv
FROM
   (
    SELECT
        mpo_company_policy_number company_pol,
        mpo_policy_reference polref,
        (SELECT count(*) FROM mis_forms WHERE mfo_policy_reference = mpo_policy_reference) mfo,
        (SELECT count(*) FROM mis_form_vars WHERE mfv_policy_reference = mpo_policy_reference) mfv,
        (SELECT count(*) FROM mis_form_richtext_vars WHERE mrv_form_var_id IN (SELECT mfv_id FROM mis_form_vars WHERE mfv_policy_reference = mpo_policy_reference)) mrv
    FROM mis_policies
    WHERE mpo_policy_reference IN (
            SELECT distinct wah_entity_reference
            FROM wfl_activity_history
            WHERE wah_task_id = (SELECT wta_id FROM wfl_tasks WHERE wta_name = 'FORMSMANAGEMENT')
              AND wah_date_created > TRUNC(TO_DATE('&&SPLITDATE', 'MM/DD/YYYY')))
    GROUP BY mpo_company_policy_number, mpo_policy_reference
   ) policy,
   (
    SELECT
        mpo_company_policy_number company_pol,
        mpo_policy_reference polref,
        (SELECT count(*) FROM mis_forms@&&dblink WHERE mfo_policy_reference = mpo_policy_reference) mfo,
        (SELECT count(*) FROM mis_form_vars@&&dblink WHERE mfv_policy_reference = mpo_policy_reference) mfv,
        (SELECT count(*) FROM mis_form_richtext_vars@&&dblink WHERE mrv_form_var_id IN (SELECT mfv_id FROM mis_form_vars@&&dblink WHERE mfv_policy_reference = mpo_policy_reference)) mrv
    FROM mis_policies@&&dblink
    WHERE mpo_policy_reference IN (
            SELECT distinct wah_entity_reference
            FROM wfl_activity_history
            WHERE wah_task_id = (SELECT wta_id FROM wfl_tasks WHERE wta_name = 'FORMSMANAGEMENT')
              AND wah_date_created > TRUNC(TO_DATE('&&SPLITDATE', 'MM/DD/YYYY')))
    GROUP BY mpo_company_policy_number, mpo_policy_reference
   ) classic
WHERE policy.polref = classic.polref
  AND (policy.mfo != classic.mfo
       OR policy.mfv != classic.mfv
       OR policy.mrv != classic.mrv)
ORDER BY 1, 2;


PROMPT =====================================
PROMPT
EXIT
