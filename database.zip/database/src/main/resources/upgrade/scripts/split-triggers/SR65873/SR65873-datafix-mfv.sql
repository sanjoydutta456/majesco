PROMPT
PROMPT =====================================================
PROMPT Executing SR65873-datafix-mfv.sql
PROMPT =====================================================

SET SERVEROUTPUT ON SIZE 1000000
SET LINE 256
SET PAGESIZE 50000
SET VERIFY OFF

COLUMN company_pol FORMAT A20 TRUNCATE
COLUMN polref FORMAT A20 TRUNCATE

SPOOL SR65873-datafix-mfv.log

--DEFINE SPLITDATE=07/22/2013
--DEFINE SPLITDATE=09/01/2013
DEFINE SPLITDATE=&1
DEFINE INDEXTBSP=IIPD
DEFINE LABEL=Datafix_MFV_201311
DEFINE dblink=SPLITCLA

/*
ANALYSIS:
1. check if any new MFV entries since split
    a. if there are, make sure they are only for Classic

DATAFIX:
1. Loop through Policy WAH.  For each FORMSMANAGEMENT since split:
    a. IF polref does not exist in MPO
        1. DELETE Classic MFV entries for polref
    b. IF polref does exist in MPO
        1. DELETE Classic MFV entries for polref
        2. For each MFV for polref
            a. INSERT INTO Classic MFV
*/


PROMPT
PROMPT =========================
PROMPT BEFORE Policy
PROMPT =========================
SELECT
    mpo_company_policy_number company_pol,
    mpo_policy_reference polref,
    (SELECT count(*) FROM mis_forms WHERE mfo_policy_reference = mpo_policy_reference) mfo,
    (SELECT count(*) FROM mis_form_vars WHERE mfv_policy_reference = mpo_policy_reference) mfv,
    (SELECT count(*) FROM mis_form_richtext_vars WHERE mrv_form_var_id IN (SELECT mfv_id FROM mis_form_vars WHERE mfv_policy_reference = mpo_policy_reference)) mrv
FROM mis_policies
WHERE mpo_policy_reference IN (
        SELECT distinct wah_entity_reference
        FROM wfl_activity_history
        WHERE wah_task_id = (SELECT wta_id FROM wfl_tasks WHERE wta_name = 'FORMSMANAGEMENT')
          AND wah_date_created > TRUNC(TO_DATE('&&SPLITDATE', 'MM/DD/YYYY')))
GROUP BY mpo_company_policy_number, mpo_policy_reference
ORDER BY 2
;

PROMPT
PROMPT =========================
PROMPT BEFORE Classic
PROMPT =========================
SELECT
    mpo_company_policy_number company_pol,
    mpo_policy_reference polref,
    (SELECT count(*) FROM mis_forms@&&dblink WHERE mfo_policy_reference = mpo_policy_reference) mfo,
    (SELECT count(*) FROM mis_form_vars@&&dblink WHERE mfv_policy_reference = mpo_policy_reference) mfv,
    (SELECT count(*) FROM mis_form_richtext_vars@&&dblink WHERE mrv_form_var_id IN (SELECT mfv_id FROM mis_form_vars@&&dblink WHERE mfv_policy_reference = mpo_policy_reference)) mrv
FROM mis_policies@&&dblink
WHERE mpo_policy_reference IN (
        SELECT distinct wah_entity_reference
        FROM wfl_activity_history
        WHERE wah_task_id = (SELECT wta_id FROM wfl_tasks WHERE wta_name = 'FORMSMANAGEMENT')
          AND wah_date_created > TRUNC(TO_DATE('&&SPLITDATE', 'MM/DD/YYYY')))
GROUP BY mpo_company_policy_number, mpo_policy_reference
ORDER BY 2
;

PROMPT
PROMPT =========================
PROMPT BEFORE Classic/Policy differ
PROMPT =========================
SELECT
    policy.company_pol,
    policy.polref,
    policy.mfo,
    classic.mfo,
    policy.mfv,
    classic.mfv,
    policy.mrv,
    classic.mrv
FROM
   (
    SELECT
        mpo_company_policy_number company_pol,
        mpo_policy_reference polref,
        (SELECT count(*) FROM mis_forms WHERE mfo_policy_reference = mpo_policy_reference) mfo,
        (SELECT count(*) FROM mis_form_vars WHERE mfv_policy_reference = mpo_policy_reference) mfv,
        (SELECT count(*) FROM mis_form_richtext_vars WHERE mrv_form_var_id IN (SELECT mfv_id FROM mis_form_vars WHERE mfv_policy_reference = mpo_policy_reference)) mrv
    FROM mis_policies
    WHERE mpo_policy_reference IN (
            SELECT distinct wah_entity_reference
            FROM wfl_activity_history
            WHERE wah_task_id = (SELECT wta_id FROM wfl_tasks WHERE wta_name = 'FORMSMANAGEMENT')
              AND wah_date_created > TRUNC(TO_DATE('&&SPLITDATE', 'MM/DD/YYYY')))
    GROUP BY mpo_company_policy_number, mpo_policy_reference
   ) policy,
   (
    SELECT
        mpo_company_policy_number company_pol,
        mpo_policy_reference polref,
        (SELECT count(*) FROM mis_forms@&&dblink WHERE mfo_policy_reference = mpo_policy_reference) mfo,
        (SELECT count(*) FROM mis_form_vars@&&dblink WHERE mfv_policy_reference = mpo_policy_reference) mfv,
        (SELECT count(*) FROM mis_form_richtext_vars@&&dblink WHERE mrv_form_var_id IN (SELECT mfv_id FROM mis_form_vars@&&dblink WHERE mfv_policy_reference = mpo_policy_reference)) mrv
    FROM mis_policies@&&dblink
    WHERE mpo_policy_reference IN (
            SELECT distinct wah_entity_reference
            FROM wfl_activity_history
            WHERE wah_task_id = (SELECT wta_id FROM wfl_tasks WHERE wta_name = 'FORMSMANAGEMENT')
              AND wah_date_created > TRUNC(TO_DATE('&&SPLITDATE', 'MM/DD/YYYY')))
    GROUP BY mpo_company_policy_number, mpo_policy_reference
   ) classic
WHERE policy.polref = classic.polref
  AND (policy.mfo != classic.mfo
       OR policy.mfv != classic.mfv
       OR policy.mrv != classic.mrv)
ORDER BY 1, 2;

PROMPT
PROMPT =========================
PROMPT Prepare
PROMPT =========================
DECLARE
    v_exists NUMBER;
BEGIN
    SELECT count(*)
    INTO v_exists
    FROM user_tables
    WHERE table_name = 'DEBUG_DATAFIX';

    IF v_exists = 0 THEN
        EXECUTE IMMEDIATE 'CREATE TABLE DEBUG_DATAFIX(dbd_label VARCHAR2(32), dbd_entityref VARCHAR2(20), dbd_msg VARCHAR2(4000), dbd_date_created DATE)';
        DBMS_OUTPUT.PUT_LINE('DEBUG_DATAFIX created');
    END IF;

    SELECT count(*)
    INTO v_exists
    FROM user_indexes
    WHERE index_name = 'DEBUG_DATAFIX_NU1';

    IF v_exists = 0 THEN
        EXECUTE IMMEDIATE 'CREATE INDEX DEBUG_DATAFIX_NU1 ON DEBUG_DATAFIX(dbd_label) TABLESPACE &&INDEXTBSP';
        DBMS_OUTPUT.PUT_LINE('DEBUG_DATAFIX_NU1 created');
    END IF;

    SELECT count(*)
    INTO v_exists
    FROM user_indexes
    WHERE index_name = 'DEBUG_DATAFIX_NU2';

    IF v_exists = 0 THEN
        EXECUTE IMMEDIATE 'CREATE INDEX DEBUG_DATAFIX_NU2 ON DEBUG_DATAFIX(dbd_entityref) TABLESPACE &&INDEXTBSP';
        DBMS_OUTPUT.PUT_LINE('DEBUG_DATAFIX_NU2 created');
    END IF;

END;
/

PROMPT
PROMPT =========================
PROMPT Run
PROMPT =========================
DECLARE
    v_trg_id NUMBER;
    v_mrv_id NUMBER;

    v_status VARCHAR2(4000);
    v_exists_mfv NUMBER;
    v_exists_dbd NUMBER;
    v_count_mrv NUMBER;

    v_processed NUMBER := 0;
    v_skipped NUMBER := 0;
BEGIN
    FOR rec IN
           (SELECT distinct wah_entity_reference
            FROM wfl_activity_history
            WHERE wah_task_id = (SELECT wta_id FROM wfl_tasks WHERE wta_name = 'FORMSMANAGEMENT')
              AND wah_date_created > TRUNC(TO_DATE('&&SPLITDATE', 'MM/DD/YYYY'))
              --AND wah_entity_reference IN ('Q10CA0008008530000')
            ORDER BY 1
           )
    LOOP
        v_status := 'Datafix MFV:' || rec.wah_entity_reference ||':';

        SELECT count(*)
        INTO v_exists_dbd
        FROM debug_datafix
        WHERE dbd_label = '&&LABEL'
          AND dbd_entityref = rec.wah_entity_reference;

        IF v_exists_dbd = 0 THEN
            v_processed := v_processed + 1;

            SELECT count(*)
            INTO v_exists_mfv
            FROM mis_form_vars
            WHERE mfv_policy_reference = rec.wah_entity_reference;
    
            DELETE FROM mis_form_richtext_vars@&&dblink
            WHERE mrv_form_var_id IN
                   (SELECT mfv_id
                    FROM mis_form_vars@&&dblink
                    WHERE mfv_policy_reference = rec.wah_entity_reference);
            
            v_status := v_status || CHR(10) ||'D:' || 'mrv:' || SQL%ROWCOUNT ||':';
            
            DELETE FROM mis_form_vars@&&dblink
            WHERE mfv_policy_reference = rec.wah_entity_reference;
            

            v_status := v_status || CHR(10) ||'D:' || 'mfv:' || SQL%ROWCOUNT ||':';
    
            IF v_exists_mfv > 0 THEN
                INSERT INTO mis_form_vars@&&dblink
                    (MFV_ID, MFV_POLICY_REFERENCE, MFV_COVERAGE_PART_REFERENCE, MFV_FORM_NUMBER, MFV_REVISION_NUMBER, MFV_VAR_NAME, MFV_VAR_DESC, MFV_VAR_TYPE, MFV_VAR_SIZE, MFV_VAR_VALUE, MFV_USER_CREATED, MFV_DATE_CREATED, MFV_USER_MODIFIED, MFV_DATE_MODIFIED, MFV_ENTITY_TYPE, MFV_REQUIRED, MFV_OCCURRENCE, MFV_VAR_EXPRESSION, MFV_VAR_ORDER, MFV_VAR_DEFAULT_VALUE, MFV_VALIDATION_CRITERIA, MFV_ALLOW_SPACE)
                    SELECT
                        s_mfv_id_seq.nextval@&&dblink, MFV_POLICY_REFERENCE, MFV_COVERAGE_PART_REFERENCE, MFV_FORM_NUMBER, MFV_REVISION_NUMBER, MFV_VAR_NAME, MFV_VAR_DESC, MFV_VAR_TYPE, MFV_VAR_SIZE, MFV_VAR_VALUE, MFV_USER_CREATED, MFV_DATE_CREATED, MFV_USER_MODIFIED, MFV_DATE_MODIFIED, MFV_ENTITY_TYPE, MFV_REQUIRED, MFV_OCCURRENCE, MFV_VAR_EXPRESSION, MFV_VAR_ORDER, MFV_VAR_DEFAULT_VALUE, MFV_VALIDATION_CRITERIA, MFV_ALLOW_SPACE
                    FROM mis_form_vars
                    WHERE mfv_policy_reference = rec.wah_entity_reference;

                v_status := v_status || CHR(10) ||'I:' || 'mfv:' || SQL%ROWCOUNT ||':';

                v_count_mrv := 0;
                FOR recmrv IN
                       (SELECT *
                        FROM mis_form_vars, mis_form_richtext_vars
                        WHERE mfv_id = mrv_form_var_id
                          AND mfv_policy_reference = rec.wah_entity_reference)
                LOOP
                    SELECT mfv_id
                    INTO v_trg_id
                    FROM mis_form_vars@&&dblink
                    WHERE mfv_policy_reference = recmrv.mfv_policy_reference
                      AND mfv_coverage_part_reference = recmrv.mfv_coverage_part_reference
                      AND mfv_form_number = recmrv.mfv_form_number
                      AND mfv_var_name = recmrv.mfv_var_name
                      AND NVL(mfv_entity_type, '@@@@@') = NVL(recmrv.mfv_entity_type, '@@@@@')
                      AND NVL(mfv_occurrence, '-9999999999') = NVL(recmrv.mfv_occurrence, '-9999999999')
                      ;

                    SELECT s_mrv_id_seq.nextval@&&dblink
                    INTO v_mrv_id
                    FROM dual;

                    INSERT INTO mis_form_richtext_vars@&&dblink (mrv_id, mrv_form_var_id, mrv_form_var_value, mrv_date_created, mrv_user_created, mrv_date_modified, mrv_user_modified)
                    VALUES (v_mrv_id, v_trg_id, NULL, recmrv.mrv_date_created, recmrv.mrv_user_created, recmrv.mrv_date_modified, recmrv.mrv_user_modified);

                    v_count_mrv := v_count_mrv + SQL%ROWCOUNT;
                    
/*
                    UPDATE mis_form_richtext_vars@&&dblink
                    SET mrv_form_var_value = recmrv.mrv_form_var_value
                    WHERE mrv_id = v_mrv_id;
*/
                    UPDATE mis_form_richtext_vars@&&dblink
                    SET mrv_form_var_value = (SELECT mrv_form_var_value FROM mis_form_richtext_vars WHERE mrv_id = recmrv.mrv_id)
                    WHERE mrv_id = v_mrv_id;
                    
                END LOOP;

                v_status := v_status || CHR(10) ||'I:' || 'mrv:' || SQL%ROWCOUNT ||':';
            END IF;
    
            INSERT INTO debug_datafix(dbd_label, dbd_entityref, dbd_msg, dbd_date_created) VALUES('&&LABEL', rec.wah_entity_reference, v_status, sysdate);
    
            COMMIT;
        ELSE
            v_skipped := v_skipped + 1;
        END IF;
    END LOOP;

    DBMS_OUTPUT.PUT_LINE('Processed: ' || v_processed);
    DBMS_OUTPUT.PUT_LINE('Skipped  : ' || v_skipped);
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    DBMS_OUTPUT.PUT_LINE('ERROR: processing:');
    DBMS_OUTPUT.PUT_LINE(SUBSTR(v_status, 1, 255));
    DBMS_OUTPUT.PUT_LINE(SQLCODE);
    DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 255));
END;
/

PROMPT
PROMPT =========================
PROMPT AFTER Policy
PROMPT =========================
SELECT
    (SELECT mpo_company_policy_number FROM mis_policies WHERE mpo_policy_reference = dbd_entityref) company_pol,
    dbd_entityref polref,
    (SELECT count(*) FROM mis_forms WHERE mfo_policy_reference = dbd_entityref) mfo,
    (SELECT count(*) FROM mis_form_vars WHERE mfv_policy_reference = dbd_entityref) mfv,
    (SELECT count(*) FROM mis_form_richtext_vars WHERE mrv_form_var_id IN (SELECT mfv_id FROM mis_form_vars WHERE mfv_policy_reference = dbd_entityref)) mrv
FROM debug_datafix
WHERE dbd_label = '&&LABEL'
ORDER BY 2
;

PROMPT
PROMPT =========================
PROMPT AFTER Classic
PROMPT =========================
SELECT
    (SELECT mpo_company_policy_number FROM mis_policies@&&dblink WHERE mpo_policy_reference = dbd_entityref) company_pol,
    dbd_entityref polref,
    (SELECT count(*) FROM mis_forms@&&dblink WHERE mfo_policy_reference = dbd_entityref) mfo,
    (SELECT count(*) FROM mis_form_vars@&&dblink WHERE mfv_policy_reference = dbd_entityref) mfv,
    (SELECT count(*) FROM mis_form_richtext_vars@&&dblink WHERE mrv_form_var_id IN (SELECT mfv_id FROM mis_form_vars@&&dblink WHERE mfv_policy_reference = dbd_entityref)) mrv
FROM debug_datafix
WHERE dbd_label = '&&LABEL'
ORDER BY 2
;

PROMPT
PROMPT =========================
PROMPT AFTER Classic/Policy differ
PROMPT =========================
SELECT
    policy.company_pol,
    policy.polref,
    policy.mfo,
    classic.mfo,
    policy.mfv,
    classic.mfv,
    policy.mrv,
    classic.mrv
FROM
   (
    SELECT
        mpo_company_policy_number company_pol,
        mpo_policy_reference polref,
        (SELECT count(*) FROM mis_forms WHERE mfo_policy_reference = mpo_policy_reference) mfo,
        (SELECT count(*) FROM mis_form_vars WHERE mfv_policy_reference = mpo_policy_reference) mfv,
        (SELECT count(*) FROM mis_form_richtext_vars WHERE mrv_form_var_id IN (SELECT mfv_id FROM mis_form_vars WHERE mfv_policy_reference = mpo_policy_reference)) mrv
    FROM mis_policies
    WHERE mpo_policy_reference IN (
            SELECT distinct wah_entity_reference
            FROM wfl_activity_history
            WHERE wah_task_id = (SELECT wta_id FROM wfl_tasks WHERE wta_name = 'FORMSMANAGEMENT')
              AND wah_date_created > TRUNC(TO_DATE('&&SPLITDATE', 'MM/DD/YYYY')))
    GROUP BY mpo_company_policy_number, mpo_policy_reference
   ) policy,
   (
    SELECT
        mpo_company_policy_number company_pol,
        mpo_policy_reference polref,
        (SELECT count(*) FROM mis_forms@&&dblink WHERE mfo_policy_reference = mpo_policy_reference) mfo,
        (SELECT count(*) FROM mis_form_vars@&&dblink WHERE mfv_policy_reference = mpo_policy_reference) mfv,
        (SELECT count(*) FROM mis_form_richtext_vars@&&dblink WHERE mrv_form_var_id IN (SELECT mfv_id FROM mis_form_vars@&&dblink WHERE mfv_policy_reference = mpo_policy_reference)) mrv
    FROM mis_policies@&&dblink
    WHERE mpo_policy_reference IN (
            SELECT distinct wah_entity_reference
            FROM wfl_activity_history
            WHERE wah_task_id = (SELECT wta_id FROM wfl_tasks WHERE wta_name = 'FORMSMANAGEMENT')
              AND wah_date_created > TRUNC(TO_DATE('&&SPLITDATE', 'MM/DD/YYYY')))
    GROUP BY mpo_company_policy_number, mpo_policy_reference
   ) classic
WHERE policy.polref = classic.polref
  AND (policy.mfo != classic.mfo
       OR policy.mfv != classic.mfv
       OR policy.mrv != classic.mrv)
ORDER BY 1, 2;


PROMPT =====================================
PROMPT
EXIT
