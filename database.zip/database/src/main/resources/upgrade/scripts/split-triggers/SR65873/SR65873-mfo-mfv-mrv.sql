PROMPT
PROMPT =====================================================
PROMPT Executing SR65873-mfo-mfv-mrv.sql
PROMPT =====================================================

SET PAGESIZE 50000

SPOOL SR65873-mfo-mfv-mrv.log

COLUMN company_pol FORMAT A20 TRUNCATE
COLUMN polref FORMAT A20 TRUNCATE

SELECT
    policy.company_pol,
    policy.polref,
    policy.mfo,
    classic.mfo,
    policy.mfv,
    classic.mfv,
    policy.mrv,
    classic.mrv
FROM
   (
    SELECT
        mpo_company_policy_number company_pol,
        mpo_policy_reference polref,
        (SELECT count(*) FROM mis_forms WHERE mfo_policy_reference = mpo_policy_reference) mfo,
        (SELECT count(*) FROM mis_form_vars WHERE mfv_policy_reference = mpo_policy_reference) mfv,
        (SELECT count(*) FROM mis_form_richtext_vars WHERE mrv_form_var_id IN (SELECT mfv_id FROM mis_form_vars WHERE mfv_policy_reference = mpo_policy_reference)) mrv
    FROM mis_policies
    WHERE mpo_policy_reference IN (
            SELECT distinct wah_entity_reference
            FROM wfl_activity_history
            WHERE wah_task_id = (SELECT wta_id FROM wfl_tasks WHERE wta_name = 'FORMSMANAGEMENT')
              AND wah_date_created > TRUNC(TO_DATE('&&SPLITDATE', 'MM/DD/YYYY')))
    GROUP BY mpo_company_policy_number, mpo_policy_reference
   ) policy,
   (
    SELECT
        mpo_company_policy_number company_pol,
        mpo_policy_reference polref,
        (SELECT count(*) FROM mis_forms@&&dblink WHERE mfo_policy_reference = mpo_policy_reference) mfo,
        (SELECT count(*) FROM mis_form_vars@&&dblink WHERE mfv_policy_reference = mpo_policy_reference) mfv,
        (SELECT count(*) FROM mis_form_richtext_vars@&&dblink WHERE mrv_form_var_id IN (SELECT mfv_id FROM mis_form_vars@&&dblink WHERE mfv_policy_reference = mpo_policy_reference)) mrv
    FROM mis_policies@&&dblink
    WHERE mpo_policy_reference IN (
            SELECT distinct wah_entity_reference
            FROM wfl_activity_history
            WHERE wah_task_id = (SELECT wta_id FROM wfl_tasks WHERE wta_name = 'FORMSMANAGEMENT')
              AND wah_date_created > TRUNC(TO_DATE('&&SPLITDATE', 'MM/DD/YYYY')))
    GROUP BY mpo_company_policy_number, mpo_policy_reference
   ) classic
WHERE policy.polref = classic.polref
  AND (policy.mfo != classic.mfo
       OR policy.mfv != classic.mfv
       OR policy.mrv != classic.mrv)
ORDER BY 1, 2;

PROMPT =====================================
PROMPT
EXIT
