PROMPT
PROMPT =====================================================
PROMPT Executing aix_split-dblink.sql
PROMPT =====================================================

DEFINE user=&1
DEFINE dblink=&2
DEFINE classicserver=&3
DEFINE classicport=&4
DEFINE classicsid=&5

DROP PUBLIC DATABASE LINK &&dblink;

CREATE PUBLIC DATABASE LINK &&dblink
  CONNECT TO &&user IDENTIFIED BY &&user USING '(DESCRIPTION =
(ADDRESS = (PROTOCOL = TCP)(HOST = &&classicserver )(PORT = &&classicport ))
(CONNECT_DATA =
(SERVER = DEDICATED)
(SID = &&classicsid)
)
)';

PROMPT =====================================
PROMPT 

EXIT
