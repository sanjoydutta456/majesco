PROMPT
PROMPT =====================================================
PROMPT Executing classic-int.sql
PROMPT =====================================================

DEFINE SID=&1
DEFINE CC=&2

conn mic_policy_&&CC/mic_policy_&&CC@&&SID

GRANT ALL ON mis_policy_locations TO MIC_&&CC;
GRANT ALL ON mis_policy_unemployment_no TO MIC_&&CC;
GRANT ALL ON s_mpm_id_seq TO MIC_&&CC;
GRANT ALL ON s_mpa_id_seq TO MIC_&&CC;

conn mic_&&CC/mic_&&CC@&&SID

CREATE OR REPLACE SYNONYM MIS_POLICY_LOCATIONS FOR mic_policy_&&CC..MIS_POLICY_LOCATIONS;
CREATE OR REPLACE SYNONYM MIS_POLICY_UNEMPLOYMENT_NO FOR mic_policy_&&CC..MIS_POLICY_UNEMPLOYMENT_NO;
CREATE OR REPLACE SYNONYM S_MPM_ID_SEQ FOR mic_policy_&&CC..S_MPM_ID_SEQ;
CREATE OR REPLACE SYNONYM S_MPA_ID_SEQ FOR mic_policy_&&CC..S_MPA_ID_SEQ;

PROMPT =====================================
PROMPT 

EXIT
