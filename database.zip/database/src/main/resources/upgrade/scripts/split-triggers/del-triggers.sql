PROMPT
PROMPT =====================================================
PROMPT Executing del-triggers.sql
PROMPT =====================================================

-- as system
SET SERVEROUTPUT ON SIZE 1000000

DECLARE
    v_sql VARCHAR(32767) := '';
BEGIN
    FOR rec IN (SELECT owner, trigger_name FROM dba_triggers WHERE trigger_name LIKE 'TRG_AIX_SPLIT%')
    LOOP
        v_sql := 'DROP trigger ' || rec.owner ||'.'|| rec.trigger_name;
        DBMS_OUTPUT.PUT_LINE(v_sql);
        EXECUTE IMMEDIATE v_sql;
    END LOOP;
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('ERROR during:' || v_sql ||':');
    DBMS_OUTPUT.PUT_LINE(SQLCODE);
    DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 255));
END;
/

DROP PACKAGE mic_policy_ax.p_db_split;
DROP PUBLIC DATABASE LINK splitcla;

PROMPT =====================================
PROMPT 
EXIT
