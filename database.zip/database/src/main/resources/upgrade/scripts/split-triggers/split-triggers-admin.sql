PROMPT
PROMPT ==================================================
PROMPT Executing split-triggers-admin.sql
PROMPT ==================================================

DEFINE dblink=&1

@@split-triggers-aup-debug.trg &&dblink

PROMPT =====================================
PROMPT 
EXIT
