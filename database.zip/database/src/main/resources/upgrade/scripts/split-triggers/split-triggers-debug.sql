PROMPT
PROMPT ============================================
PROMPT Executing split-triggers.sql
PROMPT ============================================

DEFINE customercode=&1
DEFINE sid=&2
DEFINE dblink=&3

@@split-triggers.tab &&customercode &&sid &&dblink
@@split-triggers-debug.pkg
@@split-triggers-debug.trg &&customercode &&sid &&dblink
DROP PACKAGE p_db_split;

PROMPT =====================================
PROMPT 

EXIT
