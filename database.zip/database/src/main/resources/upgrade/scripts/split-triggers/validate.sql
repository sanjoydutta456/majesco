PROMPT
PROMPT =====================================================
PROMPT Executing validate.sql
PROMPT =====================================================

SET VERIFY OFF
SET FEEDBACK OFF

DEFINE sid=&1
DEFINE entity_type=&2
DEFINE display_num='&3'
DEFINE revision=&4

conn mic_ax/mic_ax@&&SID
SET SERVEROUTPUT ON SIZE 1000000
SET LINE 256

SPOOL split-verify.&&entity_type.&&display_num.-&&revision..log

DECLARE
    TYPE v_varray IS VARRAY(64) OF USER_TABLES.table_name%TYPE;
    v_polref_count_tables V_VARRAY := v_varray('MIS_BILLING', 'MIS_ALT_DISPUTE_RESOLUTION', 'MIS_CA_SYMBOLS', 'MIS_COVERAGES_CA', 'MIS_COVERAGES_CR', 'MIS_COVERAGES_EC', 'MIS_COVERAGES_GL', 'MIS_COVERAGES_IM', 'MIS_COVERAGES_PL', 'MIS_COVERAGES_PR', 'MIS_COVERAGES_UC', 'MIS_COVERAGES_WC', 'MIS_COVERAGE_OPTIONS', 'MIS_NAMES', 'MIS_POLICY_LOCATIONS', 'MIS_POLICY_UNEMPLOYMENT_NO', 'MIS_RISKS_CA', 'MIS_RISKS_CR', 'MIS_RISKS_EC', 'MIS_RISKS_GL', 'MIS_RISKS_IB', 'MIS_RISKS_IM', 'MIS_RISKS_PL', 'MIS_RISKS_PR', 'MIS_RISKS_UC', 'MIS_RISKS_WC', 'MIS_POLICY_QUESTIONS', 'MIS_FORMS', 'MIS_PRINT_INFORMATION');
    v_polref_count_prefixes V_VARRAY := v_varray('MBI', 'MDR', 'MCS', 'MCO_CA', 'MCO_CR', 'MCO_EC', 'MCO_GL', 'MCO_IM', 'MCO_PL', 'MCO_PR', 'MCO_UC', 'MCO_WC', 'MCT', 'MNA', 'MPL', 'MPU', 'MRI_CA', 'MRI_CR', 'MRI_EC', 'MRI_GL', 'MRI_IB', 'MRI_IM', 'MRI_PL', 'MRI_PR', 'MRI_UC', 'MRI_WC', 'MPQ', 'MFO', 'MPR');

    v_polref_sum_tables V_VARRAY := v_varray('MIS_COVERAGE_PARTS', 'MIS_RISKS', 'MIS_COVERAGES', 'MIS_POLICY_INSTALLMENTS', 'MIS_POLICY_FINANCIALS', 'MIS_POLICY_COMMS_FEES');
    v_polref_sum_prefixes V_VARRAY := v_varray('MCP', 'MRI', 'MCO', 'MPI', 'MPF', 'MPM');
    v_polref_sum_column V_VARRAY := v_varray('MCP_TRANSACTION_PREMIUM', 'MRI_TRANSACTION_PREMIUM', 'MCO_TRANSACTION_PREMIUM', 'MPI_AMOUNT', 'MPF_FULL_TERM_PREMIUM', 'MPM_NET_COMMISSION');

    v_table     USER_TABLES.table_name%TYPE;

    v_polref    MIS_POLICIES.mpo_policy_reference%TYPE;
    v_display   MIS_POLICIES.mpo_company_policy_number%TYPE;
    v_insured   MIS_POLICIES.mpo_insured_name%TYPE;
    v_agent     MIS_POLICIES.mpo_agent_id%TYPE;

    v_rows      NUMBER;
    v_sum       NUMBER;

    v_sql       VARCHAR2(32767);
BEGIN
    IF v_polref_count_tables.last != v_polref_count_prefixes.last THEN
        DBMS_OUTPUT.PUT_LINE('ERROR: length of v_polref_count_tables and v_polref_count_prefixes does not match');
        RETURN;
    END IF;
    IF v_polref_sum_tables.last != v_polref_sum_prefixes.last THEN
        DBMS_OUTPUT.PUT_LINE('ERROR: length of v_polref_sum_tables and v_polref_sum_prefixes does not match');
        RETURN;
    END IF;
    IF v_polref_sum_tables.last != v_polref_sum_column.last THEN
        DBMS_OUTPUT.PUT_LINE('ERROR: length of v_polref_sum_tables and v_polref_sum_column does not match');
        RETURN;
    END IF;

    v_table := 'MIS_POLICIES';
    SELECT mpo_policy_reference, mpo_company_policy_number, mpo_insured_name, mpo_agent_id
    INTO v_polref, v_display, v_insured, v_agent
    FROM mis_policies
    WHERE mpo_policy_quote_indicator = '&&entity_type'
      AND mpo_company_policy_number = '&&display_num'
      AND mpo_revision_number = '&&revision';

    DBMS_OUTPUT.PUT_LINE(v_polref ||','|| v_display ||','|| v_insured ||','|| v_agent);

    DBMS_OUTPUT.PUT_LINE('Policy Reference' ||','|| 'Table Name' ||','|| 'Rows' ||','|| 'Sum');

    SELECT COUNT(*), SUM(mpo_transaction_premium)
    INTO v_rows, v_sum
    FROM mis_policies
    WHERE mpo_policy_reference = v_polref;

    DBMS_OUTPUT.PUT_LINE(v_polref ||','|| v_table ||','|| v_rows ||','|| v_sum);

    FOR i IN v_polref_sum_tables.first .. v_polref_sum_tables.last LOOP
        v_table := v_polref_sum_tables(i);

        v_sql := '';
        v_sql := v_sql || 'SELECT COUNT(*), SUM('|| v_polref_sum_column(i) ||') ' || CHR(10);
        v_sql := v_sql || 'FROM ' || v_table || ' ' || CHR(10);
        v_sql := v_sql || 'WHERE ' || v_polref_sum_prefixes(i) || '_policy_reference = ''' || v_polref || ''' ' || CHR(10);
        EXECUTE IMMEDIATE v_sql INTO v_rows, v_sum;

        DBMS_OUTPUT.PUT_LINE(v_polref ||','|| v_table ||','|| v_rows ||','|| v_sum);
    END LOOP;

    FOR i IN v_polref_count_tables.first .. v_polref_count_tables.last LOOP
        v_table := v_polref_count_tables(i);

        v_sql := '';
        v_sql := v_sql || 'SELECT COUNT(*) ' || CHR(10);
        v_sql := v_sql || 'FROM ' || v_table || ' ' || CHR(10);
        v_sql := v_sql || 'WHERE ' || v_polref_count_prefixes(i) || '_policy_reference = ''' || v_polref || ''' ' || CHR(10);

        EXECUTE IMMEDIATE v_sql INTO v_rows;

        DBMS_OUTPUT.PUT_LINE(v_polref ||','|| v_table ||','|| v_rows ||','|| 'N/A');
    END LOOP;

    v_table := 'MIS_POLICY_COMM_RECIPIENTS';
    SELECT count(*), SUM(mpc_comm_amount)
    INTO v_rows, v_sum
    FROM mis_policy_comm_recipients
    WHERE mpc_financial_id IN (SELECT mpf_id FROM mis_policy_financials WHERE mpf_policy_reference = v_polref);

    DBMS_OUTPUT.PUT_LINE(v_polref ||','|| v_table ||','|| v_rows ||','|| v_sum);

    v_table := 'MIS_POLICY_TAX_FEES';
    SELECT count(*), SUM(mpt_amount)
    INTO v_rows, v_sum
    FROM mis_policy_tax_fees
    WHERE mpt_financial_id IN (SELECT mpf_id FROM mis_policy_financials WHERE mpf_policy_reference = v_polref);

    DBMS_OUTPUT.PUT_LINE(v_polref ||','|| v_table ||','|| v_rows ||','|| v_sum);

    v_table := 'MIS_POLICY_INST_COMMS_FEES';
    SELECT count(*), SUM(mpa_net_commission)
    INTO v_rows, v_sum
    FROM mis_policy_inst_comms_fees
    WHERE mpa_comms_fees_id IN (SELECT mpm_id FROM mis_policy_comms_fees WHERE mpm_policy_reference = v_polref);

    DBMS_OUTPUT.PUT_LINE(v_polref ||','|| v_table ||','|| v_rows ||','|| v_sum);

    v_table := 'MIS_POLICY_TIERS_COMMS_FEES';
    SELECT count(*), SUM(mps_tier_commission)
    INTO v_rows, v_sum
    FROM mis_policy_tiers_comms_fees
    WHERE mps_comms_fees_id IN (SELECT mpm_id FROM mis_policy_comms_fees WHERE mpm_policy_reference = v_polref);

    DBMS_OUTPUT.PUT_LINE(v_polref ||','|| v_table ||','|| v_rows ||','|| v_sum);

    v_table := 'CSISARMH';
    SELECT count(*), SUM(mh_year_prem_mp)
    INTO v_rows, v_sum
    FROM csisarmh
    WHERE mh_mcpp_sw != 'Y'
      AND mh_p_q = SUBSTR(v_polref, 1, 1)
      AND mh_cmpny_code = SUBSTR(v_polref, 2, 2)
      AND mh_brnc = SUBSTR(v_polref, 4, 2)
      AND mh_pol = SUBSTR(v_polref, 6, 9)
      AND mh_year = SUBSTR(v_polref, 15, 1)
      AND mh_endor_pol = SUBSTR(v_polref, 16, 3);

    DBMS_OUTPUT.PUT_LINE(v_polref ||','|| v_table ||','|| v_rows ||','|| v_sum);

EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('ERROR processing ' || v_polref ||':'|| v_table);
    RAISE;
END;
/

PROMPT =====================================
PROMPT 

EXIT
