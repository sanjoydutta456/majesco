#!/bin/bash

##  Eric Beuscher
##  setCustomerDatabaseEnv.sh

export MICConnectString='${oracle.system.tns.alias}'

export TWO_TASK=${oracle.system.sid}

export MICSystemUsername=${oracle.system.username}
export MICSystemPassword=${oracle.system.password}
export MICSysPassword=${oracle.sys.password}

export MICCustomerCode=${customer.code}

export MICUserName=${schema.mic.username}
export MICUserPassword=${schema.mic.password}
export MICUserDataTablespace=${schema.mic.data.tablespace}
export MICUserIndexTablespace=${schema.mic.index.tablespace}

export MICPolicydUserName=${schema.mic_policyd.username.lx}
export MICPolicydPassword=${schema.mic_policyd.password.lx}
export MICPolicydDataTablespace=${schema.mic_policyd.data.tablespace}
export MICPolicydIndexTablespace=${schema.mic_policyd.index.tablespace}

export MICPolicyUserName=${schema.mic_policy.username}
export MICPolicyPassword=${schema.mic_policy.password}
export MICPolicyDataTablespace=${schema.mic_policy.data.tablespace}
export MICPolicyIndexTablespace=${schema.mic_policy.index.tablespace}

export MICCommonUserName=${schema.mic_common.username}
export MICCommonPassword=${schema.mic_common.password}
export MICCommonDataTablespace=${schema.mic_policy.data.tablespace}
export MICCommonIndexTablespace=${schema.mic_policy.index.tablespace}

export MICCRMUserName=${schema.mic_crm.username}
export MICCRMPassword=${schema.mic_crm.password}
export MICCRMDataTablespace=${schema.mic_policy.data.tablespace}
export MICCRMIndexTablespace=${schema.mic_policy.index.tablespace}

export MICRepositoryUserName=${schema.mic_repository.username}
export MICRepositoryPassword=${schema.mic_repository.password}
export MICRepositoryDataTablespace=${schema.mic_repository.data.tablespace}
export MICRepositoryIndexTablespace=${schema.mic_repository.index.tablespace}

export MICBillingUserName=${schema.mic_billing.username}
export MICBillingPassword=${schema.mic_billing.password}
export MICBillingDataTablespace=${schema.mic_billing.data.tablespace}
export MICBillingIndexTablespace=${schema.mic_billing.index.tablespace}

export MICClaimUserName=${schema.mic_claim.username}
export MICClaimPassword=${schema.mic_claim.password}
export MICClaimDataTablespace=${schema.mic_claim.data.tablespace}
export MICClaimIndexTablespace=${schema.mic_claim.index.tablespace}

export MICMessagingUserName=${derived.jdbc.messaging.datasource.username}

export TILESUserName=${schema.tiles.username}
export TILESPassword=${schema.tiles.password}

export SITEUserName=${schema.site.username}
export SITEPassword=${schema.site.password}

export MICPolicyStudioUserName=${schema.policy_studio.username}
export MICPolicyStudioPassword=${schema.policy_studio.password}
