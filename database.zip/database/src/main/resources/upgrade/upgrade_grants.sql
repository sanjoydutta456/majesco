PROMPT
PROMPT ==============================================
PROMPT Executing upgrade_grants.sql
PROMPT ==============================================


PROMPT ==============================================
PROMPT 
EXIT SUCCESS