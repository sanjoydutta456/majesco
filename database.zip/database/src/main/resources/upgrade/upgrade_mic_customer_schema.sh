#!/bin/bash

##  Eric Beuscher
##  upgrade_mic_customer_schema.sh

## Change the current directory to where the batch script exists
olddir=`pwd`
shdir=`dirname $0`

is_pctv2=${is.pctv2}
cd $shdir

trap 'onexit' EXIT

function onexit() {
    cd $olddir
}

echo "====================="
echo "Preparing environment"
echo "====================="
envfile=$shdir/setCommonDatabaseEnv.sh
## Checking Environment scripts exist or not
if [ ! -e $envfile ]; then
    echo "ERROR: $envfile does not exist"
    exit 1;
fi
source $envfile

## Create a temporary subdirectory in case it's missing
tmpdir=$INSTALL_PATH/logs/MIC_Logs    
if [ ! -d $tmpdir ]; then
    mkdir $tmpdir
fi

if [ ! -x "$SQLPLUS_BIN" ]; then
    SQLPLUS_BIN=$INSTALLER_SQL_CLIENT_HOME
fi

export ORACLE_HOME=$SQLPLUS_BIN
export LD_LIBRARY_PATH=$ORACLE_HOME
export PATH=$PATH:$ORACLE_HOME

errorlog=$tmpdir

TWO_TASK=$MICConnectString

is_licensed_nexgen_mic=is.licensed.nexgen.mic
is_licensed_nexgen_ri=is.licensed.nexgen.ri
is_licensed_bi=is.licensed.bi
is_dual_env=dualEnvironment.nextgen.flag

mic_imaging_username=${imaging.ifs.schema.username}
mic_imaging_password=${imaging.ifs.schema.password}
MicCustomerdomain=${customer.domain}
echo "=============================="
echo "Preparing customer environment"
echo "=============================="
envfile1=$shdir/setCustomerDatabaseEnv.sh
## Checking Environment scripts exist or not
if [ ! -e $envfile1 ]; then
    echo "ERROR: $envfile1 does not exist"
    exit 1;
fi
source $envfile1

errorlog=$tmpdir

echo "Upgrading DB Objects for" $MICCustomerCode

##Purge Recyclebin.

echo "Cleanup recyclebin for mic_policy_dl..."
sqlplus -s $MICPolicydUserName/$MICPolicydPassword@$MICConnectString @purge_recyclebin >> $errorlog/purge_recyclebin.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @purge_recyclebin"
    exit 1
fi

echo "Cleanup recyclebin for mic_common..."
sqlplus -s $MICCommonUserName/$MICCommonPassword@$MICConnectString @purge_recyclebin >> $errorlog/purge_recyclebin.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @purge_recyclebin"
    exit 1
fi


echo "Cleanup recyclebin for mic_policy..."
sqlplus -s $MICPolicyUserName/$MICPolicyPassword@$MICConnectString @purge_recyclebin >> $errorlog/purge_recyclebin.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @purge_recyclebin"
    exit 1
fi

echo "Cleanup recyclebin for mic_billing..."
sqlplus -s $MICBillingUserName/$MICBillingPassword@$MICConnectString @purge_recyclebin >> $errorlog/purge_recyclebin.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @purge_recyclebin"
    exit 1
fi

echo "Cleanup recyclebin for mic_crm..."
sqlplus -s $MICCRMUserName/$MICCRMPassword@$MICConnectString @purge_recyclebin >> $errorlog/purge_recyclebin.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @purge_recyclebin"
    exit 1
fi

echo "Cleanup recyclebin for mic_repository..."
sqlplus -s $MICRepositoryUserName/$MICRepositoryPassword@$MICConnectString @purge_recyclebin >> $errorlog/purge_recyclebin.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @purge_recyclebin"
    exit 1
fi


echo "Cleanup recyclebin for mic_claim..."
sqlplus -s $MICClaimUserName/$MICClaimPassword@$MICConnectString @purge_recyclebin >> $errorlog/purge_recyclebin.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @purge_recyclebin"
    exit 1
fi

echo "Cleanup recyclebin for mic..."
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @purge_recyclebin >> $errorlog/purge_recyclebin.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @purge_recyclebin"
    exit 1
fi


##Create DB Mgmt pkgs.
echo "Create DB Mgmt pkgs"
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @create_database_management.sql $MICSystemPassword >> $errorlog/Cleanup_recyclebin.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @create_database_management.sql"
    exit 1
fi


## Load license-based properties for use by installer/MIC.
## This needs to be among the first steps done, for use by other steps.
echo "Licence File."
sqlplus -s $MICAdminUserName/$MICAdminPassword@$MICConnectString @mic_admin/mic_admin_customer_properties_license.dat $MICCustomerCode $is_licensed_nexgen_mic $is_licensed_nexgen_ri $is_licensed_bi $is_dual_env >> $errorlog/upgrade_mic_license.log
if [ $? != 0 ]; then
   echo "ERROR: could not run @mic_admin/mic_admin_customer_properties_license.dat"
    exit 1
fi



echo "Polcicy 2015 upgrade path - Tiles table cleanup"
if [x$IsForceSiteRefresh=="xY"]; then
	echo "******* Calling mic_common\mic_common_data_2015_purge.sql"
	sqlplus -s $MICCommonUserName/$MICCommonPassword@$MICConnectString @mic_common/mic_common_data_2015_purge.sql >> $errorlog/mic_common_data_2015_purge.log
	if [ $? != 0 ]; then
		echo "ERROR: could not run @create_database_management.sql"
    exit 1
	fi
else
	echo "****Skipping Tiles cleanup as force.site.refresh is either not passed to installer or it is not Y"
fi



## Changes are made to provide handling for decoupling PAS, BILLING and CLAIMS system based on the LICENSE
echo "Integrating ca_installer objects to mic_common"
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @grant_ca_installer.sql $MICCustomerCode $MICCommonUserName >> $errorlog/grant_ca_installer.log
	if [ $? != 0 ]; then
		echo "ERROR: could not run @grant_ca_installer.sql"
		exit 1
	fi


##REM Changes are made to provide handling for decoupling PAS, BILLING and CLAIMS system based on the LICENSE
echo "@grant_ca_installer.sql"
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @grant_ca_installer.sql $MICCustomerCode mic_admin >> $errorlog/grant_ca_installer.log
	if [ $? != 0 ]; then
		echo "ERROR: could not run @grant_ca_installer.sql"
		exit 1
	fi

##Upgrade db objects for mic_admin customer specific.
echo "@mic_admin/upgrade_mic_admin_customer"
sqlplus -s $MICAdminUserName/$MICAdminPassword@$MICConnectString @mic_admin/upgrade_mic_admin_customer $MICAdminIndexTablespace $MICCustomerCode >> $errorlog/upgrade_mic_admin_customer.log
	if [ $? != 0 ]; then
		echo "ERROR: could not run @mic_admin/upgrade_mic_admin_customer"
		exit 1
	fi

## Drop IEL indexes not handled by dev studio
sqlplus -s $MICPolicyStudioUserName/$MICPolicyStudioPassword@$MICConnectString @drop_iel_indexes.sql >> $errorlog/drop_iel_indexes.log
	if [ $? != 0 ]; then
		echo "ERROR: could not run @@drop_iel_indexes.sql"
		exit 1
	fi

##for new bootstrap process
echo "new bootstrap for mic_common - $MICCustomerCode"
sqlplus -s $MICCommonUserName/$MICCommonPassword@$MICConnectString @mic_common/mic_bootstrap.sql $MICCustomerCode >> $errorlog/mic_bootstrap.log
	if [ $? != 0 ]; then
		echo "ERROR: could not run @mic_common/mic_bootstrap.sql"
		exit 1
	fi


## ********************
## Run upgrade for mic_policy here once, and then again along with the other
## schemas.  Ignore any errors this first time.
## In upgrade mic_policy.ind 1.68, we add indexes on locator columns
## It looks like when we run this on a database upgraded from 9i to 10g, this
## fails the first time we run it and then succeeds on subsequent runs.
## The error is:
##     *** SR 50047 - Adding Index MIS_POLICIES_NU22 *** BEGIN
##     *
##     ERROR at line 1:
##     ORA-29855: error occurred in the execution of ODCIINDEXCREATE routine
##     ORA-04063: type body "MDSYS.SDO_INDEX_METHOD_9I" has errors
##     ORA-06512: at line 27
## We are looking for a good solution, but this work around should do the job
## and prevent install failures for something that works on rerun

	
echo "From 7.0.42, calling upgrade mic_policy first	"
echo "Upgrading mic_policy DB Objects..."
sqlplus -s $MICPolicyUserName/$MICPolicyPassword@$MICConnectString @mic_policy/upgrade_mic_policy $MICPolicyIndexTablespace $MICCustomerCode >> $errorlog/upgrade_mic_policy.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_policy/upgrade_mic_policy"
    exit 1
fi

## Upgrade db objects for every schema.

echo "Upgrading mic_policy_dl DB Objects..."
cmd='SET ESCCHAR $;'
echo $cmd  >> d_upgrade_mic_policyd.sql
echo '@mic_policy_dl/upgrade_mic_policy_dl' $MICPolicydIndexTablespace $MICCustomerCode >> d_upgrade_mic_policyd.sql
chmod +rwx d_upgrade_mic_policyd.sql


 sqlplus -s $MICPolicydUserName/$MICPolicydPassword@$MICConnectString @d_upgrade_mic_policyd.sql  >> $errorlog/upgrade_mic_policydollar.log
 if [ $? != 0 ]; then
     echo 'ERROR: could not run @mic_policy_dl/upgrade_mic_policy_dl'
     exit 1
 fi

rm d_upgrade_mic_policyd.sql
	
	

echo "Upgrading mic_common DB Objects..."
sqlplus -s $MICCommonUserName/$MICCommonPassword@$MICConnectString @mic_common/upgrade_mic_common $MICCommonIndexTablespace $MICCustomerCode >> $errorlog/upgrade_mic_common.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_common/upgrade_mic_common"
    exit 1
fi

echo "upgrade mic_policy DB Objects..."
sqlplus -s $MICPolicyUserName/$MICPolicyPassword@$MICConnectString @mic_policy/upgrade_mic_policy $MICPolicyIndexTablespace $MICCustomerCode >> $errorlog/upgrade_mic_policy.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_policy/upgrade_mic_policy"
    exit 1
fi

	
echo "Upgrade mic_billing DB Objects..."
sqlplus -s $MICBillingUserName/$MICBillingPassword@$MICConnectString @mic_billing/upgrade_mic_billing $MICBillingIndexTablespace $MICCustomerCode >> $errorlog/upgrade_mic_billing.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_billing/upgrade_mic_billing"
    exit 1
fi

echo "Upgrade mic_crm DB Objects..."
sqlplus -s $MICCRMUserName/$MICCRMPassword@$MICConnectString @mic_crm/upgrade_mic_crm $MICCRMIndexTablespace $MICCustomerCode >> $errorlog/upgrade_mic_crm.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_crm/upgrade_mic_crm"
    exit 1
fi

echo "Upgrade mic_repository DB Objects..."
sqlplus -s $MICRepositoryUserName/$MICRepositoryPassword@$MICConnectString @mic_repository/upgrade_mic_repository $MICRepositoryIndexTablespace $MICCustomerCode >> $errorlog/upgrade_mic_repository.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_repository/upgrade_mic_repository"
    exit 1
fi

echo "Upgrade mic_claim DB Objects..."
sqlplus -s $MICClaimUserName/$MICClaimPassword@$MICConnectString @mic_claim/upgrade_mic_claim $MICClaimIndexTablespace $MICCustomerCode >> $errorlog/upgrade_mic_claim.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_claim/upgrade_mic_claim"
    exit 1
fi

if [ $MICCustomerCode == "LX" ]; then
    sqlplus -s $MICPolicyUserName/$MICPolicyPassword@$MICConnectString @mic_policy/mic_policy.vw2 >> $errorlog/mic_policy_vw2.log
	if [ $? != 0 ]; then
		echo "ERROR: could not run @mic_policy/mic_policy.vw2"
		exit 1
	fi	
fi		


## Upgrade db objects for mic_user schema.
echo "Upgrade mic_claim DB Objects..."
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_user/mic_user.typ >> $errorlog/mic_user_typ.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_user/mic_user.typ"
    exit 1
fi

##Integrate db objects between different schemas.


cmd='SET ESCCHAR $;'
echo $cmd  >> d_mic_policydgrt.sql
echo '@mic_policy_dl/mic_policy_dl.grt' $MICCustomerCode >> d_mic_policydgrt.sql
chmod +rwx d_mic_policydgrt.sql

 echo "Integrating mic_policy_dl DB Objects..."
 sqlplus -s $MICPolicydUserName/$MICPolicydPassword@$MICConnectString @d_mic_policydgrt.sql $MICCustomerCode >> $errorlog/install_mic_policydollar.log
 if [ $? != 0 ]; then
     echo 'ERROR: could not run @mic_policy_dl/mic_policy_dl.grt'
     exit 1
 fi

rm d_mic_policydgrt.sql
 
cmd='SET ESCCHAR $;'
echo $cmd  >> d_mic_policydint.sql
echo '@mic_policy_dl/mic_policy_dl.int' $MICPolicydUserName $MICPolicydPassword $MICCommonUserName $MICCommonPassword $MICPolicyUserName $MICPolicyPassword $MICBillingUserName $MICBillingPassword $MICCRMUserName $MICCRMPassword $MICRepositoryUserName $MICRepositoryPassword $MICClaimUserName $MICClaimPassword system $MICSystemPassword $MICCustomerCode >> d_mic_policydint.sql
chmod +rwx d_mic_policydint.sql
 
echo "@mic_policy/mic_policy_dl.int"
sqlplus -s $MICPolicydUserName/$MICPolicydPassword@$MICConnectString @d_mic_policydint.sql  >> $errorlog/install_mic_policydollar.log
if [ $? != 0 ]; then
     echo 'ERROR: could not run @mic_policy/mic_policy_dl.int'
     exit 1
fi

rm d_mic_policydgrt.sql


echo "Integrating mic_common DB Objects..."
sqlplus -s $MICCommonUserName/$MICCommonPassword@$MICConnectString @mic_common/mic_common.grt $MICCustomerCode > $errorlog/mic_common_grt.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_common/mic_common.grt"
    exit 1
fi


echo "mic_common.int..."
sqlplus -s $MICCommonUserName/$MICCommonPassword@$MICConnectString @mic_common/mic_common.int $MICPolicydUserName $MICPolicydPassword $MICCommonUserName $MICCommonPassword $MICPolicyUserName $MICPolicyPassword $MICBillingUserName $MICBillingPassword $MICCRMUserName $MICCRMPassword $MICRepositoryUserName $MICRepositoryPassword $MICClaimUserName $MICClaimPassword system $MICSystemPassword $MICCustomerCode > $errorlog/mic_common_int.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_common/mic_common.int"
    exit 1
fi


echo "Integrating MIC_POLICY DB Objects..."
sqlplus -s $MICPolicyUserName/$MICPolicyPassword@$MICConnectString @mic_policy/mic_policy.grt $MICCustomerCode > $errorlog/mic_policy_grt.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_policy/mic_policy.grt"
    exit 1
fi

echo "mic_policy.int..."
sqlplus -s $MICPolicyUserName/$MICPolicyPassword@$MICConnectString @mic_policy/mic_policy.int $MICPolicydUserName $MICPolicydPassword $MICCommonUserName $MICCommonPassword $MICPolicyUserName $MICPolicyPassword $MICBillingUserName $MICBillingPassword $MICCRMUserName $MICCRMPassword $MICRepositoryUserName $MICRepositoryPassword $MICClaimUserName $MICClaimPassword system $MICSystemPassword $MICCustomerCode > $errorlog/mic_policy_int.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_policy/mic_policy.int"
    exit 1
fi

echo "Integrating mic_billing DB Objects..."
sqlplus -s $MICBillingUserName/$MICBillingPassword@$MICConnectString @mic_billing/mic_billing.grt $MICCustomerCode > $errorlog/mic_billing.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_billing/mic_billing.grt"
    exit 1
fi

echo "mic_billing.int  ..."
sqlplus -s $MICBillingUserName/$MICBillingPassword@$MICConnectString @mic_billing/mic_billing.int $MICPolicydUserName $MICPolicydPassword $MICCommonUserName $MICCommonPassword $MICPolicyUserName $MICPolicyPassword $MICBillingUserName $MICBillingPassword $MICCRMUserName $MICCRMPassword $MICRepositoryUserName $MICRepositoryPassword $MICClaimUserName $MICClaimPassword system $MICSystemPassword $MICCustomerCode >> $errorlog/install_mic_billing.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_billing/mic_billing.int"
    exit 1
fi

echo "Integrating mic_crm DB Objects..."
sqlplus -s $MICCRMUserName/$MICCRMPassword@$MICConnectString @mic_crm/mic_crm.grt $MICCustomerCode > $errorlog/mic_crm.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_crm/mic_crm.grt"
    exit 1
fi

echo "mic_crm.int  ..."
sqlplus -s $MICCRMUserName/$MICCRMPassword@$MICConnectString @mic_crm/mic_crm.int $MICPolicydUserName $MICPolicydPassword $MICCommonUserName $MICCommonPassword $MICPolicyUserName $MICPolicyPassword $MICBillingUserName $MICBillingPassword $MICCRMUserName $MICCRMPassword $MICRepositoryUserName $MICRepositoryPassword $MICClaimUserName $MICClaimPassword system $MICSystemPassword $MICCustomerCode >> $errorlog/mic_crm.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_crm/mic_crm.int"
    exit 1
fi


echo "Integrating mic_repository DB Objects..."
sqlplus -s $MICRepositoryUserName/$MICRepositoryPassword@$MICConnectString @mic_repository/mic_repository.grt $MICCustomerCode > $errorlog/mic_repository.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_repository/mic_repository.grt"
    exit 1
fi


echo "mic_repository.int..."
sqlplus -s $MICRepositoryUserName/$MICRepositoryPassword@$MICConnectString @mic_repository/mic_repository.int $MICPolicydUserName $MICPolicydPassword $MICCommonUserName $MICCommonPassword $MICPolicyUserName $MICPolicyPassword $MICBillingUserName $MICBillingPassword $MICCRMUserName $MICCRMPassword $MICRepositoryUserName $MICRepositoryPassword $MICClaimUserName $MICClaimPassword system $MICSystemPassword $MICCustomerCode > $errorlog/mic_repository_int.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_repository/mic_repository.int"
    exit 1
fi

echo "Integrating mic_claim DB Objects  ..."
sqlplus -s $MICClaimUserName/$MICClaimPassword@$MICConnectString @mic_claim/mic_claim.grt $MICCustomerCode > $errorlog/mic_claim.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_claim/mic_claim.grt"
    exit 1
fi

echo "mic_claim.int..."
sqlplus -s $MICClaimUserName/$MICClaimPassword@$MICConnectString @mic_claim/mic_claim.int $MICPolicydUserName $MICPolicydPassword $MICCommonUserName $MICCommonPassword $MICPolicyUserName $MICPolicyPassword $MICBillingUserName $MICBillingPassword $MICCRMUserName $MICCRMPassword $MICRepositoryUserName $MICRepositoryPassword $MICClaimUserName $MICClaimPassword system $MICSystemPassword $MICCustomerCode >> $errorlog/install_mic_claim.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_claim/mic_claim.int"
    exit 1
fi


##Upgrade common products scripts.
echo "@mic_policy/mic_policy.predtab..."
sqlplus -s $MICPolicyUserName/$MICPolicyPassword@$MICConnectString @mic_policy/mic_policy.predtab $MICPolicyIndexTablespace $MICCustomerCode >> $errorlog/mic_policy_predtab.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_policy/mic_policy.predtab"
    exit 1
fi


echo "Patching common Product."
sqlplus -s $MICPolicyUserName/$MICPolicyPassword@$MICConnectString @mic_policy/mic_policy.postdtab $MICPolicyIndexTablespace $MICCustomerCode >> $errorlog/mic_policy__posttab.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_policy/mic_policy_common.dtab"
    exit 1
fi

##Compile db objects for every schema.


echo "Compiling mic_policy$ DB Objects"
sqlplus -s $MICPolicydUserName/$MICPolicydPassword@$MICConnectString @compile_invalid_objects.sql >> $errorlog/compiling_mic_policyd.log
if [ $? != 0 ]; then
    echo "ERROR: could not run mic_policy_dl @compile_invalid_objects.sql"
    exit 1
fi



echo "Compiling mic_common DB Objects"
sqlplus -s $MICCommonUserName/$MICCommonPassword@$MICConnectString @compile_invalid_objects.sql >> $errorlog/compiling_mic_common.log
if [ $? != 0 ]; then
    echo "ERROR: could not run mic_common @compile_invalid_objects.sql"
    exit 1
fi

echo "Compiling mic_policy DB Objects"
sqlplus -s $MICPolicyUserName/$MICPolicyPassword@$MICConnectString @compile_invalid_objects.sql >> $errorlog/compiling_mic_policy.log
if [ $? != 0 ]; then
    echo "ERROR: could not run mic_policy @compile_invalid_objects.sql"
    exit 1
fi


echo "Compiling mic_billing DB Objects"
sqlplus -s $MICBillingUserName/$MICBillingPassword@$MICConnectString @compile_invalid_objects.sql >> $errorlog/compiling_mic_billing.log
if [ $? != 0 ]; then
    echo "ERROR: could not run mic_billing @compile_invalid_objects.sql"
    exit 1
fi

echo "Compiling mic_crm DB Objects"
sqlplus -s $MICCRMUserName/$MICCRMPassword@$MICConnectString @compile_invalid_objects.sql >> $errorlog/compiling_mic_crm.log
if [ $? != 0 ]; then
    echo "ERROR: could not run mic_crm @compile_invalid_objects.sql"
    exit 1
fi

echo "Compiling mic_repository DB Objects"
sqlplus -s $MICRepositoryUserName/$MICRepositoryPassword@$MICConnectString @compile_invalid_objects.sql >> $errorlog/compiling_mic_repository.log
if [ $? != 0 ]; then
    echo "ERROR: could not run mic_repository @compile_invalid_objects.sql"
    exit 1
fi


echo "Compiling mic_claim DB Objects"
sqlplus -s $MICClaimUserName/$MICClaimPassword@$MICConnectString @compile_invalid_objects.sql >> $errorlog/compiling_mic_claim.log
if [ $? != 0 ]; then
    echo "ERROR: could not run mic_claim @compile_invalid_objects.sql"
    exit 1
fi

echo "Compiling policy_studio DB Objects"
sqlplus -s $MICPolicyStudioUserName/$MICPolicyStudioPassword@$MICConnectString @compile_invalid_objects.sql >> $errorlog/compiling_policy_studio.log
if [ $? != 0 ]; then
    echo "ERROR: could not run policy_studio @compile_invalid_objects.sql"
    exit 1
fi

## Granting db objects between different schemas.


cmd='SET ESCCHAR $;'
echo $cmd  >> d_mic_policydgrt.sql
echo '@mic_policy_dl/mic_policy_dl.grt' $MICCustomerCode >> d_mic_policydgrt.sql
chmod +rwx d_mic_policydgrt.sql

 echo "Granting mic_policy_dl DB Objects..."
 sqlplus -s $MICPolicydUserName/$MICPolicydPassword@$MICConnectString @d_mic_policydgrt.sql $MICCustomerCode >> $errorlog/install_mic_policydollar.log
 if [ $? != 0 ]; then
     echo 'ERROR: could not run @mic_policy_dl/mic_policy_dl.grt'
     exit 1
 fi

rm d_mic_policydgrt.sql



echo "Granting mic_common DB Objects..."
sqlplus -s $MICCommonUserName/$MICCommonPassword@$MICConnectString @mic_common/mic_common.grt $MICCustomerCode >> $errorlog/mic_common_grt.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_common/mic_common.grt"
    exit 1
fi

echo "Granting mic_policy DB Objects..."
sqlplus -s $MICPolicyUserName/$MICPolicyPassword@$MICConnectString @mic_policy/mic_policy.grt $MICCustomerCode >> $errorlog/mic_policy_grt.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_policy/mic_policy.grt"
    exit 1
fi
    
echo "Granting mic_billing DB Objects..."
sqlplus -s $MICBillingUserName/$MICBillingPassword@$MICConnectString @mic_billing/mic_billing.grt $MICCustomerCode >> $errorlog/mic_billing.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_billing/mic_billing.grt"
    exit 1
fi

echo "Granting mic_crm DB Objects..."
sqlplus -s $MICCRMUserName/$MICCRMPassword@$MICConnectString @mic_crm/mic_crm.grt $MICCustomerCode >> $errorlog/mic_crm.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_crm/mic_crm.grt"
    exit 1
fi

echo "Granting mic_repository DB Objects..."
sqlplus -s $MICRepositoryUserName/$MICRepositoryPassword@$MICConnectString @mic_repository/mic_repository.grt $MICCustomerCode >> $errorlog/mic_repository.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_repository/mic_repository.grt"
    exit 1
fi

echo "Granting mic_claim DB Objects  ..."
sqlplus -s $MICClaimUserName/$MICClaimPassword@$MICConnectString @mic_claim/mic_claim.grt $MICCustomerCode >> $errorlog/mic_claim.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_claim/mic_claim.grt"
    exit 1
fi



echo "Granting mic_mssaging DB Objects  ..."
#sqlplus -s -l mic_imaging/mic_imaging@$MICConnectString @mic_imaging/mic_imaging.grt $MICCustomerCode >> $errorlog/mic_imaging.log
#if [ $? != 0 ]; then
#    echo "ERROR: echo Customer $MICCustomerCode does not have the Imaging module.  Skipping..."
#fi


## Load db objects for every schema.


cmd='SET ESCCHAR $;'
echo $cmd  >> d_mic_policysdat.sql
echo '@mic_policy_dl/mic_policy_dl.dat' $MICCustomerCode $MicCustomerdomain >> d_mic_policysdat.sql
chmod +rwx d_mic_policysdat.sql

echo "Loading mic_policy_dl DB Objects..."
sqlplus -s $MICPolicydUserName/$MICPolicydPassword@$MICConnectString @d_mic_policysdat.sql  >> $errorlog/loading_mic_policyd.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_policy_dl/mic_policy_dl.dat"
    exit 1
fi

rm d_mic_policysdat.sql

echo "Loading mic_common DB Objects..."
sqlplus -s $MICCommonUserName/$MICCommonPassword@$MICConnectString @mic_common/mic_common.dat $MICCustomerCode $MicCustomerdomain>> $errorlog/loading_mic_common.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_common/mic_common.dat"
    exit 1
fi


echo "Loading mic_policy DB Objects..."
sqlplus -s $MICPolicyUserName/$MICPolicyPassword@$MICConnectString @mic_policy/mic_policy.dat $MICCustomerCode $MicCustomerdomain>> $errorlog/loading_mic_policy.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_policy/mic_policy.dat"
    exit 1
fi


echo "Loading mic_billing DB Objects..."
sqlplus -s $MICBillingUserName/$MICBillingPassword@$MICConnectString @mic_billing/mic_billing.dat $MICCustomerCode $MicCustomerdomain>> $errorlog/loading_mic_billing.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_billing/mic_billing.dat"
    exit 1
fi

echo "Loading mic_crm DB Objects..."
sqlplus -s $MICCRMUserName/$MICCRMPassword@$MICConnectString @mic_crm/mic_crm.dat $MICCustomerCode $MicCustomerdomain>> $errorlog/loading_mic_crm.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_crm/mic_crm.dat"
    exit 1
fi

echo "Loading mic_repository DB Objects..."
sqlplus -s $MICRepositoryUserName/$MICRepositoryPassword@$MICConnectString @mic_repository/mic_repository.dat $MICCustomerCode $MicCustomerdomain>> $errorlog/loading_mic_repository.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_repository/mic_repository.dat"
    exit 1
fi

echo "Loading mic_claim DB Objects..."
sqlplus -s $MICClaimUserName/$MICClaimPassword@$MICConnectString @mic_claim/mic_claim.dat $MICCustomerCode $MicCustomerdomain>> $errorlog/loading_mic_claim.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_claim/mic_claim.dat"
    exit 1
fi


echo "Loading policy_studio DB Objects..."
sqlplus -s $MICClaimUserName/$MICClaimPassword@$MICConnectString @policy_studio/policy_studio.dat $MICCustomerCode $MicCustomerdomain>> $errorlog/loading_policy_studio.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @policy_studio/policy_studio.dat"
    exit 1
fi


##Datafix for every schema


cmd='SET ESCCHAR $;'
echo $cmd  >> d_datafix_mic_policyd.sql
echo '@mic_policy_dl/datafix_mic_policy_dl.sql' $MICCustomerCode $MicCustomerdomain >> d_datafix_mic_policyd.sql
chmod +rwx d_datafix_mic_policyd.sql

echo "datafix mic_policy_dl DB Objects..."
sqlplus -s $MICPolicydUserName/$MICPolicydPassword@$MICConnectString @d_datafix_mic_policyd.sql  >> $errorlog/datafix.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_policy_dl/datafix_mic_policy_dl.sql"
    exit 1
fi

rm d_datafix_mic_policyd.sql


echo "datafix mic_common DB Objects..."
sqlplus -s $MICCommonUserName/$MICCommonPassword@$MICConnectString @mic_common/datafix_mic_common.sql $MICCustomerCode $MicCustomerdomain>> $errorlog/datafix.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_common/datafix_mic_common.sql"
    exit 1
fi


echo "datafix mic_policy DB Objects..."
sqlplus -s $MICPolicyUserName/$MICPolicyPassword@$MICConnectString @mic_policy/datafix_mic_policy.sql $MICCustomerCode $MicCustomerdomain>> $errorlog/datafix.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_policy/datafix_mic_policy.sql"
    exit 1
fi


echo "datafix mic_billing DB Objects..."
sqlplus -s $MICBillingUserName/$MICBillingPassword@$MICConnectString @mic_billing/datafix_mic_billing.sql $MICCustomerCode $MicCustomerdomain>> $errorlog/datafix.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_billing/datafix_mic_billing.sql "
    exit 1
fi

echo "datafix_ mic_crm DB Objects..."
sqlplus -s $MICCRMUserName/$MICCRMPassword@$MICConnectString @mic_crm/datafix_mic_crm.sql $MICCustomerCode $MicCustomerdomain>> $errorlog/datafix.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_crm/datafix_mic_crm.dat"
    exit 1
fi

echo "datafix_ mic_repository DB Objects..."
sqlplus -s $MICRepositoryUserName/$MICRepositoryPassword@$MICConnectString @mic_repository/datafix_mic_repository.sql $MICCustomerCode $MicCustomerdomain>> $errorlog/datafix.log
if [ $? != 0 ]; then
   echo "ERROR: could not run @mic_repository/datafix_mic_repository.sql"
    exit 1
fi

echo "datafix_ mic_claim DB Objects..."
sqlplus -s $MICClaimUserName/$MICClaimPassword@$MICConnectString @mic_claim/datafix_mic_claim.sql $MICCustomerCode $MicCustomerdomain>> $errorlog/datafix.log
if [ $? != 0 ]; then
   echo "ERROR: could not run @mic_repository/datafix_mic_claim.sql"
    exit 1
fi



##Create mis_user synonyms.

cmd='SET ESCCHAR $;'
echo $cmd  >> d_mic_policydsyn.sql
echo '@mic_user/mic_policy_dl.syn' $MICPolicydUserName >> d_mic_policydsyn.sql
chmod +rwx d_mic_policydsyn.sql


echo "Creating mic_policy_dl Synonyms..."
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @d_mic_policydsyn.sql >> $errorlog/create_Synonyms.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_user/mic_policy_dl.syn"
    exit 1
fi

rm d_mic_policydsyn.sql

echo "Creating mic_common Synonyms..."
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_user/mic_common.syn $MICCommonUserName>> $errorlog/create_Synonyms.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_user/mic_common.syn"
    exit 1
fi

echo "Creating mic_policy Synonyms..."
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_user/mic_policy.syn $MICPolicyUserName>> $errorlog/create_Synonyms.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_user/mic_policy.syn"
    exit 1
fi

echo "Creating mic_billing Synonyms..."
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_user/mic_billing.syn $MICBillingUserName>> $errorlog/create_Synonyms.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_user/mic_billing.syn"
    exit 1
fi

echo "Creating mic_crm Synonyms..."
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_user/mic_crm.syn $MICCRMUserName>> $errorlog/create_Synonyms.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_user/mic_crm.syn"
    exit 1
fi

echo "Creating mic_repository Synonyms..."
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_user/mic_repository.syn $MICRepositoryUserName>> $errorlog/create_Synonyms.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_user/mic_repository.syn"
    exit 1
fi

echo "Creating mic_claim Synonyms..."
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_user/mic_claim.syn $MICClaimUserName>> $errorlog/create_Synonyms.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_user/mic_claim.syn"
    exit 1
fi

echo "Creating mic_messaging Synonyms..."
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_user/mic_messaging.syn $MICMessagingUserName>> $errorlog/create_Synonyms.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_user/mic_messaging.syn"
    exit 1
fi

echo "Creating mic_imaging Synonyms..."
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_user/mic_imaging.syn $mic_imaging_password>> $errorlog/create_Synonyms.log
if [ $? != 0 ]; then
    echo "Customer does not have the Imaging module.  Skipping..."
    ##exit 1
fi


echo "Creating policy_studio Synonyms..."
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_user/policy_studio.syn $MICPolicyStudioUserName >> $errorlog/create_Synonyms.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_user/policy_studio.syn"
    exit 1
fi


echo "Mic_Imaging grant..."
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_user/mic_user.int $MICImagingUserName $MICImagingPassword $MICUserName >> $errorlog/Mic_Imaging.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_user/mic_user.int"
    exit 1
fi


echo "Creating MIC_RO_ User..."
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @create_mic_ro_user.sql $MICCustomerCode $MICAdminDataTablespace $MICAdminIndexTablespace >> $errorlog/MIC_RO.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @create_mic_ro_user.sql"
    exit 1
fi


echo "Granting Privs to MIC_COMMON User..."
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @grant_mic_common.sql $MICCustomerCode >> $errorlog/Granting_Privs.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @grant_mic_common.sql"
    exit 1
fi

echo "Granting Privs to MIC_POLICY User..."
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @grant_mic_policy.sql $MICCustomerCode >> $errorlog/Granting_Privs.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @grant_mic_policy.sql"
    exit 1
fi

## Integrate policy_studio schema with common, policy, and user

echo "Integrating policy_studio objects to mic_common..."
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @grant_policy_studio.sql $MICCustomerCode $MICCommonUserName >> $errorlog/Integrate.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @grant_policy_studio.sql"
    exit 1
fi

echo "Integrating mic_policy objects to mic_common..."
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @grant_policy_studio.sql $MICCustomerCode $MICPolicyUserName >> $errorlog/Integrate.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @grant_policy_studio.sql"
    exit 1
fi

echo "Integrating mic objects to mic_common..."
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @grant_policy_studio.sql $MICCustomerCode $MICUserName >> $errorlog/Integrate.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @grant_policy_studio.sql"
    exit 1
fi


echo "Datafix mic_user..."
sqlplus -s $MICUserName/$MICUserPassword@$MICConnectString @mic_user/datafix_mic_user.sql $MICCustomerCode >> $errorlog/datafix_mic_user.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @mic_user/datafix_mic_user.sql"
    exit 1
fi

echo "Compiling all DB Objects..."
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @compile_invalid_objects2.sql 1 $MICCustomerCode >> $errorlog/compile.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @compile_invalid_objects2.sql"
    exit 1
fi

##echo "Compiling all DB Objects..."
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @compile_invalid_objects2.sql 2 $MICCustomerCode >> $errorlog/compile.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @compile_invalid_objects2.sql"
    exit 1
fi

echo "Compiling all DB Objects..."
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @compile_invalid_objects2.sql 3 $MICCustomerCode >> $errorlog/compile.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @compile_invalid_objects2.sql"
    exit 1
fi


##Drop DB Mgmt pkgs.
echo "Compiling all DB Objects..."
sqlplus -s $MICSystemUsername/$MICSystemPassword@$MICConnectString @drop_database_management.sql $MICSystemPassword >> $errorlog/drop.log
if [ $? != 0 ]; then
    echo "ERROR: could not run @drop_database_management.sql"
    exit 1
fi

echo "**"
echo "=================================================="
echo "MIC DB objects upgrade completed successfully for $MICCustomerCode "
echo "=================================================="
echo "."
