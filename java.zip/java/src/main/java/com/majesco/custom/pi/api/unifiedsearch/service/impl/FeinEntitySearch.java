package com.majesco.custom.pi.api.unifiedsearch.service.impl;

import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import javax.ws.rs.core.Response;

import com.coverall.el.FunctionResolver;
import com.coverall.el.InlineExpression;
import com.coverall.el.QueryWithBindVariables;
import com.coverall.el.VariableResolver;
import com.coverall.el.function.DefaultFunctionResolver;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.UnifiedSearchErrors;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.impl.AbstractUnifiedEntitySearch;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.UnifiedCountSearchResponse;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.UnifiedSearchRequest;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.UnifiedSearchResponse;
import com.coverall.mt.dao.DAOManager;
import com.coverall.mt.el.variable.VariableResolverImpl;
import com.coverall.mt.http.HTTPConstants;
import com.coverall.mt.http.MICSession;
import com.coverall.mt.http.User;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.DOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;
import com.coverall.util.GeneralUtil;
import com.majesco.custom.pi.api.unifiedsearch.service.model.FeinResponseData;

public class FeinEntitySearch extends AbstractUnifiedEntitySearch {
	
	
	static final String PARAM_USER = "user";
	static final String SEARCH_TYPE = "searchType";
	static final String DISPLAY_MODE = "displayMode";
	static final String SEARCH_VALUE = "searchValue";
	static final String SEARCH_VALUE_ESC = "searchValueEsc";
	static final String LINK ="LINK";
	static final String TYPE ="TYPE";
	static final String NAME = "NAME";
	static final String KEY = "key";
	static final String VALUE = "value";

	final static String queryId = "FeinUnifiedSearch"; 
	
	public static final Set<String> SORT_BY_COLUMN = new HashSet<String>(
				Arrays.asList(new String[] { "INSUREDNAME","ADDRESS","MODIFIEDON","MODIFIEDBY"}));
	 
	@Override
	public UnifiedSearchResponse searchEntity(UnifiedSearchRequest request) {

		UnifiedSearchResponse unifiedResponse = createBasicResponse(request);
		FeinResponseData insuredData = null;
		ArrayList<Object> agencyDatas = new ArrayList<Object>();
		ArrayList<HashMap<String, String>> searchRecords = searchRecords(request, searchQueryType.SEARCH);
		for (Map<String, String> row : searchRecords) {
			insuredData = new FeinResponseData();
			insuredData.setInsuredName(row.get("INSUREDNAME"));
			insuredData.setCity(row.get("CITY"));
			insuredData.setState(row.get("STATE"));
			insuredData.setCountry(row.get("COUNTRY"));
			insuredData.setZipcode(row.get("ZIPCODE"));
			insuredData.setInsuredAddress(row.get("ADDRESS"));
			insuredData.setModifiedOn(row.get("MODIFIEDON"));
			insuredData.setModifiedBy(row.get("MODIFIEDBY"));
			addNavigationAndAction(insuredData, request, row);
			agencyDatas.add(insuredData);
		}
		unifiedResponse.setData(agencyDatas);

		return unifiedResponse;
	}
	
	protected ArrayList<HashMap<String, String>> searchRecords(UnifiedSearchRequest searchRequest,searchQueryType queryType) {
		QueryWithBindVariables queryWithBindVariables = new QueryWithBindVariables();
		loadCommonEntityProperties(searchRequest);
		ArrayList<HashMap<String, String>> dataList = new ArrayList<HashMap<String, String>>();
		String query = null;
		if(searchQueryType.SEARCH.equals(queryType)){
			queryWithBindVariables = generateQueryWithFilters(searchRequest);
		}else if (searchQueryType.COUNT.equals(queryType)){
			queryWithBindVariables = generateQueryWithCount(searchRequest);
		}
		dataList = executeQuery(queryWithBindVariables);
		return dataList;
	}
	
	private ArrayList<HashMap<String, String>> executeQuery(QueryWithBindVariables queryWithBindVariables){
		String query = queryWithBindVariables.getQuery();
		List<String> bindVariableList = queryWithBindVariables.getBindVariablesValues();
		
		ArrayList<HashMap<String, String>> dataList = new ArrayList<HashMap<String, String>>();
		Connection conn = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		HashMap<String, String> row = null;
		try {
			conn = APIRequestContext.getApiRequestContext().getConnection();
			statement = conn.prepareStatement(query);
			
			if (!((null == bindVariableList) || (bindVariableList.isEmpty()) || ((bindVariableList.size()) == 0))) {
				GeneralUtil.bindVariablesToStatement(bindVariableList, statement, 0);
			}
			
			WebServiceLoggerUtil.logInfo("AbstractUnifiedEntitySearch", "executeQuery", query, new Object[] { query, bindVariableList });
			
			rs = statement.executeQuery();
			if (rs != null) {
				ResultSetMetaData rsmd = rs.getMetaData();
				while (rs.next()) {
					row = new HashMap<String, String>();
					int columnCount = rsmd.getColumnCount();
					for (int i = 1; i <= columnCount; i++) {
						String columnName = rsmd.getColumnName(i);
						row.put(columnName.toUpperCase(), rs.getString(columnName));
					}
					dataList.add(row);
				}
			}
		} 
        catch(SQLException e)
        {
                
                  if (e.getErrorCode() == 29902)
                  {
                		WebServiceLoggerUtil.logError("AbstractUnifiedEntitySearch", "executeQuery","Too many records found", new Object[] { query, bindVariableList, conn }, e);
                		throw new APIException("Too many records found. Please change the filter criteria", APIConstant.FAILED,getErrorMessageList(Collections.singletonList("Too many records found. Please change the filter criteria")),e);
	            	 
                  }else{
                	  
                	  WebServiceLoggerUtil.logError("AbstractUnifiedEntitySearch", "executeQuery", e.getLocalizedMessage(), new Object[] { query, bindVariableList, conn }, e);
          			  throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);

                  }
                  //System.out.println("SQL Exception -> Error Code -> " + se.getErrorCode()) ;
        }

		catch (Exception e) {
			WebServiceLoggerUtil.logError("AbstractUnifiedEntitySearch", "executeQuery", e.getLocalizedMessage(), new Object[] { query, bindVariableList, conn }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);

		}
		finally {
			try {
                DBUtil.close(rs, statement, null);                
			} catch (SQLException e) {
				WebServiceLoggerUtil.logError("AbstractUnifiedEntitySearch", "executeQuery", e.getLocalizedMessage(), new Object[] { query, bindVariableList, conn }, e);
				throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);
			}
		}
		return dataList;
	}
	
	
	public QueryWithBindVariables resolveQueryExpression(UnifiedSearchRequest searchRequest, String queryId) {
		User user = APIRequestContext.getApiRequestContext().getMtUser();
		if(queryId == null){
		   queryId = getQueryName();
		}
		String sqlQuery = null;
		HashMap variableMap = new HashMap();
		try {
			/*DAOManager daoManager = DAOManager.getInstance(ServletConfigUtil.COMPONENT_PORTAL);
			Query query = daoManager.getQuery(ServletConfigUtil.COMPONENT_PORTAL, user, queryId);
			if(query == null){
				Exception apiException  = new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,null,null);
				WebServiceLoggerUtil.logError("AbstractUnifiedEntitySearch", "resolveQueryExpression", "Query not found in queries.xml file" , new Object[] {queryId},apiException);
				throw new APIException();
			}
			sqlQuery = query.toString();*/
			String customerCode = CustomerConfigUtil.getInstance().getCustomerCode(user.getDomain());
			DAOManager daoManager = DAOManager.getInstance(ServletConfigUtil.COMPONENT_PORTAL);
			sqlQuery = daoManager.getQueryByCustomerCode(ServletConfigUtil.COMPONENT_PORTAL, customerCode, queryId).toString();
			if(sqlQuery == null || sqlQuery.length() == 0 ){
				Exception apiException  = new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,null,null);
				WebServiceLoggerUtil.logError("AbstractUnifiedEntitySearch", "resolveQueryExpression", "Query not found in queries.xml file" , new Object[] {queryId},apiException);
				throw new APIException();
			}
			Random randomizer = new Random();
			MICSession session = new MICSession(randomizer.nextInt() + "", null);
			if(searchRequest.getSourceSystemUserId() != null){
			  User simulatedUser = getSimulatedUser(searchRequest.getSourceSystemUserId());
			  if(simulatedUser != null){
				  user = simulatedUser;  
			  }else{
				  WebServiceLoggerUtil.logError("AbstractUnifiedEntitySearch", "resolveQueryExpression","simulatedUser is null, using the autheticated user", new Object[] {}, new Exception());
			  }
			}
			WebServiceLoggerUtil.logInfo("AbstractUnifiedEntitySearch","resolveQueryExpression", "User gettng used for DLS filter", new Object[] {user});
			// Provide Additional Filters in parameters
			
			HashMap params = new HashMap();
			params.put(PARAM_USER, user);
			params.put("domain", user.getDomain());
			params.put("userName", user.getUserId());
			params.put(ServletConfigUtil.COMPONENT, "portal");
			if (searchType.CONTAINS.toString().equalsIgnoreCase(searchRequest.getSearchType())) {
				params.put(SEARCH_TYPE, searchType.CONTAINS.toString());
			} else {
				params.put(SEARCH_TYPE, searchType.STARTS_WITH.toString());
			}
			String searchText  = searchRequest.getSearchText();
			String searchTextEsc = searchText;
            // Escape for Text Index
			if(searchText!= null && searchEntity.POLICY.toString().equalsIgnoreCase(searchRequest.getSearchEntityId()))
			{
				for(String escapeChar : ESCAPE_CHARS){
					searchTextEsc = searchTextEsc.replace(escapeChar, "\\"+escapeChar);
				}
				
				
			}
			params.put(SEARCH_VALUE, searchText);
			params.put(SEARCH_VALUE_ESC, searchTextEsc);
			if(searchRequest.getDisplayMode() != null){
				params.put(DISPLAY_MODE, searchRequest.getDisplayMode());
			}
			// Provide Additional Filters in parameters
			ArrayList<HashMap> additionalFiltersList = searchRequest.getFilters();
			if (additionalFiltersList != null && !additionalFiltersList.isEmpty()) {
				for (HashMap additionalFilters : additionalFiltersList) {
					if (additionalFilters != null && !additionalFilters.isEmpty()) {
						String key = null;
						String value = null;
						if (additionalFilters.containsKey(KEY)) {
							key = additionalFilters.get(KEY).toString();
						} else if (key == null && additionalFilters.containsKey(KEY.toUpperCase())) {
							key = additionalFilters.get(KEY.toUpperCase()).toString();
						}
						if (additionalFilters.containsKey(VALUE)) {
							value = additionalFilters.get(VALUE).toString();
						} else if (key == null && additionalFilters.containsKey(VALUE.toUpperCase())) {
							value = additionalFilters.get(VALUE.toUpperCase()).toString();
						}
						if(key != null && value != null){
							params.put(key, value);
						}
					}
				}
			}
			
			
			variableMap.put(VariableResolverImpl.REQUESTPARAMS_PARAMETER, params);
			session.setAttribute(HTTPConstants.SESSION_USER, user);
			variableMap.put(VariableResolverImpl.SESSION_PARAMETER, session);
			VariableResolver varResolver = new VariableResolverImpl(variableMap);
			FunctionResolver funcResolver = new DefaultFunctionResolver();
			
			try {
				varResolver.setDynamicBind(true);
				
				InlineExpression expression = new InlineExpression(sqlQuery, varResolver, funcResolver);
				
				return (expression.getQueryWithBindVariables());
			} catch (Exception e) {
				e.printStackTrace();
				
				WebServiceLoggerUtil.logError("AbstractUnifiedEntitySearch", "resolveQueryExpression", e.getLocalizedMessage(), new Object[] {queryId , sqlQuery , variableMap}, e);
				throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);
			} finally {
				varResolver.setDynamicBind(false);
			}
		}  catch (Exception e) {
			WebServiceLoggerUtil.logError("AbstractUnifiedEntitySearch", "resolveQueryExpression", e.getLocalizedMessage(), new Object[] {queryId , sqlQuery , variableMap}, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);
		}
	}
	
	
	
	private User getSimulatedUser(String userId){
		User user = null;
		try {
			if(userId != null && userId.indexOf('@') == -1 ){
				userId = userId + "@" + APIRequestContext.getApiRequestContext().getMtUser().getDomain();
			}
			User batchUser = new User(DOMUtil.BATCH_USER + "@" + APIRequestContext.getApiRequestContext().getMtUser().getDomain(),
                    DOMUtil.BATCH_PASSWORD);
            Method mGetSimulatedUser = User.class.getDeclaredMethod("getSimulatedUser", String.class);
            mGetSimulatedUser.setAccessible(true);
            user = (User) mGetSimulatedUser.invoke(batchUser, userId);
        } catch (Exception e) {
        	WebServiceLoggerUtil.logError("AbstractUnifiedEntitySearch", "getSimulatedUser", e.getLocalizedMessage(), new Object[] {userId}, e);
            
        }
		return user;
	}
	

	@Override
	public UnifiedCountSearchResponse getEntityCount(UnifiedSearchRequest request) {

		UnifiedCountSearchResponse countResponse = new UnifiedCountSearchResponse();

		countResponse = createBasicCountResponse(request);
		ArrayList<HashMap<String, String>> searchRecords = searchRecords(request, searchQueryType.COUNT);
		HashMap<String, String> countResult = searchRecords.get(0);
		String rowCount = countResult.get("ROW_COUNT");
		if (rowCount != null) {
			countResponse.setTotalRecords(Long.parseLong(rowCount));
		}
		return countResponse;
	}

	@Override
	public String getQueryName() {
		return queryId;
	}
	
	protected void validateSortByColumn(String sortBy){
		if(sortBy != null ){
			if(!SORT_BY_COLUMN.contains(sortBy.toUpperCase())){
				String errMsg = "Invalid value for SortBy, the request value is not supported for SortBy";
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				throw new APIException(httpStatusCode,APIConstant.FAILED,getErrorMessageList(Collections.singletonList(errMsg))
						,new Throwable());
			}
		}
	}


}
