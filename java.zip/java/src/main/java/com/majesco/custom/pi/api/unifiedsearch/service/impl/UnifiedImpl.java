package com.majesco.custom.pi.api.unifiedsearch.service.impl;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import java.util.Collections;
import java.util.HashMap;

import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.UnifiedSearchErrors;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.UnifiedSearchService;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.impl.AbstractUnifiedEntitySearch;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.impl.UnifiedEntitySearch;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.UnifiedSearchRequest;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mt.webservices.WebServiceLoggerUtil;


public class UnifiedImpl implements UnifiedSearchService{

	@Override
	public Object search(HttpServletRequest request) throws Exception {
	Object response = null;
	//HashMap<String,Object> wrapperResponse = new HashMap<String,Object>();
	String requestJson=APIOperationUtil.fetchRequestBody(request);
	UnifiedSearchRequest searchRequest=new UnifiedSearchRequest(requestJson);
	WebServiceLoggerUtil.logInfo("search", " Request :", new Object[] {  searchRequest});
	try {
		UnifiedEntitySearch unfiedSearch = null;
		if("FEIN".equalsIgnoreCase(searchRequest.getSearchEntityId()))
		{
		 unfiedSearch = new FeinEntitySearch();
		}
		else if("EntityId".equalsIgnoreCase(searchRequest.getSearchEntityId()))
		{
			 unfiedSearch = new EntityIdSearch();
		}
		else if("Dot".equalsIgnoreCase(searchRequest.getSearchEntityId()))
		{
			 unfiedSearch = new DotEntitySearch();
		}
		if(AbstractUnifiedEntitySearch.getHostURL() == null && request.getRequestURI() != null){
		  String requestURL = request.getScheme()+"://"+request.getServerName();
		  Integer port  = request.getServerPort();
		  if(port != null  &&  port.intValue() != -1){
			  requestURL = requestURL  +":"+request.getServerPort();
		  }
		  AbstractUnifiedEntitySearch.setHostURL(requestURL);
		}
		response = unfiedSearch.searchEntity(searchRequest);
		//wrapperResponse.put(searchRequest.getSearchEntityId().toLowerCase(), response);
	} catch (APIException e) {
		throw e;
	} catch (Exception e) {
		WebServiceLoggerUtil.logError("UnifiedSearchServiceImpl", "search", e.getLocalizedMessage(), new Object[] { searchRequest }, e);
		throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,AbstractUnifiedEntitySearch.getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);
	}
	return response;
	}


	@Override
	public String ping() {
		AbstractUnifiedEntitySearch.setHostURL(null);
		if(AbstractUnifiedEntitySearch.commonEntityProperties != null){
			AbstractUnifiedEntitySearch.commonEntityProperties.clear();
		}
		return "This is Unified Search Service";
	}


	@Override
	public Object getSearchCount(HttpServletRequest request) throws Exception {
		Object response = null;
		HashMap<String,Object> wrapperResponse = new HashMap<String,Object>();
		String requestJson=APIOperationUtil.fetchRequestBody(request);
		UnifiedSearchRequest searchRequest=new UnifiedSearchRequest(requestJson);
		WebServiceLoggerUtil.logInfo("getSearchCount", " Request :", new Object[] {  searchRequest});
		try {
			//UnifiedEntitySearch unfiedSearch = new FeinEntitySearch();
			UnifiedEntitySearch unfiedSearch = null;
			if("FEIN".equalsIgnoreCase(searchRequest.getSearchEntityId()))
			{
			 unfiedSearch = new FeinEntitySearch();
			}
			else if("EntityId".equalsIgnoreCase(searchRequest.getSearchEntityId()))
			{
				 unfiedSearch = new EntityIdSearch();
			}
			else if("Dot".equalsIgnoreCase(searchRequest.getSearchEntityId()))
			{
				 unfiedSearch = new DotEntitySearch();
			}
			
			response = unfiedSearch.getEntityCount(searchRequest);
			wrapperResponse.put(searchRequest.getSearchEntityId().toLowerCase(), response);
		} catch (APIException e) {
			throw e;
		} catch (Exception e) {
			WebServiceLoggerUtil.logError("UnifiedSearchServiceImpl", "getSearchCount", e.getLocalizedMessage(), new Object[] { searchRequest }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,AbstractUnifiedEntitySearch.getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);
		}
		return wrapperResponse;
	}

}
