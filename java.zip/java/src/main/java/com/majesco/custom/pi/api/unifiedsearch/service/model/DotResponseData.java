package com.majesco.custom.pi.api.unifiedsearch.service.model;


import java.util.ArrayList;
import java.util.HashMap;

import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.IEntityResponseData;

public class DotResponseData implements IEntityResponseData {

	String policyNumber;
	String policyEffDt;
	String insuredName;
	String polStatus;
	String address;
	String agency;
	String writtenPremium;
	String modifiedOn;
	String modifiedBy;
	String product;
	String quotePolicyIndicator;
	String sourceSystem;
	String customerName;
	String customerId;

	

	ArrayList<HashMap> actions = new ArrayList<HashMap>();
	ArrayList<HashMap> navigations = new ArrayList<HashMap>();
	
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAgency() {
		return agency;
	}
	public void setAgency(String agency) {
		this.agency = agency;
	}
	public String getWrittenPremium() {
		return writtenPremium;
	}
	public void setWrittenPremium(String writtenPremium) {
		this.writtenPremium = writtenPremium;
	}
	public String getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(String modfiedOn) {
		this.modifiedOn = modfiedOn;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modfiedBy) {
		this.modifiedBy = modfiedBy;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNum) {
		this.policyNumber = policyNum;
	}
	public String getPolicyEffDt() {
		return policyEffDt;
	}
	public void setPolicyEffDt(String policyEffDt) {
		this.policyEffDt = policyEffDt;
	}
	public String getInsuredName() {
		return insuredName;
	}
	public void setInsuredName(String insuredNm) {
		this.insuredName = insuredNm;
	}
	public String getPolStatus() {
		return polStatus;
	}
	public void setPolStatus(String polStatus) {
		this.polStatus = polStatus;
	}
		
	public ArrayList<HashMap> getActions() {
		return actions;
	}
	public void setActions(ArrayList<HashMap> actions) {
		this.actions = actions;
	}
	public ArrayList<HashMap> getNavigations() {
		return navigations;
	}
	public void setNavigations(ArrayList<HashMap> navigations) {
		this.navigations = navigations;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	
	public String getQuotePolicyIndicator() {
		return quotePolicyIndicator;
	}
	public void setQuotePolicyIndicator(String quotePolicyIndicator) {
		this.quotePolicyIndicator = quotePolicyIndicator;
	}
	
	public String getSourceSystem() {
		return sourceSystem;
	}
	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	@Override
	public String toString() {
		return "DotResponseData [policyNumber=" + policyNumber + ", policyEffDt=" + policyEffDt + ", insuredName=" + insuredName + ", polStatus="
				+ polStatus + ", address=" + address + ", agency=" + agency + ", writtenPremium=" + writtenPremium + ", modfiedOn=" + modifiedOn
				+ ", modfiedBy=" + modifiedBy + ", actions=" + actions + ", navigations=" + navigations + ", sourceSystem=" + sourceSystem + ", customerName=" + customerName + ", customerId=" + customerId + "]";
	}
	
}
