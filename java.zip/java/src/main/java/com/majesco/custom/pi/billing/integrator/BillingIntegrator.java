package com.majesco.custom.pi.billing.integrator;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.events.EventResponse;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.webservices.majescomastek.events.MajescoBillingPremiumInterfaceIntegrator;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;
import com.majesco.custom.pi.task.service.TaskCreate;

import oracle.jdbc.OracleTypes;

public class BillingIntegrator extends MajescoBillingPremiumInterfaceIntegrator {
	
	private static final String TRANSACTION_NAME = "Cancellation";
	private static final String CANCEL_PARAM_NAME = "CancelDescription";
	private static final String TRANSACTION_DATE_PARAM_NAME = "TransEffectiveDate";
	private static final String WK_PRODUCT_CODE = "WK";
	private static final String RENEWAL_TRANSACTION_NAME = "Renew Policy";
	private static final String PROCESS_TYPE = "This transaction resulted in Cancellation of Parent/Current Policy";
	
	private static final String QUERY_TO_INSERT_IN_POL_REQ = "{ ? = call K_Policy_Transaction.f_insert_policy_trans_req (?,?,?,?,?,?,?,?,?,?,?,?)}";
	private static final String QUERY_TO_INSERT_IN_REQ_PARAM = "{ ? = call K_Policy_Transaction.f_insert_policy_trans_req_params (?,?,?,?,?)}";
	
	private static final String QUERY_TO_GET_CANCEL_DETAILS = "select entity_type, entity_reference, trans_display_name, "
			+ "cancel_description, org_entity_reference from vw_mis_quote_policies where trans_display_name = ? and entity_reference = ? and entity_type = ?";
	
	private static final String QUERY_TO_GET_RENEWAL_ENTITY_REFERENCE = "select entity_reference, org_entity_reference, renewal_of_number, trans_display_name, "
			+ "k_transaction_management.f_is_booked(entity_type, entity_reference) booked_status, gid, effective_date from "
			+ "vw_mis_quote_policies where trans_display_name = ? and renewal_of_number = ? and entity_type = ?";
	
	private String renewalBookedStatus = "N";
	private Long renewalEntityGID = null;
	private Date renewalEffectiveDate = null;
	
	@Override
	public void postProcessEvent(HashMap params, EventResponse response)
			throws Exception {
		logMessage(LogEntry.SEVERITY_INFO, "BillingIntegrator - postProcessEvent()", "");

		// Retrieving details from the Params map
		String entityType = params.get("WEA_ENTITY_TYPE").toString();
		String entityRef = params.get("WEA_ENTITY_REFERENCE").toString();
		User user = (User) params.get("User");
		
		logMessage(LogEntry.SEVERITY_INFO, "EntityType : " + entityType + " EntityRef : " + entityRef + " User : " + user.getUserId(), "");

		//NonPayCancellationTask Creation
		nonPayCancellationTask(entityType, entityRef);
		
		if(response.isIsSuccess()) {
			logMessage(LogEntry.SEVERITY_INFO, "Event Status is Success", "");
			Map<String, String> currentEntityDetails = getCancellationDetails(entityType, entityRef, user);
			if (currentEntityDetails != null) {
				String renewalEntityRef = getRenewalEntityRef(entityType, currentEntityDetails.get("ORG_ENTITY_REFERENCE"), user);
				if (renewalEntityRef != null && renewalBookedStatus.equals("Y")) {
					insertCancellationRequest(entityType, renewalEntityRef, currentEntityDetails.get("CANCEL_DESCRIPTION"), renewalEntityGID, 
							getTransEffectiveDate(renewalEffectiveDate), user);
				}
			}
		}
		
	}
	
	private void nonPayCancellationTask(String entityType, String entityRef) {
		String displayPolicyNumber=null;
		int count=0;
		Connection conn = null;
		PreparedStatement pst = null;
		try {
			conn = ConnectionPool.getConnection(user);
			pst = conn.prepareStatement(
					"select MQP_ORG_ENTITY_REFERENCE,mqp_display_policy_number,count(*) from MIS_QUOTE_POLICIES "
							+ "where MQP_CANCEL_DESCRIPTION = ?" + "and mqp_entity_reference = ? "
							+" and (mqp_entity_reference not in (select ea.UTMG_ENTITY_REFERENCE from UTM_EVENT_ACTIVITIES ea\r\n"
							+ "where ea.UTMG_EVENT_CODE = 'NONPAYCANCELLATIONOCCURANCESMO' and ea.UTMG_ACTIVITY_STATUS = 'SUCCESS')) "
							+ "group by MQP_ORG_ENTITY_REFERENCE,mqp_display_policy_number");
			
			pst.setString(1, "Non-Payment of Premium");
			pst.setString(2, entityRef);
	
			try (ResultSet rs = pst.executeQuery()) {
				if (rs.next()) {
					count = rs.getInt("count(*)");
					displayPolicyNumber = rs.getString("mqp_display_policy_number");
					if (count > 3) {
						logMessage(LogEntry.SEVERITY_INFO, "Control inside", "");
						TaskCreate taskCreate = new TaskCreate();
						taskCreate.createTask(user, entityType, "Non-Pay Cancellation occurrences more than 3",
								"NONPAYCANCELLATIONOCCURANCESMO", "NONPAYCANCELLATIONOCCURANCESMORETHAN3 COMPLETE",
								entityRef, displayPolicyNumber);
	
					}
				}
			}
		} catch (Exception e) {
			logMessage(LogEntry.SEVERITY_FATAL, "Error while creating Task for Non Pay Cancellation : " + e.getMessage(), "");
		}
	}
	
	private Map getCancellationDetails(String entityType, String entityRef, User user) {
		String cancelDes = null;
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Map<String, String> currentEntityDetails = null;
		try {
			conn = ConnectionPool.getConnection(user);
			stmt = conn.prepareStatement(QUERY_TO_GET_CANCEL_DETAILS);
			stmt.setString(1, TRANSACTION_NAME);
			stmt.setString(2, entityRef);
			stmt.setString(3, entityType);
			rs = stmt.executeQuery();
			if(rs.next()) {
				currentEntityDetails = new HashMap<>();
				logMessage(LogEntry.SEVERITY_INFO, "Get Cancel Details Query fetched Record", "");
				currentEntityDetails.put("ENTITY_TYPE", rs.getString("entity_type"));
				currentEntityDetails.put("ENTITY_REFERENCE", rs.getString("entity_reference"));
				currentEntityDetails.put("TRANS_DISPLAY_NAME", rs.getString("trans_display_name"));
				currentEntityDetails.put("CANCEL_DESCRIPTION", rs.getString("cancel_description"));
				currentEntityDetails.put("ORG_ENTITY_REFERENCE", rs.getString("org_entity_reference"));
			}
			if (currentEntityDetails != null) {
				logMessage(LogEntry.SEVERITY_INFO, "Cancelled Entity Details are:", "");
				for (Map.Entry<String,String> entry : currentEntityDetails.entrySet()) {
					logMessage(LogEntry.SEVERITY_INFO, "" + entry.getKey() + ":" + entry.getValue(), "");
				}
			}
		} catch (Exception e) {
			logMessage(LogEntry.SEVERITY_FATAL, "Error while retrieving Cancellation Details : " + e.getMessage(), "");
		} finally {
			try {
				DBUtil.close(rs, stmt, conn);
			} catch(Exception ex) {}
		}
		
		return currentEntityDetails;
	}
	
	private String getRenewalEntityRef(String entityType, String orgEntityRef, User user) {
		String renewalEntityRef = null;
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			conn = ConnectionPool.getConnection(user);
			stmt = conn.prepareStatement(QUERY_TO_GET_RENEWAL_ENTITY_REFERENCE);
			stmt.setString(1, RENEWAL_TRANSACTION_NAME);
			stmt.setString(2, orgEntityRef);
			stmt.setString(3, entityType);
			rs = stmt.executeQuery();
			if(rs.next()) {
				logMessage(LogEntry.SEVERITY_INFO, "Renewal Term Exists for EntityRef : " + orgEntityRef, "");
				renewalEntityRef = rs.getString("entity_reference");
				renewalBookedStatus = rs.getString("booked_status");
				renewalEntityGID = rs.getLong("gid");
				renewalEffectiveDate = rs.getDate("effective_date");
				logMessage(LogEntry.SEVERITY_INFO, "Renewal Term EntityRef : " + renewalEntityRef, "");
			}
		} catch (Exception e) {
			logMessage(LogEntry.SEVERITY_FATAL, "Error while retrieving Renewal EntityRef : " + e.getMessage(), "");
		} finally {
			try {
				DBUtil.close(rs, stmt, conn);
			} catch(Exception ex) {}
		}
		
		return renewalEntityRef;
	}
	
	private void insertCancellationRequest(String entityType, String entityRef, String cancelDes, Long gid, String transEffectiveDate, User user) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		String errorMsg = null;
		Integer requestId = null;

		try {
			logMessage(LogEntry.SEVERITY_INFO, "insertCancellationRequest()", "");
			conn = ConnectionPool.getConnection(user);
			CallableStatement call = conn.prepareCall(QUERY_TO_INSERT_IN_POL_REQ);
			call.registerOutParameter(1, OracleTypes.INTEGER);
			call.setString(2, TRANSACTION_NAME);
			call.setString(3, entityRef);
			call.setString(4, "READY");
			call.setString(5, "CQT");
			call.setString(6, WK_PRODUCT_CODE);
			call.setString(7, entityType);
			call.setString(8, null);
			call.setLong(9, gid);
			call.setString(10, PROCESS_TYPE);
			call.setString(11, user.getUserId());
			call.registerOutParameter(12, OracleTypes.INTEGER);
			call.registerOutParameter(13, OracleTypes.VARCHAR);
			logMessage(LogEntry.SEVERITY_INFO, "insertCancellationRequest() - Before calling", "");
			call.execute();
			logMessage(LogEntry.SEVERITY_INFO, "insertCancellationRequest() - After calling", "");
			errorMsg = (String) call.getObject(13);
			Integer result = (Integer)call.getObject (1);

			if (result != 0) {
				logMessage(LogEntry.SEVERITY_FATAL, "Error while inserting Cancellation Request :" + errorMsg, "");

			} else {
				logMessage(LogEntry.SEVERITY_INFO, "Insert Record for Cancellation Request is Success for : " + entityRef, "");
				requestId = (Integer) call.getObject(12);
				logMessage(LogEntry.SEVERITY_INFO, "Cancellation Request Id : " + requestId, "");
				insertRequestParams(requestId.longValue(), CANCEL_PARAM_NAME, cancelDes, user);
				insertRequestParams(requestId.longValue(), TRANSACTION_DATE_PARAM_NAME, transEffectiveDate, user);
			}

		} catch (Exception e) {
			logMessage(LogEntry.SEVERITY_FATAL, "Error occured while inserting Cancellation Request :" + e.getMessage(), "");
		} finally {
			try {
				DBUtil.close(rs, pst, conn);
			} catch(Exception ex) {}
		}
	}
	
	private void insertRequestParams(Long requestId, String paramName, String paramValue, User user) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		String errorMsg = null;

		try {
			logMessage(LogEntry.SEVERITY_INFO, "insertRequestParams()", "");
			conn = ConnectionPool.getConnection(user);
			CallableStatement call = conn.prepareCall(QUERY_TO_INSERT_IN_REQ_PARAM);
			call.registerOutParameter(1, OracleTypes.INTEGER);
			call.setLong(2, requestId);
			call.setString(3, paramName);
			call.setString(4, paramValue);
			call.setString(5, user.getUserId());
			call.registerOutParameter(6, OracleTypes.VARCHAR);
			logMessage(LogEntry.SEVERITY_INFO, "insertRequestParams() - Before calling", "");
			call.execute();
			logMessage(LogEntry.SEVERITY_INFO, "insertRequestParams() - After calling", "");
			errorMsg = (String) call.getObject(6);
			Integer result = (Integer) call.getObject(1);

			if (result != 0) {
				logMessage(LogEntry.SEVERITY_FATAL, "Error while inserting Cancellation Request Params :" + errorMsg, "");
			} else {
				logMessage(LogEntry.SEVERITY_INFO, "Cancellation Request Params inserted successfully", "");
			}
			
		} catch (Exception e) {
			logMessage(LogEntry.SEVERITY_FATAL, "Error occured while inserting Cancellation Request Params :" + e.getMessage(), "");
		} finally {
			try {
				DBUtil.close(rs, pst, conn);
			} catch(Exception ex) {}
		}
	}
	
	private String getTransEffectiveDate(Date effectiveDate) {
		String transDate = null;
		if (effectiveDate != null) {
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			Calendar c = Calendar.getInstance();
			c.setTime(effectiveDate);
			c.add(Calendar.DATE, 1);
			transDate = sdf.format(c.getTime());
			logMessage(LogEntry.SEVERITY_INFO, "TransEffectiveDate :" + transDate, "");
		} else {
			logMessage(LogEntry.SEVERITY_INFO, "EffectiveDate of the policy is null", "");
		}
		return transDate;
	}

	private void logMessage(int logLevel, String inputMsg, String objMsg) {
		LogMinder.getLogMinder().log(logLevel, getClass().getName(), "postProcessEvent",
				ServletConfigUtil.COMPONENT_PORTAL, new Object[]{objMsg}, 
				inputMsg, null, LogMinderDOMUtil.VALUE_MIC);
	}
}
