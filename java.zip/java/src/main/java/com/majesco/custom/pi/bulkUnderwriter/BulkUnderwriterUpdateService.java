package com.majesco.custom.pi.bulkUnderwriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import javax.naming.NamingException;

import com.coverall.exceptions.JDBCException;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;

public class BulkUnderwriterUpdateService{
	public static final String PMBU_ID = "PMBU_ID";
	
	public static final String PMBU_FROM_UNDERWRITER = "PMBU_FROM_UNDERWRITER";
	public static final String PMBU_TO_UNDERWRITER = "PMBU_TO_UNDERWRITER";
	public static final String PMBU_PROCESSING_STATUS = "PMBU_PROCESSING_STATUS";
	public static final String GID = "GID";
	
	/*public static final String PMBU_PROCESSING_STATUS = "PMBU_PROCESSING_STATUS";
	public static final String PMBU_PROCESSING_DATE = "PMBU_PROCESSING_DATE";
	public static final String PMBU_ENDORSEMENT_FLAG = "PMBU_ENDORSEMENT_FLAG";
	public static final String PMBU_ERROR_RESPONSE = "PMBU_ERROR_RESPONSE";
	public static final String PMBU_CREATED_DATE = "PMBU_CREATED_DATE";
	public static final String PMBU_CREATED_USER = "PMBU_CREATED_USER";
	public static final String PMBU_UPDATED_DATE = "PMBU_UPDATED_DATE";
	public static final String PMBU_UPDATED_USER = "PMBU_UPDATED_USER";*/
	public BulkUnderwriterUpdateService() {
		// TODO Auto-generated constructor stub
	}

	public void saveObjectData(User user,String idList, Map params)
            throws Exception {
            
            Connection conn            = null;
            CallableStatement callStmt = null;
            PreparedStatement prest = null;
            ResultSet result = null;
            int wws_id = -1;
            double actualRate = 0;
            HashMap config = null;
            String[] strArray = null;  
            
            strArray = idList.split(",");  
            for (int i = 0; i< strArray.length; i++){  
            String entityReference1=strArray[i];
        	//String id = (String) params.get(PMBU_ID);
        	
        	String toUnderwriterCode = (String) params.get("PMBU_TO_UNDERWRITER_CODE_"+entityReference1);
        	String fromUnderwriter = (String) params.get("PMBU_FROM_UNDERWRITER_"+entityReference1);
        	String toUnderwriter = (String) params.get("PMBU_TO_UNDERWRITER_"+entityReference1);
        	//String processingstatus = (String) params.get(PMBU_PROCESSING_STATUS);
        	//String piprocessingDate = (String) params.get(PMBU_PROCESSING_DATE);
        	//String endorsementFlag = (String) params.get(PMBU_ENDORSEMENT_FLAG);
        	//String errorResponse = (String) params.get(PMBU_ERROR_RESPONSE);
        	//String picreatedDate = (String) params.get(PMBU_CREATED_DATE);
        	String processingStatus = (String) params.get("PMBU_PROCESSING_STATUS_"+entityReference1);
        	String pmbuId = (String) params.get("PMBU_ID_"+entityReference1);
        	String gid = (String) params.get("GID_"+entityReference1);
        	
        	//String piupdatedDate = (String) params.get(PMBU_UPDATED_DATE);
        	//String updatedUser =(String) params.get(PMBU_UPDATED_USER);
        	Date effectiveDate=null;
        	Date expiryDate=null;
        	String fromUnderwriterName = getUnderwriterName(user, fromUnderwriter);
        	String toUnderwriterName = getUnderwriterName(user, toUnderwriter);
           // Date processingDate=null;
            //Date createdDate=null;
           // Date updatedDate=null;
           
            
            try{
            	
            	
                conn = ConnectionPool.getConnection(user);
                conn.setAutoCommit(false);
                if(!processingStatus.equals("") && !processingStatus.equals("null") && processingStatus.equals("FAILED")) {
                	callStmt = conn
                            .prepareCall("{? = call k_bulk_underwriter.f_bulk_underwriter_failure(?,?)}");	
                	callStmt.registerOutParameter(1, Types.BIGINT);
                	callStmt.setString(2, pmbuId);
                	callStmt.registerOutParameter(3, Types.VARCHAR);
                	callStmt.execute();
                    
                    long errorCode = callStmt.getLong(1);
                    if (errorCode != 0) {
                        String errorMessage = callStmt.getString(3);
                        throw JDBCException.getExceptionFor(errorCode, errorMessage);
                    }

                    conn.commit();
                }
                else {
                callStmt = conn
                        .prepareCall("{? = call k_bulk_underwriter.f_insert_bulk_underwriter(?,?, ?, ?,?)}");
                
                callStmt.registerOutParameter(1, Types.BIGINT);
                //callStmt.setString(2,id );
                //callStmt.setString(2, entityType);
               // callStmt.setString(3, entityReference);
                //callStmt.setString(4,quotePolicyNumber);
                //callStmt.setString(5,quotePolicyStatus);
                callStmt.setString(2,fromUnderwriterName);
                callStmt.setString(3,toUnderwriterCode);
                callStmt.setString(4,toUnderwriterName);
                callStmt.setString(5,gid);
               // callStmt.setString(11,processingstatus);
                //callStmt.setDate(12,processingDate);
            	//callStmt.setString(13,endorsementFlag);
            	//callStmt.setString(14,errorResponse);
            	//callStmt.setDate(15,createdDate);
            	//callStmt.setString(9,createdUser);
            	//callStmt.setDate(17,updatedDate);
            	//callStmt.setString(18,updatedUser);
                callStmt.registerOutParameter(6, Types.VARCHAR);
                callStmt.execute();
                
                long errorCode = callStmt.getLong(1);
                if (errorCode != 0) {
                    String errorMessage = callStmt.getString(6);
                    throw JDBCException.getExceptionFor(errorCode, errorMessage);
                }

                conn.commit();
                }
             } catch(Exception ex){
                 ex.printStackTrace();
                if (ex instanceof JDBCException && ((JDBCException)ex).getSeverity() == JDBCException.FATAL){
                    LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                                                 getClass().getName(), "saveObjectData",
                                                 ServletConfigUtil.COMPONENT_PORTAL,
                                                 new Object[] { params },
                                                 "Error in saving a Object Data "+ex.getMessage(),
                                                 ex, LogMinderDOMUtil.VALUE_MIC);
                }else{
                    LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                                                 getClass().getName(), "saveObjectData",
                                                 ServletConfigUtil.COMPONENT_PORTAL,
                                                 new Object[] { params },
                                                 "Error in saving a Object Data."+ex.getMessage(),
                                                 ex, LogMinderDOMUtil.VALUE_MIC);
                }
                try{
                    conn.rollback();
                }catch(Exception e){
                    LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                                                 getClass().getName(), "saveObjectData",
                                                 ServletConfigUtil.COMPONENT_PORTAL,
                                                 new Object[] { params },
                                                 "Error in rolling back."+ex.getMessage(),
                                                 ex, LogMinderDOMUtil.VALUE_MIC);
                }
                throw ex;
            }finally{
                try{
                    DBUtil.close(null, callStmt, conn);
                }catch (Exception ex){
                    LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                                                 getClass().getName(), "saveObjectData",
                                                 ServletConfigUtil.COMPONENT_PORTAL,
                                                 new Object[] { params },
                                                 "Error in closing DB connection while saving a Object Data."+ex.getMessage(),
                                                 ex, LogMinderDOMUtil.VALUE_MIC);
                }
            }
            }
            
        }
	
	
	private String getUnderwriterName(User user, String underwriter) throws NamingException, SQLException {
		// TODO Auto-generated method stub
		String underwriterName = null;
		
		try(Connection conn = ConnectionPool.getConnection(user);
			PreparedStatement stmt = conn.prepareStatement
					("select sun_underwriter_name from shl_underwriters "
							+ "where sun_underwriter_code = ?")) {
			 
			stmt.setString(1, underwriter);
			try(ResultSet rs = stmt.executeQuery()){
				if(rs.next()) {
					underwriterName = rs.getString("sun_underwriter_name");
				}
			}
			
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
		
		return underwriterName;
        
	}
	
	
	

}
