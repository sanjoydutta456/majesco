package com.majesco.custom.pi.bulkupdate.constants;

public class BulkUpdateConstants {
	
	//PI_MIS_BULK_UNDERWRITER_UPDATE table column names
	public static final String COLUMN_PMBU_ID = "PMBU_ID";
	public static final String COLUMN_PMBU_ENTITY_TYPE = "PMBU_ENTITY_TYPE";
	public static final String COLUMN_PMBU_ENTITY_REFERENCE = "PMBU_ENTITY_REFERENCE";
	public static final String COLUMN_PMBU_QUOTE_POLICY_NUMBER = "PMBU_QUOTE_POLICY_NUMBER";
	public static final String COLUMN_PMBU_QUOTE_POLICY_STATUS = "PMBU_QUOTE_POLICY_STATUS";
	public static final String COLUMN_PMBU_FROM_UNDERWRITER = "PMBU_FROM_UNDERWRITER";
	public static final String COLUMN_PMBU_TO_UNDERWRITER_CODE = "PMBU_TO_UNDERWRITER_CODE";
	public static final String COLUMN_PMBU_TO_UNDERWRITER = "PMBU_TO_UNDERWRITER";
	public static final String COLUMN_PMBU_PROCESSING_STATUS = "PMBU_PROCESSING_STATUS";
	public static final String COLUMN_PMBU_PROCESSING_DATE = "PMBU_PROCESSING_DATE";
	public static final String COLUMN_PMBU_ERROR_RESPONSE = "PMBU_ERROR_RESPONSE";
	public static final String COLUMN_PMBU_NEW_ENTITY_REFERENCE = "PMBU_NEW_ENTITY_REFERENCE";
	public static final String COLUMN_PMBU_CREATED_DATE = "PMBU_CREATED_DATE";
	public static final String COLUMN_PMBU_CREATED_USER = "PMBU_CREATED_USER";
	public static final String COLUMN_PMBU_UPDATED_DATE = "PMBU_UPDATED_DATE";
	public static final String COLUMN_PMBU_UPDATED_USER = "PMBU_UPDATED_USER";
	
	//PI_MIS_BULK_RATING_UPDATE table column names
	public static final String COLUMN_PMBR_ID = "PMBR_ID";
	public static final String COLUMN_PMBR_ENTITY_TYPE = "PMBR_ENTITY_TYPE";
	public static final String COLUMN_PMBR_ENTITY_REFERENCE = "PMBR_ENTITY_REFERENCE";
	public static final String COLUMN_PMBR_QUOTE_POLICY_NUMBER = "PMBR_QUOTE_POLICY_NUMBER";
	public static final String COLUMN_PMBR_QUOTE_POLICY_STATUS = "PMBR_QUOTE_POLICY_STATUS";
	public static final String COLUMN_PMBR_PROCESSING_STATUS = "PMBR_PROCESSING_STATUS";
	public static final String COLUMN_PMBR_PROCESSING_DATE = "PMBR_PROCESSING_DATE";
	public static final String COLUMN_PMBR_NEW_ENTITY_REFERENCE ="PMBR_NEW_ENTITY_REFERENCE";
	public static final String COLUMN_PMBR_ERROR_RESPONSE = "PMBR_ERROR_RESPONSE";
	public static final String COLUMN_PMBR_CREATED_DATE = "PMBR_CREATED_DATE";
	public static final String COLUMN_PMBR_CREATED_USER = "PMBR_CREATED_USER";
	public static final String COLUMN_PMBR_UPDATED_DATE = "PMBR_UPDATED_DATE";
	public static final String COLUMN_PMBR_UPDATED_USER = "PMBR_UPDATED_USER";
	
	
	//Entity Types
	public static final String ENTITY_TYPE_QUOTE = "QUOTE";
	public static final String ENTITY_TYPE_POLICY = "POLICY";
	
	//Quote Statuses
	public static final String STATUS_QUOTE_PENDING_QUOTE = "Pending Quote";
	public static final String STATUS_QUOTE_RATING_SUSPENDED = "Rating - Suspended";
	
	//Policy Statuses
	public static final String STATUS_POLICY_INFORCE = "In Force";
	
	//Processing Statuses
	public static final String STATUS_NOT_PROCESSED = "NOT_PROCESSED";
	public static final String STATUS_PROCESSED = "PROCESSED";
	public static final String STATUS_FAILED = "FAILED";
	
	//Webservice URL paths
	public static final String BULK_UNDERWRITER_WEBSERVICE_NAME = "MIC - INTERNAL - WS - BULK UNDERWRITER PROCESSING";
	public static final String QUOTE_UPDATE_API_URL = "quoteServiceUrl";
	public static final String QUOTE_POLICY_API_USER_ID = "quotePolicyServiceUserId";
	public static final String QUOTE_POLICY_API_USER_PASSWORD = "quotePolicyServicePassword";
	public static final String BULK_RATE_WEBSERVICE_NAME ="MIC - INTERNAL - WS - BULK RATE PROCESSING";
	
	public static final String POLICY_BASE_API_URL = "policyServiceUrl";
	public static final String POLICY_UPDATE_API_URL = "policyUpdateAPIUrl";

	
	public static final String CHARSET_UTF8 = "UTF-8";
}
