package com.majesco.custom.pi.bulkupdate.model;

import java.util.Date;

public class BulkRateUpdateEntity {

	private Long pmbr_id;
	private String pmbr_entity_type;
	private String pmbr_entity_reference;
	private String pmbr_quote_policy_number;
	private String pmbr_quote_policy_status;
	private String pmbr_processing_status;
	private Date pmbr_processing_date;
	private String pmbr_error_response;
	private String pmbr_new_entity_reference;
	private Date pmbr_created_date;
	private String pmbr_created_user;
	private Date pmbr_updated_date;
	private String pmbr_updated_user;
	
	public Long getPmbr_id() {
		return pmbr_id;
	}
	public void setPmbr_id(Long pmbr_id) {
		this.pmbr_id = pmbr_id;
	}
	public String getPmbr_entity_type() {
		return pmbr_entity_type;
	}
	public void setPmbr_entity_type(String pmbr_entity_type) {
		this.pmbr_entity_type = pmbr_entity_type;
	}
	public String getPmbr_entity_reference() {
		return pmbr_entity_reference;
	}
	public void setPmbr_entity_reference(String pmbr_entity_reference) {
		this.pmbr_entity_reference = pmbr_entity_reference;
	}
	public String getPmbr_quote_policy_number() {
		return pmbr_quote_policy_number;
	}
	public void setPmbr_quote_policy_number(String pmbr_quote_policy_number) {
		this.pmbr_quote_policy_number = pmbr_quote_policy_number;
	}
	public String getPmbr_quote_policy_status() {
		return pmbr_quote_policy_status;
	}
	public void setPmbr_quote_policy_status(String pmbr_quote_policy_status) {
		this.pmbr_quote_policy_status = pmbr_quote_policy_status;
	}
	public String getPmbr_processing_status() {
		return pmbr_processing_status;
	}
	public void setPmbr_processing_status(String pmbr_processing_status) {
		this.pmbr_processing_status = pmbr_processing_status;
	}
	public Date getPmbr_processing_date() {
		return pmbr_processing_date;
	}
	public void setPmbr_processing_date(Date pmbr_processing_date) {
		this.pmbr_processing_date = pmbr_processing_date;
	}
	public String getPmbr_error_response() {
		return pmbr_error_response;
	}
	public void setPmbr_error_response(String pmbr_error_response) {
		this.pmbr_error_response = pmbr_error_response;
	}
	public String getPmbr_new_entity_reference() {
		return pmbr_new_entity_reference;
	}
	public void setPmbr_new_entity_reference(String pmbr_new_entity_reference) {
		this.pmbr_new_entity_reference = pmbr_new_entity_reference;
	}
	public Date getPmbr_created_date() {
		return pmbr_created_date;
	}
	public void setPmbr_created_date(Date pmbr_created_date) {
		this.pmbr_created_date = pmbr_created_date;
	}
	public String getPmbr_created_user() {
		return pmbr_created_user;
	}
	public void setPmbr_created_user(String pmbr_created_user) {
		this.pmbr_created_user = pmbr_created_user;
	}
	public Date getPmbr_updated_date() {
		return pmbr_updated_date;
	}
	public void setPmbr_updated_date(Date pmbr_updated_date) {
		this.pmbr_updated_date = pmbr_updated_date;
	}
	public String getPmbr_updated_user() {
		return pmbr_updated_user;
	}
	public void setPmbr_updated_user(String pmbr_updated_user) {
		this.pmbr_updated_user = pmbr_updated_user;
	}
	
}
