package com.majesco.custom.pi.bulkupdate.model;

import java.util.Date;

public class BulkUpdateUnderwriterEntity {

	private Long pmbu_id;
	private String pmbu_entity_type;
	private String pmbu_entity_reference;
	private String pmbu_quote_policy_number;
	private String pmbu_quote_policy_status;
	private String pmbu_from_underwriter;
	private String pmbu_to_underwriter_code;
	private String pmbu_to_underwriter;
	private String pmbu_processing_status;
	private Date pmbu_processing_date;
	private String pmbu_error_response;
	private String pmbu_new_entity_reference;
	private Date pmbu_created_date;
	private String pmbu_created_user;
	private Date pmbu_updated_date;
	private String pmbu_updated_user;
	public Long getPmbu_id() {
		return pmbu_id;
	}
	public void setPmbu_id(Long pmbu_id) {
		this.pmbu_id = pmbu_id;
	}
	public String getPmbu_entity_type() {
		return pmbu_entity_type;
	}
	public void setPmbu_entity_type(String pmbu_entity_type) {
		this.pmbu_entity_type = pmbu_entity_type;
	}
	public String getPmbu_entity_reference() {
		return pmbu_entity_reference;
	}
	public void setPmbu_entity_reference(String pmbu_entity_reference) {
		this.pmbu_entity_reference = pmbu_entity_reference;
	}
	public String getPmbu_quote_policy_number() {
		return pmbu_quote_policy_number;
	}
	public void setPmbu_quote_policy_number(String pmbu_quote_policy_number) {
		this.pmbu_quote_policy_number = pmbu_quote_policy_number;
	}
	public String getPmbu_quote_policy_status() {
		return pmbu_quote_policy_status;
	}
	public void setPmbu_quote_policy_status(String pmbu_quote_policy_status) {
		this.pmbu_quote_policy_status = pmbu_quote_policy_status;
	}
	public String getPmbu_from_underwriter() {
		return pmbu_from_underwriter;
	}
	public void setPmbu_from_underwriter(String pmbu_from_underwriter) {
		this.pmbu_from_underwriter = pmbu_from_underwriter;
	}
	public String getPmbu_to_underwriter_code() {
		return pmbu_to_underwriter_code;
	}
	public void setPmbu_to_underwriter_code(String pmbu_to_underwriter_code) {
		this.pmbu_to_underwriter_code = pmbu_to_underwriter_code;
	}
	public String getPmbu_to_underwriter() {
		return pmbu_to_underwriter;
	}
	public void setPmbu_to_underwriter(String pmbu_to_underwriter) {
		this.pmbu_to_underwriter = pmbu_to_underwriter;
	}
	public String getPmbu_processing_status() {
		return pmbu_processing_status;
	}
	public void setPmbu_processing_status(String pmbu_processing_status) {
		this.pmbu_processing_status = pmbu_processing_status;
	}
	public Date getPmbu_processing_date() {
		return pmbu_processing_date;
	}
	public void setPmbu_processing_date(Date pmbu_processing_date) {
		this.pmbu_processing_date = pmbu_processing_date;
	}
	public String getPmbu_error_response() {
		return pmbu_error_response;
	}
	public void setPmbu_error_response(String pmbu_error_response) {
		this.pmbu_error_response = pmbu_error_response;
	}
	public String getPmbu_new_entity_reference() {
		return pmbu_new_entity_reference;
	}
	public void setPmbu_new_entity_reference(String pmbu_new_entity_reference) {
		this.pmbu_new_entity_reference = pmbu_new_entity_reference;
	}
	public Date getPmbu_created_date() {
		return pmbu_created_date;
	}
	public void setPmbu_created_date(Date pmbu_created_date) {
		this.pmbu_created_date = pmbu_created_date;
	}
	public String getPmbu_created_user() {
		return pmbu_created_user;
	}
	public void setPmbu_created_user(String pmbu_created_user) {
		this.pmbu_created_user = pmbu_created_user;
	}
	public Date getPmbu_updated_date() {
		return pmbu_updated_date;
	}
	public void setPmbu_updated_date(Date pmbu_updated_date) {
		this.pmbu_updated_date = pmbu_updated_date;
	}
	public String getPmbu_updated_user() {
		return pmbu_updated_user;
	}
	public void setPmbu_updated_user(String pmbu_updated_user) {
		this.pmbu_updated_user = pmbu_updated_user;
	}
	
}
