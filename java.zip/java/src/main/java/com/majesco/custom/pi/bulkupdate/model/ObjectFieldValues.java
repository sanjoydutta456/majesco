package com.majesco.custom.pi.bulkupdate.model;

import org.codehaus.jackson.annotate.JsonProperty;

public class ObjectFieldValues {

	@JsonProperty("EffectiveDate")
	private String effectiveDate;
	
	@JsonProperty("GID")
	private String GID;

	public String getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getGID() {
		return GID;
	}

	public void setGID(String gID) {
		GID = gID;
	}
}
