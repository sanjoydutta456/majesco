package com.majesco.custom.pi.bulkupdate.model;

import org.codehaus.jackson.annotate.JsonProperty;

public class Policy {

	@JsonProperty("TransEffectiveDate")
	private String transEffectiveDate;
	
	@JsonProperty("EndorsementReason")
	private String endorsementReason;
	
	@JsonProperty("UnderwriterCode")
	private String underwriterCode;
	
	@JsonProperty("UnderwriterName")
	private String underwriterName;

	public String getTransEffectiveDate() {
		return transEffectiveDate;
	}

	public void setTransEffectiveDate(String transEffectiveDate) {
		this.transEffectiveDate = transEffectiveDate;
	}

	public String getEndorsementReason() {
		return endorsementReason;
	}

	public void setEndorsementReason(String endorsementReason) {
		this.endorsementReason = endorsementReason;
	}

	public String getUnderwriterCode() {
		return underwriterCode;
	}

	public void setUnderwriterCode(String underwriterCode) {
		this.underwriterCode = underwriterCode;
	}

	public String getUnderwriterName() {
		return underwriterName;
	}

	public void setUnderwriterName(String underwriterName) {
		this.underwriterName = underwriterName;
	}
}
