package com.majesco.custom.pi.bulkupdate.model;

public class PolicyBaseResponse {

}
