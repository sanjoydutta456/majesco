package com.majesco.custom.pi.bulkupdate.model;

import java.util.List;

public class PolicyErrorResponse extends PolicyBaseResponse {

	private List<PolicyError> errors;

	public List<PolicyError> getErrors() {
		return errors;
	}

	public void setErrors(List<PolicyError> errors) {
		this.errors = errors;
	}
	
	
}
