package com.majesco.custom.pi.bulkupdate.model;

import java.util.List;

public class PolicyNewTransactionResponse extends PolicyBaseResponse {
	
	private String entityType;
	private String transactionID;
	private String transactionName;
	private String productName;
	private String clientID;
	private List<ObjectFieldValues> objectFieldValuesList;
	public String getEntityType() {
		return entityType;
	}
	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}
	public String getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	public String getTransactionName() {
		return transactionName;
	}
	public void setTransactionName(String transactionName) {
		this.transactionName = transactionName;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getClientID() {
		return clientID;
	}
	public void setClientID(String clientID) {
		this.clientID = clientID;
	}
	public List<ObjectFieldValues> getObjectFieldValuesList() {
		return objectFieldValuesList;
	}
	public void setObjectFieldValuesList(List<ObjectFieldValues> objectFieldValuesList) {
		this.objectFieldValuesList = objectFieldValuesList;
	}
}
