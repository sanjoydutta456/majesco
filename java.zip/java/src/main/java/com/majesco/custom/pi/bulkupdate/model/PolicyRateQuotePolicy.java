package com.majesco.custom.pi.bulkupdate.model;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class PolicyRateQuotePolicy {

	@JsonProperty("TransEffectiveDate")
	private String transEffectiveDate;
	
	@JsonProperty("EndorsementReason")
	private String endorsementReason;

	public String getTransEffectiveDate() {
		return transEffectiveDate;
	}

	public void setTransEffectiveDate(String transEffectiveDate) {
		this.transEffectiveDate = transEffectiveDate;
	}

	public String getEndorsementReason() {
		return endorsementReason;
	}

	public void setEndorsementReason(String endorsementReason) {
		this.endorsementReason = endorsementReason;
	}

	@Override
	public String toString() {
		return "PolicyRateQuotePolicy [transEffectiveDate=" + transEffectiveDate + ", endorsementReason="
				+ endorsementReason + "]";
	}
	
	
}
