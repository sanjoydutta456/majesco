package com.majesco.custom.pi.bulkupdate.model;

public class PolicyRateUpdateRequest {

	private String rate;
	
	private PolicyRateQuotePolicy quotePolicy;

	public String getRate() {
		return rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}

	public PolicyRateQuotePolicy getQuotePolicy() {
		return quotePolicy;
	}

	public void setQuotePolicy(PolicyRateQuotePolicy quotePolicy) {
		this.quotePolicy = quotePolicy;
	}

	@Override
	public String toString() {
		return "PolicyRateUpdateRequest [rate=" + rate + ", quotePolicy=" + quotePolicy + "]";
	}
	
	
}
