package com.majesco.custom.pi.bulkupdate.model;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class PolicyRedoQuotePolicy {
	
	@JsonProperty("UnderwriterCode")
	private String underwriterCode;
	
	@JsonProperty("UnderwriterName")
	private String underwriterName;

	public String getUnderwriterCode() {
		return underwriterCode;
	}

	public void setUnderwriterCode(String underwriterCode) {
		this.underwriterCode = underwriterCode;
	}

	public String getUnderwriterName() {
		return underwriterName;
	}

	public void setUnderwriterName(String underwriterName) {
		this.underwriterName = underwriterName;
	}
}
