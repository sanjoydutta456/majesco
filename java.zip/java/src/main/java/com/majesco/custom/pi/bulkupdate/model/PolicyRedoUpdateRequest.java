package com.majesco.custom.pi.bulkupdate.model;

public class PolicyRedoUpdateRequest {
	
	private String rate;
	
	private PolicyRedoQuotePolicy quotePolicy;

	public String getRate() {
		return rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}

	public PolicyRedoQuotePolicy getQuotePolicy() {
		return quotePolicy;
	}

	public void setQuotePolicy(PolicyRedoQuotePolicy quotePolicy) {
		this.quotePolicy = quotePolicy;
	}
}
