package com.majesco.custom.pi.bulkupdate.model;

import org.codehaus.jackson.annotate.JsonProperty;

public class PolicyUpdateRequest {
	
	@JsonProperty("Policy")
	private Policy policy;
	
	public Policy getPolicy() {
		return policy;
	}

	public void setPolicy(Policy policy) {
		this.policy = policy;
	}
}
