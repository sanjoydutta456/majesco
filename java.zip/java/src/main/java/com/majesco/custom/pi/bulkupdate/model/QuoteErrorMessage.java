package com.majesco.custom.pi.bulkupdate.model;

public class QuoteErrorMessage {

	private String moreinfo;

	public String getMoreinfo() {
		return moreinfo;
	}

	public void setMoreinfo(String moreinfo) {
		this.moreinfo = moreinfo;
	}
}
