package com.majesco.custom.pi.bulkupdate.model;

import java.util.List;

public class QuoteErrorResponse {
	
	private String statuscode;
	private String status;
	private String id;
	private List<QuoteErrorMessage> message;
	
	public String getStatuscode() {
		return statuscode;
	}
	public void setStatuscode(String statuscode) {
		this.statuscode = statuscode;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public List<QuoteErrorMessage> getMessage() {
		return message;
	}
	public void setMessage(List<QuoteErrorMessage> message) {
		this.message = message;
	}
	
	
}
