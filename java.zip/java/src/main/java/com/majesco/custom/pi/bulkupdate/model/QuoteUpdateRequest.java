package com.majesco.custom.pi.bulkupdate.model;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class QuoteUpdateRequest {
	
	private String rate;
	private String fullModel;
	private String updateSSID;
	private String draft;
	private String quickQuote;
	private String sourceSystemUserId;
	private String sourceSystemCode;
	private String parallelProcessing;
	private int sourceSystemRequestNo; 
	private String errorMessagePlaceHolderType = "GID";
	
	private QuotePolicy quotePolicy;

	public String getRate() {
		return rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}

	public String getFullModel() {
		return fullModel;
	}

	public void setFullModel(String fullModel) {
		this.fullModel = fullModel;
	}

	public String getUpdateSSID() {
		return updateSSID;
	}

	public void setUpdateSSID(String updateSSID) {
		this.updateSSID = updateSSID;
	}

	public String getDraft() {
		return draft;
	}

	public void setDraft(String draft) {
		this.draft = draft;
	}
	
	public String getQuickQuote() {
		return quickQuote;
	}

	public void setQuickQuote(String quickQuote) {
		this.quickQuote = quickQuote;
	}

	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}

	public void setSourceSystemUserId(String sourceSystemUserId) {
		this.sourceSystemUserId = sourceSystemUserId;
	}

	public String getSourceSystemCode() {
		return sourceSystemCode;
	}

	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}

	public String getParallelProcessing() {
		return parallelProcessing;
	}

	public void setParallelProcessing(String parallelProcessing) {
		this.parallelProcessing = parallelProcessing;
	}

	public int getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}

	public void setSourceSystemRequestNo(int sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}

	public String getErrorMessagePlaceHolderType() {
		return errorMessagePlaceHolderType;
	}

	public void setErrorMessagePlaceHolderType(String errorMessagePlaceHolderType) {
		this.errorMessagePlaceHolderType = errorMessagePlaceHolderType;
	}

	public QuotePolicy getQuotePolicy() {
		return quotePolicy;
	}

	public void setQuotePolicy(QuotePolicy quotePolicy) {
		this.quotePolicy = quotePolicy;
	}

	@Override
	public String toString() {
		return "QuoteUpdateRequest [rate=" + rate + ", fullModel=" + fullModel + ", updateSSID=" + updateSSID
				+ ", draft=" + draft + ", quickQuote=" + quickQuote + ", sourceSystemUserId=" + sourceSystemUserId
				+ ", sourceSystemCode=" + sourceSystemCode + ", parallelProcessing=" + parallelProcessing
				+ ", sourceSystemRequestNo=" + sourceSystemRequestNo + ", errorMessagePlaceHolderType="
				+ errorMessagePlaceHolderType + ", quotePolicy=" + quotePolicy + "]";
	}
}
