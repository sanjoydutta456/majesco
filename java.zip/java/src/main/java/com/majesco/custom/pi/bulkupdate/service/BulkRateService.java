package com.majesco.custom.pi.bulkupdate.service;

import java.io.IOException;
import java.io.StringWriter;
import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.w3c.dom.Document;

import com.coverall.exceptions.ServiceException;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.events.EventProcessor;
import com.coverall.mt.http.User;
import com.coverall.mt.services.SchedulableService;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServicesDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;
import com.majesco.custom.pi.bulkupdate.constants.BulkUpdateConstants;
import com.majesco.custom.pi.bulkupdate.model.BulkRateUpdateEntity;
import com.majesco.custom.pi.bulkupdate.model.QuoteErrorMessage;
import com.majesco.custom.pi.bulkupdate.model.QuoteErrorResponse;
import com.majesco.custom.pi.bulkupdate.model.QuotePolicy;
import com.majesco.custom.pi.bulkupdate.model.QuoteUpdateRequest;

import oracle.jdbc.OracleTypes;

public class BulkRateService extends SchedulableService {
	

	private static final long serialVersionUID = 1L;
	
	
	private static final String QUERY_GET_UNPROCESSED_RECORDS = "{ ? = call k_bulk_rates.f_get_bulk_rate_on_status (?)}";

	private static final String FUNCTION_NAME = "BulkRating";
	
	BulkRateServiceHelper serviceHelper = new BulkRateServiceHelper();
	BulkUnderwriterServiceHelper uwServiceHelper = new BulkUnderwriterServiceHelper();
	
	public BulkRateService() throws RemoteException {
		super();
	}

	
	public Document process(Document request, String logName) throws Exception {
		Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        User user = null;
        try {
        	serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkRate-Scheduler Started at:" + new Date(), "");
			
			
        	user = ServicesDOMUtil.getUser(request);
            conn = ConnectionPool.getConnection(user);
            CallableStatement call = conn.prepareCall (QUERY_GET_UNPROCESSED_RECORDS);
            call.registerOutParameter (1, OracleTypes.CURSOR);
            call.setString (2, BulkUpdateConstants.STATUS_NOT_PROCESSED);
            serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkRate-Before calling the function to get Records", "");
            call.execute ();
            serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkRate-After calling the function to get Records", "");
            ResultSet rset = (ResultSet)call.getObject (1);
            List<BulkRateUpdateEntity> entityList = buildEntityFromResultSet(rset);
         
            //Processing Quote Entity records
            for(BulkRateUpdateEntity entity: entityList ) {
            	if(entity.getPmbr_entity_type().equalsIgnoreCase(BulkUpdateConstants.ENTITY_TYPE_QUOTE)) {
            		processQuote(user, entity);
            	} 
            }
            
            //Processing Policy Entity records
            serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkRate-Before calling BulkRateServicePolicyHelper", "");
            BulkRateServicePolicyHelper policyHelper = new BulkRateServicePolicyHelper();
            policyHelper.processPolicyList(entityList, user, FUNCTION_NAME);
            serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkRate-After completing BulkRate Policy Processing", "");

        } catch (Exception e) {
			serviceHelper.logMessage(LogEntry.SEVERITY_FATAL, "Error in BulkRateUpdate Service : " + e.getMessage(), "");
		} finally {
            DBUtil.close(rs, pst, conn);
        }
	   return request;     
	}
	
	private List<BulkRateUpdateEntity> buildEntityFromResultSet(ResultSet rset) throws Exception {
		List<BulkRateUpdateEntity> entityList = new ArrayList<>();
		if (rset != null) {
			serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkRateUpdate-Before converting ResultSet into List of objects", "");
			while(rset.next()) {
				BulkRateUpdateEntity entity = new BulkRateUpdateEntity();
				entity.setPmbr_id(rset.getLong(BulkUpdateConstants.COLUMN_PMBR_ID));
				entity.setPmbr_entity_type(rset.getString(BulkUpdateConstants.COLUMN_PMBR_ENTITY_TYPE));
				entity.setPmbr_entity_reference(rset.getString(BulkUpdateConstants.COLUMN_PMBR_ENTITY_REFERENCE));
				entity.setPmbr_quote_policy_number(rset.getString(BulkUpdateConstants.COLUMN_PMBR_QUOTE_POLICY_NUMBER));
				entity.setPmbr_quote_policy_status(rset.getString(BulkUpdateConstants.COLUMN_PMBR_QUOTE_POLICY_STATUS));
				entity.setPmbr_processing_status(rset.getString(BulkUpdateConstants.COLUMN_PMBR_PROCESSING_STATUS));
				entity.setPmbr_processing_date(rset.getDate(BulkUpdateConstants.COLUMN_PMBR_PROCESSING_DATE));
				entity.setPmbr_error_response(rset.getString(BulkUpdateConstants.COLUMN_PMBR_ERROR_RESPONSE));
				entity.setPmbr_new_entity_reference(rset.getString(BulkUpdateConstants.COLUMN_PMBR_NEW_ENTITY_REFERENCE));
				entity.setPmbr_created_date(rset.getDate(BulkUpdateConstants.COLUMN_PMBR_CREATED_DATE));
				entity.setPmbr_created_user(rset.getString(BulkUpdateConstants.COLUMN_PMBR_CREATED_USER));
				entity.setPmbr_updated_date(rset.getDate(BulkUpdateConstants.COLUMN_PMBR_UPDATED_DATE));
				entity.setPmbr_updated_user(rset.getString(BulkUpdateConstants.COLUMN_PMBR_UPDATED_USER));
				
				entityList.add(entity);
			}
		}
		serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkRateUpdate-After converting ResultSet into List of objects", "");
		return entityList;
	}
	
	private void processQuote(User user, BulkRateUpdateEntity entity) throws Exception {
			
			DefaultHttpClient client = new DefaultHttpClient();
			BulkRateServiceHelper serviceHelper = new BulkRateServiceHelper();
		
			try {
				
				//Executing request
				HttpPut putRequest = createHttpPutForQuote(user, entity);
				HttpResponse response = client.execute(putRequest);
	
				//processing the response
				if (response.getStatusLine().getStatusCode() == 200) {
					// update the processing status as processed
					//getQuoteSuccessResponse(response);
					serviceHelper.updateBulkRateRecordStatus(user, BulkUpdateConstants.STATUS_PROCESSED, entity.getPmbr_id(), "");
					
					serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkRate-Quote Processing Sucess-Entity Ref:"
							+ entity.getPmbr_entity_reference(), "Entity Ref:" + entity.getPmbr_entity_reference());
				} else {
					// update the processing status as failed
					String responseContent = getQuoteErrorResponse(response);
					serviceHelper.updateBulkRateRecordStatus(user, BulkUpdateConstants.STATUS_FAILED, entity.getPmbr_id(), responseContent);
					
					serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Error-BulkRateUpdate-Quote Processing-Entity Ref:"
							+ entity.getPmbr_entity_reference(), "Entity Ref:" + entity.getPmbr_entity_reference());
				}
				
			} catch (IOException | ServiceException e) {
				serviceHelper.logMessage(LogEntry.SEVERITY_FATAL, "Error in BulkRateUpdate Service : " + e.getMessage(),
						"EntityRef: " + entity.getPmbr_entity_reference());
			}
		}
	
	private HttpPut createHttpPutForQuote(User user, BulkRateUpdateEntity entity) throws Exception {
		HttpPut putMethod = null;
		Map webserviceParams =  EventProcessor.
    			getWebServiceParameters(BulkUpdateConstants.BULK_RATE_WEBSERVICE_NAME, user);
		if (webserviceParams == null) {
			serviceHelper.logMessage(LogEntry.SEVERITY_FATAL, "Info-BulkRateUpdate-WS Params Map is null", "");
			return putMethod;
		}
		
		String serviceURL = (String)webserviceParams.get(BulkUpdateConstants.QUOTE_UPDATE_API_URL);
		
		serviceURL = serviceURL.replace("{quoteId}", entity.getPmbr_entity_reference());
		
		serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkRateUpdate-Constructed Service URL : " + serviceURL, "");
		
		putMethod = new HttpPut(serviceURL);
		
		String userName = (String)webserviceParams.get(BulkUpdateConstants.QUOTE_POLICY_API_USER_ID);
		String password = (String)webserviceParams.get(BulkUpdateConstants.QUOTE_POLICY_API_USER_PASSWORD);
		
		serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkRateUpdate-WS Param UserName:Pwd:" + userName + ":" + password, "");
		
		String authString = java.util.Base64.getEncoder().encodeToString((userName + ":" + password).getBytes());
		putMethod.setHeader("Authorization", "Basic " + authString);
		
		String jsonString = getJson(buildQuoteRequstObject(user, entity));
		StringEntity input = new StringEntity(jsonString);
		input.setContentType("application/json");
		
		putMethod.setEntity(input);
		
		serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkRateUpdate-before returning HttpPut", "");
		
		return putMethod;
	}
		
	private QuoteUpdateRequest buildQuoteRequstObject(User user, BulkRateUpdateEntity entity) throws Exception {
		QuoteUpdateRequest req = new QuoteUpdateRequest();
		req.setRate("Y");
		req.setFullModel("N");
		req.setUpdateSSID("N");
		
		if (uwServiceHelper
				.getEntityRefCurrentStatus(user, entity.getPmbr_entity_type(), entity.getPmbr_entity_reference())
				.equalsIgnoreCase(BulkUpdateConstants.STATUS_QUOTE_RATING_SUSPENDED)) {
			req.setDraft("Y");
		} else {
			req.setDraft("N");
		}
		
		req.setQuickQuote("N");
		req.setSourceSystemUserId(user.getUserId());
		req.setSourceSystemCode("PAS");
		req.setParallelProcessing("N");
		
		QuotePolicy qp = new QuotePolicy();
	
		req.setQuotePolicy(qp);
		
		serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Quote Payload For Entity : " + entity.getPmbr_entity_reference() + ": " + req.toString(), "");
		
		return req;
	}


	private String getQuoteErrorResponse(HttpResponse response) throws Exception {
		QuoteErrorResponse responseObject = new QuoteErrorResponse();
		String errorRes = EntityUtils.toString(response.getEntity());
		serviceHelper.logMessage(LogEntry.SEVERITY_INFO,
				"Content of Error Response From Quote Update Api :" + errorRes, "");

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(org.codehaus.jackson.map.DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		responseObject = mapper.readValue(errorRes, QuoteErrorResponse.class);
		
		logErrorDetails(responseObject);

		return errorRes;
	}
	
	private String logErrorDetails(QuoteErrorResponse errorResponse) {
		int i = 0;
		StringBuffer sb = new StringBuffer();
		if (errorResponse.getMessage() != null && errorResponse.getMessage().size() > 0) {
			for (QuoteErrorMessage msg : errorResponse.getMessage()) {
				sb.append("|");
				serviceHelper.logMessage(LogEntry.SEVERITY_INFO,
						"Message - " + String.valueOf(++i) + " : " + msg.getMoreinfo(), "");
			}
		}
		return sb.toString();
	}
	
	private String getJson(QuoteUpdateRequest obj){
		ObjectMapper mapper = new ObjectMapper();
		StringWriter writer = new StringWriter();
		try {
			mapper.writeValue(writer, obj);
		} catch (IOException e) {
			serviceHelper.logMessage(LogEntry.SEVERITY_FATAL, "Exception while converting PolicyEndorsementRequest into JSON", "");
		}
		serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Payload in Json Format:" + writer.getBuffer().toString(), "");
		return writer.getBuffer().toString();
		
	}
	
	@Override
	public String getComponentName() {
		return ServletConfigUtil.COMPONENT_PORTAL;
	}
}
