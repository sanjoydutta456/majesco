package com.majesco.custom.pi.bulkupdate.service;

import java.io.IOException;
import java.io.StringWriter;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.codehaus.jackson.map.ObjectMapper;

import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;
import com.majesco.custom.pi.bulkupdate.model.PolicyErrorResponse;
import com.majesco.custom.pi.bulkupdate.model.PolicyTransactionResponse;
import com.majesco.custom.pi.bulkupdate.model.PolicyUpdateRequest;

import oracle.jdbc.OracleTypes;

public class BulkRateServiceHelper {

	private static final String FUNCTION_NAME = "BulkRating";
	private static final String COLUMN_EFFECTIVE_DATE = "MQP_EFFECTIVE_DATE";
	private static final String COLUMN_REVISION_NUMBER = "MQP_REVISION_NUMBER";
	private static final String TRANS_EFFECTIVE_DATE_FORMAT = "yyyy-MM-dd";
	
	private static final String QUERY_UPDATE_PROCESSED_RECORD_STATUS = "{ ? = call k_bulk_rates.f_update_bulk_rate_status (?, ?, ?)}";
	
	private static final String QUERY_FETCH_ENTITY_DETAILS = "SELECT MQP_EFFECTIVE_DATE, MQP_REVISION_NUMBER FROM MIS_QUOTE_POLICIES WHERE MQP_ENTITY_REFERENCE = ? AND ROWNUM < 2 ORDER BY MQP_GID DESC";

	public void updateBulkRateRecordStatus(User user, String status, Long pmbr_id, String errorDetails)
			throws Exception {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;

		try {
			conn = ConnectionPool.getConnection(user);
			CallableStatement call = conn.prepareCall(QUERY_UPDATE_PROCESSED_RECORD_STATUS);
			call.registerOutParameter(1, OracleTypes.INTEGER);
			call.setString(2, status);
			call.setLong(3, pmbr_id);

			Clob clob = conn.createClob();
			clob.setString(1, errorDetails);
			call.setClob(4, clob);

			call.execute();

			Integer result = (Integer) call.getObject(1);

			if (result != 0) {
				logMessage(LogEntry.SEVERITY_INFO, "BulkRating-Error while updating Processed Status in db :" + pmbr_id, "");
			}
		} catch (Exception e) {
			logMessage(LogEntry.SEVERITY_FATAL, "BulkRating-Exception while updating the Process status record", e.getMessage());
		} finally {
			DBUtil.close(rs, pst, conn);
		}
	}
	
	public String getEntityEffectiveDate(User user, String entityRef) throws Exception {
		logMessage(LogEntry.SEVERITY_INFO, "BulkRateServiceHelper - control inside getEntityEffectiveDate() method", "");
		String entityEffectiveDate = null;
		Date retrivedEffectiveDate = null;
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			conn = ConnectionPool.getConnection(user);
			pst = conn.prepareStatement(QUERY_FETCH_ENTITY_DETAILS);
			pst.setString(1, entityRef);
			rs = pst.executeQuery();
			while (rs.next()) {
				retrivedEffectiveDate = rs.getDate(COLUMN_EFFECTIVE_DATE);
				SimpleDateFormat sf = new SimpleDateFormat(TRANS_EFFECTIVE_DATE_FORMAT);
				entityEffectiveDate = sf.format(retrivedEffectiveDate);
				logMessage(LogEntry.SEVERITY_INFO, "BulkRateServiceHelper - Formatted TransEffectiveDate(yyyy-MM-dd) :" + entityEffectiveDate, "");
			}
		} catch (Exception e) {
			logMessage(LogEntry.SEVERITY_FATAL, "Exception while retrieving Effective Date from database", "");
		} finally {
			DBUtil.close(rs, pst, conn);
		}

		return entityEffectiveDate;
	}
	
	public Integer getEntityRevisionNumber(User user, String entityRef) throws Exception {
		logMessage(LogEntry.SEVERITY_INFO, "BulkRateServiceHelper - control inside getEntityRevisionNumber() method", "");
		Integer entityRevisionNumber = 0;
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			conn = ConnectionPool.getConnection(user);
			pst = conn.prepareStatement(QUERY_FETCH_ENTITY_DETAILS);
			pst.setString(1, entityRef);
			rs = pst.executeQuery();
			while (rs.next()) {
				entityRevisionNumber = rs.getInt(COLUMN_REVISION_NUMBER);
				logMessage(LogEntry.SEVERITY_INFO, "BulkRateServiceHelper - Revision Number of Entity : " + entityRef
						+ " Revision Number : " + entityRevisionNumber, "");
			}
		} catch (Exception e) {
			logMessage(LogEntry.SEVERITY_FATAL, "Exception while retrieving Revision Number from database", "");
		} finally {
			DBUtil.close(rs, pst, conn);
		}

		return entityRevisionNumber;
	}

	public String getJson(PolicyTransactionResponse obj) {
		ObjectMapper mapper = new ObjectMapper();
		StringWriter writer = new StringWriter();
		try {
			mapper.writeValue(writer, obj);
		} catch (IOException e) {
			logMessage(LogEntry.SEVERITY_FATAL, "Exception while converting PolicyNewTransactionResponse into JSON", "");
		}
		logMessage(LogEntry.SEVERITY_INFO, "PolicyTransactionResponse in Json Format:" + writer.getBuffer().toString(), "");
		return writer.getBuffer().toString();

	}

	public String getJson(PolicyErrorResponse obj) {
		ObjectMapper mapper = new ObjectMapper();
		StringWriter writer = new StringWriter();
		try {
			mapper.writeValue(writer, obj);
		} catch (IOException e) {
			logMessage(LogEntry.SEVERITY_FATAL, "Exception while converting PolicyErrorResponse into JSON", "");
		}
		logMessage(LogEntry.SEVERITY_INFO, "PolicyErrorResponse in Json Format:" + writer.getBuffer().toString(), "");
		return writer.getBuffer().toString();

	}

	public String getJson(PolicyUpdateRequest obj) {
		ObjectMapper mapper = new ObjectMapper();
		StringWriter writer = new StringWriter();
		try {
			mapper.writeValue(writer, obj);
		} catch (IOException e) {
			logMessage(LogEntry.SEVERITY_FATAL, "Exception while converting PolicyUpdateRequest into JSON", "");
		}
		logMessage(LogEntry.SEVERITY_INFO, "PolicyUpdateRequest in Json Format:" + writer.getBuffer().toString(), "");
		return writer.getBuffer().toString();

	}

	public void logMessage(int logLevel, String inputMsg, String objMsg) {
		LogMinder.getLogMinder().log(logLevel, BulkRateServiceHelper.class.getName(), FUNCTION_NAME,
				ServletConfigUtil.COMPONENT_PORTAL, new Object[] { objMsg }, inputMsg, null,
				LogMinderDOMUtil.VALUE_SCHEDULAR);
	}

}
