package com.majesco.custom.pi.bulkupdate.service;

import java.io.IOException;
import java.io.StringWriter;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.map.ObjectMapper;

import com.coverall.mt.events.EventProcessor;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.majesco.custom.pi.bulkupdate.constants.BulkUpdateConstants;
import com.majesco.custom.pi.bulkupdate.model.BulkRateUpdateEntity;
import com.majesco.custom.pi.bulkupdate.model.PolicyRateQuotePolicy;
import com.majesco.custom.pi.bulkupdate.model.PolicyRateUpdateRequest;

public class BulkRateServicePolicyHelper {
	
	private String functionName = "";
	
	private static final String ENDORSEMENT_URL = "endorse";
	private static final String ENDORSEMENT_REASON = "Rate Change";
	
	BulkRateServiceHelper serviceHelper = new BulkRateServiceHelper();
	BulkUnderwriterServiceHelper uwServiceHelper = new BulkUnderwriterServiceHelper();
	DefaultHttpClient client = new DefaultHttpClient();
	
	
	public void processPolicyList(List<BulkRateUpdateEntity> entityList, User user, String functionName) {
		this.functionName = functionName;
		serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkRate-Control inside BulkRateServicePolicyHelper", "");
		try {
			for (BulkRateUpdateEntity entity : entityList) {
				if (entity.getPmbr_entity_type().equalsIgnoreCase(BulkUpdateConstants.ENTITY_TYPE_POLICY)) {
					processPolicy(user, entity);
				}
			}
		} catch (Exception e) {
			serviceHelper.logMessage(LogEntry.SEVERITY_FATAL, "Error in BulkRateService Policy Helper : " + e.getMessage(), "");
		}

	}
	
	
	private void processPolicy(User user, BulkRateUpdateEntity entity) {
		try {
			// Retrieving Webservice Parameters
			Map<String, String> wsParams = getWSParameters(user);
			String baseUrl = (String) wsParams.get(BulkUpdateConstants.POLICY_BASE_API_URL);
			serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkRateServicePolicyHelper-Policy Base URL : " + baseUrl, "");
			
			String userName = (String)wsParams.get(BulkUpdateConstants.QUOTE_POLICY_API_USER_ID);
			String password = (String)wsParams.get(BulkUpdateConstants.QUOTE_POLICY_API_USER_PASSWORD);
			serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkRateServicePolicyHelper-WS Param UserName:Pwd:" + userName + ":" + password, "");
			
			// If the policy is booked or not booked but revision number is more than zero then Endorsement transaction API should be called
			// If the policy is not booked and revision number is zero then Update transaction API should be called
			
			if (uwServiceHelper.getPolicyBookingStatus(user, entity.getPmbr_entity_type(), entity.getPmbr_entity_reference()).equalsIgnoreCase("N")) {
				if (serviceHelper.getEntityRevisionNumber(user, entity.getPmbr_entity_reference()) == 0) {
					performUpdateTransaction(entity, baseUrl, userName, password, user);
					serviceHelper.logMessage(LogEntry.SEVERITY_INFO,
							"Info-BulkRateServicePolicyHelper-Policy Not Booked with Revision Number Zero", "");
				} else {
					serviceHelper.logMessage(LogEntry.SEVERITY_INFO,
							"Info-BulkRateServicePolicyHelper-Policy Not Booked with Revision Number other than Zero", "");
					performEndorseTransaction(entity, baseUrl, userName, password, user);
				}
			} else {
				serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUpdateUnderwriterPolicyHelper-Policy is Booked", "");
				performEndorseTransaction(entity, baseUrl, userName, password, user);
			}
			
		} catch (Exception e) {
			serviceHelper.logMessage(LogEntry.SEVERITY_FATAL, "Error in BulkRateService Policy Helper : " + e.getMessage(), "");
		}
	}
	
	private void performEndorseTransaction(BulkRateUpdateEntity entity, String baseUrl, String userName, String password, User user) {
		try {
			HttpPost postRequest = createHttpPostForEndoTransaction(entity, baseUrl, userName, password, user);
			HttpResponse response = this.client.execute(postRequest);
			if (response.getStatusLine().getStatusCode() == 200) {
				serviceHelper.updateBulkRateRecordStatus(user, BulkUpdateConstants.STATUS_PROCESSED, entity.getPmbr_id(), "");
				
				serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkRateServicePolicyHelper-Policy Endo Transaction Sucess-Entity Ref:"
						+ entity.getPmbr_entity_reference(), "Entity Ref:" + entity.getPmbr_entity_reference());
			} else {
				updateProcessingStatusForErrorStatusCodes(response, user, entity.getPmbr_id(), entity.getPmbr_entity_reference());
			}
			
		} catch (Exception e) {
			serviceHelper.logMessage(LogEntry.SEVERITY_FATAL, "Error in BulkUpdateUnderwriterServicePolicyHelper : Endo Transaction : " + e.getMessage(), "");
		}
	}
	
	private void performUpdateTransaction(BulkRateUpdateEntity entity, String baseUrl, String userName, String password, User user) {
		try {
			HttpPut putRequest = createHttpPutForUpdateTransaction(entity, baseUrl, userName, password, user);
			HttpResponse response = this.client.execute(putRequest);
			if (response.getStatusLine().getStatusCode() == 200) {
				serviceHelper.updateBulkRateRecordStatus(user, BulkUpdateConstants.STATUS_PROCESSED, entity.getPmbr_id(), "");
				
				serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkRateServicePolicyHelper-Policy Update Transaction Sucess-Entity Ref:"
						+ entity.getPmbr_entity_reference(), "Entity Ref:" + entity.getPmbr_entity_reference());
			} else {
				updateProcessingStatusForErrorStatusCodes(response, user, entity.getPmbr_id(), entity.getPmbr_entity_reference());
			}
			
		} catch (Exception e) {
			serviceHelper.logMessage(LogEntry.SEVERITY_FATAL, "Error in BulkUpdateUnderwriterServicePolicyHelper : Update Transaction : " + e.getMessage(), "");
		}
	}
	
	
	private HttpPost createHttpPostForEndoTransaction(BulkRateUpdateEntity entity, String baseUrl,
			String userName, String password, User user) throws Exception {
		HttpPost postMethod = null;
		String serviceUrl = null;
		
		// baseUrl/{policyId}/endorse
		serviceUrl = baseUrl + "/" + entity.getPmbr_entity_reference() + "/" + ENDORSEMENT_URL;
		serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkRateServicePolicyHelper-Policy Endo URL:" + serviceUrl, "");

		postMethod = new HttpPost(serviceUrl);
		
		String authString = java.util.Base64.getEncoder().encodeToString((userName + ":" + password).getBytes());
		postMethod.setHeader("Authorization", "Basic " + authString);
		
		String jsonString = getJson(buildPolicyRequstObject(user, entity));
		StringEntity input = new StringEntity(jsonString);
		input.setContentType("application/json");
		
		postMethod.setEntity(input);
		
		return postMethod;
	}
	
	private HttpPut createHttpPutForUpdateTransaction(BulkRateUpdateEntity entity, String baseUrl,
			String userName, String password, User user) throws Exception {
		HttpPut putMethod = null;
		String serviceUrl = null;
		
		// baseUrl/{policyId} 
		serviceUrl = baseUrl + "/" + entity.getPmbr_entity_reference();
		serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkRateServicePolicyHelper-Policy Update URL:" + serviceUrl, "");
		putMethod = new HttpPut(serviceUrl);
		
		String authString = java.util.Base64.getEncoder().encodeToString((userName + ":" + password).getBytes());
		putMethod.setHeader("Authorization", "Basic " + authString);
		
		String jsonString = getJson(buildPolicyRequstObject(user, entity));
		StringEntity input = new StringEntity(jsonString);
		input.setContentType("application/json");
		
		putMethod.setEntity(input);
		
		return putMethod;
	}
	
	private void updateProcessingStatusForErrorStatusCodes(HttpResponse response, User user, Long pmbrId, String entityRef) throws Exception {
		String errorResponse = EntityUtils.toString(response.getEntity());
		serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Error-BulkRateServicePolicyHelper-Policy Processing-Error Response:"
				+ errorResponse, "");
		serviceHelper.updateBulkRateRecordStatus(user, BulkUpdateConstants.STATUS_FAILED, pmbrId, errorResponse);
		serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Error-BulkRateServicePolicyHelper-Policy Processing-Entity Ref:"
				+ entityRef, "");
	} 
	
	private PolicyRateUpdateRequest buildPolicyRequstObject(User user, BulkRateUpdateEntity entity) {
		PolicyRateUpdateRequest req = new PolicyRateUpdateRequest();
		try {
			req.setRate("Y");
	
			PolicyRateQuotePolicy qp = new PolicyRateQuotePolicy();
			qp.setEndorsementReason(ENDORSEMENT_REASON);
			qp.setTransEffectiveDate(serviceHelper.getEntityEffectiveDate(user, entity.getPmbr_entity_reference()));
		
			req.setQuotePolicy(qp);
	
			serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Policy Payload For Entity : " + entity.getPmbr_entity_reference() + ": " + req.toString(), "");
		} catch (Exception e) {
			serviceHelper.logMessage(LogEntry.SEVERITY_FATAL, "Exception in BulkRateServicePolicyHelper while building the Policy Payload", "");
		}
		
		return req;
	}
	
	private String getJson(PolicyRateUpdateRequest obj){
		ObjectMapper mapper = new ObjectMapper();
		StringWriter writer = new StringWriter();
		try {
			mapper.writeValue(writer, obj);
		} catch (IOException e) {
			serviceHelper.logMessage(LogEntry.SEVERITY_FATAL, "Exception while converting PolicyRateUpdateRequest into JSON", "");
		}
		serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Payload in Json Format:" + writer.getBuffer().toString(), "");
		return writer.getBuffer().toString();
		
	}
	
	@SuppressWarnings("unchecked")
	private Map<String, String> getWSParameters(User user) throws Exception {
		
		Map<String, String> webserviceParams = EventProcessor
				.getWebServiceParameters(BulkUpdateConstants.BULK_RATE_WEBSERVICE_NAME, user);
		if (webserviceParams == null) {
			serviceHelper.logMessage(LogEntry.SEVERITY_FATAL, "Info-BulkRatePolicyHelper-WS Params Map is null", "");
			return null;
		}
		
		return webserviceParams;
	}
}
