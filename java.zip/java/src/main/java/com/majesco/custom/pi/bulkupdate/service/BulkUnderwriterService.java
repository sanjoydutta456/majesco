package com.majesco.custom.pi.bulkupdate.service;

import java.io.IOException;
import java.io.StringWriter;
import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.w3c.dom.Document;

import com.coverall.exceptions.ServiceException;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.events.EventProcessor;
import com.coverall.mt.http.User;
import com.coverall.mt.services.SchedulableService;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServicesDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;
import com.majesco.custom.pi.bulkupdate.constants.BulkUpdateConstants;
import com.majesco.custom.pi.bulkupdate.model.BulkUpdateUnderwriterEntity;
import com.majesco.custom.pi.bulkupdate.model.QuoteUpdateRequest;
import com.majesco.custom.pi.bulkupdate.model.QuoteErrorMessage;
import com.majesco.custom.pi.bulkupdate.model.QuoteErrorResponse;
import com.majesco.custom.pi.bulkupdate.model.QuotePolicy;

import oracle.jdbc.OracleTypes;

public class BulkUnderwriterService extends SchedulableService {

	private static final long serialVersionUID = 1L;
	
	public BulkUnderwriterService() throws RemoteException {
		super();
	}

	private static final String QUERY_GET_UNPROCESSED_RECORDS = "{ ? = call k_bulk_underwriter.f_get_bulk_underwriter_on_status (?)}";

	private static final String FUNCTION_NAME = "BulkUnderwriter";
	
	private BulkUnderwriterServiceHelper serviceHelper = new BulkUnderwriterServiceHelper();

	
	public Document process(Document request, String logName) throws Exception {
		Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        User user = null;
        try {
        	logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUpdateUnderwriter-Scheduler Started at:" + new Date(), "");
			
			
        	user = ServicesDOMUtil.getUser(request);
            conn = ConnectionPool.getConnection(user);
            CallableStatement call = conn.prepareCall (QUERY_GET_UNPROCESSED_RECORDS);
            call.registerOutParameter (1, OracleTypes.CURSOR);
            call.setString (2, BulkUpdateConstants.STATUS_NOT_PROCESSED);
            logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUpdateUnderwriter-Before calling the function to get Records", "");
            call.execute ();
            logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUpdateUnderwriter-After calling the function to get Records", "");
            ResultSet rset = (ResultSet)call.getObject (1);
            List<BulkUpdateUnderwriterEntity> entityList = buildEntityFromResultSet(rset);
         
            //Processing Quote Entity records
            for(BulkUpdateUnderwriterEntity entity: entityList ) {
            	if(entity.getPmbu_entity_type().equalsIgnoreCase(BulkUpdateConstants.ENTITY_TYPE_QUOTE)) {
            		processQuote(user, entity);
            	} 
            }
            
            //Processing Policy Entity records
            BulkUnderwriterServicePolicyHelper policyHelper = new BulkUnderwriterServicePolicyHelper();
            policyHelper.processPolicyList(entityList, user, FUNCTION_NAME);

        } catch (Exception e) {
			logMessage(LogEntry.SEVERITY_FATAL, "Error in BulkUpdateUnderwriter Service : " + e.getMessage(), "");
		} finally {
            DBUtil.close(rs, pst, conn);
        }
	   return request;     
	}
	
	private List<BulkUpdateUnderwriterEntity> buildEntityFromResultSet(ResultSet rset) throws Exception {
		List<BulkUpdateUnderwriterEntity> entityList = new ArrayList<>();
		if (rset != null) {
			logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUpdateUnderwriter-Before converting ResultSet into List of objects", "");
			while(rset.next()) {
				BulkUpdateUnderwriterEntity entity = new BulkUpdateUnderwriterEntity();
				entity.setPmbu_id(rset.getLong(BulkUpdateConstants.COLUMN_PMBU_ID));
				entity.setPmbu_entity_type(rset.getString(BulkUpdateConstants.COLUMN_PMBU_ENTITY_TYPE));
				entity.setPmbu_entity_reference(rset.getString(BulkUpdateConstants.COLUMN_PMBU_ENTITY_REFERENCE));
				entity.setPmbu_quote_policy_number(rset.getString(BulkUpdateConstants.COLUMN_PMBU_QUOTE_POLICY_NUMBER));
				entity.setPmbu_quote_policy_status(rset.getString(BulkUpdateConstants.COLUMN_PMBU_QUOTE_POLICY_STATUS));
				entity.setPmbu_from_underwriter(rset.getString(BulkUpdateConstants.COLUMN_PMBU_FROM_UNDERWRITER));
				entity.setPmbu_to_underwriter_code(rset.getString(BulkUpdateConstants.COLUMN_PMBU_TO_UNDERWRITER_CODE));
				entity.setPmbu_to_underwriter(rset.getString(BulkUpdateConstants.COLUMN_PMBU_TO_UNDERWRITER));
				entity.setPmbu_processing_status(rset.getString(BulkUpdateConstants.COLUMN_PMBU_PROCESSING_STATUS));
				entity.setPmbu_processing_date(rset.getDate(BulkUpdateConstants.COLUMN_PMBU_PROCESSING_DATE));
				entity.setPmbu_error_response(rset.getString(BulkUpdateConstants.COLUMN_PMBU_ERROR_RESPONSE));
				entity.setPmbu_new_entity_reference(rset.getString(BulkUpdateConstants.COLUMN_PMBU_NEW_ENTITY_REFERENCE));
				entity.setPmbu_created_date(rset.getDate(BulkUpdateConstants.COLUMN_PMBU_CREATED_DATE));
				entity.setPmbu_created_user(rset.getString(BulkUpdateConstants.COLUMN_PMBU_CREATED_USER));
				entity.setPmbu_updated_date(rset.getDate(BulkUpdateConstants.COLUMN_PMBU_UPDATED_DATE));
				entity.setPmbu_updated_user(rset.getString(BulkUpdateConstants.COLUMN_PMBU_UPDATED_USER));
				
				entityList.add(entity);
			}
		}
		logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUpdateUnderwriter-After converting ResultSet into List of objects", "");
		return entityList;
	}
	
	private void processQuote(User user, BulkUpdateUnderwriterEntity entity) throws Exception {
		
		DefaultHttpClient client = new DefaultHttpClient();
		BulkUnderwriterServiceHelper serviceHelper = new BulkUnderwriterServiceHelper();
	
		try {
			
			//Executing request
			HttpPut putRequest = createHttpPutForQuote(user, entity);
			HttpResponse response = client.execute(putRequest);

			//processing the response
			if (response.getStatusLine().getStatusCode() == 200) {
				// update the processing status as processed
				//getQuoteSuccessResponse(response);
				serviceHelper.updateBulkUnderwriterRecordStatus(user, BulkUpdateConstants.STATUS_PROCESSED, entity.getPmbu_id(), "");
				
				logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUpdateUnderwriter-Quote Processing Sucess-Entity Ref:"
						+ entity.getPmbu_entity_reference(), "Entity Ref:" + entity.getPmbu_entity_reference());
			} else {
				// update the processing status as failed
				String responseContent = getQuoteErrorResponse(response);
				serviceHelper.updateBulkUnderwriterRecordStatus(user, BulkUpdateConstants.STATUS_FAILED, entity.getPmbu_id(), responseContent);
				
				logMessage(LogEntry.SEVERITY_INFO, "Error-BulkUpdateUnderwriter-Quote Processing-Entity Ref:"
						+ entity.getPmbu_entity_reference(), "Entity Ref:" + entity.getPmbu_entity_reference());
			}
			
		} catch (IOException | ServiceException e) {
			logMessage(LogEntry.SEVERITY_FATAL, "Error in BulkUpdateUnderwriter Service : " + e.getMessage(),
					"EntityRef: " + entity.getPmbu_entity_reference());
		}
	}
	
	private HttpPut createHttpPutForQuote(User user, BulkUpdateUnderwriterEntity entity) throws Exception {
		HttpPut putMethod = null;
		Map webserviceParams =  EventProcessor.
    			getWebServiceParameters(BulkUpdateConstants.BULK_UNDERWRITER_WEBSERVICE_NAME, user);
		if (webserviceParams == null) {
			logMessage(LogEntry.SEVERITY_FATAL, "Info-BulkUpdateUnderwriter-WS Params Map is null", "");
			return putMethod;
		}
		
		String serviceURL = (String)webserviceParams.get(BulkUpdateConstants.QUOTE_UPDATE_API_URL);
		
		serviceURL = serviceURL.replace("{quoteId}", entity.getPmbu_entity_reference());
		
		logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUpdateUnderwriter-Constructed Service URL : " + serviceURL, "");
		
		putMethod = new HttpPut(serviceURL);
		
		String userName = (String)webserviceParams.get(BulkUpdateConstants.QUOTE_POLICY_API_USER_ID);
		String password = (String)webserviceParams.get(BulkUpdateConstants.QUOTE_POLICY_API_USER_PASSWORD);
		
		logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUpdateUnderwriter-WS Param UserName:Pwd:" + userName + ":" + password, "");
		
		String authString = java.util.Base64.getEncoder().encodeToString((userName + ":" + password).getBytes());
		putMethod.setHeader("Authorization", "Basic " + authString);
		
		String jsonString = getJson(buildQuoteRequstObject(user, entity));
		StringEntity input = new StringEntity(jsonString);
		input.setContentType("application/json");
		
		putMethod.setEntity(input);
		
		logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUpdateUnderwriter-before returning HttpPut", "");
		
		return putMethod;
	}
		
	private QuoteUpdateRequest buildQuoteRequstObject(User user, BulkUpdateUnderwriterEntity entity) throws Exception {
		QuoteUpdateRequest req = new QuoteUpdateRequest();
		req.setRate("N");
		req.setFullModel("N");
		req.setUpdateSSID("N");
		
		if (serviceHelper
				.getEntityRefCurrentStatus(user, entity.getPmbu_entity_type(), entity.getPmbu_entity_reference())
				.equalsIgnoreCase(BulkUpdateConstants.STATUS_QUOTE_RATING_SUSPENDED)) {
			req.setDraft("Y");
		} else {
			req.setDraft("N");
		}
		
		req.setQuickQuote("N");
		req.setSourceSystemUserId(user.getUserId());
		req.setSourceSystemCode("PAS");
		req.setParallelProcessing("N");
		
		QuotePolicy qp = new QuotePolicy();
		if (entity.getPmbu_to_underwriter_code() != null) {
			qp.setUnderwriterCode(entity.getPmbu_to_underwriter_code());
		} else {
			qp.setUnderwriterCode("");
		}
		if (entity.getPmbu_to_underwriter() != null) {
			qp.setUnderwriterName(entity.getPmbu_to_underwriter());
		} else {
			qp.setUnderwriterName("");
		}
	
		req.setQuotePolicy(qp);
		
		logMessage(LogEntry.SEVERITY_INFO, "Quote Payload For Entity : " + entity.getPmbu_entity_reference() + ": " + req.toString(), "");
		
		return req;
	}

	private String getQuoteErrorResponse(HttpResponse response) throws Exception {
		QuoteErrorResponse responseObject = new QuoteErrorResponse();
		String errorRes = EntityUtils.toString(response.getEntity());
		logMessage(LogEntry.SEVERITY_INFO,
				"Content of Error Response From Quote Update Api :" + errorRes, "");

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(org.codehaus.jackson.map.DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		responseObject = mapper.readValue(errorRes, QuoteErrorResponse.class);
		
		logErrorDetails(responseObject);

		return errorRes;
	}
	
	private String logErrorDetails(QuoteErrorResponse errorResponse) {
		int i = 0;
		StringBuffer sb = new StringBuffer();
		if (errorResponse.getMessage() != null && errorResponse.getMessage().size() > 0) {
			for (QuoteErrorMessage msg : errorResponse.getMessage()) {
				sb.append("|");
				logMessage(LogEntry.SEVERITY_INFO,
						"Message - " + String.valueOf(++i) + " : " + msg.getMoreinfo(), "");
			}
		}
		return sb.toString();
	}
	
	private String getJson(QuoteUpdateRequest obj){
		ObjectMapper mapper = new ObjectMapper();
		StringWriter writer = new StringWriter();
		try {
			mapper.writeValue(writer, obj);
		} catch (IOException e) {
			logMessage(LogEntry.SEVERITY_FATAL, "Exception while converting PolicyEndorsementRequest into JSON", "");
		}
		logMessage(LogEntry.SEVERITY_INFO, "Payload in Json Format:" + writer.getBuffer().toString(), "");
		return writer.getBuffer().toString();
		
	}
	
	private void logMessage(int logLevel, String inputMsg, String objMsg) {
		LogMinder.getLogMinder().log(logLevel, BulkUnderwriterService.class.getName(), FUNCTION_NAME,
				ServletConfigUtil.COMPONENT_PORTAL, new Object[]{objMsg}, 
				inputMsg, null, LogMinderDOMUtil.VALUE_SCHEDULAR);
	}
	
	@Override
	public String getComponentName() {
		return ServletConfigUtil.COMPONENT_PORTAL;
	}
}
