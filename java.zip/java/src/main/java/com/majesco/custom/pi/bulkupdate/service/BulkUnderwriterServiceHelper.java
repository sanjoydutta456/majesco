package com.majesco.custom.pi.bulkupdate.service;

import java.io.IOException;
import java.io.StringWriter;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.codehaus.jackson.map.ObjectMapper;

import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;
import com.majesco.custom.pi.bulkupdate.model.PolicyErrorResponse;
import com.majesco.custom.pi.bulkupdate.model.PolicyRedoUpdateRequest;
import com.majesco.custom.pi.bulkupdate.model.PolicyTransactionResponse;
import com.majesco.custom.pi.bulkupdate.model.PolicyUpdateRequest;

import oracle.jdbc.OracleTypes;

public class BulkUnderwriterServiceHelper {
	
	private static final String FUNCTION_NAME = "BulkUnderwriter";
	private static final String QUERY_UPDATE_PROCESSED_RECORD_STATUS = "{ ? = call k_bulk_underwriter.f_update_bulk_underwriter_status (?, ?, ?)}";
	private static final String QUERY_GET_ENTITY_REF_CURRENT_STATUS = "{ ? = call K_WORKFLOW_ACTIVITY_MANAGEMENT.F_GET_STATUS(?, ?)}";
	private static final String QUERY_GET_POLICY_BOOKING_STATUS = "{ ? = call k_transaction_management.f_is_booked(?, ?)}";
	
	public void updateBulkUnderwriterRecordStatus(User user, String status, Long pmbu_id, String errorDetails) throws Exception {
		Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            conn = ConnectionPool.getConnection(user);
            CallableStatement call = conn.prepareCall (QUERY_UPDATE_PROCESSED_RECORD_STATUS);
            call.registerOutParameter (1, OracleTypes.INTEGER);
            call.setString (2, status);
            call.setLong(3, pmbu_id);
            
            Clob clob = conn.createClob();
            clob.setString(1, errorDetails);
            call.setClob(4, clob);
            
            call.execute ();
            
            Integer result = (Integer)call.getObject (1);
            
            if (result != 0 ) {
            	logMessage(LogEntry.SEVERITY_INFO, "BulkUnderwriter-Error while updating Processed Status in db :" + pmbu_id, "");
            }
        } catch (Exception e) {
        	logMessage(LogEntry.SEVERITY_FATAL, "BulkUnderwriter-Exception while updating the Process status record", e.getMessage());
        } finally {
            DBUtil.close(rs, pst, conn);
        }
	}
	
	public String getEntityRefCurrentStatus(User user, String entityType, String entityRef) throws Exception {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		String currentStatus = null;

		try {
			conn = ConnectionPool.getConnection(user);
			CallableStatement call = conn.prepareCall(QUERY_GET_ENTITY_REF_CURRENT_STATUS);
			call.registerOutParameter(1, OracleTypes.VARCHAR);
			call.setString(2, entityType);
			call.setString(3, entityRef);

			call.execute();

			currentStatus = (String) call.getObject(1);
			logMessage(LogEntry.SEVERITY_INFO, "BulkUnderwriter-Current Status of Entity :" + entityRef + " :" + currentStatus, "");

		} catch (Exception e) {
			logMessage(LogEntry.SEVERITY_FATAL,
					"BulkUnderwriter-Exception while retrieving Current status of the entity :" + entityRef, e.getMessage());
		} finally {
			DBUtil.close(rs, pst, conn);
		}

		return currentStatus;
	}
	
	public String getPolicyBookingStatus(User user, String entityType, String entityRef) throws Exception {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		String bookingStatus = null;

		try {
			conn = ConnectionPool.getConnection(user);
			CallableStatement call = conn.prepareCall(QUERY_GET_POLICY_BOOKING_STATUS);
			call.registerOutParameter(1, OracleTypes.VARCHAR);
			call.setString(2, entityType);
			call.setString(3, entityRef);

			call.execute();

			bookingStatus = (String) call.getObject(1);
			logMessage(LogEntry.SEVERITY_INFO, "BulkUnderwriter-Policy Booking Status - Entity :" + entityRef + " : " + bookingStatus, "");

		} catch (Exception e) {
			logMessage(LogEntry.SEVERITY_FATAL,
					"BulkUnderwriter-Exception while retrieving Policy Booking status of the entity : " + entityRef, e.getMessage());
		} finally {
			DBUtil.close(rs, pst, conn);
		}

		return bookingStatus;
	}
		
	public String getJson(PolicyTransactionResponse obj){
		ObjectMapper mapper = new ObjectMapper();
		StringWriter writer = new StringWriter();
		try {
			mapper.writeValue(writer, obj);
		} catch (IOException e) {
			logMessage(LogEntry.SEVERITY_FATAL, "Exception while converting PolicyNewTransactionResponse into JSON", "");
		}
		logMessage(LogEntry.SEVERITY_INFO, "PolicyTransactionResponse in Json Format:" + writer.getBuffer().toString(), "");
		return writer.getBuffer().toString();
		
	}
	
	public String getJson(PolicyErrorResponse obj){
		ObjectMapper mapper = new ObjectMapper();
		StringWriter writer = new StringWriter();
		try {
			mapper.writeValue(writer, obj);
		} catch (IOException e) {
			logMessage(LogEntry.SEVERITY_FATAL, "Exception while converting PolicyErrorResponse into JSON", "");
		}
		logMessage(LogEntry.SEVERITY_INFO, "PolicyErrorResponse in Json Format:" + writer.getBuffer().toString(), "");
		return writer.getBuffer().toString();
		
	}
	
	public String getJson(PolicyUpdateRequest obj){
		ObjectMapper mapper = new ObjectMapper();
		StringWriter writer = new StringWriter();
		try {
			mapper.writeValue(writer, obj);
		} catch (IOException e) {
			logMessage(LogEntry.SEVERITY_FATAL, "Exception while converting PolicyUpdateRequest into JSON", "");
		}
		logMessage(LogEntry.SEVERITY_INFO, "PolicyUpdateRequest in Json Format:" + writer.getBuffer().toString(), "");
		return writer.getBuffer().toString();
		
	}
	
	public String getJson(PolicyRedoUpdateRequest obj){
		ObjectMapper mapper = new ObjectMapper();
		StringWriter writer = new StringWriter();
		try {
			mapper.writeValue(writer, obj);
		} catch (IOException e) {
			logMessage(LogEntry.SEVERITY_FATAL, "Exception while converting PolicyRedoUpdateRequest into JSON", "");
		}
		logMessage(LogEntry.SEVERITY_INFO, "PolicyRedoUpdateRequest in Json Format:" + writer.getBuffer().toString(), "");
		return writer.getBuffer().toString();
		
	}
	
	public void logMessage(int logLevel, String inputMsg, String objMsg) {
		LogMinder.getLogMinder().log(logLevel, BulkUnderwriterServiceHelper.class.getName(), FUNCTION_NAME,
				ServletConfigUtil.COMPONENT_PORTAL, new Object[]{objMsg}, 
				inputMsg, null, LogMinderDOMUtil.VALUE_SCHEDULAR);
	}
}
