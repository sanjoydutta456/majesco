package com.majesco.custom.pi.bulkupdate.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.map.ObjectMapper;

import com.coverall.mt.events.EventProcessor;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.majesco.custom.pi.bulkupdate.constants.BulkUpdateConstants;
import com.majesco.custom.pi.bulkupdate.model.BulkRateUpdateEntity;
import com.majesco.custom.pi.bulkupdate.model.BulkUpdateUnderwriterEntity;
import com.majesco.custom.pi.bulkupdate.model.Policy;
import com.majesco.custom.pi.bulkupdate.model.PolicyBaseResponse;
import com.majesco.custom.pi.bulkupdate.model.PolicyErrorResponse;
import com.majesco.custom.pi.bulkupdate.model.PolicyRateQuotePolicy;
import com.majesco.custom.pi.bulkupdate.model.PolicyRateUpdateRequest;
import com.majesco.custom.pi.bulkupdate.model.PolicyRedoQuotePolicy;
import com.majesco.custom.pi.bulkupdate.model.PolicyRedoUpdateRequest;
import com.majesco.custom.pi.bulkupdate.model.PolicyTransactionResponse;
import com.majesco.custom.pi.bulkupdate.model.PolicyUpdateRequest;

public class BulkUnderwriterServicePolicyHelper {

	private String functionName = "";
	
	// at the end of Start New Transaction URL policyEntityRef should be appended
	private static final String START_NEW_TRANSACTION_URL = 
			"/startNewTransaction?productCode=WK&entityType=POLICY&transactionName=ChangeUnderwriter&optimizedFlow=Y&transactionID="; 
	
	// at the end of Update URL append {policyId} - will be returned as GID from Start New Transaction API
	private static final String UPDATE_URL = "/Policy/"; 
	private static final String VALIDATE_TRANSACTION_URL = "/validateTransaction";
	private static final String COMPLETE_TRANSACTION_URL = "/completeTransaction";
	private static final String SUSPEND_TRANSACTION_URL = "/suspendTransaction";
	
	// header params
	private static final String TRANSACTION_ID = "transactionID";
	private static final String CLIENT_ID = "clientID";
	private static final String GID = "gid";
	private static final String TRANS_EFFECTIVE_DATE = "transEffectiveDate";
	
	// Process flow steps
	private static final String STATUS_STEP_1 = "startNewTransaction";
	private static final String STATUS_STEP_2 = "update";
	private static final String STATUS_STEP_3 = "validateTransaction";
	private static final String STATUS_STEP_4 = "completeTransaction";
	
	private static final String STATUS_SUCCESS = "Success";
	private static final String STATUS_ERROR = "Error";
	
	private static final String ENDORSEMENT_REASON = "Changing Underwriter";
	
	private Map<String, String> transactionStatusMap = null;
	
	private BulkUnderwriterServiceHelper serviceHelper = new BulkUnderwriterServiceHelper();
	private BulkRateServiceHelper rateServiceHelper = new BulkRateServiceHelper();
	
	DefaultHttpClient client = new DefaultHttpClient();

	public void processPolicyList(List<BulkUpdateUnderwriterEntity> entityList, User user, String functionName) {
		this.functionName = functionName;
		
		try {
			for (BulkUpdateUnderwriterEntity entity : entityList) {
				if (entity.getPmbu_entity_type().equalsIgnoreCase(BulkUpdateConstants.ENTITY_TYPE_POLICY)) {
					checkBookingStatusAndProcess(user, entity);
				}
			}
		} catch (Exception e) {
			serviceHelper.logMessage(LogEntry.SEVERITY_FATAL, "Error in BulkUpdateUnderwriterService Policy Helper : " + e.getMessage(), "");
		}

	}
	
	private void checkBookingStatusAndProcess(User user, BulkUpdateUnderwriterEntity entity) throws Exception {
		try {
			if (serviceHelper.getPolicyBookingStatus(user, entity.getPmbu_entity_type(), entity.getPmbu_entity_reference()).equalsIgnoreCase("N")) {
				if (rateServiceHelper.getEntityRevisionNumber(user, entity.getPmbu_entity_reference()) == 0) {
					// Retrieving Web Service Parameters
					Map<String, String> wsParams = getWSParameters(user);
					String baseUrl = (String) wsParams.get(BulkUpdateConstants.POLICY_UPDATE_API_URL);
					serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUpdateUnderwriterPolicyHelper-Policy Update API Base URL : " + baseUrl, "");
					
					String userName = (String)wsParams.get(BulkUpdateConstants.QUOTE_POLICY_API_USER_ID);
					String password = (String)wsParams.get(BulkUpdateConstants.QUOTE_POLICY_API_USER_PASSWORD);
					
					serviceHelper.logMessage(LogEntry.SEVERITY_INFO,
							"Info-BulkUpdateUnderwriterPolicyHelper-Policy Ready For Booking or Not yet Booked with Revision Zero", "");
					performRedoUpdateTransaction(entity, baseUrl, userName, password, user);
				} else {
					serviceHelper.logMessage(LogEntry.SEVERITY_INFO,
							"Info-BulkUpdateUnderwriterPolicyHelper-Policy Not Booked with Revision Number other than Zero",
							"");
					processPolicy(user, entity);
				}
			} else {
				serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUpdateUnderwriterPolicyHelper-Policy is Booked", "");
				processPolicy(user, entity);
			}
		} catch (Exception e) {
			serviceHelper.logMessage(LogEntry.SEVERITY_FATAL, "Error in BulkUpdateUnderwriterService Policy Helper checkBookingStatusAndProcess(): " + e.getMessage(), "");
		}
	}

	private void processPolicy(User user, BulkUpdateUnderwriterEntity entity) {
		
		initializeTransactionStatusMap();
		
		try {
			// Retrieving Web Service Parameters
			Map<String, String> wsParams = getWSParameters(user);
			String baseUrl = (String) wsParams.get(BulkUpdateConstants.POLICY_BASE_API_URL);
			serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUpdateUnderwriterPolicyHelper-Policy Base URL : " + baseUrl, "");
			
			String userName = (String)wsParams.get(BulkUpdateConstants.QUOTE_POLICY_API_USER_ID);
			String password = (String)wsParams.get(BulkUpdateConstants.QUOTE_POLICY_API_USER_PASSWORD);
			serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUpdateUnderwriterPolicyHelper-WS Param UserName:Pwd:" + userName + ":" + password, "");

			// Step-1: Start New Transaction - HttpGet
			performStartNewTransaction(entity, baseUrl, userName, password, user);
			
			// Step-2: Update Underwriter - HttpPut
			// pathParam : policyId - GID of Step-1 response should be appended to the Url
			// Header Params: transactionID and clientID
			if (this.transactionStatusMap.get(STATUS_STEP_1).equals(STATUS_SUCCESS)) {
				performUpdateTransaction(entity, baseUrl, userName, password, user);
			}
			
			// Step-3: Validate Transaction - HttpGet || Header Params: transactionID and clientID
			if (this.transactionStatusMap.get(STATUS_STEP_2).equals(STATUS_SUCCESS)) {
				performValidateTransaction(entity, baseUrl, userName, password, user);
			}
			// Step-4: Complete Transaction - HttpGet || Header Params: transactionID and clientID
			if (this.transactionStatusMap.get(STATUS_STEP_3).equals(STATUS_SUCCESS)) {
				performCompleteTransaction(entity, baseUrl, userName, password, user);
			}
			
			// Final Status check
			if (this.transactionStatusMap.get(STATUS_STEP_4).equals(STATUS_SUCCESS)) {
				serviceHelper.updateBulkUnderwriterRecordStatus(user, BulkUpdateConstants.STATUS_PROCESSED, entity.getPmbu_id(), "");
			} else {
				// Suspend Transaction Api is called if we get success response from Start New Transaction
				// since transactionID and clientID values are available only if the Start New Transaction is success
				if (this.transactionStatusMap.get(STATUS_STEP_1).equals(STATUS_SUCCESS)) {
					performSuspendTransaction(entity, baseUrl, userName, password, user);
				}
			}
				
		} catch (Exception e) {
			serviceHelper.logMessage(LogEntry.SEVERITY_FATAL, "Error in BulkUpdateUnderwriterService Policy Helper : " + e.getMessage(), "");
		}

	}

	private void performStartNewTransaction(BulkUpdateUnderwriterEntity entity, String baseUrl, String userName, String password, User user) {
		
		try {
			HttpGet getRequest = createHttpGetForStartNewTransaction(entity.getPmbu_entity_reference(), baseUrl, userName, password);
			HttpResponse response = this.client.execute(getRequest);
			String transactionId = "";
			String clientId = "";
			String gid = "";
			String transEffectiveDate = "";
			if (response.getStatusLine().getStatusCode() == 200) {
				PolicyBaseResponse transResponse = getPolicyTransactionResponse(response);
				if(transResponse instanceof PolicyErrorResponse) {
					// update the status as failed and stop the further flow
					serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUpdateUnderwriterPolicyHelper-Policy failed at Start New Transaction :"
							+ entity.getPmbu_entity_reference(), "");
					
					PolicyErrorResponse errorResponse = (PolicyErrorResponse) transResponse;
					serviceHelper.updateBulkUnderwriterRecordStatus(user, BulkUpdateConstants.STATUS_FAILED,
							entity.getPmbu_id(), serviceHelper.getJson(errorResponse));
					this.transactionStatusMap.put(STATUS_STEP_1, STATUS_ERROR);
					
					serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Error-BulkUpdateUnderwriterPolicyHelper-Policy Processing-Entity Ref:"
							+ entity.getPmbu_entity_reference(), "Entity Ref:" + entity.getPmbu_entity_reference());
					
				} else {
					// Parse the transResponse to retrieve the required details
					PolicyTransactionResponse newTransRes = (PolicyTransactionResponse) transResponse;
					serviceHelper.logMessage(LogEntry.SEVERITY_INFO,
							"Info-BulkUpdateUnderwriterPolicyHelper-New Transaction Success Response converted into JSON String :"
									+ serviceHelper.getJson(newTransRes), "");
					
					transactionId = newTransRes.getTransactionID();
					clientId = newTransRes.getClientID();
					gid = newTransRes.getObjectFieldValuesList().get(0).getGID();
					transEffectiveDate = newTransRes.getObjectFieldValuesList().get(0).getEffectiveDate();
					
					this.transactionStatusMap.put(TRANSACTION_ID, transactionId);
					this.transactionStatusMap.put(CLIENT_ID, clientId);
					this.transactionStatusMap.put(GID, gid);
					this.transactionStatusMap.put(TRANS_EFFECTIVE_DATE, transEffectiveDate);
					
					serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUpdateUnderwriterPolicyHelper-transactionId :"
							+ transactionId + " : clientId :" + clientId + " : GID :" + gid + " : EffectiveDate :" + transEffectiveDate, "");
					
					this.transactionStatusMap.put(STATUS_STEP_1, STATUS_SUCCESS);
					serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUpdateUnderwriterPolicyHelper-Policy Processing Step-1 Success-Entity Ref:"
							+ entity.getPmbu_entity_reference(), "Entity Ref:" + entity.getPmbu_entity_reference());
				}
			} else {
				updateProcessingStatusForErrorStatusCodes(response, user, entity.getPmbu_id(), entity.getPmbu_entity_reference());
			}
		} catch (Exception e) {
			serviceHelper.logMessage(LogEntry.SEVERITY_FATAL, "Error in BulkUpdateUnderwriterServicePolicyHelper : Start New Transaction : " + e.getMessage(), "");
		} 
	}
	
	private void performUpdateTransaction(BulkUpdateUnderwriterEntity entity, String baseUrl, String userName, String password, User user) {
		try {
			HttpPut putRequest = createHttpPutForUpdateTransaction(entity, baseUrl, userName, password);
			HttpResponse response = this.client.execute(putRequest);
			if (response.getStatusLine().getStatusCode() == 200) {
				PolicyBaseResponse transResponse = getPolicyTransactionResponse(response);
				if(transResponse instanceof PolicyErrorResponse) {
					// update the status as failed and stop the further flow
					
					serviceHelper.logMessage(LogEntry.SEVERITY_INFO,
							"Info-BulkUpdateUnderwriterPolicyHelper-Policy failed at Update Transaction :"
									+ entity.getPmbu_entity_reference(), "");
					
					PolicyErrorResponse errorResponse = (PolicyErrorResponse) transResponse;
					serviceHelper.updateBulkUnderwriterRecordStatus(user, BulkUpdateConstants.STATUS_FAILED,
							entity.getPmbu_id(), serviceHelper.getJson(errorResponse));
					this.transactionStatusMap.put(STATUS_STEP_2, STATUS_ERROR);
					
					serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Error-BulkUpdateUnderwriterPolicyHelper-Policy Processing-Entity Ref:"
							+ entity.getPmbu_entity_reference(), "Entity Ref:" + entity.getPmbu_entity_reference());
					
				} else {
					
					this.transactionStatusMap.put(STATUS_STEP_2, STATUS_SUCCESS);
					serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUpdateUnderwriterPolicyHelper-Policy Processing Step-2 Success-Entity Ref:"
							+ entity.getPmbu_entity_reference(), "Entity Ref:" + entity.getPmbu_entity_reference());
				}
			} else {
				updateProcessingStatusForErrorStatusCodes(response, user, entity.getPmbu_id(), entity.getPmbu_entity_reference());
			}
			
		} catch (Exception e) {
			serviceHelper.logMessage(LogEntry.SEVERITY_FATAL, "Error in BulkUpdateUnderwriterServicePolicyHelper : Update Transaction : " + e.getMessage(), "");
		}
	}
	
	private void performValidateTransaction(BulkUpdateUnderwriterEntity entity, String baseUrl, String userName, String password, User user) {
		try {
			HttpGet getRequest = createHttpGetForValidateTransaction(entity.getPmbu_entity_reference(), baseUrl, userName, password);
			HttpResponse response = this.client.execute(getRequest);
			if (response.getStatusLine().getStatusCode() == 200) {
				PolicyBaseResponse transResponse = getPolicyTransactionResponse(response);
				if(transResponse instanceof PolicyErrorResponse) {
					// update the status as failed and stop the further flow
					serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUpdateUnderwriterPolicyHelper-Policy failed at Validate Transaction :"
							+ entity.getPmbu_entity_reference(), "");
					
					PolicyErrorResponse errorResponse = (PolicyErrorResponse) transResponse;
					serviceHelper.updateBulkUnderwriterRecordStatus(user, BulkUpdateConstants.STATUS_FAILED,
							entity.getPmbu_id(), serviceHelper.getJson(errorResponse));
					this.transactionStatusMap.put(STATUS_STEP_3, STATUS_ERROR);
					
					serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Error-BulkUpdateUnderwriterPolicyHelper-Policy Processing-Entity Ref:"
							+ entity.getPmbu_entity_reference(), "Entity Ref:" + entity.getPmbu_entity_reference());
					
				} else {
					
					this.transactionStatusMap.put(STATUS_STEP_3, STATUS_SUCCESS);
					serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUpdateUnderwriterPolicyHelper-Policy Processing Step-3 Success-Entity Ref:"
							+ entity.getPmbu_entity_reference(), "Entity Ref:" + entity.getPmbu_entity_reference());
				}
			} else {
				updateProcessingStatusForErrorStatusCodes(response, user, entity.getPmbu_id(), entity.getPmbu_entity_reference());
			}
			
		} catch (Exception e) {
			serviceHelper.logMessage(LogEntry.SEVERITY_FATAL, "Error in BulkUpdateUnderwriterServicePolicyHelper : Validate Transaction : " + e.getMessage(), "");
		}
	}
	
	private void performCompleteTransaction(BulkUpdateUnderwriterEntity entity, String baseUrl, String userName, String password, User user) {
		try {
			HttpGet getRequest = createHttpGetForCompleteTransaction(entity.getPmbu_entity_reference(), baseUrl, userName, password);
			HttpResponse response = this.client.execute(getRequest);
			if (response.getStatusLine().getStatusCode() == 200) {
				PolicyBaseResponse transResponse = getPolicyTransactionResponse(response);
				if(transResponse instanceof PolicyErrorResponse) {
					// update the status as failed and stop the further flow
					serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUpdateUnderwriterPolicyHelper-Policy failed at Complete Transaction :"
							+ entity.getPmbu_entity_reference(), ""); 
					
					PolicyErrorResponse errorResponse = (PolicyErrorResponse) transResponse;
					serviceHelper.updateBulkUnderwriterRecordStatus(user, BulkUpdateConstants.STATUS_FAILED,
							entity.getPmbu_id(), serviceHelper.getJson(errorResponse));
					this.transactionStatusMap.put(STATUS_STEP_4, STATUS_ERROR);
					
					serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Error-BulkUpdateUnderwriterPolicyHelper-Policy Processing-Entity Ref:"
							+ entity.getPmbu_entity_reference(), "Entity Ref:" + entity.getPmbu_entity_reference());
					
				} else {
				
					this.transactionStatusMap.put(STATUS_STEP_4, STATUS_SUCCESS);
					serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUpdateUnderwriterPolicyHelper-Policy Processing Step-4 Success-Entity Ref:"
							+ entity.getPmbu_entity_reference(), "Entity Ref:" + entity.getPmbu_entity_reference());
				}
			} else {
				updateProcessingStatusForErrorStatusCodes(response, user, entity.getPmbu_id(), entity.getPmbu_entity_reference());
			}
			
		} catch (Exception e) {
			serviceHelper.logMessage(LogEntry.SEVERITY_FATAL, "Error in BulkUpdateUnderwriterServicePolicyHelper : Complete Transaction : " + e.getMessage(), "");
		}
	}
	
	private void performSuspendTransaction(BulkUpdateUnderwriterEntity entity, String baseUrl, String userName, String password, User user) {
		try {
			HttpGet getRequest = createHttpGetForSuspendTransaction(entity.getPmbu_entity_reference(), baseUrl, userName, password);
			HttpResponse response = this.client.execute(getRequest);
			if (response.getStatusLine().getStatusCode() == 200) {
				PolicyBaseResponse transResponse = getPolicyTransactionResponse(response);
				if(transResponse instanceof PolicyErrorResponse) {
					// update the status as failed and stop the further flow
					serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUpdateUnderwriterPolicyHelper-Policy failed at Suspend Transaction :"
							+ entity.getPmbu_entity_reference(), ""); 
				} else {
					serviceHelper.logMessage(LogEntry.SEVERITY_INFO,
							"Info-BulkUpdateUnderwriterPolicyHelper-Policy Processing Suspend Transaction Success-Entity Ref:"
									+ entity.getPmbu_entity_reference(), "Entity Ref:" + entity.getPmbu_entity_reference());
				}
			} else {
				// if the Suspend transaction is failed also, no further action is taken
			}
			
		} catch (Exception e) {
			serviceHelper.logMessage(LogEntry.SEVERITY_FATAL, "Error in BulkUpdateUnderwriterServicePolicyHelper : Suspend Transaction : " + e.getMessage(), "");
		}
	}
	
	private void performRedoUpdateTransaction(BulkUpdateUnderwriterEntity entity, String baseUrl, String userName, String password, User user) {
		try {
			HttpPut putRequest = createHttpPutForRedoUpdateTransaction(entity, baseUrl, userName, password, user);
			HttpResponse response = this.client.execute(putRequest);
			if (response.getStatusLine().getStatusCode() == 200) {
				serviceHelper.updateBulkUnderwriterRecordStatus(user, BulkUpdateConstants.STATUS_PROCESSED, entity.getPmbu_id(), "");
				
				serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUnderwriterServicePolicyHelper-Policy Update Transaction Sucess-Entity Ref:"
						+ entity.getPmbu_entity_reference(), "");
			} else {
				updateProcessingStatusForErrorStatusCodes(response, user, entity.getPmbu_id(), entity.getPmbu_entity_reference());
			}
			
		} catch (Exception e) {
			serviceHelper.logMessage(LogEntry.SEVERITY_FATAL, "Error in BulkUpdateUnderwriterServicePolicyHelper : Update Transaction : " + e.getMessage(), "");
		}
	}

	@SuppressWarnings("unchecked")
	private Map<String, String> getWSParameters(User user) throws Exception {
		
		Map<String, String> webserviceParams = EventProcessor
				.getWebServiceParameters(BulkUpdateConstants.BULK_UNDERWRITER_WEBSERVICE_NAME, user);
		if (webserviceParams == null) {
			serviceHelper.logMessage(LogEntry.SEVERITY_FATAL, "Info-BulkUpdateUnderwriterPolicyHelper-WS Params Map is null", "");
			return null;
		}
		
		return webserviceParams;
	}

	private HttpGet createHttpGetForStartNewTransaction(String entityRef, String baseUrl, String userName, String password) {
		HttpGet getMethod = null;
		String serviceUrl = null;
		
		serviceUrl = baseUrl + START_NEW_TRANSACTION_URL + entityRef;
		getMethod = new HttpGet(serviceUrl);
		
		String authString = java.util.Base64.getEncoder().encodeToString((userName + ":" + password).getBytes());
		getMethod.setHeader("Authorization", "Basic " + authString);
		serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUpdateUnderwriterPolicyHelper-New Transaction URL : " + serviceUrl, "");
		
		return getMethod;
	}
	
	private HttpPut createHttpPutForUpdateTransaction(BulkUpdateUnderwriterEntity entity, String baseUrl,
			String userName, String password) throws Exception {
		HttpPut putMethod = null;
		String serviceUrl = null;

		serviceUrl = baseUrl + UPDATE_URL + this.transactionStatusMap.get(GID);
		putMethod = new HttpPut(serviceUrl);
		
		setHeaderParamsInHttpPut(putMethod, userName, password);

		String jsonString = serviceHelper.getJson(buildPolicyUpdateRequest(entity));
		StringEntity input = new StringEntity(jsonString);
		input.setContentType("application/json");

		putMethod.setEntity(input);

		serviceHelper.logMessage(LogEntry.SEVERITY_INFO,
				"Info-BulkUpdateUnderwriterPolicyHelper-Update Transaction URL : " + serviceUrl, "");

		return putMethod;
	}
	
	private HttpGet createHttpGetForValidateTransaction(String entityRef, String baseUrl, String userName, String password) {
		HttpGet getMethod = null;
		String serviceUrl = null;
		
		serviceUrl = baseUrl + VALIDATE_TRANSACTION_URL;
		getMethod = new HttpGet(serviceUrl);
		setHeaderParamsInHttpGet(getMethod, userName, password);
		
		serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUpdateUnderwriterPolicyHelper-Validate Transaction URL : " + serviceUrl, "");
		
		return getMethod;
	}
	
	private HttpGet createHttpGetForCompleteTransaction(String entityRef, String baseUrl, String userName, String password) {
		HttpGet getMethod = null;
		String serviceUrl = null;
		
		serviceUrl = baseUrl + COMPLETE_TRANSACTION_URL;
		getMethod = new HttpGet(serviceUrl);
		setHeaderParamsInHttpGet(getMethod, userName, password);
		
		serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUpdateUnderwriterPolicyHelper-Complete Transaction URL : " + serviceUrl, "");
		
		return getMethod;
	}
	
	private HttpGet createHttpGetForSuspendTransaction(String entityRef, String baseUrl, String userName, String password) {
		HttpGet getMethod = null;
		String serviceUrl = null;
		
		serviceUrl = baseUrl + SUSPEND_TRANSACTION_URL;
		getMethod = new HttpGet(serviceUrl);
		setHeaderParamsInHttpGet(getMethod, userName, password);
		
		serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUpdateUnderwriterPolicyHelper-Suspend Transaction URL : " + serviceUrl, "");
		
		return getMethod;
	}
	
	private HttpPut createHttpPutForRedoUpdateTransaction(BulkUpdateUnderwriterEntity entity, String baseUrl,
			String userName, String password, User user) throws Exception {
		HttpPut putMethod = null;
		String serviceUrl = null;
		
		// baseUrl/{policyId} 
		serviceUrl = baseUrl + "/" + entity.getPmbu_entity_reference();
		serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Info-BulkUnderwriterServicePolicyHelper-Policy Redo API URL:" + serviceUrl, "");
		putMethod = new HttpPut(serviceUrl);
		
		String authString = java.util.Base64.getEncoder().encodeToString((userName + ":" + password).getBytes());
		putMethod.setHeader("Authorization", "Basic " + authString);
		
		String jsonString = serviceHelper.getJson(buildPolicyRedoRequestObject(user, entity));
		StringEntity input = new StringEntity(jsonString);
		input.setContentType("application/json");
		
		putMethod.setEntity(input);
		
		return putMethod;
	}
	
	private void setHeaderParamsInHttpPut(HttpPut putMethod, String userName, String password) {
		putMethod.setHeader(TRANSACTION_ID, this.transactionStatusMap.get(TRANSACTION_ID));
		putMethod.setHeader(CLIENT_ID, this.transactionStatusMap.get(CLIENT_ID));

		String authString = java.util.Base64.getEncoder().encodeToString((userName + ":" + password).getBytes());
		putMethod.setHeader("Authorization", "Basic " + authString);
	}
	
	private void setHeaderParamsInHttpGet(HttpGet getMethod, String userName, String password) {
		getMethod.setHeader(TRANSACTION_ID, this.transactionStatusMap.get(TRANSACTION_ID));
		getMethod.setHeader(CLIENT_ID, this.transactionStatusMap.get(CLIENT_ID));
		
		String authString = java.util.Base64.getEncoder().encodeToString((userName + ":" + password).getBytes());
		getMethod.setHeader("Authorization", "Basic " + authString);
	}
	
	private void updateProcessingStatusForErrorStatusCodes(HttpResponse response, User user, Long pmbuId, String entityRef) throws Exception {
		String errorResponse = EntityUtils.toString(response.getEntity());
		serviceHelper.updateBulkUnderwriterRecordStatus(user, BulkUpdateConstants.STATUS_FAILED, pmbuId, errorResponse);
		serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Error-BulkUpdateUnderwriterPolicyHelper-Policy Processing-Entity Ref:"
				+ entityRef, "");
	} 
	
	private PolicyBaseResponse getPolicyTransactionResponse(HttpResponse response) throws Exception {

		PolicyTransactionResponse newTransResponse = new PolicyTransactionResponse();
		PolicyErrorResponse errorResponse = new PolicyErrorResponse();
		String successRes = EntityUtils.toString(response.getEntity());
		serviceHelper.logMessage(LogEntry.SEVERITY_INFO,
				"Content of Success Response From Policy Start New Transaction Api :" + successRes, "");

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(org.codehaus.jackson.map.DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		if (successRes.contains("transactionID") && successRes.contains("clientID")) {
			newTransResponse = mapper.readValue(successRes, PolicyTransactionResponse.class);
			return newTransResponse;
		} else {
			errorResponse = mapper.readValue(successRes, PolicyErrorResponse.class);
			return errorResponse;
		}
	}
	
	private PolicyUpdateRequest buildPolicyUpdateRequest(BulkUpdateUnderwriterEntity entity) {
		PolicyUpdateRequest puRequest = new PolicyUpdateRequest();
		Policy policy = new Policy();

		policy.setTransEffectiveDate(transactionStatusMap.get(TRANS_EFFECTIVE_DATE));
		policy.setEndorsementReason(ENDORSEMENT_REASON);
		policy.setUnderwriterCode(entity.getPmbu_to_underwriter_code());
		policy.setUnderwriterName(entity.getPmbu_to_underwriter());
		puRequest.setPolicy(policy);
		
		return puRequest;
	}
	
	private PolicyRedoUpdateRequest buildPolicyRedoRequestObject(User user, BulkUpdateUnderwriterEntity entity) {
		PolicyRedoUpdateRequest req = new PolicyRedoUpdateRequest();
		try {
			req.setRate("N");
	
			PolicyRedoQuotePolicy qp = new PolicyRedoQuotePolicy();
			qp.setUnderwriterCode(entity.getPmbu_to_underwriter_code());
			qp.setUnderwriterName(entity.getPmbu_to_underwriter());
			
			req.setQuotePolicy(qp);
	
			serviceHelper.logMessage(LogEntry.SEVERITY_INFO, "Policy Redo Payload For Entity : " + entity.getPmbu_entity_reference() + ": " + req.toString(), "");
		} catch (Exception e) {
			serviceHelper.logMessage(LogEntry.SEVERITY_FATAL, "Exception in BulkUnderwriterServicePolicyHelper while building the Policy Redo Payload", "");
		}
		
		return req;
	}
	
	private void initializeTransactionStatusMap() {
		if (transactionStatusMap == null) {
			transactionStatusMap = new HashMap<String, String>();
		}
		transactionStatusMap.put(TRANSACTION_ID, "");
		transactionStatusMap.put(CLIENT_ID, "");
		transactionStatusMap.put(GID, "");
		transactionStatusMap.put(TRANS_EFFECTIVE_DATE, "");
		transactionStatusMap.put(STATUS_STEP_1, STATUS_ERROR);
		transactionStatusMap.put(STATUS_STEP_2, STATUS_ERROR);
		transactionStatusMap.put(STATUS_STEP_3, STATUS_ERROR);
		transactionStatusMap.put(STATUS_STEP_4, STATUS_ERROR);
	}
}
