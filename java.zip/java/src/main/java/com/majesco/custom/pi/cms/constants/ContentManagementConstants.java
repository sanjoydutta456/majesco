package com.majesco.custom.pi.cms.constants;

public class ContentManagementConstants {
	
	public static final String FUNCTION_NAME = "ContentManagement";
	
	//Content Management Web service Name
	public static final String CONTENT_MANAGEMENT_WEB_SERVICE_NAME = "MIC - INTERNAL - WS - CONTENT MANAGEMENT PROCESSING";
	
	//Web service parameters
	public static final String WS_PARAM_SFTP_HOST = "sftpHost";
	public static final String WS_PARAM_SFTP_USER_ID = "sftpUserId";
	public static final String WS_PARAM_SFTP_PASSWORD = "sftpPassword";
	public static final String WS_PARAM_SFTP_PORT = "sftpPort";
	public static final String WS_PARAM_SFTP_PATH = "sftpPath";
	public static final String WS_PARAM_DOC_REPO_USER_ID = "docRepoUserId";
	public static final String WS_PARAM_DOC_REPO_PASSWORD = "docRepoPassword";
	public static final String WS_PARAM_DELETE_TEMP_FOLDER = "deleteCurrentRunFolder";
	
	public static final String PROTOCOL_HTTP = "http://";
	public static final String PROTOCOL_HTTPS = "https://";
	public static final String HTTP_DEFAULT_PORT = "80";
	public static final String HTTPS_DEFAULT_PORT = "443";
	
	//PI_MIS_DOC_GEN_PRINT table column names
	public static final String COLUMN_PMDP_ID = "PMDP_ID";
	public static final String COLUMN_PMDP_ENTITY_TYPE = "PMDP_ENTITY_TYPE";
	public static final String COLUMN_PMDP_ENTITY_REFERENCE = "PMDP_ENTITY_REFERENCE";
	public static final String COLUMN_PMDP_PROCESSING_STATUS = "PMDP_PROCESSING_STATUS";
	public static final String COLUMN_PMDP_PROCESSING_DATE = "PMDP_PROCESSING_DATE";
	public static final String COLUMN_PMDP_POLICY_NUMBER = "PMDP_POLICY_NUMBER";
	public static final String COLUMN_PMDP_POLICY_SUFFIX = "PMDP_POLICY_SUFFIX";
	public static final String COLUMN_PMDP_FULL_POLICY_ID = "PMDP_FULL_POLICY_ID";
	public static final String COLUMN_PMDP_POLICY_STATUS = "PMDP_POLICY_STATUS";
	public static final String COLUMN_PMDP_EFFECTIVE_DATE = "PMDP_EFFECTIVE_DATE";
	public static final String COLUMN_PMDP_EXPIRATION_DATE = "PMDP_EXPIRATION_DATE";
	public static final String COLUMN_PMDP_INCEPTION_DATE = "PMDP_INCEPTION_DATE";
	public static final String COLUMN_PMDP_PRIMARY_INSURED_NAME = "PMDP_PRIMARY_INSURED_NAME";
	public static final String COLUMN_PMDP_BILLING_ACCOUNT_ID = "PMDP_BILLING_ACCOUNT_ID";
	public static final String COLUMN_PMDP_PRODUCER_ID = "PMDP_PRODUCER_ID";
	public static final String COLUMN_PMDP_DOC_PKG_ID = "PMDP_DOC_PKG_ID";
	public static final String COLUMN_PMDP_DOC_NAME = "PMDP_DOC_NAME";
	public static final String COLUMN_PMDP_DOC_DESCRIPTION = "PMDP_DOC_DESCRIPTION";
	public static final String COLUMN_PMDP_DOC_DATE = "PMDP_DOC_DATE";
	public static final String COLUMN_PMDP_FILE_NAME = "PMDP_FILE_NAME";
	public static final String COLUMN_PMDP_PRODUCT_CODE = "PMDP_PRODUCT_CODE";
	public static final String COLUMN_PMDP_ATTACHMENT_TYPE = "PMDP_ATTACHMENT_TYPE";
	public static final String COLUMN_PMDP_MODE = "PMDP_MODE";
	public static final String COLUMN_PMDP_SIGNED_FLAG = "PMDP_SIGNED_FLAG";
	public static final String COLUMN_PMDP_RECIPIENT_TYPE = "PMDP_RECIPIENT_TYPE";
	public static final String COLUMN_PMDP_RECIPIENT_EMAIL = "PMDP_RECIPIENT_EMAIL";
	public static final String COLUMN_PMDP_RECIPIENT_ADD_LINE1 = "PMDP_RECIPIENT_ADD_LINE1";
	public static final String COLUMN_PMDP_RECIPIENT_ADD_LINE2 = "PMDP_RECIPIENT_ADD_LINE2";
	public static final String COLUMN_PMDP_RECIPIENT_STATE_CODE = "PMDP_RECIPIENT_STATE_CODE";
	public static final String COLUMN_PMDP_RECIPIENT_CITY = "PMDP_RECIPIENT_CITY";
	public static final String COLUMN_PMDP_RECIPIENT_ZIP_CODE = "PMDP_RECIPIENT_ZIP_CODE";
	public static final String COLUMN_PMDP_RECIPIENT_COUNTRY = "PMDP_RECIPIENT_COUNTRY";
	public static final String COLUMN_PMDP_DISTRIBUTION_METHOD = "PMDP_DISTRIBUTION_METHOD";
	public static final String COLUMN_PMDP_DATE_CREATED = "PMDP_DATE_CREATED";
	public static final String COLUMN_PMDP_DATE_MODIFIED = "PMDP_DATE_MODIFIED";
	public static final String COLUMN_PMDP_USER_CREATED = "PMDP_USER_CREATED";
	public static final String COLUMN_PMDP_USER_MODIFIED = "PMDP_USER_MODIFIED";
	
	//Processing Statuses
	public static final String STATUS_NOT_PROCESSED = "NOT_PROCESSED";
	public static final String STATUS_PROCESSED = "PROCESSED";
	public static final String STATUS_FAILED = "FAILED";

}
