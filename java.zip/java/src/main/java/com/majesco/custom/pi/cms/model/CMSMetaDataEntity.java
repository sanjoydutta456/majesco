package com.majesco.custom.pi.cms.model;

import java.util.Date;

import org.codehaus.jackson.annotate.JsonPropertyOrder;


@JsonPropertyOrder({"policyNumber","policySuffix","fullPolicyId","policyStatus","effectiveDate","expirationDate","inceptionDate",
	"primaryInsuredName","billingAccountId","producerId","docPkgId","docName","docDescription","docDate","productCode","attachmentType","mode",
	"signedFlag","recipientEmail","recipientAddLine1","recipientAddLine2","recipientState","recipientCity","recipientCountry","recipientZipCode",
	"distributionMethod"})
public class CMSMetaDataEntity {
	
	//PI_MIS_DOC_GEN_PRINT table columns should be mapped to required properties in this entity
	//Note: PMDP_FILE_NAME should be mapped to docName property
	private String policyNumber;
	private String policySuffix;
	private String fullPolicyId;
	private String policyStatus;
	private Date effectiveDate;
	private Date expirationDate;
	private Date inceptionDate;
	private String primaryInsuredName;
	private String billingAccountId;
	private String producerId;
	private String docPkgId;
	private String docName;
	private String docDescription;
	private Date docDate;
	private String productCode;
	private String attachmentType;
	private String mode;
	private String signedFlag;
	private String recipientEmail;
	private String recipientAddLine1;
	private String recipientAddLine2;
	private String recipientState;
	private String recipientCity;
	private String recipientCountry;
	private String recipientZipCode;
	private String distributionMethod;
	
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getPolicySuffix() {
		return policySuffix;
	}
	public void setPolicySuffix(String policySuffix) {
		this.policySuffix = policySuffix;
	}
	public String getFullPolicyId() {
		return fullPolicyId;
	}
	public void setFullPolicyId(String fullPolicyId) {
		this.fullPolicyId = fullPolicyId;
	}
	public String getPolicyStatus() {
		return policyStatus;
	}
	public void setPolicyStatus(String policyStatus) {
		this.policyStatus = policyStatus;
	}
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public Date getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}
	public Date getInceptionDate() {
		return inceptionDate;
	}
	public void setInceptionDate(Date inceptionDate) {
		this.inceptionDate = inceptionDate;
	}
	public String getPrimaryInsuredName() {
		return primaryInsuredName;
	}
	public void setPrimaryInsuredName(String primaryInsuredName) {
		this.primaryInsuredName = primaryInsuredName;
	}
	public String getBillingAccountId() {
		return billingAccountId;
	}
	public void setBillingAccountId(String billingAccountId) {
		this.billingAccountId = billingAccountId;
	}
	public String getProducerId() {
		return producerId;
	}
	public void setProducerId(String producerId) {
		this.producerId = producerId;
	}
	public String getDocPkgId() {
		return docPkgId;
	}
	public void setDocPkgId(String docPkgId) {
		this.docPkgId = docPkgId;
	}
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	public String getDocDescription() {
		return docDescription;
	}
	public void setDocDescription(String docDescription) {
		this.docDescription = docDescription;
	}
	public Date getDocDate() {
		return docDate;
	}
	public void setDocDate(Date docDate) {
		this.docDate = docDate;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getAttachmentType() {
		return attachmentType;
	}
	public void setAttachmentType(String attachmentType) {
		this.attachmentType = attachmentType;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public String getSignedFlag() {
		return signedFlag;
	}
	public void setSignedFlag(String signedFlag) {
		this.signedFlag = signedFlag;
	}
	public String getRecipientEmail() {
		return recipientEmail;
	}
	public void setRecipientEmail(String recipientEmail) {
		this.recipientEmail = recipientEmail;
	}
	public String getRecipientAddLine1() {
		return recipientAddLine1;
	}
	public void setRecipientAddLine1(String recipientAddLine1) {
		this.recipientAddLine1 = recipientAddLine1;
	}
	public String getRecipientAddLine2() {
		return recipientAddLine2;
	}
	public void setRecipientAddLine2(String recipientAddLine2) {
		this.recipientAddLine2 = recipientAddLine2;
	}
	public String getRecipientState() {
		return recipientState;
	}
	public void setRecipientState(String recipientState) {
		this.recipientState = recipientState;
	}
	public String getRecipientCity() {
		return recipientCity;
	}
	public void setRecipientCity(String recipientCity) {
		this.recipientCity = recipientCity;
	}
	public String getRecipientCountry() {
		return recipientCountry;
	}
	public void setRecipientCountry(String recipientCountry) {
		this.recipientCountry = recipientCountry;
	}
	public String getRecipientZipCode() {
		return recipientZipCode;
	}
	public void setRecipientZipCode(String recipientZipCode) {
		this.recipientZipCode = recipientZipCode;
	}
	public String getDistributionMethod() {
		return distributionMethod;
	}
	public void setDistributionMethod(String distributionMethod) {
		this.distributionMethod = distributionMethod;
	}
}
