package com.majesco.custom.pi.cms.model;

import java.util.List;


public class CMSMetaDataRoot {

	private List<CMSMetaDataEntity> policyDocMetaDetails;

	public List<CMSMetaDataEntity> getPolicyDocMetaDetails() {
		return policyDocMetaDetails;
	}

	public void setPolicyDocMetaDetails(List<CMSMetaDataEntity> policyDocMetaDetails) {
		this.policyDocMetaDetails = policyDocMetaDetails;
	}
	
	
}
