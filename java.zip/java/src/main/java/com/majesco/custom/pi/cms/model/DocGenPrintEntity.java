package com.majesco.custom.pi.cms.model;

import java.util.Date;

public class DocGenPrintEntity {

	private Long pmdp_id;
	private String pmdp_entity_type;
	private String pmdp_entity_reference;
	private String pmdp_processing_status;
	private Date pmdp_processing_date;
	private String pmdp_policy_number;
	private String pmdp_policy_suffix;
	private String pmdp_full_policy_id;
	private String pmdp_policy_status;
	private Date pmdp_effective_date;
	private Date pmdp_expiration_date;
	private Date pmdp_inception_date;
	private String pmdp_primary_insured_name;
	private String pmdp_billing_account_id;
	private String pmdp_producer_id;
	private String pmdp_doc_pkg_id;
	private String pmdp_doc_name;
	private String pmdp_doc_description;
	private Date pmdp_doc_date;
	private String pmdp_file_name;
	private String pmdp_product_code;
	private String pmdp_attachment_type;
	private String pmdp_mode;
	private String pmdp_signed_flag;
	private String pmdp_recipient_type;
	private String pmdp_recipient_email;
	private String pmdp_recipient_add_line1;
	private String pmdp_recipient_add_line2;
	private String pmdp_recipient_state_code;
	private String pmdp_recipient_city;
	private String pmdp_recipient_zip_code;
	private String pmdp_recipient_country;
	private String pmdp_distribution_method;
	private Date pmdp_date_created;
	private Date pmdp_date_modified;
	private String pmdp_user_created;
	private String pmdp_user_modified;
	public Long getPmdp_id() {
		return pmdp_id;
	}
	public void setPmdp_id(Long pmdp_id) {
		this.pmdp_id = pmdp_id;
	}
	public String getPmdp_entity_type() {
		return pmdp_entity_type;
	}
	public void setPmdp_entity_type(String pmdp_entity_type) {
		this.pmdp_entity_type = pmdp_entity_type;
	}
	public String getPmdp_entity_reference() {
		return pmdp_entity_reference;
	}
	public void setPmdp_entity_reference(String pmdp_entity_reference) {
		this.pmdp_entity_reference = pmdp_entity_reference;
	}
	public String getPmdp_processing_status() {
		return pmdp_processing_status;
	}
	public void setPmdp_processing_status(String pmdp_processing_status) {
		this.pmdp_processing_status = pmdp_processing_status;
	}
	public Date getPmdp_processing_date() {
		return pmdp_processing_date;
	}
	public void setPmdp_processing_date(Date pmdp_processing_date) {
		this.pmdp_processing_date = pmdp_processing_date;
	}
	public String getPmdp_policy_number() {
		return pmdp_policy_number;
	}
	public void setPmdp_policy_number(String pmdp_policy_number) {
		this.pmdp_policy_number = pmdp_policy_number;
	}
	public String getPmdp_policy_suffix() {
		return pmdp_policy_suffix;
	}
	public void setPmdp_policy_suffix(String pmdp_policy_suffix) {
		this.pmdp_policy_suffix = pmdp_policy_suffix;
	}
	public String getPmdp_full_policy_id() {
		return pmdp_full_policy_id;
	}
	public void setPmdp_full_policy_id(String pmdp_full_policy_id) {
		this.pmdp_full_policy_id = pmdp_full_policy_id;
	}
	public String getPmdp_policy_status() {
		return pmdp_policy_status;
	}
	public void setPmdp_policy_status(String pmdp_policy_status) {
		this.pmdp_policy_status = pmdp_policy_status;
	}
	public Date getPmdp_effective_date() {
		return pmdp_effective_date;
	}
	public void setPmdp_effective_date(Date pmdp_effective_date) {
		this.pmdp_effective_date = pmdp_effective_date;
	}
	public Date getPmdp_expiration_date() {
		return pmdp_expiration_date;
	}
	public void setPmdp_expiration_date(Date pmdp_expiration_date) {
		this.pmdp_expiration_date = pmdp_expiration_date;
	}
	public Date getPmdp_inception_date() {
		return pmdp_inception_date;
	}
	public void setPmdp_inception_date(Date pmdp_inception_date) {
		this.pmdp_inception_date = pmdp_inception_date;
	}
	public String getPmdp_primary_insured_name() {
		return pmdp_primary_insured_name;
	}
	public void setPmdp_primary_insured_name(String pmdp_primary_insured_name) {
		this.pmdp_primary_insured_name = pmdp_primary_insured_name;
	}
	public String getPmdp_billing_account_id() {
		return pmdp_billing_account_id;
	}
	public void setPmdp_billing_account_id(String pmdp_billing_account_id) {
		this.pmdp_billing_account_id = pmdp_billing_account_id;
	}
	public String getPmdp_producer_id() {
		return pmdp_producer_id;
	}
	public void setPmdp_producer_id(String pmdp_producer_id) {
		this.pmdp_producer_id = pmdp_producer_id;
	}
	public String getPmdp_doc_pkg_id() {
		return pmdp_doc_pkg_id;
	}
	public void setPmdp_doc_pkg_id(String pmdp_doc_pkg_id) {
		this.pmdp_doc_pkg_id = pmdp_doc_pkg_id;
	}
	public String getPmdp_doc_name() {
		return pmdp_doc_name;
	}
	public void setPmdp_doc_name(String pmdp_doc_name) {
		this.pmdp_doc_name = pmdp_doc_name;
	}
	public String getPmdp_doc_description() {
		return pmdp_doc_description;
	}
	public void setPmdp_doc_description(String pmdp_doc_description) {
		this.pmdp_doc_description = pmdp_doc_description;
	}
	public Date getPmdp_doc_date() {
		return pmdp_doc_date;
	}
	public void setPmdp_doc_date(Date pmdp_doc_date) {
		this.pmdp_doc_date = pmdp_doc_date;
	}
	public String getPmdp_file_name() {
		return pmdp_file_name;
	}
	public void setPmdp_file_name(String pmdp_file_name) {
		this.pmdp_file_name = pmdp_file_name;
	}
	public String getPmdp_product_code() {
		return pmdp_product_code;
	}
	public void setPmdp_product_code(String pmdp_product_code) {
		this.pmdp_product_code = pmdp_product_code;
	}
	public String getPmdp_attachment_type() {
		return pmdp_attachment_type;
	}
	public void setPmdp_attachment_type(String pmdp_attachment_type) {
		this.pmdp_attachment_type = pmdp_attachment_type;
	}
	public String getPmdp_mode() {
		return pmdp_mode;
	}
	public void setPmdp_mode(String pmdp_mode) {
		this.pmdp_mode = pmdp_mode;
	}
	public String getPmdp_signed_flag() {
		return pmdp_signed_flag;
	}
	public void setPmdp_signed_flag(String pmdp_signed_flag) {
		this.pmdp_signed_flag = pmdp_signed_flag;
	}
	public String getPmdp_recipient_type() {
		return pmdp_recipient_type;
	}
	public void setPmdp_recipient_type(String pmdp_recipient_type) {
		this.pmdp_recipient_type = pmdp_recipient_type;
	}
	public String getPmdp_recipient_email() {
		return pmdp_recipient_email;
	}
	public void setPmdp_recipient_email(String pmdp_recipient_email) {
		this.pmdp_recipient_email = pmdp_recipient_email;
	}
	public String getPmdp_recipient_add_line1() {
		return pmdp_recipient_add_line1;
	}
	public void setPmdp_recipient_add_line1(String pmdp_recipient_add_line1) {
		this.pmdp_recipient_add_line1 = pmdp_recipient_add_line1;
	}
	public String getPmdp_recipient_add_line2() {
		return pmdp_recipient_add_line2;
	}
	public void setPmdp_recipient_add_line2(String pmdp_recipient_add_line2) {
		this.pmdp_recipient_add_line2 = pmdp_recipient_add_line2;
	}
	public String getPmdp_recipient_state_code() {
		return pmdp_recipient_state_code;
	}
	public void setPmdp_recipient_state_code(String pmdp_recipient_state_code) {
		this.pmdp_recipient_state_code = pmdp_recipient_state_code;
	}
	public String getPmdp_recipient_city() {
		return pmdp_recipient_city;
	}
	public void setPmdp_recipient_city(String pmdp_recipient_city) {
		this.pmdp_recipient_city = pmdp_recipient_city;
	}
	public String getPmdp_recipient_zip_code() {
		return pmdp_recipient_zip_code;
	}
	public void setPmdp_recipient_zip_code(String pmdp_recipient_zip_code) {
		this.pmdp_recipient_zip_code = pmdp_recipient_zip_code;
	}
	public String getPmdp_recipient_country() {
		return pmdp_recipient_country;
	}
	public void setPmdp_recipient_country(String pmdp_recipient_country) {
		this.pmdp_recipient_country = pmdp_recipient_country;
	}
	public String getPmdp_distribution_method() {
		return pmdp_distribution_method;
	}
	public void setPmdp_distribution_method(String pmdp_distribution_method) {
		this.pmdp_distribution_method = pmdp_distribution_method;
	}
	public Date getPmdp_date_created() {
		return pmdp_date_created;
	}
	public void setPmdp_date_created(Date pmdp_date_created) {
		this.pmdp_date_created = pmdp_date_created;
	}
	public Date getPmdp_date_modified() {
		return pmdp_date_modified;
	}
	public void setPmdp_date_modified(Date pmdp_date_modified) {
		this.pmdp_date_modified = pmdp_date_modified;
	}
	public String getPmdp_user_created() {
		return pmdp_user_created;
	}
	public void setPmdp_user_created(String pmdp_user_created) {
		this.pmdp_user_created = pmdp_user_created;
	}
	public String getPmdp_user_modified() {
		return pmdp_user_modified;
	}
	public void setPmdp_user_modified(String pmdp_user_modified) {
		this.pmdp_user_modified = pmdp_user_modified;
	}
}
