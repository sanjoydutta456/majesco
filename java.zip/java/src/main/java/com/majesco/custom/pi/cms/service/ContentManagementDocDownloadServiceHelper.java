package com.majesco.custom.pi.cms.service;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.URL;
import java.net.URLConnection;
import java.net.UnknownServiceException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;

import com.coverall.exceptions.ExceptionImpl;
import com.coverall.exceptions.JDBCException;
import com.coverall.mt.http.HTTPConstants;
import com.coverall.mt.http.User;
import com.coverall.mt.util.InterfaceConversionUtil;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.util.MachineInfoUtil;
import com.coverall.mt.xml.DOMUtil;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.majesco.custom.pi.cms.constants.ContentManagementConstants;
import com.majesco.custom.pi.cms.model.CMSMetaDataEntity;
import com.majesco.custom.pi.cms.model.CMSMetaDataRoot;
import com.majesco.custom.pi.cms.model.DocGenPrintEntity;

public class ContentManagementDocDownloadServiceHelper {
	
	private static final String CURRENT_FOLDER_DATE_SUFFIX = "yyyyMMdd_HH_mm";
	private static final String CURRENT_FOLDER_PREFIX = "protective_policy_";
	private static final String BASE_FOLDER_POLICY_PATH = "policy";
	private static final String ZIP_FOLDER = "zip";
	private static final String USER_DOMAIN = "protective.com";
	private static final String FILE_EXTENSION_PDF = ".pdf";
	private static final String FILE_EXTENSION_JSON = ".JSON";
	private static final String FILE_EXTENSION_ZIP = ".zip";
	private static final int BUFFER_SIZE = 1024;

	private ContentManagementServiceHelper serviceHelper = new ContentManagementServiceHelper();
	private ContentManagementSFTPServiceHelper sftpServiceHelper = new ContentManagementSFTPServiceHelper();
	
	public String getCurrentRunFolderName() {
		String currentFolder = "";
		
		SimpleDateFormat sdf = new SimpleDateFormat(CURRENT_FOLDER_DATE_SUFFIX);
		String suffix = sdf.format(new Date());
		currentFolder = CURRENT_FOLDER_PREFIX + suffix;
		logMessage(LogEntry.SEVERITY_INFO, "Info-ContentManagementDocDownloadServiceHelper-Current Folder Path :" + currentFolder, "");
		return currentFolder;
	}
	
	public String getBaseFolder() {

		String basePath = System.getProperty(DOMUtil.MIC_SYSTEM_HOME) + File.separator + BASE_FOLDER_POLICY_PATH;
		logMessage(LogEntry.SEVERITY_INFO, "Info-ContentManagementDocDownloadServiceHelper-Base Path :" + basePath, "");
		File baseDir = new File(basePath);
		if (!baseDir.exists()) {
			baseDir.mkdirs();
			logMessage(LogEntry.SEVERITY_INFO, "Info-ContentManagementDocDownloadServiceHelper-Base Policy folder created", "");
		} else {
			logMessage(LogEntry.SEVERITY_INFO, "Info-ContentManagementDocDownloadServiceHelper-Base Policy folder already exists", "");
		}

		return basePath;
	}
	
	public String getZipFolder() {
		String zipFolderPath = getBaseFolder() + File.separator + ZIP_FOLDER;
		File zipFolder = new File(zipFolderPath);
		if (!zipFolder.exists()) {
			zipFolder.mkdir();
		}
		return zipFolderPath;
	}
	
	public String createCurrentRunFolder() {
		String currentFolderPath = getBaseFolder() + File.separator + getCurrentRunFolderName();
		logMessage(LogEntry.SEVERITY_INFO, "Info-ContentManagementDocDownloadServiceHelper-Current Run Folder Path :" + currentFolderPath, "");
		File currentFolder = new File(currentFolderPath);
		if (!currentFolder.exists()) {
			currentFolder.mkdir();
			logMessage(LogEntry.SEVERITY_INFO, "Info-ContentManagementDocDownloadServiceHelper-Current Run folder created", "");
		} else {
			logMessage(LogEntry.SEVERITY_INFO, "Info-ContentManagementDocDownloadServiceHelper-Current Run folder already exists", "");
		}
		return currentFolderPath;
	}
	
	public void downloadDocuments(List<DocGenPrintEntity> entityList, User user) throws Exception {
		String currentRunFilePath = createCurrentRunFolder();
		String currentRunFolderName = getCurrentRunFolderName();
		logMessage(LogEntry.SEVERITY_INFO, "Info-ContentManagementDocDownloadServiceHelper-downloadDocuments() : ", "");

		Map<String, String> wsParams = serviceHelper.getWSParameters(user);
		String authStr = (String) wsParams.get(ContentManagementConstants.WS_PARAM_DOC_REPO_USER_ID) + ":"
				+ (String) wsParams.get(ContentManagementConstants.WS_PARAM_DOC_REPO_PASSWORD);
		Base64 b = new Base64();
		String basicAuthCred = b.encodeAsString(authStr.getBytes());
		File docFile = null;
		String docFilePath = null;
		
		if (entityList != null && entityList.size() > 0) {
			List<CMSMetaDataEntity> metaDataList = new ArrayList<>();
			List<Long> printIdList = new ArrayList<>();
			for (DocGenPrintEntity printEntity : entityList) {
				try(InputStream inStream = getDocumentServletResponseStream(printEntity.getPmdp_entity_reference(),
						printEntity.getPmdp_doc_pkg_id(), basicAuthCred)) {
					docFilePath = currentRunFilePath + File.separator + printEntity.getPmdp_file_name() + FILE_EXTENSION_PDF;
					logMessage(LogEntry.SEVERITY_INFO, "ContentManagementDocDownloadServiceHelper: docFilePath :" + docFilePath, "");
					docFile = new File(docFilePath);
					
					if (docFile.exists()) {
						docFile.delete();
					}
					docFile.createNewFile();
					
					try(BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(docFile), BUFFER_SIZE)) {
						
						byte[] data = new byte[BUFFER_SIZE];
						int count;
						while ((count = inStream.read(data, 0, BUFFER_SIZE)) != -1) {
							bos.write(data, 0, count);
						}
					}
					logMessage(LogEntry.SEVERITY_INFO,
							"ContentManagementDocDownloadServiceHelper: File download Success for :"
									+ printEntity.getPmdp_entity_reference() + ":" + printEntity.getPmdp_file_name(), "");
					metaDataList.add(serviceHelper.buildCMSMetaData(printEntity));
					printIdList.add(printEntity.getPmdp_id());
				} catch (Exception e) {
					logMessage(LogEntry.SEVERITY_FATAL, "ContentManagementDocDownloadServiceHelper: Exception while downloading file :" + e.getMessage(), "");
					serviceHelper.updateProcessingStatus(user, printEntity.getPmdp_id(), ContentManagementConstants.STATUS_FAILED);
				}
			}

			createMetaDataFile(metaDataList, currentRunFilePath, currentRunFolderName, user);
			
			zipAndUploadToSFTP(currentRunFilePath, currentRunFolderName, user, printIdList);
		}
	}
	
	public void zipAndUploadToSFTP(String currentRunFilePath, String currentRunFolderName, User user, List<Long> printIdList) {
		//Zip the folder and transfer the zip file
		String zipFolderPath = currentRunFilePath;
		File zipFolder = new File(zipFolderPath);
		if (zipFolder.isDirectory() && zipFolder.list().length > 0) {
			String zipFilePath = getZipFolder() + File.separator + currentRunFolderName + FILE_EXTENSION_ZIP;
			sftpServiceHelper.zipDirectory(zipFolder, zipFilePath);
			sftpServiceHelper.uploadFileToSFTP(zipFilePath, user);
			String fileTransferStatus = sftpServiceHelper.uploadFileToSFTP(zipFilePath, user);
			if (fileTransferStatus.equals("SUCCESS")) {
				logMessage(LogEntry.SEVERITY_INFO, "ContentManagementDocDownloadServiceHelper - Zip File Transfer Success", "");
				updateProcessingStatusAfterZipFileTransfer(user, ContentManagementConstants.STATUS_PROCESSED, printIdList);
			} else {
				logMessage(LogEntry.SEVERITY_FATAL, "ContentManagementDocDownloadServiceHelper - Zip File Transfer Failed", "");
				updateProcessingStatusAfterZipFileTransfer(user, ContentManagementConstants.STATUS_FAILED, printIdList);
			}
		} else {
			logMessage(LogEntry.SEVERITY_FATAL, "ContentManagementDocDownloadServiceHelper-Zip Folder doesn't have files", "");
		}
		
		//Deleting the current run folder
		deleteCurrentRunFolder(currentRunFilePath, user);
	}
	
	private void updateProcessingStatusAfterZipFileTransfer(User user, String status, List<Long> printIdList) {
		try {
			logMessage(LogEntry.SEVERITY_INFO, "ContentManagementDocDownloadServiceHelper-Processing Status for this run : " + status, "");
			if (printIdList != null && printIdList.size() > 0) {
				for(Long pmdpId : printIdList) {
					serviceHelper.updateProcessingStatus(user, pmdpId, status);
				}
				logMessage(LogEntry.SEVERITY_INFO, "ContentManagementDocDownloadServiceHelper-Processing Status updated successfully", "");
			}
		} catch (Exception e) {
			logMessage(LogEntry.SEVERITY_FATAL, "ContentManagementDocDownloadServiceHelper-Error while updating Processing Status", "");
		}
	}
	
	private void deleteCurrentRunFolder(String folderPath, User user) {
		String deleteCurrentRunFolder = "false";
		try {
			deleteCurrentRunFolder = (String) serviceHelper.getWSParameters(user).get(ContentManagementConstants.WS_PARAM_DELETE_TEMP_FOLDER);
			if (deleteCurrentRunFolder.equals("true")) {
				deleteFolder(new File(folderPath));
			}
		} catch (Exception e) {
			logMessage(LogEntry.SEVERITY_FATAL, "ContentManagementDocDownloadServiceHelper-Error while deleting current run folder:" + e.getMessage(), "");
		}
	}
	
	public InputStream getDocumentServletResponseStream(String entityReference, String packageId, String basicAuthCred)
			throws Exception {
		URLConnection httpConn = null;
		InputStream in = null;

		String httpURL = getFullURL(InetAddress.getLocalHost().getHostName());

		String customerDomain = USER_DOMAIN;
		httpURL += "/mic/imaging/servlet/DocumentPackaging";

		String content = "?ctiComponent=imaging&packageId=" + packageId + "&entityReference=" + entityReference
				+ "&isStandalone=Y&userDomain=" + customerDomain + "&" + HTTPConstants.REQUEST_PREPARE_FOR_DUPLEX
				+ "=true";
		content += "&throwError=true";
		httpURL += content;
		logMessage(LogEntry.SEVERITY_INFO, "getDocumentServletResponseStream():Content : " + content, "");
		httpConn = new URL(httpURL).openConnection();
		httpConn.setRequestProperty("Content-Type", "application/pdf");
		httpConn.setRequestProperty("Authorization", "Basic " + basicAuthCred);
		httpConn.setDoOutput(true);
		httpConn.setUseCaches(false);
		httpConn.setDefaultUseCaches(false);
		try {
			in = httpConn.getInputStream();
			logMessage(LogEntry.SEVERITY_INFO, "getDocumentServletResponseStream(): data in Inputstream", "");
		} catch (UnknownServiceException e) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, "ContentManagementDocDownloadServiceHelper",
					"getDocumentServletResponseStream", "", new Object[] {},
					"Error occured while reading response from  Document Packaging Servlet :"
							+ httpConn.getHeaderField("ErrorString") + ". URL executed [" + httpURL + "]",
					e, this.getClass().getName());
			throw new ExceptionImpl(ExceptionImpl.NON_FATAL, "Error in Document generation: Policy list is empty!", e);
		}

		return in;
	}
	
	private final String getFullURL(String hostname) throws JDBCException {
		logMessage(LogEntry.SEVERITY_INFO, "getFullURL() : Inside the method : HostName : " + hostname, "");
		String siteName = MachineInfoUtil.getSiteName();
		if (siteName != null) {
			return siteName;
		}
		StringBuilder url = new StringBuilder();
		try (Connection aconn = InterfaceConversionUtil.getAdminConnection();
				Statement st = aconn.createStatement();
				ResultSet rs = st
						.executeQuery("select * from adm_machines where (lower(ama_name) = '" + hostname.toLowerCase()
								+ "' or lower(ama_virtualhost_name) = '" + hostname.toLowerCase() + "')")) {

			if (rs.next()) {
				logMessage(LogEntry.SEVERITY_INFO, "getFullURL() : Inside Resultset", "");
				String isSecure = rs.getString("ama_secure");
				if (isSecure.equalsIgnoreCase("Y")) {
					url.append(ContentManagementConstants.PROTOCOL_HTTPS);
				} else {
					url.append(ContentManagementConstants.PROTOCOL_HTTP);
				}
				String name = "";
				String domain = "";
				String port = "";
				String virtualhostName = rs.getString("ama_virtualhost_name");
				if (virtualhostName == null || virtualhostName.equalsIgnoreCase("")) {
					// use normal parameters
					name = rs.getString("ama_name");
					domain = rs.getString("ama_fqdn");
					port = rs.getString("ama_admin_port");
				} else {
					// use virtual host parameters
					name = rs.getString("ama_virtualhost_name");
					domain = rs.getString("ama_userdomain");
					port = rs.getString("ama_virtualhost_port");
					if (port == null || port.equalsIgnoreCase("")) {
						port = rs.getString("ama_admin_port");
					}
				}
				url.append(name);
				url.append(".");
				url.append(domain);
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
						ContentManagementDocDownloadServiceHelper.class.getName(), "getFullUrl",
						ServletConfigUtil.COMPONENT_PORTAL, null, "Port = " + port, null,
						LogMinderDOMUtil.VALUE_SCHEDULAR);
				if (!(port.equalsIgnoreCase(ContentManagementConstants.HTTP_DEFAULT_PORT)
						|| port.equalsIgnoreCase(ContentManagementConstants.HTTPS_DEFAULT_PORT))) {
					url.append(":");
					url.append(port);
				}
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
						ContentManagementDocDownloadServiceHelper.class.getName(), "getFullUrl",
						ServletConfigUtil.COMPONENT_PORTAL, null, "URL = " + url.toString(), null,
						LogMinderDOMUtil.VALUE_SCHEDULAR);
			} else {
				throw new JDBCException(ExceptionImpl.FATAL, "Unable to retrieve results for hostname: " + hostname,
						null);
			}
		} catch (Exception e) {
			throw new JDBCException(ExceptionImpl.FATAL, "Error while creating FullUrl (" + hostname + ")", e);
		}
		return url.toString();
	}
	
	private void createMetaDataFile(List<CMSMetaDataEntity> metaDataList, String currentRunFilePath, String currentRunFolderName, User user) {
		String metaDataFilePath = currentRunFilePath + File.separator + currentRunFolderName + FILE_EXTENSION_JSON;
		logMessage(LogEntry.SEVERITY_INFO, "ContentManagementDocDownloadServiceHelper-MetaDataFilePath : " + metaDataFilePath, "");
		if (metaDataList != null && metaDataList.size() > 0) {
			CMSMetaDataRoot metaDataRoot = serviceHelper.buildCMSMetaDataRoot(metaDataList);
			try {
				FileWriter fw = new FileWriter(metaDataFilePath);
				fw.write(serviceHelper.getJson(metaDataRoot));
				fw.close();
			} catch (Exception e) {
				logMessage(LogEntry.SEVERITY_FATAL, "Error while creating meta data JSON file :" + e.getMessage(), "");
			}
			
			logMessage(LogEntry.SEVERITY_INFO, "ContentManagementDocDownloadServiceHelper-MetaDataFileCreated Successfully", "");

		} else {
			logMessage(LogEntry.SEVERITY_FATAL, "ContentManagementDocDownloadServiceHelper-MetaDataFile Not Created since list is empty", "");
		}
	}
	
	private void deleteFolder(File file) {
		logMessage(LogEntry.SEVERITY_INFO, "ContentManagementDocDownloadServiceHelper: Deleting the Folder :" + file.getName(), "");
		if (file.exists()) {
			for (File subFile : file.listFiles()) {
				if (subFile.isDirectory()) {
					deleteFolder(subFile);
				} else {
					subFile.delete();
				}
			}
			file.delete();
		}
		logMessage(LogEntry.SEVERITY_INFO, "ContentManagementDocDownloadServiceHelper: Folder deleted successfully", "");
	}
	
	private void logMessage(int logLevel, String inputMsg, String objMsg) {
		LogMinder.getLogMinder().log(logLevel, ContentManagementDocDownloadServiceHelper.class.getName(), ContentManagementConstants.FUNCTION_NAME,
				ServletConfigUtil.COMPONENT_PORTAL, new Object[]{objMsg}, 
				inputMsg, null, LogMinderDOMUtil.VALUE_SCHEDULAR);
	}
}
