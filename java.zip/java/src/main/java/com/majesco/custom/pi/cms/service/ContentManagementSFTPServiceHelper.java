package com.majesco.custom.pi.cms.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.majesco.custom.pi.cms.constants.ContentManagementConstants;

public class ContentManagementSFTPServiceHelper {

	private ContentManagementServiceHelper serviceHelper = new ContentManagementServiceHelper();

	public String uploadFileToSFTP(String filePath, User user) {
		logMessage(LogEntry.SEVERITY_INFO, "ContentManagementSFTPServiceHelper - uploadFileToSFTP()", "");
		String fileUploadStatus = "FAILED";
		Session session = null;
		Channel channel = null;
		ChannelSftp channelSftp = null;
		try {
			// Retrieving SFTP config details Web service Parameters map
			Map<String, String> wsParams = serviceHelper.getWSParameters(user);
			String sftpHost = wsParams.get(ContentManagementConstants.WS_PARAM_SFTP_HOST);
			String sftpUserId = wsParams.get(ContentManagementConstants.WS_PARAM_SFTP_USER_ID);
			String sftpPassword = wsParams.get(ContentManagementConstants.WS_PARAM_SFTP_PASSWORD);
			String sftpPort = wsParams.get(ContentManagementConstants.WS_PARAM_SFTP_PORT);
			String sftpPath = wsParams.get(ContentManagementConstants.WS_PARAM_SFTP_PATH);
			int port = Integer.valueOf(sftpPort);

			JSch jsch = new JSch();
			session = jsch.getSession(sftpUserId, sftpHost, port);
			session.setPassword(sftpPassword);
			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			session.setConfig(config);
			session.connect();
			channel = session.openChannel("sftp");
			channel.connect();
			channelSftp = (ChannelSftp) channel;
			channelSftp.cd(sftpPath);
			try {
				File fileToUpload = new File(filePath);
				channelSftp.put(new FileInputStream(fileToUpload), fileToUpload.getName());
				fileUploadStatus = "SUCCESS";
				logMessage(LogEntry.SEVERITY_INFO,
						"File :" + filePath + " is successfully uploaded into SFTP location", "");
			} catch (Exception e) {
				e.printStackTrace();
				logMessage(LogEntry.SEVERITY_FATAL,
						"ContentManagementSFTPServiceHelper-Error occured while transfering the file to sftp location : File Name : "
								+ filePath + " Exception :" + e.getMessage(), "");
			}

		} catch (Exception e) {
			logMessage(LogEntry.SEVERITY_FATAL,
					"ContentManagementSFTPServiceHelper-Error occured while configuring SFTP connection: " + e.getMessage(), "");
		} finally {
			try {
				channelSftp.exit();
				channel.disconnect();
				session.disconnect();
			} catch(Exception e){
				logMessage(LogEntry.SEVERITY_FATAL, "ContentManagementSFTPServiceHelper-Error while closing SFTP connection :" + e.getMessage(), "");
			}
		}

		return fileUploadStatus;
	}
	
	public void zipDirectory(File dir, String zipDirName) {
		logMessage(LogEntry.SEVERITY_INFO, "ContentManagementSFTPServiceHelper : Zip Folder :" + dir.getAbsolutePath() + " Zip File Name :" + zipDirName, "");
		List<String> filesListInDir = new ArrayList<String>();
		try {
			filesListInDir = populateFilesList(dir);
			// now zip files one by one
			// create ZipOutputStream to write to the zip file
			FileOutputStream fos = new FileOutputStream(zipDirName);
			ZipOutputStream zos = new ZipOutputStream(fos);
			for (String filePath : filesListInDir) {
				// for ZipEntry we need to keep only relative file path, so we used substring on
				// absolute path
				ZipEntry ze = new ZipEntry(filePath.substring(dir.getAbsolutePath().length() + 1, filePath.length()));
				zos.putNextEntry(ze);
				// read the file and write to ZipOutputStream
				FileInputStream fis = new FileInputStream(filePath);
				byte[] buffer = new byte[1024];
				int len;
				while ((len = fis.read(buffer)) > 0) {
					zos.write(buffer, 0, len);
				}
				zos.closeEntry();
				fis.close();
			}
			logMessage(LogEntry.SEVERITY_INFO, "ContentManagementSFTPServiceHelper : Zipping Folder Completed Successfully", ""); 
			zos.close();
			fos.close();
		} catch (Exception e) {
			logMessage(LogEntry.SEVERITY_FATAL, "ContentManagementSFTPServiceHelper: Error while zipping the folder :" + e.getMessage(), ""); 
		}
	}

	private List<String> populateFilesList(File dir) throws Exception {
		List<String> filesListInDir = new ArrayList<String>();
		if (dir.isFile()) {
			filesListInDir.add(dir.getAbsolutePath());
		} else {
			File[] files = dir.listFiles();
			for (File file : files) {
				if (file.isFile()) {
					filesListInDir.add(file.getAbsolutePath());
				} else {
					filesListInDir.addAll(populateFilesList(file));
				}
			}
		}
		return filesListInDir;
	}

	private void logMessage(int logLevel, String inputMsg, String objMsg) {
		LogMinder.getLogMinder().log(logLevel, ContentManagementSFTPServiceHelper.class.getName(),
				ContentManagementConstants.FUNCTION_NAME, ServletConfigUtil.COMPONENT_PORTAL, new Object[] { objMsg },
				inputMsg, null, LogMinderDOMUtil.VALUE_SCHEDULAR);
	}
}
