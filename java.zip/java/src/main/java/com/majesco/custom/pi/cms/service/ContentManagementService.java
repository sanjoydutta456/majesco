package com.majesco.custom.pi.cms.service;

import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.w3c.dom.Document;

import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;
import com.coverall.mt.services.SchedulableService;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServicesDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;
import com.majesco.custom.pi.cms.constants.ContentManagementConstants;
import com.majesco.custom.pi.cms.model.DocGenPrintEntity;

import oracle.jdbc.OracleTypes;

public class ContentManagementService extends SchedulableService {
	
	private static final long serialVersionUID = 1L;
	
	
	private static final String COLUMN_ENTITY_REF = "mpo_policy_reference";
	private static final String ENTITY_TYPE = "POLICY";
	
	private static final String QUERY_GET_BOOKED_POLICY_ENTITIES = "{ ? = call k_content_management_processing.f_get_booked_policy_entity_ref (?)}";
	
	private static final String QUERY_TO_INSERT_RECORD_IN_STAGING_TABLE = "{ ? = call k_content_management_processing.f_add_doc_gen_print_data(?, ?, ?, ?)}";
	
	private ContentManagementServiceHelper serviceHelper = new ContentManagementServiceHelper();
	private ContentManagementDocDownloadServiceHelper docDownloadServiceHelper = new ContentManagementDocDownloadServiceHelper();

	public ContentManagementService() throws RemoteException {
		super();
	}
	
	public Document process(Document request, String logName) throws Exception {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		User user = null;
		try {
			logMessage(LogEntry.SEVERITY_INFO, "Info-ContentManagement-Scheduler Started at:" + new Date(), "");
			user = ServicesDOMUtil.getUser(request);
			conn = ConnectionPool.getConnection(user);
			CallableStatement call = conn.prepareCall(QUERY_GET_BOOKED_POLICY_ENTITIES);
			call.registerOutParameter(1, OracleTypes.CURSOR);
			call.setString(2, ENTITY_TYPE);
			logMessage(LogEntry.SEVERITY_INFO, "Info-ContentManagement-Before calling the function to get Records", "");
			call.execute();
			logMessage(LogEntry.SEVERITY_INFO, "Info-ContentManagement-After calling the function to get Records", "");
			ResultSet rset = (ResultSet) call.getObject(1);
			List<String> entityRefList = getEntityListFromResultSet(rset);
			// Inserting Policy Document details in to staging table
			if (entityRefList.size() > 0) {
				logMessage(LogEntry.SEVERITY_INFO, "Info-ContentManagementService-Number of New Records available for Processing : " + entityRefList.size(), "");
				for (String entityRef : entityRefList) {
					insertIntoStaging(ENTITY_TYPE, entityRef, user);
				}
			} else {
				logMessage(LogEntry.SEVERITY_FATAL, "Info-ContentManagementService-No New Records are available for Processing : ", "");
			}
			
			//updating Failed records status as NOT_PROCESSED
			serviceHelper.updateFailedRecords(user);
			
			// Processing NOT_PROCESSED status records
			List<DocGenPrintEntity> entityList = serviceHelper.getRecordsByStatus(user, ContentManagementConstants.STATUS_NOT_PROCESSED);
			if (entityList != null && entityList.size() > 0) {
				logMessage(LogEntry.SEVERITY_INFO, "Info-ContentManagementService-Number of Records available for Document Download : " + entityList.size(), "");
				for (DocGenPrintEntity entity : entityList) {
					logMessage(LogEntry.SEVERITY_INFO, "Info-ContentManagementService-PMDP_ID : " + entity.getPmdp_id(), "");
				}
				docDownloadServiceHelper.downloadDocuments(entityList, user);
			} else {
				logMessage(LogEntry.SEVERITY_FATAL, "Info-ContentManagementService-No Records available for Document Download : " + entityList.size(), "");
			}

		} catch (Exception e) {
			logMessage(LogEntry.SEVERITY_FATAL, "Error in ContentManagementService : " + e.getMessage(), "");
		} finally {
			DBUtil.close(rs, pst, conn);
		}
		return request;
	}
	
	private void insertIntoStaging(String entityType, String entityRef, User user) throws Exception {
		logMessage(LogEntry.SEVERITY_INFO, "ContentManagement Service:Entity Ref : " + entityRef, "");
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		String errorMsg = null;
	
		try {
			conn = ConnectionPool.getConnection(user);
			CallableStatement call = conn.prepareCall(QUERY_TO_INSERT_RECORD_IN_STAGING_TABLE);
			call.registerOutParameter(1, OracleTypes.INTEGER);
			call.setString(2, entityType);
			call.setString(3, entityRef);
			call.setString(4, user.getUserId());
			call.registerOutParameter(5, OracleTypes.VARCHAR);
			
			logMessage(LogEntry.SEVERITY_INFO, "Info-ContentManagement-Before calling the function to insert into staging", "");
			call.execute();
			logMessage(LogEntry.SEVERITY_INFO, "Info-ContentManagement-After calling the function to insert into staging", "");
			errorMsg = (String) call.getObject(5);
			
			Integer result = (Integer)call.getObject (1);
	            
            if (result != 0 ) {
            	logMessage(LogEntry.SEVERITY_FATAL, "ContentManagement-Error while inserting record into staging table :" + entityRef, "");
            	logMessage(LogEntry.SEVERITY_FATAL, "ContentManagement-Error Message from Oracle Function :" + errorMsg, "");
            }
		} catch (Exception e) {
			logMessage(LogEntry.SEVERITY_FATAL, "Error in ContentManagement Service : insertIntoStaging()" + e.getMessage(), "");
		} finally {
			DBUtil.close(rs, pst, conn);
		}
	}
	
	
	private List<String> getEntityListFromResultSet(ResultSet rset) throws Exception {
		List<String> entityRefList = new ArrayList<String>();

		if (rset != null) {
			logMessage(LogEntry.SEVERITY_INFO, "Info-ContentManagement-Before converting ResultSet into Entity Ref List", "");
			while (rset.next()) {
				entityRefList.add(rset.getString(COLUMN_ENTITY_REF));
			}
		}
		logMessage(LogEntry.SEVERITY_INFO, "Info-ContentManagement-After converting ResultSet into Entity Ref List", "");
		return entityRefList;
	}
	
	private void logMessage(int logLevel, String inputMsg, String objMsg) {
		LogMinder.getLogMinder().log(logLevel, ContentManagementService.class.getName(), ContentManagementConstants.FUNCTION_NAME,
				ServletConfigUtil.COMPONENT_PORTAL, new Object[]{objMsg}, 
				inputMsg, null, LogMinderDOMUtil.VALUE_SCHEDULAR);
	}

	@Override
	public String getComponentName() {
		return ServletConfigUtil.COMPONENT_PORTAL;
	}
}
