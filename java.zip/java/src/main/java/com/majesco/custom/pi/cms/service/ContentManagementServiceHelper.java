package com.majesco.custom.pi.cms.service;

import java.io.IOException;
import java.io.StringWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;

import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.events.EventProcessor;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;
import com.majesco.custom.pi.cms.constants.ContentManagementConstants;
import com.majesco.custom.pi.cms.model.CMSMetaDataEntity;
import com.majesco.custom.pi.cms.model.CMSMetaDataRoot;
import com.majesco.custom.pi.cms.model.DocGenPrintEntity;

import oracle.jdbc.OracleTypes;

public class ContentManagementServiceHelper {
	

	private static final String QUERY_GET_UNPROCESSED_RECORDS = "{ ? = call k_content_management_processing.f_get_records_on_status (?)}";

	private static final String QUERY_UPDATE_FAILED_RECORDS = "{ ? = call k_content_management_processing.f_update_failure_records (?)}";
	
	private static final String QUERY_UPDATE_PROCESSING_STATUS = "{ ? = call k_content_management_processing.f_update_processing_status (?, ?, ?)}";
	
	public List<DocGenPrintEntity> getRecordsByStatus(User user, String processedStatus) throws Exception {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		List<DocGenPrintEntity> entityList = null;
		try {
			logMessage(LogEntry.SEVERITY_INFO, "Info-ContentManagementServiceHelper - getRecordsByStatus():", "");

			conn = ConnectionPool.getConnection(user);
			CallableStatement call = conn.prepareCall(QUERY_GET_UNPROCESSED_RECORDS);
			call.registerOutParameter(1, OracleTypes.CURSOR);
			call.setString(2, processedStatus);
			logMessage(LogEntry.SEVERITY_INFO,
					"Info-ContentManagementServiceHelper-Before calling the function to get Not Processed Records", "");
			call.execute();
			logMessage(LogEntry.SEVERITY_INFO,
					"Info-ContentManagementServiceHelper-After calling the function to get Not Processed Records", "");
			ResultSet rset = (ResultSet) call.getObject(1);
			entityList = buildEntityFromResultSet(rset);

		} catch (Exception e) {
			logMessage(LogEntry.SEVERITY_FATAL, "Error in ContentManagementServiceHelper : " + e.getMessage(), "");
		} finally {
			DBUtil.close(rs, pst, conn);
		}

		return entityList;
	}
	
	public void updateFailedRecords(User user) throws Exception {
		logMessage(LogEntry.SEVERITY_INFO, "ContentManagementServiceHelper - updateFailedRecords()", "");
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		String errorMsg = null;

		try {
			conn = ConnectionPool.getConnection(user);
			CallableStatement call = conn.prepareCall(QUERY_UPDATE_FAILED_RECORDS);
			call.registerOutParameter(1, OracleTypes.INTEGER);
			call.registerOutParameter(2, OracleTypes.VARCHAR);
			logMessage(LogEntry.SEVERITY_INFO, "Info-ContentManagementServiceHelper-Before updating Failed Records", "");
			call.execute();
			logMessage(LogEntry.SEVERITY_INFO, "Info-ContentManagementServiceHelper-After updating Failed Records", "");
			errorMsg = (String) call.getObject(2);

			Integer result = (Integer) call.getObject(1);

			if (result != 0) {
				logMessage(LogEntry.SEVERITY_FATAL,
						"ContentManagementServiceHelper-Error Message from Oracle Function :" + errorMsg, "");
			}

		} catch (Exception e) {
			logMessage(LogEntry.SEVERITY_FATAL,
					"Error in ContentManagementServiceHelper : updateFailedRecords()" + e.getStackTrace(), "");
		} finally {
			DBUtil.close(rs, pst, conn);
		}

	}
	
	public void updateProcessingStatus(User user, Long pmdpId, String status) throws Exception {
		logMessage(LogEntry.SEVERITY_INFO, "ContentManagementServiceHelper - updateProcessingStatus()", "");
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		String errorMsg = null;

		try {
			conn = ConnectionPool.getConnection(user);
			CallableStatement call = conn.prepareCall(QUERY_UPDATE_PROCESSING_STATUS);
			call.registerOutParameter(1, OracleTypes.INTEGER);
			call.setLong(2, pmdpId);
			call.setString(3, status);
			call.registerOutParameter(4, OracleTypes.VARCHAR);
			call.execute();
			logMessage(LogEntry.SEVERITY_INFO,
					"Info-ContentManagementServiceHelper-After updating  Record status for PMDP_ID :" + pmdpId + " Status :" + status, "");
			
			errorMsg = (String) call.getObject(4);
			Integer result = (Integer) call.getObject(1);

			if (result != 0) {
				logMessage(LogEntry.SEVERITY_FATAL,
						"ContentManagementServiceHelper-Error Message from Oracle Function :" + errorMsg, "");
			}

		} catch (Exception e) {
			logMessage(LogEntry.SEVERITY_FATAL,
					"Error in ContentManagement Service : updateProcessingStatus()" + e.getMessage(), "");
		} finally {
			DBUtil.close(rs, pst, conn);
		}

	}
	
	private List<DocGenPrintEntity> buildEntityFromResultSet(ResultSet rset) throws Exception {
		List<DocGenPrintEntity> entityList = new ArrayList<>();
		
		if (rset != null) {
			logMessage(LogEntry.SEVERITY_INFO, "Info-ContentManagementServiceHelper-Before converting ResultSet into List of DocGenPrintEntity objects", "");
			while(rset.next()) {
				DocGenPrintEntity printEntity = new DocGenPrintEntity();
				printEntity.setPmdp_id(rset.getLong(ContentManagementConstants.COLUMN_PMDP_ID));
				printEntity.setPmdp_entity_type(rset.getString(ContentManagementConstants.COLUMN_PMDP_ENTITY_TYPE));
				printEntity.setPmdp_entity_reference(rset.getString(ContentManagementConstants.COLUMN_PMDP_ENTITY_REFERENCE));
				printEntity.setPmdp_processing_status(rset.getString(ContentManagementConstants.COLUMN_PMDP_PROCESSING_STATUS));
				printEntity.setPmdp_processing_date(rset.getDate(ContentManagementConstants.COLUMN_PMDP_PROCESSING_DATE));
				printEntity.setPmdp_policy_number(rset.getString(ContentManagementConstants.COLUMN_PMDP_POLICY_NUMBER));
				printEntity.setPmdp_policy_suffix(rset.getString(ContentManagementConstants.COLUMN_PMDP_POLICY_SUFFIX));
				printEntity.setPmdp_full_policy_id(rset.getString(ContentManagementConstants.COLUMN_PMDP_FULL_POLICY_ID));
				printEntity.setPmdp_policy_status(rset.getString(ContentManagementConstants.COLUMN_PMDP_POLICY_STATUS));
				printEntity.setPmdp_effective_date(rset.getDate(ContentManagementConstants.COLUMN_PMDP_EFFECTIVE_DATE));
				printEntity.setPmdp_expiration_date(rset.getDate(ContentManagementConstants.COLUMN_PMDP_EXPIRATION_DATE));
				printEntity.setPmdp_inception_date(rset.getDate(ContentManagementConstants.COLUMN_PMDP_INCEPTION_DATE));
				printEntity.setPmdp_primary_insured_name(rset.getString(ContentManagementConstants.COLUMN_PMDP_PRIMARY_INSURED_NAME));
				printEntity.setPmdp_billing_account_id(rset.getString(ContentManagementConstants.COLUMN_PMDP_BILLING_ACCOUNT_ID));
				printEntity.setPmdp_producer_id(rset.getString(ContentManagementConstants.COLUMN_PMDP_PRODUCER_ID));
				printEntity.setPmdp_doc_pkg_id(rset.getString(ContentManagementConstants.COLUMN_PMDP_DOC_PKG_ID));
				printEntity.setPmdp_doc_name(rset.getString(ContentManagementConstants.COLUMN_PMDP_DOC_NAME));
				printEntity.setPmdp_doc_description(rset.getString(ContentManagementConstants.COLUMN_PMDP_DOC_DESCRIPTION));
				printEntity.setPmdp_doc_date(rset.getDate(ContentManagementConstants.COLUMN_PMDP_DOC_DATE));
				printEntity.setPmdp_file_name(rset.getString(ContentManagementConstants.COLUMN_PMDP_FILE_NAME));
				printEntity.setPmdp_product_code(rset.getString(ContentManagementConstants.COLUMN_PMDP_PRODUCT_CODE));
				printEntity.setPmdp_attachment_type(rset.getString(ContentManagementConstants.COLUMN_PMDP_ATTACHMENT_TYPE));
				printEntity.setPmdp_mode(rset.getString(ContentManagementConstants.COLUMN_PMDP_MODE));
				printEntity.setPmdp_signed_flag(rset.getString(ContentManagementConstants.COLUMN_PMDP_SIGNED_FLAG));
				printEntity.setPmdp_recipient_type(rset.getString(ContentManagementConstants.COLUMN_PMDP_RECIPIENT_TYPE));
				printEntity.setPmdp_recipient_email(rset.getString(ContentManagementConstants.COLUMN_PMDP_RECIPIENT_EMAIL));
				printEntity.setPmdp_recipient_add_line1(rset.getString(ContentManagementConstants.COLUMN_PMDP_RECIPIENT_ADD_LINE1));
				printEntity.setPmdp_recipient_add_line2(rset.getString(ContentManagementConstants.COLUMN_PMDP_RECIPIENT_ADD_LINE2));
				printEntity.setPmdp_recipient_state_code(rset.getString(ContentManagementConstants.COLUMN_PMDP_RECIPIENT_STATE_CODE));
				printEntity.setPmdp_recipient_city(rset.getString(ContentManagementConstants.COLUMN_PMDP_RECIPIENT_CITY));
				printEntity.setPmdp_recipient_zip_code(rset.getString(ContentManagementConstants.COLUMN_PMDP_RECIPIENT_ZIP_CODE));
				printEntity.setPmdp_recipient_country(rset.getString(ContentManagementConstants.COLUMN_PMDP_RECIPIENT_COUNTRY));
				printEntity.setPmdp_distribution_method(rset.getString(ContentManagementConstants.COLUMN_PMDP_DISTRIBUTION_METHOD));
				printEntity.setPmdp_date_created(rset.getDate(ContentManagementConstants.COLUMN_PMDP_DATE_CREATED));
				printEntity.setPmdp_date_modified(rset.getDate(ContentManagementConstants.COLUMN_PMDP_DATE_MODIFIED));
				printEntity.setPmdp_user_created(rset.getString(ContentManagementConstants.COLUMN_PMDP_USER_CREATED));
				printEntity.setPmdp_user_modified(rset.getString(ContentManagementConstants.COLUMN_PMDP_USER_MODIFIED));
				
				entityList.add(printEntity);
			}
		}
		logMessage(LogEntry.SEVERITY_INFO, "Info-ContentManagementServiceHelper-After converting ResultSet into List of DocGenPrintEntity objects", "");
		return entityList;
	}
	
	public CMSMetaDataRoot buildCMSMetaDataRoot(List<CMSMetaDataEntity> entityList) {
		CMSMetaDataRoot root = new CMSMetaDataRoot();
		root.setPolicyDocMetaDetails(entityList);
		logMessage(LogEntry.SEVERITY_INFO, "Info-ContentManagementServiceHelper-CMS Meta data root object created successfully", "");
		return root;
	}
	
	public CMSMetaDataRoot buildCMSMetaData(List<DocGenPrintEntity> entityList) {
		List<CMSMetaDataEntity> metaDataList = new ArrayList<>();
		if (entityList != null && entityList.size() > 0) {
			for (DocGenPrintEntity printEntity : entityList) {
				CMSMetaDataEntity metaData = buildCMSMetaData(printEntity);
				metaDataList.add(metaData);
			}
			
			CMSMetaDataRoot root = new CMSMetaDataRoot();
			root.setPolicyDocMetaDetails(metaDataList);
			logMessage(LogEntry.SEVERITY_INFO, "Info-ContentManagementServiceHelper-CMS Meta data objects created successfully", "");
			return root;
		} else {
			return null;
		}
	}
	
	public CMSMetaDataEntity buildCMSMetaData(DocGenPrintEntity printEntity) {
		CMSMetaDataEntity metaData = new CMSMetaDataEntity();
		metaData.setPolicyNumber(printEntity.getPmdp_policy_number());
		metaData.setPolicySuffix(printEntity.getPmdp_policy_suffix());
		metaData.setFullPolicyId(printEntity.getPmdp_full_policy_id());
		metaData.setPolicyStatus(printEntity.getPmdp_policy_status());
		metaData.setEffectiveDate(printEntity.getPmdp_effective_date());
		metaData.setExpirationDate(printEntity.getPmdp_expiration_date());
		metaData.setInceptionDate(printEntity.getPmdp_inception_date());
		metaData.setPrimaryInsuredName(printEntity.getPmdp_primary_insured_name());
		metaData.setBillingAccountId(printEntity.getPmdp_billing_account_id());
		metaData.setProducerId(printEntity.getPmdp_producer_id());
		metaData.setDocPkgId(printEntity.getPmdp_doc_pkg_id());
		metaData.setDocName(printEntity.getPmdp_file_name());
		metaData.setDocDescription(printEntity.getPmdp_doc_description());
		metaData.setDocDate(printEntity.getPmdp_doc_date());
		metaData.setProductCode(printEntity.getPmdp_product_code());
		metaData.setAttachmentType(printEntity.getPmdp_attachment_type());
		metaData.setMode(printEntity.getPmdp_mode());
		metaData.setSignedFlag(printEntity.getPmdp_signed_flag());
		metaData.setRecipientEmail(printEntity.getPmdp_recipient_email());
		metaData.setRecipientAddLine1(printEntity.getPmdp_recipient_add_line1());
		metaData.setRecipientAddLine2(printEntity.getPmdp_recipient_add_line2());
		metaData.setRecipientState(printEntity.getPmdp_recipient_state_code());
		metaData.setRecipientCity(printEntity.getPmdp_recipient_city());
		metaData.setRecipientZipCode(printEntity.getPmdp_recipient_zip_code());
		metaData.setDistributionMethod(printEntity.getPmdp_distribution_method());
		
		return metaData;
	}
	
	@SuppressWarnings("unchecked")
	public Map<String, String> getWSParameters(User user) throws Exception {
		
		Map<String, String> webserviceParams = EventProcessor
				.getWebServiceParameters(ContentManagementConstants.CONTENT_MANAGEMENT_WEB_SERVICE_NAME, user);
		if (webserviceParams == null) {
			logMessage(LogEntry.SEVERITY_FATAL, "Info-ContentManagementDocDownloadService-WS Params Map is null", "");
			return null;
		}
		
		return webserviceParams;
	}
	
	public String getJson(CMSMetaDataEntity obj){
		ObjectMapper mapper = new ObjectMapper();
		StringWriter writer = new StringWriter();
		try {
			mapper.writeValue(writer, obj);
		} catch (IOException e) {
			logMessage(LogEntry.SEVERITY_FATAL, "Exception while converting CMSMetaDataEntity into JSON", "");
		}
		logMessage(LogEntry.SEVERITY_INFO, "CMSMetaDataEntity in Json Format:" + writer.getBuffer().toString(), "");
		return writer.getBuffer().toString();
		
	}
	
	public String getJson(CMSMetaDataRoot obj){
		ObjectMapper mapper = new ObjectMapper();
		StringWriter writer = new StringWriter();
		try {
			mapper.writeValue(writer, obj);
		} catch (IOException e) {
			logMessage(LogEntry.SEVERITY_FATAL, "Exception while converting CMSMetaDataRoot into JSON", "");
		}
		logMessage(LogEntry.SEVERITY_INFO, "CMSMetaDataRoot in Json Format:" + writer.getBuffer().toString(), "");
		return writer.getBuffer().toString();
		
	}
	
	private void logMessage(int logLevel, String inputMsg, String objMsg) {
		LogMinder.getLogMinder().log(logLevel, ContentManagementServiceHelper.class.getName(), ContentManagementConstants.FUNCTION_NAME,
				ServletConfigUtil.COMPONENT_PORTAL, new Object[]{objMsg}, 
				inputMsg, null, LogMinderDOMUtil.VALUE_SCHEDULAR);
	}

}
