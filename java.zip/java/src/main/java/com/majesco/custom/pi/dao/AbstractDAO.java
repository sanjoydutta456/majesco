package com.majesco.custom.pi.dao;

import com.coverall.exceptions.ExceptionImpl;
import com.coverall.exceptions.FactoryObjectInitializationException;
import com.coverall.exceptions.JDBCException;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.HTTPConstants;
import com.coverall.mt.http.User;

import com.coverall.util.DBUtil;

import java.io.Serializable;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;

import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


/*
 *                 Majesco Code License Notice
 *
 * The contents of this file are subject to the Majesco Code License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License
 *
 * The Original Code is for My Insurance Center. The Initial Developer
 * of the Original Code is Majesco, All Rights Reserved.
 */
/**
 * This DAO class is use to initialize the parameter,insert,delete and update submission.
 * @author $Author:   anil  $
 * @version $Revision:   1.14  $
 */
public abstract class AbstractDAO implements IDao, Serializable {
    protected Map data = new HashMap();
    protected Map dataTypes = new HashMap();
    protected User user;

    /**
     * This operation is used to initialise the data for key passed in the parameter
     * @param User to get connection to use to load data
     * @param The primary key to use to load data
     * @throws Exception if any error occurs during initialisation, mutiple records found or no records found
     */
    public void initialise(User user, String reference) throws Exception {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = ConnectionPool.getConnection(user);
            String selectQuery = getSelectQuery();
            ps = conn.prepareStatement(selectQuery);
            ps.setString(1, reference);
            rs = ps.executeQuery();
            if (rs.next()) {
                Iterator it = getColumns().iterator();
                while (it.hasNext()) {
                    String column = it.next().toString();
                    String value = rs.getString(column);
                    data.put(column, value);
                }
            } else {
                throw new JDBCException("No record found with key " + reference, null);
            }
            if (rs.next()) {
                throw new JDBCException("Multiple records found with key " + reference, null);
            }
            
            this.user = user;
        } catch (JDBCException je) {
            throw je;
        } catch (Throwable error) {
            throw new JDBCException("", error);
        } finally {
            DBUtil.close(rs, ps, conn);
        }
    }

    /**
     * This operation retrieves the column values from the request object and stores them in a map
     * @param user the user who sent the request
     * @param userData the request data
     * @throws Exception if any exception occurs while processing
     */
    public void initialise(User user, Map userData) throws Exception {
        if (userData == null || userData.size() == 0) {
            throw new FactoryObjectInitializationException(ExceptionImpl.FATAL, 
                                                           "args was null", 
                                                           null);
        }
        this.user = user;

        List columns = this.getColumns();

        if (columns == null) {
            throw new FactoryObjectInitializationException(ExceptionImpl.FATAL, 
                                                           "column list is null", 
                                                           null);
        }

        Iterator columnsItr = columns.iterator();
        while (columnsItr.hasNext()) {
            String columnName = (String)columnsItr.next();

            if (userData.containsKey(columnName)) {
                String columnValue = (String)userData.remove(columnName);
                data.put(columnName, columnValue);
            }
        }
    }

    /**
     * Retrieves the value for the column name passed in the parameter
     * @param column the column name whose value is to be fetched
     * @return the column value
     */
    public String getValue(String column) {
        return (String)data.get(column);
    }

    /**
     * This method inserts the submissions entered by user.
     * @param connection Handle to the database
     * @throws Exception  if any exception occurs while processing
     * */
    public long insert(Connection connection) throws Exception {
        long pk = 0;
        CallableStatement callableStatement = null;
        try {
            String insertProcedureName = this.getInsertProcedure();
            callableStatement = 
                    this.getStatement(connection, insertProcedureName, 
                                      IDao.NEW_INT);

            callableStatement.execute();

            long errorCode = callableStatement.getLong(1);

            if (errorCode != 0) {
                int errorMessagePosition = this.getErrorMessagePosition(IDao.NEW_INT);
                String errorMessage = callableStatement.getString(errorMessagePosition);
                throw JDBCException.getExceptionFor(errorCode, errorMessage);
            } else {
                int pkPosition = this.getColumns().size() + (isSaveSupported() ? 2 : 1);
                pkPosition = pkPosition + (isValidateAddressSupported() ? 1 : 0);
                pk = callableStatement.getLong(pkPosition);
            }
        } finally {
            DBUtil.close(null, callableStatement);
        }

        return pk;
    }

    /**
     * Updates the data into the database
     * @param connection the database handle
     * @throws Exception if any exception occurs while processing
     */
    public void update(Connection connection) throws Exception {
        CallableStatement callableStatement = null;
        try {
            String updateProcedureName = this.getUpdateProcedure();
            callableStatement = 
                    this.getStatement(connection, updateProcedureName, 
                                      IDao.EDIT_INT);

            callableStatement.execute();

            long errorCode = callableStatement.getLong(1);

            if (errorCode != 0) {
                
                int errorMessagePosition = 
                    this.getErrorMessagePosition(IDao.EDIT_INT);
                String errorMessage = callableStatement.getString(errorMessagePosition);
                throw JDBCException.getExceptionFor(errorCode, errorMessage);
            }
        } finally {
            DBUtil.close(null, callableStatement);
        }
    }

    /**
     * Deletes data from the database
     * @param connection handle to the database
     * @throws Exception if any exception occurs while processing
     */
    public void delete(Connection connection) throws Exception {
        CallableStatement callableStatement = null;
        try {
            String deleteProcedureName = this.getDeleteProcedure();
            callableStatement = 
                    this.getStatement(connection, deleteProcedureName, 
                                      IDao.DELETE_INT);

            callableStatement.execute();

            long errorCode = callableStatement.getLong(1);

            if (errorCode != 0) {
                int errorMessagePosition = this.getErrorMessagePosition(IDao.DELETE_INT);
                String errorMessage = callableStatement.getString(errorMessagePosition);
                throw JDBCException.getExceptionFor(errorCode, errorMessage);
            }
        } finally {
            DBUtil.close(null, callableStatement);
        }
    }

    /**
     * Creates the CallableStatement object and returns it
     * @param connection the database handle
     * @param sqlFunctionName the name of the sql function which is to be executed
     * @param operation the valid operation code
     * @return a callable statement
     * @throws Exception if any exception occurs while processing
     */
    protected CallableStatement getStatement(Connection connection, 
                                             String sqlFunctionName, 
                                             int operation) throws Exception {
        CallableStatement cStmt = null;
        String sqlFunctionCall = null;
        int sqlFunctionCallParamsNum = 2;
        List sqlFunctionParamsList = null;       
        //Create the correct parameters list based on the operation
        switch (operation) {
        case IDao.NEW_INT:
        case IDao.EDIT_INT:
            sqlFunctionParamsList = this.getColumns();
            sqlFunctionCallParamsNum = sqlFunctionParamsList.size();
            break;
        case IDao.DELETE_INT:
            List tempList = this.getColumns();
            String pkeyColumnName = (String)tempList.get(0);
            String userModifiedColName =
                (String)tempList.get(tempList.size() - 1);
            sqlFunctionParamsList = new ArrayList(2);
            sqlFunctionParamsList.add(pkeyColumnName);
            sqlFunctionParamsList.add(userModifiedColName);
            if(null == this.getValue(userModifiedColName) || "".equals(this.getValue(userModifiedColName))){
                this.data.remove(userModifiedColName);
                this.data.put(userModifiedColName,user.getFullName());
            }
            sqlFunctionCallParamsNum = sqlFunctionParamsList.size();
            break;
        }
        
        data.put(sqlFunctionParamsList.get(sqlFunctionParamsList.size()-1), user.getFullName());
        
        if (isSaveSupported()) {
            sqlFunctionParamsList.add("P_SAVE");
            data.put("P_SAVE", "Y");
            sqlFunctionCallParamsNum = sqlFunctionParamsList.size();
        }
        
        if (isValidateAddressSupported()) {
            sqlFunctionParamsList.add("P_VALIDATE_ADDRESS");
            data.put("P_VALIDATE_ADDRESS", "Y");
            sqlFunctionCallParamsNum = sqlFunctionParamsList.size();
        }

        //Create the PL/SQL function call
        StringBuffer sBuf = new StringBuffer();
        sBuf.append("{ ? = call ");
        sBuf.append(sqlFunctionName);
        sBuf.append("(");
        for (int index = 0; index < sqlFunctionCallParamsNum + 1; index++) {
            sBuf.append("?");
            if (index != sqlFunctionCallParamsNum) {
                sBuf.append(",");
            }
        }
        sBuf.append(") }");
        sqlFunctionCall = sBuf.toString();

        //Create the callable statement
        cStmt = connection.prepareCall(sqlFunctionCall);

        //Register the parameters
        cStmt.registerOutParameter(1, Types.BIGINT);
        for (int index = 0; index < sqlFunctionCallParamsNum; index++) {
            String columnName = (String)sqlFunctionParamsList.get(index);
            String columnValue = this.getValue(columnName);
           
            if(null != columnValue){
            	columnValue = columnValue.replaceAll("\r\n", "\n");
            	//unescape the characters from xss filter
            	columnValue = columnValue.replaceAll("&amp;", "&");
            	columnValue = columnValue.replace("&lt;", "<");
            	columnValue = columnValue.replaceAll("&gt;", ">");
            }    
            
            int parameterPosition = 
                (operation == IDao.NEW_INT) ? (index + 1) : (index + 2);

            if (operation != IDao.NEW_INT || 
                (index > 0 && index <= sqlFunctionCallParamsNum - 1)) {
                if (index == 0) {
                    cStmt.setLong(parameterPosition, 
                                  Long.parseLong(columnValue));
                } else {
                    if (columnValue == null || "".equals(columnValue.trim())) {                        
                        String dataType = getDataType(columnName);
                        if(null == dataType || "string".equalsIgnoreCase(dataType)){
                            cStmt.setNull(parameterPosition, Types.VARCHAR);
                        } else if("date".equalsIgnoreCase(dataType)){
                            cStmt.setDate(parameterPosition, null);
                         }
                    } else {
                        String dataType = getDataType(columnName);
                        if(null == dataType || "string".equalsIgnoreCase(dataType)){
                            cStmt.setString(parameterPosition, columnValue);
                        } else if("date".equalsIgnoreCase(dataType)){
                            try {
                                SimpleDateFormat parseDateFormat = new SimpleDateFormat("MM/dd/yyyy");
                                Date date = new java.sql.Date(parseDateFormat.parse(columnValue).getTime());
                                cStmt.setDate(parameterPosition, date);
                            } catch (Throwable error) {
                                throw new JDBCException(
                                    JDBCException.NON_FATAL, 
                                    "Use MM/DD/YYYY format for date.", null);
                            }

                        }
                    }
                }
            } else if (operation == IDao.NEW_INT && index == 0) {
                cStmt.registerOutParameter(sqlFunctionCallParamsNum + 1, 
                                           Types.BIGINT);
            }
        }

        int lastParameterPosition = sqlFunctionParamsList.size() + 2;
        cStmt.registerOutParameter(lastParameterPosition, Types.VARCHAR);
        return cStmt;
    }

    /**
     * Returns the position of the error message out parameter in the PL/SQL function that is invoked
     * @param operation a valid operation code
     * @return the position of the error message out parameter in the PL/SQL function that is invoked
     */
    protected int getErrorMessagePosition(int operation) {
        List tempColumnList = this.getColumns();
        int errorMessagePosition = -1;
        switch (operation) {
        case IDao.NEW_INT:
        case IDao.EDIT_INT:            
              
              if(isSaveSupported() && isValidateAddressSupported()) {
              errorMessagePosition = tempColumnList.size() + 4;      
              }else if (isSaveSupported() || isValidateAddressSupported() ) {
                errorMessagePosition = tempColumnList.size() + 3;    

              }else {
                errorMessagePosition = tempColumnList.size() + 2;    

              }
              
           // errorMessagePosition = tempColumnList.size() + (isSaveSupported() ? 3: 2);
            break;
        case IDao.DELETE_INT:
            errorMessagePosition = isSaveSupported()? 5 : 4;
            break;
        }

        return errorMessagePosition;
    }
    
    public String getSelectQuery() throws Exception {
        throw new UnsupportedOperationException("Select function is not supported on this object.");
    }
    
    public void deleteAll(Connection conn, Map params) throws Exception {
        CallableStatement cs = null; 
        try  {
            cs = conn.prepareCall("{ ? = call K_Folder_Management.f_del_folder_object_data(?, ?, ?) }");
            String folderObjectId = (String)params.get(HTTPConstants.PARAM_FOLDER_OBJECT_ID);
            cs.registerOutParameter(1, Types.NUMERIC);
            cs.registerOutParameter(4, Types.VARCHAR);
            cs.setString(2, folderObjectId);
            cs.setString(3, user.getFullName());
            cs.execute();
            long errorCode = cs.getLong(1);
            if (errorCode != 0) {
                String errorMessage = cs.getString(4);
                throw JDBCException.getExceptionFor(errorCode, errorMessage);
            }
        } finally  {
            DBUtil.close(null, cs, null);
        }
    }

    public String getDataType(String columnName){
        return (String)dataTypes.get(columnName);
    }
    
    protected boolean isSaveSupported() {
        return false;
    }
    
    protected boolean isValidateAddressSupported() {
        return false;
    }
    
    public void setValue(String column, String value) {
        data.put(column, value);        
    }
    
    public void purgeOOSE(Connection conn) throws Exception {  
    	throw new UnsupportedOperationException();
    }
    
    public void book(Connection conn) throws Exception { 
    	throw new UnsupportedOperationException();
    }
    
    public void bookOverride(Connection conn,Map params) throws Exception { 
    	throw new UnsupportedOperationException();
    }
    
    public void unbookOverride(Connection conn,Map params) throws Exception { 
    	throw new UnsupportedOperationException();
    }
    
    public void autoCompleteTransaction(Connection conn) throws Exception{
        throw new UnsupportedOperationException();
    }
    
}
