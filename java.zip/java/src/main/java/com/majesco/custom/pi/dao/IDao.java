package com.majesco.custom.pi.dao;

import com.coverall.factory.FactoryObject;
import com.coverall.mt.http.User;

import java.sql.Connection;
import java.sql.PreparedStatement;

import java.util.List;
import java.util.Map;
/*
 *                 Majesco Code License Notice
 *
 * The contents of this file are subject to the Majesco Code License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License
 *
 * The Original Code is for My Insurance Center. The Initial Developer
 * of the Original Code is Majesco, All Rights Reserved.
 */

/**
 * This interface is used to insert, update or delete data from the database in a generic manner.
 * @author $Author:   anil  $
 * @version $Revision:   1.5  $
 */
public interface IDao {

    public static final String NEW = "new";
    public static final String EDIT = "edit";
    public static final String VIEW = "view";
    public static final String DELETE = "delete";
    public static final String DELETE_ALL = "deleteAll";
    public static final String PURGE_OOSE = "purgeOOSE";
    public static final String BOOK	 = "book";
    public static final String BOOK_OVERRIDE = "bookOverride"; 
    public static final String AUTO_COMPLETE = "autoComplete";
    
    public static final int NEW_INT = 1;
    public static final int EDIT_INT = 2;
    public static final int DELETE_INT = 3;    
    public static final int DELETE_ALL_INT = 3;    

    /**
     * This operation should return the name of the PL/SQL function 
     * which will be invoked to insert data.
     * @return the PL/SQL function which will be used to insert data
     * @throws Exception if any error occurs while processing
     */
    public String getInsertProcedure() throws Exception;

    /**
     * This operation should return the name of the PL/SQL function 
     * which will be invoked to update data.
     * @return the PL/SQL function which will be used to update data
     * @throws Exception if any error occurs while processing
     */
    public String getUpdateProcedure() throws Exception;

    /**
     * This operation should return the name of the PL/SQL function 
     * which will be invoked to delete data.
     * @return the PL/SQL function which will be used to delete data
     * @throws Exception if any error occurs while processing
     */
    public String getDeleteProcedure() throws Exception;

    /**
     * Returns the SQL query to load all the data about this entity
     * @return the SQL query to load the data
     * @throws Exception if any error occurs while processing
     */
    public String getSelectQuery() throws Exception;
    
    /**
     * This operation will return the value of the column name specified in the parameter.
     * @param column the column name whose value is to be retrieved
     * @return the column value for the column name passed as the parameter
     */
    public String getValue(String column);
   
    /**
     * Returns a list of all column names on which the insert, update or delete operation should be performed
     * @return a list of all column names on which the insert, update or delete operation should be performed
     */
    public List getColumns();

    /**
     * This operation is used to initialise the data passed in the parameter
     * @param data a map containing initialisation data specific to the DAO implementation.
     * @throws Exception if any error occurs during initialisation
     */
    public void initialise(User user, Map data) throws Exception;

    /**
     * This operation is used to initialise the data for key passed in the parameter
     * @param User to get connection to use to load data
     * @param The primary key to use to load data
     * @throws Exception if any error occurs during initialisation, mutiple records found or no records found
     */
    public void initialise(User user, String reference) throws Exception;

    /**
     * This operation will insert data for the <code>User</code> object passed in the parameter.
     * @param connection the handle to the database
     * @return the identifier of the inserted entity
     * @throws Exception if any error occurs while inserting
     */
    public long insert(Connection conn) throws Exception;

    /**
     * This operation will modify data for the <code>User</code> object passed in the parameter.
     * @param connection the handle to the database
     * @throws Exception if any error occurs while updating
     */
    public void update(Connection conn) throws Exception;

    /**
     * This operation will delete data for the <code>User</code> object passed in the parameter.
     * @param connection the handle to the database
     * @throws Exception if any error occurs while deleting
     */
    public void delete(Connection conn) throws Exception;

	/**
     * This operation will delete data for the OOSE transaction related <code>User</code> object passed in the parameter.
     * @param connection the handle to the database
     * @throws Exception if any error occurs while deleting
     */
    public void purgeOOSE(Connection conn) throws Exception;
    
	/**
     * This operation will book the policy for book transaction related <code>User</code> object passed in the parameter.
     * @param connection the handle to the database
     * @throws Exception if any error occurs while deleting
     */    
    public void book(Connection conn) throws Exception;  
    
    
    public void bookOverride(Connection conn, Map params) throws Exception;
    
    public void unbookOverride(Connection conn,  Map params) throws Exception;

    
    /**
     * Get Data Type function will get the data type for a column.
     * @param columnName
     * @return
     */
    public String  getDataType(String columnName);
    
    /**
     * This operation will auto complete the transaction without a need to visit PCT screen.
     * Works only when transaction does not requires any other input from user other than Save-Rate-Complete operations.
     * @param connection the handle to the database
     * @throws Exception if any error occurs while deleting
     */
    public void autoCompleteTransaction(Connection conn) throws Exception;
    
}
