package com.majesco.custom.pi.holdandrelease;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.naming.NamingException;
import javax.xml.rpc.holders.StringHolder;

import org.apache.commons.lang.StringUtils;

import com.coverall.exceptions.ExceptionImpl;
import com.coverall.exceptions.FolderException;
import com.coverall.exceptions.JDBCException;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.HTTPConstants;
import com.coverall.mt.http.User;
import com.coverall.mt.soa.ListService;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;
import com.majesco.pi.portal.noc.objects.NocHoldRequestObj;
import com.majesco.pi.portal.noc.services.NocHoldReleaseClient;

public class HoldAndReleaseServices extends ListService {
    
    private static final String PMHR_HOLD_REASON = "PMHR_HOLD_REASON";
    
    private static final String PMHR_RELEASE_DATE = "PMHR_RELEASE_DATE";
    
    private static final String ENTITY_REFERENCE = "_entityReference";
    
    private static final String ENTITY_TYPE = "_entityType";
    
    private static final String ENTITY_DISPLAY_NAME = "_entityDisplayName";
    
    private static final String PMHR_CURRENT_RELEASE_DATE = "PMHR_CURRENT_RELEASE_DATE";
    
    private static final String PMHR_ID = "PMHR_ID";
    
    private static final String SIMPLE_DATE_FORMAT = "yyyy-MM-dd";
    
    private static final String NOC_ACTION = "NOC_ACTION";
    
    private static final String HOLD_ACTION = "HOLD";
    
    private static final String ACTIVE_NOC = "ACTIVE_NOC";
    
    private boolean isNocSuccess = false;
    
    

	protected void createNocRecord(User user, Map params) throws Exception {

		String entityType = (String) params.get(ENTITY_TYPE);
		String entityDisplayName = (String) params.get(ENTITY_DISPLAY_NAME);

		boolean isActiveNoc = isActiveNocExists(user, entityType, entityDisplayName);

		if (!isActiveNoc) {
			setupNewNocRecord(user, entityType, entityDisplayName);
		}
		
		params.put(ACTIVE_NOC, String.valueOf(isActiveNoc));

	}

	private void setupNewNocRecord(User user, String entityType, String entityDisplayName) throws Exception {

		int recordCount = 0;
		boolean recordExist = false;

		try (Connection conn = ConnectionPool.getConnection(user);
				PreparedStatement stmt = conn.prepareStatement("select count(1) ACTIVE_RECORD \r\n"
						+ "    from PI_MIS_HOLD_RELEASE where PMHR_ENTITY_TYPE = ? \r\n"
						+ "    and PMHR_POLICY_NUMBER = ? and PMHR_IS_RELEASED is null")) {

			stmt.setString(1, entityType);
			stmt.setString(2, entityDisplayName);
			try (ResultSet rs = stmt.executeQuery()) {
				if (rs.next()) {
					recordCount = rs.getInt("ACTIVE_RECORD");
					recordExist = recordCount == 1;
				}
    }
    
		} catch (NamingException | SQLException e) {
			e.printStackTrace();
			throw e;
		}
            
		if (!recordExist) {
            Connection conn            = null;
            CallableStatement callStmt = null;
            
			try {
            
				conn = ConnectionPool.getConnection(user);
				conn.setAutoCommit(false);
            
				callStmt = conn.prepareCall("{? = call k_hold_release_management.f_insert_noc_hold_data(?, ?, ?, ?) }");

				callStmt.registerOutParameter(1, Types.BIGINT);

				callStmt.setString(2, entityType);
				callStmt.setString(3, entityDisplayName);
				callStmt.setString(4, user.getFullName());
				callStmt.registerOutParameter(5, Types.VARCHAR);
				callStmt.execute();

				long errorCode = callStmt.getLong(1);
				if (errorCode != 0) {
					String errorMessage = callStmt.getString(5);
					throw JDBCException.getExceptionFor(errorCode, errorMessage);
            }
            
				conn.commit();
			} catch (Exception ex) {
				if (ex instanceof JDBCException && ((JDBCException) ex).getSeverity() == JDBCException.FATAL) {
					LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "setupNewNocRecord",
							ServletConfigUtil.COMPONENT_PORTAL, new Object[] {},
							"Error in saving a new Hold and Object." + ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
				} else {
					LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO, getClass().getName(), "setupNewNocRecord",
							ServletConfigUtil.COMPONENT_PORTAL, new Object[] {},
							"Error in saving a new Hold and Object." + ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
				}
				try {
					conn.rollback();
				} catch (Exception e) {
					LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "setupNewNocRecord",
							ServletConfigUtil.COMPONENT_PORTAL, new Object[] {},
							"Error in rolling back." + ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
				}
				throw ex;
			} finally {
				try {
					DBUtil.close(null, callStmt, conn);
				} catch (Exception ex) {
					LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "setupNewNocRecord",
							ServletConfigUtil.COMPONENT_PORTAL, new Object[] {},
							"Error in closing DB connection while saving a new Hold and Release." + ex.getMessage(), ex,
							LogMinderDOMUtil.VALUE_MIC);
				}
			}
            }
            
	}
            
	private boolean isActiveNocExists(User user, String entityType, String entityDisplayName) throws Exception {
            
		boolean isActiveNoc = false;
		int recordCount = 0;
            
		try (Connection conn = ConnectionPool.getConnection(user);
				PreparedStatement stmt = conn.prepareStatement("select count(1) ACTIVE_RECORD \r\n"
						+ "    from PI_MIS_HOLD_RELEASE \r\n" + "    where PMHR_ENTITY_TYPE = ? \r\n"
						+ "    and PMHR_POLICY_NUMBER = ? \r\n" + "    and PMHR_IS_RELEASED = 'N'")) {
            
			stmt.setString(1, entityType);
			stmt.setString(2, entityDisplayName);
			try (ResultSet rs = stmt.executeQuery()) {
				if (rs.next()) {
					recordCount = rs.getInt("ACTIVE_RECORD");
					isActiveNoc = recordCount == 1;
				}
			}
            
		} catch (NamingException | SQLException e) {
			e.printStackTrace();
			throw e;
		}
            
		if (isActiveNoc) {
			String currentReleaseDateStr = null;
			int pmhrId = 0;
			try (Connection conn = ConnectionPool.getConnection(user);
					PreparedStatement stmt = conn.prepareStatement("select PMHR_RELEASE_DATE, \r\n" + "    PMHR_ID \r\n"
							+ "    from PI_MIS_HOLD_RELEASE \r\n" + "    where PMHR_ENTITY_TYPE = ? \r\n"
							+ "    and PMHR_POLICY_NUMBER = ? \r\n" + "    and PMHR_IS_RELEASED = 'N'")) {
            
				stmt.setString(1, entityType);
				stmt.setString(2, entityDisplayName);
				try (ResultSet rs = stmt.executeQuery()) {
					if (rs.next()) {
						currentReleaseDateStr = rs.getString("PMHR_RELEASE_DATE");
						pmhrId = rs.getInt("PMHR_ID");
					}
				}

			} catch (NamingException | SQLException e) {
				e.printStackTrace();
				throw e;
			}

			Date currentReleaseDate = null;
			SimpleDateFormat parseDateFormat = new SimpleDateFormat("yyyy-MM-dd");

			if (currentReleaseDateStr != null && !currentReleaseDateStr.equals("")) {
				currentReleaseDate = new java.sql.Date(parseDateFormat.parse(currentReleaseDateStr).getTime());
			}

			Calendar currentCal = Calendar.getInstance();
			currentCal.set(Calendar.HOUR_OF_DAY,0);
			currentCal.set(Calendar.MINUTE,0);
			currentCal.set(Calendar.SECOND,0);
			currentCal.set(Calendar.MILLISECOND,0);
            
			Date currentDate = new Date(currentCal.getTime().getTime());
            	
			if (currentDate.equals(currentReleaseDate) || currentDate.after(currentReleaseDate)) {

				markRelease(user, pmhrId);
				isActiveNoc = false;
			}
		}

		return isActiveNoc;

	}

	private void markRelease(User user, int pmhrId) throws Exception {

		Connection conn = null;
		CallableStatement callStmt = null;

		try {
            	
                conn = ConnectionPool.getConnection(user);
                conn.setAutoCommit(false);

			callStmt = conn.prepareCall("{? = call k_hold_release_management.f_mark_release(?, ?, ?, ?) }");
                
                callStmt.registerOutParameter(1, Types.BIGINT);

			callStmt.setInt(2, pmhrId);
			callStmt.setString(3, "Y");
			callStmt.setString(4, user.getFullName());
			callStmt.registerOutParameter(5, Types.VARCHAR);
                callStmt.execute();
                
                long errorCode = callStmt.getLong(1);
                if (errorCode != 0) {
				String errorMessage = callStmt.getString(5);
                    throw JDBCException.getExceptionFor(errorCode, errorMessage);
                }

                conn.commit();
		} catch (Exception ex) {
			if (ex instanceof JDBCException && ((JDBCException) ex).getSeverity() == JDBCException.FATAL) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "markRelease",
						ServletConfigUtil.COMPONENT_PORTAL, new Object[] {},
						"Error in saving a new Hold and Object." + ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
			} else {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO, getClass().getName(), "markRelease",
						ServletConfigUtil.COMPONENT_PORTAL, new Object[] {},
						"Error in saving a new Hold and Object." + ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
                }
			try {
                    conn.rollback();
			} catch (Exception e) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "markRelease",
						ServletConfigUtil.COMPONENT_PORTAL, new Object[] {}, "Error in rolling back." + ex.getMessage(),
                                                 ex, LogMinderDOMUtil.VALUE_MIC);
                }
                throw ex;
		} finally {
			try {
                    DBUtil.close(null, callStmt, conn);
			} catch (Exception ex) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "markRelease",
						ServletConfigUtil.COMPONENT_PORTAL, new Object[] {},
						"Error in closing DB connection while saving a new Hold and Release." + ex.getMessage(), ex,
						LogMinderDOMUtil.VALUE_MIC);
                }
            }
            
        }
	
		private void markReleaseImmediately(User user, int pmhrId) throws Exception {

		Connection conn = null;
		CallableStatement callStmt = null;

		try {
            	
                conn = ConnectionPool.getConnection(user);
                conn.setAutoCommit(false);

			callStmt = conn.prepareCall("{? = call k_hold_release_management.f_mark_release_immediately(?, ?, ?, ?) }");
                
                callStmt.registerOutParameter(1, Types.BIGINT);

			callStmt.setInt(2, pmhrId);
			callStmt.setString(3, "Y");
			callStmt.setString(4, user.getFullName());
			callStmt.registerOutParameter(5, Types.VARCHAR);
                callStmt.execute();
                
                long errorCode = callStmt.getLong(1);
                if (errorCode != 0) {
				String errorMessage = callStmt.getString(5);
                    throw JDBCException.getExceptionFor(errorCode, errorMessage);
                }

                conn.commit();
		} catch (Exception ex) {
			if (ex instanceof JDBCException && ((JDBCException) ex).getSeverity() == JDBCException.FATAL) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "markRelease",
						ServletConfigUtil.COMPONENT_PORTAL, new Object[] {},
						"Error in saving a new Hold and Object." + ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
			} else {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO, getClass().getName(), "markRelease",
						ServletConfigUtil.COMPONENT_PORTAL, new Object[] {},
						"Error in saving a new Hold and Object." + ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
                }
			try {
                    conn.rollback();
			} catch (Exception e) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "markRelease",
						ServletConfigUtil.COMPONENT_PORTAL, new Object[] {}, "Error in rolling back." + ex.getMessage(),
                                                 ex, LogMinderDOMUtil.VALUE_MIC);
                }
                throw ex;
		} finally {
			try {
                    DBUtil.close(null, callStmt, conn);
			} catch (Exception ex) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "markRelease",
						ServletConfigUtil.COMPONENT_PORTAL, new Object[] {},
						"Error in closing DB connection while saving a new Hold and Release." + ex.getMessage(), ex,
						LogMinderDOMUtil.VALUE_MIC);
                }
            }
            
        }

        private String getEffectiveDate(User user, String entityReference) throws NamingException, SQLException {

		String effectiveDate = null;
		
		try (Connection conn = ConnectionPool.getConnection(user);
				PreparedStatement stmt = conn.prepareStatement(
						"select effective_date from VW_MIS_QUOTE_POLICIES " + "where ENTITY_REFERENCE = ?")) {
			
			stmt.setString(1, entityReference);
			try (ResultSet rs = stmt.executeQuery()) {
				if (rs.next()) {
					effectiveDate = rs.getString("effective_date");
				}
			}
			
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
		
		return effectiveDate;
        
	}
    
        private String getSourceSystemCode(User user) throws NamingException, SQLException {
    		// TODO Auto-generated method stub
    		String billingSysMappingName = null;
    		
		try (Connection conn = ConnectionPool.getConnection(user);
				PreparedStatement stmt = conn
						.prepareStatement("select BILLING_SYS_MAPPING_NAME from IEL_MIC_BILL_MAPPING"
    							+ " where INTG_SERVICE_NAME = 'PREMIUM_INTERFACE'"
								+ " and INTG_MODULE_NAME = 'SOURCE_SYSTEM'" + " and PAS_SYS_FIELD_NAME = 'MIC'")) {
    			
			try (ResultSet rs = stmt.executeQuery()) {
				if (rs.next()) {
    					billingSysMappingName = rs.getString("BILLING_SYS_MAPPING_NAME");
    				}
    			}
    			
    		} catch (NamingException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    			throw e;
    		} catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    			throw e;
    		}
    		
    		return billingSysMappingName;
            
    	}
        
		/**
         * Used to update a Hold And Release
	 * 
         * @param user
         * @param params
         */
        protected void updateObjectData(User user, Map params) throws Exception {

		NocHoldReleaseClient holdReleaseClient = new NocHoldReleaseClient();

            String holdReason = (String) params.get(PMHR_HOLD_REASON);
            String pireleaseDate = (String) params.get(PMHR_RELEASE_DATE);
            String entityReference = (String) params.get(ENTITY_REFERENCE);
            String entityDisplayName = (String) params.get(ENTITY_DISPLAY_NAME);
			String nocAction = (String) params.get(NOC_ACTION);
			String pmhrId = (String) params.get(PMHR_ID);
			boolean isHoldCall = false;
			Date releaseDate = null;
			String effectiveDate = null;
        
            SimpleDateFormat parseDateFormat = new SimpleDateFormat(SIMPLE_DATE_FORMAT);

		if (pireleaseDate != null && !pireleaseDate.equals("")) {
            	releaseDate = new java.sql.Date(parseDateFormat.parse(pireleaseDate).getTime());
            }
            
		String pieffectiveDate = getEffectiveDate(user, entityReference);
		if (pieffectiveDate != null && !pieffectiveDate.equals("")) {
            	effectiveDate = new java.sql.Date(parseDateFormat.parse(pieffectiveDate).getTime()).toString();
            }
            
		String sourceSystemCode = getSourceSystemCode(user);
		String uuid = StringUtils.right(UUID.randomUUID().toString(), 29);
            
            NocHoldRequestObj requestObj = new NocHoldRequestObj();

            requestObj.setRequestDate(new java.util.Date());
            requestObj.setSourceSystemRequestNo(uuid);
            requestObj.setSourceSystemCode(sourceSystemCode);
            requestObj.setSourceSystemUserId(user.getFullName());
            requestObj.setSourceSystemUserName(user.getUserId());
            requestObj.setHoldTypeCode("NOC");

		if (HOLD_ACTION.equalsIgnoreCase(nocAction)) {
			isHoldCall = true;
		} else {
			
			Calendar currentCal = Calendar.getInstance();
			currentCal.set(Calendar.HOUR_OF_DAY,0);
			currentCal.set(Calendar.MINUTE,0);
			currentCal.set(Calendar.SECOND,0);
			currentCal.set(Calendar.MILLISECOND,0);
            
			Date currentDate = new Date(currentCal.getTime().getTime());
			isHoldCall = releaseDate.after(currentDate);
		}

		if (isHoldCall) {

			requestObj.setReasonCode(holdReason);
            requestObj.setReleaseDate(releaseDate);
            
			holdReleaseClient.hold(requestObj, user, entityDisplayName, effectiveDate);
			updateHoldNocData(user, pmhrId, requestObj);

		} else {
            holdReleaseClient.release(requestObj, user, entityDisplayName, effectiveDate);
            markReleaseImmediately(user, Integer.parseInt(pmhrId));
		}
		
		isNocSuccess = true;
		
	}

	private void updateHoldNocData(User user, String pmhrId, NocHoldRequestObj requestObj) throws Exception {

		Connection conn = null;
		CallableStatement callStmt = null;
            
            try {
			// get the connection object
                conn = ConnectionPool.getConnection(user);
                conn.setAutoCommit(false);

                callStmt = conn
                        .prepareCall("{? = call k_hold_release_management.f_update_hold_release_data(?, ?, ?, ?, ?, ?) }");

                callStmt.registerOutParameter(1, Types.BIGINT);

			callStmt.setString(2, pmhrId);
			callStmt.setString(3, requestObj.getReasonCode());
			callStmt.setDate(4, new Date(requestObj.getReleaseDate().getTime()));
			callStmt.setString(5, "N");
                callStmt.setString(6, user.getFullName());
                callStmt.registerOutParameter(7, Types.VARCHAR);
                callStmt.execute();

                long errorCode = callStmt.getLong(1);
                if (errorCode != 0) {
                    String errorMessage = callStmt.getString(7);
                    throw JDBCException.getExceptionFor(errorCode, errorMessage);
                }

                conn.commit();
		} catch (Exception ex) {
			if (ex instanceof JDBCException && ((JDBCException) ex).getSeverity() == JDBCException.FATAL) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "updateHoldNocData",
						ServletConfigUtil.COMPONENT_PORTAL, new Object[] { "pmhrId=" + pmhrId, requestObj },
						"Error in saving a new Hold and Object." + ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
			} else {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO, getClass().getName(), "updateHoldNocData",
						ServletConfigUtil.COMPONENT_PORTAL, new Object[] { "pmhrId=" + pmhrId, requestObj },
						"Error in saving a new Hold and Object." + ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
                }
			try {
                    conn.rollback();
			} catch (Exception e) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "updateHoldNocData",
						ServletConfigUtil.COMPONENT_PORTAL, new Object[] { "pmhrId=" + pmhrId, requestObj },
						"Error in rolling back." + ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
                }
                throw ex;
		} finally {
			try {
                    DBUtil.close(null, callStmt, conn);
			} catch (Exception ex) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "updateHoldNocData",
						ServletConfigUtil.COMPONENT_PORTAL, new Object[] { "pmhrId=" + pmhrId, requestObj },
						"Error in closing DB connection while saving a new Hold and Release." + ex.getMessage(), ex,
						LogMinderDOMUtil.VALUE_MIC);
            }
        }

       }
	
	@Override
	public String getDataHtmlX(String userName, String password, Map params, 
            StringHolder count) throws Exception
            {
					 try {
			            User user = new User(userName, password);
			            params = getParameters(user, params);
			            
			            isNocSuccess = false;
		
			            String stage = (String)params.get(HTTPConstants.PARAM_STAGE);
			            String action = 
			                (String)params.get(HTTPConstants.PARAM_USER_ACTION);
		
			            boolean ignoreComplete = 
			                "Y".equalsIgnoreCase((String)params.get(HTTPConstants.PARAM_IGNORE_COMPLETE_STAGE));
		
			            if ((ignoreComplete || 
			                 !HTTPConstants.PARAM_COMPLETE_STAGE.equalsIgnoreCase(stage)) || 
			                HTTPConstants.PARAM_RESTART_ACTION.equalsIgnoreCase((String)params.get(HTTPConstants.PARAM_USER_ACTION)) || 
			                HTTPConstants.PARAM_IN_PROGRESS_ACTION.equalsIgnoreCase((String)params.get(HTTPConstants.PARAM_USER_ACTION)) ||
			                HTTPConstants.PARAM_RERUN_ACTION.equalsIgnoreCase(action)||
			                HTTPConstants.PARAM_MODIFY_ACTION.equalsIgnoreCase((String)params.get(HTTPConstants.PARAM_USER_ACTION))) {
			                processRequest(user, params);
			            }
		
			            String html = "";
		
			            if (!(action != null && 
			                  ACTION_DELETE_ALL.equalsIgnoreCase(action))) {
		
			                String customerCode = 
			                    CustomerConfigUtil.getInstance().getCustomerCode(user.getDomain());
		
			                params.put(HTTPConstants.PARAM_CUSTOMER_CODE, customerCode);
		
			                count.value = getCount(user, params);
			                params.put(PARAM_RECORD_COUNT, count.value);
		
			                //Folder object portlet id
			                String portletId = (String)params.get("_portletId");
		
			                //Form for ws methods usage
			                html = 
			"<span style=\"display:none\"><FORM id=\"" + portletId + "Form\" name=\"" + 
			 portletId + "Form\" action=\"/mic/portal/servlet/FolderServlet\">";
		
			                Set keys = params.keySet();
			                Iterator iterator = keys.iterator();
			                
			                while (iterator.hasNext()) {
			                    String parameterName = (String)iterator.next();
		
			                    String parameterValue = (String)params.get(parameterName);
			                    if (!parameterName.startsWith("PMHR_")) {
				                    html += 
				                            ("\n<INPUT id=\"" + parameterName + "\" name=\"" + parameterName + 
				                             "\" value=\"" + parameterValue + 
				                             "\" type=\"hidden\"/>");
			                    }
			                }
		
			                html += "\n</FORM>\n</span>";
			                
			                if(isNocSuccess) {
			                	html += "<span type=\"script\">alert('" + 
			        	                "Transaction saved successfully."+ "');</span>";
			                }
		
			                action = (String)params.get(HTTPConstants.PARAM_USER_ACTION);
		
			                if ((action == null) || action.equalsIgnoreCase(ACTION_LIST)) {
			                	createNocRecord(user, params);
			                    html += getListHtml(user, params);
			                } else if (ACTION_CUSTOMIZE.equalsIgnoreCase(action)) {
			                    html += getCustomizationHtml(user, params);
			                } else if (ACTION_REFRESH.equalsIgnoreCase(action)) {
			                    String entityType = 
			                        "document.forms['folderToolbarForm']." + 
			                        HTTPConstants.PARAM_ENTITY_TYPE + ".value ";
			                    String entityReference = 
			                        "document.forms['folderToolbarForm']." + 
			                        HTTPConstants.PARAM_ENTITY_REFERENCE + ".value ";
			                    String entityDisplayName = 
			                        "document.forms['folderToolbarForm']." + 
			                        HTTPConstants.PARAM_ENTITY_DISPLAY_NAME + ".value ";
			                    html = 
			"<span type=\"script\">javascript:getDashboard(" + entityType + ", " + 
			 entityReference + ", " + entityDisplayName + ");</span>";
			                } else {
			                    html += getEditHtml(user, params);
			                }
			            }
			            return html;
			        } catch (FolderException fe) {
	            throw fe;
	        } catch (Throwable error) {
	            int sevirity = LogEntry.SEVERITY_FATAL;
	            if (error instanceof ExceptionImpl && 
	                ((ExceptionImpl)error).getSeverity() == 
	                ExceptionImpl.NON_FATAL) {
	                sevirity = LogEntry.SEVERITY_INFO;
	            }
	            LogMinder.getLogMinder().log(sevirity, getClass().getName(), 
	                                         "getDataHTML", 
	                                         ServletConfigUtil.COMPONENT_FRAMEWORK, 
	                                         new Object[] { userName, params }, 
	                                         "Error generating HTML to display in folder's tab.", 
	                                         error, LogMinderDOMUtil.VALUE_MIC);

	            return "<span type=\"script\">alert('" + 
	                error.getMessage().replaceAll("\'", "`") + "');</span>";
	        }
		 		
            }
}
