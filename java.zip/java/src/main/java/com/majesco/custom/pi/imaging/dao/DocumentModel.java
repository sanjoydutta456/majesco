/*
 *                 Majesco Code License Notice
 *
 * The contents of this file are subject to the Majesco Code License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License
 *
 * The Original Code is for My Insurance Center. The Initial Developer
 * of the Original Code is Majesco, All Rights Reserved.
 */

package com.majesco.custom.pi.imaging.dao;

import java.sql.*;

/**
 * DOCUMENT ME!
 *
 * @author $Author:   vincent  $
 * @version $Revision:   1.9  $
 */
public class DocumentModel implements SQLData {
    public static final String FORM = "form";
    public static final String DOCUMENT = "document";
    public static final String WORD_NEW = "wordNew";
    private String sql_type;
    private String documentType;
    private long documentId;
    private String documentName;
    private String coveragePart;
    private String userOverride;
    private String editionDate;
    private String entityType;
    private long documentOccurrence = 0;
    private String include;
    private String wordFormat;

    public DocumentModel() {
    }

    public DocumentModel(String sql_type, String documentType,
                         long documentId, String documentName, 
                         String coveragePart, String userOverride, 
                         String editionDate, String entityType,
                         long documentOccurrence,String include) {
        this.sql_type = sql_type;
        this.documentType = documentType;
        this.documentId = documentId;
        this.documentName = documentName;
        this.coveragePart = coveragePart;
        this.userOverride = userOverride;
        this.editionDate = editionDate;
        this.entityType = entityType;
        this.documentOccurrence = documentOccurrence;
        this.include = include;
    }
    
	public DocumentModel(String sql_type, String documentType, long documentId,
			String documentName, String coveragePart, String userOverride,
			String editionDate, String entityType, long documentOccurrence,
			String include, String wordFormat) {
		this.sql_type = sql_type;
		this.documentType = documentType;
		this.documentId = documentId;
		this.documentName = documentName;
		this.coveragePart = coveragePart;
		this.userOverride = userOverride;
		this.editionDate = editionDate;
		this.entityType = entityType;
		this.documentOccurrence = documentOccurrence;
		this.include = include;
		this.wordFormat = wordFormat;
	}

    /* implements SQLData */
    // define a get method to return the SQL type of the object 

    public String getSQLTypeName() throws SQLException {
        return sql_type;
    }

    // define the required readSQL() method                   

    public void readSQL(SQLInput stream, String typeName) throws SQLException {
        sql_type = typeName;
        documentType = stream.readString();
        documentId = stream.readLong();
        documentName = stream.readString();
        coveragePart = stream.readString();
        userOverride = stream.readString();
        editionDate = stream.readString();
        entityType = stream.readString();
        documentOccurrence = stream.readLong();
        include = stream.readString();
        wordFormat = stream.readString();
    }

    // define the required writeSQL() method                     

    public void writeSQL(SQLOutput stream) throws SQLException {
        stream.writeLong(documentId);
        stream.writeString(documentType);
        stream.writeString(documentName);
        stream.writeString(coveragePart);
        stream.writeString(userOverride);
        stream.writeString(editionDate);
        stream.writeString(entityType);
        stream.writeLong(documentOccurrence);
        stream.writeString(include);
        stream.writeString(wordFormat);
    }

    public void setDocumentId(long documentId) {
        this.documentId = documentId;
    }

    public long getDocumentId() {
        return documentId;
    }

    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }

    public String getDocumentName() {
        return documentName;
    }

    public void setCoveragePart(String coveragePart) {
        this.coveragePart = coveragePart;
    }

    public String getCoveragePart() {
        return coveragePart;
    }

    public void setUserOverride(String userOverride) {
        this.userOverride = userOverride;
    }

    public String getUserOverride() {
        return userOverride;
    }

    public void setEditionDate(String editionDate) {
        this.editionDate = editionDate;
    }

    public String getEditionDate() {
        return editionDate;
    }

    public void setEntityType(String entityType) {
        this.entityType = entityType;
    }

    public String getEntityType() {
        return entityType;
    }


    public String toString() {
        return  " entityType = " + entityType + 
                " documentId = " + documentId + 
                " documentType = " + documentType +
                " documentName = " + documentName + 
                " sql_type = " + sql_type + 
                " coveragePart = " + coveragePart + 
                " userOverride = " + userOverride + 
                " editionDate = " + editionDate +
                " documentOccurrence = " + documentOccurrence +
                " include = " + include +
                " wordFormat = " + wordFormat;
    }

    public void setDocumentOccurrence(long documentOccurrence) {
        this.documentOccurrence = documentOccurrence;
    }

    public long getDocumentOccurrence() {
        return documentOccurrence;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setInclude(String include) {
        this.include = include;
    }

    public String getInclude() {
        return include;
    }

	public String getWordFormat() {
		return wordFormat;
	}

	public void setWordFormat(String wordFormat) {
		this.wordFormat = wordFormat;
	}
}

