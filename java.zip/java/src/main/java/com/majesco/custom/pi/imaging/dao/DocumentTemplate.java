package com.majesco.custom.pi.imaging.dao;

import com.coverall.mt.http.HTTPConstants;
import com.coverall.mt.http.User;
import com.coverall.mt.mailmerge.MailMerge;
import com.coverall.mt.mailmerge.MailMergeException;
import com.coverall.mt.pl.step.impl.StepLogUtil;
import com.coverall.mt.pl.step.impl.StepLogUtility;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.ServicesDOMUtil;
import com.coverall.util.DBUtil;
import com.coverall.util.FileUtil;
import com.coverall.util.PDFUtil;
import com.majesco.custom.pi.dao.AbstractDAO;
import com.majesco.custom.pi.imaging.dao.DocumentModel;
import com.majesco.custom.pi.imaging.soa.filecabinet.dao.FileCabinetAssociation;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.Serializable;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class DocumentTemplate extends AbstractDAO implements Serializable {

    public static final List COLUMNS = new ArrayList();

    /** The template id db column name constant*/
    public static final String PDT_ID = "PDT_ID";

    /** The document id db column name constant*/
    public static final String PDT_DOCUMENT_ID = "PDT_DOCUMENT_ID";

    /** The template name db column name constant*/
    public static final String PDT_NAME = "PDT_NAME";

    /** The template description db column name constant*/
    public static final String PDT_DESCRIPTION = "PDT_DESCRIPTION";

    /** The template MIME Type db column name constant*/
    public static final String PDT_MIME_TYPE = "PDT_MIME_TYPE";

    /** The template is form db column name constant*/
    public static final String PDT_IS_FORM = "PDT_IS_FORM";

    /** The template is form db column name constant*/
    public static final String PDT_IS_MANUSCRIPT = "PDT_IS_MANUSCRIPT";

    /** The template is form db column name constant*/
    public static final String PDT_IS_STATIC = "PDT_IS_STATIC";

    /** The user modified db column name constant*/
    public static final String PDT_USER_MODIFIED = "DSR_USER_MODIFIED";

    /** The template file path db column name constant*/
    private static final String MFF_FILE_PATH = "MFF_FILE_PATH";

    /** The template file path db column name constant*/
    private static final String MFF_FILE_NAME = "MFF_FILE_NAME";

    /** The template file path db column name constant*/
    private static final String PDT_IS_MIC_DOCUMENT = "PDT_IS_MIC_DOCUMENT";

    /** The template edition date db column name constant*/
    public static final String PDT_EDITION_DATE = "PDT_EDITION_DATE";

    /** The template state code db column name constant*/
    public static final String PDT_STATE_CODE = "PDT_STATE_CODE";

    /** The template customer code db column name constant*/
    public static final String PDT_CUSTOMER_CODE = "DSR_RESOURCE_OWNER";

    /** The template revision db column name constant*/
    public static final String PDT_REVISION = "PDT_REVISION";

    /** The template revision db column name constant*/
    public static final String PDT_IS_INTERLINE = "PDT_IS_INTERLINE";

    /** The template revision db column name constant*/
    //public static final String PDT_DOC_TYPE = "PDT_DOC_TYPE";

    /** The Manage parameter constant*/
    private static final String PARAM_MANAGE = "Manage";

    /** The Use parameter constant*/
    private static final String PARAM_USE = "Use";

    /** The None parameter constant*/
    private static final String PARAM_NONE = "None";

    private String tempFilePath = null;

    private File templateDownloadFile = null;
    
    private long templateDownloadFileSize;
    
    private File mergedDocument = null;
    
    private long occurrence = 0;

    private boolean hasSupplemental = true;
    
    private DocumentModel documentModel;


    /** Query for inserting template to the DB */
    private static final String QUERY_INSERT_TEMPLATE =
        "K_DOCUMENT_TEMPLATE_MANAGEMENT.f_add_template";

    /** Query for updating template from DB */
    private static final String QUERY_UPDATE_TEMPLATE =
        "K_DOCUMENT_TEMPLATE_MANAGEMENT.f_mod_template";

    /** Query for updating template from DB */
    private static final String QUERY_DELETE_TEMPLATE =
        "K_DOCUMENT_TEMPLATE_MANAGEMENT.f_del_template";

	/* Changes not done for same name document as query is based on PDT_ID */
    /** Query for selecting template data from DB */
    private static final String QUERY_SELECT_TEMPLATE =
        "SELECT * FROM PS_DOCUMENT_TEMPLATE, DS_RESOURCE WHERE DSR_GID = PDT_ID AND DSR_DATE_DELETED IS NULL AND PDT_ID=?";

    /** Query for getting folderId based upon entityreference*/
    private static final String QUERY_GET_FOLDER_ID =
        "SELECT FOB_FOLDER_OBJECT_ID FROM FOM_FOLDER_OBJECTS ,FOM_ENTITY_FOLDERS " +
        "WHERE FOB_FOLDER_ID = FEF_FOLDER_ID " +
        "AND FEF_ENTITY_TYPE = 'DOCUMENT TEMPLATE' " +
        "AND FOB_OBJECT_NAME = 'Template' " + "AND FEF_ENTITY_REFERENCE = ? ";

    private static final String SUPPLEMENT = "_SUPPLEMENT";

    public static final String PDT_WORD_FORMAT  = "PDT_WORD_FORMAT";
    
    /**default constructor */
    public DocumentTemplate() {
    }

    static {
        COLUMNS.add(PDT_ID);
        COLUMNS.add(PDT_DOCUMENT_ID);
        COLUMNS.add(PDT_NAME);
        COLUMNS.add(PDT_DESCRIPTION);
        COLUMNS.add(PDT_MIME_TYPE);
        COLUMNS.add(PDT_IS_FORM);
        COLUMNS.add(PDT_IS_MANUSCRIPT);
        COLUMNS.add(PDT_IS_STATIC);
        COLUMNS.add(PDT_IS_MIC_DOCUMENT);
        COLUMNS.add(PDT_EDITION_DATE);
        COLUMNS.add(PDT_STATE_CODE);
        COLUMNS.add(PDT_CUSTOMER_CODE);
        COLUMNS.add(PDT_REVISION);
        COLUMNS.add(PDT_IS_INTERLINE);
        COLUMNS.add(PDT_WORD_FORMAT);
        COLUMNS.add(PDT_USER_MODIFIED);
    }

    /**
     * Returns the PL/SQL Function name which will be used to insert a new template
     * @return the PL/SQL Function name which will be used to insert a new template
     * @throws Exception if any error occurs while processing
     */
    public String getInsertProcedure() throws Exception {
        return QUERY_INSERT_TEMPLATE;
    }

    /**
     * Returns the PL/SQL Function name which will be used to update a template
     * @return the PL/SQL Function name which will be used to update a template
     * @throws Exception if any error occurs while processing
     */
    public String getUpdateProcedure() throws Exception {
        return QUERY_UPDATE_TEMPLATE;
    }

    /**
     * Returns the PL/SQL Function name which will be used to delete a template
     * @return the PL/SQL Function name which will be used to delete a template
     * @throws Exception if any error occurs while processing
     */
    public String getDeleteProcedure() throws Exception {
        return QUERY_DELETE_TEMPLATE;
    }

    /**
     * Returns the SQL query to load all the data about this entity
     * @return the SQL query to load the data
     * @throws Exception if any error occurs while processing
     */
    public String getSelectQuery() throws Exception {
        return QUERY_SELECT_TEMPLATE;
    }

    /**
     * Returns the list of colums which should be used while inserting, updating or deleting a template
     * @return the list of colums which should be used while inserting, updating or deleting a template
     */
    public List getColumns() {
        return COLUMNS;
    }


    /**
     * deletes the file associated with the template from Sling,delets the entry from file Association
     * as well deletes the template from DB.
     * @param connection
     * @throws Exception
     */
    public void delete(Connection connection) throws Exception {

        try {
            /** Delete the file associated with the template.*/
            deleteFile(connection);
            /** Delete the template.*/
            super.delete(connection);
        } catch (Exception e) {
            connection.rollback();
            throw e;
        }
    }

    /**
     * deletes the file associated with the template from Sling,delets the entry from file Association
     * @throws Exception
     */
    public void deleteFile(Connection connection) throws Exception {
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int folderId = 0;
        String templateIdString = this.getValue(PDT_ID);
        try {
            pstmt = connection.prepareStatement(QUERY_GET_FOLDER_ID);
            pstmt.setString(1, templateIdString.trim());
            rs = pstmt.executeQuery();
            if (rs.next()) {
                folderId = rs.getInt("FOB_FOLDER_OBJECT_ID");
                try {
                    FileCabinetAssociation fileCabinetAssociation =
                        new FileCabinetAssociation();
                    fileCabinetAssociation.init(user, folderId);
                    if (fileCabinetAssociation.getFilePath() != null) {
                        fileCabinetAssociation.delete(user);
                    }
                } catch (Exception e) {
                    throw new Exception("You can not delete the Template as file is not associated with the Template");
                }
            }
        } catch (Exception e) {
            throw e;
        } finally {
            DBUtil.close(rs, pstmt);
        }
    }

    public void deleteLocalCopy() {
        if (mergedDocument != null) {
            if (mergedDocument.getParentFile().exists()) {
                FileUtil.delete(mergedDocument.getParentFile());
            }
        }

    }

    /**
     * gets the privilege type associated with the template for specific user.
     * @param user
     * @param objectId
     * @return Privilege String
     * @throws Exception
     */
    public static String getPrivilegeForUser(User user,
                                             int objectId) throws Exception {
        String priviledgeType = null;
        String priviledge =
            user.hasPrivileges(objectId, HTTPConstants.PARAM_DOCUMENT_TEMPLATE,
                               9);
        if ("Y".equalsIgnoreCase(priviledge)) {
            priviledgeType = PARAM_MANAGE;
        } else {
            priviledge =
                    user.hasPrivileges(objectId, HTTPConstants.PARAM_DOCUMENT_TEMPLATE,
                                       1);
            if ("Y".equalsIgnoreCase(priviledge)) {
                priviledgeType = PARAM_USE;
            } else {
                priviledgeType = PARAM_NONE;
            }
        }
        return priviledgeType;
    }

    /**
     * Returns the MIME Type of the template.
     * @return the MIME type
     * @throws Exception
     */
    public String getTemplateMIMEType() throws Exception {
        return (String)data.get(PDT_MIME_TYPE);
    }

    public String getTemplateWordFormat() throws Exception {
        return (String)data.get(PDT_WORD_FORMAT);
    }
    
    /**
     * Sets the path of the template file .
     * @param templatePath
     * @throws Exception
     * @return void
     */
    public void setTemplatePath(String templatePath) throws Exception {
        data.put(MFF_FILE_PATH, templatePath);
    }

    public void setFileName(String fileName) throws Exception {
        data.put(MFF_FILE_NAME, fileName);
    }

    public void setTemplateOccurrence(long occurrence) throws Exception {
        this.occurrence = occurrence;
    }

    public void setHasSupplemental(boolean hasSupplemental) {
    	this.hasSupplemental = hasSupplemental;
    }
    
    public void setTemplateDownloadFile(File templateDownloadFile) {
    	this.templateDownloadFile = templateDownloadFile;
    }
    
    public long getTemplateDownloadFileSize() {
    	return this.templateDownloadFileSize;
    }
    
    public void setDocumentModel(DocumentModel documentModel) {
    	this.documentModel = documentModel;
    }
    
    public DocumentModel getDocumentModel() {
    	return this.documentModel;
    }
    
    /**
     * Merges the template file and the entity data.
     * @param entityType
     * @param entityReference
     * @param user
     * @return the merged file
     * @throws MailMergeException
     */
    public File getMergedDocument(String entityType, String entityReference, long occurrence,
                                  User user,Connection conn) throws MailMergeException {	//Changes made for SR#64287. Added 'occurrence' parameter.
        String mimeType = (String)data.get(PDT_MIME_TYPE);
        String templateName = (String)data.get(PDT_NAME);
        String isStatic = (String)data.get(PDT_IS_STATIC);
               
        String level3UniqueId = null;
                      
        level3UniqueId = null;
        try {
        	
        	if(templateDownloadFile == null) {
        		templateDownloadFile = fetchDocument(user);
        	}
        	
            level3UniqueId = StepLogUtility.addLogLevel3Info("Merging Document", null);
            if("Y".equalsIgnoreCase(isStatic) && !hasSupplemental) {
            	mergedDocument = templateDownloadFile;
            } else {
            	mergedDocument =
                    MailMerge.merge(user, entityType, entityReference, mimeType, templateDownloadFile, templateName, occurrence,conn);
            }
        } finally {
           StepLogUtil.markLevel3ProcessingComplete(level3UniqueId);
           level3UniqueId = null;
        }
                      
        return mergedDocument;
    }

    /**
     * Merges the template file and the entity data.
     * @param entityType
     * @param entityReference
     * @param user
     * @return the merged file
     * @throws MailMergeException
     */
    public File fetchDocument(User user) throws MailMergeException {	//Changes made for SR#64287. Added 'occurrence' parameter.
        String templatePath = (String)data.get(MFF_FILE_PATH);
        String templateName = (String)data.get(PDT_NAME);
        String fileName = (String)data.get(MFF_FILE_NAME);
        
        FileCabinetAssociation fca = new FileCabinetAssociation();
        FileOutputStream fos = null;
        InputStream is = null;
        File tempFile = null;

        String level3UniqueId = null;
        try {
            level3UniqueId = StepLogUtility.addLogLevel3Info("Fetching document from sling", null);
            fca.fetchFileDataFromSling(user, templatePath);

            File tempDirectory = new File(tempFilePath);
            tempDirectory.mkdirs();

            if (occurrence > 0) {
                if(fileName != null && fileName.indexOf(SUPPLEMENT + ".") != -1) {
                	tempFile = new File(tempDirectory, templateName + SUPPLEMENT + "_" + occurrence + ".docx");
                } else {
                	tempFile = new File(tempDirectory, templateName + "_" + occurrence + ".docx");               
                }
            }else {
                tempFile = new File(tempDirectory, fileName);
            }

            fos = new FileOutputStream(tempFile);
            is = fca.getFileInputStream();

            FileUtil.streamCopy(is, fos);

            fos.flush();
            
            templateDownloadFileSize = tempFile.length();
        } catch (Throwable error) {
            throw new MailMergeException("Error getting document template " +
                                         (String)data.get(PDT_NAME) +
                                         " from Sling.", error);
        } finally {
            try {
                fos.close();
            } catch (Exception ex) {
                //Suppress
            }

            try {
                is.close();
            } catch (Exception ex) {
                //Suppress
            }
            
            StepLogUtil.markLevel3ProcessingComplete(level3UniqueId);
            level3UniqueId = null;
        }

        return tempFile;
    }
        
    
    public File getMergedDocument(String entityType, String entityReference,
            User user, Connection con) throws MailMergeException {
    	return getMergedDocument(entityType, entityReference, occurrence, user, con); //Changes made for SR#64287. Added 'occurrence' parameter.
    }
    
    public File getMergedDocument(String entityType, String entityReference,
            User user) throws MailMergeException {
    	return getMergedDocument(entityType, entityReference, occurrence, user);	//Changes made for SR#64287. Added 'occurrence' parameter.
    }
    
    // Changes made for SR#64287. Overloaded getMergedDocument() to pass occurrence parameter.
    
    public File getMergedDocument(String entityType, String entityReference, long occurrence,
            User user) throws MailMergeException {
    	return getMergedDocument(entityType, entityReference, occurrence, user, null);
    }
    /**
     * Merges the template file and the entity data.
     * @param entityType
     * @param entityReference
     * @param user
     * @return the merged file
     * @throws MailMergeException
     */
       public File getMergedPDF(String entityType, String entityReference,
                             User user) throws Exception {
        File convertedFile = null;
        mergedDocument = getMergedDocument(entityType, entityReference, user);
        if(null != mergedDocument) {
            convertedFile = PDFUtil.convertDocxToPDF(mergedDocument,mergedDocument.getParentFile());
        }
        return convertedFile;
    }


    public void setTempFilePath(String tempFilePath) {
        this.tempFilePath = tempFilePath;
    }

    public String getTempFilePath() {
        return tempFilePath;
    }

    public int getFileId(String fileName) {
        if(((fileName.toLowerCase()).indexOf(HTTPConstants.SUPPLEMENT_DOCX) > 0) ||
            ((fileName.toLowerCase()).indexOf(HTTPConstants.SUPPLEMENT_PDF) > 0)
            ) {
            return 2;  // file is supplement.
        } else if(((fileName.toLowerCase()).indexOf(HTTPConstants.SUPPLEMENT_DOCX) < 1) ||
            ((fileName.toLowerCase()).indexOf(HTTPConstants.SUPPLEMENT_PDF) < 1)) {
            return 1;  // File is main document
        }
        return 0;  //Take no action related to merge PDF.
    }

	
}
