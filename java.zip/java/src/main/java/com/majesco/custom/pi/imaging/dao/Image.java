package com.majesco.custom.pi.imaging.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.majesco.custom.pi.dao.AbstractDAO;

/**
 * This DAO class is use to initialize the parameter,insert,delete and update a
 * Image Entity.
 * 
 * @author $Author:   sagar  $
 * @version $Revision:   1.0  $
 */
public class Image extends AbstractDAO implements Serializable {
    private static final List COLUMNS = new ArrayList();

    /**
     * Primary key - Image Id
     */
    private static final String COL_NAME_MIM_ID = "PIG_ID";

    /**
     * Name of the Image
     */
    private static final String COL_NAME_MIM_NAME = "PIG_NAME";

    /**
     * Description
     */
    private static final String COL_NAME_MIM_DESCRIPTION = "PIG_DESCRIPTION";

    /**
     * Type
     */
    private static final String COL_NAME_MIM_TYPE = "PIG_TYPE";

    /**
     * Sub Type
     */
    private static final String COL_NAME_MIM_SUB_TYPE = "PIG_SUB_TYPE";

    /**
     * Width
     */
    private static final String COL_NAME_MIM_WIDTH = "PIG_WIDTH";

    /**
     * Height
     */
    private static final String COL_NAME_MIM_HEIGHT = "PIG_HEIGHT";

    /**
     * Horizontal DPI
     */
    private static final String COL_NAME_MIM_HORIZONTAL_DPI = "PIG_HORIZONTAL_DPI";

    /**
     * Vertical DPI
     */
    private static final String COL_NAME_MIM_VERTICAL_DPI = "PIG_VERTICAL_DPI";

    /**
     * Customer Code
     */
    private static final String COL_NAME_MIM_CUSTOMER_CODE = "DSR_RESOURCE_OWNER";

    /**
     * Image User Modified
     */
    private static final String COL_NAME_MIM_USER_MODIFIED = "DSR_USER_MODIFIED";
    
    /**
     * Query for inserting Image Entity to the DB
     */
    private static final String QUERY_INSERT_IMAGE = "k_image_management.f_add_image";

    /**
     * Query for updating Image Entity from DB
     */
    private static final String QUERY_UPDATE_IMAGE = "k_image_management.f_mod_image";

    /**
     * Query for deleting Image from DB
     */
    private static final String QUERY_DELETE_IMAGE = "k_image_management.f_del_image";
        
    /** Query for selecting Image data from DB */
    private static final String QUERY_SELECT_IMAGE = "SELECT * FROM PS_IMAGE,DS_RESOURCE WHERE DSR_GID = PIG_ID AND PIG_ID=?";
    
    static{
        COLUMNS.add(COL_NAME_MIM_ID);
        COLUMNS.add(COL_NAME_MIM_NAME);
        COLUMNS.add(COL_NAME_MIM_DESCRIPTION);
        COLUMNS.add(COL_NAME_MIM_TYPE);
        COLUMNS.add(COL_NAME_MIM_SUB_TYPE);
        COLUMNS.add(COL_NAME_MIM_WIDTH);
        COLUMNS.add(COL_NAME_MIM_HEIGHT);
        COLUMNS.add(COL_NAME_MIM_HORIZONTAL_DPI);
        COLUMNS.add(COL_NAME_MIM_VERTICAL_DPI);
        COLUMNS.add(COL_NAME_MIM_CUSTOMER_CODE); 
        COLUMNS.add(COL_NAME_MIM_USER_MODIFIED);
	}

    /**
     * Returns the PL/SQL Function name which will be used to insert a new Image
     * Entity
     * 
     * @return the PL/SQL Function name which will be used to insert a new Image
     *         Entity
     * @throws Exception
     *             if any error occurs while processing
     */
    public String getInsertProcedure() throws Exception {
        return QUERY_INSERT_IMAGE;
}

    /**
     * Returns the PL/SQL Function name which will be used to update a Image
     * Entity
     * 
     * @return the PL/SQL Function name which will be used to update a Image
     *         Entity
     * @throws Exception
     *             if any error occurs while processing
     */
    public String getUpdateProcedure() throws Exception {
        return QUERY_UPDATE_IMAGE;
    }

    /**
     * Returns the PL/SQL Function name which will be used to delete a Image
     * Entity
     * 
     * @return the PL/SQL Function name which will be used to delete a Image
     *         Entity
     * @throws Exception
     *             if any error occurs while processing
     */
    public String getDeleteProcedure() throws Exception {
        return QUERY_DELETE_IMAGE;
    }

    /**
     * Returns the SQL query to load all the data about this entity
     * 
     * @return the SQL query to load the data
     * @throws Exception
     *             if any error occurs while processing
     */
    public String getSelectQuery() throws Exception {
        return QUERY_SELECT_IMAGE;
    }
    
    /**
     * Returns the list of columns which should be used while inserting,
     * updating or deleting a Image Entity
     * 
     * @return the list of columns which should be used while inserting,
     *         updating or deleting a Image Entity
     */
    public List getColumns() {
        return new ArrayList(COLUMNS);
    }

    protected boolean isSaveSupported() {
        return true;
    }

}
