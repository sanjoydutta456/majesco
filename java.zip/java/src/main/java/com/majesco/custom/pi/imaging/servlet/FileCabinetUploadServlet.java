package com.majesco.custom.pi.imaging.servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Map;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.coverall.exceptions.MissingDataException;
import com.coverall.exceptions.TemplateFileUploadException;
import com.coverall.mt.cms.IDirectory;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.HTTPConstants;
import com.coverall.mt.http.User;
import com.coverall.mt.mailmerge.MailMerge;
import com.coverall.mt.servlet.MultipartRequestWrapper;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.DOMUtil;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;
import com.coverall.util.FileUtil;
import com.majesco.custom.pi.imaging.dao.DocumentTemplate;
import com.majesco.custom.pi.imaging.dao.Image;
import com.majesco.custom.pi.imaging.soa.filecabinet.dao.FileCabinetAssociation;


/**
 * This servlet is responsible for uploading files for the FileCabinetWebService.
 */
public class FileCabinetUploadServlet extends HttpServlet {
	
	private static final Logger logger = LoggerFactory.getLogger(FileCabinetUploadServlet.class.getClass());
			
    /** Constant to represent the portlet id parameter.*/
    public static final String PARAMETER_PORTLET_ID = "portletId";

    /** Constant to represent the error message parameter.*/
    public static final String PARAMETER_ERROR_MSG = "errorMsg";

    /** Constant to represent the Auto Refresh parameter.*/
    public static final String PARAMETER_AUTO_REFRESH = "autoRefresh";

    /** Constant to represent the jsp for displaying errors. */
    public static final String ERROR_JSP_PATH = "fileUpload.jsp";

    /** Constant for Temp Folder **/
    private static final String TEMP = "temp";

    /** Constant for Template Download Folder **/
    private static final String TEMPLATE_DOWNLOAD = "templateDownload";
    
    /** Constant for Request parameter Attachment Category **/
    private static final String REQUEST_ATTACHMENT_CATEGORY = "attachmentCategory";
    

    private static final Random randomizer = new Random();

    /**
     * Invokes doPost.
     * @param request - The request object
     * @param response - the response object to which the response will be written to
     * @throws ServletException - if any error occurs while processing
     * @throws IOException - if any error occurs while processing
     */
    public void doGet(HttpServletRequest request,
                      HttpServletResponse response) throws ServletException,
                                                           IOException {

        doPost(request, response);
    }

    /**
     * Retrieves the file from the request object and stores it in Sling.
     * Also inserts a record in the <code>MIS_FOLDER_OBJECTS_FILES_ASSN</code>
     * table.
     * @param request - The request object
     * @param response - the response object to which the response will be written to
     * @throws ServletException - if any error occurs while processing
     * @throws IOException - if any error occurs while processing
     */
    public void doPost(HttpServletRequest request,
                       HttpServletResponse response) throws ServletException,
                                                            IOException {

        User user = User.getUser(request);

        if (user == null) {
            String queryString = request.getQueryString();
            response.sendRedirect("/mic/imaging/index.jsp?" + queryString);
            return;
        }

        FileInputStream mergedFileIs = null;
        String micRiHome = "";
        File tempDirectory = null;

        try {
            String folderIdStr =
                request.getParameter(HTTPConstants.REQUEST_FOLDER_ID);
            String entityType =
                request.getParameter(HTTPConstants.REQUEST_ENTITY_TYPE);
            String entityReference =
                request.getParameter(HTTPConstants.REQUEST_ENTITY_REFERENCE);
            String userFileName =
                ((String)request.getParameter(HTTPConstants.REQUEST_FILE_NAME)).trim();
            logger.info("fileName :" + userFileName);
            String userAttachmentCategory = "";
            if (request.getParameter(REQUEST_ATTACHMENT_CATEGORY) != null) {
	            userAttachmentCategory =
	            		((String)request.getParameter(REQUEST_ATTACHMENT_CATEGORY)).trim();
            } 
            logger.info("fileAttachmentCategory :" + userAttachmentCategory);
            String userFileDescription =
                    ((String)request.getParameter(HTTPConstants.REQUEST_FILE_DESCRIPTION)).trim();
            logger.info("fileDescription :" + userFileDescription);
            String templateInfo =
                request.getParameter(HTTPConstants.REQUEST_TEMPLATE_INFO);
            
            String portletId = request.getParameter(PARAMETER_PORTLET_ID);
            String isSupplement = request.getParameter(HTTPConstants.IS_SUPPLEMENT);
            
            String userType = request.getParameter(HTTPConstants.REQUEST_USER_TYPE);
            
            Map fileItems =
                (Map)request.getAttribute(MultipartRequestWrapper.PARAM_NAME_FILE_ITEMS);
            
            String downloadBehaviour=request.getParameter("downloadBehaviour");

            String templateId = null;
            String templatePath = "";

            /* templateInfo is null when template dropdown is not visible.
             * templateInfo is of the form 'id~path' when template dropdown is visible and is selected.
             * templateInfo is '~' when template dropdown is visible but no template is selected.*/
            if (null != templateInfo && !"".equals(templateInfo)) {
                templateId =
                        templateInfo.substring(0, templateInfo.indexOf("~"));
                templatePath =
                        templateInfo.substring(templateInfo.indexOf("~") + 1,
                                               templateInfo.length());
            }

            validateMandatoryFields(folderIdStr, entityType, entityReference,
                                    portletId, userFileName, fileItems,
                                    templateId, user);

            long folderId = Long.parseLong(folderIdStr);

            String filePath =
                FileCabinetAssociation.FOLDER_NAME_FILE_CABINET + IDirectory.SEPARATOR +
                entityType + IDirectory.SEPARATOR + entityReference;
            ;

            FileCabinetAssociation fileCabAsso = new FileCabinetAssociation();
            fileCabAsso.setFolderObjectId(folderId);
            fileCabAsso.setFileName(userFileName);
            fileCabAsso.setFilePath(filePath);
            fileCabAsso.setUserCreated(user.getFullName());
            fileCabAsso.setEntityType(entityType);
            fileCabAsso.setEntityReference(entityReference);            
            fileCabAsso.setUserType(userType);    
            fileCabAsso.setFileDescription(userFileDescription);
            fileCabAsso.setAttachmentCategory(userAttachmentCategory);
            
            DocumentTemplate mtDAO = null;
            File tempFile = null;
            /* Create a folder to store all the temporary files */
                micRiHome =
                        System.getProperty(DOMUtil.MIC_SYSTEM_HOME) + File.separator +
                        ServletConfigUtil.COMPONENT_RI + File.separator +
                        CustomerConfigUtil.getInstance().getCustomerCode(user.getDomain());

                tempDirectory =
                        new File(micRiHome + File.separator + TEMP + File.separator +
                                 TEMPLATE_DOWNLOAD + File.separator +
                                 randomizer.nextLong());
                tempDirectory.mkdirs();
            if (null != templateId) {

                // Merge the template with the data and obtain the merged file.
                mtDAO = new DocumentTemplate();
                mtDAO.initialise(user, templateId);
                mtDAO.setFileName(userFileName);
                mtDAO.setTemplatePath(templatePath);
                mtDAO.setTempFilePath(tempDirectory.getAbsolutePath());
                File mergedFile =
                    mtDAO.getMergedDocument(entityType, entityReference, user);
                if(null != mergedFile) {
                    mergedFileIs = new FileInputStream(mergedFile);

                    // Obtain the MIME type for the template file.
                    String templateFileType = mtDAO.getTemplateMIMEType();

                    fileCabAsso.setFileSize(mergedFile.length());
                    fileCabAsso.setFileType(templateFileType);
                    fileCabAsso.setFileInputStream(mergedFileIs);
                    fileCabAsso.setTempDirPath(tempDirectory.getAbsolutePath());
                }
            } else {
                if (fileItems.size() > 1) {
                    throw new MissingDataException("Only one file can be uploaded at a time",
                                                   null);
                }

                String fileName =
                    (String)new ArrayList(fileItems.keySet()).get(0);
                FileItem fileItem = (FileItem)fileItems.get(fileName);
                fileCabAsso.setFileInputStream(fileItem.getInputStream());
                fileCabAsso.setTempDirPath(tempDirectory.getAbsolutePath());

                if (HTTPConstants.PARAM_DOCUMENT_TEMPLATE.equalsIgnoreCase(entityType)) {
                    FileCabinetAssociation tempFileCabAsso =
                        new FileCabinetAssociation();
                    int responseCode = tempFileCabAsso.validateAttachment(user, fileCabAsso.getFolderObjectId(), userFileName, isSupplement);
                    if (responseCode == 1) {
                        throw new TemplateFileUploadException("Invalid supplement file name, it must end with '_supplement.docx'", null);
                    } else if(responseCode == 2){
                        throw new TemplateFileUploadException("Invalid main file name, it must not end with '_supplement.docx'.", null);
                    } else if(responseCode == 3){
                        throw new TemplateFileUploadException("Main file not uploaded for this document template.", null);
                    }
                    // Check if a file already exists for the template

                    tempFileCabAsso.init(user, folderId, userFileName);
                    String tempFileName = tempFileCabAsso.getFileName();
                    if (null != tempFileName && !"".equals(tempFileName)) {
                        request.setAttribute(PARAMETER_AUTO_REFRESH, "true");
                        throw new TemplateFileUploadException("A file has already been attached for this template.",
                                                              null);
                    }
                    // Check if the MIME type of the file to be attached is the same as the
                    // MIME type set for the template
                    mtDAO = new DocumentTemplate();
                    mtDAO.initialise(user, entityReference);
                    String templateMIMEType = mtDAO.getTemplateMIMEType();
                    String templateName = mtDAO.getValue(mtDAO.PDT_NAME);
                    if (null != templateMIMEType &&
                        !"".equals(templateMIMEType) &&
                        !templateMIMEType.equalsIgnoreCase(fileItem.getContentType())) {
                        throw new TemplateFileUploadException("Please check the type of the file attached OR if the file is currently in use. ",
                                                              null);
                    }

                    // Read the input stream in a a temp file
                    tempFile =
                            File.createTempFile(randomizer.nextInt() + "", "tmp");
                    FileOutputStream fos = new FileOutputStream(tempFile);
                    InputStream is = fileItem.getInputStream();

                    FileUtil.streamCopy(is, fos);

                    fos.flush();
                    fos.close();
                    is.close();

                    // Check if the uploaded file is static
                    boolean isStatic =MailMerge.isStatic(user, templateMIMEType,
                                                 tempFile, templateName);

                    Connection conn = null;
                    try {
                        conn = ConnectionPool.getConnection(user);
                        // Update the template with the static flag
                        mtDAO.setValue(mtDAO.PDT_IS_STATIC,
                                       isStatic ? "Y" : "N");
                        mtDAO.update(conn);
                    } finally {
                        try {
                            DBUtil.close(conn);
                        } finally {
                            // Suppress
                        }
                    }
                    conn.commit();
                    // Reset file cabinate association stream to temp file
                    fileCabAsso.setFileInputStream(new FileInputStream(tempFile));

                } else if (HTTPConstants.PARAM_IMAGE.equalsIgnoreCase(entityType)) {
                    // Check if a file already exists for the image
                    FileCabinetAssociation tempFileCabAsso =
                        new FileCabinetAssociation();
                    tempFileCabAsso.init(user, folderId);
                    String tempFileName = tempFileCabAsso.getFileName();
                    if (null != tempFileName && !"".equals(tempFileName)) {
                        request.setAttribute(PARAMETER_AUTO_REFRESH, "true");
                        throw new TemplateFileUploadException("A file has already been attached for this image.",
                                                              null);
                    }
                    // Check if the MIME type of the file to be attached is the same as the
                    // MIME type set for the image
                    Image image = new Image();
                    image.initialise(user, entityReference);
                    String uploadedFileMIMEType = fileItem.getContentType();
                    if (!(uploadedFileMIMEType.equals("image/jpeg") ||
                          uploadedFileMIMEType.equals("image/jpg") ||
                          uploadedFileMIMEType.equals("image/pjpeg") ||
                          uploadedFileMIMEType.equals("image/gif"))) {
                        throw new TemplateFileUploadException("Please check the type of the file attached. Only JPEG and GIF files are allowed. ",
                                                              null);
                    }

                    // Read the input stream in a a temp file
                    tempFile =
                            File.createTempFile(randomizer.nextInt() + "", "tmp");
                    FileOutputStream fos = new FileOutputStream(tempFile);
                    InputStream is = fileItem.getInputStream();

                    FileUtil.streamCopy(is, fos);

                    fos.flush();
                    fos.close();
                    is.close();

                    // Reset file cabinet association stream to temp file
                    fileCabAsso.setFileInputStream(new FileInputStream(tempFile));
                }

                //Mime Type for Manual Upload Documents 
                fileCabAsso.setFileSize(fileItem.getSize());
                String contentType = fileItem.getContentType();
                String name = fileItem.getName();
                if (name != null && name.lastIndexOf(".") > 0) {
                	String[] extension = name.toLowerCase().split("\\.");
                	String fileExtension = extension[extension.length-1];
                	fileCabAsso.setFileExtension("." + fileExtension);
                	
                	Map<String, String> mimeTypeMap = fileCabAsso.getFileExtensionMimeType(user);
                    String mimeType = mimeTypeMap.get("." + extension[extension.length-1]);
                    contentType = (mimeType == null) ? contentType : mimeType;
                }
                fileCabAsso.setFileType(contentType);
            }
            fileCabAsso.setDownloadBehaviour(downloadBehaviour);
            try {
            	fileCabAsso.insert(user);	
            }finally {
            	
                if(fileCabAsso != null)
                {
                	fileCabAsso.getFileInputStream().close();
                }
			}
            

            if (tempFile != null) {
                tempFile.delete();
            }

            this.sendSuccess(response, portletId);
        } catch (Exception e) {
            this.sendError(request, response, e.getMessage(), e);
        } finally {
            if (mergedFileIs != null) {
                mergedFileIs.close();
            }
            if (tempDirectory != null) {
                FileUtil.delete(tempDirectory);
            }
        }
    }

    /**
     * Performs not null validations on the Strings passed in the parameter.
     * @param folderIdStr - the folder id
     * @param entityType - the entity type
     * @param entityReference - the entity reference
     * @param portletId - the portlet id
     * @param userFileName 0 the file name of the file to be uploaded
     * @param fileItems - the file(s) to be uploaded
     * @throws MissingDataException - if any of the parameters are empty or blank
     */
    private void validateMandatoryFields(String folderIdStr, String entityType,
                                         String entityReference,
                                         String portletId, String userFileName,
                                         Map fileItems,
                                         String templateId, User user) throws MissingDataException {
        if (folderIdStr == null || "".equals(folderIdStr.trim())) {
            throw new MissingDataException("The hidden field folderId is missing.",
                                           null);
        }

        if (entityType == null || "".equals(entityType.trim())) {
            throw new MissingDataException("The hidden field entityType is missing.",
                                           null);
        }


        if (entityReference == null || "".equals(entityReference.trim())) {
            throw new MissingDataException("The hidden field entityReference is missing.",
                                           null);
        }

        if (portletId == null || "".equals(portletId.trim())) {
            throw new MissingDataException("The hidden field portletId is missing.",
                                           null);
        }

        if (userFileName == null || "".equals(userFileName.trim())) {
            throw new MissingDataException("Please specify the file name",
                                           null);
        }
        if ((!(fileItems == null || fileItems.size() == 0)) &&
            (null == templateId)) {
            String fileName = (String)new ArrayList(fileItems.keySet()).get(0);
            FileItem fileItem = (FileItem)fileItems.get(fileName);
            if (fileItem.getFieldName() == null ||
                fileItem.getName() == null || "".equals(fileItem.getName())) {
                if (!HTTPConstants.PARAM_DOCUMENT_TEMPLATE.equalsIgnoreCase(entityType)) {
                    throw new MissingDataException("Please specify either the file to upload OR the template name.",
                                                   null);
                } else {
                    throw new MissingDataException("Please specify the file to upload.",
                                                   null);
                }
                
            }
            String fileExtension  = fileItem.getName().substring(fileItem.getName().lastIndexOf(".") + 1);
            if (!CustomerConfigUtil.getInstance().checkFileExtensionIsValid(user.getDomain(), fileExtension)) {
            	throw new MissingDataException("File with extension ." + fileExtension + " cannot be uploaded.",
                        null);
            }
			String customerDefinedFileSize = CustomerConfigUtil.getInstance().getCustomerProperty(
					user.getDomain(),
					ServletConfigUtil.COMPONENT_PORTAL,
					CustomerConfigUtil.CUST_DEF_FILE_SIZE);
			if(customerDefinedFileSize != null) {
				double custDefinedFileSize = Double.parseDouble(customerDefinedFileSize);	
				double sizeInBytes = fileItem.getSize();
				double fileSizeInMB = sizeInBytes/(1024*1024);
				if(custDefinedFileSize > 0 && fileSizeInMB > custDefinedFileSize){
					throw new MissingDataException("File with size more than " + custDefinedFileSize + " MB cannot be uploaded.",
                            null);					
				}
			}
        }

    }

    /**
     * Forwards the exception passed in the parameter to the error jsp page.
     * @param request - The request object
     * @param response - the response object to which the response will be written to
     * @param errorMessage - the error message which is to be displayed
     * @param throwable - the exception which is to be lgged.
     * @throws IOException if any error occurs while processing
     */
    private void sendError(HttpServletRequest request,
                           HttpServletResponse response, String errorMessage,
                           Throwable throwable) throws IOException {

        if (throwable instanceof TemplateFileUploadException) {
            LogMinder.getLogMinder().log(LogEntry.SEVERITY_ERROR,
                                         getClass().getName(), "sendError",
                                         ServletConfigUtil.COMPONENT_IMAGING,
                                         new Object[] { },
                                         "Posting error message to response - " +
                                         errorMessage, throwable,
                                         LogMinderDOMUtil.VALUE_MIC);
        } else {
            LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                                         getClass().getName(), "sendError",
                                         ServletConfigUtil.COMPONENT_IMAGING,
                                         new Object[] { },
                                         "Posting error message to response - " +
                                         errorMessage, throwable,
                                         LogMinderDOMUtil.VALUE_MIC);
        }

        request.setAttribute(PARAMETER_ERROR_MSG, errorMessage);

        try {
            getServletContext().getRequestDispatcher(ERROR_JSP_PATH).forward(request,
                                                                             response);
        } catch (ServletException e) {
            LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                                         getClass().getName(), "sendError",
                                         ServletConfigUtil.COMPONENT_IMAGING,
                                         new Object[] { },
                                         "Failed to forward request to path - " +
                                         ERROR_JSP_PATH, throwable,
                                         LogMinderDOMUtil.VALUE_MIC);
        }
    }

    /**
     * This operation writes HTML code to the response to close the File Attach pop-up.
     * @param response - the response object to which the response will be written to
     * @param portletId - the portlet id for which a refresh will be fired after closing the attach pop-up window.
     * @throws IOException if any exception occurs while processing.
     */
    private void sendSuccess(HttpServletResponse response,
                             String portletId) throws IOException {
        StringBuffer sBuf = new StringBuffer();
        sBuf.append("<HTML><HEAD><BODY onload='javascript:parent.closeAttachPopup(\"" +
                    portletId + "\", self);return false;'>");
        sBuf.append("</BODY></HTML>");
        response.setHeader("Content-Type", "text/html");
        response.getWriter().println(sBuf.toString());
    }
}
