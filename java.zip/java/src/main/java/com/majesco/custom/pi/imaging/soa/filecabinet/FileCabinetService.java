package com.majesco.custom.pi.imaging.soa.filecabinet;

import com.coverall.exceptions.JDBCException;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.HTTPConstants;
import com.coverall.mt.http.User;
import com.coverall.mt.soa.ListService;
import com.coverall.mt.xml.DOMUtil;
import org.apache.commons.lang.StringEscapeUtils;
import com.majesco.custom.pi.imaging.soa.filecabinet.dao.FileCabinetAssociation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;

import javax.naming.NamingException;


/**
 * This class is the web service class for the File Cabinet Web Service.
 *
 * @author $Author:   aman  $
 * @version $Revision:   1.4  $
 */
public class FileCabinetService extends ListService {

  
    private static final String PARAM_FILE_NAME = "fileName";
    private static final String PARAM_FILE_PATH = "filePath";
    private static final String PARAM_FOLDER_OBJECT_ID = "folderObjectId";
    private static final String PARAM_TARGET_FOLDER_OBJECT_ID = "targetFolderObjectId";
    
    /**
     * Default constructor.
     */
    public FileCabinetService() {
    }

    /**
     * Used to delete an Object.
     * @param userName
     * @param password
     * @param params
     * @throws Exception
     */
    public void deleteObjectData(User user, Map params) throws Exception {

        String strFolderObjectId = (String)params.get(PARAM_FOLDER_OBJECT_ID);
        
        String strFileName = (String)params.get(PARAM_FILE_NAME);
        String strFilePath = (String)params.get(PARAM_FILE_PATH);
        if(!isValidFileName(user,(String)params.get(PARAM_FILE_NAME))) {
        	strFileName = org.apache.commons.lang.StringEscapeUtils.unescapeHtml(strFileName);
        	strFilePath = org.apache.commons.lang.StringEscapeUtils.unescapeHtml(strFilePath);
        }

        if (strFolderObjectId == null) {
            throw new Exception("Request parameter folderObjectId is missing.");
        }

        if ((strFileName == null) || (strFileName == "")) {
            throw new Exception("Request parameter fileName is missing.");
        }

        if ((strFilePath == null) || (strFilePath == "")) {
            throw new Exception("Request parameter filePath is missing.");
        }

        long folderObjectId = 0;

        try {
            folderObjectId = Long.parseLong(strFolderObjectId);
        } catch (Exception ex) {
            throw new Exception("Invalid folderObjectId : " + 
                                strFolderObjectId);
        }

        String fileName = strFileName;
        String filePath = strFilePath;

        FileCabinetAssociation fcAssn = new FileCabinetAssociation();
        fcAssn.setFolderObjectId(folderObjectId);
        fcAssn.setFileName(fileName);
        fcAssn.setFilePath(filePath);
        fcAssn.delete(user);
    }
    
    public boolean isValidFileName(User user, String unEscapeFileName){
    	Connection conn = null;
    	PreparedStatement prest = null;
    	ResultSet rs = null;
    	int count = 0;
    	boolean validName = true;
    	//String query;
    	try {
			conn = ConnectionPool.getConnection(user);
			 String query = "select count(1) from MIS_FOLDER_OBJECTS_FILES_ASSN where MFF_FILE_NAME = ? ";
	         prest = conn.prepareStatement(query);
	         prest.setString(1, unEscapeFileName);
	         rs = prest.executeQuery();
	         if(rs != null){
	        	 while (rs.next()) {
	        		count = rs.getInt(1);
	        	 }
	         }
	         if(count > 0) {
	        	 validName = true;
	         }else {
	        	 validName = false;
	         }
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		} finally {
			if(conn != null) {
				try {
					conn.close();
					rs.close();
					prest.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
				}
			}
		}
    	return validName;
    }

    /**Used to delete all the objects under a folder.
     * @param user
     * @param params
     * @throws Exception
     */
    public void deleteAllObjectData(User user, Map params) throws Exception {

        String strFolderObjectId = (String)params.get(PARAM_FOLDER_OBJECT_ID);
        long count = Long.parseLong(getCount(user, params));
        if (count != 0 && 
            DOMUtil.FALSE.equalsIgnoreCase((String)params.get(HTTPConstants.PARAM_IGNORE_DATA))) {
            throw new JDBCException("There is data in this tab. It cannot be removed.", 
                                    null);
        }
        
        long folderObjectId = 0;

        try {
            folderObjectId = Long.parseLong(strFolderObjectId);
        } catch (Exception ex) {
            throw new Exception("Invalid folderObjectId : " + 
                                strFolderObjectId);
        }
        FileCabinetAssociation fcAssn = new FileCabinetAssociation();
        fcAssn.setFolderObjectId(folderObjectId);
        fcAssn.deleteAll(user);
    }

    /**Used to clone object data from one folder into another.
     * @param user
     * @param params
     * @throws Exception
     */
    public void cloneObjectData(User user, Map params) throws Exception {

        String strSourceFolderObjectId = (String)params.get(PARAM_FOLDER_OBJECT_ID);
        String strTargetFolderObjectId = (String)params.get(PARAM_TARGET_FOLDER_OBJECT_ID);
        
        long sourceFolderObjectId = 0;

        try {
            sourceFolderObjectId = Long.parseLong(strSourceFolderObjectId);
        } catch (Exception ex) {
            throw new Exception("Invalid folderObjectId : " + 
                                strSourceFolderObjectId);
        }
        
        long targetFolderObjectId = 0;

        try {
            targetFolderObjectId = Long.parseLong(strTargetFolderObjectId);
        } catch (Exception ex) {
            throw new Exception("Invalid targetFolderObjectId : " + 
                                strTargetFolderObjectId);
        }
        
        FileCabinetAssociation fcAssn = new FileCabinetAssociation();
        fcAssn.setFolderObjectId(sourceFolderObjectId);
        fcAssn.clone(user,targetFolderObjectId);
    }

}

