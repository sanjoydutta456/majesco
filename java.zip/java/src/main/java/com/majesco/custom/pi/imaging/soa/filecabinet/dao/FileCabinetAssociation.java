 /*
 *                 Majesco Code License Notice
 *
 * The contents of this file are subject to the Majesco Code License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License
 *
 * The Original Code is for My Insurance Center. The Initial Developer
 * of the Original Code is Majesco, All Rights Reserved.
 */

package com.majesco.custom.pi.imaging.soa.filecabinet.dao; 

import static com.coverall.util.RepositoryConstants.MIC_DIRECTORY_NAME;
import static com.coverall.util.RepositoryConstants.PATH_SEPERATOR;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;

import com.coverall.cms.client.IResponseHandler;
import com.coverall.cms.client.RepositoryAccess;
import com.coverall.cms.client.RepositoryAccessResponse;
import com.coverall.cms.client.impl.sling.http.SlingConstants;
import com.coverall.cms.utility.CustomerCmsUtil;
import com.coverall.exceptions.ExceptionImpl;
import com.coverall.exceptions.FactoryObjectInitializationException;
import com.coverall.exceptions.FileSystemException;
import com.coverall.factory.FactoryObject;
import com.coverall.mt.cms.CMSDirectory;
import com.coverall.mt.cms.IDirectory;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;
import com.coverall.util.FileUtil;

/**
 * Data Access Object for the FileCabinet Web Service.
 */
public class FileCabinetAssociation implements FactoryObject, Serializable {

    /** The virtual folder id under which the file(s) will be stored.*/
    private long folder_object_id;

    /** The file name*/
    private String file_name;
    
    /**NEW The attachment category*/
    private String attachment_category; //NEW

    /** The file path*/
    private String file_path;

    /** The file type*/
    private String file_type;

    /** The file size*/
    private long file_size;

    /** The file creation date*/
    private java.sql.Date date_created;

    /** The file modification date*/
    private java.sql.Date date_modified;

    /** The user who created the file*/
    private String user_created;

    /** The user who modified the file*/
    private String user_modified;

    /** The entity reference*/
    private String entityReference;

    /** The entity type*/
    private String entityType;

    /** The user who provided type of the file*/
    private String user_type;
    
    /** The user who provided type of the file*/
    private String file_extension;
        
    /** The file input stream*/
    private InputStream fileInputStream = null;

    /** The temporary file path */
    private String tempDirPath;
    
    /** The file download behaviour */
    private String downloadBehaviour;
    
    /** file Description */
    private String fileDescription;
    
    private static final String SUPPLEMENT_FILE_POSTFIX = "_supplement.docx";

    /** The folder object id db column name constant */
    private static final String COL_NAME_FOLDER_OBJECT_ID = 
        "MFF_FOLDER_OBJECT_ID";

    /** The file name db column name constant*/
    private static final String COL_NAME_FILE_NAME = "MFF_FILE_NAME";
    
    /**NEW The attachment category db column name constant*/
    private static final String COL_NAME_ATTACHMENT_CATEGORY = "MFF_C_ATTACH_CATEGORY"; //NEW

    /** The file path db column name constant*/
    private static final String COL_NAME_FILE_PATH = "MFF_FILE_PATH";

    /** The file path db column name constant*/
    private static final String COL_NAME_FILE_DESCRIPTION = "MFF_FILE_DESCRIPTION";
        
    /** The file path db column name constant*/
    private static final String COL_NAME_FILE_EXTENSION = "MFF_FILE_EXTENSION";
    
    /** The file type db column name constant*/
    private static final String COL_NAME_FILE_TYPE = "MFF_FILE_TYPE";

    /** The file size db column name constant*/
    private static final String COL_NAME_FILE_SIZE = "MFF_FILE_SIZE";

    /** The date created db column name constant*/
    private static final String COL_NAME_DATE_CREATED = "MFF_DATE_CREATED";

    /** The date modified db column name constant*/
    private static final String COL_NAME_DATE_MODIFIED = "MFF_DATE_MODIFIED";

    /** The user created db column name constant*/
    private static final String COL_NAME_USER_CREATED = "MFF_USER_CREATED";

    /** The user modified db column name constant*/
    private static final String COL_NAME_USER_MODIFIED = "MFF_USER_MODIFIED";
    
    /** The user modified db column name constant*/
    private static final String COL_NAME_USER_TYPE = "MFF_USER_TYPE";

    /** The constant to store a part of the Sling file path.*/
    public static final String FOLDER_NAME_FILE_CABINET = "file cabinet";

    /** The Entity Type db column name constant.*/
    public static final String ENTITY_TYPE = "FEF_ENTITY_TYPE";

    /** The Entity Reference db column name constant.*/
    public static final String ENTITY_REFERENCE = "FEF_ENTITY_REFERENCE";

    /** Query constant used for fetching files count*/
    private static final String QUERY_GET_FILESCOUNT = 
        "SELECT COUNT(MFF_FOLDER_OBJECT_ID) FROM MIS_FOLDER_OBJECTS_FILES_ASSN WHERE MFF_FOLDER_OBJECT_ID = ?";
        
    /** Query constant used for fetching information of all the files under a folder*/
    private static final String QUERY_GET_FILES_INFO = 
        "SELECT MFF_FILE_NAME,MFF_ATTACHMENT_CATEGORY,MFF_FILE_PATH,MFF_FILE_TYPE,MFF_FILE_SIZE,MFF_USER_CREATED from MIS_FOLDER_OBJECTS_FILES_ASSN WHERE MFF_FOLDER_OBJECT_ID=?";		//added attachment category

    /** Query constant used for fetching entityType,entityReference of the target folder(used for cloning)*/
    private static final String QUERY_GET_TARGET_FOLDER_INFO = 
        "SELECT FEF_ENTITY_TYPE,FEF_ENTITY_REFERENCE FROM FOM_FOLDER_OBJECTS,FOM_ENTITY_FOLDERS\n" + 
        "WHERE FOB_FOLDER_ID = FEF_FOLDER_ID AND FOB_FOLDER_OBJECT_ID =?";

    /** Query constant used for fetching the sequence value*/
    private static final String QUERY_FETCH_SEQUENCEVAL = 
        " SELECT S_IFS_FILE_CABINET.NEXTVAL FROM dual";

    /** Query constant used for fetching files*/
    private static final String QUERY_SELECT_FILE_CAB_ASSOC = 
        "SELECT * FROM MIS_FOLDER_OBJECTS_FILES_ASSN WHERE MFF_FOLDER_OBJECT_ID = ?";
    
    private static final String QUERY_SELECT_FILE_CAB_ASSOC_USING_ID_AND_NAME = 
        "SELECT * FROM MIS_FOLDER_OBJECTS_FILES_ASSN WHERE MFF_FOLDER_OBJECT_ID = ? AND MFF_FILE_NAME = ?";

    /** Query constant used for inserting a file*/
    private static final String QUERY_INSERT_FILE_CAB_ASSOC = 
        "{ ? = call K_FILE_CABINET_MANAGEMENT_C.F_ADD_FILE_FOLDER_ASSOC_1(?,?,?,?,?,?,?,?,?,?,?,?) }";

    /** Query constant used for deleting a file*/
    private static final String QUERY_DELETE_FILE_CAB_ASSOC = 
        "{ ? = call K_FILE_CABINET_MANAGEMENT_C.F_DEL_FILE_FOLDER_ASSOC_C(?,?,?,?,?) }";
        
    /** Query constant used for fetching the file size*/
    private static final String QUERY_FETCH_FILE_SIZE =
        "SELECT MFF_FILE_SIZE FROM MIS_FOLDER_OBJECTS_FILES_ASSN WHERE MFF_FILE_PATH = ?";

    /**
     * Sets the virtual folder id under which the file(s) will be stored.
     * @param folder_object_id the virtual folder id under which the file(s) will be stored.
     */
    public void setFolderObjectId(long folder_object_id) {
        this.folder_object_id = folder_object_id;
    }

    /**
     * Returns the virtual folder id under which the file(s) will be stored.
     * @return the virtual folder id under which the file(s) will be stored.
     */
    public long getFolderObjectId() {
        return folder_object_id;
    }

    /**
     * Sets the file name.
     * @param file_name the file name to set
     */
    public void setFileName(String file_name) {
        this.file_name = file_name;
    }

    /**
     * Returns the file name.
     * @return the file name
     */
    public String getFileName() {
        return file_name;
    }
    
    /**NEW
     * Sets the attachment category.
     * @param attachment_category the attachment category to set
     */
    public void setAttachmentCategory(String attachment_category) {
        this.attachment_category = attachment_category;							//NEW
    }

    /**NEW
     * Returns the attachment category.
     * @return the attachment category
     */
    public String getAttachmentCategory() {
        return attachment_category;												//NEW
    }
    
    
    
    public String getDownloadBehaviour() {
		return downloadBehaviour;
	}

	public void setDownloadBehaviour(String downloadBehaviour) {
		this.downloadBehaviour = downloadBehaviour;
	}

	/**
     * Returns the file description
     * @return
     */
    public String getFileDescription() {
		return fileDescription;
	}

    /**
     * Set the file description 
     * @param fileDescription
     */
	public void setFileDescription(String fileDescription) {
		this.fileDescription = fileDescription;
	}

    /**
     * The file path to set.
     * @param file_path the file path
     */
    public void setFilePath(String file_path) {
        this.file_path = file_path;
    }

    /**
     * Returns the file path.
     * @return the file path
     */
    public String getFilePath() {
        return file_path;
    }

    /**
     * The file type to set.
     * @param file_type the file type to set
     */
    public void setFileType(String file_type) {
        this.file_type = file_type;
    }

    /**
     * The stored file type.
     * @return the file type
     */
    public String getFileType() {
        return file_type;
    }

    /**
     * The file size to set.
     * @param file_size the file size
     */
    public void setFileSize(long file_size) {
        this.file_size = file_size;
    }

    /**
     * Returns the stored file size.
     * @return the stored file size
     */
    public long getFileSize() {
        return file_size;
    }

    /**
     * Sets the created date.
     * @param date_created the date created
     */
    public void setDateCreated(Date date_created) {
        this.date_created = date_created;
    }

    /**
     * Retrieves the date created.
     * @return the date created
     */
    public Date getDateCreated() {
        return date_created;
    }

    /**
     * Sets the modified date.
     * @param date_modified the modified date
     */
    public void setDateModified(Date date_modified) {
        this.date_modified = date_modified;
    }

    /**
     * Retrieves the modified date.
     * @return the modified date
     */
    public Date getDateModified() {
        return date_modified;
    }

    /**
     * Sets the user created.
     * @param user_created the user created
     */
    public void setUserCreated(String user_created) {
        this.user_created = user_created;
    }

    /**
     * Retrieves the user created.
     * @return the user created
     */
    public String getUserCeated() {
        return user_created;
    }

    /**
     * Sets the user modified.
     * @param user_modified the user modified
     */
    public void setUserModified(String user_modified) {
        this.user_modified = user_modified;
    }

    /**
     * Retrieves the user modified.
     * @return the user modified
     */
    public String getUserModified() {
        return user_modified;
    }

    /**
     * Sets the entity reference.
     * @param entityReference the entity reference
     */
    public void setEntityReference(String entityReference) {
        this.entityReference = entityReference;
    }

    /**
     * Retrieves the entity reference.
     * @return the entity reference
     */
    public String getEntityReference() {
        return entityReference;
    }

    /**
     * Sets the entity type.
     * @param entityType the entity type
     */
    public void setEntityType(String entityType) {
        this.entityType = entityType;
    }

    /**
     * Retrieves the entity type.
     * @return the entity type
     */
    public String getEntityType() {
        return entityType;
    }
    
    /**
     * Retrieves user type of the file.
     * @return user type
     */
    public String getUserType() {
		return user_type;
	}

    /**
     * Set user type of the file.
     * @param user_type
     */
	public void setUserType(String user_type) {
		this.user_type = user_type;
	}
	
	/**
	 * Returns the file extension
	 * @return
	 */
	public String getFileExtension() {
		return file_extension;
	}

	/**
	 * Sets the file extension
	 * @param file_extension
	 */
	public void setFileExtension(String file_extension) {
		this.file_extension = file_extension;
	}
    
    /**
     * sets the file input stream to upload the file.
     * @param fileInputStream the file input stream to upload the file
     */
    public void setFileInputStream(InputStream fileInputStream) {
        this.fileInputStream = fileInputStream;
    }

    /**
     * Returns the file input stream to download the file.
     * @return the file input stream to download the file
     */
    public InputStream getFileInputStream() {
        return fileInputStream;
    }

    public String getTempDirPath() {
        return tempDirPath;
    }

    public void setTempDirPath(String tempDirPath) {
        this.tempDirPath = tempDirPath;
    }
    
    public void init(User user, long folderObjectsId) throws Exception {
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            conn = ConnectionPool.getConnection(user);
            pst = conn.prepareStatement(QUERY_SELECT_FILE_CAB_ASSOC);
            pst.setLong(1, folderObjectsId);
            rs = pst.executeQuery();

            if (rs.next()) {
                HashMap args = new HashMap();
                args.put(FactoryObject.INIT_KEY, rs);
                init(args);
            }
        } finally {
            DBUtil.close(rs, pst, conn);
        }
    }
    
    public void init(User user, long folderObjectsId, String fileName) throws Exception {
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            conn = ConnectionPool.getConnection(user);
            pst = conn.prepareStatement(QUERY_SELECT_FILE_CAB_ASSOC_USING_ID_AND_NAME);
            pst.setLong(1, folderObjectsId);
            pst.setString(2, fileName);
            rs = pst.executeQuery();

            if (rs.next()) {
                HashMap args = new HashMap();
                args.put(FactoryObject.INIT_KEY, rs);
                init(args);
            }
        } finally {
            DBUtil.close(rs, pst, conn);
        }
    }

    /**
     * Initialises this isntance with the hashmap passed as arguments.
     * @param args the initialisation arguments
     * @throws FactoryObjectInitializationException if an error occurs during initialisation
     */
    public void init(HashMap args) throws FactoryObjectInitializationException {
        if (args == null) {
            throw new FactoryObjectInitializationException(ExceptionImpl.FATAL, 
                                                           "args was null", 
                                                           null);
        }

        ResultSet rs = (ResultSet)args.get("INIT_KEY");

        if (rs == null) {
            throw new FactoryObjectInitializationException(ExceptionImpl.FATAL, 
                                                           "rs was null", 
                                                           null);
        }

        try {
            this.folder_object_id = rs.getLong(COL_NAME_FOLDER_OBJECT_ID);
            this.file_name = rs.getString(COL_NAME_FILE_NAME);
            this.attachment_category = rs.getString(COL_NAME_ATTACHMENT_CATEGORY);		//NEW
            this.file_path = rs.getString(COL_NAME_FILE_PATH);
            this.fileDescription = rs.getString(COL_NAME_FILE_DESCRIPTION);
            this.file_extension = rs.getString(COL_NAME_FILE_EXTENSION);   
            this.file_type = rs.getString(COL_NAME_FILE_TYPE);
            this.file_size = rs.getLong(COL_NAME_FILE_SIZE);
            this.date_created = rs.getDate(COL_NAME_DATE_CREATED);
            this.date_modified = rs.getDate(COL_NAME_DATE_MODIFIED);
            this.user_created = rs.getString(COL_NAME_USER_CREATED);
            this.user_modified = rs.getString(COL_NAME_USER_MODIFIED);
            this.user_type = rs.getString(COL_NAME_USER_TYPE);
        } catch (Throwable t) {
            throw new FactoryObjectInitializationException(ExceptionImpl.FATAL, 
                                                           "unable to load object", 
                                                           t);
        }
    }

    /**
     * Inserts the file uploaded by the user in the parameter to Sling and the database.
     * @param user - the user who uploads the file
     * @throws Exception if any error occurs while processing
     */
    public void insert(User user) throws Exception {
        Connection connection = null;
        CallableStatement callableStatement = null;
        IDirectory entityDir = null;
        String userErrorMsg = "Failed to upload file " + this.getFileName() + " to path(" + this.getFilePath() + ")";
        try {
            try {
                connection = ConnectionPool.getConnection(user);
                int sequenceVal = this.fetchSequenceVal(user, connection);
                //Try to add the file to Sling first
                entityDir = this.addFileToSling(user, sequenceVal);
                callableStatement = 
                        connection.prepareCall(QUERY_INSERT_FILE_CAB_ASSOC);
                callableStatement.registerOutParameter(1, Types.BIGINT);
                callableStatement.setLong(2, this.getFolderObjectId());
                callableStatement.setString(3, this.getFileName());
                callableStatement.setString(4, this.getFilePath());
                callableStatement.setString(5, this.getFileDescription());
                callableStatement.setString(6, this.getFileExtension());
                callableStatement.setString(7, this.getFileType());
                callableStatement.setLong(8, this.getFileSize());
                callableStatement.setString(9, this.getUserCeated());
                callableStatement.setString(10, this.getUserType());
                callableStatement.registerOutParameter(11, Types.VARCHAR);
                callableStatement.setString(12, this.getDownloadBehaviour());
                callableStatement.setString(13, this.getAttachmentCategory());
                callableStatement.execute();

                long errorCode = callableStatement.getLong(1);

                if (errorCode != 0) {
                    String errorMessage = 
                        "Error adding file cabinet folder object association : ";
                    errorMessage = 
                            errorMessage + callableStatement.getString(8);
                    throw new SQLException(errorMessage);
                }

                //Commit Sling and DB insert
                entityDir.commit();
                connection.commit();
            } catch (Exception ex) {
                LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, 
                                             getClass().getName(), "insert", 
                                             ServletConfigUtil.COMPONENT_IMAGING, 
                                             new Object[] { }, 
                                             userErrorMsg + ". Roll back sequence started.", 
                                             ex, LogMinderDOMUtil.VALUE_MIC);
                //Tracks if both Sling and DB transaction has been rolled back.
                boolean isCleanRollback = true;

                //Try to rollback. Log any errors and proceed.
                try {
                    if (connection != null) {
                        connection.rollback();
                    }
                } catch (SQLException sqe) {
                    isCleanRollback = false;
                    LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, 
                                                 getClass().getName(), 
                                                 "insert", 
                                                 ServletConfigUtil.COMPONENT_IMAGING, 
                                                 new Object[] { }, 
                                                 "DB Rollback failed.", sqe, 
                                                 LogMinderDOMUtil.VALUE_MIC);
                }

                //Log the error message depending on whether both Sling and DB transactions were rolled back.
                String rollBackMsg = 
                    (isCleanRollback ? "Rolled back successfully." : "Rolled back partially.");

                LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, 
                                             getClass().getName(), "insert", 
                                             ServletConfigUtil.COMPONENT_IMAGING, 
                                             new Object[] { }, 
                                             userErrorMsg + ". " + rollBackMsg, ex, 
                                             LogMinderDOMUtil.VALUE_MIC);
                throw new FileSystemException(ExceptionImpl.FATAL, 
                                              userErrorMsg, ex);
            }
        } finally {
            try {
                DBUtil.close(null, callableStatement, connection);
            } catch (SQLException sqe) {
                LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, 
                                             getClass().getName(), "insert", 
                                             ServletConfigUtil.COMPONENT_IMAGING, 
                                             new Object[] { }, 
                                             "Exception while closing the connection", 
                                             sqe, 
                                             LogMinderDOMUtil.VALUE_MIC);
            }
        }
    }

    /**
     * Deletes an existing file for the user in the parameter from both Sling and the database.
     * @param user the user who wants to delete the file
     * @throws Exception if any error occurs while processing
     */
    public void delete(User user) throws Exception {
        Connection connection = null;
        CallableStatement callableStatement = null;
        IDirectory targetFile = null;
        boolean deleteFileFlag = false;
        String userErrorMsg = "Failed to delete file " + this.getFileName() + " at path(" + this.getFilePath() + ")";
        try {
            if(isFileExistInSling(user) == true) {
                //Delete the file from Sling first
                targetFile = this.deleteFileFromSling(user);
                deleteFileFlag = true;
            } else {
                deleteFileFlag = true;
            }
            if(deleteFileFlag == true) {
                connection = ConnectionPool.getConnection(user);
                callableStatement = 
                        connection.prepareCall(QUERY_DELETE_FILE_CAB_ASSOC);
                        
                callableStatement.registerOutParameter(1, Types.BIGINT);
                callableStatement.setLong(2, this.getFolderObjectId());
                callableStatement.setString(3, this.getFileName());
                callableStatement.setString(4, this.getFilePath());
                callableStatement.setString(5, user.getFullName());
                callableStatement.registerOutParameter(6, Types.VARCHAR);
                //callableStatement.setString(7, this.getAttachmentCategory());
                callableStatement.execute();
                long errorCode = callableStatement.getLong(1);
                if (errorCode != 0) {
                    String errorMessage = 
                        "Error deleting file cabinet folder object association : ";
                    errorMessage = 
                            errorMessage + callableStatement.getString(6);
                    throw new SQLException(errorMessage);
                }
                //Commit DB insert
                connection.commit();
            }
        } catch (Exception ex) {
            LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, 
                                         getClass().getName(), "delete", 
                                         ServletConfigUtil.COMPONENT_IMAGING, 
                                         new Object[] { }, 
                                         userErrorMsg + ". Roll back sequence started.", 
                                         ex, LogMinderDOMUtil.VALUE_MIC);
                                         
            //Tracks if both Sling and DB transaction has been rolled back.
            boolean isCleanRollback = true;

            // Try to rollback. Log any errors and proceed.
            try {
                if (connection != null) {
                    connection.rollback();
                }
            } catch (SQLException sqe) {
                isCleanRollback = false;
                LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, 
                                             getClass().getName(), 
                                             "delete", 
                                             ServletConfigUtil.COMPONENT_IMAGING, 
                                             new Object[] { }, 
                                             "DB Rollback failed.", sqe, 
                                             LogMinderDOMUtil.VALUE_MIC);
            }

            //Log the error message depending on whether both Sling and DB transactions were rolled back.
            String rollBackMsg = 
                (isCleanRollback ? "Rolled back successfully." : "Rolled back partially.");

            LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, 
                                         getClass().getName(), "delete", 
                                         ServletConfigUtil.COMPONENT_IMAGING, 
                                         new Object[] { }, 
                                         userErrorMsg + ". " + rollBackMsg, ex, 
                                         LogMinderDOMUtil.VALUE_MIC);
            throw new FileSystemException(ExceptionImpl.FATAL, 
                                              userErrorMsg, ex);
        } finally {
            try {
                DBUtil.close(null, callableStatement, connection);
            } catch (SQLException sqe) {
                LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, 
                                             getClass().getName(), "delete", 
                                             ServletConfigUtil.COMPONENT_IMAGING, 
                                             new Object[] { }, 
                                             "Exception while closing the connection", 
                                             sqe, 
                                             LogMinderDOMUtil.VALUE_MIC);
            }
        }
    }

    /** Deletes all the files under the folder from Sling and the database
     * @param user
     * @throws Exception
     */
    public void deleteAll(User user) throws Exception {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        CallableStatement callableStatement = null;
        ResultSet rs = null;
        IDirectory targetFile = null;
        String errorMsg = "";
        try{
            connection = ConnectionPool.getConnection(user);
            preparedStatement = 
                    connection.prepareStatement(QUERY_GET_FILES_INFO);
            preparedStatement.setLong(1, this.getFolderObjectId());
            rs= preparedStatement.executeQuery();
            
            String fileName ="";
            String filePath ="";
            Exception lastException = null;
            while (rs.next()){
                fileName = rs.getString(COL_NAME_FILE_NAME);
                filePath = rs.getString(COL_NAME_FILE_PATH);
                this.setFilePath(filePath);
                this.setFileName(fileName);

                String userErrorMsg = "Failed to delete file " + fileName + " at path(" + filePath + ")";
                try {
                    //Try to delete the file to Sling first
                    targetFile = this.deleteFileFromSling(user);
                    callableStatement = 
                            connection.prepareCall(QUERY_DELETE_FILE_CAB_ASSOC);
                    callableStatement.registerOutParameter(1, Types.BIGINT);
                    callableStatement.setLong(2, this.getFolderObjectId());
                    callableStatement.setString(3, this.getFileName());
                    callableStatement.setString(4, this.getFilePath());
                    callableStatement.setString(5, user.getFullName());
                    callableStatement.registerOutParameter(6, Types.VARCHAR);
                    //callableStatement.setString(7,this.getAttachmentCategory());
                    callableStatement.execute();
    
                    long errorCode = callableStatement.getLong(1);
    
                    if (errorCode != 0) {
                        String errorMessage = 
                            "Error deleting file cabinet folder object association : ";
                        errorMessage = 
                                errorMessage + callableStatement.getString(6);
                        throw new SQLException(errorMessage);
                    }
    
                    //Commit DB insert
                    connection.commit();
                } catch (Exception ex) {
                    lastException = ex;
                    
                    LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, 
                                                 getClass().getName(), "deleteAll", 
                                                 ServletConfigUtil.COMPONENT_IMAGING, 
                                                 new Object[] { }, 
                                                 userErrorMsg + ". Roll back sequence started.", 
                                                 ex, LogMinderDOMUtil.VALUE_MIC);
                                                 
                    //Tracks if both Sling and DB transaction has been rolled back.
                    boolean isCleanRollback = true;

                    // Try to rollback. Log any errors and proceed.
                    try {
                        if (connection != null) {
                            connection.rollback();
                        }
                    } catch (SQLException sqe) {
                        isCleanRollback = false;
                        LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, 
                                                     getClass().getName(), 
                                                     "deleteAll", 
                                                     ServletConfigUtil.COMPONENT_IMAGING, 
                                                     new Object[] { }, 
                                                     "DB Rollback failed.", sqe, 
                                                     LogMinderDOMUtil.VALUE_MIC);
                    }
                
                    //Log the error message depending on whether both Sling and DB transactions were rolled back.
                    String rollbackMsg = 
                        (isCleanRollback ? "Rolled back successfully." : "Rolled back partially.");
                
                    LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, 
                                                 getClass().getName(), "deleteAll", 
                                                 ServletConfigUtil.COMPONENT_IMAGING, 
                                                 new Object[] { }, 
                                                 userErrorMsg + ". " + rollbackMsg, null, 
                                                 LogMinderDOMUtil.VALUE_MIC);
                }
            }
            
            if (lastException != null){
                errorMsg = "All files could not be deleted";
                
                throw new FileSystemException(ExceptionImpl.FATAL, 
                                              errorMsg, lastException);
            }
        } catch (Exception ex) {
            if ("".equals(errorMsg)){
                errorMsg = "Failed to obtain file information for the folder. Aborting file deletion.";
            }
            LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, 
                                         getClass().getName(), 
                                         "deleteAll", 
                                         ServletConfigUtil.COMPONENT_IMAGING, 
                                         new Object[] { }, 
                                         errorMsg, ex, 
                                         LogMinderDOMUtil.VALUE_MIC);
            throw new FileSystemException(ExceptionImpl.FATAL, 
                                          errorMsg, ex);
        } finally {
            try {
                DBUtil.close(null,preparedStatement);
            } catch (SQLException sqe) {
                LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, 
                                             getClass().getName(), "deleteAll", 
                                             ServletConfigUtil.COMPONENT_IMAGING, 
                                             new Object[] { }, 
                                             "Exception while closing the statement", 
                                             sqe, 
                                             LogMinderDOMUtil.VALUE_MIC);
            }
            try {
                DBUtil.close(null, callableStatement, connection);
            } catch (SQLException sqe) {
                LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, 
                                             getClass().getName(), "deleteAll", 
                                             ServletConfigUtil.COMPONENT_IMAGING, 
                                             new Object[] { }, 
                                             "Exception while closing the connection", 
                                             sqe, 
                                             LogMinderDOMUtil.VALUE_MIC);
            }
        }
    }

    /** Clones a folder by copying all the files from the source folder to the target folder. Also copies the file assocations in the database.
     * @param user
     * @param targetFolderObjectId
     * @throws Exception
     */
    public void clone(User user,long targetFolderObjectId) throws Exception {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        CallableStatement callableStatement = null;
        ResultSet rs = null;
        IDirectory sourceEntityDir = null;
        IDirectory targetEntityDir = null;
        String errorMsg = "";
        try {
			HashMap<String, String> parameters = new HashMap<String, String>();
			String customerCode = CustomerConfigUtil.getInstance().getCustomerCode(user.getDomain());
			parameters.put(SlingConstants.SLING_SERVER_URL, CustomerConfigUtil.getInstance().getCustomerProperty(customerCode, ServletConfigUtil.COMPONENT_IMAGING, SlingConstants.SLING_SERVER_URL));
			parameters.put(SlingConstants.SLING_USER_NAME, CustomerConfigUtil.getInstance().getCustomerProperty(customerCode, ServletConfigUtil.COMPONENT_IMAGING, SlingConstants.SLING_USER_NAME));
			parameters.put(SlingConstants.SLING_PASSWORD, CustomerConfigUtil.getInstance().getCustomerProperty(customerCode, ServletConfigUtil.COMPONENT_IMAGING, SlingConstants.SLING_PASSWORD));
			parameters.put(SlingConstants.SLING_WORKSPACE, CustomerConfigUtil.getInstance().getCustomerProperty(customerCode, ServletConfigUtil.COMPONENT_IMAGING, SlingConstants.SLING_WORKSPACE));			
		
            RepositoryAccess repositoryAccess = CustomerCmsUtil.getInstance().getRepositoryAccess(customerCode, parameters, MIC_DIRECTORY_NAME);
            connection = ConnectionPool.getConnection(user);

            // Set the target Entity Type and Entity Reference
            preparedStatement = 
                    connection.prepareStatement(QUERY_GET_TARGET_FOLDER_INFO);
            preparedStatement.setLong(1, targetFolderObjectId);
            rs= preparedStatement.executeQuery();

            String targetEntityType = "";
            String targetEntityReference ="";
            while (rs.next()) {
                targetEntityType = rs.getString("FEF_ENTITY_TYPE");
                targetEntityReference = rs.getString("FEF_ENTITY_REFERENCE");
            }            
            
            this.setEntityType(targetEntityType);
            this.setEntityReference(targetEntityReference);
            
            preparedStatement = 
                    connection.prepareStatement(QUERY_GET_FILES_INFO);
            preparedStatement.setLong(1, this.getFolderObjectId());
            rs= preparedStatement.executeQuery();
            
            Exception lastException = null;
            String userErrorMsg = "";
            IResponseHandler responseHandler = null;
            while (rs.next()) {

                final String fileName = rs.getString(COL_NAME_FILE_NAME);
                final String filePath = rs.getString(COL_NAME_FILE_PATH);

                this.setFilePath(filePath);
                this.setFileName(fileName);
                this.setFileType(rs.getString(COL_NAME_FILE_TYPE));
                this.setFileSize(rs.getLong(COL_NAME_FILE_SIZE));
                this.setUserCreated(rs.getString(COL_NAME_USER_CREATED));
                try {
                    int sequenceVal = this.fetchSequenceVal(user, connection);
                    
                    /* Obtain the source file as InputStream */
                    sourceEntityDir = this.getFileFromSling(user, this.getFilePath());
                    this.setFileInputStream(sourceEntityDir.getFileAsStream());

                    /* Set target Path */
                    String targetFilePath = FileCabinetAssociation.FOLDER_NAME_FILE_CABINET + IDirectory.SEPARATOR +
                    targetEntityType + IDirectory.SEPARATOR + targetEntityReference;  
                    this.setFilePath(targetFilePath);

                    /* Set the error msg */
                    userErrorMsg = "Failed to upload file " + fileName + " to path(" + targetFilePath + ")";
                    
                    /* Copy the file to the target folder */
                    //Try to add the file to Sling first
                    targetEntityDir = this.addFileToSling(user, sequenceVal);
                    callableStatement = 
                            connection.prepareCall(QUERY_INSERT_FILE_CAB_ASSOC);
                    callableStatement.registerOutParameter(1, Types.BIGINT);
                    callableStatement.setLong(2, targetFolderObjectId);
                    callableStatement.setString(3, this.getFileName());
                    callableStatement.setString(4, this.getFilePath());
                    callableStatement.setString(5, this.getFileDescription());
                    callableStatement.setString(6, this.getFileExtension());
                    callableStatement.setString(7, this.getFileType());
                    callableStatement.setLong(8, this.getFileSize());
                    callableStatement.setString(9, this.getUserCeated());
                    callableStatement.setString(10, this.getUserType());
                    callableStatement.setString(11, this.getAttachmentCategory());		//NEW
                    callableStatement.registerOutParameter(12, Types.VARCHAR);
                    callableStatement.execute();
    
                    long errorCode = callableStatement.getLong(1);
    
                    if (errorCode != 0) {
                        String errorMessage = 
                            "Error adding file cabinet folder object association : ";
                        errorMessage = 
                                errorMessage + callableStatement.getString(8);
                        throw new SQLException(errorMessage);
                    }

                    //Commit DB insert
                    connection.commit();
                } catch (Exception ex) {
                    LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, 
                                                 getClass().getName(), "clone", 
                                                 ServletConfigUtil.COMPONENT_IMAGING, 
                                                 new Object[] { }, 
                                                 userErrorMsg + ". Roll back sequence started.", 
                                                 ex, LogMinderDOMUtil.VALUE_MIC);
                                                 
                    lastException = ex;
                    //Tracks if both Sling and DB transaction has been rolled back.
                    boolean isCleanRollback = true;
                    // Rollback database insert

                    // Try to rollback. Log any errors and proceed.
                    try {
                        if (connection != null) {
                            connection.rollback();
                        }
                    } catch (SQLException sqe) {
                        isCleanRollback = false;
                        LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, 
                                                     getClass().getName(), 
                                                     "clone", 
                                                     ServletConfigUtil.COMPONENT_IMAGING, 
                                                     new Object[] { }, 
                                                     "DB Rollback failed.", sqe, 
                                                     LogMinderDOMUtil.VALUE_MIC);
                    }
    
                    //Log the error message depending on whether both Sling and DB transactions were rolled back.
                    String rollbackMsg = 
                        (isCleanRollback ? "Rolled back successfully." : "Rolled back partially.");
    
                    LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, 
                                                 getClass().getName(), "clone", 
                                                 ServletConfigUtil.COMPONENT_IMAGING, 
                                                 new Object[] { }, 
                                                 userErrorMsg + ". " + rollbackMsg, null, 
                                                 LogMinderDOMUtil.VALUE_MIC);
                }
            }

            if (lastException != null){
                errorMsg = "All files could not be cloned";
                
                throw new FileSystemException(ExceptionImpl.FATAL, 
                                              errorMsg, lastException);
            }
        } catch (Exception ex) {
            if ("".equals(errorMsg)){
                errorMsg = "Failed to obtain file information for the source folder. Aborting folder cloning.";
            }
            LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, 
                                         getClass().getName(), 
                                         "clone", 
                                         ServletConfigUtil.COMPONENT_IMAGING, 
                                         new Object[] { }, 
                                         errorMsg, ex, 
                                         LogMinderDOMUtil.VALUE_MIC);
            throw new FileSystemException(ExceptionImpl.FATAL, 
                                          errorMsg, ex); 
        } finally {
            try {
                DBUtil.close(null,preparedStatement);
            } catch (SQLException sqe) {
                LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, 
                                             getClass().getName(), "clone", 
                                             ServletConfigUtil.COMPONENT_IMAGING, 
                                             new Object[] { }, 
                                             "Exception while closing the statement", 
                                             sqe, 
                                             LogMinderDOMUtil.VALUE_MIC);
            }
            try {
                DBUtil.close(null, callableStatement, connection);
            } catch (SQLException sqe) {
                LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, 
                                             getClass().getName(), "clone", 
                                             ServletConfigUtil.COMPONENT_IMAGING, 
                                             new Object[] { }, 
                                             "Exception while closing the connection", 
                                             sqe, 
                                             LogMinderDOMUtil.VALUE_MIC);
            }
        }
    }
    


    /**
     * Returns the total number of files existing in the virtual folder object id passed in the parameter.
     * @param user the user for whom the file count is to be retrieved.
     * @param folderObjectId the virtual folder object id whose file count is to be retrieved.
     * @return the file count
     * @throws Exception if any error occurs while processing
     */
    public static int getFilesCount(User user, 
                                    long folderObjectId) throws Exception {
        int filesCount = -1;
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            conn = ConnectionPool.getConnection(user);
            pst = conn.prepareStatement(QUERY_GET_FILESCOUNT);
            pst.setLong(1, folderObjectId);
            rs = pst.executeQuery();

            if (rs.next()) {
                filesCount = rs.getInt(1);
            }
        } finally {
            DBUtil.close(rs, pst, conn);
        }
        return filesCount;
    }

    /**
     * Adds the file to Sling for the user passed in the parameter.
     * @param user the user who wishes to store the file in Sling
     * @params sequenceVal the sequence number of the file about to be stored.
     * @return the Sling directory to which the file was added.
     * @throws FileSystemException if any error occurs while processing
     */
    private IDirectory addFileToSling(User user, 
                                    int sequenceVal) throws FileSystemException {
        IDirectory entityDir = getEntityDir(user);
        RepositoryAccess repositoryAccess = null;

        String slingFilePath = entityDir + PATH_SEPERATOR + this.file_name;
        OutputStream fos = null;

        try {
			HashMap<String, String> parameters = new HashMap<String, String>();
			String customerCode = CustomerConfigUtil.getInstance().getCustomerCode(user.getDomain());
			parameters.put(SlingConstants.SLING_SERVER_URL, CustomerConfigUtil.getInstance().getCustomerProperty(customerCode, ServletConfigUtil.COMPONENT_IMAGING, SlingConstants.SLING_SERVER_URL));
			parameters.put(SlingConstants.SLING_USER_NAME, CustomerConfigUtil.getInstance().getCustomerProperty(customerCode, ServletConfigUtil.COMPONENT_IMAGING, SlingConstants.SLING_USER_NAME));
			parameters.put(SlingConstants.SLING_PASSWORD, CustomerConfigUtil.getInstance().getCustomerProperty(customerCode, ServletConfigUtil.COMPONENT_IMAGING, SlingConstants.SLING_PASSWORD));
			parameters.put(SlingConstants.SLING_WORKSPACE, CustomerConfigUtil.getInstance().getCustomerProperty(customerCode, ServletConfigUtil.COMPONENT_IMAGING, SlingConstants.SLING_WORKSPACE));			
		
            repositoryAccess = CustomerCmsUtil.getInstance().getRepositoryAccess(customerCode, parameters, MIC_DIRECTORY_NAME);
            if (!repositoryAccess.exists(slingFilePath)) {
                String newFileName = sequenceVal + "_" + this.file_name;
                File tempFile = new File(this.tempDirPath + File.separator + newFileName);
                fos = new FileOutputStream(tempFile);
                FileUtil.streamCopy(this.fileInputStream, fos);
                fos.close();

                repositoryAccess.upload(entityDir.getAbsolutePath(), tempFile);
                this.setFilePath(this.getFilePath() + PATH_SEPERATOR + newFileName);
            } else {
                String errMsg = "File named " + this.getFileName() + " already exists. Unable to upload file. "
                        + "Please try again with a different file name.";
                throw new FileSystemException(ExceptionImpl.NON_FATAL, errMsg, null);
            }
        } catch (Throwable ioe) {
            LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, 
                    getClass().getName(), "addFileToSling", 
                    ServletConfigUtil.COMPONENT_IMAGING, 
                    new Object[] { }, 
                    "Error while closing...", 
                    ioe, 
                    LogMinderDOMUtil.VALUE_MIC);
        }
        return entityDir;
    }

    /**
     * Deletes the file from Sling for the user passed in the parameter
     * @param user the user who wishes to delete the file
     * @return the Sling directory of the deleted file
     * @throws FileSystemException if any error occurs while processing
     */
    private IDirectory deleteFileFromSling(User user) throws FileSystemException {
        RepositoryAccess repositoryAccess = null;

        String filePath = this.getFilePath();
        IDirectory existingFile = this.getFileFromSling(user, filePath);
        if (existingFile == null || !existingFile.isFile()) {
            throw new FileSystemException(ExceptionImpl.FATAL, 
                                          "Cannot find file in path - " + 
                                          this.getFilePath(), null);
        } else {
            String dirPath = existingFile.getAbsolutePath().substring(0, existingFile.getAbsolutePath().lastIndexOf("/"));
            List<String> children = null;
            try {
				HashMap<String, String> parameters = new HashMap<String, String>();
				String customerCode = CustomerConfigUtil.getInstance().getCustomerCode(user.getDomain());
				parameters.put(SlingConstants.SLING_SERVER_URL, CustomerConfigUtil.getInstance().getCustomerProperty(customerCode, ServletConfigUtil.COMPONENT_IMAGING, SlingConstants.SLING_SERVER_URL));
				parameters.put(SlingConstants.SLING_USER_NAME, CustomerConfigUtil.getInstance().getCustomerProperty(customerCode, ServletConfigUtil.COMPONENT_IMAGING, SlingConstants.SLING_USER_NAME));
				parameters.put(SlingConstants.SLING_PASSWORD, CustomerConfigUtil.getInstance().getCustomerProperty(customerCode, ServletConfigUtil.COMPONENT_IMAGING, SlingConstants.SLING_PASSWORD));
				parameters.put(SlingConstants.SLING_WORKSPACE, CustomerConfigUtil.getInstance().getCustomerProperty(customerCode, ServletConfigUtil.COMPONENT_IMAGING, SlingConstants.SLING_WORKSPACE));			
			
                repositoryAccess = CustomerCmsUtil.getInstance().getRepositoryAccess(customerCode, parameters, MIC_DIRECTORY_NAME);
                if (repositoryAccess.exists(existingFile.getAbsolutePath()) == true) {
                    if (!"".equalsIgnoreCase(dirPath)) {
                        RepositoryAccessResponse accessResponse = repositoryAccess.list(dirPath);
                        children = accessResponse.dir();
                        // Delete the file from Sling first
                        if (children.size() > 1) {
                            repositoryAccess.delete(existingFile.getAbsolutePath());
                        } else {
                            repositoryAccess.delete(dirPath);
                        }
                    }
                } else {
                    throw new FileSystemException(ExceptionImpl.FATAL, "Cannot find file in path - "
                            + this.getFilePath(), null);
                }
            } catch (Throwable ioe) {
                LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, 
                        getClass().getName(), "deleteFileFromSling", 
                        ServletConfigUtil.COMPONENT_IMAGING, 
                        new Object[] { }, 
                        "Error while closing...", 
                        ioe, 
                        LogMinderDOMUtil.VALUE_MIC);
            }
            return existingFile;
        }
    }

    /**
     * Retrieves an existing file from Sling for the user and the given path.
     * @param user the user for whom the file is to be fetched
     * @param fullFilePath the full file path where the file is stored in Sling
     * @throws FileSystemException if any error occurs while processing
     */
    public void fetchFileDataFromSling(User user, 
                                     String fullFilePath) throws FileSystemException {
        IDirectory file = this.getFileFromSling(user, fullFilePath);

        if (file == null) {
            throw new FileSystemException(ExceptionImpl.FATAL, 
                                          "Cannot find file in path - " + 
                                          fullFilePath, null);
        }

        if (!file.isFile()) {
            throw new FileSystemException(ExceptionImpl.FATAL, 
                                          "Not a valid file. - " + 
                                          fullFilePath, null);
        }


        try {
            if (this.fileInputStream != null) {
                this.fileInputStream.close();
            }
        } catch (IOException e) {
            // Ignore
        }

        this.fileInputStream = file.getFileAsStream();
        this.setFileSize(-1);
        this.setFileName(file.getName());
        this.setFilePath(file.getAbsolutePath());
    }

    /**
     * Retrieves the Sling directory under which the file should be stored or retrieved for the given user
     * @param user the user whose Sling storage directory is to be retrieved.
     * @return the Sling drectoty for the given user
     * @throws FileSystemException if any error occurs while processing
     */
    private IDirectory getEntityDir(User user) throws FileSystemException {
        CMSDirectory root = new CMSDirectory(user, LogMinderDOMUtil.VALUE_MIC);
        IDirectory fileCabinetDir = 
            root.getDirectory(FOLDER_NAME_FILE_CABINET);
        if (fileCabinetDir == null) {
            fileCabinetDir = root.addDirectory(FOLDER_NAME_FILE_CABINET);
        }

        IDirectory entityTypeDir = 
            fileCabinetDir.getDirectory(this.entityType);
        if (entityTypeDir == null) {
            entityTypeDir = fileCabinetDir.addDirectory(this.entityType);
        }

        IDirectory entityReferenceDir = 
            entityTypeDir.getDirectory(this.entityReference);
        if (entityReferenceDir == null) {
            entityReferenceDir = 
                    entityTypeDir.addDirectory(this.entityReference);
        }

        return entityReferenceDir;
    }

    /**
     * Retrieves the folder name under which the file will be stored or retrieved.
     * @return the folder name under which the file will be stored or retrieved.
     */
    private String getFolderName() {
        return IDirectory.SEPARATOR + "file cabinet" + IDirectory.SEPARATOR + 
            entityType + IDirectory.SEPARATOR + entityReference;
    }

    /**
     * Returns the file object from Sling for the given parameters
     * @param user the user for whom the file is to be retrieved
     * @param fullFilePath the full path of the file stored in Sling
     * @return thefile stored in Sling
     * @throws FileSystemException if any error occurs while processing
     */
    private IDirectory getFileFromSling(User user, 
                                      String fullFilePath) throws FileSystemException {
        CMSDirectory root = new CMSDirectory(user, LogMinderDOMUtil.VALUE_MIC);
        IDirectory file = root.getDirectory(fullFilePath);
        return file;
    }

    /**
     * Retrieves the value of the <code>S_SlingConstants.SLING_FILE_CABINET</code>
     * sequence, which is used to store the file in the Sling Path
     * @param user the user for whom the file is to be stored.
     * @return the next value of the <code>S_SlingConstants.SLING_FILE_CABINET</code> sequence.
     */
    private int fetchSequenceVal(User user, Connection conn) {
        int sequenceVal = -1;
        Statement pst = null;
        ResultSet rs = null;

        try {
            pst = conn.createStatement();

            rs = pst.executeQuery(QUERY_FETCH_SEQUENCEVAL);

            if (rs.next()) {
                sequenceVal = rs.getInt(1);
            }
        } catch (SQLException e) {

        } finally {
            try {
                DBUtil.close(rs, pst);

            } catch (SQLException sql) {
            }
        }
        return sequenceVal;
    }
    
    /**
     * Retrieves the value of the <code>MFF_FILE_SIZE</code>
     * file size, which is stored while file uploading
     * @param user the user for whom the file is to be stored.
     * @filePath full path of file to be downloaded.
     * @return the next value of the <code>MFF_FILE_SIZE</code> sequence.
     */
    public long fetchFileSize(User user,String filePath){
        long fileSize=-1;
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        
        try {
            conn = ConnectionPool.getConnection(user);
            pst = conn.prepareStatement(QUERY_FETCH_FILE_SIZE);
            pst.setString(1,filePath);
            rs = pst.executeQuery();

            if (rs.next()) {
                fileSize = rs.getInt(1);
            }
        } catch (SQLException e) {

        }catch (NamingException ne) {

        }finally {
            try {
                DBUtil.close(rs, pst);

            } catch (SQLException sql) {
            }
        }
        
        return fileSize;
    }
    private boolean isFileExistInSling(User user) {
        IDirectory existingFile;
        try {
            existingFile = this.getFileFromSling(user, this.getFilePath());
            if (existingFile == null || !existingFile.isFile()) {
                return false;
            }
        } catch (FileSystemException e) {
            return false;
        }
        
        return true;
    }
    
    public int validateAttachment(User user, long folderObjectsId, String fileName, String isSupplement) throws Exception {
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        int responseCode = 0;

        try {
            if (null != isSupplement && !"".equals(isSupplement) && "true".equalsIgnoreCase(isSupplement)) {
                if((fileName.toLowerCase()).lastIndexOf(SUPPLEMENT_FILE_POSTFIX) < 0){
                    responseCode = 1;
                } else if((fileName.toLowerCase()).lastIndexOf(SUPPLEMENT_FILE_POSTFIX) > 0) {
                    fileName = fileName.substring(0, ((fileName.toLowerCase()).indexOf(SUPPLEMENT_FILE_POSTFIX))) + ".DOCX";
                    conn = ConnectionPool.getConnection(user);
                    pst = conn.prepareStatement("SELECT COUNT(1) FROM MIS_FOLDER_OBJECTS_FILES_ASSN WHERE MFF_FOLDER_OBJECT_ID = ? AND UPPER(MFF_FILE_NAME) = UPPER(?)");
                    pst.setLong(1, folderObjectsId);
                    pst.setString(2, fileName);
                    rs = pst.executeQuery();
                    if (rs.next()) {
                        if(rs.getInt(1) == 0 )
                            responseCode = 3;
                    }
                }
            } else {
                if((fileName.toLowerCase()).lastIndexOf(SUPPLEMENT_FILE_POSTFIX) > 0){
                    responseCode = 2;
                }
            }
        } catch(SQLException ex) {
            ex.printStackTrace();
            throw ex;
        }finally {
            DBUtil.close(rs, pst, conn);
        }
        return responseCode;
    }
    
    /*
     * Get additional details from Customer Maintained table
     */
    public Map<String, String> getFileExtensionMimeType(User user) 
    		throws Exception {
    	HashMap<String, String> mimeTypeMap = new HashMap<String, String>();
    	Connection conn = null;
    	PreparedStatement psmt = null;
        ResultSet rs = null;
        String sql = "SELECT smt_mime_type, smt_file_extension FROM SHL_MIME_TYPES";
        String fileExtension = null;
        String mimeType = null;
        
    	try {
    		conn = ConnectionPool.getConnection(user);
    		psmt = conn.prepareStatement(sql);
            rs = psmt.executeQuery();
            while (rs.next()) {
            	fileExtension = rs.getString("smt_file_extension");
            	mimeType = rs.getString("smt_mime_type");
            	fileExtension = (fileExtension == null) ? null : fileExtension.toLowerCase().trim();
            	mimeType = (mimeType == null) ? null : mimeType.toLowerCase().trim();
            	if ( fileExtension != null ) {
            		mimeTypeMap.put(fileExtension, mimeType);
            	}
            }
        } catch (Exception e) {
            throw new Exception("Error while getting data from SHL_MIME_TYPES table " + e.getMessage());
        } finally {
        	DBUtil.close(rs, psmt, conn);
        }
    	
    	return mimeTypeMap;
    }
	
	//New Attachment Category code
	public Map<String,String>  getFileCategory(User user)throws Exception{
    	Connection conn   = null;
    	PreparedStatement pst = null;
    	ResultSet rs = null;
    	Map<String,String> map = new HashMap<String, String>();
        try {
        	
        	String sql = " Select ATTACHMENT_CAT_ID,ATTACHMENT_CAT_DESC from IEL_PI_MIC_ATTACHMNT_CATEG";
            conn  = ConnectionPool.getConnection(user);
            pst   = conn.prepareStatement(sql);
                    
            rs = pst.executeQuery();
            while (rs.next()){
            	
            	map.put(rs.getString(1), rs.getString(2));
            	
            }
            
             
        } catch (Exception ex) {
            LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                getClass().getName(), "getAttachCategory",
                ServletConfigUtil.COMPONENT_PORTAL,
                new Object[] {},
                "Error occurred while getting Attachment Category .", ex,
                LogMinderDOMUtil.VALUE_MIC);
            throw ex;
        } finally {
            DBUtil.close(null, pst, conn);
            DBUtil.close(rs,null);
        }
        
        return map;
    }
    
}
