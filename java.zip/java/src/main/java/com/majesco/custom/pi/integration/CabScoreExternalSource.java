package com.majesco.custom.pi.integration;

import java.util.Map;

import com.coverall.datatypes.NestedStringMap;
import com.coverall.mt.events.EventProcessorUtility;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.pct.server.service.IPCTServerLogger;
import com.coverall.pctv2.client.exceptions.ExternalSourceException;
import com.coverall.pctv2.server.expression.es.ExternalSourceHelper;
import com.coverall.pctv2.server.expression.es.IPCTExternalSourceImplementor;
import com.coverall.pctv2.server.service.IPCTRequestContext;
import com.coverall.pctv2.server.service.PCTRequestContext;
import com.coverall.pctv2.server.service.PCTSession;
import com.majesco.custom.pi.integration.constants.CabScoreConstants;
import com.majesco.custom.pi.integration.constants.ValenScoreConstants;

public class CabScoreExternalSource implements IPCTExternalSourceImplementor {
	private String RESPONSE_CODE = null;
	IPCTRequestContext reqContext = PCTRequestContext.getContext();
	PCTSession session = reqContext.getPCTSession();
	IPCTServerLogger logger = reqContext.getLogger();

	public void call(Map<String, String> inParams, Map<String, String> outParams) throws ExternalSourceException {

		LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, CabScoreExternalSource.class.getName(), "call ",
				ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { inParams },
				"call  from CabScoreExternalSource Started:" + inParams, null, LogMinderDOMUtil.VALUE_MIC);

		if (inParams == null) {

			outParams.clear();
		} else {
			try {
				String entityReference = reqContext.getEntityReference();

				String entityType = reqContext.getEntityType();
				String score = "";
				if (validateInputData(inParams)) {
					User user = reqContext.getUser();
					int activityId = -1;
					if (user == null || entityReference == null) {
						outParams.clear();
						throw new ExternalSourceException("User Object or entity reference is null");
					} else {
						if (null != entityType
								&& ("QUOTE".equalsIgnoreCase(entityType) || "POLICY".equalsIgnoreCase(entityType))) {

							try {
								String dotNumber = (String) inParams.get("dotNumber");
								NestedStringMap otherEventData = new NestedStringMap();
								otherEventData.put(USER, user.getFullName());
								otherEventData.put(ENTITY_TYPE, reqContext.getEntityType());
								otherEventData.put(ENTITY_REFERENCE, entityReference);
								otherEventData.put(CabScoreConstants.DOT_NUMBER, dotNumber);

								reqContext.getLogger().logInfo(getClass(), "call",
										new Object[] { otherEventData, outParams }, "Ready to call CAB Score Service");

								// First delete the completed activity, if any
								EventProcessorUtility.deleteCompletedActivity(entityType, entityReference,
										CabScoreConstants.CABSCOREREPORTEVENT, user);

								activityId = EventProcessorUtility.addActivity(entityType, entityReference,
										CabScoreConstants.CABSCOREREPORTEVENT,
										EventProcessorUtility.ACTIVITY_TYPE_MANUAL, otherEventData.toString(), user,
										reqContext.getConnection());
								LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
										CabScoreExternalSource.class.getName(), "call ",
										ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { inParams },
										"activityId:" + activityId, null, LogMinderDOMUtil.VALUE_MIC);

								Map responseMap = ExternalSourceHelper.getEventResponse(activityId);

								LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
										CabScoreExternalSource.class.getName(), "responseMap value: " + responseMap,
										ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { inParams },
										"responseMap:" + responseMap, null, LogMinderDOMUtil.VALUE_MIC);

								if (responseMap != null) {
									outParams.put(CabScoreConstants.DOT_NUMBER,
											(String) responseMap.get(CabScoreConstants.DOT_NUMBER));

									if (responseMap.containsKey(STATUS_CODE)) {
										RESPONSE_CODE = (String) responseMap.get(STATUS_CODE);
									}

									if (responseMap.containsKey("score")) {
										score = (String) responseMap.get("score");

									}

								}
								outParams.put("score", score);

								reqContext.getLogger().logInfo(getClass(), "call", new Object[] { activityId },
										"Made call to cab Score Service");

								if (null != RESPONSE_CODE && !RESPONSE_CODE.equals("200")) {
									boolean isAgentUser = ExternalSourceHelper.userHasRole(AGENT_ROLE);
									if (isAgentUser) {

										logger.logInfo(getClass(), "call",
												new Object[] { reqContext.getEntityType(),
														reqContext.getEntityReference(), inParams, outParams, user,
														RESPONSE_CODE, ValenScoreConstants.VALEN_SERVICE_NAME },
												"Got response from WebService" + AGENT_ERROR_MESSAGE + " Status Code : "
														+ RESPONSE_CODE);
									} else {

										logger.logInfo(getClass(), "call",
												new Object[] { reqContext.getEntityType(),
														reqContext.getEntityReference(), inParams, outParams, user,
														ValenScoreConstants.VALEN_SERVICE_NAME },
												"Got response from WebService" + AGENT_ERROR_MESSAGE + " Status Code : "
														+ RESPONSE_CODE);
									}
								}

							} catch (Exception e) {

								logger.logInfo(getClass(), "call",
										new Object[] { reqContext.getEntityType(), reqContext.getEntityReference(),
												inParams, outParams, user, ValenScoreConstants.VALEN_SERVICE_NAME },
										" Please Save the current work and suspend the " + reqContext.getEntityType()
												+ "until issue resolves." + " Status Code : " + RESPONSE_CODE);
							}
							logger.logInfo(getClass(), "call",
									new Object[] { reqContext.getEntityType(), reqContext.getEntityReference(),
											inParams, outParams, user, ValenScoreConstants.VALEN_SERVICE_NAME },
									"Got response from WebService");
						}

					}

				} else {
					logger.logInfo(
							getClass(), "call", new Object[] { reqContext.getEntityType(),
									reqContext.getEntityReference(), inParams, outParams },
							ValenScoreConstants.ERROR_MISSING_PARAMETERS);
					outParams.clear();
				}
			} finally {
				logger.logExiting(getClass(), "call", new Object[] { reqContext.getEntityType(),
						reqContext.getEntityReference(), inParams, outParams }, "Exiting call");
				session.clearStatusMsg();
			}
		}

	}

	private boolean validateInputData(Map<String, String> inParams) {
		boolean returnVal = false;
		if (inParams.size() == 0) {
			return returnVal;
		}
		return true;
	}

}
