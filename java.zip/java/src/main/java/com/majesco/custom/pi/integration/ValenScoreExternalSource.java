package com.majesco.custom.pi.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import com.coverall.datatypes.NestedStringMap;
import com.coverall.mt.events.EventProcessorUtility;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.pct.server.service.IPCTServerLogger;
import com.coverall.pctv2.client.exceptions.ExternalSourceException;
import com.coverall.pctv2.server.expression.es.ExternalSourceHelper;
import com.coverall.pctv2.server.expression.es.IPCTExternalSourceImplementor;
import com.coverall.pctv2.server.service.IPCTRequestContext;
import com.coverall.pctv2.server.service.PCTRequestContext;
import com.coverall.pctv2.server.service.PCTSession;
import com.majesco.custom.pi.integration.constants.ValenScoreConstants;
import com.majesco.custom.pi.integration.model.Classification;
import com.majesco.custom.pi.integration.model.State;
import com.coverall.util.DBUtil;

public class ValenScoreExternalSource implements IPCTExternalSourceImplementor {
	private String RESPONSE_CODE = null;
	IPCTRequestContext reqContext = PCTRequestContext.getContext();
	PCTSession session = reqContext.getPCTSession();
	IPCTServerLogger logger = reqContext.getLogger();

	public void call(Map<String, String> inParams, Map<String, String> outParams) throws ExternalSourceException {
		LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, ValenScoreExternalSource.class.getName(),
				"call ", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { inParams },
				"call  from ValenScoreExternalSource Started"+inParams, null,
				LogMinderDOMUtil.VALUE_MIC);
		
		if (inParams == null) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, ValenScoreExternalSource.class.getName(),
					"call ", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { inParams },
					ValenScoreConstants.ERROR_MISSING_PARAMETERS, null,
					LogMinderDOMUtil.VALUE_MIC);
			
			outParams.clear();
		} else {
			try {
				String entityReference = reqContext.getEntityReference();
				String entityType = reqContext.getEntityType();
				if (validateInputData(inParams)) {
					User user = reqContext.getUser();
					int activityId = -1;
					if (user == null || entityReference == null) {
						outParams.clear();
						throw new ExternalSourceException("User Object or entity reference is null");
					} else {
						if (null != entityType
								&& ("QUOTE".equalsIgnoreCase(entityType) || "POLICY".equalsIgnoreCase(entityType))) {

							try {
								String available_history_1 = (String) inParams.get(ValenScoreConstants.AVAILABLE_HISTORY_ONE);
								LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, ValenScoreExternalSource.class.getName(),
										"available_history_1 ", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { available_history_1 },
										"available_history_1:"+available_history_1, null,
										LogMinderDOMUtil.VALUE_MIC);
								String available_history_2 = (String) inParams.get(ValenScoreConstants.AVAILABLE_HISTORY_TWO);
								LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, ValenScoreExternalSource.class.getName(),
										"available_history_2 ", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { available_history_2 },
										"available_history_2:"+available_history_2, null,
										LogMinderDOMUtil.VALUE_MIC);
								String available_history_3 = (String) inParams.get(ValenScoreConstants.AVAILABLE_HISTORY_THREE);
								LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, ValenScoreExternalSource.class.getName(),
										"available_history_3 ", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { available_history_3 },
										"available_history_3:"+available_history_3, null,
										LogMinderDOMUtil.VALUE_MIC);
								String new_renew_flag = (String) inParams.get(ValenScoreConstants.NEW_RENEW_FLAG);
								LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, ValenScoreExternalSource.class.getName(),
										"new_renew_flag ", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { new_renew_flag },
										"new_renew_flag:"+new_renew_flag, null,
										LogMinderDOMUtil.VALUE_MIC);
								String non_zero_claim_count_1 = (String) inParams.get(ValenScoreConstants.NON_ZERO_CLAIM_COUNT_ONE);
								LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, ValenScoreExternalSource.class.getName(),
										"non_zero_claim_count_1 ", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { non_zero_claim_count_1 },
										"non_zero_claim_count_1:"+non_zero_claim_count_1, null,
										LogMinderDOMUtil.VALUE_MIC);
								String non_zero_claim_count_2 = (String) inParams.get(ValenScoreConstants.NON_ZERO_CLAIM_COUNT_TWO);
								LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, ValenScoreExternalSource.class.getName(),
										"non_zero_claim_count_2 ", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { non_zero_claim_count_2 },
										"non_zero_claim_count_2:"+non_zero_claim_count_2, null,
										LogMinderDOMUtil.VALUE_MIC);
								String non_zero_claim_count_3 = (String) inParams.get(ValenScoreConstants.NON_ZERO_CLAIM_COUNT_THREE);
								LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, ValenScoreExternalSource.class.getName(),
										"non_zero_claim_count_3 ", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { non_zero_claim_count_3 },
										"non_zero_claim_count_3:"+non_zero_claim_count_3, null,
										LogMinderDOMUtil.VALUE_MIC);
								String original_policy_term_number = (String) inParams
										.get(ValenScoreConstants.ORIGINAL_POLICY_TERM_NUMBER);
								LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, ValenScoreExternalSource.class.getName(),
										"original_policy_term_number ", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { original_policy_term_number },
										"original_policy_term_number:"+original_policy_term_number, null,
										LogMinderDOMUtil.VALUE_MIC);
								String policy_state_code = (String) inParams.get(ValenScoreConstants.POLICY_STATE_CODE);
								LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, ValenScoreExternalSource.class.getName(),
										"policy_state_code ", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { policy_state_code },
										"policy_state_code:"+policy_state_code, null,
										LogMinderDOMUtil.VALUE_MIC);
								String policy_zip_code = (String) inParams.get(ValenScoreConstants.POLICY_ZIP_CODE);
								LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, ValenScoreExternalSource.class.getName(),
										"policy_zip_code ", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { policy_zip_code },
										"policy_zip_code:"+policy_zip_code, null,
										LogMinderDOMUtil.VALUE_MIC);
								String term_effective_date = (String) inParams.get(ValenScoreConstants.TERM_EFFECTIVE_DATE);
								LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, ValenScoreExternalSource.class.getName(),
										"term_effective_date ", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { term_effective_date },
										"term_effective_date:"+term_effective_date, null,
										LogMinderDOMUtil.VALUE_MIC);
								
								NestedStringMap otherEventData = new NestedStringMap();
								otherEventData.put(USER, user.getFullName());
								otherEventData.put(ENTITY_TYPE, reqContext.getEntityType());
								otherEventData.put(ENTITY_REFERENCE, entityReference);
								otherEventData.put(ValenScoreConstants.AVAILABLE_HISTORY_ONE, available_history_1);
								otherEventData.put(ValenScoreConstants.AVAILABLE_HISTORY_TWO, available_history_2);
								otherEventData.put(ValenScoreConstants.AVAILABLE_HISTORY_THREE, available_history_3);
								otherEventData.put(ValenScoreConstants.NEW_RENEW_FLAG, new_renew_flag);
								otherEventData.put(ValenScoreConstants.NON_ZERO_CLAIM_COUNT_ONE,
										non_zero_claim_count_1);
								otherEventData.put(ValenScoreConstants.NON_ZERO_CLAIM_COUNT_TWO,
										non_zero_claim_count_2);
								otherEventData.put(ValenScoreConstants.NON_ZERO_CLAIM_COUNT_THREE,
										non_zero_claim_count_3);
								otherEventData.put(ValenScoreConstants.ORIGINAL_POLICY_TERM_NUMBER,
										original_policy_term_number);
								otherEventData.put(ValenScoreConstants.POLICY_STATE_CODE, policy_state_code);
								otherEventData.put(ValenScoreConstants.POLICY_ZIP_CODE, policy_zip_code);
								otherEventData.put(ValenScoreConstants.TERM_EFFECTIVE_DATE, term_effective_date);
								
								otherEventData.put(ValenScoreConstants.TERM_EFFECTIVE_DATE, term_effective_date);
								
								reqContext.getLogger().logInfo(getClass(), "call",
										new Object[] { otherEventData, outParams }, "Ready to Valen Score Service");

								// First delete the completed activity, if any
								EventProcessorUtility.deleteCompletedActivity(entityType, entityReference,
										ValenScoreConstants.VALENSCOREREPORTEVENT, user);

								activityId = EventProcessorUtility.addActivity(entityType, entityReference,
										ValenScoreConstants.VALENSCOREREPORTEVENT,
										EventProcessorUtility.ACTIVITY_TYPE_MANUAL, otherEventData.toString(), user,
										reqContext.getConnection());
								LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, ValenScoreExternalSource.class.getName(),
										"call ", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { activityId },
										"ValenScoreExternalSource Started"+activityId, null,
										LogMinderDOMUtil.VALUE_MIC);

								Map responseMap = ExternalSourceHelper.getEventResponse(activityId);
								if (responseMap != null) {
									outParams.put(ValenScoreConstants.VALEN_SCORE,
											(String) responseMap.get(ValenScoreConstants.VALEN_SCORE));
									outParams.put(ValenScoreConstants.VALEN_BIN,
											(String) responseMap.get(ValenScoreConstants.VALEN_BIN));
									outParams.put(ValenScoreConstants.MIS_CLASSIFICATION_SCORE,
											(String) responseMap.get(ValenScoreConstants.MIS_CLASSIFICATION_SCORE));

									if (responseMap.containsKey(STATUS_CODE)) {
										RESPONSE_CODE = (String) responseMap.get(STATUS_CODE);
									}
								}

								reqContext.getLogger().logInfo(getClass(), "call", new Object[] { activityId },
										"Made call to Valen Score Service");

								if (null != RESPONSE_CODE && !RESPONSE_CODE.equals("200")) {
									boolean isAgentUser = ExternalSourceHelper.userHasRole(AGENT_ROLE);
									if (isAgentUser) {

										logger.logInfo(getClass(), "call",
												new Object[] { reqContext.getEntityType(),
														reqContext.getEntityReference(), inParams, outParams, user,
														RESPONSE_CODE, ValenScoreConstants.VALEN_SERVICE_NAME },
												"Got response from WebService" + AGENT_ERROR_MESSAGE + " Status Code : "
														+ RESPONSE_CODE);
									} else {

										logger.logInfo(getClass(), "call",
												new Object[] { reqContext.getEntityType(),
														reqContext.getEntityReference(), inParams, outParams, user,
														ValenScoreConstants.VALEN_SERVICE_NAME },
												"Got response from WebService" + AGENT_ERROR_MESSAGE + " Status Code : "
														+ RESPONSE_CODE);
									}
								}

							} catch (Exception e) {

								logger.logInfo(getClass(), "call",
										new Object[] { reqContext.getEntityType(), reqContext.getEntityReference(),
												inParams, outParams, user, ValenScoreConstants.VALEN_SERVICE_NAME },
										" Please Save the current work and suspend the " + reqContext.getEntityType()
												+ "until issue resolves." + " Status Code : " + RESPONSE_CODE);
							}
							logger.logInfo(getClass(), "call",
									new Object[] { reqContext.getEntityType(), reqContext.getEntityReference(),
											inParams, outParams, user, ValenScoreConstants.VALEN_SERVICE_NAME },
									"Got response from WebService");
						}

					}

				} else {
					logger.logInfo(
							getClass(), "call", new Object[] { reqContext.getEntityType(),
									reqContext.getEntityReference(), inParams, outParams },
							ValenScoreConstants.ERROR_MISSING_PARAMETERS);
					outParams.clear();
				}
			} finally {
				logger.logExiting(getClass(), "call", new Object[] { reqContext.getEntityType(),
						reqContext.getEntityReference(), inParams, outParams }, "Exiting call");
				session.clearStatusMsg();
			}
		}

	}

	private boolean validateInputData(Map<String, String> inParams) {
		boolean returnVal = false;
		if (inParams.size() == 0) {
			return returnVal;
		}
		return true;
	}
	
	

}
