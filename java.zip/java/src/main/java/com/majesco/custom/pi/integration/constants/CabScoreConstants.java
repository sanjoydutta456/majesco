package com.majesco.custom.pi.integration.constants;

public class CabScoreConstants {
	
	public static final String ERROR_MISSING_PARAMETERS = "Cab score cannot be order as the required information is missing";
	public static final String CAB_SERVICE_NAME = "MIC - INTERNAL - WS - SCORE - CAB";
	public static final String CABSCOREREPORTEVENT = "CABSCOREREPORTEVENT";
	
	public static final String DOT_NUMBER  = "dotNumber";
	public static final String WEB_SERVICE_RESPONSE = "WEB_SERVICE_RESPONSE";
	public static final String WEB_SERVICE_REQUEST = "WEB_SERVICE_REQUEST";
	
	
	
	
	
	
	
}
