package com.majesco.custom.pi.integration.constants;

public class ValenScoreConstants {
	
	public static final String ERROR_MISSING_PARAMETERS = "Valen score cannot be order as the required information is missing";
	public static final String VALEN_SERVICE_NAME = "MIC - INTERNAL - WS - SCORE - VALEN";
	public static final String VALENSCOREREPORTEVENT = "VALENSCOREREPORTEVENT";
	
	public static final String VALEN_SCORE  = "VALEN_SCORE";
	public static final String VALEN_BIN   = "VALEN_BIN";
	public static final String MIS_CLASSIFICATION_SCORE  = "MIS_CLASSIFICATION_SCORE";
	
	public static final String WEB_SERVICE_RESPONSE = "WEB_SERVICE_RESPONSE";
	public static final String WEB_SERVICE_REQUEST = "WEB_SERVICE_REQUEST";
	
	public static final String AVAILABLE_HISTORY_ONE  = "available_history_1";
	public static final String AVAILABLE_HISTORY_TWO  = "available_history_2";
	public static final String AVAILABLE_HISTORY_THREE  = "available_history_3";
	public static final String NEW_RENEW_FLAG  = "new_renew_flag";
	public static final String NON_ZERO_CLAIM_COUNT_ONE  = "non_zero_claim_count_1";
	public static final String NON_ZERO_CLAIM_COUNT_TWO  = "non_zero_claim_count_2";
	public static final String NON_ZERO_CLAIM_COUNT_THREE  = "non_zero_claim_count_3";
	public static final String POLICY_STATE_CODE  = "policy_state_code";
	public static final String POLICY_ZIP_CODE  = "policy_zip_code";
	public static final String TERM_EFFECTIVE_DATE  = "term_effective_date";
	public static final String ORIGINAL_POLICY_TERM_NUMBER  = "original_policy_term_number";
	
	
	
	
	
}
