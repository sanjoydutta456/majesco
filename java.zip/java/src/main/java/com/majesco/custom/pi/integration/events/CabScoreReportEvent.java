package com.majesco.custom.pi.integration.events;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.HashMap;
import java.util.Map;
import com.coverall.datatypes.NestedStringMap;
import com.coverall.exceptions.JDBCException;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.events.EventProcessor;
import com.coverall.mt.events.EventResponse;
import com.coverall.mt.events.EventResponseDetails;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.webservices.WebServiceDAO;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;
import com.majesco.custom.pi.integration.constants.CabScoreConstants;
import com.majesco.pi.webservices.score.CabScoreAPIServiceClient;

public class CabScoreReportEvent extends EventProcessor {

	private static final String NAME_WEBSERVICE = "MIC - INTERNAL - WS - SCORE - CAB";
	private static final String RESPONSE_VALUES_MAP = "responseValuesMap";
	public static final String REQUEST_ID = "REQUEST_ID";
	public static final String RESPONSE_RECEIVED = "RESPONSE_RECEIVED";
	public static final String STATUS_CODE = "STATUS_CODE";
	private static final String CLASS_NAME = EventProcessor.class.getName();

	@Override
	public EventResponse execute(String xmlMessage, HashMap params) throws Exception {
		LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "CabScoreReportEvent execute",
				ServletConfigUtil.COMPONENT_FRAMEWORK, null, "CabScoreReportEvent execute", null,
				LogMinderDOMUtil.VALUE_MIC);

		EventResponseDetails eventResponse = new EventResponseDetails();

		User user = (User) params.get("User");
		String entityType = params.get("ENTITY_TYPE").toString();
		String entityReference = params.get("ENTITY_REFERENCE").toString(); // ENTITY_REFERENCE
		String dotNumber = (String) params.get(CabScoreConstants.DOT_NUMBER);

		Map responseMap = new HashMap();
		CabScoreAPIServiceClient client = new CabScoreAPIServiceClient();
		String RiskID = null;
		responseMap = client.cabScoreReport(dotNumber, entityType, entityReference, user, params);
		eventResponse.setIsSuccess(true);

		LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "CabScoreReportEvent execute",
				ServletConfigUtil.COMPONENT_FRAMEWORK, null, "CabScoreReportEvent execute:::" + responseMap, null,
				LogMinderDOMUtil.VALUE_MIC);
		// {score=94, CAB_ENTITY_TYPE=QUOTE, CAB_ENTITY_REFERENCE=Q01WK0000001780000,
		// CAB_ID=14, CAB_STATUS_CODE=200, ResponseReceived=Y}
		params.put("score", responseMap.get("score").toString());
		params.put(REQUEST_ID, responseMap.get("CAB_ID").toString());
		params.put(RESPONSE_RECEIVED, responseMap.get("ResponseReceived").toString());
		params.put(STATUS_CODE, responseMap.get("CAB_STATUS_CODE").toString());

		return eventResponse;
	}

	@Override
	public EventResponse processEvent(HashMap params) throws Exception {

		int webserviceId;
		User user = null;
		HashMap config = null;
		String xmlMessage = null;
		EventResponseDetails eventResponse = new EventResponseDetails();
		user = (User) params.get("User");
		webserviceId = Integer.parseInt(params.get("WEE_PROCESSOR_ID").toString());
		config = WebServiceDAO.getWSGeneralParameters(user, webserviceId);

		LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, CabScoreReportEvent.class.getName(),
				"CABScoreReportEvent", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { "", "" },
				"processEvent of getWSGeneralParameters started:" + config, null, LogMinderDOMUtil.VALUE_MIC);

		params.putAll(config);

		boolean shouldCallWebService = new Boolean((String) config.get("Call web service")).booleanValue();

		if (shouldCallWebService) {
			eventResponse = (EventResponseDetails) execute(xmlMessage, params);

			if (eventResponse.isIsSuccess()) {
				postProcessEvent(params, eventResponse);
			} else {
				return eventResponse;
			}
			postProcessEvent(params, eventResponse);
		} else {
			eventResponse.setIsSuccess(true);
			eventResponse.setResponse("Did not execute since WS Param callwebservice=" + shouldCallWebService);

		}
		return eventResponse;

	}

	@Override
	public String getWebServiceName() {
		LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(),
				"Did not execute since WS Param callwebservice= ", ServletConfigUtil.COMPONENT_FRAMEWORK, null,
				"getWebServiceName", null, LogMinderDOMUtil.VALUE_MIC);
		return NAME_WEBSERVICE;
	}

	@Override
	public void postProcessEvent(HashMap params, EventResponse response) throws Exception {

		/*
		 * {WEA_OTHER_EVENT_DATA={ENTITY_REFERENCE=Q01WK0000001780000,
		 * USER=admin@protectiveinsurance.com, dotNumber=70559, ENTITY_TYPE=QUOTE},
		 * ENTITY_REFERENCE=Q01WK0000001780000, User=admin@protectiveinsurance.com, Call
		 * web service=true, WEA_ID=1245, WEE_PROCESSOR_TYPE=WEBSERVICE, REQUEST_ID=16,
		 * client_id=0oa3h231c4uyUOadk1d7, WEA_ENTITY_TYPE=QUOTE,
		 * WEE_PROCESS_RETRY_INTERVAL=1, score=94,
		 * WEA_ENTITY_REFERENCE=Q01WK0000001780000, grant_type=client_credentials,
		 * DB_CONNECTION=org.jboss.jca.adapters.jdbc.jdk7.WrappedConnectionJDK7@
		 * 36d2af8f, WEA_TRANSACTIONAL=Y, WEA_STATUS=READY,
		 * client_secret=s0N7dC-8_cKJfoZwhxQg84i7NXRO-s-O9GVEsnTI, RESPONSE_RECEIVED=Y,
		 * dotNumber=70559,
		 * cabScoreDetailsUrl=https://qa.gnpapi.protectiveinsurance.com,
		 * WEA_EXTERNAL_EVENT_ID=92,
		 * tokenGenerationUrl=https://qa.gnpapi.protectiveinsurance.com,
		 * STATUS_CODE=200, USER=admin@protectiveinsurance.com, ENTITY_TYPE=QUOTE,
		 * WEE_EVENT_TYPE=CABSCOREREPORTEVENT, WEA_TRANSACTION_DATE=2022-07-16,
		 * WEE_PROCESSOR_EXTENSION=com.majesco.custom.pi.integration.events.
		 * CabScoreReportEvent, WEE_PROCESSOR_ID=71,
		 * cabPdfDetailsUrl=https://qa.gnpapi.protectiveinsurance.com}
		 */

		NestedStringMap responseValuesMap = new NestedStringMap();
		responseValuesMap.put(REQUEST_ID, params.get(REQUEST_ID).toString());
		responseValuesMap.put(RESPONSE_RECEIVED, params.get(RESPONSE_RECEIVED).toString());
		responseValuesMap.put(STATUS_CODE, params.get(STATUS_CODE).toString());
		responseValuesMap.put("score", params.get("score").toString());
		responseValuesMap.put(CabScoreConstants.DOT_NUMBER, params.get(CabScoreConstants.DOT_NUMBER).toString());

		params.put(RESPONSE_VALUES_MAP, responseValuesMap);

		saveResponse(params);

	}

	protected void saveResponse(HashMap params) throws Exception {

		String query = null;
		Connection conn = null;
		PreparedStatement pst = null;
		User user = null;
		NestedStringMap responseValuesMap = null;
		int activityId;
		int rowsUpdated = 0;
		String responseValuesStr = null;

		try {
			responseValuesMap = (NestedStringMap) params.get(RESPONSE_VALUES_MAP);

			if (responseValuesMap != null) {

				responseValuesStr = responseValuesMap.toString();

				if (responseValuesStr != null && !responseValuesStr.equals(new NestedStringMap().toString())) {
					activityId = Integer.parseInt(params.get("WEA_ID").toString());

					user = (User) params.get("User");
					query = "UPDATE WFL_EVENT_ACTIVITIES " + " SET WEA_OTHER_EVENT_DATA = ? " + " WHERE WEA_ID = ?";

					conn = ConnectionPool.getConnection(user);
					pst = conn.prepareStatement(query);

					pst.setString(1, responseValuesStr);
					pst.setInt(2, activityId);

					rowsUpdated = pst.executeUpdate();

					if (rowsUpdated == 0) {
						String errorMessage = "No rows were updated in WFL_EVENT_ACTIVITIES. Response not saved in WEA_OTHER_EVENT_DATA";
						throw new JDBCException(errorMessage, null);
					}
					conn.commit();
				}
			}
		} catch (Exception ex) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, CLASS_NAME, "saveResponse",
					ServletConfigUtil.COMPONENT_PORTAL, new Object[] { params },
					"Error in saving ISO - Prefill response: " + ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
			try {
				conn.rollback();
			} catch (Exception e) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, CLASS_NAME, "saveResponse",
						ServletConfigUtil.COMPONENT_PORTAL, new Object[] { params },
						"Error in rolling back." + ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
			}
			throw ex;
		} finally {
			try {
				DBUtil.close(null, pst, conn);
			} catch (Exception ex) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, CLASS_NAME, "saveResponse",
						ServletConfigUtil.COMPONENT_PORTAL, new Object[] { params },
						"Error in closing DB connection while saving ISO - Prefill response." + ex.getMessage(), ex,
						LogMinderDOMUtil.VALUE_MIC);
			}

		}
		LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "postProcessEvent",
				ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Exiting saveResponse", null,
				LogMinderDOMUtil.VALUE_MIC);
	}

}
