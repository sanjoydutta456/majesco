package com.majesco.custom.pi.integration.events;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.coverall.util.DBUtil;
import com.coverall.datatypes.NestedStringMap;
import com.coverall.exceptions.JDBCException;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.events.EventProcessor;
import com.coverall.mt.events.EventResponse;
import com.coverall.mt.events.EventResponseDetails;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.webservices.WebServiceDAO;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.majesco.custom.pi.integration.ValenScoreExternalSource;
import com.majesco.custom.pi.integration.constants.CabScoreConstants;
import com.majesco.custom.pi.integration.constants.ValenScoreConstants;
import com.majesco.custom.pi.integration.model.Classification;
import com.majesco.custom.pi.integration.model.Inputs;
import com.majesco.custom.pi.integration.model.Insured;
import com.majesco.custom.pi.integration.model.Score;
import com.majesco.custom.pi.integration.model.State;
import com.majesco.custom.pi.integration.model.ValenScore;
import com.majesco.pi.webservices.score.ValenScoreAPIServiceClient;

public class VALENScoreReportEvent extends EventProcessor {

	private static final String NAME_WEBSERVICE = "MIC - INTERNAL - WS - SCORE - VALEN";
	private static final String RESPONSE_VALUES_MAP = "responseValuesMap";
	public static final String REQUEST_ID = "REQUEST_ID";
	public static final String RESPONSE_RECEIVED = "RESPONSE_RECEIVED";
	public static final String STATUS_CODE = "STATUS_CODE";
	private static final String CLASS_NAME = EventProcessor.class.getName();

	@Override
	public EventResponse execute(String xmlMessage, HashMap params) throws Exception {
		LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, ValenScoreExternalSource.class.getName(),
				"VALENScoreReportEvent ", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { params },
				"VALENScoreReportEvent execute:"+params, null,
				LogMinderDOMUtil.VALUE_MIC);

		EventResponseDetails eventResponse = new EventResponseDetails();

		User user = (User) params.get("User");
		String entityType = params.get("ENTITY_TYPE").toString();
		String entityReference = params.get("ENTITY_REFERENCE").toString(); // ENTITY_REFERENCE
		String available_history_1 = (String) params.get(ValenScoreConstants.AVAILABLE_HISTORY_ONE);
		String available_history_2 = (String) params.get(ValenScoreConstants.AVAILABLE_HISTORY_TWO);
		String available_history_3 = (String) params.get(ValenScoreConstants.AVAILABLE_HISTORY_THREE);

		String new_renew_flag = (String) params.get(ValenScoreConstants.NEW_RENEW_FLAG);
		String non_zero_claim_count_1 = (String) params.get(ValenScoreConstants.NON_ZERO_CLAIM_COUNT_ONE);
		String non_zero_claim_count_2 = (String) params.get(ValenScoreConstants.NON_ZERO_CLAIM_COUNT_TWO);
		String non_zero_claim_count_3 = (String) params.get(ValenScoreConstants.NON_ZERO_CLAIM_COUNT_THREE);
		String original_policy_term_number = (String) params.get(ValenScoreConstants.ORIGINAL_POLICY_TERM_NUMBER);
		String policy_state_code = (String) params.get(ValenScoreConstants.POLICY_STATE_CODE);
		String policy_zip_code = (String) params.get(ValenScoreConstants.POLICY_ZIP_CODE);
		String term_effective_date = (String) params.get(ValenScoreConstants.TERM_EFFECTIVE_DATE);
		
		Insured insured = new Insured();
		insured.setAvailable_history_1(available_history_1);
		insured.setAvailable_history_2(available_history_2);
		insured.setAvailable_history_3(available_history_3);
		insured.setNew_renew_flag(new_renew_flag);
		insured.setNon_zero_claim_count_1(non_zero_claim_count_1);
		insured.setNon_zero_claim_count_2(non_zero_claim_count_2);
		insured.setNon_zero_claim_count_3(non_zero_claim_count_3);
		insured.setOriginal_policy_term_number(original_policy_term_number);
		insured.setPolicy_state_code(policy_state_code);
		insured.setPolicy_zip_code(policy_zip_code);
		insured.setTerm_effective_date(term_effective_date);
		insured.setMyclass(getInsuredClassCodeDetails(entityReference,user));
		insured.setState(getStateCodeAndModfactorDetails(entityReference,user));
		Inputs inputs = new Inputs();
		inputs.setInsured(insured);
		Score score = new Score();
		score.setInputs(inputs);
		ValenScore vScore = new ValenScore();
		vScore.setScore(score);
		Map responseMap = new HashMap();
		ValenScoreAPIServiceClient client = new ValenScoreAPIServiceClient();
		responseMap = client.valenScoreReport(vScore, entityType, entityReference, user, params);
		LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, ValenScoreExternalSource.class.getName(),
				"VALENScoreReportEvent responseMap", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { responseMap },
				"VALENScoreReportEvent responseMap:"+responseMap, null,
				LogMinderDOMUtil.VALUE_MIC);
		eventResponse.setIsSuccess(true);

		params.put(ValenScoreConstants.VALEN_SCORE, (String) responseMap.get(ValenScoreConstants.VALEN_SCORE));
		params.put(ValenScoreConstants.VALEN_BIN, (String) responseMap.get(ValenScoreConstants.VALEN_BIN));
		params.put(ValenScoreConstants.MIS_CLASSIFICATION_SCORE,
				(String) responseMap.get(ValenScoreConstants.MIS_CLASSIFICATION_SCORE));
		params.put(RESPONSE_RECEIVED, responseMap.get("ResponseReceived").toString());
		
		return eventResponse;
	}

	@Override
	public EventResponse processEvent(HashMap params) throws Exception {
		LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO, VALENScoreReportEvent.class.getName(),
				"VALENScoreReportEvent", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { "", "" },
				"processEvent of VALENScoreReportEvent started", null, LogMinderDOMUtil.VALUE_MIC);

		int webserviceId;
		User user = null;
		HashMap config = null;
		String xmlMessage = null;
		EventResponseDetails eventResponse = new EventResponseDetails();
		user = (User) params.get("User");
		webserviceId = Integer.parseInt(params.get("WEE_PROCESSOR_ID").toString());
		config = WebServiceDAO.getWSGeneralParameters(user, webserviceId);

		params.putAll(config);

		boolean shouldCallWebService = new Boolean((String) config.get("Call web service")).booleanValue();

		if (shouldCallWebService) {
			eventResponse = (EventResponseDetails) execute(xmlMessage, params);
			if (eventResponse.isIsSuccess()) {
				postProcessEvent(params, eventResponse);
			} else {
				return eventResponse;
			}
			postProcessEvent(params, eventResponse);
		} else {
			eventResponse.setIsSuccess(true);
			eventResponse.setResponse("Did not execute since WS Param callwebservice=" + shouldCallWebService);
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO, getClass().getName(),
					"Did not execute since WS Param callwebservice= " + shouldCallWebService,
					ServletConfigUtil.COMPONENT_FRAMEWORK, null, eventResponse.getResponse(), null,
					LogMinderDOMUtil.VALUE_MIC);
		}
		return eventResponse;

	}

	@Override
	public String getWebServiceName() {
		LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO, getClass().getName(),
				"Did not execute since WS Param callwebservice= ", ServletConfigUtil.COMPONENT_FRAMEWORK, null, "",
				null, LogMinderDOMUtil.VALUE_MIC);
		return NAME_WEBSERVICE;
	}

	@Override
	public void postProcessEvent(HashMap params, EventResponse response) throws Exception {
		LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO, getClass().getName(),
				"Did not execute since WS Param callwebservice= ", ServletConfigUtil.COMPONENT_FRAMEWORK, null, "",
				null, LogMinderDOMUtil.VALUE_MIC);
		NestedStringMap responseValuesMap = new NestedStringMap();
		responseValuesMap.put(RESPONSE_RECEIVED, params.get(RESPONSE_RECEIVED).toString());
		responseValuesMap.put(ValenScoreConstants.VALEN_SCORE, (String) params.get(ValenScoreConstants.VALEN_SCORE));
		responseValuesMap.put(ValenScoreConstants.VALEN_BIN, (String) params.get(ValenScoreConstants.VALEN_BIN));
		responseValuesMap.put(ValenScoreConstants.MIS_CLASSIFICATION_SCORE,
				(String) params.get(ValenScoreConstants.MIS_CLASSIFICATION_SCORE));
		
		
		
		
		params.put(RESPONSE_VALUES_MAP, responseValuesMap);
		saveResponse(params);

	}

	protected void saveResponse(HashMap params) throws Exception {
		LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO, getClass().getName(), "saveResponse",
				ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { params }, "Entering saveResponse method", null,
				LogMinderDOMUtil.VALUE_MIC);

		String query = null;
		Connection conn = null;
		PreparedStatement pst = null;
		User user = null;
		NestedStringMap responseValuesMap = null;
		int activityId;
		int rowsUpdated = 0;
		String responseValuesStr = null;

		try {
			responseValuesMap = (NestedStringMap) params.get(RESPONSE_VALUES_MAP);

			if (responseValuesMap != null) {

				responseValuesStr = responseValuesMap.toString();

				if (responseValuesStr != null && !responseValuesStr.equals(new NestedStringMap().toString())) {
					activityId = Integer.parseInt(params.get("WEA_ID").toString());

					user = (User) params.get("User");
					query = "UPDATE WFL_EVENT_ACTIVITIES " + " SET WEA_OTHER_EVENT_DATA = ? " + " WHERE WEA_ID = ?";

					conn = ConnectionPool.getConnection(user);
					pst = conn.prepareStatement(query);

					pst.setString(1, responseValuesStr);
					pst.setInt(2, activityId);

					rowsUpdated = pst.executeUpdate();
					if (rowsUpdated == 0) {
						String errorMessage = "No rows were updated in WFL_EVENT_ACTIVITIES. Response not saved in WEA_OTHER_EVENT_DATA";
						throw new JDBCException(errorMessage, null);
					}
					conn.commit();
				}
			}
		} catch (Exception ex) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, CLASS_NAME, "saveResponse",
					ServletConfigUtil.COMPONENT_PORTAL, new Object[] { params },
					"Error in saving Valen Score response: " + ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
			try {
				conn.rollback();
			} catch (Exception e) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, CLASS_NAME, "saveResponse",
						ServletConfigUtil.COMPONENT_PORTAL, new Object[] { params },
						"Error in rolling back." + ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
			}
			throw ex;
		} finally {
			try {
				DBUtil.close(null, pst, conn);
			} catch (Exception ex) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, CLASS_NAME, "saveResponse",
						ServletConfigUtil.COMPONENT_PORTAL, new Object[] { params },
						"Error in closing DB connection while saving Valen Score response." + ex.getMessage(), ex,
						LogMinderDOMUtil.VALUE_MIC);
			}

		}
		LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO, getClass().getName(), "postProcessEvent",
				ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Exiting saveResponse", null,
				LogMinderDOMUtil.VALUE_MIC);
	}
	
	public ArrayList<Classification> getInsuredClassCodeDetails(String entityReference,User user) throws Exception {

		LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, ValenScoreExternalSource.class.getName(),
				"entityReference ", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { entityReference },
				"getInsuredClassCodeDetails entityReference:"+entityReference, null,
				LogMinderDOMUtil.VALUE_MIC);
		ArrayList<Classification> insuredClassCodeList = new ArrayList<Classification>();

		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {

			// ENTITY_REFERENCE='Q01WK0000002140000'
			String sql = "SELECT CLASS_CODE,RISK_STATE,ANNUAL_EXPOSURE FROM VW_MIS_WC_CLASSES "
					+ " WHERE ENTITY_REFERENCE = ? ";
			conn =  ConnectionPool.getConnection(user);
			ps = conn.prepareStatement(sql);
			ps.setString(1, entityReference);
			rs = ps.executeQuery();
			while (rs != null && rs.next()) {
				Classification classification=new Classification();
				classification.setClass_code(rs.getString(1));
				classification.setState_code(rs.getString(2));
				classification.setPayroll_amount_initial(rs.getString(3));
				insuredClassCodeList.add(classification);
				
			}
		} catch (Exception e) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, "ValenScoreExternalSource", "getInsuredClassCodeDetails",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Error while getting getInsuredClassCodeDetails. ", e,
					LogMinderDOMUtil.VALUE_MIC);
			throw e;
		} finally {
			try {
				DBUtil.close(rs, ps, conn);
			} catch (Exception ex) {
				// suppress
			}
		}
		
		return insuredClassCodeList;

	}
	
	public ArrayList<State> getStateCodeAndModfactorDetails(String entityReference,User user) throws Exception {

		LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, ValenScoreExternalSource.class.getName(),
				"entityReference ", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { entityReference },
				"getStateCodeAndModfactorDetails entityReference:"+entityReference, null,
				LogMinderDOMUtil.VALUE_MIC);
		ArrayList<State> stateCodeAndModfactorList = new ArrayList<State>();

		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			
			// ENTITY_REFERENCE='Q01WK0000031080000'
			String sql = "SELECT MODIFIER_FACTOR,MERIT_MODIFIER_FACTOR,RISK_STATE FROM vw_MIS_WC_RATING_PERIODS "
					+ " WHERE ENTITY_REFERENCE = ? ";
			conn = ConnectionPool.getConnection(user);
			ps = conn.prepareStatement(sql);
			ps.setString(1, entityReference);
			rs = ps.executeQuery();
			while (rs != null && rs.next()) {
				State state=new State();
				state.setExperience_mod_factor_initial(rs.getString(1));
				state.setMerit_mod_factor_initial(rs.getString(2));
				state.setState_code(rs.getString(3));
				stateCodeAndModfactorList.add(state);
				
			}
		} catch (Exception e) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, "ValenScoreExternalSource", "getStateCodeAndModfactorDetails",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Error while getting getStateCodeAndModfactorDetails. ", e,
					LogMinderDOMUtil.VALUE_MIC);
			throw e;
		} finally {
			try {
				DBUtil.close(rs, ps, conn);
			} catch (Exception ex) {
				// suppress
			}
		}
		
		return stateCodeAndModfactorList;

	}

}
