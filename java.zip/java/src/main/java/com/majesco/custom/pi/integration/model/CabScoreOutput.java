package com.majesco.custom.pi.integration.model;

import org.codehaus.jackson.annotate.JsonProperty;

public class CabScoreOutput {
	
	@JsonProperty("scores")
	Scores scores;

	public Scores getScores() {
		return scores;
	}

	public void setScores(Scores scores) {
		this.scores = scores;
	}

}
