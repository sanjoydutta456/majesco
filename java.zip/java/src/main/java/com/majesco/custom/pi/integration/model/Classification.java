package com.majesco.custom.pi.integration.model;

import org.codehaus.jackson.annotate.JsonProperty;

public class Classification {
	@JsonProperty("state_code")
	String state_code;

	@JsonProperty("class_code")
	String class_code;
	@JsonProperty("payroll_amount_initial")
	String payroll_amount_initial;

	public String getState_code() {
		return this.state_code;
	}

	public void setState_code(String state_code) {
		this.state_code = state_code;
	}

	public String getClass_code() {
		return this.class_code;
	}

	public void setClass_code(String class_code) {
		this.class_code = class_code;
	}

	public String getPayroll_amount_initial() {
		return this.payroll_amount_initial;
	}

	public void setPayroll_amount_initial(String payroll_amount_initial) {
		this.payroll_amount_initial = payroll_amount_initial;
	}

	@Override
	public String toString() {
		return "Classification [state_code=" + state_code + ", class_code=" + class_code + ", payroll_amount_initial="
				+ payroll_amount_initial + "]";
	}

}
