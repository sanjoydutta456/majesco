package com.majesco.custom.pi.integration.model;

import org.codehaus.jackson.annotate.JsonProperty;

public class Info {
	@JsonProperty("score_id")
	String score_id;
	
	@JsonProperty("score_key")
	String score_key;
	public String getScore_id() {
		return score_id;
	}
	public void setScore_id(String score_id) {
		this.score_id = score_id;
	}
	public String getScore_key() {
		return score_key;
	}
	public void setScore_key(String score_key) {
		this.score_key = score_key;
	}
	@Override
	public String toString() {
		return "Info [score_id=" + score_id + ", score_key=" + score_key + "]";
	}
	

}
