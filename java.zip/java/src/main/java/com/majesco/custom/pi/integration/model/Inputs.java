package com.majesco.custom.pi.integration.model;

public class Inputs {

	Insured insured;

	public Insured getInsured() {
		return this.insured;
	}

	public void setInsured(Insured insured) {
		this.insured = insured;
	}

}
