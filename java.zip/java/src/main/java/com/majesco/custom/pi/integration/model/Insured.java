package com.majesco.custom.pi.integration.model;

import java.util.ArrayList;

import org.codehaus.jackson.annotate.JsonProperty;

public class Insured{
  
	String available_history_1;
	String available_history_2;
	String available_history_3;
	String new_renew_flag;
	String non_zero_claim_count_1;
	String non_zero_claim_count_2;
    String non_zero_claim_count_3; 
    String original_policy_term_number;
    String policy_state_code;
    String policy_zip_code;
    String term_effective_date;
    @JsonProperty("class")
    ArrayList<Classification> myclass;
    
    ArrayList<State> state;
    
	
    public String getAvailable_history_1() { 
		 return this.available_history_1; } 
    public void setAvailable_history_1(String available_history_1) { 
		 this.available_history_1 = available_history_1; } 
 
  
    public String getAvailable_history_2() { 
		 return this.available_history_2; } 
    public void setAvailable_history_2(String available_history_2) { 
		 this.available_history_2 = available_history_2; } 
    
   
    public String getAvailable_history_3() { 
		 return this.available_history_3; } 
    public void setAvailable_history_3(String available_history_3) { 
		 this.available_history_3 = available_history_3; } 
    
    
    public String getNew_renew_flag() { 
		 return this.new_renew_flag; } 
    public void setNew_renew_flag(String new_renew_flag) { 
		 this.new_renew_flag = new_renew_flag; } 
    
   
    public String getNon_zero_claim_count_1() { 
		 return this.non_zero_claim_count_1; } 
    public void setNon_zero_claim_count_1(String non_zero_claim_count_1) { 
		 this.non_zero_claim_count_1 = non_zero_claim_count_1; } 
   
    
    public String getNon_zero_claim_count_2() { 
		 return this.non_zero_claim_count_2; } 
    public void setNon_zero_claim_count_2(String non_zero_claim_count_2) { 
		 this.non_zero_claim_count_2 = non_zero_claim_count_2; } 
   
   
    public String getNon_zero_claim_count_3() { 
		 return this.non_zero_claim_count_3; } 
    public void setNon_zero_claim_count_3(String non_zero_claim_count_3) { 
		 this.non_zero_claim_count_3 = non_zero_claim_count_3; } 

   
    public String getOriginal_policy_term_number() { 
		 return this.original_policy_term_number; } 
    public void setOriginal_policy_term_number(String original_policy_term_number) { 
		 this.original_policy_term_number = original_policy_term_number; } 
  
    
    public String getPolicy_state_code() { 
		 return this.policy_state_code; } 
    public void setPolicy_state_code(String policy_state_code) { 
		 this.policy_state_code = policy_state_code; } 
    
   
    public String getPolicy_zip_code() { 
		 return this.policy_zip_code; } 
    public void setPolicy_zip_code(String policy_zip_code) { 
		 this.policy_zip_code = policy_zip_code; } 
   
   
    public String getTerm_effective_date() { 
		 return this.term_effective_date; } 
    public void setTerm_effective_date(String term_effective_date) { 
		 this.term_effective_date = term_effective_date; } 
   
    
    public ArrayList<Classification> getMyclass() { 
		 return this.myclass; } 
    public void setMyclass(ArrayList<Classification> myclass) { 
		 this.myclass = myclass; } 
    
   
    public ArrayList<State> getState() { 
		 return this.state; } 
    public void setState(ArrayList<State> state) { 
		 this.state = state; } 
   
}
