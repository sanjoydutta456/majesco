package com.majesco.custom.pi.integration.model;

import org.codehaus.jackson.annotate.JsonProperty;

public class InsuredResponse {
	
	@JsonProperty("final_misclass_bin")
	String final_misclass_bin;
	
	@JsonProperty("final_risk_bin")
	String final_risk_bin;
	@JsonProperty("loss_ratio_relativity_prediction")
	String loss_ratio_relativity_prediction;
	
	public String getFinal_misclass_bin() {
		return final_misclass_bin;
	}
	public void setFinal_misclass_bin(String final_misclass_bin) {
		this.final_misclass_bin = final_misclass_bin;
	}
	public String getFinal_risk_bin() {
		return final_risk_bin;
	}
	public void setFinal_risk_bin(String final_risk_bin) {
		this.final_risk_bin = final_risk_bin;
	}
	public String getLoss_ratio_relativity_prediction() {
		return loss_ratio_relativity_prediction;
	}
	public void setLoss_ratio_relativity_prediction(String loss_ratio_relativity_prediction) {
		this.loss_ratio_relativity_prediction = loss_ratio_relativity_prediction;
	}
	
	@Override
	public String toString() {
		return "InsuredResponse [final_misclass_bin=" + final_misclass_bin + ", final_risk_bin=" + final_risk_bin
				+ ", loss_ratio_relativity_prediction=" + loss_ratio_relativity_prediction + "]";
	}
	
	

}
