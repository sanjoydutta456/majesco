package com.majesco.custom.pi.integration.model;

import org.codehaus.jackson.annotate.JsonProperty;

public class Outputs {
	 @JsonProperty("insured")
	InsuredResponse insuredResponse;



	public InsuredResponse getInsuredResponse() {
		return insuredResponse;
	}

	public void setInsuredResponse(InsuredResponse insuredResponse) {
		this.insuredResponse = insuredResponse;
	}
	
	@Override
	public String toString() {
		return "Outputs [insuredResponse=" + insuredResponse + "]";
	}

}
