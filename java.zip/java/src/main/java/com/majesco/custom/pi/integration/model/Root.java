package com.majesco.custom.pi.integration.model;

public class Root{
	Score score;
    public Score getScore() { 
		 return this.score; } 
    public void setScore(Score score) { 
		 this.score = score; } 
  
}
