package com.majesco.custom.pi.integration.model;

public class Score{
	Inputs inputs;
    public Inputs getInputs() { 
		 return this.inputs; } 
    public void setInputs(Inputs inputs) { 
		 this.inputs = inputs; }
    
   
}
