package com.majesco.custom.pi.integration.model;

import org.codehaus.jackson.annotate.JsonProperty;

public class Scores {
	
	@JsonProperty("ISS")
	ISS iss;

	public ISS getIss() {
		return iss;
	}

	public void setIss(ISS iss) {
		this.iss = iss;
	}
	

}
