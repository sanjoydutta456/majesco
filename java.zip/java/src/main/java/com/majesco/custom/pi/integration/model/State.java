package com.majesco.custom.pi.integration.model;

public class State{
   
	String state_code;
	String experience_mod_factor_initial;
	String merit_mod_factor_initial;
	
    public String getState_code() { 
		 return this.state_code; } 
    public void setState_code(String state_code) { 
		 this.state_code = state_code; } 
    
  
    public String getExperience_mod_factor_initial() { 
		 return this.experience_mod_factor_initial; } 
    public void setExperience_mod_factor_initial(String experience_mod_factor_initial) { 
		 this.experience_mod_factor_initial = experience_mod_factor_initial; } 
    
   
    public String getMerit_mod_factor_initial() { 
		 return this.merit_mod_factor_initial; } 
    public void setMerit_mod_factor_initial(String merit_mod_factor_initial) { 
		 this.merit_mod_factor_initial = merit_mod_factor_initial; } 
    
}
