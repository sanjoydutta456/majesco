package com.majesco.custom.pi.integration.model;

import org.codehaus.jackson.annotate.JsonProperty;

public class ValenScoreOutput {
	
	@JsonProperty("info")
	Info info;
	
	@JsonProperty("outputs")
	Outputs outputs;
	public Info getInfo() {
		return info;
	}
	public void setInfo(Info info) {
		this.info = info;
	}
	public Outputs getOutputs() {
		return outputs;
	}
	public void setOutputs(Outputs outputs) {
		this.outputs = outputs;
	}
	@Override
	public String toString() {
		return "ValenScoreOutput [info=" + info + ", outputs=" + outputs + "]";
	}
	

}
