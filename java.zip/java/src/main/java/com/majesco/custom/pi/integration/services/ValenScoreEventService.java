package com.majesco.custom.pi.integration.services;

import com.coverall.mt.services.EventProcessingService;
import com.coverall.mt.services.ILocalService;

public class ValenScoreEventService extends EventProcessingService {
	
	private static final EventProcessingService INSTANCE = new ValenScoreEventService();    


    private static final String TASK_NAME = "VALENScoreReportEvent";
    private static final String WEBSERVICE_NAME = "MIC - INTERNAL - WS - SCORE - VALEN";
    /**
     * Get the milestone task this service works on
     * @return the milestone task this service works on.
     */
    @Override
    public String getStartTask() {
        return TASK_NAME;
    }

    /**
     * Get the name of the webservice used in this event.
     * @return The webservice name.
     */
    @Override
    public String getWebServiceName() {
        return WEBSERVICE_NAME;
    }
	    
    /**
     * Method called be Schedulable task to get this instance
     * @return the singleton instance of this service
     */
    public static ILocalService getService() {
        return INSTANCE;
    }
    

}
