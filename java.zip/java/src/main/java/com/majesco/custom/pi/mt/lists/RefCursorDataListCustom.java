package com.majesco.custom.pi.mt.lists;

import com.coverall.el.*;
import com.coverall.el.function.*;
import com.coverall.exceptions.*;
import com.coverall.mt.db.*;
import com.coverall.mt.el.variable.*;
import com.coverall.mt.http.*;
import com.coverall.mt.lists.IDataList;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.*;
import com.coverall.util.*;

import org.w3c.dom.*;

import javax.servlet.http.*;

import java.sql.*;

import java.util.*;

public class RefCursorDataListCustom implements IDataList {
    /** DOCUMENT ME! */
    private static final int MAX_COUNT = 300;

    /** DOCUMENT ME! */
    private static final int MAX_EXPORT_COUNT = 6000;

    /** DOCUMENT ME! */
    protected ArrayList columns = new ArrayList();

    /** DOCUMENT ME! */
    protected ArrayList rows = new ArrayList();

    /** Connection used to get results from database */
    protected Connection connection;

    /** DOCUMENT ME! */
    protected HashMap columnIDMap;

    /** Results retrieved from database */
    protected ResultSet results;

    /** Statement used to get results from database */
    protected Statement statement;

    /** DOCUMENT ME! */
    protected String sortBy;

    /** DOCUMENT ME! */
    protected String sortOrder;

    /** DOCUMENT ME! */
    protected String view;

    /** DOCUMENT ME! */
    protected boolean hasNext;

    /** DOCUMENT ME! */
    protected int fromRow = -1;

    /** DOCUMENT ME! */
    protected int maxCount = 0;

    /**Returns the count of the resultset */
    protected int resultCount = 0;
    
    protected boolean setresultCount = false ;
    
    private static final String USER_NAME = "userFullName";
    
	public static final Set<String> DYNAMIC_BINDING_OFF_FILE_NAMES = new HashSet<String>(Arrays.asList("program_production.xml","BulkUnderwrtierUpdate.xml"));

	/**
     * Creates a new SQLListData object.
     */
    public RefCursorDataListCustom() {
        init();
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public ArrayList getColumns() {
        return columns;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public int getRowCount() {
        return resultCount;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public int getSelectedRowCount() {
        return getRowCount();
    }

    /**
     * DOCUMENT ME!
     *
     * @param from DOCUMENT ME!
     * @param count DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public int getRows(int from, int count) {
        try {
            from -= fromRow;
            from = Math.max(from, 0);
            count = Math.min(from + count, rows.size());

            return new ArrayList(rows.subList(from, count)).size();
        } catch (Exception exc) {
            //Jumpto from
            fromRow = from;
            from -= fromRow;
            from = Math.max(from, 0);
            count = Math.min(from + count, rows.size());

            return new ArrayList(rows.subList(from, count)).size();
        }
    }

    /**
     * DOCUMENT ME!
     *
     * @param row DOCUMENT ME!
     * @param column DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     *
     * @throws ArrayIndexOutOfBoundsException DOCUMENT ME!
     */
    public String getValue(int row, 
                           int column) throws ArrayIndexOutOfBoundsException {
        if (row != (fromRow + rows.size())) {
            row = row - fromRow;
        }

        ArrayList record = (ArrayList)rows.get(row);

        return (String)record.get(column);
    }

    /**
     * DOCUMENT ME!
     *
     * @param row DOCUMENT ME!
     * @param columnId DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     *
     * @throws ArrayIndexOutOfBoundsException DOCUMENT ME!
     */
    public String getValue(int row, 
                           String columnId) throws ArrayIndexOutOfBoundsException {
        String column = (String)columnIDMap.get(columnId);

        if (column == null) {
            column = columnId.toUpperCase();
        }

        return getValue(row, columns.indexOf(column));
    }

    /**
     * DOCUMENT ME!
     *
     * @param currentRow DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public boolean hasNext(int currentRow) {
        return hasNext || (currentRow < (fromRow + rows.size()));
    }

    /**
     * DOCUMENT ME!
     *
     * @param reportDoc DOCUMENT ME!
     * @param session DOCUMENT ME!
     * @param params DOCUMENT ME!
     *
     * @throws InitializationException DOCUMENT ME!
     */
    public void loadRows(Document reportDoc, HttpSession session, 
                         Map params) throws InitializationException {
        String view = (String)params.get(HTTPConstants.REQUEST_VIEW);
        String sortBy = (String)params.get(HTTPConstants.REQUEST_SORT_BY);
        String sortOrder = 
            (String)params.get(HTTPConstants.REQUEST_SORT_ORDER);
        int from = 
            Integer.parseInt((String)params.get(HTTPConstants.REQUEST_FROM));
        /** done to remove the spaces in the user name*/
        if(params.get("userFullName") !=null) {
             String userName = (String)params.get("userFullName");
             params.remove(USER_NAME);
             params.put(USER_NAME,userName.trim());
         }
        if (!view.equalsIgnoreCase(this.view) || 
            !sortBy.equalsIgnoreCase(this.sortBy) || 
            !sortOrder.equalsIgnoreCase(this.sortOrder)) {
            init();
            this.view = view;
            this.sortBy = sortBy;
            this.sortOrder = sortOrder;
            fromRow = from - 1;

            String fetchSize = reportDoc.getDocumentElement().getAttribute("fetchSize");
            
            if (fetchSize == null || fetchSize.equals(""))  {
                maxCount = MAX_COUNT;
            } else {
                maxCount = Integer.parseInt(fetchSize);
            }

            Element viewElement = 
                XMLUtil.getElementByNameAndAttribute(reportDoc, 
                                                     ReportDOMUtil.ELEMENT_VIEW, 
                                                     ReportDOMUtil.ATTRIBUTE_ID, 
                                                     view);

            if (ReportDOMUtil.VALUE_YES.equalsIgnoreCase((String)params.get(HTTPConstants.REQUEST_PRINTING)) || 
                ReportDOMUtil.VALUE_YES.equalsIgnoreCase((String)params.get(HTTPConstants.REQUEST_EXPORTING)) || 
                ReportDOMUtil.VALUE_SUMMARY.equalsIgnoreCase(viewElement.getAttribute(ReportDOMUtil.ATTRIBUTE_TYPE))) {
                maxCount = MAX_EXPORT_COUNT;
            }
        }

        if //Going back from fetch size
            //Going forward from fetch size (Can happen during print/extract when maxCount % average rows per previous page is not 0 ) 
            ((from < fromRow) || (from > (fromRow + rows.size())) || 
             (from == (fromRow + maxCount))) { //Going forward from fetch size

            String sql = null;
            String canGetCount = null;
            
            List<Object> bindVariableList = null;
            
            try {
                User user = 
                    (User)session.getAttribute(HTTPConstants.SESSION_USER);

                Element listElement = reportDoc.getDocumentElement();

                Element tableElement = 
                    XMLUtil.getElementByTagName(listElement, ReportDOMUtil.ELEMENT_TABLE);
                Element headerElement = 
                    XMLUtil.getElementByTagName(tableElement, 
                                                ReportDOMUtil.ELEMENT_HEADER);
                NodeList columnList = 
                    headerElement.getElementsByTagName(ReportDOMUtil.ELEMENT_TCOLUMN);
                int numColumns = columnList.getLength();

                for (int i = 0; i < numColumns; ++i) {
                    Element column = (Element)columnList.item(i);
                    columnIDMap.put(column.getAttribute(ReportDOMUtil.ATTRIBUTE_ID), 
                                    column.getAttribute(ReportDOMUtil.ATTRIBUTE_COLUMN).toUpperCase());
                }

                Element viewsElement = 
                    XMLUtil.getElementByTagName(reportDoc.getDocumentElement(), 
                                                ReportDOMUtil.ELEMENT_VIEWS);
                Element viewElement = 
                    XMLUtil.getElementByNameAndAttribute(viewsElement, 
                                                         ReportDOMUtil.ELEMENT_VIEW, 
                                                         ReportDOMUtil.ATTRIBUTE_ID, 
                                                         view);

                NodeList breaks = 
                    viewElement.getElementsByTagName(ReportDOMUtil.ELEMENT_BREAK);
                int numBreaks = breaks.getLength();
                String orderByClause = "";

                for (int i = 0; i < numBreaks; ++i) {
                    Element breakElement = (Element)breaks.item(i);
                    String columnId = 
                        breakElement.getAttribute(DOMUtil.ATTRIBUTE_ID);
                    Element columnElement = 
                        XMLUtil.getElementByNameAndAttribute(headerElement, 
                                                             ReportDOMUtil.ELEMENT_TCOLUMN, 
                                                             DOMUtil.ATTRIBUTE_ID, 
                                                             columnId);
                    String sortKey = 
                        columnElement.getAttribute(ReportDOMUtil.ATTRIBUTE_SORT_KEY);
                    Element sortColumnElement = 
                        XMLUtil.getElementByNameAndAttribute(headerElement, 
                                                             ReportDOMUtil.ELEMENT_TCOLUMN, 
                                                             DOMUtil.ATTRIBUTE_ID, 
                                                             sortKey);

                    if (sortColumnElement != null) {
                        columnElement = sortColumnElement;
                    }

                    String column = 
                        columnElement.getAttribute(ReportDOMUtil.ATTRIBUTE_COLUMN);
                    String breakOrder = breakElement.getAttribute("sortOrder");

                    if (breakOrder.startsWith("asc")) {
                        breakOrder = " ASC";
                    } else {
                        breakOrder = " DESC";
                    }

                    orderByClause += (column + breakOrder + ",");
                }

                Element columnElement = 
                    XMLUtil.getElementByNameAndAttribute(headerElement, 
                                                         ReportDOMUtil.ELEMENT_TCOLUMN, 
                                                         DOMUtil.ATTRIBUTE_ID, 
                                                         sortBy);

                if (columnElement != null) {
                    String sortKey = 
                        columnElement.getAttribute(ReportDOMUtil.ATTRIBUTE_SORT_KEY);
                    Element sortColumnElement = 
                        XMLUtil.getElementByNameAndAttribute(headerElement, 
                                                             ReportDOMUtil.ELEMENT_TCOLUMN, 
                                                             DOMUtil.ATTRIBUTE_ID, 
                                                             sortKey);

                    if (sortColumnElement != null) {
                        columnElement = sortColumnElement;
                    }

                    String column = 
                        columnElement.getAttribute(ReportDOMUtil.ATTRIBUTE_COLUMN);

                    if (column != null && !"".equals(column)) {

                        if (sortOrder.startsWith("asc")) {
                            sortOrder = " ASC ";
                        } else {
                            sortOrder = " DESC ";
                        }

                        orderByClause += (column + sortOrder);

                    }
                }

                if (orderByClause.endsWith(",")) {
                    orderByClause = 
                            orderByClause.substring(0, orderByClause.lastIndexOf(","));
                }

                String page = 
                    (String)params.get(HTTPConstants.REQUEST_REPORT_JUMPTO);
				
				if (ReportDOMUtil.VALUE_YES.equalsIgnoreCase(
                        (String) params.get(HTTPConstants.REQUEST_PRINTING)))
                {
                	page="";
                }

                if ((page != null) && !"".equals(page)) {
                    fromRow = Integer.parseInt(page);
                } else {

                    if (from < fromRow) {
                        from = (from / maxCount) * maxCount;
                    }

                    fromRow = from;
                }

                Element sqlElement = 
                    XMLUtil.getElementByTagName(listElement, ReportDOMUtil.ELEMENT_SQL);
                params = new HashMap(params);
                params.put("startRowNum", fromRow + "");
                params.put("endRowNum", (fromRow + maxCount + 1) + "");
                params.put("orderByClause", orderByClause);

                HashMap sqlParams = new HashMap();
                Iterator it = params.keySet().iterator();
                while (it.hasNext()) {
                    String key = (String)it.next();
                    String value = (String)params.get(key);
                    if (value != null) {
                        if (value.startsWith("'")) {
                            value = value.substring(1);
                        }
                        if (value.endsWith("'")) {
                            value = value.substring(0, value.length() - 2);
                        }
                        value = value.replaceAll("'", "''");
                    }
                    sqlParams.put(key, value);
                }

                HashMap variableMap = new HashMap();
                variableMap.put(VariableResolverImpl.SESSION_PARAMETER, 
                                session);
                variableMap.put(VariableResolverImpl.REQUESTPARAMS_PARAMETER, 
                                sqlParams);

                VariableResolver varResolver = 
                    new VariableResolverImpl(variableMap);
                FunctionResolver funcResolver = new DefaultFunctionResolver();

                QueryWithBindVariables queryWithBindVariables = new QueryWithBindVariables();
                
                try {
					varResolver.setDynamicBind(isEligibleForDynamicBinding(sqlElement, params));
					
					//translate the SQL document to apply data level security and populate customizations
					DOMUtil.mapDataToElement(sqlElement, varResolver, 
					                         funcResolver);
					sql = XMLUtil.getElementValue(sqlElement);
					
					queryWithBindVariables = BindVariablesInfoManager.prepareQueryWithBindVariables(sql, varResolver);
					
					sql = queryWithBindVariables.getQuery();
				} finally {
					varResolver.setDynamicBind(false);
				}
                
                //canGetCount indicates if the count for the SQL query needs to be obtained
                canGetCount = sqlElement.getAttribute("canGetCount");
                int calcOutParamIndex = 0;
                if ("true".equalsIgnoreCase(canGetCount)) {
                    //get the last occurance of ")" and append another ? for the out parameter
                    int lastOccurance = sql.lastIndexOf(")");
                    sql = sql.substring(0, lastOccurance).trim() + ",?) }";
                    String[] result = sql.split("\\?");
                    calcOutParamIndex = result.length - 1;
                }

                LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO, 
                                             getClass().getName(), "loadRows", 
                                             ServletConfigUtil.COMPONENT_FRAMEWORK, 
                                             null, 
                                             " SQL for report [" + sql + "]", 
                                             null, LogMinderDOMUtil.VALUE_MIC);

                connection = ConnectionPool.getConnection(user);
                
                bindVariableList = new ArrayList<Object>();
                
                if (null != (queryWithBindVariables.getBindVariablesValues())) {
                	bindVariableList.addAll(queryWithBindVariables.getBindVariablesValues());
                }

                CallableStatement st = connection.prepareCall(sql);
                statement = st;

                String typeClass = 
                    sqlElement.getAttribute(DOMUtil.ATTRIBUTE_TYPE);
                String typeField = 
                    sqlElement.getAttribute(DOMUtil.ATTRIBUTE_DATATYPE);

                if ((typeClass == null) || typeClass.equals("")) {
                    typeClass = "oracle.jdbc.OracleTypes";
                }

                if ((typeField == null) || typeField.equals("")) {
                    typeField = "CURSOR";
                }
                
                st.registerOutParameter(1, 
                                        Class.forName(typeClass).getField(typeField).getInt(null));
                
                if (null != bindVariableList)
                {
                	GeneralUtil.bindVariablesToCallableStatementGeneric(bindVariableList, st, 1);
                }
                
              //if canGetCount is true then register the out parameter for the count.   
                if ("true".equalsIgnoreCase(canGetCount)) {
                    st.registerOutParameter(((bindVariableList.size()) + 2), Types.INTEGER);
                }
                
                LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO, getClass().getName(), "loadRows", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { sql, bindVariableList }, "", null, LogMinderDOMUtil.VALUE_MIC);
            	
                st.execute();
                
                results = (ResultSet)st.getObject(1);
                if ("true".equalsIgnoreCase(canGetCount)) {
                    resultCount = st.getInt(calcOutParamIndex);
                    setresultCount =true;
                }
                ResultSetMetaData rsmd = results.getMetaData();
                int numCols = rsmd.getColumnCount();
                columns = new ArrayList();

                for (int i = 0; i < numCols; ++i) {
                    columns.add(rsmd.getColumnName(i + 1).toUpperCase());
                }

                rows = new ArrayList();

                int rowCount = 0;
                hasNext = false;

                while (results.next()) {
                    ArrayList row = new ArrayList();

                    for (int i = 0; i < numCols; i++) {
                        String value = results.getString(i + 1);
                        row.add((value != null) ? value : "");
                    }

                    if (++rowCount > maxCount) {
                        hasNext = true;
                        break;
                    }
                    rows.add(row);
                }
                
                if (setresultCount == false) {
                    resultCount = fromRow + rowCount ;
                    setresultCount = true;
                }
            } catch (Exception error) {
            	LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "loadRows", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { sql, bindVariableList }, "", error, LogMinderDOMUtil.VALUE_MIC);
            	
            	throw new InitializationException("Error creating list data object. SQL is \n" + 
                                                  sql, error);
            } finally {
                closeResultSet();
            }
        }
    }

    /**
     * Clean up database connection, statement, resultset etc.
     */
    protected void closeResultSet() {
        try {
            results.close();
        } catch (Throwable error) {
        }

        try {
            statement.close();
        } catch (Throwable error) {
        }

        try {
            ConnectionPool.releaseConnection(connection);
        } catch (Throwable error) {
        }
    }

    private void init() {
        columns = new ArrayList();
        rows = new ArrayList();
        hasNext = false;
        fromRow = 0;
        columnIDMap = new HashMap();
    }

	private boolean isEligibleForDynamicBinding(Element sqlElement, Map parameterMap) {
		try {
			if (null == sqlElement) {
				return true;
			}

			if (DYNAMIC_BINDING_OFF_FILE_NAMES.contains(parameterMap.get("reportXML"))) {
				String dlsFilterPatternPrimary = "'\\'',func:sqlEscape(var:user('DLSFILTER',";

				String expression = extractAndFormatExpression(sqlElement);

				if ((null != expression) && (expression.contains(dlsFilterPatternPrimary))) {
					return false;
				}
			}
		} catch (Exception e) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "isEligibleForDynamicBinding",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {},
					String.valueOf(parameterMap.get("reportXML")), e, LogMinderDOMUtil.VALUE_MIC);

			throw e;
		}

		return true;
	}

	private String extractAndFormatExpression(Element sqlElement) {
		try {
			NodeList childNodeList = sqlElement.getChildNodes();

			for (int index = 0; index < (childNodeList.getLength()); index++) {
				Node node = childNodeList.item(index);

				if ((Node.TEXT_NODE) == (node.getNodeType())) {
					String nodeValue = node.getNodeValue();

					if ((null != nodeValue) && (Expression.isExpression(nodeValue))) {
						nodeValue = nodeValue.replaceAll("\\r\\n|\\r|\\n", "");
						nodeValue = nodeValue.replaceAll(" ", "");

						return nodeValue;
					}
				}
			}
		} catch (Exception e) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "extractAndFormatExpression",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "", e, LogMinderDOMUtil.VALUE_MIC);

			throw e;
		}

		return null;
	}
}
