package com.majesco.custom.pi.portal.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Map;

import com.coverall.billing.soa.BillingService;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.HTTPConstants;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;

public class BillingCustomService extends BillingService {
	
	@Override
	protected String getBillType(String entityReference, User user, Map params) {
		
		String billType= (String)params.get(HTTPConstants.PROPERTY_PARAM_BILL_TYPE);
		logMessage(LogEntry.SEVERITY_INFO, "BillingCustomService.getBillType() Custom Class method, Entity Ref :" + entityReference, "");
		
		if (billType == null || billType.trim().equals("")) {
			Connection conn = null;
			PreparedStatement stmt = null;
			ResultSet rs = null;
			String oldEntityReference = null;
			
			try {
				conn = ConnectionPool.getConnection(user);
				stmt = conn.prepareStatement("select MPF_BILL_TYPE from MIS_POLICY_FINANCIALS where MPF_POLICY_REFERENCE = ?");
				stmt.setString(1, entityReference);
				rs = stmt.executeQuery();
				if(rs.next()) {
					billType = rs.getString("MPF_BILL_TYPE");
				}
				
				if (billType == null || billType.trim().equals("")) {
					logMessage(LogEntry.SEVERITY_INFO, "BillingCustomService.getBillType() Control in First Condition Check", "");
					stmt = conn.prepareStatement("SELECT bill_type_code FROM iel_mic_bill_types imbt,mis_policy_financials WHERE imbt.product_code = (SELECT product_code FROM vw_mis_quote_policies WHERE entity_reference = ?) AND" +
							" mpf_policy_reference = SUBSTR(?, 1, 15) ||LPAD(DECODE(GREATEST(TO_NUMBER(SUBSTR(?,-1,3))-1, 0), 0, 0, TO_NUMBER(SUBSTR(?,-1,3))-1),3,'0') AND mpf_bill_type = imbt.bill_type_code");
					stmt.setString(1, entityReference);
					stmt.setString(2, entityReference);
					stmt.setString(3, entityReference);
					stmt.setString(4, entityReference);
					rs = stmt.executeQuery();
					if(rs.next()) {
						billType = rs.getString("BILL_TYPE_CODE");
					}
				}
				
				if (billType == null || billType.trim().equals("") ) {
					logMessage(LogEntry.SEVERITY_INFO, "BillingCustomService.getBillType() Control in Second Condition Check", "");
					stmt = conn.prepareStatement("select OLD_ENTITY_REFERENCE from VW_MIS_QUOTE_POLICIES where ENTITY_REFERENCE = ?");
					stmt.setString(1, entityReference);
					rs = stmt.executeQuery();
					if(rs.next()) {
						oldEntityReference = rs.getString("OLD_ENTITY_REFERENCE");
					}
					
					if(oldEntityReference != null && !(oldEntityReference.trim().equals(""))){
						stmt = conn.prepareStatement("select MPF_BILL_TYPE from MIS_POLICY_FINANCIALS where MPF_POLICY_REFERENCE = ?");
						stmt.setString(1, oldEntityReference);
						rs = stmt.executeQuery();
						if(rs.next()) {
							billType = rs.getString("MPF_BILL_TYPE");
						}
					}
				} 
				
				if (billType == null || billType.trim().equals("")  ) {
					logMessage(LogEntry.SEVERITY_INFO, "BillingCustomService.getBillType() Control in Third Condition Check", "");
					//Retrieving ProgramCode, ProductCode and CompanyCode from vw_mis_quote_policies
					String programCode = "";
					String productCode = "";
					String companyCode = "";
					stmt = conn.prepareStatement("select program_code, product_code, company_code from vw_mis_quote_policies where entity_reference = ?");
					stmt.setString(1, entityReference);
					rs = stmt.executeQuery();
					if(rs.next()) {
						programCode = rs.getString("program_code");
						productCode = rs.getString("product_code");
						companyCode = rs.getString("company_code");
					}

					logMessage(LogEntry.SEVERITY_INFO, "BillingCustomService : ProgramCode :" + programCode + ", ProductCode :" + productCode + ", CompanyCode :" + companyCode, "");
					
					//Retrieving BillType
					stmt = conn.prepareStatement(
							"select BILL_TYPE_CODE from (select BILL_TYPE_CODE from IEL_MIC_BILL_TYPES where PROGRAM_CODE = ? AND PRODUCT_CODE = ? " + 
					"AND (COMPANY_CODE = ? OR COMPANY_CODE IS NULL) ORDER BY BILL_TYPE_CODE DESC) where rownum < 2");
					stmt.setString(1, programCode);
					stmt.setString(2, productCode);
					stmt.setString(3, companyCode);
					rs = stmt.executeQuery();
					if(rs.next()) {
						billType = rs.getString("BILL_TYPE_CODE");
					}
					logMessage(LogEntry.SEVERITY_INFO, "BillingCustomService:Bill Type Code : " + billType, "");
				}
			} catch(Exception ex) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(),
						new Exception().getStackTrace()[0].toString(), ServletConfigUtil.COMPONENT_PORTAL,
						new Object[] { entityReference },
						"\nException occured while getting bill Type from IEL_MIC_BILL_TYPES table.\n" + ex.getMessage(), null,
						LogMinderDOMUtil.VALUE_MIC);
			} finally {
				try {
					DBUtil.close(rs, stmt, conn);
				} catch(Exception ex) {}
			}
			
			if (billType == null || billType.trim().equals("")) {
				logMessage(LogEntry.SEVERITY_INFO, "BillingCustomService.getBillType() Control in Fourth Condition Check", "");
				billType = CustomerConfigUtil.getInstance().getCustomerProperty(user.getDomain(),
						ServletConfigUtil.COMPONENT_PORTAL,
						HTTPConstants.PROPERTY_PARAM_BILL_TYPE);
				
				if (billType == null || billType.trim().equals("")) {
					logMessage(LogEntry.SEVERITY_INFO, "BillingCustomService.getBillType() Control in Fifth Condition Check", "");
					billType = "D";
				}
			}
			
			params.put(HTTPConstants.PROPERTY_PARAM_BILL_TYPE, billType);			
		}
		return billType;
	}
	
	private void logMessage(int logLevel, String inputMsg, String objMsg) {
		LogMinder.getLogMinder().log(logLevel, getClass().getName(), "BillingCustomService",
				ServletConfigUtil.COMPONENT_PORTAL, new Object[]{objMsg}, 
				inputMsg, null, LogMinderDOMUtil.VALUE_MIC);
	}

}
