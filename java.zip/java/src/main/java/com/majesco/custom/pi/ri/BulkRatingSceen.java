package com.majesco.custom.pi.ri;

import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;

import com.coverall.exceptions.JDBCException;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;
import com.coverall.mt.soa.ListService;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;

public class BulkRatingSceen extends ListService{
	
	public static final String PMBR_ID = "PMBR_ID";
	public static final String PMBR_PROCESSING_STATUS = "PMBR_PROCESSING_STATUS";
	public static final String GID = "GID";

	public BulkRatingSceen() {
		// TODO Auto-generated constructor stub
	}
	
	public void saveObjectData(User user, String idList, Map params)
            throws Exception {
            
            Connection conn            = null;
            
            CallableStatement callStmt = null;
            
            Connection conn2            = null;
            
            CallableStatement callStmt2 = null;
            
            PreparedStatement prest = null;
            
            ResultSet result = null;
            
            int wws_id = -1;
            
            double actualRate = 0;
            
            HashMap config = null;
            String[] strArray = null; 
            strArray = idList.split(","); 
            
            for (int i = 0; i< strArray.length; i++){  
            
            	String entityReference1 = strArray[i];
            	
             //   String id = (String) params.get("PMBR_ID_"+entityReference1);
            	
            	String processingStatus = (String) params.get("PMBR_PROCESSING_STATUS_"+entityReference1);
            	String pmbrId = (String) params.get("PMBR_ID_"+entityReference1);
            	String gid = (String) params.get("GID_"+entityReference1);
            	
            try{
            	
                conn = ConnectionPool.getConnection(user);
                conn.setAutoCommit(false);
               
                if(!processingStatus.equals("") && !processingStatus.equals("null") && processingStatus.equals("FAILED")) {


                	callStmt = conn
                            .prepareCall("{? = call k_bulk_rates.f_bulk_rate_failure(?)}");	
                	callStmt.registerOutParameter(1, Types.BIGINT);
                	callStmt.setString(2, pmbrId);
                	callStmt.execute();
                
                
                	conn.commit();
                	
                	}
                
                else {
                
                callStmt = conn
                        .prepareCall("{? = call k_bulk_rates.f_insert_bulk_rates(?)}");
                
                callStmt.registerOutParameter(1, Types.INTEGER);
                callStmt.setString(2, gid);
               // callStmt.registerOutParameter(8, Types.VARCHAR);
                callStmt.execute();
                
                
                conn.commit();
                
                
                
                
                }

                
             } 
            catch(Exception ex){
                 ex.printStackTrace();
                if (ex instanceof JDBCException && ((JDBCException)ex).getSeverity() == JDBCException.FATAL){
                    LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                                                 getClass().getName(), "saveObjectData",
                                                 ServletConfigUtil.COMPONENT_PORTAL,
                                                 new Object[] { params },
                                                 "Error in saving a Object Data "+ex.getMessage(),
                                                 ex, LogMinderDOMUtil.VALUE_MIC);
                }else{
                    LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                                                 getClass().getName(), "saveObjectData",
                                                 ServletConfigUtil.COMPONENT_PORTAL,
                                                 new Object[] { params },
                                                 "Error in saving a Object Data."+ex.getMessage(),
                                                 ex, LogMinderDOMUtil.VALUE_MIC);
                }
                try{
                    conn.rollback();
                }catch(Exception e){
                    LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                                                 getClass().getName(), "saveObjectData",
                                                 ServletConfigUtil.COMPONENT_PORTAL,
                                                 new Object[] { params },
                                                 "Error in rolling back."+ex.getMessage(),
                                                 ex, LogMinderDOMUtil.VALUE_MIC);
                }
                throw ex;
            }finally{
                try{
                    DBUtil.close(null, callStmt, conn);
                }catch (Exception ex){
                    LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                                                 getClass().getName(), "saveObjectData",
                                                 ServletConfigUtil.COMPONENT_PORTAL,
                                                 new Object[] { params },
                                                 "Error in closing DB connection while saving a Object Data."+ex.getMessage(),
                                                 ex, LogMinderDOMUtil.VALUE_MIC);
                }
            }
            
            
        }
	
	}
	
}
