package com.majesco.custom.pi.ri.services;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;

import com.coverall.exceptions.ServiceException;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.majesco.pi.portal.noc.constants.NocHoldRleaseConstants;

import javax.net.ssl.HttpsURLConnection;

import com.coverall.mt.events.EventProcessor;
import com.coverall.mt.http.User;



public class APICallDatalake {

	
	public  String response(User user, String jsonExtract, String tokenResponse) throws ServiceException, MalformedURLException {
		
		String dataResponse = null;
		
		
		
		
		try {
		
			Map webserviceParams =  EventProcessor.
        			getWebServiceParameters(DatalakeConstants.DATALAKE_WEBSERVICE , user);
			
			
			URL url = new URL((String)webserviceParams.get(DatalakeConstants.DATALAKE_URL));
			
			HttpsURLConnection con = (HttpsURLConnection)url.openConnection();
			
			con.setRequestMethod("POST");
	
			con.setRequestProperty("Authorization", "Bearer "+tokenResponse);
			
			con.setDoOutput(true);
			
			
			
			String jsonInputString = jsonExtract;

				OutputStream os = con.getOutputStream() ;
			    byte[] input = jsonInputString.getBytes("utf-8");
			    os.write(input, 0, input.length);			

			    dataResponse = con.getResponseCode() +" "+ con.getResponseMessage();
			    
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                    this.getClass().getName(),
                    "gatherInput",
                    ServletConfigUtil.COMPONENT_FRAMEWORK,
                    new Object[] { con.getResponseMessage() +
                                   "entityReference" },
                    "After dataResponse ", null,
                    
                    LogMinderDOMUtil.VALUE_MIC);
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			
			
			e.printStackTrace();
			
			 LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                     this.getClass().getName(),
                     "gatherInput",
                     ServletConfigUtil.COMPONENT_FRAMEWORK,
                     new Object[] {
                                    "entityReference" },
                     "Error Response", e,
                     
                     LogMinderDOMUtil.VALUE_MIC);
		}
		
		
		return dataResponse;
	}
}
