package com.majesco.custom.pi.ri.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.coverall.exceptions.JDBCException;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;

public class CheckFailedRecords {

public boolean checkOldFailedPolicyReferenceStatus(String entityReference, User user) {
		
		
		Connection conn            = null;
        
        CallableStatement callStmt = null;
        
        PreparedStatement pstmt_1 = null;
        
        PreparedStatement pstmt_2 = null;
        
        ResultSet result = null;
		
        try{

        	String oldEntitySQL = "select mpo_old_policy_reference from mis_policies where mpo_policy_reference = ?";
        	
        	
        	conn = ConnectionPool.getConnection(user);
        	
        	pstmt_1 = conn.prepareStatement(oldEntitySQL);
        	
        	pstmt_1.setString(1, entityReference);
        	
        	result = pstmt_1.executeQuery();
        	
        	String previousEntityReference = null;
        	
        	while(result.next()) {
        		
        		previousEntityReference = result.getString("mpo_old_policy_reference");
        	}
        	
        	
            String selectSql = "select dlsi_status from PI_DATALAKE_SERVICE_INTG where dlsi_entity_reference = ?";
        	
            pstmt_2 = conn.prepareStatement(selectSql);
        	
        	pstmt_2.setString(1, previousEntityReference);
            	            
            result = pstmt_2.executeQuery();
            
            while(result.next()) {
            	
            	String status = result.getString("dlsi_status");
            	
            	if(status.equals("Failed"))
            		return false;
            	else if (status.equals("Successful"))
            		return true;
            	
            }
            
         } catch(Exception ex){
             ex.printStackTrace();
             
             LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                     this.getClass().getName(),
                     "gatherInput",
                     ServletConfigUtil.COMPONENT_FRAMEWORK,
                     new Object[] { "error 101" },
                     "Created Date ", ex,
                     
                     LogMinderDOMUtil.VALUE_MIC);
     
        }
         
            try{
                DBUtil.close(null, callStmt, conn);
            }
            catch (Exception ex){
            	ex.printStackTrace();
            	
            	if (ex instanceof JDBCException && ((JDBCException)ex).getSeverity() == JDBCException.FATAL){
                    LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                                                 getClass().getName(), "saveObjectData",
                                                 ServletConfigUtil.COMPONENT_PORTAL,
                                                 new Object[] { "error 103" },
                                                 "Error in saving a Object Data "+ex.getMessage(),
                                                 ex, LogMinderDOMUtil.VALUE_MIC);
                }else{
                    LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                                                 getClass().getName(), "saveObjectData",
                                                 ServletConfigUtil.COMPONENT_PORTAL,
                                                 new Object[] { "entity reference" },
                                                 "Error in saving a Object Data."+ex.getMessage(),
                                                 ex, LogMinderDOMUtil.VALUE_MIC);
                }
            	
            	try{
                    conn.rollback();
                }catch(Exception e){
                    LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                                                 getClass().getName(), "saveObjectData",
                                                 ServletConfigUtil.COMPONENT_PORTAL,
                                                 new Object[] { "error" },
                                                 "Error in rolling back."+ex.getMessage(),
                                                 ex, LogMinderDOMUtil.VALUE_MIC);
                }
            		
            }
            finally{
                try{
                    DBUtil.close(null, callStmt, conn);
                }catch (Exception ex){
                    LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                                                 getClass().getName(), "saveObjectData",
                                                 ServletConfigUtil.COMPONENT_PORTAL,
                                                 new Object[] {"entityReference" },
                                                 "Error in closing DB connection while saving a Object Data."+ex.getMessage(),
                                                 ex, LogMinderDOMUtil.VALUE_MIC);
                }
            }
		
		
		return true;
	}
	
}
