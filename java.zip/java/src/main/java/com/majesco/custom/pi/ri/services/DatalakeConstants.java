package com.majesco.custom.pi.ri.services;

public class DatalakeConstants {

public static final String DATALAKE_WEBSERVICE 			= "MIC - INTERNAL - WS - DATALAKE INTEGRATION";
	
	public static final String DATALAKE_TOKEN_BASE_URL 		= "tokenURL";
	
	public static final String GRANT_TYPE 	= "grantType";
	
	public static final String CLIENT_SECRET 	= "clientSecret";
	
	public static final String CLIENT_ID 	= "clientID";
	
	public static final String DATALAKE_URL 	= "datalakeURL";
	
	public static final String SCOPE 				= "scope";
	
	public static final String RETRY_COUNT 				= "noOfRetries";
	
}
