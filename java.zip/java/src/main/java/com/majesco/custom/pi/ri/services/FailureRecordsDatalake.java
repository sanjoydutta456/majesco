package com.majesco.custom.pi.ri.services;

import java.io.Reader;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Map;

import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.events.EventProcessor;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;

public class FailureRecordsDatalake {

	public void processFailedDatalake(User user, String tokenResponse) {
		
		Connection conn = null;
        PreparedStatement pstmt = null;
        CallableStatement callStmt = null;
        ResultSet rs = null;
        String dataResponse = null;
        String jsonExtract = null;
        int id = 0;
        String status = null;
        int retry_count = 0;
        
        try {

        	Map webserviceParams =  EventProcessor.
        			getWebServiceParameters(DatalakeConstants.DATALAKE_WEBSERVICE , user);
        	
        	
            
            String responseURL = (String)webserviceParams.get(DatalakeConstants.DATALAKE_URL);
            
            String noOfRetries = (String)webserviceParams.get(DatalakeConstants.RETRY_COUNT);
        	
        	String selectSql = "select DLSI_ID, DLSI_REQUEST, DLSI_RETRY_COUNT, DLSI_ENTITY_REFERENCE from pi_datalake_service_intg where (dlsi_status is null or dlsi_status = 'Failed') AND (cast(DLSI_retry_count as int) < ? or cast(DLSI_retry_count as int) is null) ";
        	
        	conn = ConnectionPool.getConnection(user);
        	
        	// If record exist for the given task id then update the record else insert new record
        	
        	
        	
        	pstmt = conn.prepareStatement(selectSql);
        	
        	pstmt.setString(1, noOfRetries);
        	
            rs = pstmt.executeQuery();
            
            while(rs.next()) {
            	
            String previous_reference = rs.getString("DLSI_ENTITY_REFERENCE");	
	
            Clob jsonRsponseClob = 	rs.getClob("DLSI_REQUEST");
            
            id = rs.getInt("DLSI_ID");
            
            String retry = rs.getString("DLSI_RETRY_COUNT");
            
            if(retry == null)
            	 retry_count = 1;
            else {
             retry_count =Integer.parseInt(retry);
             retry_count++;
             }
            
            retry = String.valueOf(retry_count);
            
            Reader r = jsonRsponseClob.getCharacterStream();
            
            StringBuffer buffer = new StringBuffer();
            
            
            int ch;
            while ((ch = r.read())!=-1) 
            {
               
            	buffer.append(""+(char)ch);
            }
            
            jsonExtract  = buffer.toString();
            
           CheckFailedRecords checkRecords = new CheckFailedRecords();
            
          boolean check =  checkRecords.checkOldFailedPolicyReferenceStatus(previous_reference, user);
            
            
            if(tokenResponse.equals("Error: Token Generation"))
            	dataResponse = "Error: Token Generation";
            
            else if (check == true) {
            	 APICallDatalake data = new APICallDatalake();
                
                 dataResponse = data.response(user, jsonExtract, tokenResponse);
            }
            
            else if (check == false) {
            	
            	dataResponse = "Error: Previous Transaction is not Successful";
            }
            
            if(dataResponse.equals("202 Accepted"))
            	status = "Successful";
            else
            	status = "Failed";
            
            
            
            callStmt = conn.prepareCall("{? = call k_insert_datalake.f_update_datalake_final(?, ?, ?, ?, ?)}");
            
            callStmt.registerOutParameter(1, Types.INTEGER);
            callStmt.setInt(2, id);
            callStmt.setString(3, status);
            callStmt.setString(4, responseURL);
            
            Clob clob1 = conn.createClob();
            clob1.setString(1, dataResponse);
            callStmt.setClob(5, clob1);
            
            callStmt.setString(6, retry);
            callStmt.execute();
            
            
            conn.commit();
            
            LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                    this.getClass().getName(),
                    "gatherInput",
                    ServletConfigUtil.COMPONENT_FRAMEWORK,
                    new Object[] { dataResponse +
                                   retry +status },
                    "Created Date " +dataResponse, null,
                    
                    LogMinderDOMUtil.VALUE_MIC);
            
            
            }
        		            
            	             
                     	
            
        } 
        
        catch (Exception e) {
            LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                                         "WorkFlowNotificationService",
                                         e.getStackTrace()[0].toString(),
                                         ServletConfigUtil.COMPONENT_FRAMEWORK,
                                         new Object[] { user},
                                         "Error occured while getting event turn on value.",
                                         e, LogMinderDOMUtil.VALUE_MIC);
        } 
        
        finally {
            	try {
            		DBUtil.close(rs, pstmt, conn);
            		} 
            	catch (SQLException se) {
                // ignore this one
            }
        }
		
		
	}
	
}
