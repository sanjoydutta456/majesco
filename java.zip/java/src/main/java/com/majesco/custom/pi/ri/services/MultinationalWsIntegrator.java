package com.majesco.custom.pi.ri.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.Reader;
import java.sql.Date;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.naming.NamingException;
import org.json.simple.JSONObject;
//import org.json.JSONArray;
//import org.json.simple.JSONObject;

import com.coverall.exceptions.ExceptionImpl;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.events.EventProcessor;
import com.coverall.mt.events.EventProcessorUtility;
import com.coverall.mt.events.EventResponse;
import com.coverall.mt.events.EventResponseDetails;
import com.coverall.mt.http.HTTPConstants;
import com.coverall.mt.http.User;
import com.coverall.mt.util.InterfaceFtpUtil;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.DOMUtil;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
//import com.coverall.mt.xml.xmlextractv2.PolicyExportToXML;

import com.coverall.util.DBUtil;
import com.google.gson.JsonObject;

public class MultinationalWsIntegrator extends EventProcessor {
    private static final String EVENT_BOOK_POLICY = "BookPolicy";
    private static final String EVENT_BOOK_POLICY_JSON = "BookPolicyjson";
    private static final String VIEW_PREFIX = "viewPrefix";
    private static final String EXPORT_XML_PATH = "exportXMLPath";
    private static final String WEBSERVICE_NAME = "MIC - INTERNAL - WS - XML - BOOKING - SERVICE";
    private static final String PARAM_FTP_URL = "ftpUrl";
    private static final String PARAM_FTP_USERNAME = "ftpUserName";
    private static final String PARAM_FTP_PASSWORD = "ftpPassword";
    private static final String PARAM_FTP_FOLDER = "ftpFolder";
    private static final String PARAM_FTP_EACH_FILE = "ftpEachFile";
    private static final String PARAM_VALID_COMPANY_CODE = "validCompanyCode";
    private static final String PARAM_CUSTOMER_CODE = "customerCode";
    private static final String PARAM_COMPANY_CODE = "companyCode";
    private static final String PARAM_COMPANY_NAME = "companyName";
    private static final String PARAM_IS_CLOUD_CUSTOMER = "isCloudCustomer";


    
    
    private static final String PARAM_IS_TABLE_EXISTS = " SELECT decode(count(pta_resource_id),0,'false','true') is_table_exist  FROM ps_table WHERE " +
            " pta_name = 'IEL_IC_MIC_XML_BOOK' " ;

    private static final String PARAM_GET_FTP_DETAILS = " SELECT company_code  ,customer_code ,company_name ,ftp_url ,ftp_user_name ,ftp_password ,ftp_folder ,ftp_each_file  " +
            " FROM iel_ic_mic_xml_book " +
            " WHERE company_code = (SELECT  company_code FROM vw_mis_quote_policies WHERE entity_reference = ? ) ";
    
  
    
    

    public MultinationalWsIntegrator() {
        super();
    }

    /**
     * @return webservice name
     */
    public String getWebServiceName() {
        return this.WEBSERVICE_NAME;
    }

    /**
     * @param params
     * @param response
     * @throws Exception
     */
    public void postProcessEvent(HashMap params, EventResponse response) throws Exception {
    }
    /**
     *
     * @param activityId
     * @param entityType
     * @param entityReference
     * @param params
     * @return the export file name
     * @throws Exception
     */
    public String gatherInput( String entityType,
                              String entityReference,
                              User user, String createdUser, String modifiedUser, String tokenResponse, String oldPolicyReference, int revisionNumber) throws Exception {
        

        // get user information from context
        //User user = (User)params.get(EventProcessorUtility.PARAM_USER);
        if(user == null) {
            throw new Exception("User can't be null!");
        }

        String exportXmlFile = null;
        String exportjsonFile = null;
       
        HashMap map = new HashMap();
        map.put(HTTPConstants.REQUEST_ENTITY_TYPE, entityType);
        map.put(HTTPConstants.REQUEST_ENTITY_REFERENCE, entityReference);
        map.put(VIEW_PREFIX, "RT");

        try {
        	String productCode = getProductCode(user, entityReference);
            if (productCode != null) {
                //Temp file location //mic/ri/XX(customer code)/temp
                String customerCode = CustomerConfigUtil.getInstance().getCustomerCode(user.getDomain());
                String tempBasePath = System.getProperty(DOMUtil.MIC_SYSTEM_HOME) + File.separator
                        + ServletConfigUtil.COMPONENT_RI + File.separator
                        + customerCode + File.separator + "XML";;
           
                        String tempBasePathJSON = System.getProperty(DOMUtil.MIC_SYSTEM_HOME) + File.separator
                                + ServletConfigUtil.COMPONENT_RI + File.separator
                                + customerCode + File.separator + "JSON";;
                
                        File baseDir = new File(tempBasePath);
                if(!baseDir.exists()){
                    baseDir.mkdirs();
                }
                
                
                LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                        this.getClass().getName(),
                        "gatherInput",
                        ServletConfigUtil.COMPONENT_FRAMEWORK,
                        new Object[] { entityType +
                                       entityReference },
                        "Temp XML Path " + tempBasePath,
                        null,
                        LogMinderDOMUtil.VALUE_MIC);
                
                
                
                
                
                
                File tempFile = File.createTempFile(entityType, entityReference, baseDir);
                exportXmlFile =  baseDir + File.separator + tempFile.getName()+".xml";

                // get xml data from PolicyExportToXML based on user information
                PolicyExportToXML  policyClzz = new PolicyExportToXML(exportXmlFile, map, user, true);
                policyClzz.generateXML();
//  json changes  ----------------------------------------------------------------------------------------
                
                LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                        this.getClass().getName(),
                        "gatherInput",
                        ServletConfigUtil.COMPONENT_FRAMEWORK,
                        new Object[] { "input" +
                                       "output" },
                        "JSON  ",
                        null,
                        LogMinderDOMUtil.VALUE_MIC);
                
                
                
                
                Reader fileReader = new FileReader(exportXmlFile);
                BufferedReader bufReader = new BufferedReader(fileReader);
                StringBuilder sb = new StringBuilder();
                String line = bufReader.readLine();
                while( line != null){
                sb.append(line).append("\n");
                line = bufReader.readLine();
                }
                String xml2String = sb.toString();
                bufReader.close();
                
    
                JsonObject obj = new JsonObject();
                
                obj.addProperty("entityReference",entityReference);
                obj.addProperty("policyExtractXml",xml2String);
  
                File baseDir1 = new File(tempBasePathJSON);
                if(!baseDir1.exists()){
                baseDir1.mkdirs();
                }
                
                File tempFilejson = File.createTempFile(entityType, entityReference, baseDir1);
                exportjsonFile =  baseDir1 + File.separator + tempFilejson.getName()+".json";
                
                FileWriter file = new FileWriter(exportjsonFile);
                file.write(obj.toString());
                file.close();  
                     
                String jsonExtract = obj.toString();
                
                
                
                insertDatalake insertData = new insertDatalake();
                
               insertData.insertDatalake(entityType, entityReference, jsonExtract, createdUser, modifiedUser, user, tokenResponse, oldPolicyReference, revisionNumber);

                
                
            }
        } catch (Exception e) {
            LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                                         this.getClass().getName(),
                                         "gatherInput",
                                         ServletConfigUtil.COMPONENT_FRAMEWORK,
                                         new Object[] { "Error during gathering Input" },
                                         "Error during gathering Input " +
                                         e.getMessage(), e,
                                         LogMinderDOMUtil.VALUE_WEBSERVICES);
            throw new Exception("Unexpected error during gathering input", e);
        } finally {}
        return exportXmlFile;
    }

    /**
     * @param xmlMessage
     * @param config
     * @return the event response
     * @throws Exception
     */
    public EventResponse execute(String xmlMessage, HashMap config) throws Exception{
        EventResponseDetails eventResponse = new EventResponseDetails();
        String customerCode = null;
        String ftpUserName = (String) config.get(PARAM_FTP_USERNAME);
    	String ftpPassword = (String) config.get(PARAM_FTP_PASSWORD);
    	String ftpFolder = (String) config.get(PARAM_FTP_FOLDER);
    	String ftpUrl = (String) config.get(PARAM_FTP_URL);
    	String ftpEachFile = (String) config.get(PARAM_FTP_EACH_FILE);
    	String validcompanyCode = (String) config.get(PARAM_VALID_COMPANY_CODE);
    	String isCloudCustomer =  (null!= config && config.containsKey(PARAM_IS_CLOUD_CUSTOMER)) ? (String) config.get(PARAM_IS_CLOUD_CUSTOMER) : null;

        User user = (User)config.get(EventProcessorUtility.PARAM_USER);
        
         if (null != user ) { 
         customerCode = CustomerConfigUtil.getInstance().getCustomerCode(user.getDomain());
         }
         
        if(xmlMessage == null || "".equalsIgnoreCase(xmlMessage)) {
            eventResponse.setStoreDetails(true);
            eventResponse.setResponse("No xml file got exported.");
            eventResponse.setIsSuccess(true);
            return eventResponse;
        }

        String exportXMLPath = (String)config.get(EXPORT_XML_PATH);
        if(exportXMLPath == null || "".equalsIgnoreCase(exportXMLPath.trim())) {
        	
            throw new Exception("The directory for Exporting the XML file can't be empty!");
        }

        String entityReference = (String)config.get("WEA_ENTITY_REFERENCE");
        String entityType = (String)config.get("WEA_ENTITY_TYPE");

        File sourceFile = null;
        try {
            sourceFile = new File(xmlMessage);
            File oldDestFile = new File(exportXMLPath + File.separator + entityReference + ".xml");
            File destFile = null;
            if( oldDestFile.exists()  ) {
            	//oldDestFile.renameTo(new File(exportXMLPath + File.separator + entityReference + "_old.xml"));
            	oldDestFile.delete();
            	destFile = new File(exportXMLPath + File.separator + entityReference + ".xml");
            } else {
            	destFile = new File(exportXMLPath + File.separator + entityReference + ".xml");
            }
            sourceFile.renameTo(destFile);
            eventResponse.setStoreDetails(false);
            eventResponse.setIsSuccess(true);
            
            if (eventResponse.isIsSuccess() && null != destFile && destFile.length() > 0 ) {
            
    		if (validateFTPParam(config)) { 
				
				if (null != ftpEachFile
						&& "Y".equalsIgnoreCase(ftpEachFile.trim()) && isValidCompanyCode(user, entityReference, entityType, validcompanyCode)) { 

					ftpEachFile(destFile, config, customerCode);  

					 
				}
				
			}
    		
    		if (isTableExists(user, entityReference) && null != isCloudCustomer && new Boolean(isCloudCustomer).booleanValue()) {
    			
    			if (isValidCompanyCode(user, entityReference, entityType, validcompanyCode) ) {
    				config.putAll( getFTPDetails(user, entityReference));
    				if (validateFTPParam(config)) {
					ftpEachFile(destFile, config, customerCode);  
    				}
    				
    			}
    			
    		}
            
            }    
    
        } catch (Exception ex) {
            eventResponse.setStoreDetails(true);
            eventResponse.setResponse(ex.getMessage());
            eventResponse.setIsSuccess(false);
            throw ex;
        } finally {
            if(sourceFile != null && sourceFile.exists()) {
                sourceFile.delete();
            }
        }
        return eventResponse;
    }

    private String getProductCode(User user, String entityRef) throws Exception {
         String productCodeQry =
             "select product_code from ev_mis_quote_policies where entity_reference=?";
         String productCode = null;

         Connection connection = null;
         PreparedStatement stmt = null;
         ResultSet rs = null;

         try {
             connection = ConnectionPool.getConnection(user);
             stmt = connection.prepareStatement(productCodeQry);
             stmt.setString(1, entityRef);
             rs = stmt.executeQuery();
             if (rs.next()) {
                 productCode = rs.getString(1);
             }
         } catch (NamingException e) {
             LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                                          this.getClass().getName(),
                                          "getProductCode",
                                          ServletConfigUtil.COMPONENT_FRAMEWORK,
                                          new Object[] { "Could not get connection for user - " +
                                                         user.getFullName() },
                                          "Error getting product code ", e,
                                          LogMinderDOMUtil.VALUE_WEBSERVICES);
             throw new Exception("Could not get connection for user " +
                                 user.getFullName() + " / " + e.getMessage());
         } catch (SQLException e) {
             LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                                         this.getClass().getName(),
                                          "getProductCode",
                                          ServletConfigUtil.COMPONENT_FRAMEWORK,
                                          new Object[] { "SQL exception " },
                                          "Error getting product code", e,
                                          LogMinderDOMUtil.VALUE_WEBSERVICES);

             throw new Exception("SQLException " + e.getMessage());
         } finally {
             try {
                 DBUtil.close(rs, stmt, connection);
             } catch (SQLException e) {
                 //suppress this exception
             }
         }
         return productCode;
     }
    
    
    boolean isValidCompanyCode(User user, String entityRef, String entityType , String validCompanyCode) throws Exception {
    	boolean isValidCompany = false;
    	String applicableCompany = "";
    	
    	
    	  if (!(null != validCompanyCode && validCompanyCode.length() > 0)) {
    		  
    		  return isValidCompany;
    		  
    	  }
    	  
    		String sqlQuery = " SELECT DECODE(COUNT(gid), 0 , 'N', 'Y') is_valid_company " +
        			" FROM vw_mis_quote_policies " +
        			" WHERE entity_reference = ? " +
        			" AND entity_type        =  ? " +
        			" AND company_code      IN ( " ;
    		String validCompany [] =validCompanyCode.split(",");
	    		
			for (String company : validCompany) {
	
				applicableCompany += "?,";
			}
			
			applicableCompany = applicableCompany.substring(0, applicableCompany.lastIndexOf(",") );

			sqlQuery = sqlQuery + applicableCompany + " )  AND ROWNUM = 1 " ;
    
		
        Connection connection = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
        	connection = ConnectionPool.getConnection(user);
            stmt = connection.prepareStatement(sqlQuery);
            stmt.setString(1, entityRef);
            stmt.setString(2, entityType);
            int bindCounter = 3;
            for (String company : validCompany) {
            	stmt.setString(bindCounter++, company.trim());
            }

            rs = stmt.executeQuery();
        	if (rs.next()) {

        		isValidCompany = rs.getString("is_valid_company").equalsIgnoreCase("Y") ? true
						: false;

			}

        } catch (NamingException e) {
            LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                                         this.getClass().getName(),
                                         "isValidCompanyCode",
                                         ServletConfigUtil.COMPONENT_FRAMEWORK,
                                         new Object[] { "Could not get connection for user - " +
                                                        user.getFullName() },
                                         "Error getting company code ", e,
                                         LogMinderDOMUtil.VALUE_WEBSERVICES);
            throw new Exception("Could not get connection for user " +
                                user.getFullName() + " / " + e.getMessage());
        } catch (SQLException e) {
            LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                                        this.getClass().getName(),
                                         "isValidCompanyCode",
                                         ServletConfigUtil.COMPONENT_FRAMEWORK,
                                         new Object[] { "SQL exception " },
                                         "Error getting company code", e,
                                         LogMinderDOMUtil.VALUE_WEBSERVICES);

            throw new Exception("SQLException " + e.getMessage());
        } finally {
            try {
                DBUtil.close(rs, stmt, connection);
            } catch (SQLException e) {
                //suppress this exception
            }
        }
        return isValidCompany;
    }
    
    
	private boolean validateFTPParam(Map targetParameters) {
		boolean isValid = false;
		String ftpUserName = (String) targetParameters.get(PARAM_FTP_USERNAME);
		String ftpPassword = (String) targetParameters.get(PARAM_FTP_PASSWORD);
		String ftpFolder = (String) targetParameters.get(PARAM_FTP_FOLDER);
		String ftpUrl = (String) targetParameters.get(PARAM_FTP_URL);
		String ftpEachFile = (String) targetParameters.get(PARAM_FTP_EACH_FILE);
		
		if (isEmpty(ftpUserName) || isEmpty(ftpPassword) || isEmpty(ftpFolder) || isEmpty(ftpUrl) || isEmpty(ftpEachFile) ) {
			return isValid;
		}
		
		
		if (!(isEmpty(ftpUserName) && isEmpty(ftpPassword) && isEmpty(ftpFolder) && isEmpty(ftpUrl) && isEmpty(ftpEachFile) )) {
			isValid = true;
			return isValid;
		}
		
		LogMinder
		.getLogMinder()
				.log(LogEntry.SEVERITY_DEBUG,
						getClass().getName(),
						"validateFTPParam",
						ServletConfigUtil.COMPONENT_FRAMEWORK,
						new Object[] {
								" ftpUserName " + ftpUserName,
								" ftpPassword " + ftpPassword,
								" ftpFolder " + ftpFolder,
								" ftpUrl " + ftpUrl ,
								" ftpEachFile " + ftpEachFile,
								" isValidParameters " + isValid},
						"Executing validateFTPParam method to process ImageRightTransfer Service ",
						null, LogMinderDOMUtil.VALUE_MIC);
		
		return isValid;

	}
	
	 public static boolean isEmpty(String param) {
	        boolean result = true;
	        if (param != null && param.trim().length() > 0) {
	            result = false;
	        }
	        return result;
	    }
	 
	 private void ftpEachFile (File file, Map targetParameters, String customerCode) throws Exception { 
    	 
	    	try {
	    		InterfaceFtpUtil ftpUtil = new InterfaceFtpUtil();
	    		ftpUtil.setUrl((String) targetParameters.get(PARAM_FTP_URL));
	    		ftpUtil.setUserName((String) targetParameters.get(PARAM_FTP_USERNAME));
	    		ftpUtil.setPassword((String) targetParameters.get(PARAM_FTP_PASSWORD));
	    		ftpUtil.setTargetFolder((String) targetParameters.get(PARAM_FTP_FOLDER));
	    		ftpUtil.setTargetFileNamePrefix(""); 
	    		ftpUtil.setGenReceiptFile(false);                        		
				ftpUtil.uploadFile(file.getParent(),file.getName(), customerCode);     
				deleteFile(file.getParent()); 
	       

			} catch (Exception e) {
				   LogMinder.getLogMinder().log(
	                       LogEntry.SEVERITY_INFO,
	                       this.getClass().getName(),
	                       "ftpEachFile",
	                       ServletConfigUtil.COMPONENT_FRAMEWORK,
	                       new Object[] {},
	                       "Error in file transfer :"
	                               + file.getAbsolutePath(),
	                       e,
	                       this.getClass().getName());
		

	                			   throw new ExceptionImpl(
	                       ExceptionImpl.FATAL,
	                       "Error in file transfer :"
	                               + file.getAbsolutePath(),
	                       e);
			}
	    	 	
	    	
	    }
	 

		public void deleteFile(String location) {
			File folder = new File(location);
			if (folder.exists()) {

				for (File listOffiles : folder.listFiles()) { 

					listOffiles.delete();

				}
				folder.delete();
			}
			
		}


		private boolean isTableExists(User user, String entityRef) throws Exception {

	         Connection connection = null;
	         PreparedStatement stmt = null;
	         ResultSet rs = null;
	         boolean isExists = false;

	         try {
	             connection = ConnectionPool.getConnection(user);
	             stmt = connection.prepareStatement(PARAM_IS_TABLE_EXISTS);
	             rs = stmt.executeQuery();
	             if (rs.next()) {
	            	 isExists = new Boolean(rs.getString("is_table_exist")).booleanValue();
	             }
	         } catch (NamingException e) {
	             LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
	                                          this.getClass().getName(),
	                                          "isTableExists",
	                                          ServletConfigUtil.COMPONENT_FRAMEWORK,
	                                          new Object[] { "Could not get connection for user - " +
	                                                         user.getFullName() },
	                                          "Error checkin if table exists ", e,
	                                          LogMinderDOMUtil.VALUE_WEBSERVICES);
	             throw new Exception("Could not get connection for user " +
	                                 user.getFullName() + " / " + e.getMessage());
	         } catch (SQLException e) {
	             LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
	                                         this.getClass().getName(),
	                                          "isTableExists",
	                                          ServletConfigUtil.COMPONENT_FRAMEWORK,
	                                          new Object[] { "SQL exception " },
	                                          "Error checkin if table exists", e,
	                                          LogMinderDOMUtil.VALUE_WEBSERVICES);

	             throw new Exception("SQLException " + e.getMessage());
	         } finally {
	             try {
	                 DBUtil.close(rs, stmt, connection);
	             } catch (SQLException e) {
	                 //suppress this exception
	             }
	      
			}
	         return isExists;
	     }

		
		private Map<String,String> getFTPDetails(User user, String entityRef) throws Exception {

	         Connection connection = null;
	         PreparedStatement stmt = null;
	         ResultSet rs = null;
	         String companyCode = null;
	         String customerCode = null;

	         Map <String,String> recordMap = new HashMap<String, String>();

	         try {
	             connection = ConnectionPool.getConnection(user);
	             stmt = connection.prepareStatement(PARAM_GET_FTP_DETAILS);
	             stmt.setString(1, entityRef);
	             rs = stmt.executeQuery();
	             if (rs.next()) {
	            	 recordMap.put(PARAM_COMPANY_CODE, null !=rs.getString("company_code") && rs.getString("company_code").trim().length() > 0 ? rs.getString("company_code") : "");
	            	 recordMap.put(PARAM_COMPANY_NAME, null !=rs.getString("company_name") && rs.getString("company_name").trim().length() > 0 ? rs.getString("company_name") : "");
	            	 recordMap.put(PARAM_CUSTOMER_CODE, null !=rs.getString("customer_code") && rs.getString("customer_code").trim().length() > 0 ? rs.getString("customer_code") : "");
	            	 recordMap.put(PARAM_FTP_URL, null !=rs.getString("ftp_url") && rs.getString("ftp_url").trim().length() > 0 ? rs.getString("ftp_url") : "");
	            	 recordMap.put(PARAM_FTP_USERNAME, null !=rs.getString("ftp_user_name") && rs.getString("ftp_user_name").trim().length() > 0 ? rs.getString("ftp_user_name") : "");
	            	 recordMap.put(PARAM_FTP_PASSWORD, null !=rs.getString("ftp_password") && rs.getString("ftp_password").trim().length() > 0 ? rs.getString("ftp_password") : "");
	            	 recordMap.put(PARAM_FTP_FOLDER, null !=rs.getString("ftp_folder") && rs.getString("ftp_folder").trim().length() > 0 ? rs.getString("ftp_folder") : "");
	            	 recordMap.put(PARAM_FTP_EACH_FILE, null !=rs.getString("ftp_each_file") && rs.getString("ftp_each_file").trim().length() > 0 ? rs.getString("ftp_each_file") : "");

	             }
	         } catch (NamingException e) {
	             LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
	                                          this.getClass().getName(),
	                                          "getFTPDetails",
	                                          ServletConfigUtil.COMPONENT_FRAMEWORK,
	                                          new Object[] { "Could not get connection for user - " +
	                                                         user.getFullName() },
	                                          "Error in fetching getFTPDetails ", e,
	                                          LogMinderDOMUtil.VALUE_WEBSERVICES);
	             throw new Exception("Could not get connection for user " +
	                                 user.getFullName() + " / " + e.getMessage());
	         } catch (SQLException e) {
	             LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
	                                         this.getClass().getName(),
	                                          "getFTPDetails",
	                                          ServletConfigUtil.COMPONENT_FRAMEWORK,
	                                          new Object[] { "SQL exception " },
	                                          "Error in fetching getFTPDetails", e,
	                                          LogMinderDOMUtil.VALUE_WEBSERVICES);

	             throw new Exception("SQLException " + e.getMessage());
	         } finally {
	             try {
	                 DBUtil.close(rs, stmt, connection);
	             } catch (SQLException e) {
	                 //suppress this exception
	             }
	      
			}
	         return recordMap;
	     }
		
		
		
		
		

		
}


