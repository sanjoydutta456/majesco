package com.majesco.custom.pi.ri.services;

import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.validators.SQLInjectionValidator;

public class PolicyExportThreadNew implements Runnable {

	PolicyExportTransaction policyExtractTransaction = null;
	String zipFilePath = null;
	int progressStatus =0;
	
	public PolicyExportThreadNew(String entityReference,String entityType,String entityDisplayName, String operationMode, String viewPrefix, User user ) throws Exception{
		validateInputs(entityType, entityReference);
		policyExtractTransaction = new PolicyExportTransaction(entityReference, entityType, entityDisplayName,  operationMode, viewPrefix, user);
		policyExtractTransaction.initializePolicyExportTransactionNew();
	}

	public void run() {

		try {
			zipFilePath = policyExtractTransaction.processExportTransaction();
		} catch (Exception e) {
			LogMinder.getLogMinder().log(
                    LogEntry.SEVERITY_FATAL,
                    "PolicyExportThread",
                    "run",
                    "",
                    new Object[] {},
                    "There is problem while creating policy XML",
                    e,
                    LogMinderDOMUtil.VALUE_MIC);
		}
	}

	public PolicyExportTransaction getPolicyExtractTransaction() {
		return policyExtractTransaction;
	}

	public void setPolicyExtractTransaction(
			PolicyExportTransaction policyExtractTransaction) {
		this.policyExtractTransaction = policyExtractTransaction;
	}
	
	private void validateInputs(String entityType, String entityReference) {
		try {
			SQLInjectionValidator.validateEntityType(entityType);
			SQLInjectionValidator.validateEntityReference(entityReference);
		} catch (Exception e) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, "PolicyExportThread", "validateInputs", "",
					new Object[] { entityType, entityReference }, "Policy extract input parameters validation failed",
					e, LogMinderDOMUtil.VALUE_MIC);
			throw e;
		}

	}

}
