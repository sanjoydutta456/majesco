package com.majesco.custom.pi.ri.services;

import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.coverall.el.FunctionResolver;
import com.coverall.el.InlineExpression;
import com.coverall.el.VariableResolver;
import com.coverall.el.function.DefaultFunctionResolver;
import com.coverall.exceptions.ELException;
import com.coverall.exceptions.ELParseException;
import com.coverall.exceptions.ExceptionImpl;
import com.coverall.mt.cache.XSDCache;
import com.majesco.custom.pi.ri.services.XSDCacheCreator;
//import com.coverall.mt.cache.XSDCacheCreator;
import com.coverall.mt.el.variable.VariableResolverImpl;
import com.coverall.mt.http.HTTPConstants;
import com.coverall.mt.http.User;
import com.coverall.mt.util.GenUtil;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.xml.xmlextractv2.Column;
import com.coverall.mt.xml.xmlextractv2.ColumnAttribute;
import com.coverall.mt.xml.xmlextractv2.ListObjectHierarchy;
import com.coverall.mt.xml.xmlextractv2.ObjectHierarchy;
import com.coverall.mt.xml.xmlextractv2.PendingExpCovForExportImport;
import com.coverall.mt.xml.xmlextractv2.Table;
import com.coverall.util.DBUtil;
import com.coverall.util.XMLUtil;

/**
 * This class Exports a policy in XML format.
 * It uses a XSD file which specifies the details about the policy and it's relations.
 * @author Mitesh Sarawagi
 */
public class PolicyExportToXML {
    /* Global variable and constants declaration.*/

	public static final String INDENT_XML = "indentXML";
	
    private static final String NEWLINE = "\r\n";
    private static final String CONST_FK_COLUMN_NAME = "FKColumnName";
    private static final String CONST_FK_COLUMN_VALUE = "FKColumnValue";
    private static final String CONST_SELECT = "SELECT ";
    private static final String CONST_COLUMN_PREFIX = "columnPrefix";
    private static final String CONST_ENTITY_TYPE = "entityType";
    private static final String CONST_ENTITY_REFERENCE = "entityReference";
    private static final String CONST_OLD_ENTITY_TYPE = "OLD_ENTITY_TYPE";
    private static final String CONST_OLD_ENTITY_REFERENCE = "OLD_ENTITY_REFERENCE";
    private static final String CONST_ID = "ID";
    private static final String CONST_TRANS_CODE = "TRANSACTION_CODE";
    private static final String ROOT_ELEMENT = "QuotePolicyList";

    private XSDCache xsdCache = null;
    private String oldEntityType;
    private String oldEntityReference;
    private XMLGeneratorParameters xmlGeneratorParameters;
	private String exportMode = null;
	
	private Map<String, String> dsrValueMap = null;

    public static boolean logPerformance = true;
    public static int logLevel = LogEntry.SEVERITY_FATAL;
    private boolean isReviseAudit=false;

    private boolean indentXML = true;    

    public PolicyExportToXML(Map<String, String> params, boolean useCache){
        setXMLGeneratorParameters(new XMLGeneratorParameters(params));
        if(getXMLGeneratorParameters().getLogging() == false)	{
            PolicyExportToXML.logPerformance = false;
        }
        
        xsdCache = new XSDCacheCreator(getXMLGeneratorParameters(), useCache).getXSDCache();
    	
    }
    
    public PolicyExportToXML(String[] arg, boolean useCache){
        setXMLGeneratorParameters(new XMLGeneratorParameters(arg));
        if(getXMLGeneratorParameters().getLogging() == false)
            PolicyExportToXML.logPerformance = false;
        xsdCache = new XSDCacheCreator(
                            getXMLGeneratorParameters(),
                            useCache
                       ).getXSDCache();
    }

    public PolicyExportToXML(
            String exportXMLPath, HashMap params, User user, boolean useCache
    ) throws Exception{
    	
    	Object object = params.get(INDENT_XML);
    	exportMode = (String)params.get("exportMode");
    	if( (object != null) && (object instanceof String) ){
    		String indentXml = (String) object;
    		if(indentXml != null) {
    			indentXml = indentXml.trim();
    			if(indentXml.equalsIgnoreCase("N")) {
    				indentXML = false;
    			}
    		}
    	}
    	
        XMLGeneratorParameters XMLGenParam = null;
        try {
            XMLGenParam
            = new XMLGeneratorParameters(
                                exportXMLPath,
                                params, user);
                /* if product code is not found that means record for specified
                entity_refernce/ entity_type is not found */
             if(XMLGenParam.getProductCode().equalsIgnoreCase("")){
                 String str = "There are no records for entity_reference:" + XMLGenParam.getEntityReference()
                 + " and entity_type:" + XMLGenParam.getEntityType() + ". Please enter correct entity_reference/entity_type";
                 XMLGenParam.getLogger().log(LogEntry.SEVERITY_FATAL, new Exception(str),str);
                 throw new Exception(str);
            }else{
                 setXMLGeneratorParameters(XMLGenParam);
                 xsdCache = new XSDCacheCreator(
                                     getXMLGeneratorParameters(),
                                     useCache
                                ).getXSDCache();
             }
        } catch (Exception e) { // construction failed, release connection. Example XMLGenParam.getProductCode() creates connection
            if(XMLGenParam != null) {
                XMLGenParam.closeConnection();
            }
            throw e;
        }
    }

    public  PrintWriter generateXML() throws ExceptionImpl {
        try {
            return generateXMLActual();
        } finally {
            XMLGeneratorParameters x = getXMLGeneratorParameters();
            if(x != null) {
                x.closeConnection();
            }
        }
    }

    private PrintWriter generateXMLActual() throws ExceptionImpl {
        /* Variable declaration.*/
        int indentCount = 0;
        long time1 = System.currentTimeMillis();

        StringBuffer buffer = new StringBuffer();
        //getXMLGeneratorParameters().getXMLWriter().println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        PrintWriter writer = getXMLGeneratorParameters().getXMLWriter();
        //SR 65816
        if(indentXML) {
           // writer.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        } else {
           // writer.print("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        }
        try {
            generateObjectListXML(
                    (ListObjectHierarchy) getXsdCache()
                            .getLstHierarchyMap()
                            .get(getXMLGeneratorParameters().getProductCode()),
                    null,
                    null,
                    indentCount,
                    buffer);
            /* Flush the XML generated */
            //System.out.println(buffer);
            getXMLGeneratorParameters().printXMLWriter(buffer);
            
            long time2 = System.currentTimeMillis();
            getXMLGeneratorParameters().getLogger().log(
                    LogEntry.SEVERITY_FATAL,
                    null,
                    getXMLGeneratorParameters().getEntityType() + " "
                            + getXMLGeneratorParameters().getEntityReference() + " Exported at \"" + getXMLGeneratorParameters().getExportXMLPath() + "\"");

            getXMLGeneratorParameters().getLogger().log(
                    LogEntry.SEVERITY_FATAL,
                    null,
                    getXMLGeneratorParameters().getEntityType() + " "
                            + getXMLGeneratorParameters().getEntityReference() + " XML export took " + (time2-time1) + " milliseconds.");
        
        }catch(Exception e){
            getXMLGeneratorParameters().getLogger().log(
                    LogEntry.SEVERITY_FATAL,
                    e, "Could not parse the input schema:" + e.getMessage());
        }
        return getXMLGeneratorParameters().getXMLWriter();
    }


    public static void main(String[] args) throws Exception {
        PolicyExportToXML policyExportImport =
            new PolicyExportToXML(args, false); //false here means do not get the XSD info from the cache
        XMLGeneratorParameters XMLGenParam = policyExportImport.getXMLGeneratorParameters();
        logPerformance("New PolicyImportToXML:"+ XMLGenParam.getEntityReference());

        try {
            if (XMLGenParam.getDriverName() != null && XMLGenParam.getHost() != null
                && XMLGenParam.getPort() != null && XMLGenParam.getSid() != null
                && XMLGenParam.getUserId() != null && XMLGenParam.getPassword() != null
                && XMLGenParam.getEntityType() != null && XMLGenParam.getEntityReference() != null
                && XMLGenParam.getExportXMLPath() != null && XMLGenParam.getConfigFilePath() != null) {

                policyExportImport.generateXML();

            } else {
                XMLGenParam.getLogger().log(LogEntry.SEVERITY_FATAL, null, "Valid Parameters expected");
                XMLGenParam.getLogger().log(LogEntry.SEVERITY_FATAL, null,
                                       "Usage :java PolicyExportToXML " +
                                       "host=<host> port=<port> sid=<sid> userId=<userId> password=<password> " +
                                       "entityType=<entityType> entityReference=<entityReference> " +
                                       "exportXMLPath=<exportXMLPath> configFilePath=<configFilePath> rootElement=<rootElement> customerCode=<customerCode>");
            }

        } catch (Exception e) {
            XMLGenParam.getLogger().log(LogEntry.SEVERITY_FATAL, null, XMLGenParam.getEntityType() + " " + XMLGenParam.getEntityReference() + " could not be exported");
            XMLGenParam.getLogger().log(LogEntry.SEVERITY_FATAL, e, e.getMessage());
            throw e;
        }
       logPerformance("New PolicyImportToXML:"+ XMLGenParam.getEntityReference());

    }


    /**
     *
     * @param out PrintWriter used to write the export XML
     * @param con Connection reference to the database
     * @param params Contains parameter values passed through the request
     * @param currentElementDecl Contains the current element declaration to be processed.
     * @param buffer Stores the XML to be flushed out to a file.
     * @param indentCount Used to keep track of the tabbing/indentation in the generated XML
     * @param user Application user logged in
     * @throws ExceptionImpl thrown in case of any error
     */

      private boolean generateObjectListXML(
            ListObjectHierarchy lstObjHierarchy,
            HashMap parentTableDataMap,
            HashMap paramMap,
            int indentCnt, StringBuffer buffer) throws ExceptionImpl {

        XMLGeneratorParameters XMLGenParam = getXMLGeneratorParameters();
        
        Table tableObj = (Table) getXsdCache().getTableMap().get(lstObjHierarchy.getObjectInfo().getBaseName());
		String tableExportMode = null;
		if(tableObj != null) {
			tableExportMode = tableObj.getExportMode();
		}
        
        if(tableObj != null && (tableExportMode == null || tableExportMode.equalsIgnoreCase(exportMode))) {        
        int characterCount = 0;
        if (lstObjHierarchy.getName()
                .equalsIgnoreCase(ROOT_ELEMENT)){
            characterCount = buffer.length();
            buffer.append("<" + lstObjHierarchy.getName());
            buffer.append(XMLGenParam.getXMLNameSpace());
            characterCount = buffer.length() - characterCount;
        }else{
            characterCount = buffer.length();
            printTab(buffer, indentCnt);
            buffer.append("<" + lstObjHierarchy.getName());
            characterCount = buffer.length() - characterCount;
        }
        buffer.append(">");
        characterCount += ">".length();

        HashMap xsdParams = lstObjHierarchy.getParamMap();

        if(paramMap==null){
            paramMap = new HashMap();
            paramMap.put(CONST_ENTITY_REFERENCE, XMLGenParam.getEntityReference());
            paramMap.put(CONST_ENTITY_TYPE, XMLGenParam.getEntityType());
        }

        if (xsdParams != null){
            Table tab = (Table)getXsdCache().getTableMap().
                            get(lstObjHierarchy.getParentLstObjHierarchy().getObjectInfo().getBaseName());
            String parentColPrefix;
            if(null != exportMode && "exportPolicyAsIs".equalsIgnoreCase(exportMode)) {
            	parentColPrefix = tab.getColumnPrefix("");
            } else {
            	parentColPrefix = tab.getColumnPrefix(XMLGenParam.getViewPrefix());
            }
            
            Set xsdParamEntrySet = xsdParams.entrySet();
            Iterator xsdIt = xsdParamEntrySet.iterator();
            while (xsdIt.hasNext()){
                Map.Entry mapEntry = (Map.Entry)xsdIt.next();
                String xsdKey = (String)mapEntry.getKey();
                String xsdValue = (String)mapEntry.getValue();
                if(parentColPrefix!= null && "_".equalsIgnoreCase(parentColPrefix)){
                	parentColPrefix="";
                }
                String dbValue = (String)parentTableDataMap.get(parentColPrefix + xsdValue);
                paramMap.put(xsdKey, dbValue);
            }
            paramMap.put(CONST_FK_COLUMN_NAME, lstObjHierarchy.getObjectInfo().getColumnName());
        }

        boolean isObjecWriteComplete = generateObjectXML(lstObjHierarchy.getObjectInfo(),
                paramMap,
                indentCnt,
                buffer);

        if(isObjecWriteComplete){
            printTab(buffer, indentCnt);
            buffer.append("</" + lstObjHierarchy.getName() + ">");
        }else{
            buffer.delete(buffer.length() - characterCount, buffer.length());
        }
        }        

        return true;
    }


    private boolean generateObjectXML(ObjectHierarchy ObjHierarchy,
            HashMap paramTableMap,
            int indentCnt, StringBuffer buffer){

        XMLGeneratorParameters XMLGenParam = getXMLGeneratorParameters();
        Table tableObj = (Table) getXsdCache().getTableMap().get(ObjHierarchy.getBaseName());
        String xsdWhereClauseStr = tableObj.getWhereClause();
        String xsdOrderByStr = tableObj.getOrderBy();
        StringBuffer xsdWhereClause = null;
        StringBuffer whereClauses = new StringBuffer();
        boolean rowExist=false;
        String columnPrefix;
        String viewPrefix;
        if(null != exportMode && "exportPolicyAsIs".equalsIgnoreCase(exportMode)) {
            columnPrefix = tableObj.getColumnPrefix("");
            viewPrefix = tableObj.getViewPrefixToUse("");
        } else {
        	columnPrefix = tableObj.getColumnPrefix(XMLGenParam.getViewPrefix());
        	viewPrefix = tableObj.getViewPrefixToUse(XMLGenParam.getViewPrefix());
        }
        paramTableMap.put(CONST_COLUMN_PREFIX, columnPrefix);
        if(columnPrefix!= null && "_".equalsIgnoreCase(columnPrefix)){
        	columnPrefix="";
        }
        
        String tableName = tableObj.getTableName();
        getXMLGeneratorParameters().getLogger().log(
                LogEntry.SEVERITY_INFO,
                null, "STARTING Export of table:" + tableName);
        getXMLGeneratorParameters().getLogger().log(LogEntry.SEVERITY_INFO, null, "***********************************************************");


        try {
            if (xsdWhereClauseStr != null && !"".equals(xsdWhereClauseStr)) {
                xsdWhereClause = new StringBuffer(xsdWhereClauseStr);
                HashMap variableMap = new HashMap();
                variableMap.put(
                        VariableResolverImpl.REQUESTPARAMS_PARAMETER,
                        paramTableMap);

                xsdWhereClause = resolveExpression(
                        xsdWhereClause,
                        new VariableResolverImpl(variableMap),
                        new DefaultFunctionResolver());
                whereClauses.append(" WHERE " + xsdWhereClause);
            } else {
                whereClauses.append(" WHERE " + columnPrefix
                        + "ENTITY_TYPE = '" + XMLGenParam.getEntityType()
                        + "' AND " + columnPrefix + "ENTITY_REFERENCE = '"
                        + XMLGenParam.getEntityReference() + "'");

                String fkColumnName = (String) paramTableMap
                        .get(CONST_FK_COLUMN_NAME);
                String fkColumnValue = (String) paramTableMap
                        .get(CONST_FK_COLUMN_VALUE);

                if (fkColumnName != null && fkColumnValue != null) {
                    whereClauses.append(" AND " + columnPrefix + fkColumnName
                            + " = '" + fkColumnValue + "'");
                }
            }
            /* Form the query to be executed */
            String tableQuery;
            String queryHint = tableObj.getQueryHint();
            if(GenUtil.isNullOrEmpty(queryHint)) {
                tableQuery = CONST_SELECT + " * FROM ";
            } else {
                tableQuery = CONST_SELECT + "/*+ " + queryHint +" */" + " * FROM "; // /*+ CURSOR_SHARING_EXACT */
            }
            /* Append the table name */
            tableQuery += viewPrefix + tableName;
            /* Append the where clause */
            tableQuery += whereClauses;
            if(!"".equals(xsdOrderByStr)){
                tableQuery +=xsdOrderByStr;
            }else{
                /* Append the order by clause */
                tableQuery += " ORDER BY 1 ASC";
            }


            ArrayList arrResultSet = null;
            ResultSet rs = null;
            Statement stmt = null;
            long time1;
            long time2;
            long time3;
            long time4;
            
            try{
                getXMLGeneratorParameters().getLogger().log(
                        LogEntry.SEVERITY_INFO,
                        null, "Running Select Query " + tableQuery + " to get table data." + NEWLINE);
                time1 = System.currentTimeMillis();
                
                stmt =  XMLGenParam.getDBConnection().createStatement();
                rs = stmt.executeQuery(tableQuery);
                
                time2 = System.currentTimeMillis();
                
                 indentCnt++;
                 /* Process the result */
                 rowExist = false;
                 arrResultSet = new ArrayList();
                 arrResultSet = getResultSet(rs);
                 
                 time3 = System.currentTimeMillis();
                 if ((time3-time2) > 0 || (time2-time1)> 0) {
 	                getXMLGeneratorParameters().getLogger().log(
 	                        LogEntry.SEVERITY_INFO,
 	                        null, "Query execution time " + ((time2-time1)) + " milliseconds "
 	                        + " Results reading time " + ((time3-time2))  + " milliseconds " + NEWLINE);
                 }
            } catch (Exception e) {
                getXMLGeneratorParameters().getLogger().log(LogEntry.SEVERITY_FATAL, e, "Error querying table while generating XML. Error=" + e.getMessage() + ". Query=" + tableQuery);
                throw new ExceptionImpl(ExceptionImpl.FATAL, "Error generating XML", e);
            } finally {
                try {
                    DBUtil.close(rs, stmt);
                } catch (SQLException sqle) {
                    getXMLGeneratorParameters().getLogger().log(LogEntry.SEVERITY_FATAL, sqle, "Error closing rs, stmt while generating XML. Error=" + sqle.getMessage());
                }
            }
            
            List replaceColumnNames = tableObj.getReplaceColumn();
    		List replaceColumnQuery = tableObj.getReplaceColumnValue();
    		List replaceColumnValue = null;
    		if(replaceColumnNames != null && replaceColumnQuery != null) {
    			replaceColumnValue = new ArrayList();
    			ResultSet replaceQuery_rs = null;
    		 	Statement replaceQuery_stmt = null;
    			for(int i = 0 ; i < replaceColumnQuery.size(); i++) {
    				try {
    					String columnQueryStr = (String) replaceColumnQuery.get(i);
    					if("DS_RESOURCE".equalsIgnoreCase(columnQueryStr)) {
    						if(dsrValueMap == null) {
    							columnQueryStr = "SELECT DSR_GID, DSR_UUID FROM DS_RESOURCE";
		    					StringBuffer columnQuery = new StringBuffer(columnQueryStr);
			    				replaceQuery_stmt =  XMLGenParam.getDBConnection().createStatement();
		    	            	HashMap variableMap = new HashMap();
		    	                variableMap.put(
		    	                        VariableResolverImpl.REQUESTPARAMS_PARAMETER,
		    	                        paramTableMap);
		
		    	                columnQuery = resolveExpression(
		    	                		columnQuery,
		    	                        new VariableResolverImpl(variableMap),
		    	                        new DefaultFunctionResolver());
		    	                columnQueryStr = columnQuery.toString();
			    				replaceQuery_rs = replaceQuery_stmt.executeQuery(columnQueryStr);
			    				dsrValueMap = new HashMap();
			    	            while(replaceQuery_rs.next()) {	    	                
			    	            	dsrValueMap.put(replaceQuery_rs.getString(1),replaceQuery_rs.getString(2));
			    	            }  									    	            
    						} 
    						replaceColumnValue.add(dsrValueMap);
    					} else  {
	    					StringBuffer columnQuery = new StringBuffer(columnQueryStr);
		    				replaceQuery_stmt =  XMLGenParam.getDBConnection().createStatement();
	    	            	HashMap variableMap = new HashMap();
	    	                variableMap.put(
	    	                        VariableResolverImpl.REQUESTPARAMS_PARAMETER,
	    	                        paramTableMap);

	    	                columnQuery = resolveExpression(
	    	                		columnQuery,
	    	                        new VariableResolverImpl(variableMap),
	    	                        new DefaultFunctionResolver());
	    	                columnQueryStr = columnQuery.toString();
		    				replaceQuery_rs = replaceQuery_stmt.executeQuery(columnQueryStr);
		    	            HashMap valueMap = new HashMap();
		    	            while(replaceQuery_rs.next()) {	    	                
		    	            	valueMap.put(replaceQuery_rs.getString(1),replaceQuery_rs.getString(2));
		    	            }
		    	            replaceColumnValue.add(valueMap);
						}
    				} catch (Exception e) {
    	                throw new ExceptionImpl(ExceptionImpl.FATAL, "Error generating XML", e);
    	            } finally {
    	                try {
	                        DBUtil.close(replaceQuery_rs, replaceQuery_stmt);
    	                } catch (SQLException sqle) {
    	                    getXMLGeneratorParameters().getLogger().log(LogEntry.SEVERITY_FATAL, sqle, sqle.getMessage());
    	                }
    	            }
    			}
    		}     		

            for(int iOuter = 0; iOuter< arrResultSet.size(); iOuter++){

            	time4 = System.currentTimeMillis();
                rowExist = true;
                getXMLGeneratorParameters().getLogger().log(
                        LogEntry.SEVERITY_INFO,
                        null,
                        "Adding row data to the exported XML");
                HashMap currentTableMap = new HashMap();
                currentTableMap.putAll((HashMap)arrResultSet.get(iOuter));
                if(replaceColumnNames != null && replaceColumnValue != null) {        			
        			for(int i = 0 ; i < replaceColumnValue.size(); i++) {
        				String columnName = (String)replaceColumnNames.get(i);
        				if(columnName != null && columnName.contains("PPE_EXPRESSIONS")){
        					String columnValue = (String) currentTableMap.get(columnName);
                        	Map coumnValueMap = (HashMap)replaceColumnValue.get(i); 
                        	PendingExpCovForExportImport pendingExpressionConvertor = new PendingExpCovForExportImport();
                        	String replaceValue = pendingExpressionConvertor.populatePendingExpressionsForExport(coumnValueMap, columnValue);
                        	currentTableMap.put(columnName, replaceValue);
        				}
        				else if(columnName != null && !columnName.contains("CONTEXT_PATH")) {
        					String columnValue = (String) currentTableMap.get(columnName);
                        	Map coumnValueMap = (HashMap)replaceColumnValue.get(i);
                        	String replaceValue = (String) coumnValueMap.get(columnValue);
                        	currentTableMap.put(columnName, replaceValue);
        				} else if (columnName != null && columnName.contains("CONTEXT_PATH")) {
        					String columnValue = (String) currentTableMap.get(columnName);
        					Map coumnValueMap = (HashMap)replaceColumnValue.get(i);
        					String replaceValue = replaceContextPathToUUID(coumnValueMap, columnValue);
        					currentTableMap.put(columnName, replaceValue);
        				}
        			}
        		}
                printTab(buffer, indentCnt);
                buffer.append("<" + ObjHierarchy.getName());

                //Get Attribute Info for the table
                ArrayList lstAttributeCols = tableObj.getAttributeColumns();
                if (tableObj.isIncludeAttributesGroup() == true) {
                    lstAttributeCols.addAll(getXsdCache()
                            .getAttributeGroup()
                            .getColumns());
                    Collections.sort((List)lstAttributeCols);
                }

                for (int iLoop = 0; iLoop < lstAttributeCols.size(); iLoop++) {
                    Column col = (Column) lstAttributeCols.get(iLoop);
                    String colValue = (String) currentTableMap.get(columnPrefix + col
                            .getColumnName());
                    if (!(col.isRequired() == true)
                            && (colValue == null || "".equals(colValue))) {
                        //Skip printing
                    } else {
                        buffer.append(" " + col.getName() + "=\"" + colValue
                                + "\"");
                    }
                }
                buffer.append(">");
                indentCnt++;



                boolean offsetRowPresent = false;
                HashMap mapOffsetResultSet = null;
                /* generateOffset is default true. Unless it is passed as false, offset will be generated, if supported
                 * supportsOffset is set for each object. It has to be specified as 'true' to generate offset for this table
                 * Offset generation is currently supported only for PCT objects
                 */
                if (XMLGenParam.getGenerateOffset()
                        && tableObj.isSupportsOffset()) {

                    if (tableObj.isRootObject()) {
                        setOldEntityType((String) currentTableMap
                                .get(columnPrefix + CONST_OLD_ENTITY_TYPE));
                        setOldEntityReference((String) currentTableMap
                                .get(columnPrefix + CONST_OLD_ENTITY_REFERENCE));
                        String transactionCode = ((String)currentTableMap.get(columnPrefix + CONST_TRANS_CODE));
                        // Changes made for SR#64021. Added condition for ALR and RLR transactions in below IF condition.
                        if("03AR".equalsIgnoreCase(transactionCode) || "03IR".equalsIgnoreCase(transactionCode) 
                        		|| "RLR".equalsIgnoreCase(transactionCode)){
                            setReviseAudit(true);
                        }
                    }

                    if (getOldEntityReference() != null
                            && !"".equals(getOldEntityReference())) {
                        String offsetTableQuery = CONST_SELECT + " * FROM ";
                        offsetTableQuery += viewPrefix + tableName;
                        if (tableObj.isPCTObject()) {
                            String id = (String) currentTableMap
                                    .get(columnPrefix + CONST_ID);
                            offsetTableQuery += " WHERE " + columnPrefix
                                    + "ENTITY_TYPE = '" + getOldEntityType()
                                    + "' AND " + columnPrefix
                                    + "ENTITY_REFERENCE = '"
                                    + getOldEntityReference() + "'";

                            if (! tableObj.isRootObject()) {
                                offsetTableQuery += " AND " + columnPrefix
                                        + "ID = " + id;
                                // In case of reviseAudit transaction
                                //Changes made for SR#59599
                               // if(isReviseAudit()==true){
                                    String sysStart = (String) currentTableMap.get(columnPrefix + "SYS_START_DATE");
                                    String sysEnd = (String) currentTableMap.get(columnPrefix + "SYS_END_DATE");

                                    if(sysStart != null && sysEnd != null){
                                           if(!"".equalsIgnoreCase(sysStart) && !"".equalsIgnoreCase(sysEnd)){
                                                  sysStart= sysStart.substring(0, 10).replaceAll("-", "/");
                                                  sysEnd= sysEnd.substring(0, 10).replaceAll("-", "/");
                                           }
                                           offsetTableQuery +=  " AND NVL ( " + columnPrefix + "SYS_START_DATE , to_date('1900/01/01', 'YYYY/MM/DD')) = ";
                                           offsetTableQuery += " NVL( to_date('" + sysStart + "','YYYY/MM/DD')" +  ", to_date('1900/01/01', 'YYYY/MM/DD'))";
                                           offsetTableQuery +=  " AND NVL ( " + columnPrefix + "SYS_END_DATE , to_date('1900/01/01', 'YYYY/MM/DD')) = ";
                                           offsetTableQuery += " NVL(to_date( '" +sysEnd +  "','YYYY/MM/DD'), to_date('1900/01/01', 'YYYY/MM/DD'))";

                                }
                            }
                        } else {
                            // replace entity reference with old entity reference in Where clause
                            Pattern pattern = Pattern.compile("'" + XMLGenParam
                                    .getEntityReference() + "'");
                            Matcher matcher = pattern.matcher(whereClauses);
                            String whereClauses_offset_entity_reference = matcher
                                    .replaceAll("'" + getOldEntityReference() + "'");
                            //replace Entity Type
                            Pattern pattern_entityType = Pattern
                                    .compile("'" + XMLGenParam.getEntityType() + "'");
                            Matcher matcher_entityType = pattern_entityType
                                    .matcher(whereClauses_offset_entity_reference);
                            String whereClauses_offset = matcher_entityType
                                    .replaceAll("'" + getOldEntityType() + "'");

                            offsetTableQuery += whereClauses_offset;

                            if (!("".equalsIgnoreCase(tableObj
                                    .getLinkingColumns()) || null == tableObj
                                    .getLinkingColumns())) {
                                String[] columns = tableObj
                                        .getLinkingColumns()
                                        .split(",");

                                for (int i = 0; i < columns.length; i++) {
                                    String colValue = (String) currentTableMap
                                            .get(columnPrefix + columns[i]);
                                    if (null == colValue
                                            || "".equalsIgnoreCase(colValue)) {
                                        // if column value is null add "is null" to the query
                                        offsetTableQuery += " AND "
                                                + columnPrefix + columns[i]
                                                + " is null";
                                        ;
                                    } else {
                                        offsetTableQuery += " AND "
                                                + columnPrefix + columns[i]
                                                + " = '" + colValue + "'";
                                    }
                                }
                            }
                        }
                        getXMLGeneratorParameters().getLogger().log(
                                LogEntry.SEVERITY_INFO,
                                null,
                                "Running Select  Off set Query "
                                        + offsetTableQuery
                                        + " to get table data." + NEWLINE);

                        ResultSet offset_rs = null;
                        Statement offset_stmt = null;
                        mapOffsetResultSet = new HashMap();
                        try{
                        	long startTime = System.currentTimeMillis();
                            offset_stmt = XMLGenParam.getDBConnection().createStatement();
                            offset_rs = offset_stmt.executeQuery(offsetTableQuery);
                            long endTime = System.currentTimeMillis();
                            if ((endTime-startTime) > 0 ) {
            	                getXMLGeneratorParameters().getLogger().log(
            	                        LogEntry.SEVERITY_INFO,
            	                        null, "Off set Query execution time " + ((endTime-startTime)) + " milliseconds " + NEWLINE);
                            }
                            mapOffsetResultSet = getFirstRowOfResultSet(offset_rs);
                            if(mapOffsetResultSet.size()>0){
                                offsetRowPresent = true;
                            }
                        } catch (Exception e) {
                            throw new ExceptionImpl(ExceptionImpl.FATAL, "Error generating XML", e);
                        } finally {
                            try {
                                DBUtil.close(offset_rs, offset_stmt);
                            } catch (SQLException sqle) {
                                getXMLGeneratorParameters().getLogger().log(LogEntry.SEVERITY_FATAL, sqle, sqle.getMessage());
                            }
                        }

                    }
                }

                ArrayList arrColumns = tableObj.getNonAttributeColumns();

                for (int iLoop = 0; iLoop < arrColumns.size(); iLoop++) {
                    StringBuffer elementBuffer = new StringBuffer();
                    Column col = (Column) arrColumns.get(iLoop);
                    ArrayList arrColAttributes = col.getLstAttributes();

                    for (int iInnerLoop =  arrColAttributes.size() -1; iInnerLoop >= 0; iInnerLoop--) {
                        ColumnAttribute colAttr = (ColumnAttribute) arrColAttributes
                                .get(iInnerLoop);
                        String colAttrValue = "";
                        if (colAttr.isOffSetValue()) {
                            if (offsetRowPresent && mapOffsetResultSet !=null) {
                                colAttrValue = (String)mapOffsetResultSet.get(
                                        columnPrefix + col.getColumnName());
                                //colAttrValue = ((colAttrValue == null || "null"
                                      //  .equalsIgnoreCase(colAttrValue)) ? ""
                                        //: colAttrValue);
                              colAttrValue = ((colAttrValue == null) ? ""
                                  : colAttrValue);
                                colAttrValue = XMLUtil
                                        .escapeStringForXML(colAttrValue);
                            }
                        } else {
                            colAttrValue = (String) currentTableMap.get(columnPrefix
                                    + col.getColumnName());
                            colAttrValue = ((colAttrValue == null) ? ""
                                    : colAttrValue);
                            colAttrValue = XMLUtil
                                    .escapeStringForXML(colAttrValue);
                        }

                        if (colAttr.isOffSetValue()) {
                            if (colAttrValue == null || "".equals(colAttrValue)) {
                                // Skip Printing
                            } else {
                                if(elementBuffer.length() ==0)
                                    elementBuffer.append("<"+col.getName());
                                elementBuffer.append(" " + colAttr.getName()
                                        + "=\"" + colAttrValue + "\"");
                            }
                        } else {
                            if (col.isNillable()
                                    && (colAttr.getName() == null || ""
                                            .equals(colAttrValue))) {
                                // Skip Printing
                            } else {
                                if(elementBuffer.length() ==0)
                                    elementBuffer.append("<"+col.getName());
                                elementBuffer.append(" " + colAttr.getName()
                                        + "=\"" + colAttrValue + "\"");
                            }
                        }

                    }
                    if(elementBuffer.length() !=0){
                        elementBuffer.append(" />");
                        printTab(buffer, indentCnt);
                        buffer.append(elementBuffer);
                    }
                }
                long time5 = System.currentTimeMillis();
                if ((time5-time4) > 0) {
	                getXMLGeneratorParameters().getLogger().log(
	                        LogEntry.SEVERITY_INFO,
	                        null, " XML generation time " + ((time5-time4))  + " milliseconds" + NEWLINE);
                }

                for (int iLoop = 0; iLoop < ObjHierarchy.getLstObject().size(); iLoop++) {
                    generateObjectListXML(
                            (ListObjectHierarchy) ObjHierarchy
                                    .getLstObject()
                                    .get(iLoop),
                            currentTableMap,
                            paramTableMap,
                            indentCnt,
                            buffer);
                }

                indentCnt--;
                printTab(buffer, indentCnt);
                buffer.append("</" + ObjHierarchy.getName() + ">");

                getXMLGeneratorParameters().getLogger().log(
                        LogEntry.SEVERITY_INFO,
                        null,
                        "COMPLETING Export of table:" + tableName);
                getXMLGeneratorParameters().getLogger().log(
                        LogEntry.SEVERITY_INFO,
                        null,
                        "***********************************************************"
                                + NEWLINE);

            }
        } catch (Exception e) {
            getXMLGeneratorParameters().getLogger().log(
                    LogEntry.SEVERITY_FATAL,
                    null, XMLGenParam.getEntityType() + " " + XMLGenParam.getEntityReference() + " could not be exported");
            getXMLGeneratorParameters().getLogger().log(LogEntry.SEVERITY_FATAL,
                    e, e.getMessage());
        }
        return rowExist;

    }

  private String replaceContextPathToUUID(Map<String, String> coumnValueMap,
			String columnValue) {
	    String[] columnValueList = columnValue.split("/");
	    StringBuilder replaceValue = new StringBuilder();
	    int count = 0;
	    for(String str : columnValueList) {
	    	if(count > 0) {
	    		replaceValue.append('/');
	    	}
	    	String value = coumnValueMap.get(str);
	    	if(value == null) {
	    		value = "";
	    	}
	    	replaceValue.append(value);
	    	count++;
	    }	    
	    replaceValue.append('/');
		return replaceValue.toString();
	}

private ArrayList getResultSet(ResultSet rs) throws ExceptionImpl, SQLException{
      ArrayList arr = new ArrayList();
      String columnName = "";
      String columnValue = "";
      while(rs.next()){
          ResultSetMetaData rsmd = rs.getMetaData();
          HashMap map = new HashMap();
          for (int i=1; i <= rsmd.getColumnCount(); i++){
              columnName = rsmd.getColumnName(i);
              columnValue = getColumnValueAtIndex(rs, i);
            //Changes Start for SR 76650
              Pattern unicodeOutliers = Pattern.compile(HTTPConstants.REGULER_EXPRESSION,
                      Pattern.UNICODE_CASE | Pattern.CANON_EQ
                              | Pattern.CASE_INSENSITIVE);
              Matcher unicodeOutlierMatcher = unicodeOutliers.matcher(columnValue);
              columnValue = unicodeOutlierMatcher.replaceAll(" ");
              map.put(columnName, columnValue);
            //Changes End for SR 76650
          }
          arr.add(map);
      }
      return arr;
  }

  private HashMap getFirstRowOfResultSet(ResultSet rs) throws ExceptionImpl, SQLException{
      HashMap map = new HashMap();
      String columnName = "";
      String columnValue = "";
      while(rs.next()){
          ResultSetMetaData rsmd = rs.getMetaData();
          for (int i=1; i <= rsmd.getColumnCount(); i++){
              columnName = rsmd.getColumnName(i);
              columnValue = getColumnValueAtIndex(rs, i);
            //Changes Start for SR 76650
              Pattern unicodeOutliers = Pattern.compile(HTTPConstants.REGULER_EXPRESSION,
                      Pattern.UNICODE_CASE | Pattern.CANON_EQ
                              | Pattern.CASE_INSENSITIVE);
              Matcher unicodeOutlierMatcher = unicodeOutliers.matcher(columnValue);
              columnValue = unicodeOutlierMatcher.replaceAll(" ");
              map.put(columnName, columnValue);
            //Changes End for SR 76650
          }
          return map;
      }
      return map;
  }


  /**
   * This method returns the value for the specified column from the resultset
   * @param rs
   * @param columnName
   * @return
   * @throws ExceptionImpl
   */
  private String getColumnValue(ResultSet rs, String columnName) throws ExceptionImpl{
      ResultSetMetaData rsmd = null;
      String columnValue = null;
      try{

          rsmd = rs.getMetaData();
          for (int j = 1; j <= rsmd.getColumnCount(); j++) {
              if (columnName.equalsIgnoreCase(rsmd.getColumnName(j))){
                  /* Get the column value */
                  columnValue = getColumnValueAtIndex(rs, j);
                  break;
              }
          }
      }catch(Exception e){
          throw new ExceptionImpl(ExceptionImpl.FATAL, "Error in obtaining the value for column: " + columnName, e);
      }
      return columnValue;
  }



  /**
   * This method prints out indentCount number of tabs, on a new line, in the export XML.
   * @param out StringBuffer used to write the export XML
   * @param indentCount Used to keep track of the tabbing/indentation in the generated XML
   */
  private void printTab(StringBuffer buff, int indentCount) {
      
	  if(indentXML) {
      int indentIndex = 0;
      String indentTab = "    ";
      indentIndex = indentCount;
      buff.append(NEWLINE);
      while (indentIndex != 0) {
          buff.append(indentTab);
          indentIndex--;
      }
  }
  }

  /**
   * This method returns the value of the column at the index specified from the resultset
   * @param rs
   * @param columnIndex
   * @return
   * @throws ExceptionImpl
   */
  private String getColumnValueAtIndex(ResultSet rs, int columnIndex) throws ExceptionImpl{
      ResultSetMetaData rsmd = null;
      String columnValue = null;
      String columnName = null;
      try{
          rsmd = rs.getMetaData();
          if (("varchar2").equalsIgnoreCase(rsmd.getColumnTypeName(columnIndex)) ||
              ("char").equalsIgnoreCase(rsmd.getColumnTypeName(columnIndex))) {
              columnValue = rs.getString(columnIndex);
              if (null == columnValue){
                  columnValue = "";
              }
          } else if (("number").equalsIgnoreCase(rsmd.getColumnTypeName(columnIndex))) {
              DecimalFormat formatter = new DecimalFormat("#.##########");
              double d = rs.getDouble(columnIndex);
              columnValue = "" + formatter.format(d);

              if (rs.wasNull()){
                  columnValue = "";
              }
          } else if (("date").equalsIgnoreCase(rsmd.getColumnTypeName(columnIndex))) {
               //Changes made for SR#58135.
				/* Changes are made because whenever we export a policy it was showing the date properly but the time was wrong i.e. 00:00:00
				To provide the time with date we have used timestamp */
			  java.sql.Timestamp timeStampValue = rs.getTimestamp(columnIndex);
              if (timeStampValue != null) {
              SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
                  columnValue = dateFormat.format(timeStampValue);
              }else{
                  columnValue = "";
              }
          } else if (("clob").equalsIgnoreCase(rsmd.getColumnTypeName(columnIndex))) {
              columnValue =
                      DBUtil.readClob(rs.getClob(columnIndex));
              if ("null".equalsIgnoreCase(columnValue) || null == columnValue){
                  columnValue = "";
              }
          }
          columnName = rsmd.getColumnName(columnIndex);
      }catch(Exception e){
          throw new ExceptionImpl(ExceptionImpl.FATAL, "Error in obtaining the value for column: " + columnName, e);
      }
      return columnValue;
  }

  /**
  *
  * This method is used to resolve the Where clause
  * @param where clause string to resolve.
  * @param VariableResolver
  * @param FunctionResolver
  * @throws ELParseException, ELException thrown in case of any error
  */
  private StringBuffer resolveExpression(StringBuffer whereClauses,
              VariableResolver varResolver,
              FunctionResolver funcResolver2) throws ELParseException, ELException {
      InlineExpression expression = new InlineExpression(whereClauses.toString(), varResolver, funcResolver2);
      whereClauses = new StringBuffer(expression.getValue());
      return whereClauses;
  }
  
  
  
  public static boolean isNullOrEmpty(String str) {
      return (str == null || str.trim().equals(""));
  }
  
  public static String customTrim(String str) {
      return (str == null) ? "" : str.trim();
  }

  public XMLGeneratorParameters getXMLGeneratorParameters() {
      return xmlGeneratorParameters;
  }
  public void setXMLGeneratorParameters(XMLGeneratorParameters generatorParameters) {
      xmlGeneratorParameters = generatorParameters;
  }

  public String getOldEntityType() {
      return oldEntityType;
  }

  public void setOldEntityType(String oldEntityType) {
      this.oldEntityType = oldEntityType;
  }

  public String getOldEntityReference() {
      return oldEntityReference;
  }

  public void setOldEntityReference(String oldEntityReference) {
      this.oldEntityReference = oldEntityReference;
  }

  public XSDCache getXsdCache() {
      return xsdCache;
  }

  static final Runtime runtime = Runtime.getRuntime ();
  static void logPerformance (String msg){
      if(logPerformance){
          System.out.println("Performace Log --> Memory Usage Log:" + msg + ":" + (runtime.totalMemory () - runtime.freeMemory ()));
          System.out.println("Performace Log --> Time Log (in millisecond):" + msg + ":" + Calendar.getInstance().getTimeInMillis());
      }
  }

  public boolean isReviseAudit() {
    return isReviseAudit;
  }

  public void setReviseAudit(boolean isReviseAudit) {
     this.isReviseAudit = isReviseAudit;
  }
}