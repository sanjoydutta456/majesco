package com.majesco.custom.pi.ri.services;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.google.gson.Gson;
import com.coverall.exceptions.ExceptionImpl;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.vo.PctObjectKey;
import com.coverall.mt.xml.xmlextractv2.PolicyExportToXML;
import com.coverall.mt.xml.xmlextractv2.PolicyExportToXMLForImport;
import com.coverall.util.CommandUtil;
import com.coverall.util.DBUtil;

public class PolicyExportTransaction implements Serializable {
	public static final String CONST_EXPORT_ALL_MODE = "exportAllPolicy";
	private static final String CONST_EXPORT_AS_XML = "exportPolicyAsXML";
	public static final String CONST_EXPORT_ALL_AS_IS_MODE = "exportAllPolicyAsIs";
	private String entityType = null;
	private String entityReference = null;
	private String entityDisplayName = null;
	private String exportMode = null;
	private Connection conn = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;
	private File tempFile = null;
	private Map exportPolicesList= null;
	private User user = null;
	private String basePath = null;
	private String exportXMLFolder = null;
	private String customerCode = null;
	private Map savedFilePath = new LinkedHashMap();
	private String zipFileSavePath = null;
	String tempfolderName = null;
	private int percentComplete = 0;
	private int currentRevisionCount = 0;
	private String viewPrefixParam = null;
	public static final String EXPORT_XML_FOR_IMPORT = "exportPolicyForImport";
	public static final String EXPORT_XML_FOR_JSON = "exportPolicyAsIsJson";

	public PolicyExportTransaction(String entityReference,String entityType,String entityDisplayName, String operationMode,String viewPrefixParam, User user ){
		this.entityReference = entityReference;
		this.entityType = entityType;
		this.entityDisplayName = entityDisplayName;
		this.exportMode = operationMode;
		this.viewPrefixParam  = viewPrefixParam;
		this.user= user;
		if (user != null) {
			this.customerCode = CustomerConfigUtil.getInstance().getCustomerCode(user.getDomain());
		}
	}

	public String processExportTransaction() throws Exception{
		try {
			
			if(exportMode.equalsIgnoreCase(EXPORT_XML_FOR_JSON)){
				exportPolicyJson();
			}else{
				exportPolicyXMLs();
			}
			
			if(exportMode.equalsIgnoreCase(CONST_EXPORT_AS_XML) || EXPORT_XML_FOR_IMPORT.equalsIgnoreCase(exportMode) || exportMode.equalsIgnoreCase(EXPORT_XML_FOR_JSON)){
				ArrayList xmlpath = (ArrayList)savedFilePath.get(entityReference);
				if( xmlpath !=null && xmlpath.size() > 0 ){
					zipFileSavePath = basePath + File.separator + "interfaces" + File.separator + customerCode + File.separator +xmlpath.get(0).toString();
				}
			}else {
				createManifestXMLfile(savedFilePath, exportXMLFolder + File.separator +"MANIFEST.XML");
				//Changes for SR#74579
				if (entityDisplayName.contains("/")){
					String[] dispPolicyNoArr = entityDisplayName.split("/");
					if (dispPolicyNoArr.length > 0) { 
						entityDisplayName = dispPolicyNoArr[0];      
					}			
				}
				zipFileSavePath = basePath + File.separator + "interfaces" + File.separator + customerCode + File.separator + entityDisplayName +".zip";   
				//End of changes made for SR#74579
				createZipFile(zipFileSavePath, exportXMLFolder);
				deleteTempDirectory(new File(exportXMLFolder));
			}

		}
		catch(Exception e){
			LogMinder.getLogMinder().log(
                    LogEntry.SEVERITY_FATAL,
                    "PolicyExportTransaction",
                    "processExportTransaction",
                    "",
                    new Object[] {},
                    "There is problem while creating policy XML",
                    e,
                    LogMinderDOMUtil.VALUE_MIC);
			throw new Exception("There is problem processing export transaction for entity reference " + entityReference + " . Please MIC log for more detail.");
		}

		return zipFileSavePath;

	}

	private boolean exportPolicyXMLs()
	{
		if (exportPolicesList != null) {
			HashMap params = new HashMap();
			String exportXmlFile = null;
			File file = null;
			if(exportMode.equalsIgnoreCase(CONST_EXPORT_AS_XML) && viewPrefixParam != null && !("".equalsIgnoreCase(viewPrefixParam.trim()))){
				params.put("viewPrefix",viewPrefixParam);

			}else{
				params.put("viewPrefix","AT");
			}
			ArrayList policyRevisionData = null;
			Iterator iterator = exportPolicesList.keySet().iterator();
			String policyReference=null;
			String policyType = null;
			while(iterator. hasNext()){
				policyReference = (String)iterator.next();
				policyType = (String) exportPolicesList.get(policyReference);
				policyRevisionData = new ArrayList();
				file = new File(exportXMLFolder + File.separator + policyReference + File.separator+ "XML");
				file.mkdirs();
				params.put("entityType", policyType);
				params.put("entityReference", policyReference);
				if(exportMode.equalsIgnoreCase(CONST_EXPORT_ALL_AS_IS_MODE)) {
					params.put("exportMode", "exportPolicyAsIs");
				} else {
					params.put("exportMode", exportMode);
				}
				tempFile = new File(exportXMLFolder + File.separator + policyReference + File.separator + "XML" +File.separator+ policyReference + ".xml");
				exportXmlFile = exportXMLFolder + File.separator + policyReference
				+ File.separator +"XML" + File.separator + tempFile.getName();

				LogMinder.getLogMinder().log(
	                    LogEntry.SEVERITY_INFO,
	                    "PolicyExportTransaction",
	                    "exportPolicyXMLs",
	                    "",
	                    new Object[] {},
	                    "Exporting XML for entity reference -" + policyReference,
	                    null,
	                    LogMinderDOMUtil.VALUE_MIC);

				try {
					if(EXPORT_XML_FOR_IMPORT.equalsIgnoreCase(exportMode))	{
						PolicyExportToXMLForImport exporter = new PolicyExportToXMLForImport(exportXmlFile, params, user, true);
						exporter.generateXML();
					}else	{
						PolicyExportToXML policyClzz = new PolicyExportToXML(exportXmlFile, params, user, true);
						policyClzz.generateXML();
					}
				 } catch (Exception e) {
					LogMinder.getLogMinder().log(
		                    LogEntry.SEVERITY_FATAL,
		                    "PolicyExportTransaction",
		                    "exportPolicyXMLs",
		                    "",
		                    new Object[] {},
		                    "Export XML failed for entity reference -" + policyReference,
		                    e,
		                    LogMinderDOMUtil.VALUE_MIC);

				}

				currentRevisionCount = currentRevisionCount + 1;
				setExportPolicyProgressStatus();
				policyRevisionData.add((tempFile.getAbsolutePath()).substring(exportXMLFolder.lastIndexOf(tempfolderName)));
				savedFilePath.put(policyReference, policyRevisionData);

			}

			return true;
		}
		return false;
	}
	
	
	private boolean exportPolicyJson()
	{
		if (exportPolicesList != null) {
			HashMap params = new HashMap();
			String exportXmlFile = null;
			File file = null;			
			ArrayList policyRevisionData = null;
			Iterator iterator = exportPolicesList.keySet().iterator();
			String policyReference=null;
			String policyType = null;
			while(iterator. hasNext()){
				policyReference = (String)iterator.next();
				policyType = (String) exportPolicesList.get(policyReference);
				policyRevisionData = new ArrayList();
				file = new File(exportXMLFolder + File.separator + policyReference + File.separator+ "JSON");
				file.mkdirs();
				params.put("entityType", policyType);
				params.put("entityReference", policyReference);
				tempFile = new File(exportXMLFolder + File.separator + policyReference + File.separator + "JSON" +File.separator+ policyReference + ".json");
				exportXmlFile = exportXMLFolder + File.separator + policyReference
				+ File.separator +"JSON" + File.separator + tempFile.getName();

				LogMinder.getLogMinder().log(
	                    LogEntry.SEVERITY_INFO,
	                    "PolicyExportTransaction",
	                    "exportPolicyJson",
	                    "",
	                    new Object[] {},
	                    "Exporting Json for entity reference -" + policyReference,
	                    null,
	                    LogMinderDOMUtil.VALUE_MIC);

				try {
					
					Object response = null;
					try {
						Class extractRequestClass = Class.forName("com.coverall.pctv2.server.rs.service.microservices.ExtractTransactionRequest");
						Method entityMet = extractRequestClass.getMethod("setEntityType", String.class);
						Method refMet = extractRequestClass.getMethod("setEntityReference", String.class);
						Method detMet = extractRequestClass.getMethod("setPolicyAdditionalDetails", String.class);
						Object extractTransactionRequest = extractRequestClass.newInstance();
						entityMet.invoke(extractTransactionRequest, policyType);
						refMet.invoke(extractTransactionRequest, policyReference);
						detMet.invoke(extractTransactionRequest, "Y");
						
						Class processorClass = Class.forName("com.coverall.pctv2.server.service.ExtractTransactionProcessor");
						Method method = processorClass.getMethod("extractTransaction", String.class);
						Class[] parameterTypes = {extractRequestClass, User.class };
						Constructor cons = processorClass.getConstructor(parameterTypes);
						Object[] arguments = {extractTransactionRequest, user};
						Object extractTransactionProcessor = cons.newInstance(arguments);
						response = method.invoke(extractTransactionProcessor, "N");
						
						
					} catch (Exception e) {
						throw new ExceptionImpl(ExceptionImpl.FATAL, "Error while Reading CFP to get updatable Fields", e);
					}
					
					// Writing the Jason into response
					String json = new Gson().toJson(response);
					
					PrintWriter XMLWriter = null;
					
					try {
		                /* Get PrintWriter to the write the Export XML */
		                XMLWriter = new PrintWriter(new FileWriter(exportXmlFile));
		                XMLWriter.print(json);
				        XMLWriter.flush();
		            }catch (Exception e) {
		                
		            } finally{
		            	try {
		                    if (XMLWriter != null) {
		                        XMLWriter.close();
		                    }
		                } catch (Exception e) {
		                    
		                }
		            }
					
					
					
				 } catch (Exception e) {
					LogMinder.getLogMinder().log(
		                    LogEntry.SEVERITY_FATAL,
		                    "PolicyExportTransaction",
		                    "exportPolicyXMLs",
		                    "",
		                    new Object[] {},
		                    "Export XML failed for entity reference -" + policyReference,
		                    e,
		                    LogMinderDOMUtil.VALUE_MIC);

				}

				currentRevisionCount = currentRevisionCount + 1;
				setExportPolicyProgressStatus();
				policyRevisionData.add((tempFile.getAbsolutePath()).substring(exportXMLFolder.lastIndexOf(tempfolderName)));
				savedFilePath.put(policyReference, policyRevisionData);

			}

			return true;
		}
		return false;
	}
	
	
	
	public boolean initializePolicyExportTransaction() throws Exception{
		try{
		boolean success = false;
		exportPolicesList = new LinkedHashMap();
		basePath = System.getProperty("mic.system.home");
		tempfolderName = "Export" + new Date().getTime();
		exportXMLFolder = basePath + File.separator + "interfaces" + File.separator + customerCode + File.separator +tempfolderName;
		File exportFolder = new File(exportXMLFolder);
		exportFolder.mkdirs();
		if(exportMode.equalsIgnoreCase(CONST_EXPORT_ALL_MODE) || exportMode.equalsIgnoreCase(CONST_EXPORT_ALL_AS_IS_MODE)){

				conn = ConnectionPool.getConnection(user);
				if (conn != null) {
				   pst = conn.prepareStatement(" SELECT B.entity_reference, B.entity_type " +
						   					   " FROM ev_mis_quote_policies A, " +
						   					   " ev_mis_quote_policies B " +
						   					   " WHERE A.entity_reference   = ? " +
						   					   " AND B.org_entity_reference = A.org_entity_reference order by b.revision_number asc");

					pst.setString(1, entityReference);

					rs = pst.executeQuery();
					while (rs.next()) {
						exportPolicesList.put(rs.getString("entity_reference"),rs.getString("entity_type") );
					}
					success = true;
				} else {
					LogMinder.getLogMinder().log(
		                    LogEntry.SEVERITY_INFO,
		                    "PolicyExportTransaction",
		                    "initializePolicyExportTransaction",
		                    "",
		                    new Object[] {},
		                    "There is problem while getting database connection.",
		                    null,
		                    LogMinderDOMUtil.VALUE_MIC);
			}

		}
		else {
					exportPolicesList.put(entityReference,entityType);
			}
		}
		catch(Exception e){
			LogMinder.getLogMinder().log(
                    LogEntry.SEVERITY_FATAL,
                    "PolicyExportTransaction",
                    "initializePolicyExportTransaction",
                    "",
                    new Object[] {},
                    "There is problem while initialize policy export transaction.",
                    e,
                    LogMinderDOMUtil.VALUE_MIC);
					throw new Exception("There is problem while initializing Policy Export Transaction.");
		}
		finally{
			try {
				DBUtil.close(null, pst, conn);

			} catch (SQLException e) {
				LogMinder.getLogMinder().log(
	                    LogEntry.SEVERITY_FATAL,
	                    "PolicyExportTransaction",
	                    "initializePolicyExportTransaction",
	                    "",
	                    new Object[] {},
	                    "There is problem while closing database connection.",
	                    e,
	                    LogMinderDOMUtil.VALUE_MIC);
				throw new Exception("There is problem while creating database connection. ");
			}
		}
		return true;
	}
	private void createManifestXMLfile(Map exportedFilePaths ,String fileSavePath) throws Exception {

		DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
		Document document = documentBuilder.newDocument();
		Element rootElement = document.createElement("POLICY");
		document.appendChild(rootElement);
		Iterator iterator = exportedFilePaths.keySet().iterator();
		String policyReference=null;
		while(iterator. hasNext()){
			policyReference = (String)iterator.next();
			Element revision = document.createElement("REVISON");
			revision.setAttribute("ENTITY_REFERENCE", policyReference);
			rootElement.appendChild(revision);
			ArrayList al = (ArrayList)exportedFilePaths.get(policyReference);
			for(int i=0;i<al.size();i++){
				switch(i){
					case 0 :  Element exportedXML = document.createElement("XML");
					exportedXML.appendChild(document.createTextNode((String)al.get(i)));
					revision.appendChild(exportedXML);
					break;

					/*
    				case 1 :  Element exportedPDF = document.createElement("PDF");
    						  exportedPDF.appendChild(document.createTextNode((String)al.get(i)));
    						  revision.appendChild(exportedPDF);
    						  break;

    				case 2 :  Element exportedLogs = document.createElement("LOG");
    						  exportedLogs.appendChild(document.createTextNode((String)al.get(i)));
    						  revision.appendChild(exportedLogs);
    						  break;
					 */
				}

			}
		}

		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(document);
		FileOutputStream fs = new FileOutputStream( new File(fileSavePath));
		StreamResult result = new StreamResult(fs);
		transformer.transform(source, result);
		fs.close();

	}

	private void createZipFile(String zipFileName, String inputFolderPath) throws Exception {

		File dirObj = new File(inputFolderPath);
		ZipOutputStream out = new ZipOutputStream(new FileOutputStream(zipFileName));
		
		if (CommandUtil.isLinux()) {
			addDirecoryToZipFolderLinux(tempfolderName,dirObj, out);
		} else {
		addDirecoryToZipFolder(tempfolderName,dirObj, out);
		}
		out.close();

	}

	private void addDirecoryToZipFolderLinux(String path, File dirObj, ZipOutputStream out) throws IOException {
		File[] files = dirObj.listFiles();
		byte[] tmpBuf = new byte[1024];

		for (int i = 0; i < files.length; i++) {
			if (files[i].isDirectory()) {
				path = files[i].getAbsolutePath();
				path = path.substring(path.lastIndexOf(tempfolderName));
                addDirecoryToZipFolderLinux(path,files[i], out);
				continue;
			}
            FileInputStream in = new FileInputStream(files[i].getAbsolutePath());
            path = files[i].getAbsolutePath();
            path = path.substring(path.lastIndexOf(tempfolderName));            
			out.putNextEntry(new ZipEntry(path));
			int len;
			while ((len = in.read(tmpBuf)) > 0) {
				out.write(tmpBuf, 0, len);
			}
			out.closeEntry();
			in.close();
		}
	}

	private void addDirecoryToZipFolder(String path, File dirObj, ZipOutputStream out) throws IOException {
		File[] files = dirObj.listFiles();
		byte[] tmpBuf = new byte[1024];

		for (int i = 0; i < files.length; i++) {
			if (files[i].isDirectory()) {
				path = files[i].getAbsolutePath();
				path = path.substring(path.lastIndexOf(tempfolderName));
				addDirecoryToZipFolder(path,files[i], out);
				continue;
			}
			FileInputStream in = new FileInputStream(files[i].getAbsolutePath());
			path = path.substring(path.lastIndexOf(tempfolderName));
			out.putNextEntry(new ZipEntry(path+File.separator+ files[i].getName()));
			int len;
			while ((len = in.read(tmpBuf)) > 0) {
				out.write(tmpBuf, 0, len);
			}
			out.closeEntry();
			in.close();
		}
	}

	public boolean deleteTempDirectory( File fileOrDirectory ) {
		if (fileOrDirectory == null) return false;
		if (!fileOrDirectory.exists()) return false;
		if (fileOrDirectory.isDirectory()) {
			File listFile[] = fileOrDirectory.listFiles();
			for(int i=0;i<listFile.length;i++)
			{
				deleteTempDirectory(listFile[i]); // recursive call
			}
		}
		return fileOrDirectory.delete();
	}

	private void setExportPolicyProgressStatus() {
		if(exportPolicesList != null){
			int totalRevisions = exportPolicesList.size();
			float temp = (float) currentRevisionCount / totalRevisions;
			percentComplete = (int) (temp * 100);

		}
	}

	public int getExportPolicyProgressStatus() {
		return percentComplete;

	}

	public String getZipFilePath() {
		return zipFileSavePath;
	}

	public String getEntityReference() {
		return entityReference;
	}

	public String getEntityDisplayName() {
		return entityDisplayName;
	}

	public String getExportMode() {
		return exportMode;
	}
	
	public boolean initializePolicyExportTransactionNew() throws Exception{
		try{
		boolean success = false;
		exportPolicesList = new LinkedHashMap();
		basePath = System.getProperty("mic.system.home");
		tempfolderName = "Export" + new Date().getTime();
		exportXMLFolder = basePath + File.separator + "interfaces" + File.separator + customerCode + File.separator +tempfolderName;
		File exportFolder = new File(exportXMLFolder);
		exportFolder.mkdirs();
		if(exportMode.equalsIgnoreCase(CONST_EXPORT_ALL_MODE) || exportMode.equalsIgnoreCase(CONST_EXPORT_ALL_AS_IS_MODE)){

				conn = ConnectionPool.getConnection(user);
				if (conn != null) {
				   pst = conn.prepareStatement(" SELECT B.entity_reference, B.entity_type " +
						   					   " FROM ev_mis_quote_policies A, " +
						   					   " ev_mis_quote_policies B " +
						   					   " WHERE A.entity_reference   = ? " +
						   					   " AND B.org_entity_reference = A.org_entity_reference order by b.revision_number asc");

					pst.setString(1, entityReference);

					rs = pst.executeQuery();
					while (rs.next()) {
						exportPolicesList.put(rs.getString("entity_reference"),rs.getString("entity_type") );
					}
					success = true;
				} else {
					LogMinder.getLogMinder().log(
		                    LogEntry.SEVERITY_INFO,
		                    "PolicyExportTransaction",
		                    "initializePolicyExportTransaction",
		                    "",
		                    new Object[] {},
		                    "There is problem while getting database connection.",
		                    null,
		                    LogMinderDOMUtil.VALUE_MIC);
			}

		}
		else {
					exportPolicesList.put(entityReference,entityType);
			}
		}
		catch(Exception e){
			LogMinder.getLogMinder().log(
                    LogEntry.SEVERITY_FATAL,
                    "PolicyExportTransaction",
                    "initializePolicyExportTransaction",
                    "",
                    new Object[] {},
                    "There is problem while initialize policy export transaction.",
                    e,
                    LogMinderDOMUtil.VALUE_MIC);
					throw new Exception("There is problem while initializing Policy Export Transaction.");
		}
		finally{
			try {
				DBUtil.close(null, pst, conn);

			} catch (SQLException e) {
				LogMinder.getLogMinder().log(
	                    LogEntry.SEVERITY_FATAL,
	                    "PolicyExportTransaction",
	                    "initializePolicyExportTransaction",
	                    "",
	                    new Object[] {},
	                    "There is problem while closing database connection.",
	                    e,
	                    LogMinderDOMUtil.VALUE_MIC);
				throw new Exception("There is problem while creating database connection. ");
			}
		}
		return true;
	}


}
