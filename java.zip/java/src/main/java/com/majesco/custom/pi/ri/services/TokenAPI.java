package com.majesco.custom.pi.ri.services;

import java.io.*;
import java.net.*;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

import org.json.JSONObject;

import com.coverall.mt.events.EventProcessor;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.majesco.pi.portal.noc.constants.NocHoldRleaseConstants;
public class  TokenAPI{

    public String tokenResponse(User user) {

    	
    	
    	String accessToken = "";
    	
    	 String jsonInputString = "";
        
        
                try {
                	
                	Map webserviceParams =  EventProcessor.
                			getWebServiceParameters(DatalakeConstants.DATALAKE_WEBSERVICE , user);
                	
                	String tokenURL= (String)webserviceParams.get(DatalakeConstants.DATALAKE_TOKEN_BASE_URL);
                	
                	String grantType = (String)webserviceParams.get(DatalakeConstants.GRANT_TYPE);
                    
                	String client_secret =(String)webserviceParams.get(DatalakeConstants.CLIENT_SECRET);
                    
                	String client_id =(String)webserviceParams.get(DatalakeConstants.CLIENT_ID);
                	
                	String scope = (String)webserviceParams.get(DatalakeConstants.SCOPE);
                	
                	
                     URL url = new URL(tokenURL);
                    HttpsURLConnection con = (HttpsURLConnection)url.openConnection();
                    
                    
                    con.setDoOutput(true);
                    con.setDoInput(true);
                    con.setRequestMethod("POST"); 
                    
                    
                    
                     jsonInputString =("client_secret="+client_secret+"&client_id="+client_id+"&scope="+scope+"&grant_type="+grantType);
                            
                    OutputStream os = con.getOutputStream();
                    
                    byte[] postData = jsonInputString.getBytes("utf-8");
                    int postDataLength = postData.length;
                                        
                    os.write(postData, 0, postDataLength);             
                    
                    // Read the response.
                    InputStreamReader isr=null;
                        if (con.getResponseCode() == 200) {
                     isr = new InputStreamReader(con.getInputStream());
                    }
                            else
                         {
                                               isr = new InputStreamReader(con.getErrorStream());
                                               
                                               accessToken = "Error: Token Generation";
                                               
                                               return accessToken;
                   }
                    BufferedReader in = new BufferedReader(isr);
                    String responseString = "";
                    String outputString = "";
                   // Write response to a String.
                    while ((responseString = in.readLine()) != null) {
                     outputString = outputString + responseString;
                    }
                    
                    JSONObject jsonObject = new JSONObject(outputString);
                    
                    String finalToken = jsonObject.getString("access_token");
                    
                       accessToken = finalToken;
                       
                       
                       LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                               this.getClass().getName(),
                               "gatherInput",
                               ServletConfigUtil.COMPONENT_FRAMEWORK,
                               new Object[] { finalToken },
                               "Created Date " , null,
                               
                               LogMinderDOMUtil.VALUE_MIC);
               
                
                } 
                catch (Exception e) 
                {
                    accessToken = "Error: Token Generation"; //+ e.getMessage();            
                }

       
				return accessToken;
        
    }

}