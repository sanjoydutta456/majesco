/*
\ *                 Code License Notice 
 *
 * The contents of this file are subject to the Majesco Code License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License
 *
 * The Original Code is for My Insurance Center. The Initial Developer
 * of the Original Code is Majesco, All Rights Reserved.
 */

package com.majesco.custom.pi.ri.services;

import java.io.PrintWriter;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.w3c.dom.Document;

import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;
import com.coverall.mt.services.SchedulableService;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServicesDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;
import com.coverall.util.XMLUtil;
import com.majesco.custom.pi.ri.services.workflownotification.api.NotificationServiceResponse;
import com.majesco.custom.pi.ri.services.workflownotification.api.WorkflowStatusNotification;
import com.majesco.custom.pi.ri.services.workflownotification.client.NotificationServiceRestClient;

/**
 * DOCUMENT ME!
 *
 * @author $Author:   nishikanta_b  $
 * @version $Revision:   1.18  $
 */
public class WorkFlowNotificationService extends SchedulableService {

    /** Constant for Temp Folder **/
    private static final String TEMP = "temp";
    private static final Random randomizer = new Random();

    /**
     * Creates a new UnderwriterUploadService object.
     *
     * @throws RemoteException DOCUMENT ME!
     */
    public WorkFlowNotificationService() throws RemoteException {
    	super();
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String getComponentName() {
        return ServletConfigUtil.COMPONENT_RI;
    }

    /**
     * DOCUMENT ME!
     *
     * @param request DOCUMENT ME!
     * @param logName DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     *
     * @throws Throwable DOCUMENT ME!
     */

   


    public Document processWFLNotification(Document request, String logName)
    throws Throwable {
//        Connection conn              = null;
    	
    	LogMinder.getLogMinder().logExists("processWFLNotification");
    	
    	long start = System.nanoTime();
    	
       
        User user                    = null;
        String webServiceURL              = null;
        String userId                = null;
        String password              = null;
        String maxNumberAttempts     = null;
        String taskId = null;

        PrintWriter pw = null;

        int addCount    = 0;
        int updateCount = 0;
        int failedCount = 0;
        int count       = 0;
       // HttpServletResponse response = null;

        try {
            webServiceURL     = (String) ServicesDOMUtil.getRequestParameter(request,
                    "webServiceURL");
            
            userId     = (String) ServicesDOMUtil.getRequestParameter(request,
                    "userId");
            
            password     = (String) ServicesDOMUtil.getRequestParameter(request,
                    "password");
            
            maxNumberAttempts     = (String) ServicesDOMUtil.getRequestParameter(request,
                    "maxNumberAttempts");
            
            user = ServicesDOMUtil.getUser(request);
            
            taskId = (String) ServicesDOMUtil.getRequestParameter(request,  ServicesDOMUtil.PARAM_ATA_TASK_ID);
            
            
            TokenAPI response = new TokenAPI();
            
            String tokenResponse = response.tokenResponse(user);
            
            
           FailureRecordsDatalake failedRecords = new FailureRecordsDatalake();
            
            failedRecords.processFailedDatalake(user, tokenResponse);
            
           
            
            // get the last executed WFH id for a specific task id
            int lastExecutedTaskId = getLastFetchId(user,taskId);
            //int lastExecutedTaskId = 1;
           // if(lastExecutedTaskId>0)	{
	            // get all records for notification
	            List <WorkflowStatusNotification> workFlowNotificatonLst= getRecordsForNotification(user , lastExecutedTaskId, tokenResponse);
	            
	            //process notify
	             processNotify(webServiceURL,userId,password,maxNumberAttempts,user,workFlowNotificatonLst,taskId,lastExecutedTaskId);
          //  }
            /*String taskLogFile = (String) ServicesDOMUtil.getRequestParameter(request,
                    ServicesDOMUtil.PARAM_TASK_LOG_FILE);

            pw = new PrintWriter(new FileWriter(new File(taskLogFile)));
            pw.println("<table width=\"100%\">");

            setHeader(pw, false);
*/
            

       } catch (Exception ex) {
                ServicesDOMUtil.setResponseParameter(request,
                    ServicesDOMUtil.PARAM_STATUS, ServicesDOMUtil.VALUE_STATUS_FAIL);
                LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                    getClass().getName(), "processWFLNotification",
                    ServletConfigUtil.COMPONENT_RI,
                    new Object[] { taskId },
                    ex.getMessage(), ex, LogMinderDOMUtil.VALUE_SCHEDULAR);
            } finally {
                try {
                   /* if (pw != null) {
                        pw.println(
                            "<tr class=\"PrintDataText\"><td colspan=\"3\">Total underwriters added : " +
                            addCount + "</td></tr>");
                        pw.println(
                            "<tr class=\"PrintDataText\"><td colspan=\"3\">Total underwriters updated : " +
                            updateCount + "</td></tr>");
                        pw.println(
                                "<tr class=\"PrintDataText\"><td colspan=\"3\">Total underwriters Failed : " +
                                failedCount + "</td></tr>");
                        pw.println("</table>");
                        pw.close();
                    }*/
                } catch (Exception ex) {
                    LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                        getClass().getName(), "uploadProducers",
                        ServletConfigUtil.COMPONENT_RI, new Object[] { pw },
                        ex.getMessage(), ex, LogMinderDOMUtil.VALUE_PRODUCER_UPLOAD);
                }

                /*if(processedXML != null){
                   deleteDir(processedXML.getParentFile());
                }
                if(individualProducerXMLDir != null){
                   deleteDir(individualProducerXMLDir);
                }*/
            }
        
        long end = System.nanoTime();
        
        long execution = end - start;
        
        LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                this.getClass().getName(),
                "gatherInput",
                ServletConfigUtil.COMPONENT_FRAMEWORK,
                new Object[] { execution },
                "JSON Generated based on entity reference:  ",
                null,
                LogMinderDOMUtil.VALUE_MIC);
        
            return request;
    }

   
	private void processNotify(String webServiceURL, String userId,
			String password, String maxNumberAttempts, User user,
			List<WorkflowStatusNotification> workFlowNotificatonLst, String taskId , int lastExecutedTaskId) {
		long processingNotificationId = 0L;
		NotificationServiceRestClient restClient = new NotificationServiceRestClient(webServiceURL, userId, password);

		int count = 0;		
		
		for(WorkflowStatusNotification workFlowNotificaton: workFlowNotificatonLst){
			count++;
			try{
				 LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG,
		                    getClass().getName(), "processNotify",
		                    ServletConfigUtil.COMPONENT_RI,
		                    new Object[] { workFlowNotificaton },
		                    "Sending Notification", null, LogMinderDOMUtil.VALUE_SCHEDULAR);
			//processingNotificationId = 	workFlowNotificaton.getNotificationId(); 
			//NotificationServiceResponse ntfServiceresponse = restClient.sendNotification(workFlowNotificaton);
			//if(ntfServiceresponse.isSuccess())	{
				 processSave(taskId,workFlowNotificaton.getNotificationId(),user);
			//}else	{
			//	 processSaveFailTask(taskId,processingNotificationId,user,lastExecutedTaskId);
			//}
			 
			}catch(Exception ex){
				 processSaveFailTask(taskId,processingNotificationId,user,lastExecutedTaskId);
	                LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
	                        getClass().getName(), "processNotify",
	                        ServletConfigUtil.COMPONENT_RI,
	                        new Object[] { taskId,  workFlowNotificaton},
	                        ex.getMessage(), ex, LogMinderDOMUtil.VALUE_SCHEDULAR);
				 
			}
		}
		
	}
	
	
   /**
    * Save the fail records
    * @param taskId
    * @param failNotificationId
    * @param user
    * @param lastExecutedTaskId
    */
	private void processSaveFailTask(String taskId, long failNotificationId,
			User user, int lastExecutedTaskId) {

	 	    Connection conn = null;
	        PreparedStatement pstmt = null;
	        ResultSet rs = null;
	        int maxNumberAttmpt = 1;
	       
	        try {
	        	
	        	String insertSql = "INSERT INTO NTF_NOTIFICATION_TASK_FAILURE (NTF_ID, NTF_TASK_ID, NTF_WFH_ID,NTF_NUM_ATTEMPTS,NTF_DATE_MODIFIED)"+
                                   "VALUES(NTF_TASK_FAILURE_SEQ.nextval,?,?,?,sysdate)";
	        	
	        	String updateSql = "UPDATE NTF_NOTIFICATION_TASK_FAILURE SET NTF_NUM_ATTEMPTS = ? WHERE NTF_TASK_ID = ? AND NTF_WFH_ID = ? ";
	        	
	        	String selectSql = "select NTF_NUM_ATTEMPTS from NTF_NOTIFICATION_TASK_FAILURE where NTF_TASK_ID = ? AND NTF_WFH_ID = ?";
	        	
	        	conn = ConnectionPool.getConnection(user);
	        	
	        	// If record exist for the given task id then update the record else insert new record
	        		            
	            pstmt = conn.prepareStatement(selectSql);
	            pstmt.setInt(1, Integer.parseInt(taskId));	
	            pstmt.setLong(2, failNotificationId);	            
	            rs = pstmt.executeQuery();
	            
	            if (rs.next()){
	            	
	            	maxNumberAttmpt = maxNumberAttmpt + rs.getInt("NTF_NUM_ATTEMPTS");        	   
	            	
	         	}
	            pstmt.close();	        		
	        	
				if (maxNumberAttmpt == 1) {
					pstmt = conn.prepareStatement(insertSql);
					pstmt.setInt(1, Integer.parseInt(taskId));
					pstmt.setLong(2, failNotificationId);
					pstmt.setInt(3, maxNumberAttmpt);
					pstmt.execute();
				} else {
					pstmt = conn.prepareStatement(updateSql);					
					pstmt.setInt(1, maxNumberAttmpt);
					pstmt.setInt(2, Integer.parseInt(taskId));
					pstmt.setLong(3, failNotificationId);
					pstmt.execute();
				}	             
	                     	
	            
	        } catch (Exception e) {
	            LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
	                                         "WorkFlowNotificationService",
	                                         e.getStackTrace()[0].toString(),
	                                         ServletConfigUtil.COMPONENT_FRAMEWORK,
	                                         new Object[] { user},
	                                         "Error occured while getting event turn on value.",
	                                         e, LogMinderDOMUtil.VALUE_MIC);
	            

	        } finally {
	            try {
	            	DBUtil.close(rs, pstmt, conn);
	            } catch (SQLException se) {
	                // ignore this one
	            }
	        }
	       	     		  
	    
		
	}

	/**
	 * Save the last processed records from the WFL_ACTIVITY_HISTORY table 
	 * @param taskId
	 * @param notificationId
	 * @param user
	 * @param lastExecutedTaskId
	 */
	private void processSave(String taskId, long notificationId ,  User user ) {

	 	   Connection conn = null;
	        PreparedStatement pstmt = null;
	        ResultSet rs = null;
	       
	        try {
	        	
	        	String updateSql = "UPDATE NTL_NOTIFICATION_TASK_LOG SET NTL_WFH_ID = ? WHERE NTL_TASK_ID = ?";
	        	
	        	conn = ConnectionPool.getConnection(user);
	        	
	            pstmt = conn.prepareStatement(updateSql);
	            pstmt.setLong(1, notificationId);	
	            pstmt.setInt(2, Integer.parseInt(taskId));	            
	            pstmt.executeUpdate();
	        	
	        } catch (Exception e) {
	            LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
	                                         "WorkFlowNotificationService",
	                                         e.getStackTrace()[0].toString(),
	                                         ServletConfigUtil.COMPONENT_FRAMEWORK,
	                                         new Object[] { user},
	                                         "Error occured while getting event turn on value.",
	                                         e, LogMinderDOMUtil.VALUE_MIC);
	            

	        } finally {
	            try {
	            	DBUtil.close(rs, pstmt, conn);
	            } catch (SQLException se) {
	                // ignore this one
	            }
	        }
	       	     		  
	    
		
	}



    
    
   /**
    * to get the last executed task id
    * @param user
 * @param taskId 
    * @return
    */
    private int getLastFetchId(User user, String taskId) {
 	   Connection conn = null;
        PreparedStatement pstmt = null;
        PreparedStatement pstmtInsert = null;
        ResultSet rs = null;
        int lastExecutedWFHid = -1;
        String sqlGetIdFromNTL = "SELECT NTL_WFH_ID FROM NTL_NOTIFICATION_TASK_LOG WHERE NTL_TASK_ID = "+taskId;
        
        try {
        	
            conn = ConnectionPool.getConnection(user);
            
            //#1. Get Last execution if from NTL_NOTIFICATION_TASK_LOG table
            pstmt = conn.prepareStatement(sqlGetIdFromNTL);
           // pstmt.setString(1, taskId);
            rs = pstmt.executeQuery();

            if(rs.next())	{
            	lastExecutedWFHid = rs.getInt("NTL_WFH_ID");
            }else	{
            	
            	//First execution of this task. Insert max WAH_ID into NTL_NOTIFICATION_TASK_LOG, so that next task execution will select newer records
            	
                String insertNTL = "INSERT INTO NTL_NOTIFICATION_TASK_LOG (NTL_TASK_ID, NTL_WFH_ID, NTL_EXECUTION_TIME) VALUES ( ? , "
                		+ " (SELECT NVL(MAX(WAH_ID),0) from WFL_ACTIVITY_HISTORY), SYSDATE ) ";
                pstmtInsert = conn.prepareStatement(insertNTL);
                pstmtInsert.setString(1, taskId);
                pstmtInsert.executeUpdate();
                
                //Return negative number to indicate there is no records to process in this execution of the task
            }
        } catch (Exception e) {
            LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                                         "WorkFlowNotificationService",
                                         e.getStackTrace()[0].toString(),
                                         ServletConfigUtil.COMPONENT_FRAMEWORK,
                                         new Object[] { user},
                                         "Error occured while getLastFetchId",
                                         e, LogMinderDOMUtil.VALUE_MIC);
            

        } finally {
            try {
            	DBUtil.close(rs, pstmt, conn);
            } catch (SQLException se) {
                // ignore this one
            }
        }
        return lastExecutedWFHid;
    }

 /**
  * get all records for notification
  * @param user
  * @param lastExecutedTaskId
  */
	private List <WorkflowStatusNotification> getRecordsForNotification(User user, int lastExecutedTaskId, String tokenResponse) {
		
	 	   Connection conn = null;
	        PreparedStatement pstmt = null;
	        ResultSet rs = null;
	        WorkflowStatusNotification workFlowNotificaton = null;
	        List <WorkflowStatusNotification> workFlowNotificatonLst = new ArrayList<WorkflowStatusNotification>();
	       
	        try {
	        	String sql ="SELECT mpo.mpo_policy_reference , decode(mpo.MPO_POLICY_QUOTE_INDICATOR,'Q','QUOTE','POLICY') entity_type, mpo_old_policy_reference, wac.WAC_ID wac_id, "+
	        			    " mpo.mpo_revision_number mpo_revision_number, wac.wac_user_created wac_user_created, wac.wac_date_created wac_date_created, wac.wac_date_modified wac_date_modified, "+
	        			  " wac.wac_user_modified wac_user_modified FROM mis_policies mpo, wfl_activities wac WHERE 1 =1 and mpo.MPO_POLICY_REFERENCE = wac.WAC_ENTITY_REFERENCE"+
	        		    " AND mpo_book_flag = DECODE(mpo_policy_quote_indicator,'Q','N','Y') and wac.WAC_ID > ?"+
	        			" and wac_workflow_task_id IN"+
	        		   " (SELECT wwt_id FROM wfl_workflow_tasks WHERE wwt_workflow_id IN"+
	        		            "(SELECT wwo_id FROM wfl_workflows WHERE wwo_entity_type IN ('POLICY','QUOTE'))"+
	        		            "AND wwt_task_name = DECODE(wwt_workflow_id,1,'BOOKING',2,'DOCUMENTS','BOOKING'))"+
	        		            "AND EXISTS (SELECT 1 FROM wfl_activities WHERE wac_workflow_task_id IN"+
	        		            "(SELECT wwt_id FROM wfl_workflow_tasks WHERE wwt_workflow_id IN"+
	        		            "(SELECT wwo_id FROM wfl_workflows WHERE wwo_entity_type IN ('POLICY','QUOTE'))"+
	        		            "AND wwt_task_name = DECODE(wwt_workflow_id,1,'BOOKING',2,'DOCUMENTS','BOOKING'))"+
	        		            "AND wac_entity_reference = mpo_policy_reference AND wac_stage = 'COMPLETE')";
				
          	        	
	             	
	            conn = ConnectionPool.getConnection(user);
	            pstmt = conn.prepareStatement(sql);
	            
	           
	          pstmt.setString(1, String.valueOf(lastExecutedTaskId));
	         
	          rs = pstmt.executeQuery();
	            
	            
	            
	            while (rs.next()){
	          
	            	workFlowNotificaton = new WorkflowStatusNotification();
	            	workFlowNotificaton.setEntityType(rs.getString("ENTITY_TYPE"));
	            	workFlowNotificaton.setNotificationId(rs.getLong("WAC_ID"));
	            	workFlowNotificaton.setEntityReference(rs.getString("MPO_POLICY_REFERENCE"));
	            	workFlowNotificaton.setOldPolicyReference(rs.getString("MPO_OLD_POLICY_REFERENCE"));
	            	workFlowNotificaton.setRevisionNumber(rs.getInt("MPO_REVISION_NUMBER"));
	            	workFlowNotificaton.setDateCreated(rs.getDate("wac_date_created"));
	            	workFlowNotificaton.setDateModified(rs.getDate("wac_date_modified"));
	            	workFlowNotificaton.setUserCreated(rs.getString("wac_user_created"));
	            	workFlowNotificaton.setUserModified(rs.getString("wac_user_modified"));
	            	
	            	LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
	                        this.getClass().getName(),
	                        "gatherInput",
	                        ServletConfigUtil.COMPONENT_FRAMEWORK,
	                        new Object[] { lastExecutedTaskId +
	                                       lastExecutedTaskId },
	                        "JSON Generated based on entity reference:  "+ rs.getString("mpo_revision_number"),
	                        null,
	                        LogMinderDOMUtil.VALUE_MIC);
	            	

	            	MultinationalWsIntegrator export = new MultinationalWsIntegrator();
	            
	            	export.gatherInput(rs.getString("ENTITY_TYPE"),rs.getString("MPO_POLICY_REFERENCE"),user, rs.getString("wac_user_created"),rs.getString("wac_user_modified"), tokenResponse, rs.getString("mpo_old_policy_reference"), rs.getInt("mpo_revision_number"));
	            	
	            	
	            	
	            	workFlowNotificatonLst.add(workFlowNotificaton);
	         	}
	         	
	                     	
	            
	        } catch (Exception e) {
	            LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
	                                         "WorkFlowNotificationService : method : getRecordsForNotification",
	                                         e.getStackTrace()[0].toString(),
	                                         ServletConfigUtil.COMPONENT_FRAMEWORK,
	                                         new Object[] { user},
	                                         "Error occured while getting event turn on value.",
	                                         e, LogMinderDOMUtil.VALUE_SCHEDULAR);
	            

	        } finally {
	            try {
	            	DBUtil.close(rs, pstmt, conn);
	            } catch (SQLException se) {
	                // ignore this one
	            }
	        }
	       
	        return workFlowNotificatonLst;
	     		  
	    }
}
