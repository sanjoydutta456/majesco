package com.majesco.custom.pi.ri.services;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import com.coverall.mt.cache.XSDCacheKey;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;
import com.coverall.mt.util.GenUtil;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;
import com.coverall.util.LoadPropertiesUtil;


public class XMLGeneratorParameters {
    
    private static final String CONST_GENERATE_OFFSET = "generateOffset";
    public static final String CONST_VIEW_PREFIX = "viewPrefix";
    public static final String FOLDER_NEXTGEN_PRODUCT_CACHE = "NextGenProductCache";
    public static final String ORACLE_DRIVER 	= "oracle.jdbc.driver.OracleDriver";
    public static final String EXPORT_XML_PATH 	= "exportXMLPath";
    public static final String CONFIG_FILE_PATH = "configFilePath";
    public static final String ENTITY_TYPE 		= "entityType";
    public static final String ENTITY_REF 		= "entityReference";
    public static final String DB_USERID		= "userId";
    public static final String DB_PASSWORD		= "password";
    public static final String DB_HOSTNAME		= "host";
    public static final String DB_PORT			= "port";
    public static final String DB_SID			= "sid";
    public static final String LOGGING			= "logging";
    public static final String PRODUCT_CODE		= "productCode";
    public static final String CUSTOMER_CODE	= "customerCode";
    public static final String USER_NAME		= "userName";
    
    //private String  mode;
    private String exportXMLPath;
    private String configFilePath;
    private String entityType;
    private String entityReference;
    //private String rootElement = "QuotePolicyList";
    private String userId;
    private String password; 
    private String host;
    private String port;
    private String sid;
    //private String workingDirectory; 
    private boolean logging;
    private String productCode; 
    //private String lobCode;
    private String customerCode;
    private String userName;
    //private String validate;
    private boolean generateOffset = true; // by default this is true
    private String viewPrefix;
    private String jdbcURL;
    private String driverName;
    private User user;
    private Connection DBConnection = null;
    private PrintWriter XMLWriter = null;
    private int logLevel = LogEntry.SEVERITY_FATAL;
    private Logger logger= null;
    
    
    public XMLGeneratorParameters(
            String exportXMLPath, HashMap params, User user){
        
        setExportXMLPath(exportXMLPath);
        setUser(user);
        CustomerConfigUtil conUtil = CustomerConfigUtil.getInstance();
        setCustomerCode(conUtil.getCustomerCode(user.getDomain()));
        setEntityReference((String)params.get("entityReference"));
        setEntityType((String)params.get("entityType"));
        setViewPrefix((String)params.get("viewPrefix"));
        setLogging(true);
        logger = new Logger(getLogLevel());       
    }
    
    XMLGeneratorParameters(Map<String, String> params){
    	if(params!=null){
    		exportXMLPath 	= params.get(EXPORT_XML_PATH);
    		configFilePath 	= params.get(CONFIG_FILE_PATH);
    		entityType 		= params.get(ENTITY_TYPE);
    		entityReference	= params.get(ENTITY_REF);
    		userId			= params.get(DB_USERID);
    		password		= params.get(DB_PASSWORD);
    		/*host			= params.get(DB_HOSTNAME);
    		port			= params.get(DB_PORT);
    		sid				= params.get(DB_SID);*/
    		logging			= Boolean.TRUE.toString().equalsIgnoreCase(params.get(LOGGING));
    		productCode		= params.get(PRODUCT_CODE);
    		customerCode	= params.get(CUSTOMER_CODE);
    		userName		= params.get(USER_NAME);
    		generateOffset	= Boolean.FALSE.toString().equals(params.get(CONST_GENERATE_OFFSET));
    		viewPrefix		= params.get(CONST_VIEW_PREFIX);
    	}
        if (userName == null){
            userName="admin@mic.com";
        }
        
        //jdbcURL = "jdbc:oracle:thin:@" + host + ":" + port + ":" + sid;
        jdbcURL = LoadPropertiesUtil.getInstance().getJdbcUrl();
        driverName = ORACLE_DRIVER; 
        logger = new Logger(getLogLevel());  
    }
    
    XMLGeneratorParameters(String[] args){
        String argName=null;
        String argValue=null;
        for (int i = 0; i < args.length; ++i) {
            String[] keyValue = args[i].split("=");
            try {
                argName = keyValue[0];
                argValue = keyValue[1];
            } catch (ArrayIndexOutOfBoundsException aioobe) {
                argValue = null;
            }            
            /*if(argName.equalsIgnoreCase("mode")){
                mode = argValue;
            }else */if(argName.equalsIgnoreCase(EXPORT_XML_PATH)){
                exportXMLPath = argValue;
            }else if(argName.equalsIgnoreCase(CONFIG_FILE_PATH)){
                configFilePath = argValue;
            }else if(argName.equalsIgnoreCase(ENTITY_TYPE)){
                entityType = argValue;
            }else if(argName.equalsIgnoreCase(ENTITY_REF)){
                entityReference = argValue;
            /*}else if(argName.equalsIgnoreCase("rootElement")){
                rootElement = argValue;*/
            }else if(argName.equalsIgnoreCase(DB_USERID)){
                userId = argValue;
            }else if(argName.equalsIgnoreCase(DB_PASSWORD)){
                password = argValue;
            /*}else if(argName.equalsIgnoreCase(DB_HOSTNAME)){
                host = argValue;
            }else if(argName.equalsIgnoreCase(DB_PORT)){
                port = argValue;
            }else if(argName.equalsIgnoreCase(DB_SID)){
                sid = argValue;*/
            /*}else if(argName.equalsIgnoreCase("workingDirectory")){
                workingDirectory = argValue;*/
            }else if(argName.equalsIgnoreCase(LOGGING)){
                if(argValue.equalsIgnoreCase("true")){
                    logging = true;
                }else{
                    logging = false;
                }
            }else if(argName.equalsIgnoreCase(PRODUCT_CODE)){
                this.productCode = argValue;
            /*}else if(argName.equalsIgnoreCase("lobCode")){
                lobCode = argValue;*/
            }else if(argName.equalsIgnoreCase(CUSTOMER_CODE)){
                customerCode = argValue;
            }else if(argName.equalsIgnoreCase(USER_NAME)){
                userName = argValue;
            /*}else if(argName.equalsIgnoreCase("validate")){
                validate = argValue;*/
            }else if(argName.equalsIgnoreCase(CONST_GENERATE_OFFSET)){
                if(argValue.equalsIgnoreCase("false"))
                    generateOffset = false;                
            }else if(argName.equalsIgnoreCase(CONST_VIEW_PREFIX)){
                viewPrefix = argValue;
            }            
        }
        
        if (userName == null){
            userName="admin@mic.com";
        }
        
        //jdbcURL = "jdbc:oracle:thin:@" + host + ":" + port + ":" + sid;
        jdbcURL = LoadPropertiesUtil.getInstance().getJdbcUrl();
        driverName = "oracle.jdbc.driver.OracleDriver"; 
        logger = new Logger(getLogLevel());  
    }
    
    
    
    public void printXMLWriter(StringBuffer buffer){
        XMLWriter.print(buffer);
        XMLWriter.flush();
    }
    
    public XSDCacheKey getXSDCacheKey(){
        return new XSDCacheKey(getCustomerCode(), getProductCode());
    }
    
    
    public String getXMLTagWithVersion(){
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
    }
    
    public String getXMLNameSpace(){
        String xsdLocation = "";
        if(getConfigFilePath()==null || getConfigFilePath().trim().equals("")){
            xsdLocation = getDeafultXSDPath();
        }else{
            xsdLocation = getConfigFilePath();
        }
        
        String schemaLocation = "xsi:schemaLocation=\"http://cover-all.com/micextract " +"WKXMLExtract.xsd\""; 
                                    
        String nameSpaceInfo = " xmlns = \"http://cover-all.com/micextract\" xmlns:mic=\"http://cover-all.com/mic\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" " + schemaLocation;
        
        return nameSpaceInfo;
    }
    
    
    public Connection getDBConnection() {
        if (DBConnection == null){
            try {
                if (null == getUser()) {
                    Class.forName(getDriverName());
                    DBConnection = DriverManager.getConnection(getJdbcURL(), getUserId(), getPassword());
                } else {
                    DBConnection = ConnectionPool.getConnection(getUser());
                }
            } catch (Exception e) {
                getLogger().log(LogEntry.SEVERITY_FATAL, null, getEntityType() + " " + getEntityReference() + " could not be exported");
                getLogger().log(LogEntry.SEVERITY_FATAL, e, e.getMessage());
            } 
        }
        return DBConnection;
    }
    
    public void closeConnection(){
        try {
            if ((DBConnection != null) && (!DBConnection.isClosed())) {
                DBConnection.close();
            }
        } catch (SQLException e) {
            getLogger().log(LogEntry.SEVERITY_FATAL, e, e.getMessage());
        }
        try {
            if (XMLWriter != null) {
                XMLWriter.close();
            }
        } catch (Exception e) {
            getLogger().log(LogEntry.SEVERITY_FATAL, e, e.getMessage());
        }
    }
       
    public PrintWriter getXMLWriter(){
        if(XMLWriter == null){
            try {
                /* Get PrintWriter to the write the Export XML */
                XMLWriter = new PrintWriter(
                                    new BufferedWriter(
                                             new FileWriter(getExportXMLPath())
                                             )
                                    );
            }catch (Exception e) {
                getLogger().log(LogEntry.SEVERITY_FATAL, null, getEntityType() + " " + getEntityReference() + " could not be exported");
                getLogger().log(LogEntry.SEVERITY_FATAL, e, e.getMessage());
            } 
        }  
        return XMLWriter;
    }
    
    public User getUser() {
        return user;
    }


    public void setUser(User user) {
        this.user = user;
    }


    /*public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }*/

    public String getExportXMLPath() {
        return exportXMLPath;
    }


    public void setExportXMLPath(String exportXMLPath) {
        this.exportXMLPath = exportXMLPath;
    }


    public String getConfigFilePath() {
        if(configFilePath ==  null)
            return "";
        return configFilePath;
    }
    
    public String getIPAddressofAppServer(){
    	String ipAddress = null;
    	Connection conn = null;
    	PreparedStatement ps = null;
    	String ipAddressQuery = null;
    	ResultSet rs =null;
    	 try {
             	conn = ConnectionPool.getAdminConnection();
             	ipAddressQuery = "select AMA_IPADDRESS from ADM_INSTANCES,ADM_MACHINES ";
             	ipAddressQuery = ipAddressQuery + " where AMA_MACHINE_ID = AIN_MACHINE_ID";
             	ipAddressQuery = ipAddressQuery + " AND AIN_CONFIGURATION_TYPE_ID IN (SELECT ACT_CONFIGURATION_TYPE_ID FROM ADM_CONFIGURATION_TYPES WHERE lower(ACT_NAME) IN (lower('Application Server'), lower('Both')))";
             	ps = conn.prepareStatement(ipAddressQuery);
             	rs = ps.executeQuery();
              
              while (rs.next()) {
            	  if(null != rs.getString("AMA_IPADDRESS")){
            		  ipAddress = rs.getString("AMA_IPADDRESS");
            		  return ipAddress;
            	  }
            }

         } catch (Exception e) {
        	 return null;
         } finally {
             try {
                 DBUtil.close(null,ps,conn);
             } catch (Throwable error) {
                 try {
                     LogMinder.getLogMinder().log(LogMinder.LOGLEVEL_ERROR,
                         getClass().getName(), "getIPAddressofAppServer",
                         ServletConfigUtil.COMPONENT_FRAMEWORK,
                         new Object[] { conn },
                         "Error closing admin connection or statement", error,
                         LogMinderDOMUtil.VALUE_MIC);
                 } catch (Throwable anotherError) {
                     error.printStackTrace();
                     anotherError.printStackTrace();
                 }
             }
         }
    	
    	return null; 
    }
    
    public String getDeafultXSDPath(){
    	String mic_home_temp = null;
    	String mic_home = System.getProperty("mic.system.home");
      String ipAddressOfAppServer = getIPAddressofAppServer();
        
      if(ipAddressOfAppServer!= null && mic_home.indexOf("mic") != -1){
        mic_home_temp = mic_home.substring(mic_home.indexOf("mic"),mic_home.length());;
        mic_home = File.separator + File.separator + ipAddressOfAppServer + File.separator + mic_home_temp;
      }
    
      String xsdFullFilePath = mic_home + File.separator
               + FOLDER_NEXTGEN_PRODUCT_CACHE + File.separator + getCustomerCode()
               + File.separator + getProductCode() + File.separator + "POLICY" + File.separator
               + productCode + "XMLExtract.xsd";
      
      return xsdFullFilePath;
    }


    public void setConfigFilePath(String configFilePath) {
        this.configFilePath = configFilePath;
    }


    public String getEntityType() {
        return entityType;
    }


    public void setEntityType(String entityType) {
        this.entityType = entityType;
    }


    public String getEntityReference() {
        return entityReference;
    }


    public void setEntityReference(String entityReference) {
        this.entityReference = entityReference;
    }

/*
    public String getRootElement() {
        return rootElement;
    }
    
    public void setRootElement(String rootElement) {
        this.rootElement = rootElement;
    }*/

    public String getUserId() {
        return userId;
    }


    public void setUserId(String userId) {
        this.userId = userId;
    }


    public String getPassword() {
        return password;
    }


    public void setPassword(String password) {
        this.password = password;
    }


    public String getHost() {
        return host;
    }


    public void setHost(String host) {
        this.host = host;
    }


    public String getPort() {
        return port;
    }


    public void setPort(String port) {
        this.port = port;
    }


    public String getSid() {
        return sid;
    }


    public void setSid(String sid) {
        this.sid = sid;
    }

    /*public String getWorkingDirectory() {
        return workingDirectory;
    }

    public void setWorkingDirectory(String workingDirectory) {
        this.workingDirectory = workingDirectory;
    }*/

    public String getProductCode() {
        String productCode = "";
        
        if(productCode == null || productCode.equals("")){
            ResultSet rs = null;  
            PreparedStatement stmt= null;
            try {
                Connection conn = getDBConnection();
                stmt = conn.prepareStatement("SELECT PRODUCT_CODE " +
                        "FROM EV_MIS_QUOTE_POLICIES " +
                        "WHERE ENTITY_REFERENCE = ? " +
                        "AND ENTITY_TYPE = ?");
                stmt.setString(1, getEntityReference());
                stmt.setString(2, getEntityType());
                rs = stmt.executeQuery();
                while (rs.next()) {
                    productCode = rs.getString(1);
                }
            }   
            catch(Exception e){
            }finally {
                try {
                    DBUtil.close(rs, stmt);
                } catch (Throwable error) {
                    error.printStackTrace();
                }
            }
            setProductCode(productCode);
        }else{
            productCode = this.productCode;
        }
        return productCode;
    }


    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }


   /* public String getLobCode() {
        return lobCode;
    }


    public void setLobCode(String lobCode) {
        this.lobCode = lobCode;
    }
*/

    public String getCustomerCode() {
        return customerCode;
    }


    public void setCustomerCode(String customerCode) {
        this.customerCode = customerCode;
    }


    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }


   /* public String getValidate() {
        return validate;
    }


    public void setValidate(String validate) {
        this.validate = validate;
    }
*/

    public boolean getGenerateOffset() {
        return generateOffset;
    }


    public void setGenerateOffset(boolean generateOffset) {
        this.generateOffset = generateOffset;
    }


    public String getViewPrefix() {
        return viewPrefix;
    }


    public void setViewPrefix(String viewPrefix) {
        this.viewPrefix = viewPrefix;
    }


    public String getJdbcURL() {
        return jdbcURL;
    }


    public void setJdbcURL(String jdbcURL) {
        this.jdbcURL = jdbcURL;
    }


    public String getDriverName() {
        return driverName;
    }


    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }  
    
    public boolean getLogging() {
        return logging;
    }


    public void setLogging(boolean logging) {
        this.logging = logging;
    }
    
    public int getLogLevel(){
        if (getLogging()){
            logLevel = 10;
        }else{
            logLevel = 70;
        }
        return logLevel;
    }

    public Logger getLogger(){
        return logger;
    }
    
    /**
     * Logger to allow calling class to customize logging
     */
    public static class Logger {
        static int logLevel;
        public Logger(int logLev){
            logLevel = logLev; 
        }
        public void log(int severity, Exception e, String message) {
            if (severity >= logLevel) {
            	//set log level to a lower mode(like DEBUG) to print out logs
            	int currentSeverityLevel = LogMinder.getLogMinder().getAcceptableSeverityLevel();
            	if (severity >= currentSeverityLevel){
	                if (e != null) {
	                    GenUtil.systemErrWithThreadInfo(message, e);
	                }
                    GenUtil.systemOutWithThreadInfo(message);
            	}
            }
        }
    }
    
}
