package com.majesco.custom.pi.ri.services;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.TreeSet;

import oracle.ias.cache.Attributes;
import oracle.ias.cache.CacheAccess;
import oracle.ias.cache.CacheException;
import oracle.ias.cache.CacheNotAvailableException;
import oracle.ias.cache.RegionNotFoundException;

import com.coverall.mt.cache.XSDCache;
import com.coverall.mt.cache.XSDCacheKey;
import com.coverall.mt.cache.XSDCacheLoader;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.xml.xmlextractv2.*;

/**
 * This class help us in doing following things -
 * 1. Create instance of class XSDCache for different customers.
 * 2. Store the XSDCache object to Cache of the Server
 * 3. Serialize the XSDCache objects to hard - drive.
 * @author Mitesh Sarawagi
 */

public class XSDCacheCreator {
    public static final String FOLDER_NEXTGEN_PRODUCT_CACHE = "NextGenProductCache";
    private static final String CUSTOMER_XSD_REGION = "CUSTOMER_XSD_REGION";
    private XSDCacheKey xsdCacheKey = null;
    private boolean setToCache = false;
    private String XSDPath = "";
    private XMLGeneratorParameters.Logger logger = null;

    public static int logLevel = PolicyExportToXML.logLevel;
    private static boolean logPerformance = PolicyExportToXML.logPerformance;
    private static Method method_CacheAccess_IsRegionExist = null;

    /**
     * This constructor will use the default XSD file location and default logging.
    @param  key This is instance of XSDCacheKey which is unique for a customer.
    @param setToCache This is boolean flag which tell the Class to do following -
            1. When True - The class will use the Server Cache to get the XSDCache.
            If there is no instance found in the Cache it will try fetching it from
            Serialize object and if there is no serialize object it will regenerate
            the XSDCache from XSD and set them to Server cache.
            2. When false - It will always generate XSDCache object from the XSD path specified.
    */
    public XSDCacheCreator(XSDCacheKey key, boolean setToCache){
        this.xsdCacheKey = key;
        this.setToCache = setToCache;
        logger = new XMLGeneratorParameters.Logger(logLevel);
    }


    /**
    @param XMLGen This is instance of XMLGeneratorParameters which hold the following information to be used by this class -
              1. Give us the XSDCacheKey Object instance.
              2. The XSD path to be used to generate the XSDCache Object.
              3. The logger and log level to be used.
    @param setToCache This is boolean flag which tell the Class to do following -
            1. When True - The class will use the Server Cache to get the XSDCache.
            If there is no instance found in the Cache it will try fetching it from
            Serialize object and if there is no serialize object it will regenerate
            the XSDCache from XSD and set them to Server cache.
            2. When false - It will always generate XSDCache object from the XSD path specified.
    */
    public XSDCacheCreator(XMLGeneratorParameters XMLGen, boolean setToCache){
        this.xsdCacheKey = XMLGen.getXSDCacheKey();
        this.setToCache = setToCache;
        this.XSDPath = XMLGen.getConfigFilePath();
        logLevel = XMLGen.getLogLevel();
        logger = XMLGen.getLogger();
    }

    public XSDCacheKey getXsdCacheKey() {
        return xsdCacheKey;
    }

    public boolean isSetToCache() {
        return setToCache;
    }

    /**
    This function creates XSDCache objects for each customer and set them to server cache,
    if it do not exists on the server. This function should be generally called on server startup.
    @return - Nothing
    */
    public static void createXSDCacheOnServer(){
        ArrayList arrXSDCacheKey = XSDCacheKey.getXSDCustomerProductList();
        for(int iLoop=0; iLoop < arrXSDCacheKey.size(); iLoop ++){
            XSDCacheKey key = (XSDCacheKey) arrXSDCacheKey.get(iLoop);
            createXSDCacheOnServer(key);
        }
    }
    
    public static void createXSDCacheOnServer(XSDCacheKey xsdCacheKey){
        new XSDCacheCreator(xsdCacheKey, true).getXSDCache();
    }

    /**
    This function XSDCache returns the XSDCache object. The logic to fetch the XSDCache object depends upon the flag setToCache.
    If setToCahce is set to -
       1. true - The class will use the Server Cache to get the XSDCache.
        If there is no instance found in the Cache it will try fetching it from
        Serialize object and if there is no serialize object it will regenerate
        the XSDCache from XSD and set them to Server cache.
       2. false - It will always generate XSDCache object from the XSD path specified.
    @return - XSDCahce for the customer.
    */
    public XSDCache getXSDCache(){
        if(isSetToCache()){
            return getXSDCacheFromServerCache(getXsdCacheKey());
        }else{
            return generateXSDCache(getXsdCacheKey());
        }
    }

    /**
      The function getXSDCacheFromServerCache will first try to get the Object XSDCache from cache,
      if the cache do not exits then it will try getting this from the serialized file stored on the disk,
      even if the object do not exists in serialized object then it will create a new XSDCache object by parsing the XSD
      and set this to server cache and serialize the same.
      @return - XSDCahce for the customer.
    */
    private XSDCache getXSDCacheFromServerCache(XSDCacheKey xsdCacheKey)  {
        CacheAccess customerXSDRegion = null;
        XSDCache xsdCache = null;
        getLogger().log(LogEntry.SEVERITY_FATAL, null, "Fetching XSD Cache through Server Cache (Region :" + CUSTOMER_XSD_REGION + ")..");
        try {
            try {
            	if(isRegionAvailable(CUSTOMER_XSD_REGION)){
            		customerXSDRegion = CacheAccess.getAccess(CUSTOMER_XSD_REGION, true);
            	}
            } catch (RegionNotFoundException rnfe) {
                getLogger().log(LogEntry.SEVERITY_FATAL, null, "Cache Region :" + CUSTOMER_XSD_REGION + " not found" );
                customerXSDRegion = null;
            }
            if (customerXSDRegion == null) {
                Attributes productXSDRegionAttr = new Attributes();
                productXSDRegionAttr.setLoader(new XSDCacheLoader());
                CacheAccess.defineRegion(CUSTOMER_XSD_REGION, productXSDRegionAttr);
                customerXSDRegion = CacheAccess.getAccess(CUSTOMER_XSD_REGION);
                getLogger().log(LogEntry.SEVERITY_FATAL, null, "New Cache Region:" + CUSTOMER_XSD_REGION + " created...." );
            }
            xsdCache = (XSDCache) customerXSDRegion.get(xsdCacheKey);
        } catch (Exception e) {
            getLogger().log(
                    LogEntry.SEVERITY_FATAL,
                    e, "Could not access Cache, Region=" + CUSTOMER_XSD_REGION + ". Error=" + e.getMessage());
        } finally {
            if (customerXSDRegion != null) {
                customerXSDRegion.close();
                getLogger().log(LogEntry.SEVERITY_FATAL, null, "Cache Region:" + CUSTOMER_XSD_REGION + " closed...." );
            }
        }
        return xsdCache;
    }

    /**
      The function generateXSDCache will just get you the XSDCache Object, by generating it from the specified XSD file.
      This will not set or get the object from the server cache and serialize object
    @return - XSDCahce for the customer.
   */
    public XSDCache generateXSDCache(XSDCacheKey key){
        XSDCache xsdCache = new XSDCache();
        String[] arrStr = key.getProducts();
        TreeSet xsdFiles = new TreeSet();

        getLogger().log(LogEntry.SEVERITY_FATAL, null, "Generating XSD Cache Object by parsing XSD for customer:" + key.getCustomer());
        SAXParseXSD saxParseXSD = null;
        for(int iLoop=0; iLoop < arrStr.length; iLoop ++){
        	try {
	            //DOM Parsing for Object Hierarchy object Starts
	            logPerformance("DOM Parse Object Hierarchy: Product:" + arrStr[iLoop] + " Customer:" + key.getCustomer() + ":Start");
	            DOMParseObjectHierarchy DOMParser
	                = new DOMParseObjectHierarchy(getProductXSDFilePath(arrStr[iLoop]), logLevel);
	            ArrayList arrXSDPaths = DOMParser.getXSDPaths();
	            xsdCache.addObjectHierarchyToList(
	                    arrStr[iLoop], DOMParser.getQuotePolicyListHierarchy());
	            logPerformance("DOM Parse Object Hierarchy: Product:" + arrStr[iLoop] + " Customer:" + key.getCustomer() + ":End");
	            //SAX Parsing for Table Starts
	            logPerformance("SAX Parse Table details: Product:" + arrStr[iLoop] + " Customer:" + key.getCustomer() + ":Start");
	
	            for(int iInnerLoop=0; iInnerLoop < arrXSDPaths.size(); iInnerLoop ++){
	                if (saxParseXSD == null)
	                     saxParseXSD= new SAXParseXSD(logLevel);
	                String XSDPath = (String)arrXSDPaths.get(iInnerLoop);
	                if(! xsdFiles.contains(XSDPath)){ //Do not parse the same File again while creating the Cache
	                    getLogger().log(LogEntry.SEVERITY_FATAL, null, "SAX Parsing XSD file at path:" + XSDPath);
	                    xsdFiles.add(XSDPath);
	                    saxParseXSD.parseXSD(XSDPath);
	                }else{
	                    getLogger().log(LogEntry.SEVERITY_FATAL, null, "Not parsing the XSD file at path:" + XSDPath + " as this is already parsed.");
	                }
	            }
	            logPerformance("SAX Parse Table details: Product:" + arrStr[iLoop] + " Customer:" + key.getCustomer() + ":End");
	           
        	}catch(Exception e){
        		getLogger().log(LogEntry.SEVERITY_FATAL, e, "Error in Generating XSD Cache for Product "+arrStr[iLoop]);
        	}
        }
        if(saxParseXSD!= null){
            xsdCache.setTableMap(saxParseXSD.getTableMap());
            xsdCache.setAttributeGroup(saxParseXSD.getAttributeGroup());
        }
        
        //******IMPORTANT*********
        // code added to add PolicyAdditionalDetails.xsd to lstHeirarchy with
        // key as customer code
        //In future if we plan to remove the xml extract we need to keep this
        //As this is used for Json extract
        try{
        	logPerformance("DOM Parse POlicyAdditonalDetails Object Hierarchy: "+ " Customer:" + key.getCustomer() + ":Start");
            DOMParseObjectHierarchy DOMParser
                = new DOMParseObjectHierarchy(getAddionalDetailsXSDFilePath(key.getCustomer()), logLevel);
            
            xsdCache.addObjectHierarchyToList(
            		key.getCustomer(), DOMParser.getQuotePolicyListHierarchy());
        	
        }catch(Exception e){
    		getLogger().log(LogEntry.SEVERITY_FATAL, e, "Error in Generating XSD Cache for POlicyAdditonalDetails Object Hierarchy");
    	}
        
        getLogger().log(LogEntry.SEVERITY_FATAL, null, "XSD Cache Object for customer:" + key.getCustomer() + " created..");
        return xsdCache;
    }

    /**
      The function will get us the path of the XSD file that should be used to generate the XSDObject.
      @return - String.
     */
    private String getProductXSDFilePath(String productCode) {
        //if the XSDPath is not set, get the XSD from the default location
        if(XSDPath.equals("")){
            String mic_home = System.getProperty("mic.system.home");
            String xsdFullFilePath = mic_home + File.separator
                     + FOLDER_NEXTGEN_PRODUCT_CACHE + File.separator + getXsdCacheKey().getCustomer()
                     + File.separator + productCode + File.separator + "POLICY" + File.separator
                     + productCode + "XMLExtract.xsd";
             return xsdFullFilePath;
        }else{
            return XSDPath;
        }
    }
    
    
    /**
    The function will get us the path of the PolicyAdditonalDetais XSD file.
    @return - String.
   */
  private String getAddionalDetailsXSDFilePath(String customer) {
	  
	  		String additionalXsdFullFilePath = System.getProperty("mic.system.home") + File.separator + FOLDER_NEXTGEN_PRODUCT_CACHE + 
			  File.separator + customer + File.separator + "PolicyAdditionalDetails.xsd";
	  
           return additionalXsdFullFilePath;
  }

    public static void main(String args[]){
        XSDCache xsdCache = new XSDCacheCreator(new XSDCacheKey("XX","WK,CA"), false).getXSDCache();
        System.out.println(xsdCache);
    }

    public XMLGeneratorParameters.Logger getLogger(){
        return logger;
    }

    static final Runtime runtime = Runtime.getRuntime ();
    public void logPerformance (String msg){
        if(logPerformance){
            getLogger().log(LogEntry.SEVERITY_FATAL,null,"Performace Log --> Memory Usage Log:" + msg + ":" + (runtime.totalMemory () - runtime.freeMemory ()));
            getLogger().log(LogEntry.SEVERITY_FATAL,null,"Performace Log --> Time Log (in millisecond):" + msg + ":" + Calendar.getInstance().getTimeInMillis());
        }
    }
    
    public static boolean isRegionAvailable(String regionName) throws CacheNotAvailableException, CacheException, SecurityException, IllegalArgumentException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        boolean useReflection = true;
        if(useReflection) {
            return isRegionAvailableUsingReflection(regionName);
        } else {
            return isRegionAvailableUsingGetAccess(regionName);
        }
    }

    private static boolean isRegionAvailableUsingReflection(String regionName) throws SecurityException, NoSuchMethodException, IllegalArgumentException, IllegalAccessException, InvocationTargetException {
        if(method_CacheAccess_IsRegionExist == null) {
            method_CacheAccess_IsRegionExist = CacheAccess.class.getDeclaredMethod("isRegionExist", String.class);
        }
        method_CacheAccess_IsRegionExist.setAccessible(true);
        boolean isRegionAvailable = (Boolean) method_CacheAccess_IsRegionExist.invoke(null, regionName);
        return isRegionAvailable;
    }
    
    private static boolean isRegionAvailableUsingGetAccess(String regionName) throws CacheNotAvailableException, CacheException {
        CacheAccess ca = null;
        try {
            ca = CacheAccess.getAccess(regionName, true); // But this logs in javacache.log file
            return true;
        } catch (RegionNotFoundException e) {
            return false;
        } finally {
            if (ca != null) {
                ca.close();
            }
        }
    }

}
