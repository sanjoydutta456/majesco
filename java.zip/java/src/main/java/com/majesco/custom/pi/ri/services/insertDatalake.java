package com.majesco.custom.pi.ri.services;

import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Map;

import com.coverall.exceptions.JDBCException;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.events.EventProcessor;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;

//import java.util.Date;
import java.sql.Date;




public class insertDatalake {
	
	
	public insertDatalake() {
	    super();
	}

	public String insertDatalake(String entityType, String entityReference, String jsonExtract, String createdUser, String modifiedUser, User user, String tokenResponse, String oldPolicyReference, int revisionNumber) {
		
		
		Connection conn            = null;
        
        CallableStatement callStmt = null;
        
        PreparedStatement prest = null;
        
        ResultSet result = null;
        
        
        String dataResponse = null; 
        
        LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                this.getClass().getName(),
                "gatherInput",
                ServletConfigUtil.COMPONENT_FRAMEWORK,
                new Object[] { "input" +
                               "output" },
                "JSON  ",
                null,
                LogMinderDOMUtil.VALUE_MIC);

        try{
        	
        	oldPolicyReferenceStatus previous_status = new oldPolicyReferenceStatus();
            
            boolean oldPolicyStatus = previous_status.checkOldPolicyReferenceStatus(oldPolicyReference,user, revisionNumber);
            
            LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                    this.getClass().getName(),
                    "gatherInput",
                    ServletConfigUtil.COMPONENT_FRAMEWORK,
                    new Object[] { "input" +
                                   "output" },
                    "JSON  ",
                    null,
                    LogMinderDOMUtil.VALUE_MIC);
           
        	
        	Map webserviceParams =  EventProcessor.
        			getWebServiceParameters(DatalakeConstants.DATALAKE_WEBSERVICE , user);
        	
            String status = null;
            String responseURL = (String)webserviceParams.get(DatalakeConstants.DATALAKE_URL);
        	
             
            
            if(tokenResponse.equals("Error: Token Generation"))
            	{dataResponse = "Error: Token Generation";
            	
            	LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                        this.getClass().getName(),
                        "gatherInput",
                        ServletConfigUtil.COMPONENT_FRAMEWORK,
                        new Object[] { "input" +
                                       "output" },
                        dataResponse,
                        null,
                        LogMinderDOMUtil.VALUE_MIC);
            	
            	}
            
            else if(oldPolicyStatus == true ) {
            	 APICallDatalake data = new APICallDatalake();
                
                 dataResponse = data.response(user, jsonExtract, tokenResponse);
                 
                 LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                         this.getClass().getName(),
                         "gatherInput",
                         ServletConfigUtil.COMPONENT_FRAMEWORK,
                         new Object[] { "input" +
                                        "output" },
                         dataResponse,
                         null,
                         LogMinderDOMUtil.VALUE_MIC);
            }
            
            else if(oldPolicyStatus == false ) {

                dataResponse = "Error: Previous Transaction is not Successful";
                
                LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                        this.getClass().getName(),
                        "gatherInput",
                        ServletConfigUtil.COMPONENT_FRAMEWORK,
                        new Object[] { "input" +
                                       "output" },
                        dataResponse,
                        null,
                        LogMinderDOMUtil.VALUE_MIC);
           } 
            
            
            if(dataResponse.equals("202 Accepted"))
            	status = "Successful";
            else
            	status = "Failed";
            
        	
         conn = ConnectionPool.getConnection(user);
            conn.setAutoCommit(false);
 
            callStmt = conn.prepareCall("{? = call k_insert_datalake.f_insert_datalake_final(?, ?, ?, ?, ?, ?, ?, ?)}");
            
            callStmt.registerOutParameter(1, Types.INTEGER);
            callStmt.setString(2, entityType);
            callStmt.setString(3, entityReference);
           
            Clob clob1 = conn.createClob();
            clob1.setString(1, jsonExtract);
            
            callStmt.setClob(4, clob1);
            
            callStmt.setString(5, status);
            callStmt.setString(6, responseURL);
            
            
            
           
            Clob clob2 = conn.createClob();
            clob2.setString(1, dataResponse);
            callStmt.setClob(7, clob2);
            
        	callStmt.setString(8, createdUser);
        	callStmt.setString(9, modifiedUser);
            callStmt.execute();
            
            
            conn.commit();
            
            
            LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                    this.getClass().getName(),
                    "gatherInput",
                    ServletConfigUtil.COMPONENT_FRAMEWORK,
                    new Object[] { entityType +
                                   entityReference },
                    "Created Date " +dataResponse, null,
                    
                    LogMinderDOMUtil.VALUE_MIC);
            
            
            
	
         } catch(Exception ex){
             ex.printStackTrace();
             
             LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                     this.getClass().getName(),
                     "gatherInput",
                     ServletConfigUtil.COMPONENT_FRAMEWORK,
                     new Object[] { dataResponse +
                                    entityReference },
                     "Created Date " +createdUser, ex,
                     
                     LogMinderDOMUtil.VALUE_MIC);
     
        }
         
            try{
                DBUtil.close(null, callStmt, conn);
            }
            catch (Exception ex){
            	ex.printStackTrace();
            	
            	if (ex instanceof JDBCException && ((JDBCException)ex).getSeverity() == JDBCException.FATAL){
                    LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                                                 getClass().getName(), "saveObjectData",
                                                 ServletConfigUtil.COMPONENT_PORTAL,
                                                 new Object[] { entityType },
                                                 "Error in saving a Object Data "+ex.getMessage(),
                                                 ex, LogMinderDOMUtil.VALUE_MIC);
                }else{
                    LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                                                 getClass().getName(), "saveObjectData",
                                                 ServletConfigUtil.COMPONENT_PORTAL,
                                                 new Object[] { entityReference },
                                                 "Error in saving a Object Data."+ex.getMessage(),
                                                 ex, LogMinderDOMUtil.VALUE_MIC);
                }
            	
            	try{
                    conn.rollback();
                }catch(Exception e){
                    LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                                                 getClass().getName(), "saveObjectData",
                                                 ServletConfigUtil.COMPONENT_PORTAL,
                                                 new Object[] { entityType },
                                                 "Error in rolling back."+ex.getMessage(),
                                                 ex, LogMinderDOMUtil.VALUE_MIC);
                }
            		
            }
            finally{
                try{
                    DBUtil.close(null, callStmt, conn);
                }catch (Exception ex){
                    LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                                                 getClass().getName(), "saveObjectData",
                                                 ServletConfigUtil.COMPONENT_PORTAL,
                                                 new Object[] {entityReference },
                                                 "Error in closing DB connection while saving a Object Data."+ex.getMessage(),
                                                 ex, LogMinderDOMUtil.VALUE_MIC);
                }
            }
        
			
	return entityType;
	}
	
}
