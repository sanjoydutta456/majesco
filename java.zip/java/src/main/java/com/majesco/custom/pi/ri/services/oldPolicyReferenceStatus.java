package com.majesco.custom.pi.ri.services;

import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Map;

import com.coverall.exceptions.JDBCException;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.events.EventProcessor;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;

public class oldPolicyReferenceStatus {

	
	public boolean checkOldPolicyReferenceStatus(String oldPolicyReference, User user, int revisionNumber) {
		
		
		if(oldPolicyReference == null)
		return true;
		
		Connection conn            = null;
        
        CallableStatement callStmt = null;
        
        PreparedStatement pstmt = null;
        
        ResultSet result = null;
		
        try{

        	LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                    this.getClass().getName(),
                    "gatherInput",
                    ServletConfigUtil.COMPONENT_FRAMEWORK,
                    new Object[] { oldPolicyReference },
                    "JSON  "+revisionNumber,
                    null,
                    LogMinderDOMUtil.VALUE_MIC);
        	
            String selectSql = "select dlsi_status from PI_DATALAKE_SERVICE_INTG where dlsi_entity_reference = ?";
        	
            conn = ConnectionPool.getConnection(user);
        	
        	pstmt = conn.prepareStatement(selectSql);
        	
        	pstmt.setString(1, oldPolicyReference);
            	            
            result = pstmt.executeQuery();
            
            while(result.next()) {
            	
            	String status = result.getString("dlsi_status");
            	
            	
            	LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                        this.getClass().getName(),
                        "gatherInput",
                        ServletConfigUtil.COMPONENT_FRAMEWORK,
                        new Object[] { status },
                        "JSON  ",
                        null,
                        LogMinderDOMUtil.VALUE_MIC);
            	
            	
            	
            	if(status.equals("Failed")) {
            		
            		LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                            this.getClass().getName(),
                            "gatherInput",
                            ServletConfigUtil.COMPONENT_FRAMEWORK,
                            new Object[] { status },
                            "RESPONSE  ",
                            null,
                            LogMinderDOMUtil.VALUE_MIC);
            		
            		
            		
            		
            		return false;}
            	else {
            		LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                            this.getClass().getName(),
                            "gatherInput",
                            ServletConfigUtil.COMPONENT_FRAMEWORK,
                            new Object[] { status },
                            "SUCCESS RESPONSE  ",
                            null,
                            LogMinderDOMUtil.VALUE_MIC);
            		
            		return true;}
            	
            }
            
         } catch(Exception ex){
             ex.printStackTrace();
             
             LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                     this.getClass().getName(),
                     "gatherInput",
                     ServletConfigUtil.COMPONENT_FRAMEWORK,
                     new Object[] { "error 101" },
                     "Created Date ", ex,
                     
                     LogMinderDOMUtil.VALUE_MIC);
     
        }
         
            try{
                DBUtil.close(null, callStmt, conn);
            }
            catch (Exception ex){
            	ex.printStackTrace();
            	
            	if (ex instanceof JDBCException && ((JDBCException)ex).getSeverity() == JDBCException.FATAL){
                    LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                                                 getClass().getName(), "saveObjectData",
                                                 ServletConfigUtil.COMPONENT_PORTAL,
                                                 new Object[] { "error 103" },
                                                 "Error in saving a Object Data "+ex.getMessage(),
                                                 ex, LogMinderDOMUtil.VALUE_MIC);
                }else{
                    LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                                                 getClass().getName(), "saveObjectData",
                                                 ServletConfigUtil.COMPONENT_PORTAL,
                                                 new Object[] { "entity reference" },
                                                 "Error in saving a Object Data."+ex.getMessage(),
                                                 ex, LogMinderDOMUtil.VALUE_MIC);
                }
            	
            	try{
                    conn.rollback();
                }catch(Exception e){
                    LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                                                 getClass().getName(), "saveObjectData",
                                                 ServletConfigUtil.COMPONENT_PORTAL,
                                                 new Object[] { "error" },
                                                 "Error in rolling back."+ex.getMessage(),
                                                 ex, LogMinderDOMUtil.VALUE_MIC);
                }
            		
            }
            finally{
                try{
                    DBUtil.close(null, callStmt, conn);
                }catch (Exception ex){
                    LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
                                                 getClass().getName(), "saveObjectData",
                                                 ServletConfigUtil.COMPONENT_PORTAL,
                                                 new Object[] {"entityReference" },
                                                 "Error in closing DB connection while saving a Object Data."+ex.getMessage(),
                                                 ex, LogMinderDOMUtil.VALUE_MIC);
                }
            }
		
		
		return true;
	}
	
	
}
