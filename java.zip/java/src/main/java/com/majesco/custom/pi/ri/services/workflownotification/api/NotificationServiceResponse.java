/**
 * 
 */
package com.majesco.custom.pi.ri.services.workflownotification.api;

/**
 * @author Kaushik87149
 *
 */
public class NotificationServiceResponse{
	private boolean success;
	private String responseMessage;
	
	
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	@Override
	public String toString() {
		return "NotificationServiceResponse [success=" + success + ", responseMessage=" + responseMessage + "]";
	}

	
	
	
}
