package com.majesco.custom.pi.ri.services.workflownotification.api;
/**
 * 
 */

import java.util.Date;

import org.codehaus.jackson.annotate.JsonIgnore;

/**
 * @author Kaushik87149
 *
 */
public class WorkflowStatusNotification {
	private long notificationId;
	private String entityType;
	private String entityReference;
	private String taskName;	
	private String taskDescription;
	private String taskStage;
	private String taskStageDescription;
	private String priorEntityReference;
	private String userCreated;
	private Date dateCreated;
	private Date dateModified;
	private String userModified;
	private String companyCode;
	private String productCode;
	private long policyNumber;
	private int renewalCounter;
	private int revisionNumber;
	//private String revisionNumber;
	private String displayPolicyNumber;
	private String transactionAction;
	private String transactionCode;
	private String oldPolicyReference;
	
	private int remainingRetryAttempts;
	
	public long getNotificationId() {
		return notificationId;
	}
	public void setNotificationId(long notificationId) {
		this.notificationId = notificationId;
	}
	public String getEntityType() {
		return entityType;
	}
	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}
	public String getEntityReference() {
		return entityReference;
	}
	public void setEntityReference(String entityReference) {
		this.entityReference = entityReference;
	}
	
	public String getOldPolicyReference() {
		return oldPolicyReference;
	}
	public void setOldPolicyReference(String oldPolicyReference) {
		this.oldPolicyReference = oldPolicyReference;
	}
	
	
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getTaskDescription() {
		return taskDescription;
	}
	public void setTaskDescription(String taskDescription) {
		this.taskDescription = taskDescription;
	}
	public String getTaskStage() {
		return taskStage;
	}
	public void setTaskStage(String taskStage) {
		this.taskStage = taskStage;
	}
	public String getTaskStageDescription() {
		return taskStageDescription;
	}
	public void setTaskStageDescription(String taskStageDescription) {
		this.taskStageDescription = taskStageDescription;
	}
	public String getPriorEntityReference() {
		return priorEntityReference;
	}
	public void setPriorEntityReference(String priorEntityReference) {
		this.priorEntityReference = priorEntityReference;
	}
	public String getUserCreated() {
		return userCreated;
	}
	public void setUserCreated(String userCreated) {
		this.userCreated = userCreated;
	}
	public String getUserModified() {
		return userModified;
	}
	public void setUserModified(String userModified) {
		this.userModified = userModified;
	}
	public Date getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	public Date getDateModified() {
		return dateModified;
	}
	public void setDateModified(Date dateModified) {
		this.dateModified = dateModified;
	}
	public String getCompanyCode() {
		return companyCode;
	}
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public long getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(long policyNumber) {
		this.policyNumber = policyNumber;
	}
	public int getRenewalCounter() {
		return renewalCounter;
	}
	public void setRenewalCounter(int renewalCounter) {
		this.renewalCounter = renewalCounter;
	}
	public int getRevisionNumber() {
		return revisionNumber;
	}
	public void setRevisionNumber(int revisionNumber) {
		this.revisionNumber = revisionNumber;
	}
	public String getDisplayPolicyNumber() {
		return displayPolicyNumber;
	}
	public void setDisplayPolicyNumber(String displayPolicyNumber) {
		this.displayPolicyNumber = displayPolicyNumber;
	}
	public String getTransactionAction() {
		return transactionAction;
	}
	public void setTransactionAction(String transactionAction) {
		this.transactionAction = transactionAction;
	}
	public String getTransactionCode() {
		return transactionCode;
	}
	public void setTransactionCode(String transactionCode) {
		this.transactionCode = transactionCode;
	}
	
	@JsonIgnore
	public int getRemainingRetryAttempts() {
		return remainingRetryAttempts;
	}
	@JsonIgnore
	public void setRemainingRetryAttempts(int remainingRetryAttempts) {
		this.remainingRetryAttempts = remainingRetryAttempts;
	}
	
	@Override
	public String toString() {
		return "WorkflowStatusNotification [notificationId=" + notificationId + ", "
				+ (entityType != null ? "entityType=" + entityType + ", " : "")
				+ (entityReference != null ? "entityReference=" + entityReference + ", " : "")
				+ (taskName != null ? "taskName=" + taskName + ", " : "")
				+ (taskDescription != null ? "taskDescription=" + taskDescription + ", " : "")
				+ (taskStage != null ? "taskStage=" + taskStage + ", " : "")
				+ (taskStageDescription != null ? "taskStageDescription=" + taskStageDescription + ", " : "")
				+ (priorEntityReference != null ? "priorEntityReference=" + priorEntityReference + ", " : "")
				+ (userCreated != null ? "userCreated=" + userCreated + ", " : "")
				+ (dateCreated != null ? "dateCreated=" + dateCreated + ", " : "")
				+ (companyCode != null ? "companyCode=" + companyCode + ", " : "")
				+ (productCode != null ? "productCode=" + productCode + ", " : "") + "policyNumber=" + policyNumber
				+ ", renewalCounter=" + renewalCounter + ", revisionNumber=" + revisionNumber + ", "
				+ (displayPolicyNumber != null ? "displayPolicyNumber=" + displayPolicyNumber + ", " : "")
				+ (transactionAction != null ? "transactionAction=" + transactionAction + ", " : "")
				+ (transactionCode != null ? "transactionCode=" + transactionCode + ", " : "")
				+ "remainingRetryAttempts=" + remainingRetryAttempts + "]";
	}
	
	
}
