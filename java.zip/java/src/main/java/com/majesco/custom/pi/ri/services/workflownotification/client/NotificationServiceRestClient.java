/**
 * 
 */
package com.majesco.custom.pi.ri.services.workflownotification.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.util.Date;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.codehaus.jackson.map.ObjectMapper;

import com.majesco.custom.pi.ri.services.workflownotification.api.NotificationServiceResponse;
import com.majesco.custom.pi.ri.services.workflownotification.api.WorkflowStatusNotification;


/**
 * @author Kaushik87149
 *
 */
public class NotificationServiceRestClient {
	
	private final String webServiceURL;
	private final String userId;
	private final String password;
	
	public NotificationServiceRestClient(String webServiceURL, String userId, String password) {
		super();
		this.webServiceURL = webServiceURL;
		this.userId = userId;
		this.password = password;
	}

	public NotificationServiceResponse sendNotification(WorkflowStatusNotification activity) throws Exception{
		NotificationServiceResponse responseObject = null;
		
		DefaultHttpClient client = new DefaultHttpClient();
		try {
			HttpPost postMethod = null;
			
			//Creating default GET METHOD instance
			postMethod = new HttpPost(webServiceURL);
			
			//Adding basic authentication to header
	        String authString = userId + ":" + password;
	        String authorizationHeader = "Basic " + org.apache.cxf.common.util.Base64Utility.encode(authString.getBytes());
			
			postMethod.addHeader("Authorization", authorizationHeader);
			
			String json = getJson(activity);
			
			StringEntity input = new StringEntity(json);
			input.setContentType("application/json");
			
	        postMethod.setEntity(input);
	        HttpResponse response = client.execute(postMethod);

			if (response.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
				   + response.getStatusLine().getStatusCode());
			}
			
			BufferedReader br = new BufferedReader(new InputStreamReader((response.getEntity().getContent())));
			
			StringBuffer buffer = new StringBuffer();
			String responseData = null;
			while ((responseData = br.readLine()) != null) {
				buffer.append(responseData);
			}
			
			ObjectMapper mapper = 	new ObjectMapper();
			mapper.configure(org.codehaus.jackson.map.DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			responseObject = mapper.readValue(buffer.toString(), NotificationServiceResponse.class);
		}finally {
			client.getConnectionManager().shutdown();
		}
		
		return responseObject;
	}
	static String getJson(WorkflowStatusNotification obj){
		ObjectMapper mapper = new ObjectMapper();
		StringWriter writer = new StringWriter();
		try {
			mapper.writeValue(writer, obj);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return writer.getBuffer().toString();
		
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		final String URL = "http://usa-pc0ljcqy.majesco.com:8080/notify";
		final String userId = "user@cover-all.com";
		final String password = "XXX";
		
		
		WorkflowStatusNotification obj = new WorkflowStatusNotification();
		obj.setNotificationId(1977133);
		obj.setEntityType("POLICY");
		obj.setEntityReference("P20CA0017072657000");
		obj.setTaskName("RATING");
		obj.setTaskDescription("Rating");
		obj.setTaskStage("READY");
		obj.setTaskStageDescription(null);
		obj.setPriorEntityReference(null);
		obj.setUserCreated("aaa@cover-all.com");
		obj.setDateCreated(new Date());
		obj.setCompanyCode("20");
		obj.setProductCode("CA");
		obj.setPolicyNumber(1707265);
		obj.setRenewalCounter(7);
		obj.setRevisionNumber(0);
		obj.setDisplayPolicyNumber("20-A-001707265-7");
		obj.setTransactionAction("redoPolicy");
		obj.setTransactionCode("05");
		
		NotificationServiceRestClient client = new NotificationServiceRestClient(URL, userId, password);
		
		NotificationServiceResponse responseObject = client.sendNotification(obj);
		System.out.println(responseObject);
		
	}
	

}
