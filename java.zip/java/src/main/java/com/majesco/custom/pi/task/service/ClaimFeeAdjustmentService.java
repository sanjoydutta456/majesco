package com.majesco.custom.pi.task.service;

import java.io.IOException;
import java.io.StringWriter;
import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.w3c.dom.Document;

import com.coverall.exceptions.JDBCException;
import com.coverall.exceptions.ServiceException;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.events.EventProcessor;
import com.coverall.mt.http.User;
import com.coverall.mt.services.SchedulableService;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServicesDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;

import com.coverall.mt.services.SchedulableService;

public class ClaimFeeAdjustmentService extends SchedulableService {
	
	public ClaimFeeAdjustmentService() throws RemoteException {
		super();
	}

	private static final long serialVersionUID = 1L;
	
	private static final String FUNCTION_NAME = "ClaimFeeAdjustment";
	
	public Document process(Document request, String logName) throws Exception {
		logMessage(LogEntry.SEVERITY_INFO, "Control inside Process Claim Fee Adjustment Service", "");
		
		ClaimFeeAdjustmentService claimFeeAdjustmentService = new ClaimFeeAdjustmentService();
	
			claimFeeAdjustmentService.claimFeeAdjustment(request, logName);	
			
			claimFeeAdjustmentService.secondYearFee(request, logName);
			
			claimFeeAdjustmentService.thirdYearFee(request, logName);
		
		return request; 
	}
	
	
	private void logMessage(int logLevel, String inputMsg, String objMsg) {
		LogMinder.getLogMinder().log(logLevel, ClaimFeeAdjustmentService.class.getName(), FUNCTION_NAME,
				ServletConfigUtil.COMPONENT_PORTAL, new Object[]{objMsg}, 
				inputMsg, null, LogMinderDOMUtil.VALUE_SCHEDULAR);
	}
	
	public void claimFeeAdjustment(Document request, String logName) 
	{
		logMessage(LogEntry.SEVERITY_INFO, "Control inside Claim Fee Adjustment one Service", "");
		Connection conn = null;
        PreparedStatement pst = null;
        User user = null;
        String MQP_ENTITY_TYPE=null;
        String MQP_ENTITY_REFERENCE=null;
        String MQP_DISPLAY_POLICY_NUMBER=null;
        CallableStatement callStmt = null;
        ResultSet rs = null;
        try 
        {	logMessage(LogEntry.SEVERITY_INFO, "Control inside Claim Fee Adjustment Service one try block", "");
        	user = ServicesDOMUtil.getUser(request);
            conn = ConnectionPool.getConnection(user);
           
            pst = conn.prepareStatement
				("select mq.MQP_ENTITY_TYPE,\r\n"
						+ "mq.MQP_ENTITY_REFERENCE,\r\n"
						+ "mq.MQP_DISPLAY_POLICY_NUMBER,\r\n"
						+ "mq.MQP_EXPIRATION_DATE,\r\n"
						+ "cf.AIBC_C_CURRENT_CLAIM_FEE\r\n"
						+ "from MIS_QUOTE_POLICIES mq, mis_c_wk_claims_fees cf\r\n"
						+ "where mq.MQP_ENTITY_REFERENCE = cf.AIBC_ENTITY_REFERENCE\r\n"
						+ "and mq.MQP_ENTITY_TYPE = 'POLICY'\r\n"
						+ "and (\r\n"
						+ "((mq.MQP_EXPIRATION_DATE >= sysdate \r\n"
						+ "and mq.MQP_EXPIRATION_DATE <= trunc(sysdate)+30 and cf.AIBC_C_CURRENT_CLAIM_FEE is not NULL)\r\n"
						+ "and (mq.MQP_ENTITY_REFERENCE not in (select ea.UTMG_ENTITY_REFERENCE from UTM_EVENT_ACTIVITIES ea \r\n"
						+ "where ea.UTMG_EVENT_CODE = 'CLAIMFEEADJUSTMENT' and ea.UTMG_ACTIVITY_STATUS = 'SUCCESS'))))\r\n"
						+ "and (mq.mqp_transaction_action ='createPolicy' \r\n"
						+ "or mq.mqp_transaction_action ='renewPolicy' \r\n"
						+ "or mq.mqp_transaction_action ='cancellation')");
            		
            rs = pst.executeQuery();
            while(rs.next()) {		
            logMessage(LogEntry.SEVERITY_INFO, "Control inside Claim Fee Adjustment one Service inside rs", "");
					MQP_ENTITY_TYPE = rs.getString("MQP_ENTITY_TYPE");
					MQP_ENTITY_REFERENCE = rs.getString("MQP_ENTITY_REFERENCE");
					MQP_DISPLAY_POLICY_NUMBER = rs.getString("MQP_DISPLAY_POLICY_NUMBER");
					
					TaskCreate taskCreate = new TaskCreate();
					taskCreate.createTask(user,MQP_ENTITY_TYPE, "Claims fee Adjustment","CLAIMFEEADJUSTMENT","CLAIM FEE ADJUSTMENT COMPLETE",MQP_ENTITY_REFERENCE,MQP_DISPLAY_POLICY_NUMBER);
					
				}
			
        }catch(Exception ex){
            ex.printStackTrace();
           if (ex instanceof JDBCException && ((JDBCException)ex).getSeverity() == JDBCException.FATAL){
               LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                                            getClass().getName(), "Claim Fee Adjustment one Service",
                                            ServletConfigUtil.COMPONENT_PORTAL,
                                            new Object[] { null },
                                            "Error in Claim Fee Adjustment Service one "+ex.getMessage(),
                                            ex, LogMinderDOMUtil.VALUE_MIC);
           }else{
               LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                                            getClass().getName(), "Claim Fee Adjustment one Service",
                                            ServletConfigUtil.COMPONENT_PORTAL,
                                            new Object[] { null },
                                            "Error in Claim Fee Adjustment Service one."+ex.getMessage(),
                                            ex, LogMinderDOMUtil.VALUE_MIC);
           }
        }finally {
        	try {
            DBUtil.close(null, pst, conn);
            }catch(Exception ex) {}
        }
	}
	
	public void secondYearFee(Document request, String logName) 
	{
		logMessage(LogEntry.SEVERITY_INFO, "Control inside Claim Fee Adjustment second year Service", "");
		Connection conn = null;
        PreparedStatement pst = null;
        User user = null;
        String MQP_ENTITY_TYPE=null;
        String MQP_ENTITY_REFERENCE=null;
        String MQP_DISPLAY_POLICY_NUMBER=null;
        CallableStatement callStmt = null;
        ResultSet rs = null;
        try 
        {	logMessage(LogEntry.SEVERITY_INFO, "Control inside Claim Fee Adjustment second year Service try block", "");
        	user = ServicesDOMUtil.getUser(request);
            conn = ConnectionPool.getConnection(user);
           
            pst = conn.prepareStatement
				("select mq.MQP_ENTITY_TYPE,\r\n"
						+ "mq.MQP_ENTITY_REFERENCE,\r\n"
						+ "mq.MQP_DISPLAY_POLICY_NUMBER,\r\n"
						+ "mq.MQP_EXPIRATION_DATE,\r\n"
						+ "cf.AIBC_C_CURRENT_CLAIM_FEE\r\n"
						+ "from MIS_QUOTE_POLICIES mq, mis_c_wk_claims_fees cf\r\n"
						+ "where mq.MQP_ENTITY_REFERENCE = cf.AIBC_ENTITY_REFERENCE\r\n"
						+ "and mq.MQP_ENTITY_TYPE = 'POLICY'\r\n"
						+ "and (\r\n"
						+ "( (mq.MQP_EXPIRATION_DATE >= sysdate - 730 \r\n"
						+ "and mq.MQP_EXPIRATION_DATE < sysdate - 365 \r\n"
						+ "and cf.AIBC_C_CURRENT_CLAIM_FEE is not NULL )\r\n"
						+ "and (mq.MQP_ENTITY_REFERENCE not in (select ea.UTMG_ENTITY_REFERENCE from UTM_EVENT_ACTIVITIES ea \r\n"
						+ "where ea.UTMG_EVENT_CODE = 'CLAIMFEEADJUSTMENTSECOND' and ea.UTMG_ACTIVITY_STATUS = 'SUCCESS'))))\r\n"
						+ "and (mq.mqp_transaction_action ='createPolicy' \r\n"
						+ "or mq.mqp_transaction_action ='renewPolicy' \r\n"
						+ "or mq.mqp_transaction_action ='cancellation')");
            
            rs = pst.executeQuery();
            while(rs.next()) {	
					logMessage(LogEntry.SEVERITY_INFO, "Control inside Claim Fee Adjustment second year Service inside rs", "");
					MQP_ENTITY_TYPE = rs.getString("MQP_ENTITY_TYPE");
					MQP_ENTITY_REFERENCE = rs.getString("MQP_ENTITY_REFERENCE");
					MQP_DISPLAY_POLICY_NUMBER = rs.getString("MQP_DISPLAY_POLICY_NUMBER");
					
					
					TaskCreate taskCreate = new TaskCreate();
					taskCreate.createTask(user,MQP_ENTITY_TYPE, "Claims fee Adjustment 2nd year","CLAIMFEEADJUSTMENTSECOND","CLAIM FEE ADJUSTMENT SECOND COMPLETE",MQP_ENTITY_REFERENCE,MQP_DISPLAY_POLICY_NUMBER);
					
				}			
        }catch(Exception ex){
            ex.printStackTrace();
           if (ex instanceof JDBCException && ((JDBCException)ex).getSeverity() == JDBCException.FATAL){
               LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                                            getClass().getName(), "Claim Fee Adjustment Service second year",
                                            ServletConfigUtil.COMPONENT_PORTAL,
                                            new Object[] { null },
                                            "Error in Claim Fee Adjustment Service second year "+ex.getMessage(),
                                            ex, LogMinderDOMUtil.VALUE_MIC);
           }else{
               LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                                            getClass().getName(), "Claim Fee Adjustment Service second year",
                                            ServletConfigUtil.COMPONENT_PORTAL,
                                            new Object[] { null },
                                            "Error in Claim Fee Adjustment Service second year."+ex.getMessage(),
                                            ex, LogMinderDOMUtil.VALUE_MIC);
           }
        }finally {
        	try {
                DBUtil.close(null, pst, conn);
                }catch(Exception ex) {}
            }
	}
	
	public void thirdYearFee(Document request, String logName)
	{
		logMessage(LogEntry.SEVERITY_INFO, "Control inside Claim Fee Adjustment third year Service", "");
		Connection conn = null;
        PreparedStatement pst = null;
        User user = null;
        String MQP_ENTITY_TYPE=null;
        String MQP_ENTITY_REFERENCE=null;
        String MQP_DISPLAY_POLICY_NUMBER=null;
        CallableStatement callStmt = null;
        ResultSet rs = null;
        try 
        {	logMessage(LogEntry.SEVERITY_INFO, "Control inside Claim Fee Adjustment third year Service try block", "");
        	user = ServicesDOMUtil.getUser(request);
            conn = ConnectionPool.getConnection(user);
           
            pst = conn.prepareStatement
			("select mq.MQP_ENTITY_TYPE,\r\n"
					+ "mq.MQP_ENTITY_REFERENCE,\r\n"
					+ "mq.MQP_DISPLAY_POLICY_NUMBER,\r\n"
					+ "mq.MQP_EXPIRATION_DATE,\r\n"
					+ "cf.AIBC_C_CURRENT_CLAIM_FEE\r\n"
					+ "from MIS_QUOTE_POLICIES mq, mis_c_wk_claims_fees cf\r\n"
					+ "where mq.MQP_ENTITY_REFERENCE = cf.AIBC_ENTITY_REFERENCE\r\n"
					+ "and mq.MQP_ENTITY_TYPE = 'POLICY'\r\n"
					+ "and (\r\n"
					+ "((mq.MQP_EXPIRATION_DATE <= sysdate - 730 \r\n"
					+ "and mq.MQP_EXPIRATION_DATE < sysdate \r\n"
					+ "and cf.AIBC_C_CURRENT_CLAIM_FEE is not NULL )\r\n"
					+ "and (mq.MQP_ENTITY_REFERENCE not in (select ea.UTMG_ENTITY_REFERENCE from UTM_EVENT_ACTIVITIES ea \r\n"
					+ "where ea.UTMG_EVENT_CODE = 'CLAIMFEEADJUSTMENTTHIRD' and ea.UTMG_ACTIVITY_STATUS = 'SUCCESS'))))\r\n"
					+ "and (mq.mqp_transaction_action ='createPolicy' \r\n"
					+ "or mq.mqp_transaction_action ='renewPolicy' \r\n"
					+ "or mq.mqp_transaction_action ='cancellation')");
       
            
            rs = pst.executeQuery();
            while(rs.next()) {	 
					logMessage(LogEntry.SEVERITY_INFO, "Control inside Claim Fee Adjustment third year Service inside rs", "");
					MQP_ENTITY_TYPE = rs.getString("MQP_ENTITY_TYPE");
					MQP_ENTITY_REFERENCE = rs.getString("MQP_ENTITY_REFERENCE");
					MQP_DISPLAY_POLICY_NUMBER = rs.getString("MQP_DISPLAY_POLICY_NUMBER");
					
					
					TaskCreate taskCreate = new TaskCreate();
					taskCreate.createTask(user,MQP_ENTITY_TYPE, "Claims fee Adjustment 3rd year","CLAIMFEEADJUSTMENTTHIRD","CLAIM FEE ADJUSTMENT THIRD COMPLETE",MQP_ENTITY_REFERENCE,MQP_DISPLAY_POLICY_NUMBER);
					
				}
			
        }catch(Exception ex){
            ex.printStackTrace();
           if (ex instanceof JDBCException && ((JDBCException)ex).getSeverity() == JDBCException.FATAL){
               LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                                            getClass().getName(), "Claim Fee Adjustment Service third year",
                                            ServletConfigUtil.COMPONENT_PORTAL,
                                            new Object[] { null },
                                            "Error in Claim Fee Adjustment Service  third year"+ex.getMessage(),
                                            ex, LogMinderDOMUtil.VALUE_MIC);
           }else{
               LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                                            getClass().getName(), "Claim Fee Adjustment Service third year",
                                            ServletConfigUtil.COMPONENT_PORTAL,
                                            new Object[] { null },
                                            "Error in Claim Fee Adjustment Service third year."+ex.getMessage(),
                                            ex, LogMinderDOMUtil.VALUE_MIC);
           }
        }finally {
        	try {
                DBUtil.close(null, pst, conn);
                }catch(Exception ex) {}
            }
	}
	

	@Override
	public String getComponentName() {
		return ServletConfigUtil.COMPONENT_PORTAL;
	}	
}

