package com.majesco.custom.pi.task.service;

import java.io.IOException;
import java.io.StringWriter;
import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.w3c.dom.Document;

import com.coverall.exceptions.JDBCException;
import com.coverall.exceptions.ServiceException;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.events.EventProcessor;
import com.coverall.mt.http.User;
import com.coverall.mt.services.SchedulableService;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServicesDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;

import com.coverall.mt.services.SchedulableService;

public class ConditionalRenewalService extends SchedulableService {
	
	private static final long serialVersionUID = 1L;
	
	private static final String FUNCTION_NAME = "ConditionalRenewal";

	public ConditionalRenewalService() throws RemoteException {
		super();
	}
	
	public Document process(Document request, String logName) throws Exception {
		logMessage(LogEntry.SEVERITY_FATAL, "Control inside Conditional Renewal Service", "");
		Connection conn = null;
        PreparedStatement pst = null;
        User user = null;
        String MQP_ENTITY_TYPE=null;
        String MQP_ENTITY_REFERENCE=null;
        String MQP_DISPLAY_POLICY_NUMBER=null;
        CallableStatement callStmt = null;
        ResultSet rs = null;
        try {logMessage(LogEntry.SEVERITY_FATAL, "Control inside Conditional Renewal Service try block", "");
        	user = ServicesDOMUtil.getUser(request);
            conn = ConnectionPool.getConnection(user);
           
            pst = conn.prepareStatement
            		("with t as ("
            				+"select st.risk_state,st.entity_reference,qp.expiration_date,qp.entity_type,qp.display_policy_number,qp.revision_number,qp.transaction_action,qp.org_entity_reference "
            				+ "from vw_MIS_WC_STATE_INFORMATION st, vw_mis_quote_policies qp where st.entity_reference=qp.entity_reference "
            				+")"
            				+"select t.risk_state,iel.no_of_days,t.entity_reference,t.entity_type,t.display_policy_number,t.expiration_date,t.revision_number,t.transaction_action,t.org_entity_reference, "
            				+"(t.expiration_date-((iel.no_of_days+30))) new_date from t,IEL_PI_WK_CN_RN_DAYS iel where t.risk_state=iel.state_code "
            				+"and iel.no_of_days in (select max(no_of_days) from IEL_PI_WK_CN_RN_DAYS ip,vw_MIS_WC_STATE_INFORMATION st where ip.state_code=st.risk_state "
            				+"and ip.expiration_date is null "
            				+"and st.entity_reference=t.entity_reference) "
            				+"and t.revision_number = (select max(qpm.mqp_revision_number) from mis_quote_policies qpm where qpm.mqp_org_entity_reference = t.org_entity_reference "
    						+"group by qpm.mqp_org_entity_reference) "
            				+"and t.expiration_date-((iel.no_of_days+30)) < trunc(sysdate) "
            				+"and (k_transaction_management.f_is_booked(t.entity_type, t.entity_reference) = 'Y' )"
            				+"and t.transaction_action !='cancellation' and ENTITY_TYPE='POLICY' "
            				+" and (t.ENTITY_REFERENCE not in (select ea.UTMG_ENTITY_REFERENCE from UTM_EVENT_ACTIVITIES ea\r\n"
            				+ "where ea.UTMG_EVENT_CODE = 'CONDITIONALRENEWAL' and ea.UTMG_ACTIVITY_STATUS = 'SUCCESS'))");
            rs = pst.executeQuery();
			while(rs.next()) {
            logMessage(LogEntry.SEVERITY_FATAL, "Control inside Conditional Renewal Service inside result set", "");
				logMessage(LogEntry.SEVERITY_FATAL, "Control inside Conditional Renewal Service inside rs", "");
					MQP_ENTITY_TYPE = rs.getString("entity_type");
					MQP_ENTITY_REFERENCE = rs.getString("entity_reference");
					MQP_DISPLAY_POLICY_NUMBER = rs.getString("display_policy_number");
					TaskCreate taskCreate=new TaskCreate();
					taskCreate.createTask(user,MQP_ENTITY_TYPE, "Conditional Renewal","CONDITIONALRENEWAL","CONDITIONAL RENEWAL COMPLETE",MQP_ENTITY_REFERENCE,MQP_DISPLAY_POLICY_NUMBER);
					
				}
			
        }catch(Exception ex){
            ex.printStackTrace();
           if (ex instanceof JDBCException && ((JDBCException)ex).getSeverity() == JDBCException.FATAL){
               LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                                            getClass().getName(), "Conditional Renewal Service",
                                            ServletConfigUtil.COMPONENT_PORTAL,
                                            new Object[] { null },
                                            "Error in Conditional Renewal Service "+ex.getMessage(),
                                            ex, LogMinderDOMUtil.VALUE_MIC);
           }else{
               LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                                            getClass().getName(), "Conditional Renewal Service",
                                            ServletConfigUtil.COMPONENT_PORTAL,
                                            new Object[] { null },
                                            "Error in Conditional Renewal Service."+ex.getMessage(),
                                            ex, LogMinderDOMUtil.VALUE_MIC);
           }
        }finally {
            DBUtil.close(null, pst, conn);
        }
		return request; 
	}
	
	
	private void logMessage(int logLevel, String inputMsg, String objMsg) {
		LogMinder.getLogMinder().log(logLevel, ConditionalRenewalService.class.getName(), FUNCTION_NAME,
				ServletConfigUtil.COMPONENT_PORTAL, new Object[]{objMsg}, 
				inputMsg, null, LogMinderDOMUtil.VALUE_SCHEDULAR);
	}

	@Override
	public String getComponentName() {
		return ServletConfigUtil.COMPONENT_PORTAL;
	}	
}

