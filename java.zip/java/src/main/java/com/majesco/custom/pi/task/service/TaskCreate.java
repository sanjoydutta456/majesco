package com.majesco.custom.pi.task.service;

import java.io.IOException;
import java.io.StringWriter;
import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.w3c.dom.Document;

import com.coverall.exceptions.JDBCException;
import com.coverall.exceptions.ServiceException;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.events.EventProcessor;
import com.coverall.mt.http.User;
import com.coverall.mt.services.SchedulableService;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServicesDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;

import com.coverall.mt.services.SchedulableService;

public class TaskCreate {
	
	private static final long serialVersionUID = 1L;
	
	

	public TaskCreate() throws RemoteException {
		super();
	}
	
	public void createTask(User user,String  MQP_ENTITY_TYPE, String UTMC_AREA_NAME,String UTMA_NAME,String UTMD_STAGE_DISPLAY_NAME,String MQP_ENTITY_REFERENCE, String MQP_DISPLAY_POLICY_NUMBER) throws Exception {
		logMessage(LogEntry.SEVERITY_FATAL, "create Task", "");
		Connection conn = null;
        PreparedStatement pst = null;
        CallableStatement callStmt = null;
        try {
        	logMessage(LogEntry.SEVERITY_FATAL, "create Task UTMA_NAME " + UTMA_NAME , "");
            conn = ConnectionPool.getConnection(user);
            int eventId = getUTMGEvenId(user,UTMA_NAME);
            int trigerredAreaId = getUTMGTriggerAreaId(user,UTMC_AREA_NAME);
            int trigerredStageId = getUTMGTriggerStageId(user,UTMD_STAGE_DISPLAY_NAME);
            
            
            callStmt = conn
		                        .prepareCall("{? = call k_create_task.f_insert_task(?,?, ?, ?,?,?,?,?)}");
		                
		                callStmt.registerOutParameter(1, Types.BIGINT);
		                callStmt.setString(2,MQP_ENTITY_TYPE);
		                callStmt.setInt(3, trigerredAreaId);
		                callStmt.setInt(4,eventId);
		                callStmt.setInt(5,trigerredStageId);
		                callStmt.setString(6,MQP_ENTITY_REFERENCE);
		                callStmt.setString(7,MQP_DISPLAY_POLICY_NUMBER);
		                callStmt.setString(8,UTMA_NAME);
		                callStmt.registerOutParameter(9, Types.VARCHAR);
		                callStmt.execute();
		                long errorCode = callStmt.getLong(1);
		                if (errorCode != 0) {
		                    String errorMessage = callStmt.getString(9);
		                    throw JDBCException.getExceptionFor(errorCode, errorMessage);
		                }
		                logMessage(LogEntry.SEVERITY_FATAL, "Control inside createTask before commit", "");
		                conn.commit();
		                logMessage(LogEntry.SEVERITY_FATAL, "Control inside CreateTask Service after commit", "");
				
			
        }catch(Exception ex){
            ex.printStackTrace();
           if (ex instanceof JDBCException && ((JDBCException)ex).getSeverity() == JDBCException.FATAL){
               LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                                            getClass().getName(), "Conditional Renewal Service",
                                            ServletConfigUtil.COMPONENT_PORTAL,
                                            new Object[] { null },
                                            "Error in create task "+ex.getMessage(),
                                            ex, LogMinderDOMUtil.VALUE_MIC);
           }else{
               LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                                            getClass().getName(), "create task",
                                            ServletConfigUtil.COMPONENT_PORTAL,
                                            new Object[] { null },
                                            "Error in create task."+ex.getMessage(),
                                            ex, LogMinderDOMUtil.VALUE_MIC);
           }
        }finally {
            DBUtil.close(null, pst, conn);
        }
		 
	}
	
	
	private void logMessage(int logLevel, String inputMsg, String objMsg) {
		LogMinder.getLogMinder().log(logLevel, ConditionalRenewalService.class.getName(), null,
				ServletConfigUtil.COMPONENT_PORTAL, new Object[]{objMsg}, 
				inputMsg, null, LogMinderDOMUtil.VALUE_SCHEDULAR);
	}

	
	
	private int getUTMGEvenId(User user,String UTMA_NAME) throws NamingException, SQLException {
		// TODO Auto-generated method stub
		logMessage(LogEntry.SEVERITY_FATAL, "Control inside create task getUTMGEvenId", "");
		int evenId=0;
		
		
		try(Connection conn = ConnectionPool.getConnection(user);
			PreparedStatement stmt = conn.prepareStatement
					("select UTMA_ID from UTM_EVENTS "
							+ "where UTMA_NAME = ?")) {
			 
			stmt.setString(1, UTMA_NAME);
			try(ResultSet rs = stmt.executeQuery()){
				if(rs.next()) {
					evenId = rs.getInt("UTMA_ID");
				}
			}
			
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
		
		return evenId;
        
	}
	
	private int getUTMGTriggerAreaId(User user,String UTMC_AREA_NAME) throws NamingException, SQLException {
		// TODO Auto-generated method stub
		logMessage(LogEntry.SEVERITY_FATAL, "Control inside create task getUTMGTriggerAreaId", "");
		int utmcId=0;
		
		try(Connection conn = ConnectionPool.getConnection(user);
			PreparedStatement stmt = conn.prepareStatement
					("select UTMC_ID from UTM_TRIGGER_AREA "
							+ "where UTMC_SUB_AREA_DISPLAY_NAME = ?")) {
			 
			stmt.setString(1, UTMC_AREA_NAME);
			try(ResultSet rs = stmt.executeQuery()){
				if(rs.next()) {
					utmcId = rs.getInt("UTMC_ID");
				}
			}
			
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
		
		return utmcId;
        
	}
	
	private int getUTMGTriggerStageId(User user,String UTMD_STAGE_DISPLAY_NAME) throws NamingException, SQLException {
		logMessage(LogEntry.SEVERITY_FATAL, "Control inside create task getUTMGTriggerStageId", "");
		// TODO Auto-generated method stub
		int utmdId=0;
		
		try(Connection conn = ConnectionPool.getConnection(user);
			PreparedStatement stmt = conn.prepareStatement
					("select UTMD_ID from UTM_TRIGGER_AREA_STAGES "
							+ "where UTMD_STAGE_DISPLAY_NAME = ?")) {
			 
			stmt.setString(1, UTMD_STAGE_DISPLAY_NAME);
			try(ResultSet rs = stmt.executeQuery()){
				if(rs.next()) {
					utmdId = rs.getInt("UTMD_ID");
				}
			}
			
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
		
		return utmdId;
        
	}
	
}

