package com.majesco.custom.pi.webservices.producerupload.impl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Random;

import javax.jws.WebService;
import javax.servlet.http.HttpServletRequest;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.cxf.phase.PhaseInterceptorChain;
import org.apache.cxf.transport.http.AbstractHTTPDestination;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.db.DriverManagerUtil;
import com.coverall.mt.http.User;
import com.coverall.mt.interfaces.EntityExportImport;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.util.ResourceManager;
import com.coverall.mt.webservices.producerupload.ProducerUploadConstants;
import com.coverall.mt.webservices.producerupload.impl.ProducerUploadService;
import com.coverall.mt.webservices.producerupload.request.ProducerUploadServiceRequest;
import com.coverall.mt.webservices.producerupload.response.ProducerUploadServiceResponse;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.DOMUtil;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.Base64;
import com.coverall.util.XMLUtil;

@WebService(endpointInterface = "com.coverall.mt.webservices.producerupload.IProducerUploadService")
public class PIProducerUploadService extends ProducerUploadService {
	
	private static final String TEMP = "temp";
	private static final Random randomizer = new Random();

	   private File preProcessXML(String inputXMLFilePath, User user) throws Exception
	    {
	        FileInputStream fis = null;
	        InputSource inSource = null;
	        String micRiHome = null;
	        File processedXML = null;
	        File processedXMLDir = null;
	        FileOutputStream fos = null;


	        try{
	            fis = new FileInputStream(new File(inputXMLFilePath));
	            inSource = new InputSource(fis);

	            micRiHome =
	                System.getProperty(DOMUtil.MIC_SYSTEM_HOME) + File.separator +
	                ServletConfigUtil.COMPONENT_RI + File.separator +
	                CustomerConfigUtil.getInstance().getCustomerCode(user.getDomain());

	            processedXMLDir = new File(micRiHome + File.separator + TEMP + File.separator +
	            randomizer.nextLong());

	            processedXMLDir.mkdirs();
	            processedXML = new File(processedXMLDir + File.separator + "processedXML.xml");

	            fos = new FileOutputStream(processedXML);

	            SAXParserFactory factory = SAXParserFactory.newInstance();
	            factory.setNamespaceAware(true);
	            SAXParser parser = factory.newSAXParser();
	            PIProducerXMLHandler handler = new PIProducerXMLHandler(fos, user);
	            XMLReader xmlReader = parser.getXMLReader();
	            xmlReader.setProperty("http://xml.org/sax/properties/lexical-handler",
	                      handler);
	            xmlReader.setFeature("http://xml.org/sax/features/validation",
	                     true);
	            xmlReader.setErrorHandler(handler);

	            parser.parse(inSource, handler);

	        }catch(Exception ex){
	            LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
	                    getClass().getName(), "uploadProducers",
	                    ServletConfigUtil.COMPONENT_RI,
	                    new Object[] {
	                        inputXMLFilePath
	                    }, ex.getMessage(), ex,
	                    LogMinderDOMUtil.VALUE_PRODUCER_UPLOAD);

	            if(processedXMLDir!=null){
	                deleteDir(processedXMLDir);
	            }
	            throw ex;
	        }
	        finally{
	            inSource = null;
	            fis.close();
	            fos.close();
	        }

	        return processedXML;
	    }
	    
	    
	    
	    
	   private boolean deleteDir(File dir) {
	        if (dir.isDirectory()) {
	            String[] children = dir.list();
	            for (int i=0; i<children.length; i++) {
	                boolean success = deleteDir(new File(dir, children[i]));
	                if (!success) {
	                    return false;
	                }
	            }
	        }

	        // The directory is now empty so delete it
	        return dir.delete();
	    }
	
	@Override
	public ProducerUploadServiceResponse producerUpload(
			ProducerUploadServiceRequest request) throws Throwable {

		HttpServletRequest httpRequest = (HttpServletRequest) PhaseInterceptorChain
				.getCurrentMessage().get(AbstractHTTPDestination.HTTP_REQUEST);
		User user = User.getUser(httpRequest);
		ProducerUploadServiceResponse producerUploadResponse = null;
		
		
		if(request == null){
			producerUploadResponse = generateServiceResponse(ProducerUploadConstants.ERROR_NO_REQUEST, ProducerUploadConstants.ERROR_MESSAGE_NO_REQUEST);
			return producerUploadResponse;
		}
		if(request.getUploadXML() == null||request.getUploadXML().length()==0){
			producerUploadResponse = generateServiceResponse(ProducerUploadConstants.ERROR_NO_PRODUCER_XML, ProducerUploadConstants.ERROR_MESSAGE_NO_PRODUCER_XML);
			return producerUploadResponse;
		}
		
		
		String uploadXML = null;
		String updateOnlyContactInfo = null;
		String configFile = null;
		File individualProducerXML = null;
		File individualProducerXMLDir = null;
		HashMap producerLog = new HashMap();

		 File processedXML = null;

		updateOnlyContactInfo = "Y";

		

		String micRiHome = System.getProperty(DOMUtil.MIC_SYSTEM_HOME)
				+ File.separator
				+ ServletConfigUtil.COMPONENT_RI
				+ File.separator
				+ CustomerConfigUtil.getInstance().getCustomerCode(
						user.getDomain());
		File individualProducerXMLTempDir = new File(micRiHome + File.separator + TEMP);
		if(!individualProducerXMLTempDir.exists()){
			individualProducerXMLTempDir.mkdirs();
		}

		individualProducerXMLDir = new File(micRiHome + File.separator + TEMP
				+ File.separator + randomizer.nextLong());
		individualProducerXMLDir.mkdirs();

		individualProducerXML = new File(individualProducerXMLDir
				+ File.separator + "individualProducerXML.xml");
		FileOutputStream fos = new FileOutputStream(individualProducerXML);
		try{
			uploadXML = extractPolicyXML(request);
		}catch (Exception e) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					getClass().getName(), "uploadProducers",
					ServletConfigUtil.COMPONENT_FRAMEWORK,
					new Object[] { individualProducerXML.getAbsolutePath(), updateOnlyContactInfo },
					e.getMessage(), e,
					LogMinderDOMUtil.VALUE_PRODUCER_UPLOAD);
			return producerUploadResponse = generateServiceResponse(ProducerUploadConstants.ERROR_INVALID_ENCODE_STRING, ProducerUploadConstants.ERROR_MESSAGE_INVALID_ENCODE_STRING);
			
		}
		
		//validate input only contains one producer 
		BufferedReader br = new BufferedReader(new StringReader(uploadXML));
		 String currLine = null;
		 int numberOfProducer=0;
		 int numberOfEntity=0;
		 
		 while ((currLine = br.readLine()) != null) {
             try{
                  if(!currLine.trim().equalsIgnoreCase("</PRODUCER>")&&!currLine.trim().equalsIgnoreCase("</PRODUCERS>")&&!currLine.trim().equalsIgnoreCase("</ENTITY>")){
                      if(currLine.trim().equalsIgnoreCase("<PRODUCER>")){
                    	  numberOfProducer++;
                      }
                     if(currLine.trim().equalsIgnoreCase("<ENTITY type=\"PRODUCER\">")){
                    	  numberOfEntity++;
                      }
                  }
                 
             	}catch(Exception ex){
		                 LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
		                     getClass().getName(), "uploadProducers",
		                     ServletConfigUtil.COMPONENT_FRAMEWORK,
		                     new Object[] { individualProducerXML.getAbsolutePath(), updateOnlyContactInfo },
		                     ex.getMessage(), ex, LogMinderDOMUtil.VALUE_PRODUCER_UPLOAD);
		         }
		      }//End of While
		 if (numberOfProducer!=1){
         	 return generateServiceResponse(ProducerUploadConstants.ERROR_NO_INVALID_INPUT,ProducerUploadConstants.ERROR_MESSAGE_NO_INVALID_INPUT);
          }
		if (numberOfEntity!=1){
         	 return generateServiceResponse(ProducerUploadConstants.ERROR_NO_INVALID_INPUT,ProducerUploadConstants.ERROR_MESSAGE_NO_INVALID_INPUT);
          }
		 //write to local file
		BufferedWriter writer = null;
		try {
			writer = new BufferedWriter(new FileWriter(individualProducerXML));
			writer.write(uploadXML);
		} catch (IOException e) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					getClass().getName(), "uploadProducers",
					ServletConfigUtil.COMPONENT_FRAMEWORK,
					new Object[] { individualProducerXML.getAbsolutePath(), updateOnlyContactInfo },
					e.getMessage(), e,
					LogMinderDOMUtil.VALUE_PRODUCER_UPLOAD);
			return producerUploadResponse = generateServiceResponse(ProducerUploadConstants.SYSTEM_ERROR, ProducerUploadConstants.ERROR_MESSAGE_SYSTEM_ERROR);
		} finally {
			try {
				if (writer != null)
					writer.close();
			} catch (IOException e) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
						getClass().getName(), "uploadProducers",
						ServletConfigUtil.COMPONENT_FRAMEWORK,
						new Object[] { individualProducerXML.getAbsolutePath(), updateOnlyContactInfo },
						e.getMessage(), e,
						LogMinderDOMUtil.VALUE_PRODUCER_UPLOAD);
				return producerUploadResponse = generateServiceResponse(ProducerUploadConstants.SYSTEM_ERROR, ProducerUploadConstants.ERROR_MESSAGE_SYSTEM_ERROR);
				
			}
		}
		
		try{
			processedXML = preProcessXML(individualProducerXML.getAbsolutePath(), user);
		}catch(Exception e){
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					getClass().getName(), "uploadProducers",
					ServletConfigUtil.COMPONENT_FRAMEWORK,
					new Object[] { processedXML.getAbsolutePath(), updateOnlyContactInfo },
					e.getMessage(), e,
					LogMinderDOMUtil.VALUE_PRODUCER_UPLOAD);
			return producerUploadResponse = generateServiceResponse(ProducerUploadConstants.SYSTEM_ERROR, ProducerUploadConstants.ERROR_MESSAGE_SYSTEM_ERROR);
		}

		//handling xml file
		LinkedList logDetails = null;
		Iterator itr = null;
		HashMap logEntry = null;

		InputSource inSource = new InputSource(new FileInputStream(
				processedXML));
		String customerCode = CustomerConfigUtil.getInstance().getCustomerCode(
				user.getDomain());

		/* Form the descriptor path */
		configFile = ResourceManager.locateConfDir(ServletConfigUtil.COMPONENT_FRAMEWORK, 
    			customerCode, "producer_descriptor.xml") + "producer_descriptor.xml";

		/* Obtain the descriptor Document */
		Document configDoc = XMLUtil.createDom(new File(configFile));

		/* Call EntityExportImport */
		EntityExportImport entityExportImport = new EntityExportImport();

		HashMap params = new HashMap();
		params.put("mode", "IMPORT");
		params.put("configFilePath", configFile);
		params.put("exportXMLPath", processedXML.getAbsolutePath());
		params.put("overwrite", "true");
		params.put("customerCode", customerCode);
		params.put("logLevel", LogEntry.SEVERITY_INFO + "");
		params.put("entityType", "PRODUCER");
		params.put("failOnError", "false");
		params.put("sinkException", "true");

		Connection conn = null;
		try	{
			conn = ConnectionPool.getConnection(user);
			if (conn != null) {
				producerLog = entityExportImport.importEntity(configDoc, inSource,
						params, conn);
			} else {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
						getClass().getName(), "uploadProducers",
						ServletConfigUtil.COMPONENT_FRAMEWORK,
						new Object[] { processedXML.getAbsolutePath(), updateOnlyContactInfo },
						"Failed to create database connection.", null,
						LogMinderDOMUtil.VALUE_PRODUCER_UPLOAD);
				return producerUploadResponse = generateServiceResponse(ProducerUploadConstants.SYSTEM_ERROR, ProducerUploadConstants.ERROR_MESSAGE_SYSTEM_ERROR);
				
				//throw new ServiceException(,null);
			}
			
		}finally	{
			if(conn!=null){
				conn.commit();
			}
			DriverManagerUtil.close(conn);
		}

		logDetails = (LinkedList) producerLog.get("LogDetails");

		itr = logDetails.iterator();
		logEntry = new HashMap();

		while (itr.hasNext()) {
			logEntry = (HashMap) itr.next();
			String failMessage = (String) (logEntry.containsKey("failedMsg") ? logEntry
					.get("failedMsg") : ProducerUploadConstants.SUCCESS);
			String errorCode = (String) ((logEntry.containsKey("failedErrorCode") && null != logEntry.get("failedErrorCode")) ? logEntry
					.get("failedErrorCode").toString() : ProducerUploadConstants.NO_ERROR);
				producerUploadResponse = generateServiceResponse(errorCode,failMessage);
		}
		fos.close();
		return producerUploadResponse;
	}

	private ProducerUploadServiceResponse generateServiceResponse(
			String errorCode, String failMessage) {
		ProducerUploadServiceResponse response=new ProducerUploadServiceResponse();
		response.setErrorCode(errorCode);
		response.setErrorMessages(failMessage);
		return response;
	}

	private java.lang.String extractPolicyXML(
			ProducerUploadServiceRequest request) {

		byte[] base64DecodedArr = Base64.base64ToByteArray(request
				.getUploadXML().trim());
		String value = null;
		try {
			value = new String(base64DecodedArr, "UTF-8");
		} catch (Exception e) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					getClass().getName(), "uploadProducers",
					ServletConfigUtil.COMPONENT_FRAMEWORK,
					new Object[] { null, "Y" },
					e.getMessage(), null,
					LogMinderDOMUtil.VALUE_PRODUCER_UPLOAD);
			e.printStackTrace();
			
		}
		return value;
	}
	
}
