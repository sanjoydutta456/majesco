package com.majesco.custom.pi.webservices.producerupload.impl;

import java.io.FileOutputStream;
import org.xml.sax.Attributes;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.ext.LexicalHandler;
import org.xml.sax.helpers.DefaultHandler;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;

public class PIProducerXMLHandler extends DefaultHandler implements LexicalHandler,
	ErrorHandler
	{
	    private boolean readingCDATASection = false;
	    private boolean sprProducerCodeFlag = false;
	    private String 	isProducerCodeUnFormated = null;
	    private boolean sprPostalCodeFlag = false;
	    private boolean sprTelephoneFlag = false;
	    private boolean sprFaxFlag = false;
	    private boolean scoPhone1Flag= false;
	    private boolean scoPhone2Flag = false;
	    private boolean scoFaxFlag = false;
	    private String CDATAString = "";


	    private FileOutputStream fos = null;

	    private static final String PRODUCER_ID_TAG = "<COLUMN name=\"SPR_PRODUCER_ID\" datatype=\"NUMBER\" remember=\"true\">\n<![CDATA[CUSTOM: SELECT S_SPR_PRODUCER_ID_SEQ.NEXTVAL FROM DUAL]]>\n</COLUMN>";

	    private static final String PRODUCER_AUTHORITY_ID_TAG="<COLUMN name=\"SPA_AUTHORITY_ID\" datatype=\"NUMBER\" remember=\"true\">\n<![CDATA[CUSTOM: SELECT S_SPA_AUTHORITY_ID_SEQ.NEXTVAL FROM DUAL]]>\n</COLUMN>";
	    private static final String PRODUCER_FK="<COLUMN name=\"SPA_PRODUCER_ID\" datatype=\"NUMBER\" remember=\"true\" uk1=\"true\">\n<![CDATA[CUSTOM: ${fk:SPR_PRODUCER_ID}]]>\n</COLUMN>";

	    private static final String PRODUCER_AUTHORITY_REPLACEMENT_ID="<COLUMN name=\"SPU_REPLACEMENT_ID\" datatype=\"NUMBER\" remember=\"true\">\n<![CDATA[CUSTOM: SELECT S_SPU_ID_SEQ.NEXTVAL FROM DUAL]]>\n</COLUMN>";
	    private static final String PRODUCER_AUTHORITY_FK="<COLUMN name=\"SPU_AUTHORITY_ID\" datatype=\"NUMBER\" remember=\"true\" uk1=\"true\">\n<![CDATA[CUSTOM: ${fk:SPA_AUTHORITY_ID}]]>\n</COLUMN>";

	    private static final String PRODUCER_LICENSE_ID_TAG="<COLUMN name=\"SPI_ID\" datatype=\"NUMBER\" remember=\"true\">\n<![CDATA[CUSTOM: SELECT S_SPI_ID_SEQ.NEXTVAL FROM DUAL]]>\n</COLUMN>";
	    private static final String PRODUCER_LICENSE_FK="<COLUMN name=\"SPI_PRODUCER_ID\" datatype=\"NUMBER\" remember=\"true\" uk1=\"true\">\n<![CDATA[CUSTOM: ${fk:SPR_PRODUCER_ID}]]>\n</COLUMN>";
	      
	    private static final String PRODUCER_ASSIGNMENTS_ID_TAG="<COLUMN name=\"SPE_ASSIGNMENT_ID\" datatype=\"NUMBER\" remember=\"true\">\n<![CDATA[CUSTOM: SELECT S_SPE_ASSIGNMENTS_ID_SEQ.NEXTVAL FROM DUAL]]>\n</COLUMN>";
	    private static final String PRODUCER_ASSIGNMENTS_FK="<COLUMN name=\"SPE_PRODUCER_ID\" datatype=\"NUMBER\" remember=\"true\" uk1=\"true\">\n<![CDATA[CUSTOM: ${fk:SPR_PRODUCER_ID}]]>\n</COLUMN>";
	    
	    private static final String PRODUCER_BILLING_ID_TAG="<COLUMN name=\"SPB_ID\" datatype=\"NUMBER\" remember=\"true\">\n<![CDATA[CUSTOM: SELECT S_SPB_ID_SEQ.NEXTVAL FROM DUAL]]>\n</COLUMN>";
	    private static final String PRODUCER_BILLING_FK="<COLUMN name=\"SPB_PRODUCER_ID\" datatype=\"NUMBER\" remember=\"true\" uk1=\"true\">\n<![CDATA[CUSTOM: ${fk:SPR_PRODUCER_ID}]]>\n</COLUMN>";
	    
	    private static final String PRODUCER_AGENT_CONTACTS_ID_TAG="<COLUMN name=\"SCO_ID\" datatype=\"NUMBER\" remember=\"true\">\n<![CDATA[CUSTOM: SELECT S_SCO_ID_SEQ.NEXTVAL FROM DUAL]]>\n</COLUMN>";
	    private static final String PRODUCER_AGENT_CONTACTS_FK="<COLUMN name=\"SCO_PRODUCER_ID\" datatype=\"NUMBER\" remember=\"true\" uk1=\"true\">\n<![CDATA[CUSTOM: ${fk:SPR_PRODUCER_ID}]]>\n</COLUMN>";
	    
	    private static final String PRODUCER_USER_CREATED = "<COLUMN name=\"SPR_USER_CREATED\" datatype=\"VARCHAR2\">\n<![CDATA[admin@majesco.com]]>\n</COLUMN>";
	    private static final String PRODUCER_DATE_CREATED = "<COLUMN name=\"SPR_DATE_CREATED\" datatype=\"DATE\">\n<![CDATA[SYSDATE]]>\n</COLUMN>";
	    private static final String PRODUCER_USER_MODIFIED = "<COLUMN name=\"SPR_USER_MODIFIED\" datatype=\"VARCHAR2\">\n<![CDATA[admin@majesco.com]]>\n</COLUMN>";
	    private static final String PRODUCER_DATE_MODIFIED = "<COLUMN name=\"SPR_DATE_MODIFIED\" datatype=\"DATE\">\n<![CDATA[SYSDATE]]>\n</COLUMN>";

	    private static final String PRODUCER_AUDIT_DATA = PRODUCER_USER_CREATED+"\n"+PRODUCER_DATE_CREATED+"\n"+PRODUCER_USER_MODIFIED+"\n"+PRODUCER_DATE_MODIFIED;

	    private static final String PRODUCER_AUTHORITY_USER_CREATED = "<COLUMN name=\"SPA_USER_CREATED\" datatype=\"VARCHAR2\">\n<![CDATA[admin@majesco.com]]>\n</COLUMN>";
	    private static final String PRODUCER_AUTHORITY_DATE_CREATED = "<COLUMN name=\"SPA_DATE_CREATED\" datatype=\"DATE\">\n<![CDATA[SYSDATE]]>\n</COLUMN>";
	    private static final String PRODUCER_AUTHORITY_USER_MODIFIED = "<COLUMN name=\"SPA_USER_MODIFIED\" datatype=\"VARCHAR2\">\n<![CDATA[admin@majesco.com]]>\n</COLUMN>";
	    private static final String PRODUCER_AUTHORITY_DATE_MODIFIED = "<COLUMN name=\"SPA_DATE_MODIFIED\" datatype=\"DATE\">\n<![CDATA[SYSDATE]]>\n</COLUMN>";

	    private static final String PRODUCER_AUTHORITY_AUDIT_DATA =PRODUCER_AUTHORITY_USER_CREATED+"\n"+PRODUCER_AUTHORITY_DATE_CREATED+"\n"+PRODUCER_AUTHORITY_USER_MODIFIED+"\n"+PRODUCER_AUTHORITY_DATE_MODIFIED;

	    private static final String PRODUCER_REPLACEMENT_USER_CREATED = "<COLUMN name=\"SPU_USER_CREATED\" datatype=\"VARCHAR2\">\n<![CDATA[admin@cover-all.com]]>\n</COLUMN>";
	    private static final String PRODUCER_REPLACEMENT_DATE_CREATED = "<COLUMN name=\"SPU_DATE_CREATED\" datatype=\"DATE\">\n<![CDATA[SYSDATE]]>\n</COLUMN>";
	    private static final String PRODUCER_REPLACEMENT_USER_MODIFIED = "<COLUMN name=\"SPU_USER_MODIFIED\" datatype=\"VARCHAR2\">\n<![CDATA[]]>\n</COLUMN>";
	    private static final String PRODUCER_REPLACEMENT_DATE_MODIFIED = "<COLUMN name=\"SPU_DATE_MODIFIED\" datatype=\"DATE\">\n<![CDATA[SYSDATE]]>\n</COLUMN>";

	    private static final String PRODUCER_REPLACEMENT_AUDIT_DATA = PRODUCER_REPLACEMENT_USER_CREATED+"\n"+PRODUCER_REPLACEMENT_DATE_CREATED+"\n"+PRODUCER_REPLACEMENT_USER_MODIFIED+"\n"+PRODUCER_REPLACEMENT_DATE_MODIFIED;

	    private static final String PRODUCER_LICENSE_USER_CREATED ="<COLUMN name=\"SPI_USER_CREATED\" datatype=\"VARCHAR2\">\n<![CDATA[admin@majesco.com]]>\n</COLUMN>";
	    private static final String PRODUCER_LICENSE_DATE_CREATED="<COLUMN name=\"SPI_DATE_CREATED\" datatype=\"DATE\">\n<![CDATA[SYSDATE]]>\n</COLUMN>";
	    private static final String PRODUCER_LICENSE_USER_MODIFIED="<COLUMN name=\"SPI_USER_MODIFIED\" datatype=\"VARCHAR2\">\n<![CDATA[admin@majesco.com]]>\n</COLUMN>";
	    private static final String PRODUCER_LICENSE_DATE_MODIFIED="<COLUMN name=\"SPI_DATE_MODIFIED\" datatype=\"DATE\">\n<![CDATA[SYSDATE]]>\n</COLUMN>";
	    
	    private static final String PRODUCER_LICENSE_AUDIT_DATA =PRODUCER_LICENSE_USER_CREATED+"\n"+PRODUCER_LICENSE_DATE_CREATED+"\n"+PRODUCER_LICENSE_USER_MODIFIED+"\n"+PRODUCER_LICENSE_DATE_MODIFIED;
	        
	    private static final String PRODUCER_ASSIGNMENTS_USER_CREATED ="<COLUMN name=\"SPE_USER_CREATED\" datatype=\"VARCHAR2\">\n<![CDATA[admin@majesco.com]]>\n</COLUMN>";
	    private static final String PRODUCER_ASSIGNMENTS_DATE_CREATED="<COLUMN name=\"SPE_DATE_CREATED\" datatype=\"DATE\">\n<![CDATA[SYSDATE]]>\n</COLUMN>";
	    private static final String PRODUCER_ASSIGNMENTS_USER_MODIFIED="<COLUMN name=\"SPE_USER_MODIFIED\" datatype=\"VARCHAR2\">\n<![CDATA[admin@majesco.com]]>\n</COLUMN>";
	    private static final String PRODUCER_ASSIGNMENTS_DATE_MODIFIED="<COLUMN name=\"SPE_DATE_MODIFIED\" datatype=\"DATE\">\n<![CDATA[SYSDATE]]>\n</COLUMN>";
	    
	    private static final String PRODUCER_ASSIGNMENTS_AUDIT_DATA = PRODUCER_ASSIGNMENTS_USER_CREATED+"\n"+PRODUCER_ASSIGNMENTS_DATE_CREATED+"\n"+PRODUCER_ASSIGNMENTS_USER_MODIFIED+"\n"+PRODUCER_ASSIGNMENTS_DATE_MODIFIED;
	  
	    
	    
	    private static final String PRODUCER_BILLING_USER_CREATED ="<COLUMN name=\"SPB_USER_CREATED\" datatype=\"VARCHAR2\">\n<![CDATA[admin@majesco.com]]>\n</COLUMN>";
	    private static final String PRODUCER_BILLING_DATE_CREATED="<COLUMN name=\"SPB_DATE_CREATED\" datatype=\"DATE\">\n<![CDATA[SYSDATE]]>\n</COLUMN>";
	    private static final String PRODUCER_BILLING_USER_MODIFIED="<COLUMN name=\"SPB_USER_MODIFIED\" datatype=\"VARCHAR2\">\n<![CDATA[admin@majesco.com]]>\n</COLUMN>";
	    private static final String PRODUCER_BILLING_DATE_MODIFIED="<COLUMN name=\"SPB_DATE_MODIFIED\" datatype=\"DATE\">\n<![CDATA[SYSDATE]]>\n</COLUMN>";
	    
	    private static final String PRODUCER_BILLING_AUDIT_DATA = PRODUCER_BILLING_USER_CREATED+"\n"+PRODUCER_BILLING_DATE_CREATED+"\n"+PRODUCER_BILLING_USER_MODIFIED+"\n"+PRODUCER_BILLING_DATE_MODIFIED;

	    private static final String PRODUCER_AGENT_CONTACTS_USER_CREATED ="<COLUMN name=\"SCO_USER_CREATED\" datatype=\"VARCHAR2\">\n<![CDATA[admin@majesco.com]]>\n</COLUMN>";
	    private static final String PRODUCER_AGENT_CONTACTS_DATE_CREATED="<COLUMN name=\"SCO_DATE_CREATED\" datatype=\"DATE\">\n<![CDATA[SYSDATE]]>\n</COLUMN>";
	    private static final String PRODUCER_AGENT_CONTACTS_USER_MODIFIED="<COLUMN name=\"SCO_USER_MODIFIED\" datatype=\"VARCHAR2\">\n<![CDATA[admin@majesco.com]]>\n</COLUMN>";
	    private static final String PRODUCER_AGENT_CONTACTS_DATE_MODIFIED="<COLUMN name=\"SCO_DATE_MODIFIED\" datatype=\"DATE\">\n<![CDATA[SYSDATE]]>\n</COLUMN>";
	    
	    private static final String PRODUCER_AGENT_CONTACTS_AUDIT_DATA = PRODUCER_AGENT_CONTACTS_USER_CREATED+"\n"+PRODUCER_AGENT_CONTACTS_DATE_CREATED+"\n"+PRODUCER_AGENT_CONTACTS_USER_MODIFIED+"\n"+PRODUCER_AGENT_CONTACTS_DATE_MODIFIED;
		
		private static final String COMMISSION_PLAN_ID_TAG="<COLUMN name=\"SCP_ID\" datatype=\"NUMBER\" remember=\"true\">\n<![CDATA[CUSTOM: SELECT S_SCP_ID_SEQ.NEXTVAL FROM DUAL]]>\n</COLUMN>";
	    private static final String COMMISSION_PLAN_FK="<COLUMN name=\"SCP_PRODUCER_ID\" datatype=\"NUMBER\" remember=\"true\">\n<![CDATA[CUSTOM: ${fk:SPR_PRODUCER_ID}]]>\n</COLUMN>";
	    private static final String COMMISSION_PLAN_USER_CREATED="<COLUMN name=\"SCP_USER_CREATED\" datatype=\"VARCHAR2\">\n<![CDATA[admin@majesco.com]]>\n</COLUMN>";
	    private static final String COMMISSION_PLAN_DATE_CREATED="<COLUMN name=\"SCP_DATE_CREATED\" datatype=\"DATE\">\n<![CDATA[SYSDATE]]>\n</COLUMN>";
	    private static final String COMMISSION_PLAN_USER_MODIFIED="<COLUMN name=\"SCP_USER_MODIFIED\" datatype=\"VARCHAR2\">\n<![CDATA[admin@majesco.com]]>\n</COLUMN>";
	    private static final String COMMISSION_PLAN_DATE_MODIFIED="<COLUMN name=\"SCP_PBI_DATE_MODIFIED\" datatype=\"DATE\">\n<![CDATA[SYSDATE]]>\n</COLUMN>";
	    private static final String COMMISSION_PLAN_AUDIT_DATA = COMMISSION_PLAN_USER_CREATED+"\n"+COMMISSION_PLAN_DATE_CREATED +"\n"+COMMISSION_PLAN_USER_MODIFIED+"\n"+COMMISSION_PLAN_DATE_MODIFIED;
	    
	    private static final String COMMISSION_PLAN_TIER_ID_TAG="<COLUMN name=\"SCT_ID\" datatype=\"NUMBER\" remember=\"true\">\n<![CDATA[CUSTOM: SELECT S_SCT_ID_SEQ.NEXTVAL FROM DUAL]]>\n</COLUMN>";
	    private static final String COMMISSION_PLAN_TIER_FK="<COLUMN name=\"SCT_PLAN_ID\" datatype=\"NUMBER\" remember=\"true\">\n<![CDATA[CUSTOM: ${fk:SCP_ID}]]>\n</COLUMN>";
	    private static final String COMMISSION_PLAN_TIER_USER_CREATED="<COLUMN name=\"SCT_USER_CREATED\" datatype=\"VARCHAR2\">\n<![CDATA[admin@majesco.com]]>\n</COLUMN>";
	    private static final String COMMISSION_PLAN_TIER_DATE_CREATED="<COLUMN name=\"SCT_DATE_CREATED\" datatype=\"DATE\">\n<![CDATA[SYSDATE]]>\n</COLUMN>";
	    private static final String COMMISSION_PLAN_TIER_USER_MODIFIED="<COLUMN name=\"SCT_USER_MODIFIED\" datatype=\"VARCHAR2\">\n<![CDATA[admin@majesco.com]]>\n</COLUMN>";
	    private static final String COMMISSION_PLAN_TIER_DATE_MODIFIED="<COLUMN name=\"SCT_PBI_DATE_MODIFIED\" datatype=\"DATE\">\n<![CDATA[SYSDATE]]>\n</COLUMN>";
	    private static final String COMMISSION_PLAN_TIER_AUDIT_DATA = COMMISSION_PLAN_TIER_USER_CREATED+"\n"+COMMISSION_PLAN_TIER_DATE_CREATED +"\n"+COMMISSION_PLAN_TIER_USER_MODIFIED+"\n"+COMMISSION_PLAN_TIER_DATE_MODIFIED;
		
		 private static final String PRODUCER_BILLING_INFO_ID_TAG="<COLUMN name=\"PBI_ID\" datatype=\"NUMBER\" remember=\"true\">\n<![CDATA[CUSTOM: SELECT S_PBI_BILLINFO_SEQ.NEXTVAL FROM DUAL]]>\n</COLUMN>";
	    private static final String PRODUCER_BILLING_INFO_FK="<COLUMN name=\"PBI_PRODUCER_ID\" datatype=\"NUMBER\" remember=\"true\">\n<![CDATA[CUSTOM: ${fk:SPR_PRODUCER_ID}]]>\n</COLUMN>";
	    
	    
	    private static final String PRODUCER_BILLING_INFO_USER_CREATED="<COLUMN name=\"PBI_USER_CREATED\" datatype=\"VARCHAR2\">\n<![CDATA[admin@majesco.com]]>\n</COLUMN>";
	    private static final String PRODUCER_BILLING_INFO_DATE_CREATED="<COLUMN name=\"PBI_DATE_CREATED\" datatype=\"DATE\">\n<![CDATA[SYSDATE]]>\n</COLUMN>";
	    private static final String PRODUCER_BILLING_INFO_USER_MODIFIED="<COLUMN name=\"PBI_USER_MODIFIED\" datatype=\"VARCHAR2\">\n<![CDATA[admin@majesco.com]]>\n</COLUMN>";
	    private static final String PRODUCER_BILLING_INFO_DATE_MODIFIED="<COLUMN name=\"PBI_DATE_MODIFIED\" datatype=\"DATE\">\n<![CDATA[SYSDATE]]>\n</COLUMN>";

	    private static final String PRODUCER_BILLING_INFO_AUDIT_DATA = PRODUCER_BILLING_INFO_USER_CREATED+"\n"+PRODUCER_BILLING_INFO_DATE_CREATED +"\n"+PRODUCER_BILLING_INFO_USER_MODIFIED+"\n"+PRODUCER_BILLING_INFO_DATE_MODIFIED;
	    
	    private static final String PRODUCER_ENOS_ID_TAG="<COLUMN name=\"SPN_ID\" datatype=\"NUMBER\" remember=\"true\">\n<![CDATA[CUSTOM: SELECT S_SPN_ID_SEQ.NEXTVAL FROM DUAL]]>\n</COLUMN>";
	    private static final String PRODUCER_ENOS_FK="<COLUMN name=\"SPN_PRODUCER_ID\" datatype=\"NUMBER\" remember=\"true\" uk1=\"true\">\n<![CDATA[CUSTOM: ${fk:SPR_PRODUCER_ID}]]>\n</COLUMN>";  
	    private static final String PRODUCER_ENOS_USER_CREATED ="<COLUMN name=\"SPN_USER_CREATED\" datatype=\"VARCHAR2\">\n<![CDATA[admin@majesco.com]]>\n</COLUMN>";
	    private static final String PRODUCER_ENOS_DATE_CREATED="<COLUMN name=\"SPN_DATE_CREATED\" datatype=\"DATE\">\n<![CDATA[SYSDATE]]>\n</COLUMN>";
	    private static final String PRODUCER_ENOS_USER_MODIFIED="<COLUMN name=\"SPN_USER_MODIFIED\" datatype=\"VARCHAR2\">\n<![CDATA[admin@majesco.com]]>\n</COLUMN>";
	    private static final String PRODUCER_ENOS_DATE_MODIFIED="<COLUMN name=\"SPN_DATE_MODIFIED\" datatype=\"DATE\">\n<![CDATA[SYSDATE]]>\n</COLUMN>";    
	    private static final String PRODUCER_ENOS_AUDIT_DATA =PRODUCER_ENOS_USER_CREATED+"\n"+PRODUCER_ENOS_DATE_CREATED+"\n"+PRODUCER_ENOS_USER_MODIFIED+"\n"+PRODUCER_ENOS_DATE_MODIFIED;
	    
	    private static final String PRODUCER_REPLACEMENTS_ID_TAG="<COLUMN name=\"SPE_REPLACEMENT_ID\" datatype=\"NUMBER\" remember=\"true\">\n<![CDATA[CUSTOM: SELECT S_SPE_REPLACEMENT_ID_SEQ.NEXTVAL FROM DUAL]]>\n</COLUMN>";
	    private static final String PRODUCER_REPLACEMENTS_FK="<COLUMN name=\"SPE_PRODUCER_ID\" datatype=\"NUMBER\" remember=\"true\" uk1=\"true\">\n<![CDATA[CUSTOM: ${fk:SPR_PRODUCER_ID}]]>\n</COLUMN>";  
	    private static final String PRODUCER_REPLACEMENTS_USER_CREATED ="<COLUMN name=\"SPE_USER_CREATED\" datatype=\"VARCHAR2\">\n<![CDATA[admin@majesco.com]]>\n</COLUMN>";
	    private static final String PRODUCER_REPLACEMENTS_DATE_CREATED="<COLUMN name=\"SPE_DATE_CREATED\" datatype=\"DATE\">\n<![CDATA[SYSDATE]]>\n</COLUMN>";
	    private static final String PRODUCER_REPLACEMENTS_USER_MODIFIED="<COLUMN name=\"SPE_USER_MODIFIED\" datatype=\"VARCHAR2\">\n<![CDATA[admin@majesco.com]]>\n</COLUMN>";
	    private static final String PRODUCER_REPLACEMENTS_DATE_MODIFIED="<COLUMN name=\"SPE_DATE_MODIFIED\" datatype=\"DATE\">\n<![CDATA[SYSDATE]]>\n</COLUMN>";    
	    private static final String PRODUCER_REPLACEMENTS_AUDIT_DATA =PRODUCER_REPLACEMENTS_USER_CREATED+"\n"+PRODUCER_REPLACEMENTS_DATE_CREATED+"\n"+PRODUCER_REPLACEMENTS_USER_MODIFIED+"\n"+PRODUCER_REPLACEMENTS_DATE_MODIFIED;
	    
	    private static final String PRODUCER_AGREEMENTS_ID_TAG="<COLUMN name=\"SPG_ID\" datatype=\"NUMBER\" remember=\"true\">\n<![CDATA[CUSTOM: SELECT S_SPG_ID_SEQ.NEXTVAL FROM DUAL]]>\n</COLUMN>";
	    private static final String PRODUCER_AGREEMENTS_FK="<COLUMN name=\"SPG_PRODUCER_ID\" datatype=\"NUMBER\" remember=\"true\" uk1=\"true\">\n<![CDATA[CUSTOM: ${fk:SPR_PRODUCER_ID}]]>\n</COLUMN>";  
	    private static final String PRODUCER_AGREEMENTS_USER_CREATED ="<COLUMN name=\"SPG_USER_CREATED\" datatype=\"VARCHAR2\">\n<![CDATA[admin@majesco.com]]>\n</COLUMN>";
	    private static final String PRODUCER_AGREEMENTS_DATE_CREATED="<COLUMN name=\"SPG_DATE_CREATED\" datatype=\"DATE\">\n<![CDATA[SYSDATE]]>\n</COLUMN>";
	    private static final String PRODUCER_AGREEMENTS_USER_MODIFIED="<COLUMN name=\"SPG_USER_MODIFIED\" datatype=\"VARCHAR2\">\n<![CDATA[admin@majesco.com]]>\n</COLUMN>";
	    private static final String PRODUCER_AGREEMENTS_DATE_MODIFIED="<COLUMN name=\"SPG_DATE_MODIFIED\" datatype=\"DATE\">\n<![CDATA[SYSDATE]]>\n</COLUMN>";    
	    private static final String PRODUCER_AGREEMENTS_AUDIT_DATA =PRODUCER_AGREEMENTS_USER_CREATED+"\n"+PRODUCER_AGREEMENTS_DATE_CREATED+"\n"+PRODUCER_AGREEMENTS_USER_MODIFIED+"\n"+PRODUCER_AGREEMENTS_DATE_MODIFIED;
	    
	    //Added for PI
	    private static final String PAPD_PRODUCER_ID="<COLUMN name=\"PAPD_PRODUCER_ID\" datatype=\"NUMBER\" remember=\"true\">\n<![CDATA[CUSTOM: ${fk:SPR_PRODUCER_ID}]]>\n</COLUMN>";
	    private static final String STATUS="<COLUMN name=\"STATUS\" datatype=\"VARCHAR2\">\n<![CDATA[Active]]>\n</COLUMN>";
	    private static final String MODIFIED_DATE="<COLUMN name=\"MODIFIED_DATE\" datatype=\"DATE\">\n<![CDATA[SYSDATE]]>\n</COLUMN>";
	    private static final String PRODUCER_PISHL_ADD_PRODUCER_DATA = PAPD_PRODUCER_ID+"\n"+STATUS+"\n"+MODIFIED_DATE;
	    
	   //End for PI
	    private boolean producerAuditDataExported = false;
	    private boolean producerAuthAuditDataExported = false;
	    private User user;
	    
	    public PIProducerXMLHandler(FileOutputStream fos, User user){
	        this.fos = fos;
	        this.user = user;
	      }
	    
	    public PIProducerXMLHandler(FileOutputStream fos){
	      this.fos = fos;
	    }

	    public String makeStartTag(String localName,Attributes attributes){
	        String startTag = "";
	        String attributeList = "";
	        int attributeCount = 0;

	        while(attributeCount<attributes.getLength()){
	            attributeList = attributeList +" "+attributes.getLocalName(attributeCount)+"=" +"\""+attributes.getValue(attributeCount)+"\"";
	            attributeCount++;
	        }

	        startTag = "<" + localName + attributeList + ">" ;

	        return startTag;
	    }

	    public String makeEndTag(String localName){
	        String endTag = "";

	        endTag = "</"+localName+">";

	        return endTag;
	    }

	    public void startElement(String uri, String localName, String qName,
	            Attributes attributes) throws SAXException {
	        try {
	            if(("PRODUCER").equalsIgnoreCase(localName)){
	                fos.write(("\n"+makeStartTag("PRODUCER",attributes)).getBytes());
	                fos.write(("\n"+PRODUCER_ID_TAG).getBytes());
	            }
	            else if(("PRODUCER_AUTHORITIES").equalsIgnoreCase(localName)){
	                if (!producerAuditDataExported) {
	                    fos.write(("\n"+PRODUCER_AUDIT_DATA).getBytes());
	                    producerAuditDataExported = true;
	                }
	                fos.write(("\n"+makeStartTag("PRODUCER_AUTHORITIES",attributes)).getBytes());
	            }
	        else if(("PRODUCER_AUTHORITY").equalsIgnoreCase(localName)){
	            fos.write(("\n"+makeStartTag("PRODUCER_AUTHORITY",attributes)).getBytes());
	            fos.write(("\n"+PRODUCER_AUTHORITY_ID_TAG).getBytes());
	            fos.write(("\n"+PRODUCER_FK).getBytes());
	        }
	        else if(("PROD_AUTHORITY_REPLACEMENTS").equalsIgnoreCase(localName)){
	            if (!producerAuthAuditDataExported){
	                fos.write(("\n"+PRODUCER_AUTHORITY_AUDIT_DATA).getBytes());
	                producerAuthAuditDataExported = true;
	            }
	            fos.write(("\n"+makeStartTag("PROD_AUTHORITY_REPLACEMENTS",attributes)).getBytes());
	        }
	        else if(("PROD_AUTHORITY_REPLACEMENT").equalsIgnoreCase(localName)){
	            fos.write(("\n"+makeStartTag("PROD_AUTHORITY_REPLACEMENT",attributes)).getBytes());
	            fos.write(("\n"+PRODUCER_AUTHORITY_REPLACEMENT_ID).getBytes());
	            fos.write(("\n"+PRODUCER_AUTHORITY_FK).getBytes());
	        }
	        else if(("PRODUCER_LICENSES").equalsIgnoreCase(localName)){
	            if (!producerAuditDataExported) {
	                fos.write(("\n"+PRODUCER_AUDIT_DATA).getBytes());
	                producerAuditDataExported = true;
	            }
	            fos.write(("\n"+makeStartTag("PRODUCER_LICENSES",attributes)).getBytes());
	        }
	        else if(("PRODUCER_LICENSE").equalsIgnoreCase(localName)){
	            fos.write(("\n"+makeStartTag("PRODUCER_LICENSE",attributes)).getBytes());
	            fos.write(("\n"+PRODUCER_LICENSE_ID_TAG).getBytes());
	            fos.write(("\n"+PRODUCER_LICENSE_FK).getBytes());
	        }
	        else if(("PRODUCER_ENOS").equalsIgnoreCase(localName)){
	            if (!producerAuditDataExported) {
	                fos.write(("\n"+PRODUCER_AUDIT_DATA).getBytes());
	                producerAuditDataExported = true;
	            }
	            fos.write(("\n"+makeStartTag("PRODUCER_ENOS",attributes)).getBytes());
	        }
	        else if(("PRODUCER_ENO").equalsIgnoreCase(localName)){
	            fos.write(("\n"+makeStartTag("PRODUCER_ENO",attributes)).getBytes());
	            fos.write(("\n"+PRODUCER_ENOS_ID_TAG).getBytes());
	            fos.write(("\n"+PRODUCER_ENOS_FK).getBytes());
	        }
	        else if(("PRODUCER_AGREEMENTS").equalsIgnoreCase(localName)){
	            if (!producerAuditDataExported) {
	                fos.write(("\n"+PRODUCER_AUDIT_DATA).getBytes());
	                producerAuditDataExported = true;
	            }
	            fos.write(("\n"+makeStartTag("PRODUCER_AGREEMENTS",attributes)).getBytes());
	        }
	        else if(("PRODUCER_AGREEMENT").equalsIgnoreCase(localName)){
	            fos.write(("\n"+makeStartTag("PRODUCER_AGREEMENT",attributes)).getBytes());
	            fos.write(("\n"+PRODUCER_AGREEMENTS_ID_TAG).getBytes());
	            fos.write(("\n"+PRODUCER_AGREEMENTS_FK).getBytes());
	        }
	        else if(("PRODUCER_REPLACEMENTS").equalsIgnoreCase(localName)){
	            if (!producerAuditDataExported) {
	                fos.write(("\n"+PRODUCER_AUDIT_DATA).getBytes());
	                producerAuditDataExported = true;
	            }
	            fos.write(("\n"+makeStartTag("PRODUCER_REPLACEMENTS",attributes)).getBytes());
	        }
	        else if(("PRODUCER_REPLACEMENT").equalsIgnoreCase(localName)){
	            fos.write(("\n"+makeStartTag("PRODUCER_REPLACEMENT",attributes)).getBytes());
	            fos.write(("\n"+PRODUCER_REPLACEMENTS_ID_TAG).getBytes());
	            fos.write(("\n"+PRODUCER_REPLACEMENTS_FK).getBytes());
	        }
	        else if("PRODUCER_ASSIGNMENTS".equalsIgnoreCase(localName)){
	            if (!producerAuditDataExported){
	                fos.write(("\n"+PRODUCER_AUDIT_DATA).getBytes());
	                producerAuditDataExported = true;
	            }
	            fos.write(("\n"+makeStartTag("PRODUCER_ASSIGNMENTS",attributes)).getBytes());
	        } else if("PRODUCER_ASSIGNMENT".equalsIgnoreCase(localName)){
	            fos.write(("\n"+makeStartTag("PRODUCER_ASSIGNMENT",attributes)).getBytes());
	            fos.write(("\n"+PRODUCER_ASSIGNMENTS_ID_TAG).getBytes());
	            fos.write(("\n"+PRODUCER_ASSIGNMENTS_FK).getBytes());
	        }
	        else if("PRODUCT_BILLING_INFOS".equalsIgnoreCase(localName)){
	            if (!producerAuditDataExported){
	                fos.write(("\n"+PRODUCER_AUDIT_DATA).getBytes());
	                producerAuditDataExported = true;
	            }
	            fos.write(("\n"+makeStartTag("PRODUCT_BILLING_INFOS",attributes)).getBytes());
	        } else if("PRODUCT_BILLING_INFO".equalsIgnoreCase(localName)){
	            fos.write(("\n"+makeStartTag("PRODUCT_BILLING_INFO",attributes)).getBytes());
	            fos.write(("\n"+PRODUCER_BILLING_ID_TAG).getBytes());
	            fos.write(("\n"+PRODUCER_BILLING_FK).getBytes());
	        }
	        else if("PRODUCER_AGENT_CONTACTS".equalsIgnoreCase(localName)){
	            if (!producerAuditDataExported){
	                fos.write(("\n"+PRODUCER_AUDIT_DATA).getBytes());
	                producerAuditDataExported = true;
	            }
	            fos.write(("\n"+makeStartTag("PRODUCER_AGENT_CONTACTS",attributes)).getBytes());
	        } else if("PRODUCER_AGENT_CONTACT".equalsIgnoreCase(localName)){
	            fos.write(("\n"+makeStartTag("PRODUCER_AGENT_CONTACT",attributes)).getBytes());
	            fos.write(("\n"+PRODUCER_AGENT_CONTACTS_ID_TAG).getBytes());
	            fos.write(("\n"+PRODUCER_AGENT_CONTACTS_FK).getBytes());
	        } else if(("PRODUCER_BILLING_INFOS").equalsIgnoreCase(localName)){
	            if (!producerAuditDataExported) {
	                fos.write(("\n"+PRODUCER_AUDIT_DATA).getBytes());
	                producerAuditDataExported = true;
	            }
	            fos.write(("\n"+makeStartTag("PRODUCER_BILLING_INFOS",attributes)).getBytes());
	        }
	        else if(("PRODUCER_BILLING_INFO").equalsIgnoreCase(localName)){
	            fos.write(("\n"+makeStartTag("PRODUCER_BILLING_INFO",attributes)).getBytes());
	            fos.write(("\n"+PRODUCER_BILLING_INFO_ID_TAG).getBytes());
	            fos.write(("\n"+PRODUCER_BILLING_INFO_FK).getBytes());
	        }
	        else if(("COMMISSION_PLAN").equalsIgnoreCase(localName)){
	            fos.write(("\n"+makeStartTag("COMMISSION_PLAN",attributes)).getBytes());
	            fos.write(("\n"+COMMISSION_PLAN_ID_TAG).getBytes());
	            fos.write(("\n"+COMMISSION_PLAN_FK).getBytes());
	        }
	        else if(("COMMISSION_PLAN_TIER").equalsIgnoreCase(localName)){
	            fos.write(("\n"+makeStartTag("COMMISSION_PLAN_TIER",attributes)).getBytes());
	            fos.write(("\n"+COMMISSION_PLAN_TIER_ID_TAG).getBytes());
	            fos.write(("\n"+COMMISSION_PLAN_TIER_FK).getBytes());
	        }
	            //Added for PI
	        else if(("PISHL_ADD_PRODUCER_DATA").equalsIgnoreCase(localName)){
	            fos.write(("\n"+makeStartTag("PISHL_ADD_PRODUCER_DATA",attributes)).getBytes());
	            
	        } //End for PI
	        else{
	                if("COLUMN".equalsIgnoreCase(localName)){
	                   if("SPR_PRODUCER_CODE".equalsIgnoreCase(attributes.getValue("name"))){
	                       sprProducerCodeFlag = true;
	                   }
	                   if("SPR_POSTAL_CODE".equalsIgnoreCase(attributes.getValue("name"))){
	                       sprPostalCodeFlag = true;
	                   }
	                   if("SPR_TELEPHONE".equalsIgnoreCase(attributes.getValue("name"))){
	                       sprTelephoneFlag = true;
	                   }
	                   if("SPR_FAX".equalsIgnoreCase(attributes.getValue("name"))){
	                	   sprFaxFlag = true;
	                   }
	                   if("SCO_PHONE_1".equalsIgnoreCase(attributes.getValue("name"))){
	                	   scoPhone1Flag = true;
	                   }
	                   if("SCO_PHONE_2".equalsIgnoreCase(attributes.getValue("name"))){
	                	   scoPhone2Flag = true;
	                   }
	                   if("SCO_FAX".equalsIgnoreCase(attributes.getValue("name"))){
	                	   scoFaxFlag = true;
	                   }
	                }
	               fos.write(("\n"+makeStartTag(localName,attributes)).getBytes());
	        }
	        } catch (Exception e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();

	            LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
	                    getClass().getName(), "startElement",
	                    ServletConfigUtil.COMPONENT_RI,null,
	                    "Failed to start XML tag.", null,
	                    LogMinderDOMUtil.VALUE_NONE);

	                throw new SAXException("Failed to start XML tag.",
	                    null);

	        }

	    }

	    public void endElement(String uri, String localName,
	            String qName) throws SAXException {
	        try{
	          if(("PRODUCER").equalsIgnoreCase(localName)){
	              if(!producerAuditDataExported){
	                  fos.write(("\n"+PRODUCER_AUDIT_DATA).getBytes());
	              }
	              fos.write(("\n"+makeEndTag(localName)).getBytes());
	              producerAuditDataExported = false;
	          }
	          else if(("PRODUCER_AUTHORITY").equalsIgnoreCase(localName)){
	              if(!producerAuthAuditDataExported){
	                  fos.write(("\n"+PRODUCER_AUTHORITY_AUDIT_DATA).getBytes());
	              }
	              fos.write(("\n"+makeEndTag(localName)).getBytes());
	              producerAuthAuditDataExported = false;
	          }
	          else if(("PROD_AUTHORITY_REPLACEMENT").equalsIgnoreCase(localName)){
	              fos.write(("\n"+PRODUCER_REPLACEMENT_AUDIT_DATA).getBytes());
	              fos.write(("\n"+makeEndTag(localName)).getBytes());
	          }
	          else if(("PRODUCER_LICENSE").equalsIgnoreCase(localName)){
	              fos.write(("\n"+PRODUCER_LICENSE_AUDIT_DATA).getBytes());
	              fos.write(("\n"+makeEndTag(localName)).getBytes());
	          }else if(("PRODUCER_ENO").equalsIgnoreCase(localName)){
	              fos.write(("\n"+PRODUCER_ENOS_AUDIT_DATA).getBytes());
	              fos.write(("\n"+makeEndTag(localName)).getBytes());
	          }else if(("PRODUCER_REPLACEMENT").equalsIgnoreCase(localName)){
	              fos.write(("\n"+PRODUCER_REPLACEMENTS_AUDIT_DATA).getBytes());
	              fos.write(("\n"+makeEndTag(localName)).getBytes());
	          }else if(("PRODUCER_AGREEMENT").equalsIgnoreCase(localName)){
	              fos.write(("\n"+PRODUCER_AGREEMENTS_AUDIT_DATA).getBytes());
	              fos.write(("\n"+makeEndTag(localName)).getBytes());
	          } else if(("PRODUCER_ASSIGNMENT").equalsIgnoreCase(localName)){
	              fos.write(("\n"+PRODUCER_ASSIGNMENTS_AUDIT_DATA).getBytes());
	              fos.write(("\n"+makeEndTag(localName)).getBytes());
	              producerAuthAuditDataExported = false;
	          } else if(("PRODUCT_BILLING_INFO").equalsIgnoreCase(localName)){
	              fos.write(("\n"+PRODUCER_BILLING_AUDIT_DATA).getBytes());
	              fos.write(("\n"+makeEndTag(localName)).getBytes());
	              producerAuthAuditDataExported = false;
	          } else if(("PRODUCER_AGENT_CONTACT").equalsIgnoreCase(localName)){
	              fos.write(("\n"+PRODUCER_AGENT_CONTACTS_AUDIT_DATA).getBytes());
	              fos.write(("\n"+makeEndTag(localName)).getBytes());
	              producerAuthAuditDataExported = false;
	          }else if(("PRODUCER_BILLING_INFO").equalsIgnoreCase(localName)){
	              fos.write(("\n"+PRODUCER_BILLING_INFO_AUDIT_DATA).getBytes());
	              fos.write(("\n"+makeEndTag(localName)).getBytes());
	          }
	          else if(("COMMISSION_PLAN").equalsIgnoreCase(localName)){
	              fos.write(("\n"+COMMISSION_PLAN_AUDIT_DATA).getBytes());
	              fos.write(("\n"+makeEndTag(localName)).getBytes());
	          }
	          else if(("COMMISSION_PLAN_TIER").equalsIgnoreCase(localName)){
	              fos.write(("\n"+COMMISSION_PLAN_TIER_AUDIT_DATA).getBytes());
	              fos.write(("\n"+makeEndTag(localName)).getBytes());
	          }
	        //Added for PI
	          else if(("PISHL_ADD_PRODUCER_DATA").equalsIgnoreCase(localName)){
	              fos.write(("\n"+PRODUCER_PISHL_ADD_PRODUCER_DATA).getBytes());
	              fos.write(("\n"+makeEndTag(localName)).getBytes());
	          }
	        //End for PI
	          
	          
	          else{
	              fos.write(("\n"+makeEndTag(localName)).getBytes());
	          }
	        }catch(Exception e){
	            e.printStackTrace();

	            LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
	                    getClass().getName(), "endElement",
	                    ServletConfigUtil.COMPONENT_RI,null,
	                    "Failed to close XML tag.", null,
	                    LogMinderDOMUtil.VALUE_NONE);

	                throw new SAXException("Failed to close XML tag.",
	                    null);
	        }
	    }

	    public void comment(char[] arg0, int arg1, int arg2) throws SAXException {
	        // TODO Auto-generated method stub

	    }

	    public static boolean isNumber(String str) {

	        //It can't contain only numbers if it's null or empty...
	        if (str == null || str.length() == 0)
	            return false;

	        for (int i = 0; i < str.length(); i++) {

	            //If we find a non-digit character we return false.
	            if (!Character.isDigit(str.charAt(i)))
	                return false;
	        }

	        return true;
	    }

	    public static String lpadCode(String code, int padLength, String pad){
	        // LPAD Code if it is a number
	        if(isNumber(code)){
	            if(code.length()<padLength){
	                StringBuffer paddedCode = new StringBuffer();
	                int requiredPadding = padLength - code.length();

	                for(int i=0;i<requiredPadding;i++){
	                    paddedCode.append(pad);
	                }
	                paddedCode.append(code);
	                code = paddedCode.toString();
	            }
	        }
	        else{
	            code = code.toUpperCase();
	        }
	        return code;
	    }

	    public static String formatZipCode(String zipCode){
	        String formattedZip = null;
	        if(isNumber(zipCode)){
	            if(zipCode.length() > 5){
	               if(zipCode.length()<10){
	                   formattedZip = zipCode.substring(0, 5)+"-"+lpadCode(zipCode.substring(5,zipCode.length()),4,"0");
	               }
	               else{
	                   formattedZip = zipCode.substring(0, 5)+"-"+zipCode.substring(5,9);
	               }
	            }
	            else{
	                formattedZip = zipCode;
	            }
	        }
	        else{
	            formattedZip = zipCode;
	        }
	        return formattedZip;
	    }

	    public static String formatPhoneNumber(String phoneNumber){
	        String formattedNumber = null;

	        if(phoneNumber.length() == 10){
	            formattedNumber = "(" + phoneNumber.substring(0, 3) + ")" + " "+phoneNumber.substring(3, 6) + "-"+phoneNumber.substring(6, 10);
	        }
	        else{
	            formattedNumber = phoneNumber;
	        }

	        return formattedNumber;
	    }

	    public void characters(char[] ch, int start,int length) throws SAXException {
	        try {
	            if (readingCDATASection) {
	                CDATAString += new String(ch, start, length);
	            }
	        } catch (Exception e) {
	             throw new SAXException(e);
	        }
	    }

	    /**
	     * Callback method called when the start of a CDATA section is encountered.
	     * Sets the flag that denotes that a CDATA section is being read as true.
	     */
	    public void startCDATA() {
	        readingCDATASection = true;
	    }

	    /**
	     * Callback method called when the end of a CDATA section is encountered.
	     * Sets the flag that denotes that a CDATA section is being read as false.
	     * Concatenates all the data read in the CDATA section, in the member variable CDATAString.
	     */
	    public void endCDATA() {
	        try{
	            readingCDATASection = false;
	            if(sprProducerCodeFlag == true){
	            	if(user!=null)	{
	                	isProducerCodeUnFormated = CustomerConfigUtil.getInstance().getCustomerProperty(
	    				user.getDomain(), ServletConfigUtil.COMPONENT_PORTAL,
	    				CustomerConfigUtil.UN_FORMATTED_PRODUCER_CODE);
	            	}
	            	if("Y".equalsIgnoreCase(isProducerCodeUnFormated)){
		                //CDATAString = lpadCode(CDATAString,10,"0");
		                sprProducerCodeFlag = false;
	            	}
	            	else{
	            		CDATAString = lpadCode(CDATAString,10,"0");
		                sprProducerCodeFlag = false;
	                }
	            }
	            if(sprPostalCodeFlag == true){
	                CDATAString = formatZipCode(CDATAString);
	                sprPostalCodeFlag = false;
	            }
	            if(sprTelephoneFlag == true){
	                CDATAString = formatPhoneNumber(CDATAString);
	                sprTelephoneFlag = false;
	            }
	            if(sprFaxFlag == true){
	                CDATAString = formatPhoneNumber(CDATAString);
	                sprFaxFlag = false;
	            }
	            if(scoPhone1Flag == true){
	                CDATAString = formatPhoneNumber(CDATAString);
	                scoPhone1Flag = false;
	            }
	            if(scoPhone2Flag == true){
	                CDATAString = formatPhoneNumber(CDATAString);
	                scoPhone2Flag = false;
	            }
	            if(scoFaxFlag == true){
	                CDATAString = formatPhoneNumber(CDATAString);
	                scoFaxFlag = false;
	            }
	            CDATAString = "<![CDATA[" + CDATAString + "]]>";
	            fos.write(("\n"+CDATAString).getBytes());
	            CDATAString = "";
	        }catch(Exception e){
	            e.printStackTrace();
	        }
	    }

	     public void endDTD() throws SAXException {
	        // TODO Auto-generated method stub

	    }


	    public void endEntity(String arg0) throws SAXException {
	        // TODO Auto-generated method stub

	    }





	    public void startDTD(String arg0, String arg1, String arg2)
	            throws SAXException {
	        // TODO Auto-generated method stub

	    }


	    public void startEntity(String arg0) throws SAXException {
	        // TODO Auto-generated method stub

	    }

}
