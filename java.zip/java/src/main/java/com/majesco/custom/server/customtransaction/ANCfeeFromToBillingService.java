package com.majesco.custom.server.customtransaction;

import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;

import org.w3c.dom.Document;

import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;
import com.coverall.mt.services.SchedulableService;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServicesDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;

import oracle.jdbc.OracleTypes;

public class ANCfeeFromToBillingService extends SchedulableService {

	private static final long serialVersionUID = 1L;
	private static final String billingANCsql = "SELECT BANC.ANC_FLAG, BANC.LEGAL_STATUS, BANC.SYSTEM_STATUS, VMQP.ENTITY_REFERENCE FROM "
			+ "BILLING_CONTENT.OUTBOUND_ANC_FEE_REVERSAL BANC,vw_mis_quote_policies VMQP "
			+ "WHERE BANC.POLICY_NO=VMQP.display_policy_number AND VMQP.ENTITY_REFERENCE=";
	private static final String QUERY_TO_INSERT_IN_POL_REQ = "{ ? = call K_Policy_Transaction.f_insert_policy_trans_req (?,?,?,?,?,?,?,?,?,?,?,?)}";
	private static final String QUERY_TO_INSERT_IN_REQ_PARAM = "{ ? = call K_Policy_Transaction.f_insert_policy_trans_req_params (?,?,?,?,?)}";
	Long requestId = null;
	
	// Retrieving details from the Params map
	HashMap params = new HashMap();
	String entityType = params.get("WEA_ENTITY_TYPE").toString();
	String entityRef = params.get("WEA_ENTITY_REFERENCE").toString();
	
	User user1 = (User) params.get("User");
	
	public ANCfeeFromToBillingService() throws RemoteException {
		super();
	}

	@Override
	public String getComponentName() {
		return ServletConfigUtil.COMPONENT_RI;
	}
	
	public Document getANCfeeFromToBilling(Document request, String logName) throws Throwable {
		logMessage(LogEntry.SEVERITY_FATAL, "EntityType : " + entityType + " EntityRef : " + entityRef + " User1 : " + user1.getUserId()+":"+user1.getPassword(), "");
		logMessage(LogEntry.SEVERITY_FATAL, "ANCfeeFromToBillingService - getANCfeeFromToBilling" + request, "");
		final String entityReference = (String) params.get("_entityReference");
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		User user = ServicesDOMUtil.getUser(request);
		
		try {
			logMessage(LogEntry.SEVERITY_FATAL, "ANCfeeFromToBillingService - entityReference: " + entityReference, "");
			connection = ConnectionPool.getConnection(user);
			statement = connection.prepareStatement(billingANCsql+"'"+entityReference+"'");
			rs = statement.executeQuery(); 
			while(rs.next()) {
				logMessage(LogEntry.SEVERITY_FATAL, "ANCfeeFromToBillingService - entityReference fro vm_quote_policies : " + rs.getString("ENTITY_REFERENCE"), "");
				if(rs.getString("ANC_FLAG").equalsIgnoreCase("PAID") && rs.getString("LEGAL_STATUS").equalsIgnoreCase("ISSUED")){
					// ANC Endorsement Service will pick the 2 records from the below tables 
					insertPolicyReq(connection, entityReference, user);
					insertRequestParams(connection, user);
				}else {
					logMessage(LogEntry.SEVERITY_FATAL, "ANCfeeFromToBillingService - getANCfeeFromToBilling : No records found", "");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				DBUtil.close(rs, statement, connection);
			} catch(Exception ex) {}
		}
		return request;
	}
	
	private void insertPolicyReq(Connection conn, String entityReference, User user) {

		logMessage(LogEntry.SEVERITY_FATAL, "ANCfeeFromToBillingService - entityReference: " + entityReference, "");
		String errorMsg = null;
		
	try {
		CallableStatement call = conn.prepareCall(QUERY_TO_INSERT_IN_POL_REQ);
		call.registerOutParameter(1, OracleTypes.INTEGER);
		call.setString(2, "ANC Premium");
		call.setString(3, entityReference);
		call.setString(4, "READY");
		call.setString(5, "CQT");
		call.setString(6, "WK");
		call.setString(7, "");
		call.setString(8, null);
		call.setLong(9, 0);
		call.setString(10, "ANC premium");
		call.setString(11, user.getUserId());
		call.registerOutParameter(12, OracleTypes.NUMBER);
		call.registerOutParameter(13, OracleTypes.VARCHAR);
		logMessage(LogEntry.SEVERITY_FATAL, "ANCfeeFromToBillingService insertCancellationRequest() - Before calling", "");
		call.execute();
		logMessage(LogEntry.SEVERITY_FATAL, "ANCfeeFromToBillingService insertCancellationRequest() - After calling", "");
		errorMsg = (String) call.getObject(13);
		Integer result = (Integer)call.getObject (1);
            
        if (result != 0 ) {
        	logMessage(LogEntry.SEVERITY_FATAL, "ANCfeeFromToBillingService Error while inserting Cancellation Request :" + errorMsg, "");
        } else {
        	logMessage(LogEntry.SEVERITY_FATAL, "ANCfeeFromToBillingService Insert Record for Cancellation Request is Success for : " + entityReference, "");
        	requestId = (Long) call.getObject(12);
        	logMessage(LogEntry.SEVERITY_FATAL, "ANCfeeFromToBillingService Cancellation Request Id : "+ requestId, "");
        }
		
	} catch (Exception e) {
		logMessage(LogEntry.SEVERITY_FATAL, "ANCfeeFromToBillingService Error occured while inserting Cancellation Request :" + e.getMessage(), "");
	} 
  }

	private void insertRequestParams(Connection conn, User user) {
		
		try {
			String errorMsg = null;
			logMessage(LogEntry.SEVERITY_FATAL, "ANCfeeFromToBillingService insertRequestParams()", "");
			CallableStatement call = conn.prepareCall(QUERY_TO_INSERT_IN_REQ_PARAM);
			call.registerOutParameter(1, OracleTypes.INTEGER);
			call.setLong(2, requestId);
			call.setString(3, "ANC Premium");
			call.setString(4, "ANC Premium");
			call.setString(5, user.getUserId());
			call.registerOutParameter(6, OracleTypes.VARCHAR);
			logMessage(LogEntry.SEVERITY_FATAL, "ANCfeeFromToBillingService insertRequestParams() - Before calling", "");
			call.execute();
			logMessage(LogEntry.SEVERITY_FATAL, "ANCfeeFromToBillingService insertRequestParams() - After calling", "");
			errorMsg = (String) call.getObject(6);
			Integer result = (Integer)call.getObject (1);
            if (result != 0 ) {
            	logMessage(LogEntry.SEVERITY_FATAL, "ANCfeeFromToBillingService Error while inserting Cancellation Request Params :" + errorMsg, "");
            } else {
            	logMessage(LogEntry.SEVERITY_FATAL, "ANCfeeFromToBillingService Cancellation Request Params inserted successfully", "");
            }
			
		} catch (Exception e) {
			logMessage(LogEntry.SEVERITY_FATAL, "ANCfeeFromToBillingService Error occured while inserting Cancellation Request Params :" + e.getMessage(), "");
		} 
	}
	
	private void logMessage(int logLevel, String inputMsg, String objMsg) {
		LogMinder.getLogMinder().log(logLevel, ANCfeeFromToBillingService.class.getName(),
				"ANC Premium receivable", ServletConfigUtil.COMPONENT_PORTAL, new Object[] { objMsg },
		inputMsg, null, LogMinderDOMUtil.VALUE_SCHEDULAR);
	}
	
}
