package com.majesco.custom.server.customtransaction;

import java.sql.Connection;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.map.ObjectMapper;

import com.coverall.mt.events.EventProcessor;
import com.coverall.mt.framework.transactions.processor.AbstractTransactionProcesssor;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.majesco.custom.pi.bulkupdate.constants.BulkUpdateConstants;
import com.majesco.custom.pi.bulkupdate.model.PolicyBaseResponse;
import com.majesco.custom.pi.bulkupdate.model.PolicyErrorResponse;
import com.majesco.custom.pi.bulkupdate.model.PolicyTransactionResponse;

public class AUDITNONCOMPFEETransInfo extends AbstractTransactionProcesssor {

	// at the end of Start New Transaction URL policyEntityRef should be appended
	private static final String START_NEW_TRANSACTION_URL = "/startNewTransaction?productCode=WK&entityType=POLICY&transactionName=AuditNonCompliance&optimizedFlow=Y&transactionID=";
	// DefaultHttpClient client = new DefaultHttpClient();
	String transactionId = null;
	String clientId = null;
	
	public AUDITNONCOMPFEETransInfo() {
		// logMessage(LogEntry.SEVERITY_FATAL,"Message - AUDITNONCOMPFEETransInfo
		// constructor -- JIRA 2097" + new Object(), "");
	}

	@Override
	public void preProcess(Map params, Connection conn, User user, HttpSession currentSession,
			HttpServletRequest request, HttpServletResponse response) throws Throwable {
		logMessage(LogEntry.SEVERITY_FATAL, "Message - AUDITNONCOMPFEETransInfo preProcess" + new Object(), "");
	}

	@Override
	public void process(Map params, Connection conn, User user, HttpSession currentSession, HttpServletRequest request,
			HttpServletResponse response) {
		logMessage(LogEntry.SEVERITY_FATAL, "Message - AUDITNONCOMPFEETransInfo process" + new Object(), "");

		try {
			Map<String, String> wsParams = getWSParameters(user);
			String baseUrl = (String) wsParams.get(BulkUpdateConstants.POLICY_BASE_API_URL);
			final String entityReference = (String) params.get("_entityReference");
			logMessage(LogEntry.SEVERITY_FATAL, "Info-ANCFee-Policy Update API Base URL : " + baseUrl, "");
			String userName = (String) wsParams.get(BulkUpdateConstants.QUOTE_POLICY_API_USER_ID);
			String password = (String) wsParams.get(BulkUpdateConstants.QUOTE_POLICY_API_USER_PASSWORD);
			performStartNewTransaction(entityReference, baseUrl, userName, password, user);
			performCompleteTransaction(baseUrl, userName, password, user);
		} catch (Exception e) {
			logMessage(LogEntry.SEVERITY_FATAL,
					"Message - AUDITNONCOMPFEETransInfo- Exception in Process : " + new Object(), "");
			e.printStackTrace();
		}
	}

	@Override
	public void postProcess(Map params, Connection conn, User user, HttpSession currentSession,
			HttpServletRequest request, HttpServletResponse response) {
		logMessage(LogEntry.SEVERITY_FATAL, "Message - AUDITNONCOMPFEETransInfo postProcess" + new Object(), "");
	}

	@Override
	public boolean shouldRefresh() {
		logMessage(LogEntry.SEVERITY_FATAL, "Message - AUDITNONCOMPFEETransInfo shouldRefresh" + new Object(), "");
		return true;
	}

	@SuppressWarnings("unchecked")
	private Map<String, String> getWSParameters(User user) throws Exception {
		Map<String, String> webserviceParams = EventProcessor
				.getWebServiceParameters(BulkUpdateConstants.BULK_UNDERWRITER_WEBSERVICE_NAME, user);
		if (webserviceParams == null) {
			logMessage(LogEntry.SEVERITY_FATAL, "Info-AuditNonCompFee-WS Params Map is null", "");
			return null;
		}
		return webserviceParams;
	}


	private void performStartNewTransaction(String entityReference, String baseUrl, String userName, String password, User user) {
		try {
			HttpGet getMethod = null;
			String serviceUrl = baseUrl + START_NEW_TRANSACTION_URL + entityReference;
			logMessage(LogEntry.SEVERITY_FATAL, "AuditNonCompFee-New Transaction URL serviceUrl : " + serviceUrl, "");
			getMethod = new HttpGet(serviceUrl);
			String authString = java.util.Base64.getEncoder().encodeToString((userName + ":" + password).getBytes());
			getMethod.setHeader("Authorization", "Basic " + authString);
			// HttpResponse response = this.client.execute(getMethod);
			HttpResponse response = new DefaultHttpClient().execute(getMethod);
			logMessage(LogEntry.SEVERITY_FATAL,"Info-AuditNonCompFee - Strt New Transaction response: " + response.getStatusLine().getStatusCode(),"");
			if (response.getStatusLine().getStatusCode() == 200) {
				PolicyBaseResponse transResponse = getPolicyTransactionResponse(response);
				if(transResponse instanceof PolicyErrorResponse) {
					PolicyErrorResponse errorResponse = (PolicyErrorResponse) transResponse;
					logMessage(LogEntry.SEVERITY_FATAL, "AuditNonCompFee-Strt New Transaction ErrorResponse : " + errorResponse.getErrors().get(0).getMessage(),""); 
				} else {
					PolicyTransactionResponse newTransRes = (PolicyTransactionResponse) transResponse;
					transactionId = newTransRes.getTransactionID();
					clientId = newTransRes.getClientID();
					logMessage(LogEntry.SEVERITY_FATAL, "AuditNonCompFee - Strt New Transaction PolicySuccessResponse : ClientId-" + clientId+" : TransactionId-"+transactionId,"");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logMessage(LogEntry.SEVERITY_FATAL, "Error in AuditNonComplianceFee : Start New Transaction stacktrace: "
					+ org.apache.commons.lang.exception.ExceptionUtils.getStackTrace(e), "");
			logMessage(LogEntry.SEVERITY_FATAL,
					"Error in AuditNonComplianceFee : Start New Transaction : " + e.getMessage(), "");
		}
	}

	private void performCompleteTransaction(String baseUrl, String userName, String password, User user) {
		try {
			HttpGet getMethod = null;
			String serviceUrl = null;
			serviceUrl = baseUrl + AuditNonCompConstants.COMPLETE_TRANSACTION_URL;
			logMessage(LogEntry.SEVERITY_FATAL, "Info-AuditNoncomFee-Complete Transaction URL: " + serviceUrl, "");
			getMethod = new HttpGet(serviceUrl);
			setHeaderParamsInHttpGet(getMethod, userName, password);
			// HttpResponse response = this.client.execute(getMethod); 
			HttpResponse response = new DefaultHttpClient().execute(getMethod);
			String successRes = EntityUtils.toString(response.getEntity());
			logMessage(LogEntry.SEVERITY_FATAL,	"AuditNonCompFee-complete response :" + successRes, "");
			logMessage(LogEntry.SEVERITY_FATAL, "AuditNonCompFee-complete Transaction response code: "
					+ response.getStatusLine().getStatusCode(), "");
		} catch (Exception e) {
			logMessage(LogEntry.SEVERITY_FATAL, "Error in AuditNonCompFee : Complete Transaction : " + e.getMessage(),
					"");
		}
	}

	private void setHeaderParamsInHttpGet(HttpGet getMethod, String userName, String password) {
		getMethod.setHeader(AuditNonCompConstants.TRANSACTION_ID, transactionId);
		getMethod.setHeader(AuditNonCompConstants.CLIENT_ID, clientId);
		String authString = java.util.Base64.getEncoder().encodeToString((userName + ":" + password).getBytes());
		getMethod.setHeader("Authorization", "Basic " + authString);
	}

	private void logMessage(int logLevel, String inputMsg, String objMsg) {
		LogMinder.getLogMinder().log(logLevel, AUDITNONCOMPFEETransInfo.class.getName(),
				AuditNonCompConstants.FUNCTION_NAME, ServletConfigUtil.COMPONENT_PORTAL, new Object[] { objMsg },
				inputMsg, null, LogMinderDOMUtil.VALUE_MIC);
	}
	private PolicyBaseResponse getPolicyTransactionResponse(HttpResponse response) throws Exception {
		PolicyTransactionResponse newTransResponse = new PolicyTransactionResponse();
		PolicyErrorResponse errorResponse = new PolicyErrorResponse();
		String successRes = EntityUtils.toString(response.getEntity());
		logMessage(LogEntry.SEVERITY_FATAL,	"Content of Success Response From Policy Start New Transaction Api :" + successRes, "");
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(org.codehaus.jackson.map.DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		if (successRes.contains("transactionID") && successRes.contains("clientID")) {
			newTransResponse = mapper.readValue(successRes, PolicyTransactionResponse.class);
			return newTransResponse;
		} else {
			errorResponse = mapper.readValue(successRes, PolicyErrorResponse.class);
			return errorResponse;
		}
	}
}
