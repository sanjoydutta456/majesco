package com.majesco.custom.server.customtransaction;

public class AuditNonCompConstants {
	
	public static final String AUDIT_NON_COMP_FEE_WEBSERVICE_NAME = "MIC - INTERNAL - WS - AUDITNONCOMPFEE PROCESSING";
	// at the end of Update URL append {policyId} - will be returned as GID from Start New Transaction API
	public static final String VALIDATE_TRANSACTION_URL = "/validateTransaction";
	public static final String COMPLETE_TRANSACTION_URL = "/completeTransaction";
	
	// header params
	public static final String TRANSACTION_ID = "transactionID";
	public static final String CLIENT_ID = "clientID";
	public static final String TRANS_EFFECTIVE_DATE = "transEffectiveDate";
	
	// Process flow steps
	public static final String STATUS_STEP_1 = "startNewTransaction";
	public static final String STATUS_STEP_2 = "completeTransaction";
	
	public static final String STATUS_SUCCESS = "Success";
	public static final String STATUS_ERROR = "Error";
	public static final String ENDORSEMENT_REASON = "Audit Non Compliance Fee";
	public static final String FUNCTION_NAME = "AUDITNONCOMPFEETransInfo";
}
