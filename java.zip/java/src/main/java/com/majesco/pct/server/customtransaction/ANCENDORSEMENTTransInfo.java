package com.majesco.pct.server.customtransaction;

import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.pctv2.server.transactions.EndorsePolicyTransInfo;
import com.majesco.custom.server.customtransaction.AUDITNONCOMPFEETransInfo;
import com.majesco.custom.server.customtransaction.AuditNonCompConstants;

public class ANCENDORSEMENTTransInfo extends EndorsePolicyTransInfo {

	private static final long serialVersionUID = 1L;
	
	public ANCENDORSEMENTTransInfo(){
		
		logMessage(LogEntry.SEVERITY_FATAL,"Message - ANCENDORSEMENTTransInfo constructor " + new Object(), ""); 
	}
	
	private void logMessage(int logLevel, String inputMsg, String objMsg) {
		LogMinder.getLogMinder().log(logLevel, AUDITNONCOMPFEETransInfo.class.getName(), AuditNonCompConstants.FUNCTION_NAME,
				ServletConfigUtil.COMPONENT_PORTAL, new Object[]{objMsg}, inputMsg, null, LogMinderDOMUtil.VALUE_SCHEDULAR);
	}
}
