package com.majesco.pct.server.customtransaction;

import com.coverall.pctv2.server.transactions.EndorsePolicyTransInfo;

public class AUDITNONCOMPTransInfo extends EndorsePolicyTransInfo {
	/**
	* 
	*/
	private static final long serialVersionUID = 1L;

}
