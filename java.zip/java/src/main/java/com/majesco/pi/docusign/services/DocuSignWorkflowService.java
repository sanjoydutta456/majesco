package com.majesco.pi.docusign.services;

import java.util.ArrayList;

import com.coverall.exceptions.InvalidServiceException;
import com.coverall.exceptions.ServiceException;
import com.coverall.licensing.util.LicenseManager;
import com.coverall.mt.http.User;
import com.coverall.mt.services.ILocalService;
import com.coverall.mt.services.WorkFlowService;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;

public class DocuSignWorkflowService extends WorkFlowService {
    private static final DocuSignWorkflowService INSTANCE = 
        new DocuSignWorkflowService();
    private boolean preReqSatisfied = false;
	
    private DocuSignWorkflowService() {
    }

    /**
     * Get the display name for the task
     * @return display name.
     */
    public String getName() {
        return "DocuSign Milestone";
    }

    /**
     * Get the milestone task this service works on
     * @return the milestone task this service works on.
     */
    public String getStartTask() {
        return "DOCUSIGN";
    }

    /**
     * Get the number of maximum transactions that can be processed by the service at a time.
     * @return maximum number of concurrent transactions
     */
    public long getMaxCuncurrentTransactions() {
        return 10;
    }

    /**
     *  Process a transaction in a given thread with given parameters.
     * @throws ServiceException 
     */    
public void processTransaction(Transaction transaction) throws ServiceException{
        
	
		//TODO Remove this logger
        LogMinder.getLogMinder().log(
                LogEntry.SEVERITY_FATAL,
                getClass().getName(),
                "DocuSign workflow service executed",
                ServletConfigUtil.COMPONENT_PORTAL,
                null,
                "DocuSign workflow service executed",
                null,
                LogMinderDOMUtil.VALUE_MIC);
        
        //TODO Start coding here
        


    	transaction.status = STATUS_COMPLETED;
    }

	/**
     * Check to see if this service can run on this machine.
     */
    public void checkPreRequisite(User user) throws InvalidServiceException {
        if (!preReqSatisfied) {
            try {
                if (isThisASMachine()) {
                    throw new InvalidServiceException(
                            "This task cannot be started on 'Application Server' machine",
                            null);
                }
                CustomerConfigUtil customerConfigUtil = CustomerConfigUtil.getInstance();
                LicenseManager licenseManager = LicenseManager.getLicenseManager();
                ArrayList<String> customers = new ArrayList<>();
                customers.add(customerConfigUtil.getCustomerCode(user.getDomain()));

                /** Workflow engine available only to next generation customers */
                if (!licenseManager.isMICNextGenerationLicensed(customers)) {
                	throw new InvalidServiceException(
                            LicenseManager.COMPONENT_MIC_NEXT_GENERATION + " is not licensed",
                            null);
                } 
            } catch (InvalidServiceException ise) {
                LogMinder.getLogMinder().log(
                        LogEntry.SEVERITY_INFO,
                        getClass().getName(),
                        ise.getStackTrace()[0].toString(),
                        ServletConfigUtil.COMPONENT_PORTAL,
                        null,
                        ise.getMessage(),
                        ise,
                        LogMinderDOMUtil.VALUE_MIC);
                throw ise;
            } catch (Exception ex) {
                LogMinder.getLogMinder().log(
                        LogEntry.SEVERITY_INFO,
                        getClass().getName(),
                        ex.getStackTrace()[0].toString(),
                        ServletConfigUtil.COMPONENT_PORTAL,
                        null,
                        ex.getMessage(),
                        ex,
                        LogMinderDOMUtil.VALUE_MIC);
                throw new InvalidServiceException(ex.getMessage(), ex);
            }
            preReqSatisfied = true;
        }
    }

    /**
     * Method called be Schedulable task to get this instance
     * @return the singleton instance of this service
     */
    public static ILocalService getService() {
        return INSTANCE;
    }

}
