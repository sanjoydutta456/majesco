/*
 *                 Majesco Code License Notice
 *
 * The contents of this file are subject to the Majesco Code License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License
 *
 * The Original Code is for My Insurance Center. The Initial Developer
 * of the Original Code is Majesco, All Rights Reserved.
 */

package com.majesco.pi.mt.dao;

import java.io.Serializable;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.coverall.admin.dao.DAObject;
import com.coverall.admin.dao.UnderwriterAssignment;
import com.coverall.admin.util.DAOUtil;
import com.coverall.el.QueryWithBindVariables;
import com.coverall.exceptions.ExceptionImpl;
import com.coverall.exceptions.FactoryObjectInitializationException;
import com.coverall.factory.FactoryObject;
import com.coverall.mt.dao.DAOManager;
import com.coverall.mt.dao.Query;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.el.variable.VariableResolverImpl;
import com.coverall.mt.http.HTTPConstants;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;
import com.coverall.util.GeneralUtil;
import com.coverall.util.StringUtil;

/**
 * DOCUMENT ME!
 *
 * @author $Author:   nilesh  $
 * @version $Revision:   1.7  $
 */
public class Underwriter extends DAObject implements Serializable {
    /** DOCUMENT ME! */
    public static final int SUN_UNDERWRITER_ID = 0;

    /** DOCUMENT ME! */
    public static final int SUN_UNDERWRITER_CODE = 1;

    /** DOCUMENT ME! */
    public static final int SUN_UNDERWRITER_NAME = 2;

    /** DOCUMENT ME! */
    public static final int SUN_EXPIRATION_DATE = 3;

    /** DOCUMENT ME! */
    public static final int SUN_ADDRESS_1 = 4;

    /** DOCUMENT ME! */
    public static final int SUN_ADDRESS_2 = 5;

    /** DOCUMENT ME! */
    public static final int SUN_ADDRESS_3 = 6;

    /** DOCUMENT ME! */
    public static final int SUN_ADDRESS_4 = 7;

    /** DOCUMENT ME! */
    public static final int SUN_CITY = 8;

    /** DOCUMENT ME! */
    public static final int SUN_COUNTY = 9;

    /** DOCUMENT ME! */
    public static final int SUN_STATE_PROVINCE = 10;

    /** DOCUMENT ME! */
    public static final int SUN_POSTAL_CODE = 11;

    /** DOCUMENT ME! */
    public static final int SUN_COUNTRY = 12;

    /** DOCUMENT ME! */
    public static final int SUN_TELEPHONE = 13;

    /** DOCUMENT ME! */
    public static final int SUN_LICENSE_ID = 14;

    /** DOCUMENT ME! */
    public static final int SUN_EMAIL_ID = 15;

    /** DOCUMENT ME! */
    public static final int SUN_DATE_CREATED = 16;

    /** DOCUMENT ME! */
    public static final int SUN_DATE_MODIFIED = 17;
    
    /** DOCUMENT ME! */
    public static final int SUN_UNDERWRITER_TYPE = 18;	//new
    
    private static String INIT_SQL = "select * from SHL_UNDERWRITERS";

    /** DOCUMENT ME! */
    public static final String GET_UNDERWRITERS_QUERY = "getUnderwriters";
    public static final String GET_UW_CODE_SEQUENCE = "S_PI_MIC_SHL_UW_CODE_SEQ.NEXTVAL";
    private java.sql.Date date_created;
    private java.sql.Date date_modified;
    private java.sql.Date expiration_date;
    private LinkedList underwriterAssignments;
    private String address_1;
    private String address_2;
    private String address_3;
    private String address_4;
    private String city;
    private String country;
    private String county;
    private String expired;
    private String license_id;
    private String email_id;
    private String postal_code;
    private String state_province;
    private String telephone;
    private String underwriter_code;
    private String underwriter_name;
    private boolean isModified = false;
    private long underwriter_id;
    private String userId;
    private String underWriterType; //new

    /**
     * Creates a new Underwriter object.
     */
    public Underwriter() {
        this.isNew = true;
        this.underwriterAssignments = new LinkedList();
    }

    /**
     * DOCUMENT ME!
     *
     * @param address_1
     *            DOCUMENT ME!
     */
    public void setAddress1(String address_1) {
        this.address_1 = address_1;
        isModified = true;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String getAddress1() {
        return address_1;
    }

    /**
     * DOCUMENT ME!
     *
     * @param address_2
     *            DOCUMENT ME!
     */
    public void setAddress2(String address_2) {
        this.address_2 = address_2;
        isModified = true;
    }

    public String getUnderWriterType() {
		return underWriterType;
	}

	public void setUnderWriterType(String underWriterType) {
		this.underWriterType = underWriterType;
		isModified = true;
	}

	/**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String getAddress2() {
        return address_2;
    }

    /**
     * DOCUMENT ME!
     *
     * @param address_3
     *            DOCUMENT ME!
     */
    public void setAddress3(String address_3) {
        this.address_3 = address_3;
        isModified = true;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String getAddress3() {
        return address_3;
    }

    /**
     * DOCUMENT ME!
     *
     * @param address_4
     *            DOCUMENT ME!
     */
    public void setAddress4(String address_4) {
        this.address_4 = address_4;
        isModified = true;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String getAddress4() {
        return address_4;
    }

    /**
     * DOCUMENT ME!
     *
     * @param assignmentId
     *            DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public UnderwriterAssignment getAssignment(long assignmentId) {
        UnderwriterAssignment result = null;

        if (underwriterAssignments != null) {
            for (int i = 0; i < underwriterAssignments.size(); i++) {
                UnderwriterAssignment assignment = (UnderwriterAssignment) underwriterAssignments
                        .get(i);

                if (assignmentId == assignment.getAssignmentId()) {
                    result = assignment;

                    break;
                }
            }
        }

        return result;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public List getAssignments() {
        return underwriterAssignments;
    }

    /**
     * DOCUMENT ME!
     *
     * @param city
     *            DOCUMENT ME!
     */
    public void setCity(String city) {
        this.city = city;
        isModified = true;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String getCity() {
        return city;
    }

    /**
     * DOCUMENT ME!
     *
     * @param country
     *            DOCUMENT ME!
     */
    public void setCountry(String country) {
        this.country = country;
        isModified = true;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String getCountry() {
        return country;
    }

    /**
     * DOCUMENT ME!
     *
     * @param county
     *            DOCUMENT ME!
     */
    public void setCounty(String county) {
        this.county = county;
        isModified = true;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String getCounty() {
        return county;
    }

    /**
     * DOCUMENT ME!
     *
     * @param date_created
     *            DOCUMENT ME!
     */
    public void setDateCreated(java.sql.Date date_created) {
        this.date_created = date_created;
        isModified = true;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public java.sql.Date getDateCreated() {
        return date_created;
    }

    /**
     * DOCUMENT ME!
     *
     * @param date_modified
     *            DOCUMENT ME!
     */
    public void setDateModified(java.sql.Date date_modified) {
        this.date_modified = date_modified;
        isModified = true;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public java.sql.Date getDateModified() {
        return date_modified;
    }

    /**
     * DOCUMENT ME!
     *
     * @param field
     *            DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public boolean isEditable(String field) {
        return true;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public HashMap getEditableFields() {
        return null;
    }

    /**
     * DOCUMENT ME!
     *
     * @param expiration_date
     *            DOCUMENT ME!
     */
    public void setExpirationDate(java.sql.Date expiration_date) {
        this.expiration_date = expiration_date;
        isModified = true;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public java.sql.Date getExpirationDate() {
        return expiration_date;
    }

    /**
     * DOCUMENT ME!
     *
     * @param expired
     *            DOCUMENT ME!
     */
    public void setExpired(String expired) {
        this.expired = expired;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String getExpired() {
        return expired;
    }

    /**
     * DOCUMENT ME!
     *
     * @param init_sql
     *            DOCUMENT ME!
     */
    public void setInitSQL(String init_sql) {
        INIT_SQL = init_sql;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String getInitSQL() {
        return INIT_SQL;
    }

    /**
     * DOCUMENT ME!
     *
     * @param license_id
     *            DOCUMENT ME!
     */
    public void setLicenseId(String license_id) {
        this.license_id = license_id;
        isModified = true;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String getLicenseId() {
        return license_id;
    }

    /**
     *
     * @return
     */
    public String getEmailId() {
        return email_id;
    }

    /**
     *
     * @param emailId
     */
    public void setEmailId(String emailId) {
        this.email_id = emailId;
        isModified = true;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public int getNetAssignmentCount() {
        return getNetAssignments().size();
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public List getNetAssignments() {
        List netAssignments = new LinkedList();

        for (int i = 0; i < underwriterAssignments.size(); i++) {
            UnderwriterAssignment assignment = (UnderwriterAssignment) underwriterAssignments
                    .get(i);

            if (!assignment.shouldBeDeleted()) {
                netAssignments.add(assignment);
            }
        }

        return netAssignments;
    }

    /**
     * DOCUMENT ME!
     *
     * @param postal_code
     *            DOCUMENT ME!
     *
     * @throws Exception
     *             DOCUMENT ME!
     */
    public void setPostalCode(String postal_code) throws Exception {
    	postal_code=postal_code.toUpperCase();
        this.postal_code = DAOUtil.getPostalCode1(postal_code)
                + ((postal_code.contains("-"))?"-":" ")
                +  DAOUtil.getPostalCode2(postal_code);

        if (this.postal_code.equals("00000-0000")) {
            this.postal_code = "";
        }

        isModified = true;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String getPostalCode() {
    	if(this.postal_code==null || this.postal_code.equalsIgnoreCase("")){
    		return "";
    	}else{
    		return this.postal_code.toUpperCase();
    	}
    }

    /**
     * DOCUMENT ME!
     *
     * @param state_province
     *            DOCUMENT ME!
     */
    public void setStateProvince(String state_province) {
        this.state_province = state_province;
        isModified = true;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String getStateProvince() {
    	if(country!=null && country.equalsIgnoreCase("UK")){
    		return null;
    	}
        return state_province;
    }

    /**
     * DOCUMENT ME!
     *
     * @param telephone
     *            DOCUMENT ME!
     */
    public void setTelephone(String telephone) {
        this.telephone = telephone;
        isModified = true;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String getTelephone() {
        return telephone;
    }

    /**
     * DOCUMENT ME!
     *
     * @param underwriter_code
     *            DOCUMENT ME!
     */
    public void setUnderwriterCode(String underwriter_code) {
        this.underwriter_code = underwriter_code;
        isModified = true;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String getUnderwriterCode() {
        return underwriter_code;
    }

    /**
     * DOCUMENT ME!
     *
     * @param underwriter_id
     *            DOCUMENT ME!
     */
    public void setUnderwriterId(long underwriter_id) {
        this.underwriter_id = underwriter_id;
        isModified = true;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public long getUnderwriterId() {
        return underwriter_id;
    }

    /**
     * DOCUMENT ME!
     *
     * @param underwriter_name
     *            DOCUMENT ME!
     */
    public void setUnderwriterName(String underwriter_name) {
        this.underwriter_name = underwriter_name;
        isModified = true;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String getUnderwriterName() {
        return underwriter_name;
    }
    
    
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
        isModified = true;
    }

    /**
     * DOCUMENT ME!
     *
     * @param assignment
     *            DOCUMENT ME!
     */
    public void addAssignment(UnderwriterAssignment assignment) {
        if (!underwriterAssignments.contains(assignment)) {
            underwriterAssignments.addFirst(assignment);
            assignment.setUnderwriterId(this.underwriter_id);
        }
    }

    /**
     * DOCUMENT ME!
     *
     * @param assignments
     *            DOCUMENT ME!
     */
    public void addAssignments(List assignments) {
        if (assignments != null) {
            for (int i = 0; i < assignments.size(); i++) {
                addAssignment(((UnderwriterAssignment) assignments.get(i)));
            }
        }
    }
    
    public String getGAUnderwriterCode(String code) {
    	String gaUWCode = "";
    	DecimalFormat df = new DecimalFormat("000000");
    	
    	 LogMinder
         .getLogMinder()
         .log(LogEntry.SEVERITY_FATAL,
                         Underwriter.class.getName(),
                         "Code cretion check before",
                         ServletConfigUtil.COMPONENT_FRAMEWORK,
                         new Object[] { },
                         "Code cretion check before",
                         null, LogMinderDOMUtil.VALUE_MIC);             
         
    	
    	if(code.length() < 6 || code.length() == 6) {
    		gaUWCode = "UW"+(df.format(Double.parseDouble(code))).substring(0, 6);
    		
    		 LogMinder
             .getLogMinder()
             .log(LogEntry.SEVERITY_FATAL,
                             Underwriter.class.getName(),
                             "Code cretion check after",
                             ServletConfigUtil.COMPONENT_FRAMEWORK,
                             new Object[] { },
                             "after",
                             null, LogMinderDOMUtil.VALUE_MIC);             
             
    		
    		return gaUWCode;
    		
    		
    		
    	}else{
    		gaUWCode = "UW"+code;
    		return gaUWCode;
    	}
    }
    
    private Long getNextSequence(String Sequence, Connection connection) {
        Long NextSequence = (long) 0;
        PreparedStatement pst = null;
        //Connection con = null;
        try {
                //con = ConnectionPool.getConnection(user);
                String sequenceQuery = "SELECT " + Sequence + " nextSeq FROM DUAL";
                pst = connection.prepareStatement(sequenceQuery);
                ResultSet rs = pst.executeQuery();
                while (rs.next()) {
                        NextSequence = Long.parseLong(rs.getString("nextSeq"));
                }
        } catch (SQLException e) {
                LogMinder
                                .getLogMinder()
                                .log(LogEntry.SEVERITY_FATAL,
                                                Underwriter.class.getName(),
                                                "getNextSequence",
                                                ServletConfigUtil.COMPONENT_FRAMEWORK,
                                                new Object[] { Sequence },
                                                "Error getting next sequence in Underwriter Exception : ",
                                                e, LogMinderDOMUtil.VALUE_MIC);
                System.out.println("Error Getting Sequence : " + Sequence
                                + " SQL Exception : " + e);
        } catch (Exception e) {
                LogMinder
                .getLogMinder()
                .log(LogEntry.SEVERITY_FATAL,
                                Underwriter.class.getName(),
                                "getNextSequence",
                                ServletConfigUtil.COMPONENT_FRAMEWORK,
                                new Object[] { Sequence },
                                "Error getting next sequence in Underwriter Exception : ",
                                e, LogMinderDOMUtil.VALUE_MIC);
                System.out.println("Error Getting Sequence : " + Sequence
                + " Exception : " + e);
        } finally {
                try {
                        DBUtil.close(null, pst, null);
                } catch (Exception e) {
                        LogMinder.getLogMinder().log(
                                        LogEntry.SEVERITY_FATAL,
                                        Underwriter.class.getName(),
                                        "getNextSequence",
                                        ServletConfigUtil.COMPONENT_FRAMEWORK,
                                        new Object[] {  },
                                        "Error closing DB Objects while getting next sequence : "
                                                        + e.getMessage(), e, LogMinderDOMUtil.VALUE_MIC);
                }
        }
        return NextSequence;
}


    /*
     * FUNCTION f_del_underwriter( f_underwriter_id IN
     * SHL_UNDERWRITERS.SUN_UNDERWRITER_ID%TYPE, f_error_message OUT VARCHAR2 )
     * RETURN NUMBER
     */
    public void delete(Connection conn) throws SQLException {
        CallableStatement callableStatement = null;

        try {
            callableStatement = (CallableStatement) conn
                    .prepareCall("{? = call k_underwriter_management_c.f_del_underwriter_c(?,?) }");
            callableStatement.registerOutParameter(1, Types.BIGINT);
            callableStatement.setLong(2, this.getUnderwriterId());
            callableStatement.registerOutParameter(3, Types.VARCHAR);
            callableStatement.execute();

            long errorCode = callableStatement.getLong(1);

            if (errorCode != 0) {
                throw new SQLException(callableStatement.getString(3));
            }
        } finally {
            DBUtil.close(null, callableStatement);
        }
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public boolean hasDefaultAssignedUnderwriter() {
        boolean result = false;

        for (int i = 0; i < underwriterAssignments.size(); i++) {
            UnderwriterAssignment underwriterAssignment = (UnderwriterAssignment) underwriterAssignments
                    .get(i);

            if (underwriterAssignment.getDefaultAssignment()) {
                result = true;

                break;
            }
        }

        return result;
    }

    /**
     * DOCUMENT ME!
     *
     * @param args
     *            DOCUMENT ME!
     *
     * @throws FactoryObjectInitializationException
     *             DOCUMENT ME!
     */
    public void init(HashMap args) throws FactoryObjectInitializationException {
        if (args == null) {
            throw new FactoryObjectInitializationException(
                    ExceptionImpl.FATAL,
                    "args was null",
                    null);
        }

        ResultSet rs = (ResultSet) args.get("INIT_KEY");

        if (rs == null) {
            throw new FactoryObjectInitializationException(
                    ExceptionImpl.FATAL,
                    "rs was null",
                    null);
        }

        try {
            this.underwriter_id = rs.getLong("SUN_UNDERWRITER_ID");
            this.underwriter_code = rs.getString("SUN_UNDERWRITER_CODE");
            this.underwriter_name = rs.getString("SUN_UNDERWRITER_NAME");
            this.expiration_date = rs.getDate("SUN_EXPIRATION_DATE");
            this.address_1 = rs.getString("SUN_ADDRESS_1");
            this.address_2 = rs.getString("SUN_ADDRESS_2");
            this.address_3 = rs.getString("SUN_ADDRESS_3");
            this.address_4 = rs.getString("SUN_ADDRESS_4");
            this.city = rs.getString("SUN_CITY");
            this.county = rs.getString("SUN_COUNTY");
            this.state_province = rs.getString("SUN_STATE_PROVINCE");
            this.postal_code = rs.getString("SUN_POSTAL_CODE");
            this.country = rs.getString("SUN_COUNTRY");
            this.telephone = rs.getString("SUN_TELEPHONE");
            this.license_id = rs.getString("SUN_LICENSE_ID");
            this.email_id = rs.getString("SUN_EMAIL_ID");
            this.date_created = rs.getDate("SUN_DATE_CREATED");
            this.date_modified = rs.getDate("SUN_DATE_MODIFIED");
            this.expired = rs.getString("SUN_EXPIRED");
            this.userId = rs.getString("SUN_USER_ID");
            this.underWriterType = rs.getString("SUN_UNDERWRITER_TYPE");
            this.isNew = false;
            
        } catch (Throwable t) {
            throw new FactoryObjectInitializationException(
                    ExceptionImpl.FATAL,
                    "unable to load object",
                    t);
        }
    }

    /**
     * DOCUMENT ME!
     *
     * @param session
     *            DOCUMENT ME!
     * @param requestParams
     *            DOCUMENT ME!
     *
     * @throws Exception
     *             DOCUMENT ME!
     */
    public void init(HttpSession session, Map requestParams) throws Exception {
        if (this.underwriter_id >= 0) {
            User user = (User) session.getAttribute(HTTPConstants.SESSION_USER);

            DAOManager daoManager = DAOManager
                    .getInstance(ServletConfigUtil.COMPONENT_ADMIN);
            HashMap variableMap = new HashMap();
            variableMap.put(VariableResolverImpl.SESSION_PARAMETER, session);
            variableMap.put(
                    VariableResolverImpl.REQUESTPARAMS_PARAMETER,
                    requestParams);

            // Get the underwriters query from the DAOManager
            Query query = daoManager.getQuery(
                    ServletConfigUtil.COMPONENT_ADMIN,
                    user,
                    GET_UNDERWRITERS_QUERY,
                    variableMap);

            Connection conn = null;
            PreparedStatement st = null;
            ResultSet rs = null;

            try {
            	QueryWithBindVariables queryWithBindVariables = query.getQueryWithBindVariables();
                conn = ConnectionPool.getConnection(user);
                st = conn.prepareStatement(queryWithBindVariables.getQuery());
                
                if(queryWithBindVariables.getBindVariablesValues() != null) {
                	GeneralUtil.bindVariablesToStatement(queryWithBindVariables.getBindVariablesValues(), st, 0);
                }
                rs = st.executeQuery();

                if (rs.next()) {
                    HashMap args = new HashMap();
                    args.put(FactoryObject.INIT_KEY, rs);
                    init(args);
                }
            } finally {
                DBUtil.close(rs, st, conn);
            }
        }
    }

    /*
     * FUNCTION f_add_underwriter_c( f_underwriter_code IN
     * SHL_UNDERWRITERS.SUN_UNDERWRITER_CODE%TYPE, f_underwriter_name IN
     * SHL_UNDERWRITERS.SUN_UNDERWRITER_NAME%TYPE, f_expiration_date IN
     * SHL_UNDERWRITERS.SUN_EXPIRATION_DATE%TYPE, f_address_1 IN
     * SHL_UNDERWRITERS.SUN_ADDRESS_1%TYPE, f_address_2 IN
     * SHL_UNDERWRITERS.SUN_ADDRESS_2%TYPE, f_address_3 IN
     * SHL_UNDERWRITERS.SUN_ADDRESS_3%TYPE, f_address_4 IN
     * SHL_UNDERWRITERS.SUN_ADDRESS_4%TYPE, f_city IN
     * SHL_UNDERWRITERS.SUN_CITY%TYPE, f_county IN
     * SHL_UNDERWRITERS.SUN_COUNTY%TYPE, f_state_province IN
     * SHL_UNDERWRITERS.SUN_STATE_PROVINCE%TYPE, f_postal_code IN
     * SHL_UNDERWRITERS.SUN_POSTAL_CODE%TYPE, f_country IN
     * SHL_UNDERWRITERS.SUN_COUNTRY%TYPE, f_telephone IN
     * SHL_UNDERWRITERS.SUN_TELEPHONE%TYPE, f_license_id IN
     * SHL_UNDERWRITERS.SUN_LICENSE_ID%TYPE, f_email_id IN
     * SHL_UNDERWRITERS.SUN_EMAIL_ID%TYPE, f_underwriter_id OUT
     * SHL_UNDERWRITERS.SUN_UNDERWRITER_ID%TYPE, 
     * f_error_message OUT VARCHAR2 ,
     * SHL_UNDERWRITERS_CUSTOM.sun_underwriter_type%TYPE, p_underwriter_type IN)
     * RETURN NUMBER
     */
    public void insert(Connection connection) throws SQLException {
        CallableStatement callableStatement = null;
        
        
        try {
        	
        	LogMinder
            .getLogMinder()
            .log(LogEntry.SEVERITY_FATAL,
                            Underwriter.class.getName(),
                            "checking before insert",
                            ServletConfigUtil.COMPONENT_FRAMEWORK,
                            new Object[] {  },
                            " checking before insert",
                            null, LogMinderDOMUtil.VALUE_MIC);  
        	
        	String gaUnderwriterCode = "";
            Long sequence = getNextSequence(GET_UW_CODE_SEQUENCE, connection);
            String newSequence = sequence+"";
            gaUnderwriterCode = getGAUnderwriterCode(newSequence);
        	
            callableStatement = (CallableStatement) connection
                    .prepareCall("{ ? = call k_underwriter_management_c.f_add_underwriter_c(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }");		//new
            callableStatement.registerOutParameter(1, Types.BIGINT);
            callableStatement.setString(2, gaUnderwriterCode);
            callableStatement.setString(3, this.getUnderwriterName());
            callableStatement.setDate(4, this.getExpirationDate());
            callableStatement.setString(5, this.getAddress1());
            callableStatement.setString(6, this.getAddress2());
            callableStatement.setString(7, this.getAddress3());
            callableStatement.setString(8, this.getAddress4());
            callableStatement.setString(9, this.getCity());
            callableStatement.setString(10, this.getCounty());
            callableStatement.setString(11, this.getStateProvince());
            callableStatement.setString(12, this.getPostalCode());
            callableStatement.setString(13, this.getCountry());
            callableStatement.setString(14, this.getTelephone());
            callableStatement.setString(15, this.getLicenseId());
            callableStatement.setString(16, this.getEmailId());
            callableStatement.setString(17, this.getUserId());
            callableStatement.registerOutParameter(18, Types.BIGINT);
            callableStatement.registerOutParameter(19, Types.VARCHAR);
            callableStatement.setString(20, this.getUnderWriterType());// new 
            callableStatement.execute();

            long errorCode = callableStatement.getLong(1);

            if (errorCode == 0) {
                this.setUnderwriterId(callableStatement.getLong(18));
            } else {
                String errorMessage = "Error adding a underwriter: ";
                errorMessage = errorMessage + callableStatement.getString(18);
                throw new SQLException(errorMessage);
            }
        } finally {
            DBUtil.close(null, callableStatement);
        }
    }

    /**
     * DOCUMENT ME!
     *
     * @param connection
     *            DOCUMENT ME!
     *
     * @throws Throwable
     *             DOCUMENT ME!
     * @throws SQLException
     *             DOCUMENT ME!
     */
    public void persist(Connection connection) throws Throwable {
        UnderwriterAssignment underwriterAssignment = null;

        try {
            connection.setAutoCommit(false);

            super.persist(connection);

            for (int i = 0; i < underwriterAssignments.size(); i++) {
                underwriterAssignment = (UnderwriterAssignment) underwriterAssignments
                        .get(i);

                if (underwriterAssignment.getDefaultAssignment()) {
                    underwriterAssignment.setAssignedUnderwriterId(this
                            .getUnderwriterId());
                }

                underwriterAssignment.setUnderwriterId(this.getUnderwriterId());
                underwriterAssignment.persist(connection);
            }

            connection.commit();
            connection.setAutoCommit(true);
        } catch (Throwable th) {
            connection.rollback();

            String message = th.getMessage();

            if (message.equalsIgnoreCase("Duplicate Record")) {
                String errorMessage = message + " - "
                        + underwriterAssignment.getAssignmentId();
                throw new SQLException(errorMessage);
            } else {
                throw th;
            }
        } finally {
            DBUtil.close(connection);
        }
    }

    /**
     * DOCUMENT ME!
     *
     * @param connection
     *            DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     *
     * @throws SQLException
     *             DOCUMENT ME!
     */
    public boolean underwriterExists(Connection connection) throws SQLException {
        boolean exists = false;
        CallableStatement callableStatement = null;

        try {
            callableStatement = (CallableStatement) connection
                    .prepareCall("{ ? = call K_Underwriter_Management.f_validate_underwriter(?,?) }");
            callableStatement.registerOutParameter(1, Types.BIGINT);
            callableStatement.setString(2, this.getUnderwriterCode());
            callableStatement.registerOutParameter(3, Types.VARCHAR);
            callableStatement.execute();

            long returnCode = callableStatement.getLong(1);

            if (returnCode != 0) {
                exists = true;
            }
        } finally {
            DBUtil.close(null, callableStatement);
        }

        return exists;
    }

    /*
     * FUNCTION f_add_underwriter( f_underwriter_code IN
     * SHL_UNDERWRITERS.SUN_UNDERWRITER_CODE%TYPE, f_underwriter_name IN
     * SHL_UNDERWRITERS.SUN_UNDERWRITER_NAME%TYPE, f_expiration_date IN
     * SHL_UNDERWRITERS.SUN_EXPIRATION_DATE%TYPE, f_address_1 IN
     * SHL_UNDERWRITERS.SUN_ADDRESS_1%TYPE, f_address_2 IN
     * SHL_UNDERWRITERS.SUN_ADDRESS_2%TYPE, f_address_3 IN
     * SHL_UNDERWRITERS.SUN_ADDRESS_3%TYPE, f_address_4 IN
     * SHL_UNDERWRITERS.SUN_ADDRESS_4%TYPE, f_city IN
     * SHL_UNDERWRITERS.SUN_CITY%TYPE, f_county IN
     * SHL_UNDERWRITERS.SUN_COUNTY%TYPE, f_state_province IN
     * SHL_UNDERWRITERS.SUN_STATE_PROVINCE%TYPE, f_postal_code IN
     * SHL_UNDERWRITERS.SUN_POSTAL_CODE%TYPE, f_country IN
     * SHL_UNDERWRITERS.SUN_COUNTRY%TYPE, f_telephone IN
     * SHL_UNDERWRITERS.SUN_TELEPHONE%TYPE, f_license_id IN
     * SHL_UNDERWRITERS.SUN_LICENSE_ID%TYPE, f_email_id IN
     * SHL_UNDERWRITERS.SUN_EMAIL_ID%TYPE, f_underwriter_id OUT
     * SHL_UNDERWRITERS.SUN_UNDERWRITER_ID%TYPE, f_error_message OUT VARCHAR2 )
     * RETURN NUMBER
     */
    public void update(Connection conn) throws SQLException {
        CallableStatement callableStatement = null;

        try {
            callableStatement = (CallableStatement) conn
                    .prepareCall("{? = call k_underwriter_management_c.f_mod_underwriter_c(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }");
            callableStatement.registerOutParameter(1, Types.BIGINT);
            callableStatement.setLong(2, this.getUnderwriterId());
            callableStatement.setString(3, this.getUnderwriterCode());
            callableStatement.setString(4, this.getUnderwriterName());
            callableStatement.setDate(5, this.getExpirationDate());
            callableStatement.setString(6, this.getAddress1());
            callableStatement.setString(7, this.getAddress2());
            callableStatement.setString(8, this.getAddress3());
            callableStatement.setString(9, this.getAddress4());
            callableStatement.setString(10, this.getCity());
            callableStatement.setString(11, this.getCounty());
            callableStatement.setString(12, this.getStateProvince());
            callableStatement.setString(13, this.getPostalCode());
            callableStatement.setString(14, this.getCountry());
            callableStatement.setString(15, this.getTelephone());
            callableStatement.setString(16, this.getLicenseId());
            callableStatement.setString(17, this.getEmailId());
            callableStatement.setString(18, this.getUserId());
            callableStatement.registerOutParameter(19, Types.VARCHAR);
            callableStatement.setString(20, this.getUnderWriterType());// new 
            callableStatement.execute();

            long errorCode = callableStatement.getLong(1);

            if (errorCode != 0) {
                String errorMessage = "Error updating a underwriter: ";
                errorMessage = errorMessage + callableStatement.getString(18);
                throw new SQLException(errorMessage);
            }
        } finally {
            DBUtil.close(null, callableStatement);
        }
    }

	
}
