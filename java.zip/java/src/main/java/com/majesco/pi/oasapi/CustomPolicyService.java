package com.majesco.pi.oasapi;

import com.coverall.mic.rest.policy.api.service.ICustomPolicyService;
import com.majesco.custom.pi.api.unifiedsearch.service.impl.UnifiedImpl;

 
public class CustomPolicyService implements ICustomPolicyService{

    public static final String CUSTOM_DATA_SEARCH = "customentitysearch";
    
 
    @Override
    public Object getCustomAPIServiceHandler(String apiFileName, String apiVersion) {

        //Policy Snapshot functionality
        if(CUSTOM_DATA_SEARCH.equalsIgnoreCase(apiFileName)) {
            return new UnifiedImpl(); 
        }

        return null;
    }
 
}
