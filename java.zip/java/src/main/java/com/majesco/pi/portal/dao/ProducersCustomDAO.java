package com.majesco.pi.portal.dao;



import java.io.Serializable;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import com.coverall.portal.dao.ProducersDAO;


public class ProducersCustomDAO extends ProducersDAO {

    private static final List COLUMNS = new ArrayList();


    /** The producer id db column name constant*/
    private static final String COL_NAME_SPR_PRODUCER_ID = "SPR_PRODUCER_ID";

    /** The producer code db column name constant*/
    private static final String COL_NAME_SPR_PRODUCER_CODE = "SPR_PRODUCER_CODE";

    /** The producer name db column name constant*/
    private static final String COL_NAME_SPR_PRODUCER_NAME = "SPR_PRODUCER_NAME";

    /** The producer address 1 db column name constant*/
    private static final String COL_NAME_SPR_ADDRESS_1 = "SPR_ADDRESS_1";

    /** The producer address 2 db column name constant*/
    private static final String COL_NAME_SPR_ADDRESS_2 = "SPR_ADDRESS_2";

    /** The producer address 3 db column name constant*/
    private static final String COL_NAME_SPR_ADDRESS_3 = "SPR_ADDRESS_3";

    /** The producer address 4 db column name constant*/
    private static final String COL_NAME_SPR_ADDRESS_4 = "SPR_ADDRESS_4";

    /** The producer city db column name constant*/
    private static final String COL_NAME_SPR_CITY = "SPR_CITY";

    /** The producer county db column name constant*/
    private static final String COL_NAME_SPR_COUNTY = "SPR_COUNTY";

    /** The producer state province db column name constant*/
    private static final String COL_NAME_SPR_STATE_PROVINCE = "SPR_STATE_PROVINCE";

    /** The producer postal code db column name constant*/
    private static final String COL_NAME_SPR_POSTAL_CODE = "SPR_POSTAL_CODE";

    /** The producer country db column name constant*/
    private static final String COL_NAME_SPR_COUNTRY = "SPR_COUNTRY";

    /** The producer Telephone db column name constant*/
    private static final String COL_NAME_SPR_TELEPHONE = "SPR_TELEPHONE";

    /** The producer License Id db column name constant*/
    private static final String COL_NAME_SPR_LICENSE_ID = "SPR_LICENSE_ID";

    /** The producer tax state province db column name constant*/
    private static final String COL_NAME_SPR_TAX_STATE_PROVINCE = "SPR_TAX_STATE_PROVINCE";

    /** The producer territory db column name constant*/
    private static final String COL_NAME_SPR_TERRITORY = "SPR_TERRITORY";

    /** The producer Estimated DWP db column name constant*/
    private static final String COL_NAME_SPR_ESTIMATED_DWP = "SPR_ESTIMATED_DWP";

    /** The producer parent producer db column name constant*/
    private static final String COL_NAME_SPR_PARENT_PRODUCER = "SPR_PARENT_PRODUCER";

    /** The producer Class db column name constant*/
    private static final String COL_NAME_SPR_PRODUCER_CLASS = "SPR_PRODUCER_CLASS";

    /** The producer FEIN Number db column name constant*/
    private static final String COL_NAME_SPR_FEIN_NUMBER = "SPR_FEIN_NUMBER";

    /** The producer Category db column name constant*/
    private static final String COL_NAME_SPR_PRODUCER_CATEGORY = "SPR_PRODUCER_CATEGORY";

    /** The producer Direct Bill Indictor db column name constant*/
    private static final String COL_NAME_SPR_DIRECT_BILL_INDICATOR = "SPR_DIRECT_BILL_INDICATOR";

    /** The producer Sub Agent db column name constant*/
    private static final String COL_NAME_SPR_SUB_AGENT = "SPR_SUB_AGENT";

    /** The producer DFU db column name constant*/
    private static final String COL_NAME_SPR_DFU = "SPR_DFU";

    /** The user modified db column name constant*/
    private static final String COL_NAME_SPR_USER_MODIFIED = "SPR_USER_MODIFIED";
    
    /** The producer's Market Manager db column name constant*/
    private static final String COL_NAME_SPR_MARKET_MANAGER = "SPR_MARKET_MANAGER";

    /** The producer's Sweep Indicator db column name constant*/
    private static final String COL_NAME_SWEEP_INDICATOR = "SPR_SWEEP_INDICATOR";
    
    /** The producer's Print Preference indicator db column name constant*/
    private static final String COL_NAME_SPR_PRINT_PREF_INDICATOR = "SPR_PRINT_PREFERENCE_INDICATOR";
    
    private static final String COL_NAME_SPR_IS_CONTACT_MANDATORY = "SPR_IS_CONTACT_MANDATORY";

	/** Start Extra fields added for AW Producer */
	
    /** The designation id db column name constant*/
    private static final String COL_NAME_SPR_DRAGON_ID = "SPR_DRAGON_ID";
    
    /** The internal name  db column name constant*/
    private static final String COL_NAME_SPR_INTERNAL_NAME = "SPR_INTERNAL_NAME";
    
    /** The FAX  db column name constant*/
    private static final String COL_NAME_SPR_FAX = "SPR_FAX";
    
    /** The Webite  db column name constant*/
    private static final String COL_NAME_SPR_WEBSITE = "SPR_WEBSITE";
	
	/** The Producer Status db column name constant*/
    private static final String COL_NAME_SPR_PRODUCER_STATUS = "SPR_PRODUCER_STATUS";
    
    /** The Distribution Designation sttus  db column name constant*/
    private static final String COL_NAME_SPR_DISTRI_DESIG = "SPR_DISTRI_DESIG";
    
    /** The producer type  db column name constant*/
    private static final String COL_NAME_SPR_PRODUCER_TYPE = "SPR_PRODUCER_TYPE";
    
    /** The producer group  db column name constant*/
    private static final String COL_NAME_SPR_PRODUCER_GROUP = "SPR_PRODUCER_GROUP";
    
    /** The Brokerage Agreement  db column name constant*/
    private static final String COL_NAME_SPR_BROK_AGRMNT = "SPR_BROK_AGRMNT";
    
    
    /** The producer group id  db column name constant*/
    private static final String COL_NAME_SPR_PRODUCER_GROUP_ID = "SPR_PRODUCER_GROUP_ID";
    
    private static final String COL_NAME_SPR_INVOICE_FLAG = "SPR_INVOICE_FLAG";
	
    private static final String COL_NAME_SPR_PARTNER_TYPE = "SPR_PARTNER_TYPE"; 
    
    private static final String COL_NAME_SPR_EMAIL_ID = "SPR_EMAIL_ID" ; 
    
    private static final String COL_NAME_SPR_LEXISNEXIS_ACCOUNT = "SPR_LEXISNEXIS_ACCOUNT" ;
	
    /** The producer second name db column name constant*/
    private static final String COL_NAME_SPR_PRODUCER_NAME_1 = "SPR_PRODUCER_NAME_1";

    /** The PARTNER_COUNTY  sttus  db column name constant*/
    private static final String COL_NAME_SPR_PARTNER_COUNTY = "SPR_PARTNER_COUNTY";
    
    /** The PRODUCER_EFF_DATE sttus  db column name constant*/
    private static final String COL_NAME_SPR_PRODUCER_EFF_DATE = "SPR_PRODUCER_EFF_DATE";
    
    /** The PRODUCER_TERM_DATE  db column name constant*/
    private static final String COL_NAME_SPR_PRODUCER_TERM_DATE = "SPR_PRODUCER_TERM_DATE";
    
    /** The SPR_DISABLED_REASON  sttus  db column name constant*/
    private static final String COL_NAME_SPR_DISABLED_REASON = "SPR_DISABLED_REASON";
    
    /** The SPR_NPN db column name constant*/
    private static final String COL_NAME_SPR_NPN = "SPR_NPN";
    
    /** The SPR_COMM_PAID_BASIS db column name constant*/
    private static final String COL_NAME_SPR_COMM_PAID_BASIS = "SPR_COMM_PAID_BASIS";    
    
  
    /** The producer Underwriter Manager column name constant*/
    private static final String COL_NAME_PAPD_UW_MANAGER = "PAPD_UW_MANAGER";

    /** The producer Underwriter Assistant column name constant*/
    private static final String COL_NAME_PAPD_UW_ASSISTANT = "PAPD_UW_ASSISTANT";

    /** The producer team lead db column name constant*/
    private static final String COL_NAME_PAPD_TEAM_LEAD = "PAPD_TEAM_LEAD";
    
    /** The producer status column name constant*/
    private static final String COL_NAME_STATUS = "STATUS";

    /** The producer modified date column name constant*/
    private static final String COL_NAME_MODIFIED_DATE = "MODIFIED_DATE";
    
    


    /** Query for inserting a producer to the DB */
    private static final String QUERY_INSERT_PRODUCER =
        "K_PRODUCER_MANAGEMENT_PI.f_add_producer";

    /** Query for updating a producer in the DB */
    private static final String QUERY_UPDATE_PRODUCER =
        "K_PRODUCER_MANAGEMENT_PI.f_mod_producer";

    /** Query for deleting a producer from DB */
    private static final String QUERY_DELETE_PRODUCER =
        "K_PRODUCER_MANAGEMENT_PI.f_del_producer";

    /** Query for selecting producer data from DB */
    private static final String QUERY_SELECT_PRODUCER_ADD_DATA =         
        " SELECT Producers.*,\r\n" + 
        "  ProdAddData.*\r\n" + 
        "FROM SHL_PRODUCERS Producers,\r\n" + 
        "  PISHL_ADD_PRODUCER_DATA ProdAddData\r\n" + 
        "WHERE SPR_PRODUCER_ID         =  ?\r\n" + 
        "AND Producers.SPR_PRODUCER_ID = ProdAddData.PAPD_PRODUCER_ID ";
    /**default constructor */
    public ProducersCustomDAO(){
    }

    static {
    	COLUMNS.add(COL_NAME_SPR_PRODUCER_ID);
        COLUMNS.add(COL_NAME_SPR_PRODUCER_CODE);
        COLUMNS.add(COL_NAME_SPR_PRODUCER_NAME);
        COLUMNS.add(COL_NAME_SPR_ADDRESS_1);
        COLUMNS.add(COL_NAME_SPR_ADDRESS_2);
        COLUMNS.add(COL_NAME_SPR_ADDRESS_3);
        COLUMNS.add(COL_NAME_SPR_ADDRESS_4);
        COLUMNS.add(COL_NAME_SPR_CITY);
        COLUMNS.add(COL_NAME_SPR_COUNTY);
        COLUMNS.add(COL_NAME_SPR_STATE_PROVINCE);
        COLUMNS.add(COL_NAME_SPR_POSTAL_CODE);
        COLUMNS.add(COL_NAME_SPR_COUNTRY);
        COLUMNS.add(COL_NAME_SPR_TELEPHONE);
        COLUMNS.add(COL_NAME_SPR_LICENSE_ID);
        COLUMNS.add(COL_NAME_SPR_TAX_STATE_PROVINCE);
        COLUMNS.add(COL_NAME_SPR_TERRITORY);
        COLUMNS.add(COL_NAME_SPR_ESTIMATED_DWP);
        COLUMNS.add(COL_NAME_SPR_PARENT_PRODUCER);
        COLUMNS.add(COL_NAME_SPR_PRODUCER_CLASS);
        COLUMNS.add(COL_NAME_SPR_FEIN_NUMBER);
        COLUMNS.add(COL_NAME_SPR_PRODUCER_CATEGORY);
        COLUMNS.add(COL_NAME_SPR_DIRECT_BILL_INDICATOR);
        COLUMNS.add(COL_NAME_SPR_SUB_AGENT);
        COLUMNS.add(COL_NAME_SPR_DFU);
        COLUMNS.add(COL_NAME_SPR_EMAIL_ID);
        COLUMNS.add(COL_NAME_SPR_MARKET_MANAGER);
        COLUMNS.add(COL_NAME_SWEEP_INDICATOR);
        COLUMNS.add(COL_NAME_SPR_PRINT_PREF_INDICATOR);
        COLUMNS.add(COL_NAME_SPR_IS_CONTACT_MANDATORY);
		/* start of Change for AW */
		COLUMNS.add(COL_NAME_SPR_DRAGON_ID);
        COLUMNS.add(COL_NAME_SPR_INTERNAL_NAME);
        COLUMNS.add(COL_NAME_SPR_FAX);
        COLUMNS.add(COL_NAME_SPR_WEBSITE);
		COLUMNS.add(COL_NAME_SPR_PRODUCER_STATUS);
        COLUMNS.add(COL_NAME_SPR_DISTRI_DESIG);
        COLUMNS.add(COL_NAME_SPR_PRODUCER_TYPE);
        COLUMNS.add(COL_NAME_SPR_PRODUCER_GROUP);
        COLUMNS.add(COL_NAME_SPR_BROK_AGRMNT);
        COLUMNS.add(COL_NAME_SPR_PRODUCER_GROUP_ID);
        COLUMNS.add(COL_NAME_SPR_PARTNER_TYPE); 
		/* End of Change for AW */
        COLUMNS.add(COL_NAME_SPR_INVOICE_FLAG); 
        COLUMNS.add(COL_NAME_SPR_LEXISNEXIS_ACCOUNT);
        COLUMNS.add(COL_NAME_SPR_PRODUCER_NAME_1);
        COLUMNS.add(COL_NAME_SPR_PARTNER_COUNTY);
        COLUMNS.add(COL_NAME_SPR_PRODUCER_EFF_DATE);
        COLUMNS.add(COL_NAME_SPR_PRODUCER_TERM_DATE);
        COLUMNS.add(COL_NAME_SPR_DISABLED_REASON);
        COLUMNS.add(COL_NAME_SPR_NPN);
        COLUMNS.add(COL_NAME_SPR_COMM_PAID_BASIS);
        /* Start of Change for PI */       
        COLUMNS.add(COL_NAME_PAPD_UW_MANAGER);
        COLUMNS.add(COL_NAME_PAPD_UW_ASSISTANT);
        COLUMNS.add(COL_NAME_PAPD_TEAM_LEAD); 
        COLUMNS.add(COL_NAME_STATUS);
        COLUMNS.add(COL_NAME_MODIFIED_DATE);

        /* End of Change for PI */
        COLUMNS.add(COL_NAME_SPR_USER_MODIFIED);  
        
     
        
    }

    /**
     * Returns the PL/SQL Function name which will be used to insert a new producer
     * @return the PL/SQL Function name which will be used to insert a new producer
     * @throws Exception if any error occurs while processing
     */
    public String getInsertProcedure() throws Exception {
        return QUERY_INSERT_PRODUCER;
    }

    /**
     * Returns the PL/SQL Function name which will be used to update a producer
     * @return the PL/SQL Function name which will be used to update a producer
     * @throws Exception if any error occurs while processing
     */
    public String getUpdateProcedure() throws Exception {
        return QUERY_UPDATE_PRODUCER;
    }

    /**
     * Returns the PL/SQL Function name which will be used to delete a producer
     * @return the PL/SQL Function name which will be used to delete a producer
     * @throws Exception if any error occurs while processing
     */
    public String getDeleteProcedure() throws Exception {
        return QUERY_DELETE_PRODUCER;
    }

    /**
     * Returns the SQL query to load all the data about this entity
     * @return the SQL query to load the data
     * @throws Exception if any error occurs while processing
     */
    public String getSelectQuery() throws Exception {
        return QUERY_SELECT_PRODUCER_ADD_DATA;
    }

    /**
     * Returns the list of colums which should be used while inserting, updating or deleting a producer
     * @return the list of colums which should be used while inserting, updating or deleting a producer
     */
    public List getColumns() {
        return new ArrayList(COLUMNS);
    }


    protected boolean isSaveSupported() {
        return true;
    }
    
    protected boolean isValidateAddressSupported() {
        return true;
    }

}
