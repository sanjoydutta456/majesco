package com.majesco.pi.portal.noc.constants;

public class NocHoldRleaseConstants {

	public static final String BILLING_WEBSERVICE 			= "MIC - INTERNAL - WS - BILLING - INTEGRATION";
	
	public static final String NOC_HOLD_SERVICE_URL 		= "nocHoldServiceUrl";
	
	public static final String NOC_RELEASE_SERVICE_URL 		= "nocReleaseServiceUrl";
	
	public static final String POLICY_PLACEHOLDER_CONST 	= "{policyNumber}";
	
	public static final String EFF_DATE_PLACEHOLDER_CONST 	= "{effectiveDate}";
	
	public static final String BILLING_SERVICE_USER_ID 		= "billingBindServiceUserId";
	
	public static final String BILLING_SERVICE_PASSWORD 	= "billingBindServicePassword";
	
	public static final String CHARSET_UTF8 				= "UTF-8";

}
