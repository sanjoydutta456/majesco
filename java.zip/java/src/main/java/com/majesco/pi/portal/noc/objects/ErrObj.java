package com.majesco.pi.portal.noc.objects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ErrObj {
	
	@JsonProperty("systemerrcode")
	private String systemErrCode;
	
	private String user;

	public final String getSystemErrCode() {
		return systemErrCode;
	}

	public final void setSystemErrCode(String systemErrCode) {
		this.systemErrCode = systemErrCode;
	}

	public final String getUser() {
		return user;
	}

	public final void setUser(String user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "ErrObj [systemErrCode=" + systemErrCode + ", user=" + user + "]";
	}

}
