package com.majesco.pi.portal.noc.objects;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class NocHoldRequestObj {
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'00:00:00.000'Z'")
	private Date requestDate;
	
	private String sourceSystemRequestNo;
	
	private String sourceSystemCode;
	
	private String sourceSystemUserId;
	
	private String sourceSystemUserName;
	
	private String reasonCode;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date releaseDate;
	
	private String holdTypeCode;
	
	private String userRemarks;

	public final Date getRequestDate() {
		return requestDate;
	}

	public final void setRequestDate(Date requestDate) {
		this.requestDate = requestDate;
	}

	public final String getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}

	public final void setSourceSystemRequestNo(String sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}

	public final String getSourceSystemCode() {
		return sourceSystemCode;
	}

	public final void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}

	public final String getSourceSystemUserId() {
		return sourceSystemUserId;
	}

	public final void setSourceSystemUserId(String sourceSystemUserId) {
		this.sourceSystemUserId = sourceSystemUserId;
	}

	public final String getSourceSystemUserName() {
		return sourceSystemUserName;
	}

	public final void setSourceSystemUserName(String sourceSystemUserName) {
		this.sourceSystemUserName = sourceSystemUserName;
	}

	public final String getReasonCode() {
		return reasonCode;
	}

	public final void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public final String getHoldTypeCode() {
		return holdTypeCode;
	}

	public final void setHoldTypeCode(String holdTypeCode) {
		this.holdTypeCode = holdTypeCode;
	}

	public final String getUserRemarks() {
		return userRemarks;
	}

	public final void setUserRemarks(String userRemarks) {
		this.userRemarks = userRemarks;
	}

	public final Date getReleaseDate() {
		return releaseDate;
	}

	public final void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}

	@Override
	public String toString() {
		return "NocHoldRequestObj [requestDate=" + requestDate + ", sourceSystemRequestNo=" + sourceSystemRequestNo
				+ ", sourceSystemCode=" + sourceSystemCode + ", sourceSystemUserId=" + sourceSystemUserId
				+ ", sourceSystemUserName=" + sourceSystemUserName + ", reasonCode=" + reasonCode + ", releaseDate="
				+ releaseDate + ", holdTypeCode=" + holdTypeCode + ", userRemarks=" + userRemarks + "]";
	}
	
}
