package com.majesco.pi.portal.noc.objects;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NocHoldResponseObj {
	
	
	@JsonProperty("statuscode")
	private String statusCode;
	
	private String status;
	
	private List<ErrObj> message;

	public final String getStatusCode() {
		return statusCode;
	}

	public final void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public final String getStatus() {
		return status;
	}

	public final void setStatus(String status) {
		this.status = status;
	}

	public final List<ErrObj> getMessage() {
		return message;
	}

	public final void setMessage(List<ErrObj> message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "NocHoldResponseObj [statusCode=" + statusCode + ", status=" + status + ", message=" + message + "]";
	}

}
