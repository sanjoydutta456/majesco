package com.majesco.pi.portal.noc.services;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;

import com.coverall.exceptions.ServiceException;
import com.coverall.mt.events.EventProcessor;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.majesco.pi.portal.noc.constants.NocHoldRleaseConstants;
import com.majesco.pi.portal.noc.objects.ErrObj;
import com.majesco.pi.portal.noc.objects.NocHoldRequestObj;
import com.majesco.pi.portal.noc.objects.NocHoldResponseObj;

public class NocHoldReleaseClient {
	
	public void hold(NocHoldRequestObj requestObj, User user, String policyNumber, String policyEffectiveDate) 
			throws ServiceException {
		
		String mName = "hold";
		BufferedReader br = null;
		InputStreamReader isr = null;
		
		ObjectMapper mapper = new ObjectMapper();
		DefaultHttpClient client = new DefaultHttpClient();
		
		NocHoldResponseObj responseObj = null;
		
		try {
		
		Map webserviceParams =  EventProcessor.
    			getWebServiceParameters(NocHoldRleaseConstants.BILLING_WEBSERVICE, user);
		
		String serviceURL = (String)webserviceParams.get(NocHoldRleaseConstants.NOC_HOLD_SERVICE_URL);
		
		serviceURL = serviceURL.replace(NocHoldRleaseConstants.POLICY_PLACEHOLDER_CONST, policyNumber);
		serviceURL = serviceURL.replace(NocHoldRleaseConstants.EFF_DATE_PLACEHOLDER_CONST, policyEffectiveDate);
		
		HttpPost postMethod = new HttpPost(serviceURL);
		
		String userName = (String)webserviceParams.get(NocHoldRleaseConstants.BILLING_SERVICE_USER_ID);
		String password = (String)webserviceParams.get(NocHoldRleaseConstants.BILLING_SERVICE_PASSWORD);
		
		String encoding = java.util.Base64.getEncoder().encodeToString((userName + ":" + password).getBytes());
		postMethod.setHeader("Authorization", "Basic " + encoding);
		postMethod.setHeader("Content-Type","application/json");
		

			String requestObjString = mapper.writeValueAsString(requestObj);
			
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,NocHoldReleaseClient.class.getName(), mName,
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[]{"Policy: "+ policyNumber," postMethod :  "+postMethod,"requestObjString : "+requestObjString}, 
					"NocHoldRelease Service: Hold call: ", null, LogMinderDOMUtil.VALUE_WEBSERVICES);
	
			StringEntity input = new StringEntity(requestObjString,NocHoldRleaseConstants.CHARSET_UTF8);
			postMethod.setEntity(input);	
			
			long startTime = System.currentTimeMillis();	
			HttpResponse response = client.execute(postMethod);
			
			isr = new InputStreamReader((response.getEntity().getContent()));
			br = new BufferedReader(isr);
			StringBuilder builder = new StringBuilder();
			String responseData = null;
			while ((responseData = br.readLine()) != null) {
				builder.append(responseData);
			}
			long endTime = System.currentTimeMillis();
			
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,NocHoldReleaseClient.class.getName(), mName,
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[]{"Policy: "+ policyNumber," response :  "+response,"response body: "+ builder.toString()}, 
					"NocHoldRelease Service: Hold", null, LogMinderDOMUtil.VALUE_WEBSERVICES);
			
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,NocHoldReleaseClient.class.getName(), mName,
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[]{"Billing Noc Hold API"}, 
					" API call took " + (endTime-startTime) + " milliseconds.", null, LogMinderDOMUtil.VALUE_WEBSERVICES);
			
			responseObj = mapper.readValue(builder.toString(), NocHoldResponseObj.class);
			
			
						
			if(response.getStatusLine().getStatusCode() != 200) {
				
				StringBuilder errorMessage = new StringBuilder();
				
				for (ErrObj errObj : responseObj.getMessage()) {
					errorMessage.append(errObj.getUser()+" ");
				}
				
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,NocHoldReleaseClient.class.getName(), mName,
						ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[]{"Policy: "+ policyNumber}, 
						errorMessage.toString(), null, LogMinderDOMUtil.VALUE_MIC);
				
				throw new ServiceException(errorMessage.toString(), null);
				
			}
			
		}catch(IOException | ServiceException e) {
			String errMsg = "Error in NOC hold Service: " + e.getMessage();
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,NocHoldReleaseClient.class.getName(), mName,
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[]{"Policy: "+ policyNumber}, 
					errMsg, null, LogMinderDOMUtil.VALUE_MIC);
			
			throw new ServiceException(errMsg, null);
		}finally {
			
			if(br != null) {
				try {
					br.close();
				} catch (IOException e) {
					//do nothing
				}
			}
			
			if(isr != null) {
				try {
					isr.close();
				} catch (IOException e) {
					//do nothing
				}
			}
		}
	}
	
	public void release(NocHoldRequestObj requestObj, User user, String policyNumber, String policyEffectiveDate) 
			throws ServiceException {
		
		String mName = "hold";
		BufferedReader br = null;
		InputStreamReader isr = null;
		
		ObjectMapper mapper = new ObjectMapper();
		DefaultHttpClient client = new DefaultHttpClient();
		
		try {
		
		Map webserviceParams =  EventProcessor.
    			getWebServiceParameters(NocHoldRleaseConstants.BILLING_WEBSERVICE, user);
		
		String serviceURL = (String)webserviceParams.get(NocHoldRleaseConstants.NOC_RELEASE_SERVICE_URL);
		
		serviceURL = serviceURL.replace(NocHoldRleaseConstants.POLICY_PLACEHOLDER_CONST, policyNumber);
		serviceURL = serviceURL.replace(NocHoldRleaseConstants.EFF_DATE_PLACEHOLDER_CONST, policyEffectiveDate);
		
		HttpPost postMethod = new HttpPost(serviceURL);
		
		String userName = (String)webserviceParams.get(NocHoldRleaseConstants.BILLING_SERVICE_USER_ID);
		String password = (String)webserviceParams.get(NocHoldRleaseConstants.BILLING_SERVICE_PASSWORD);
		
		String encoding = java.util.Base64.getEncoder().encodeToString((userName + ":" + password).getBytes());
		postMethod.setHeader("Authorization", "Basic " + encoding);
		postMethod.setHeader("Content-Type","application/json");
		

			String requestObjString = mapper.writeValueAsString(requestObj);
			
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,NocHoldReleaseClient.class.getName(), mName,
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[]{"Policy: "+ policyNumber," postMethod :  "+postMethod,"requestObjString : "+requestObjString}, 
					"NocHoldRelease Service: Release call: ", null, LogMinderDOMUtil.VALUE_WEBSERVICES);
	
			StringEntity input = new StringEntity(requestObjString,NocHoldRleaseConstants.CHARSET_UTF8);
			postMethod.setEntity(input);	
			
			long startTime = System.currentTimeMillis();	
			HttpResponse response = client.execute(postMethod);
			
			isr = new InputStreamReader((response.getEntity().getContent()));
			br = new BufferedReader(isr);
			StringBuilder builder = new StringBuilder();
			String responseData = null;
			while ((responseData = br.readLine()) != null) {
				builder.append(responseData);
			}
			long endTime = System.currentTimeMillis();
			
			
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,NocHoldReleaseClient.class.getName(), mName,
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[]{"Policy: "+ policyNumber," response :  "+response,"response body: "+ builder.toString()}, 
					"NocHoldRelease Service: Release", null, LogMinderDOMUtil.VALUE_WEBSERVICES);
			
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,NocHoldReleaseClient.class.getName(), mName,
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[]{"Billing Noc Release API"}, 
					" API call took " + (endTime-startTime) + " milliseconds.", null, LogMinderDOMUtil.VALUE_WEBSERVICES);
			
			if(response.getStatusLine().getStatusCode() != 200) {
				
				String errMessage = "Error during Billing NOC Release service call";
				
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,NocHoldReleaseClient.class.getName(), mName,
						ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[]{"Policy: "+ policyNumber}, 
						errMessage, null, LogMinderDOMUtil.VALUE_MIC);
				
				throw new ServiceException(errMessage, null);
				
			}
			
		}catch(IOException | ServiceException e) {
			String errMsg = "Error in NOC Release Service: " + e.getMessage();
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,NocHoldReleaseClient.class.getName(), mName,
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[]{"Policy: "+ policyNumber}, 
					errMsg, null, LogMinderDOMUtil.VALUE_MIC);
			
			throw new ServiceException(errMsg, null);
		}finally {
			
			if(br != null) {
				try {
					br.close();
				} catch (IOException e) {
					//do nothing
				}
			}
			
			if(isr != null) {
				try {
					isr.close();
				} catch (IOException e) {
					//do nothing
				}
			}
		}
	}
	
}
