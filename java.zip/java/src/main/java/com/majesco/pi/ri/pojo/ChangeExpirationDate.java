package com.majesco.pi.ri.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.google.gson.annotations.SerializedName;

public class ChangeExpirationDate {
	
	    @SerializedName("Policy") 
	    private Policy Policy;

	    public void setPolicy(Policy Policy){
	        this.Policy = Policy;
	    }
	    public Policy getPolicy(){
	        return this.Policy;
	    }
	
	

}
