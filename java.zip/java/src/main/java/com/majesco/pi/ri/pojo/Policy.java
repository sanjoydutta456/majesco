package com.majesco.pi.ri.pojo;

import java.util.Map;

import com.google.gson.annotations.SerializedName;

public class Policy {

    @SerializedName("TransEffectiveDate")
	private String TransEffectiveDate;
	
    @SerializedName("EndorsementReason")
	private String EndorsementReason;
	

    @SerializedName("CUnderwriterMgr")
	private String cUnderwriterManager;
   
	
    @SerializedName("CTeamLead")
	private String cTeamlead;
	
    @SerializedName("CUnderwriterAsst")
	private String cUnderwriterAssistant;
    
    @SerializedName("CancelDescription")
    private String CancelDescription;

    
	public String getTransEffectiveDate() {
		return TransEffectiveDate;
	}

	public void setTransEffectiveDate(String transEffectiveDate) {
		TransEffectiveDate = transEffectiveDate;
	}

	public String getEndorsementReason() {
		return EndorsementReason;
	}

	public void setEndorsementReason(String endorsementReason) {
		EndorsementReason = endorsementReason;
	}

	public String getcUnderwriterManager() {
		return cUnderwriterManager;
	}

	public void setcUnderwriterManager(String cUnderwriterManager) {
		this.cUnderwriterManager = cUnderwriterManager;
	}

	public String getcTeamlead() {
		return cTeamlead;
	}

	public void setcTeamlead(String cTeamlead) {
		this.cTeamlead = cTeamlead;
	}

	public String getcUnderwriterAssistant() {
		return cUnderwriterAssistant;
	}

	public void setcUnderwriterAssistant(String cUnderwriterAssistant) {
		this.cUnderwriterAssistant = cUnderwriterAssistant;
	}
	
	public String getCancelDescription() {
		return CancelDescription;
	}

	public void setCancelDescription(String cancelDescription) {
		CancelDescription = cancelDescription;
	}

	@Override
	public String toString() {
		return "Policy [TransEffectiveDate=" + TransEffectiveDate + ", EndorsementReason=" + EndorsementReason
				+ ", cUnderwriterManager=" + cUnderwriterManager + ", cTeamlead=" + cTeamlead
				+ ", cUnderwriterAssistant=" + cUnderwriterAssistant + ", CancelDescription=" + CancelDescription + "]";
	}
}
