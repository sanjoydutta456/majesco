package com.majesco.pi.ri.pojo;

import java.util.Map;

public class TransactionAttributesVO {
	
	private static final String ENTITY_TYPE_PARAM = "entityType";
	private static final String SEND_HIDDEN_ATTRIBUTES_PARAM = "sendHiddenAttributes";
	private static final String TRNANSATION_NAME_PARAM = "transactionName";
	private static final String PRODUCT_CODE_PARAM = "productCode";
	private static final String TRANSACTION_ID_PARAM = "transactionID";
	private static final String USE_OPTIMIZED_FLOW_PARAM = "useOptimizedFlow";
	private static final String C_IS_AUTO_PROPAGATION = "cIsAutoPropagation";
	private static final String SOURCE_MASTER_POLICY_REFERENCE = "sourceMasterPolicyReference";
	private static final String TARGET_MASTER_POLICY_REFERENCE = "targetMasterPolicyReference";

	
	
	private long NotificationId;
	 
	private String sourcePolicyReference;
	
	private String targetPolicyReference;

	private String transEffectiveDate;	
	
	private long policyGACbillingId = 0L;;
	
	private String newPolicyReference;
	
	private long newPolicyGid = 0L;
	
	private long insuredId = 0L;

    private long ntlPdCoveragesId =0L;
    
    private long ntOptionalCoverageId = 0L;
    
    
	private String expirationDate;

	private String trnsactionID;
	
	private String effectiveDate;
	
	private String newTransEffectiveDate;
	
	private String newExpirationDate;
	
	private String cTransactionDescription;
	
	private String cEndorsementReason;
	
	private String EndorsementReason;

	private String newEntityReference;
	
    private String reverseTo;



	private String productCode;
	
	private String transactionName;
	
	private String sendHiddenAttributes;
	
	private Long numberOfFailedAttempts = 0L;
	
	private String entityType ;
	
	private String clientId;
	
	private String useOptimizedFlow ;
   
	private String isValidRedo;
	
	private String isBooked;
	
	private String isRenewed;
	
	
	private String lobNtID;
	
	private String statePremiumGid;
	
	
	private String requestJson;
	
	private String reporterMonthBrkId;
	private String workloadJobId;
	private String workloadItemId;
	private String monthBreakdownRequestID;
	
	private String transactionCode; 
	private String pendingCancelReason;
	private String cancelCode;
	private String cancelMethod;
	private String cancelDescription;
	private String cancelType;
	private String cancelReasonDesc;
	private Map policyRequestParameters;
	private String transactionInitiatedBy;
	private String cTransactionDescriptionCutoff;
	private String shouldExtendAniversaryDate;
	private String newAnniversaryDate;
	
	public String getNewAnniversaryDate() {
		return newAnniversaryDate;
	}

	public void setNewAnniversaryDate(String newAnniversaryDate) {
		this.newAnniversaryDate = newAnniversaryDate;
	}

	public String getShouldExtendAniversaryDate() {
		return shouldExtendAniversaryDate;
	}

	public void setShouldExtendAniversaryDate(String shouldExtendAniversaryDate) {
		this.shouldExtendAniversaryDate = shouldExtendAniversaryDate;
	}

	public String getcTransactionDescriptionCutoff() {
		return cTransactionDescriptionCutoff;
	}

	public void setcTransactionDescriptionCutoff(String cTransactionDescriptionCutoff) {
		this.cTransactionDescriptionCutoff = cTransactionDescriptionCutoff;
	}

	public String getReporterMonthBrkIdCutoff() {
		return reporterMonthBrkIdCutoff;
	}

	public void setReporterMonthBrkIdCutoff(String reporterMonthBrkIdCutoff) {
		this.reporterMonthBrkIdCutoff = reporterMonthBrkIdCutoff;
	}

	private String reporterMonthBrkIdCutoff;
	
	

	public String getTransactionInitiatedBy() {
		return transactionInitiatedBy;
	}

	public void setTransactionInitiatedBy(String transactionInitiatedBy) {
		this.transactionInitiatedBy = transactionInitiatedBy;
	}

	private String cSubPolicyStatusSync ;

	public String getCancelReasonDesc() {
		return cancelReasonDesc;
	}

	public void setCancelReasonDesc(String cancelReasonDesc) {
		this.cancelReasonDesc = cancelReasonDesc;
	}

	public String getPendingCancelReason() {
		return pendingCancelReason;
	}

	public void setPendingCancelReason(String pendingCancelReason) {
		this.pendingCancelReason = pendingCancelReason;
	}

	public String getCancelCode() {
		return cancelCode;
	}

	public void setCancelCode(String cancelCode) {
		this.cancelCode = cancelCode;
	}

	public String getCancelMethod() {
		return cancelMethod;
	}

	public void setCancelMethod(String cancelMethod) {
		this.cancelMethod = cancelMethod;
	}

	public String getCancelDescription() {
		return cancelDescription;
	}

	public void setCancelDescription(String cancelDescription) {
		this.cancelDescription = cancelDescription;
	}

	public String getCancelType() {
		return cancelType;
	}

	public void setCancelType(String cancelType) {
		this.cancelType = cancelType;
	}

	public String getTransactionCode() {
		return transactionCode;
	}

	public void setTransactionCode(String transactionCode) {
		this.transactionCode = transactionCode;
	}

	public String getStatePremiumGid() {
		return statePremiumGid;
	}

	public void setStatePremiumGid(String statePremiumGid) {
		this.statePremiumGid = statePremiumGid;
	}

	public String getLobNtID() {
		return lobNtID;
	}

	public void setLobNtID(String lobNtID) {
		this.lobNtID = lobNtID;
	}

	public String getRequestJson() {
		return requestJson;
	}

	public void setRequestJson(String requestJson) {
		this.requestJson = requestJson;
	}

	public long getNotificationId() {
		return NotificationId;
	}

	public void setNotificationId(long notificationId) {
		NotificationId = notificationId;
	}

	public String getTransEffectiveDate() {
		return transEffectiveDate;
	}

	public void setTransEffectiveDate(String transEffectiveDate) {
		this.transEffectiveDate = transEffectiveDate;
	}

	public String getNewPolicyReference() {
		return newPolicyReference;
	}

	public void setNewPolicyReference(String newPolicyReference) {
		this.newPolicyReference = newPolicyReference;
	}

	public long getNewPolicyGid() {
		return newPolicyGid;
	}

	public void setNewPolicyGid(long newPolicyGid) {
		this.newPolicyGid = newPolicyGid;
	}

	public String getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}

	public String getTrnsactionID() {
		return trnsactionID;
	}

	public void setTrnsactionID(String trnsactionID) {
		this.trnsactionID = trnsactionID;
	}

	public String getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getNewTransEffectiveDate() {
		return newTransEffectiveDate;
	}

	public void setNewTransEffectiveDate(String newTransEffectiveDate) {
		this.newTransEffectiveDate = newTransEffectiveDate;
	}

	public String getNewExpirationDate() {
		return newExpirationDate;
	}

	public void setNewExpirationDate(String newExpirationDate) {
		this.newExpirationDate = newExpirationDate;
	}

	public String getcTransactionDescription() {
		return cTransactionDescription;
	}

	public void setcTransactionDescription(String cTransactionDescription) {
		this.cTransactionDescription = cTransactionDescription;
	}

	public String getcEndorsementReason() {
		return cEndorsementReason;
	}

	public void setcEndorsementReason(String cEndorsementReason) {
		this.cEndorsementReason = cEndorsementReason;
	}

	public String getEndorsementReason() {
		return EndorsementReason;
	}

	public void setEndorsementReason(String endorsementReason) {
		EndorsementReason = endorsementReason;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getTransactionName() {
		return transactionName;
	}

	public void setTransactionName(String transactionName) {
		this.transactionName = transactionName;
	}

	public String getSendHiddenAttributes() {
		return sendHiddenAttributes;
	}

	public void setSendHiddenAttributes(String sendHiddenAttributes) {
		this.sendHiddenAttributes = sendHiddenAttributes;
	}

	public Long getNumberOfFailedAttempts() {
		return numberOfFailedAttempts;
	}

	public void setNumberOfFailedAttempts(Long numberOfFailedAttempts) {
		this.numberOfFailedAttempts = numberOfFailedAttempts;
	}

	public String getEntityType() {
		return entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getUseOptimizedFlow() {
		return useOptimizedFlow;
	}

	public void setUseOptimizedFlow(String useOptimizedFlow) {
		this.useOptimizedFlow = useOptimizedFlow;
	}

	public String getIsValidRedo() {
		return isValidRedo;
	}

	public void setIsValidRedo(String isValidRedo) {
		this.isValidRedo = isValidRedo;
	}

	public String getIsBooked() {
		return isBooked;
	}

	public void setIsBooked(String isBooked) {
		this.isBooked = isBooked;
	}

	public String getIsRenewed() {
		return isRenewed;
	}

	public void setIsRenewed(String isRenewed) {
		this.isRenewed = isRenewed;
	}

	public static String getEntityTypeParam() {
		return ENTITY_TYPE_PARAM;
	}

	public static String getSendHiddenAttributesParam() {
		return SEND_HIDDEN_ATTRIBUTES_PARAM;
	}

	public static String getTrnansationNameParam() {
		return TRNANSATION_NAME_PARAM;
	}

	public static String getProductCodeParam() {
		return PRODUCT_CODE_PARAM;
	}

	public static String getTransactionIdParam() {
		return TRANSACTION_ID_PARAM;
	}

	public static String getUseOptimizedFlowParam() {
		return USE_OPTIMIZED_FLOW_PARAM;
	}

	
	public String getNewEntityReference() {
		return newEntityReference;
	}

	public void setNewEntityReference(String newEntityReference) {
		this.newEntityReference = newEntityReference;
	}

	
	public String getReverseTo() {
		return reverseTo;
	}

	public void setReverseTo(String reverseTo) {
		this.reverseTo = reverseTo;
	}
	
	public String getReporterMonthBrkId() {
		return reporterMonthBrkId;
	}

	public void setReporterMonthBrkId(String reporterMonthBrkId) {
		this.reporterMonthBrkId = reporterMonthBrkId;
	}

	public String getWorkloadJobId() {
		return workloadJobId;
	}

	public void setWorkloadJobId(String workloadJobId) {
		this.workloadJobId = workloadJobId;
	}

	public String getWorkloadItemId() {
		return workloadItemId;
	}

	public void setWorkloadItemId(String workloadItemId) {
		this.workloadItemId = workloadItemId;
	}

	public String getMonthBreakdownRequestID() {
		return monthBreakdownRequestID;
	}

	public void setMonthBreakdownRequestID(String monthBreakdownRequestID) {
		this.monthBreakdownRequestID = monthBreakdownRequestID;
	}
	
	public static String getcIsAutoPropagation() {
		return C_IS_AUTO_PROPAGATION;
	}

	public static String getSourceMasterPolicyReference() {
		return SOURCE_MASTER_POLICY_REFERENCE;
	}

	public static String getTargetMasterPolicyReference() {
		return TARGET_MASTER_POLICY_REFERENCE;
	}



	public long getInsuredId() {
		return insuredId;
	}

	public void setInsuredId(long insuredId) {
		this.insuredId = insuredId;
	}

	public long getPolicyGACbillingId() {
		return policyGACbillingId;
	}

	public void setPolicyGACbillingId(long policyGACbillingId) {
		this.policyGACbillingId = policyGACbillingId;
	}

	public long getNtlPdCoveragesId() {
		return ntlPdCoveragesId;
	}

	public void setNtlPdCoveragesId(long ntlPdCoveragesId) {
		this.ntlPdCoveragesId = ntlPdCoveragesId;
	}

	public long getNtOptionalCoverageId() {
		return ntOptionalCoverageId;
	}

	public void setNtOptionalCoverageId(long ntOptionalCoverageId) {
		this.ntOptionalCoverageId = ntOptionalCoverageId;
	}

	public String getSourcePolicyReference() {
		return sourcePolicyReference;
	}

	public void setSourcePolicyReference(String sourcePolicyReference) {
		this.sourcePolicyReference = sourcePolicyReference;
	}

	public String getTargetPolicyReference() {
		return targetPolicyReference;
	}

	public void setTargetPolicyReference(String targetPolicyReference) {
		this.targetPolicyReference = targetPolicyReference;
	}

	
	public String getcSubPolicyStatusSync() {
		return cSubPolicyStatusSync;
	}

	public void setcSubPolicyStatusSync(String cSubPolicyStatusSync) {
		this.cSubPolicyStatusSync = cSubPolicyStatusSync;
	}
	
	
	
	public Map getPolicyRequestParameters() {
		return policyRequestParameters;
	}

	public void setPolicyRequestParameters(Map policyRequestParameters) {
		this.policyRequestParameters = policyRequestParameters;
	}

	@Override
	public String toString() {
		return "TransactionAttributesVO [NotificationId=" + NotificationId + ", sourcePolicyReference="
				+ sourcePolicyReference + ", targetPolicyReference=" + targetPolicyReference + ", transEffectiveDate="
				+ transEffectiveDate + ", policyGACbillingId=" + policyGACbillingId + ", newPolicyReference="
				+ newPolicyReference + ", newPolicyGid=" + newPolicyGid + ", insuredId=" + insuredId
				+ ", ntlPdCoveragesId=" + ntlPdCoveragesId + ", ntOptionalCoverageId=" + ntOptionalCoverageId
				+ ", expirationDate=" + expirationDate + ", trnsactionID=" + trnsactionID + ", effectiveDate="
				+ effectiveDate + ", newTransEffectiveDate=" + newTransEffectiveDate + ", newExpirationDate="
				+ newExpirationDate + ", cTransactionDescription=" + cTransactionDescription + ", cEndorsementReason="
				+ cEndorsementReason + ", EndorsementReason=" + EndorsementReason + ", newEntityReference="
				+ newEntityReference + ", reverseTo=" + reverseTo + ", productCode=" + productCode
				+ ", transactionName=" + transactionName + ", sendHiddenAttributes=" + sendHiddenAttributes
				+ ", numberOfFailedAttempts=" + numberOfFailedAttempts + ", entityType=" + entityType + ", clientId="
				+ clientId + ", useOptimizedFlow=" + useOptimizedFlow + ", isValidRedo=" + isValidRedo + ", isBooked="
				+ isBooked + ", isRenewed=" + isRenewed + ", lobNtID=" + lobNtID + ", statePremiumGid="
				+ statePremiumGid + ", requestJson=" + requestJson + ", reporterMonthBrkId=" + reporterMonthBrkId
				+ ", workloadJobId=" + workloadJobId + ", workloadItemId=" + workloadItemId
				+ ", monthBreakdownRequestID=" + monthBreakdownRequestID + ", transactionCode=" + transactionCode
				+ ", pendingCancelReason=" + pendingCancelReason + ", cancelCode=" + cancelCode + ", cancelMethod="
				+ cancelMethod + ", cancelDescription=" + cancelDescription + ", cancelType=" + cancelType
				+ ", cancelReasonDesc=" + cancelReasonDesc + ", policyRequestParameters=" + policyRequestParameters
				+ ", transactionInitiatedBy=" + transactionInitiatedBy + ", cTransactionDescriptionCutoff="
				+ cTransactionDescriptionCutoff + ", reporterMonthBrkIdCutoff=" + reporterMonthBrkIdCutoff
				+ ", cSubPolicyStatusSync=" + cSubPolicyStatusSync + "]";
	}

	

	

	
	
	


	

	
	
	

}
