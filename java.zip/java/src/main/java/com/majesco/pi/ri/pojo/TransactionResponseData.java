package com.majesco.pi.ri.pojo;
import java.util.Arrays;



public class TransactionResponseData {
	private String clientId;
	private String transactionId;
	private String customerId;
	private String sourceSystemID;
	private String policyReference; 
	private String gid;
	private ErrorObject[] Errors;   


	public String getGid() { 
		return gid;
	}
	public void setGid(String gid) {
		this.gid = gid;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getSourceSystemID() {
		return sourceSystemID;
	}
	public void setSourceSystemID(String sourceSystemID) {
		this.sourceSystemID = sourceSystemID;
	}
	public ErrorObject[] getErrors() {
		return Errors;
	}
	public void setErrors(ErrorObject[] errors) {
		Errors = errors;
	}
	
	public String getPolicyReference() {
		return policyReference;
	}
	public void setPolicyReference(String policyReference) {
		this.policyReference = policyReference;
	}
	@Override
	public String toString() {
		return "TransactionResponseData [clientId=" + clientId + ", transactionId=" + transactionId + ", customerId="
				+ customerId + ", sourceSystemID=" + sourceSystemID + ", policyReference=" + policyReference + ", gid="
				+ gid + ", Errors=" + Arrays.toString(Errors) + "]";
	}

	
	
	

	

}
