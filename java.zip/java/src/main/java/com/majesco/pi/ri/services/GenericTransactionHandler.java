package com.majesco.pi.ri.services; 

public class GenericTransactionHandler {


	public IGenericTransactionPropagation getServiceHandler(String transactionType, String transactionCode) {

		if ( null!=  transactionType && null != transactionCode) {
			return new GenericTransactionProcessor();
		}else {

			return null;   
		}


	}

}