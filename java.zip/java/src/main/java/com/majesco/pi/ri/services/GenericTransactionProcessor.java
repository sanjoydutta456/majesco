package com.majesco.pi.ri.services;

import java.net.InetAddress;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;
import com.google.gson.Gson;
import com.majesco.pi.ri.pojo.ChangeExpirationDate;
import com.majesco.pi.ri.pojo.ErrorObject;
import com.majesco.pi.ri.pojo.Policy;
import com.majesco.pi.ri.pojo.TransactionAttributesVO;
import com.majesco.pi.ri.pojo.TransactionResponseData;
import com.majesco.pi.ri.utils.MasterSubPropagationUtil;


public class GenericTransactionProcessor  extends MasterSubPropagationUtil implements IGenericTransactionPropagation {

	@Override
	public synchronized void processTransaction(User user,  PolicyTransactionRequest transactionRequest, String taskId, String userName,
			String password) throws Exception {


		try {
			InetAddress ipAddr = InetAddress.getLocalHost(); 
			getServiceURLFromMahcineConfigs();
			final String  serverName = machineURL;

			TransactionAttributesVO policyRecords = null;


			boolean isFailedFromInception = true;
			StringBuilder errorDescription = new StringBuilder();
			boolean isOOSE = false;
			boolean shouldProcess = false ;


			try {		
				

            	
            	policyRecords = new TransactionAttributesVO(); 
            	policyRecords.setTrnsactionID(transactionRequest.getTransactionID());
            	policyRecords.setProductCode(transactionRequest.getProductCode());
            	policyRecords.setSendHiddenAttributes("N");
            	policyRecords.setTransactionName(transactionRequest.getRequestType());
            	policyRecords.setEntityType(transactionRequest.getEntityType()); 
            	
            	if (null!= transactionRequest && null != transactionRequest.getCopyDataReference()) {
            	policyRecords.setTargetPolicyReference(transactionRequest.getCopyDataReference());
            	
            	}
            	
            	
            	if (null!= transactionRequest && transactionRequest.getEntityType().equalsIgnoreCase("POLICY") && transactionRequest.getIsBooked().equalsIgnoreCase("Y") ) {
            		
            		shouldProcess = true;
            	}
            	
                if (null!= transactionRequest && transactionRequest.getEntityType().equalsIgnoreCase("QUOTE")  ) {
            		
            		shouldProcess = true;
            	}
                

            
                
                
                if(shouldProcess) {
				updateStatus(taskId, transactionRequest.getRequestId(), user, transactionRequest.getTransactionID(), "IN PROGRESS");


                if(null!=transactionRequest && null!= transactionRequest.getRequestParameterMap()&& transactionRequest.getRequestParameterMap().size() > 0) {
                	policyRecords.setPolicyRequestParameters(transactionRequest.getRequestParameterMap());
                }
                
           
            	
				TransactionResponseData responseDataInitiation = startNewTransactionResponse(serverName,policyRecords, userName, password);

				isFailedFromInception = false;


				
				
				ErrorObject[]  errorArrayInit = responseDataInitiation.getErrors(); 
				for (int j = 0 ; j <errorArrayInit.length ; j ++  ) {

					ErrorObject errorObj =	 errorArrayInit[j];

					if(null!= errorObj.getMessageType() && "ALERT".equalsIgnoreCase(errorObj.getMessageType()) 
							&& null!= errorObj.getMessage() && errorObj.getMessage().equalsIgnoreCase("Do you want to continue with this change?")){
						isOOSE = true; 

					}


				} 
 

				if (responseDataInitiation.getErrors() != null && responseDataInitiation.getErrors().length > 0 && !isOOSE) {
					
					ErrorObject[]  errorArray = responseDataInitiation.getErrors();
	 				errorDescription.append("Exception in Start New Transaction Initiation Call of " + policyRecords.getTransactionName()+ " , " +policyRecords.getNewPolicyReference() + ", failed with following validations :- \n");
	 				for (ErrorObject  validation : errorArray ) {
	 					errorDescription.append(null!=validation.getJasonPath()?validation.getJasonPath():"").append(validation.getMessage() + "\n");

	 				}
					
					throw new Exception("Exception on startNewTransaction for " + transactionRequest.getRequestType()  +" Call"); 

				} else {

					TransactionResponseData responseDataUpdate = updatePolicyResponse(serverName,policyRecords,userName,password);
					
					
					
					
					

					TransactionResponseData getPolicyResponse = getObjectResponse(serverName, GET_POLICY, policyRecords, userName, password);	

					if (getPolicyResponse.getErrors() != null && getPolicyResponse.getErrors().length > 0 && !isOOSE) {
						
						
						
						throw new Exception("Exception on fetching policy details for " + transactionRequest.getRequestType()  +" Call ");

					}

					policyRecords.setNewPolicyGid(Long.valueOf(getPolicyResponse.getSourceSystemID()));
					policyRecords.setNewPolicyReference(getPolicyResponse.getTransactionId());
					policyRecords.setClientId(getPolicyResponse.getClientId());


					TransactionResponseData responseDataValidate = validateTransactionResponse(serverName, policyRecords, userName, password);



					if (responseDataValidate.getErrors() != null && responseDataValidate.getErrors().length > 0) {


						ErrorObject[] errorArray = responseDataValidate.getErrors();



						for (int j = 0 ; j <errorArray.length ; j ++  ) {

							ErrorObject errorObj =	 errorArray[j];

							if(null!= errorObj.getMessageType() && "ALERT".equalsIgnoreCase(errorObj.getMessageType()) 
									&& null!= errorObj.getMessage() && errorObj.getMessage().equalsIgnoreCase("Do you want to continue with this change?")){
								isOOSE = true;

							}


						}


						if(!isOOSE) {
							
							
							ErrorObject[]  errorOOSEArray = responseDataValidate.getErrors();
			 				errorDescription.append("Exception in Validate Call of " + policyRecords.getTransactionName() + " , " +policyRecords.getNewPolicyReference() + ", failed with following validations :- \n");
			 				for (ErrorObject  validation : errorOOSEArray ) {
			 					errorDescription.append(null!=validation.getJasonPath()?validation.getJasonPath():"").append(validation.getMessage() + "\n");

			 				}
							
							
							throw new Exception(
									"Exception on validation  for " + transactionRequest.getRequestType()  +" Call");
						}
						// Call OOSE microservice 

						// Insert the record in a table with the OOSE Amendment policy reference with status as READY
						// Once Done aknowledge the alert


						TransactionResponseData responseDataValidateAck = validateAckTransactionResponse(serverName, policyRecords, userName, password);


						String newPolicyGid = getLatestPolicyGid(user, policyRecords.getNewPolicyReference());
						policyRecords.setNewPolicyGid(Long.valueOf(newPolicyGid)); 






						TransactionResponseData reResponseDataUpdate = updatePolicyResponse(serverName,policyRecords,userName,password);

						TransactionResponseData reGetPolicyResponse = getObjectResponse(serverName, GET_POLICY, policyRecords, userName, password);	

						if (reGetPolicyResponse.getErrors() != null && reGetPolicyResponse.getErrors().length > 0) {
							throw new Exception("Exception on fetching policy details for " +  transactionRequest.getRequestType()  +" Call ");

						}



						policyRecords.setNewPolicyGid(Long.valueOf(reGetPolicyResponse.getSourceSystemID()));
						policyRecords.setNewPolicyReference(reGetPolicyResponse.getTransactionId());
						policyRecords.setClientId(reGetPolicyResponse.getClientId());


						TransactionResponseData reResponseDataValidate = validateTransactionResponse(serverName, policyRecords, userName, password);

						if (reResponseDataValidate.getErrors() != null && reResponseDataValidate.getErrors().length > 0) {

							ErrorObject[]  errorOOSEArray = reResponseDataValidate.getErrors();
			 				errorDescription.append("Exception in Validate Call of " + policyRecords.getTransactionName() + " , " +policyRecords.getNewPolicyReference() + ", failed with following validations :- \n");
			 				for (ErrorObject  validation : errorOOSEArray ) {
			 					errorDescription.append(null!=validation.getJasonPath()?validation.getJasonPath():"").append(validation.getMessage() + "\n");

			 				}
							
							
							
							throw new Exception(
									"Exception on validation  for " +  transactionRequest.getRequestType()   +" Call ");  

						} 


						processOOSERecords(taskId,policyRecords.getNewPolicyGid(), user,transactionRequest.getTransactionType() ,policyRecords.getNewPolicyReference());


					} 





					TransactionResponseData responseDataComplete = completeTransactionResponse(serverName, policyRecords, userName, password);



					if (responseDataComplete.getErrors() != null && responseDataComplete.getErrors().length > 0) {
						ErrorObject[]  errorArray = responseDataComplete.getErrors();
		 				errorDescription.append("Exception in Complete Call of " + policyRecords.getTransactionName() + " , " +policyRecords.getNewPolicyReference() + ", failed with following validations :- \n");
		 				for (ErrorObject  validation : errorArray ) {
		 					errorDescription.append(null!=validation.getJasonPath()?validation.getJasonPath():"").append(validation.getMessage() + "\n");

		 				}

						throw new Exception(
								"Exception on Completion for for " + transactionRequest.getRequestType()  +" Call ");

					} 
					
					
					updateStatus(taskId, transactionRequest.getRequestId(), user, transactionRequest.getTransactionID(), "COMPLETED");







				}

              }
			}catch (Exception ex) {
				LogMinder.getLogMinder().log(
						LogEntry.SEVERITY_FATAL,
						getClass().getName(),
						new Exception().getStackTrace()[0].toString(),
						ServletConfigUtil.COMPONENT_FRAMEWORK,
						new Object[] {taskId, policyRecords.getNewPolicyGid(), user, transactionRequest.getRequestType(),isFailedFromInception},
						"An exception occured in processTransaction. ",
						ex,
						LogMinderDOMUtil.VALUE_MIC);
				try {     
					
					updateStatus(taskId, transactionRequest.getRequestId(), user, transactionRequest.getTransactionID(), "ERROR");
					

					if(!isFailedFromInception) {
						TransactionResponseData responseDataSuspend = suspendTransactionResponse(serverName,policyRecords, userName, password);
						
					}



					if(isFailedFromInception) {
					     errorDescription.append( "Exception in " + policyRecords.getTransactionName() + 
								 
									
									"  .This transaction: " + policyRecords.getTransactionName() + " is not allowed on  " + policyRecords.getTrnsactionID() + ". This can typically happen in one of the following scenarios: User does not have permission to perform this transaction or there are unbooked transactions on this policy  or this is not the latest revision of this POLICY or this transaction itself is not allowed at this point in the lifecycle. " );		

						processSaveFailTask(taskId, transactionRequest.getRequestGid(), user,transactionRequest.getTransactionType(),policyRecords.getTrnsactionID(),null,errorDescription.toString(),transactionRequest.getTaskDescription());
					}else {
						processSaveFailTask(taskId,policyRecords.getNewPolicyGid() , user, transactionRequest.getTransactionType(),policyRecords.getNewPolicyReference(),null,errorDescription.toString(),transactionRequest.getTaskDescription());

					} 

				}catch(Exception e) {
					LogMinder.getLogMinder().log( 
							LogEntry.SEVERITY_FATAL,
							getClass().getName(),
							new Exception().getStackTrace()[0].toString(),
							ServletConfigUtil.COMPONENT_FRAMEWORK,
							new Object[] {},
							"An exception occured in processTransaction. ",
							ex,
							LogMinderDOMUtil.VALUE_MIC);
				}  
			}





		}catch (Exception ex) {
			LogMinder.getLogMinder().log(
					LogEntry.SEVERITY_FATAL,
					getClass().getName(),
					new Exception().getStackTrace()[0].toString(),
					ServletConfigUtil.COMPONENT_FRAMEWORK,
					new Object[] {},
					"An exception occured in processTransaction. ",
					ex,
					LogMinderDOMUtil.VALUE_MIC);

			throw ex;


		}	


	}
	
	
	@Override
	protected TransactionResponseData updatePolicyResponse(String serverName, TransactionAttributesVO monthlyRec, String userName,
			String password) throws Exception {
		String responseJson = "";
		TransactionResponseData responseDataUpdate = null;
		Map policyReqParameterMap = null;

		try {

			Policy policy = new Policy();
			
		
			
			if(null!=monthlyRec && null!=monthlyRec.getPolicyRequestParameters() && monthlyRec.getPolicyRequestParameters().size() > 0 ) {
				
				//policy.setPolicyReqParameterMap(monthlyRec.getPolicyRequestParameters());
				
				policyReqParameterMap = monthlyRec.getPolicyRequestParameters();
				
				  Iterator it = policyReqParameterMap.keySet().iterator();
			        while(it.hasNext()) {
			            String key = (String)it.next();
			            
			          
			            			            
			            if(null!= key && key.equalsIgnoreCase("TransEffectiveDate")) { 
				            String value = (String) policyReqParameterMap.get(key) ;
				            if (null!= value)
			            	policy.setTransEffectiveDate(value);
			            }
			            
			            if(null!= key && key.equalsIgnoreCase("EndorsementReason") ) {
				            String value = (String) policyReqParameterMap.get(key) ;
				            if (null!= value)
			            	policy.setEndorsementReason(value);
			            }
			            
			            if(null!= key && key.equalsIgnoreCase("CUnderwriterMgr") ) {
				            String value = (String) policyReqParameterMap.get(key) ;
				            if (null!= value)
			            	policy.setcUnderwriterManager(value);
			            }
			            
			            if(null!= key && key.equalsIgnoreCase("CTeamLead") ) {
				            String value = (String) policyReqParameterMap.get(key) ;
				            if (null!= value)
			            	policy.setcTeamlead(value);
			            }
			            
			            if(null!= key && key.equalsIgnoreCase("CUnderwriterAsst") ) {
				            String value = (String) policyReqParameterMap.get(key) ;
				            if (null!= value)
			            	policy.setcUnderwriterAssistant(value);
			            }
			            
			            if(null!= key && key.equalsIgnoreCase("CancelDescription") ) {
				            String value = (String) policyReqParameterMap.get(key) ;
				            if (null!= value)
			            	policy.setCancelDescription(value);
			            }
			               
			        }

				
			}
			

			
			ChangeExpirationDate changeExpirationDate = new ChangeExpirationDate(); 
			changeExpirationDate.setPolicy(policy);

			Gson gson = new Gson();
			String jsonString = gson.toJson(changeExpirationDate); 
			logMessage(LogEntry.SEVERITY_INFO, "updatePolicyResponse() : jsonString : " + jsonString, "");
		
			

			String url = prepareUrl(serverName, UPDATE_TRANSACTION, monthlyRec);
			responseJson = invokeUpdatePolicyTransactionCallRequest(url, monthlyRec, userName, password, jsonString);
			responseDataUpdate = populateResponseObject(responseJson); 
			


		}catch (Exception ex) {
	        LogMinder.getLogMinder().log(
	                LogEntry.SEVERITY_FATAL,
	                getClass().getName(),
	                new Exception().getStackTrace()[0].toString(),
	                ServletConfigUtil.COMPONENT_FRAMEWORK,
	                new Object[] {},
	                "An exception occured in updatePolicyResponse. ",
	                ex,
	                LogMinderDOMUtil.VALUE_MIC);
	     
	        throw new Exception(
	                "An exception occured in updatePolicyResponse.", 
	                ex);
	    }
		return responseDataUpdate;
	}
	
	
	
	
	
	public void updateStatus(String taskId, long requestId ,  User user , String policyRef , String status ) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;




		try {

			String updateSql = " UPDATE PIMIS_POLICY_TRANS_REQ SET PIptr_status = ? WHERE PIPTR_TRANSACTION_ID  = ?   \r\n" + 
					" AND PIPTR_REQUEST_ID = ? ";


			conn = ConnectionPool.getConnection(user);

			pstmt = conn.prepareStatement(updateSql);
			pstmt.setString(1, status);	             
			pstmt.setString(2, policyRef);	     
			pstmt.setLong(3, requestId);	              

			pstmt.executeUpdate(); 
		} catch (Exception e) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					"updateStatus Service",
					e.getStackTrace()[0].toString(),
					ServletConfigUtil.COMPONENT_FRAMEWORK,
					new Object[] { user},
					"Error updateStatus Service",
					e, LogMinderDOMUtil.VALUE_MIC);


		} finally {
			try {
				DBUtil.close(rs, pstmt, conn);
			} catch (SQLException se) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
						"MasterSubOOSEPropagation",
						se.getStackTrace().toString(),
						ServletConfigUtil.COMPONENT_FRAMEWORK,
						new Object[] { user},
						"Error updateStatus Service",
						se, LogMinderDOMUtil.VALUE_MIC);
			}
		}
	}
	
	private void logMessage(int logLevel, String inputMsg, String objMsg) {
		LogMinder.getLogMinder().log(logLevel, getClass().getName(), "populateResponseObject",
				ServletConfigUtil.COMPONENT_PORTAL, new Object[]{objMsg}, 
				inputMsg, null, LogMinderDOMUtil.VALUE_MIC);
	}	
	


}
