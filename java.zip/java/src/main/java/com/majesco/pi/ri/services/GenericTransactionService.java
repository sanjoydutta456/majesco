package com.majesco.pi.ri.services;

import java.io.File;
import java.io.PrintWriter;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.hibernate.validator.internal.util.privilegedactions.GetClassLoader;
import org.w3c.dom.Document;

import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;
import com.coverall.mt.services.SchedulableService;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServicesDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;
import com.coverall.util.XMLUtil;

public class GenericTransactionService extends SchedulableService{

	/** Constant for Temp Folder **/
	private static final String TEMP = "temp";
	private static final Random randomizer = new Random();

	/**
	 * Creates a new UnderwriterUploadService object.
	 *
	 * @throws RemoteException DOCUMENT ME!
	 */
	public GenericTransactionService() throws RemoteException { 
		super();
	}

	/**
	 * DOCUMENT ME!
	 *
	 * @return DOCUMENT ME!
	 */
	public String getComponentName() {
		return ServletConfigUtil.COMPONENT_RI;
	}

	/**
	 * DOCUMENT ME!
	 *
	 * @param request DOCUMENT ME!
	 * @param logName DOCUMENT ME!
	 *
	 * @return DOCUMENT ME!
	 *
	 * @throws Throwable DOCUMENT ME!
	 */




	public Document processTransaction(Document request, String logName)
			throws Throwable {
		// Connection conn = null;
		String data = null;
		String inputFilePath = null;
		String fileType = null;
		String updateOnlyContactInfo = null;
		User user = null;
		String strSave = "Y";
		String webServiceURL = null;
		String userId = null;
		String password = null;
		String maxNumberAttempts = null;

		String taskId = null;

		PrintWriter pw = null;

		int addCount = 0;
		int updateCount = 0;
		long failedAttemptCount = 0;
		int count = 0;
		String taskDescription = null;

		try {
			webServiceURL = (String) ServicesDOMUtil.getRequestParameter(request, "webServiceURL");

			userId = (String) ServicesDOMUtil.getRequestParameter(request, "userId");

			password = (String) ServicesDOMUtil.getRequestParameter(request, "password");

			maxNumberAttempts = (String) ServicesDOMUtil.getRequestParameter(request, "maxNumberAttempts");

			user = ServicesDOMUtil.getUser(request);

			taskId = (String) ServicesDOMUtil.getRequestParameter(request, ServicesDOMUtil.PARAM_ATA_TASK_ID);
			// get the last executed WFH id for a specific task id
		//	int lastExecutedTaskId = getLastFetchId(user, taskId);

			// get all records for notification
			List workFlowNotificatonLst = getRecordsForNotification(user, taskId);
			

			
			// process notify

			for (int i = 0; i < workFlowNotificatonLst.size(); i++) {
				Map getRecordmap = (Map) workFlowNotificatonLst.get(i);


			
				if (null != getRecordmap && getRecordmap.size() > 0) {  

					String requestId = null != getRecordmap.get("PIPTR_REQUEST_ID")? (String) getRecordmap.get("PIPTR_REQUEST_ID"): null;

					String transactionID = null != getRecordmap.get("PIPTR_TRANSACTION_ID")? (String) getRecordmap.get("PIPTR_TRANSACTION_ID"): null;

					String requestType = null != getRecordmap.get("PIPTR_REQUEST_TYPE") ? (String) getRecordmap.get("PIPTR_REQUEST_TYPE"): null;		

					String productCode = null != getRecordmap.get("PIPTR_PRODUCT_CODE") ? (String) getRecordmap.get("PIPTR_PRODUCT_CODE"): null;		

					String entityType = null != getRecordmap.get("PIPTR_ENTITY_TYPE") ? (String) getRecordmap.get("PIPTR_ENTITY_TYPE"): null;		


					String shouldCopayData = null != getRecordmap.get("PIPTR_SHOULD_COPY_DATA") ? (String) getRecordmap.get("PIPTR_SHOULD_COPY_DATA"): null;		


					String copyDataReference = null != getRecordmap.get("PIPTR_COPY_DATA_REFERENCE") ? (String) getRecordmap.get("PIPTR_COPY_DATA_REFERENCE"): null;		


					String transactionCode = null != getRecordmap.get("TRANSACTION_CODE") ? (String) getRecordmap.get("TRANSACTION_CODE"): null;		

					String transactionType = null != getRecordmap.get("TRANSACTION_TYPE") ? (String) getRecordmap.get("TRANSACTION_TYPE"): null;		

					
					String requestGid = null !=getRecordmap.get("PIPTR_REQUEST_GID") ? (String) getRecordmap.get("PIPTR_REQUEST_GID"): "0";
					String isBooked = null !=getRecordmap.get("IS_BOOKED") ? (String) getRecordmap.get("IS_BOOKED"): null; 
					String transactionDesc = null !=getRecordmap.get("PIPTR_PROCESS_TYPE") ? (String) getRecordmap.get("PIPTR_PROCESS_TYPE"): null; 
					
					//PIPTR_AUTO_PROPAPITION_FLAG
					
					String autoPropagationFlag = null != getRecordmap.get("PIPTR_AUTO_PROPAPITION_FLAG") ? (String) getRecordmap.get("PIPTR_AUTO_PROPAPITION_FLAG"): null;		

                    boolean isPolicyBooked = false; 
				   
   
					
					
					GenericTransactionHandler handler = null;
					PolicyTransactionRequest transactionRequest = null;
					Map getRequestParam	= null;


					try {
						if(null!=transactionID ) {

							

							if(null!= requestId && Long.valueOf(requestId) > 0 ) { 

								getRequestParam	=  getRecordsParameters(user, Long.valueOf(requestId));
							}

                            transactionRequest = new PolicyTransactionRequest( Long.valueOf(requestId), transactionID, requestType, productCode, entityType, autoPropagationFlag, shouldCopayData, copyDataReference, transactionCode, transactionType, null,Long.valueOf(requestGid),isBooked,transactionDesc);
                            if(null!= getRequestParam && getRequestParam.size() > 0 ) {
                            	
                            	transactionRequest.setRequestParameterMap(getRequestParam);
                            	
                            	
                            }
                            
                    
                            
							String bookedPolicyReference = null;
 
                          
                            if(null!=transactionRequest && null!=transactionRequest.getRequestParameterMap() && transactionRequest.getRequestParameterMap().size() > 0 )
                            	
                            {
                				
              				  Iterator it = transactionRequest.getRequestParameterMap().keySet().iterator();
              			        while(it.hasNext()) {
              			            String key = (String)it.next();
              			            
              			            if(null!= key && key.equalsIgnoreCase("bookedPolicyReference") ) {
                  			            String value = (String) transactionRequest.getRequestParameterMap().get(key) ;

              			  
              			            	bookedPolicyReference = value ;
              			            	
              			         
              			            }
              			            
              			            
              			               
              			        }
                            	
                            }
                            
                            
                            // if bookedPolicyReference is not null then check if the  booked policy is in force.
                            
                        	handler = new GenericTransactionHandler();
							IGenericTransactionPropagation genericTransaction	= 	handler.getServiceHandler(transactionType, transactionCode);
                            
						
                            
                            
                            if(null!= bookedPolicyReference) {
                            	
                            	isPolicyBooked = checkIfPolicyBooked(user, bookedPolicyReference); 
                            	
                            	
                     
                            	
                            	if(isPolicyBooked) {
                            		if(null!= genericTransaction)
        							genericTransaction.processTransaction(user, transactionRequest, taskId, userId, password);

                            		
                            	} 
                            	
                            }else {
                        		if(null!= genericTransaction)

    							   genericTransaction.processTransaction(user, transactionRequest, taskId, userId, password);

                            	
                            }


						}  


					} catch (Exception e) { 

						LogMinder.getLogMinder().log(LogEntry.SEVERITY_ERROR, getClass().getName(),
								"GenericTransactionService", ServletConfigUtil.COMPONENT_RI,
								new Object[] { taskId }, e.getMessage(), e, LogMinderDOMUtil.VALUE_SCHEDULAR);
						throw e;

					}



				}

			}

		} catch (Exception ex) {

			ServicesDOMUtil.setResponseParameter(request, ServicesDOMUtil.PARAM_STATUS,
					ServicesDOMUtil.VALUE_STATUS_FAIL);
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "",
					ServletConfigUtil.COMPONENT_RI, new Object[] { taskId }, ex.getMessage(), ex,
					LogMinderDOMUtil.VALUE_SCHEDULAR);
			throw new Exception("An exception occured in FileNet Integration.", ex);

		} finally {
			try {

			} catch (Exception ex) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "",
						ServletConfigUtil.COMPONENT_RI, new Object[] { pw }, ex.getMessage(), ex,
						LogMinderDOMUtil.VALUE_SCHEDULAR);
			}
		}
		return request;
	}

	private void setHeader(PrintWriter pw, boolean pageBreak) {
		if (pageBreak) {
			pw.println("<tr style=\"page-break-before: always\">");
		} else {
			pw.println("<tr>");
		}

		pw.println(
				"<TD class=\"PrintTableSortableColumnHeader\"><FONT class=\"TaskLogTableRowHeader\">Underwriter code</FONT></TD>");
		pw.println(
				"<TD class=\"PrintTableSortableColumnHeader\"><FONT class=\"TaskLogTableRowHeader\">Name</FONT></TD>");
		pw.println(
				"<TD class=\"PrintTableSortableColumnHeader\"><FONT class=\"TaskLogTableRowHeader\">Status</FONT></TD>");
		pw.println("</tr>");
	}
	// Deletes all files and subdirectories under dir.
	// Returns true if all deletions were successful.
	// If a deletion fails, the method stops attempting to delete and returns false.
	private boolean deleteDir(File dir) {
		if (dir.isDirectory()) {
			String[] children = dir.list();
			for (int i=0; i<children.length; i++) {
				boolean success = deleteDir(new File(dir, children[i]));
				if (!success) {
					return false;
				}
			}
		}

		// The directory is now empty so delete it
		return dir.delete();
	}
	private String getLog(String code, String name, String status) {
		String str = "<tr class=\"PrintTableCellTextBand\">";
		str += ("<td>" + XMLUtil.escapeStringForXML(code) + "</td>");
		str += ("<td>" + XMLUtil.escapeStringForXML(name) + "</td>");
		str += ("<td>" + status + "</td>");
		str += "</tr>";

		return str;
	}



	private List  getRecordsForNotification(User user,String taskID) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List getRecordList = new ArrayList();
		HashMap recordMap = null;


		try {
			String sql = "  SELECT PIPTR_REQUEST_ID,\r\n" + 
					"  PIPTR_REQUEST_GID ,\r\n" + 
					"  PIPTR_TRANSACTION_ID,\r\n" + 
					"  PIPTR_REQUEST_TYPE,\r\n" + 
					"  PIPTR_PRODUCT_CODE,\r\n" + 
					"  PIPTR_ENTITY_TYPE,\r\n" + 
					"  PIPTR_SHOULD_COPY_DATA,\r\n" + 
					"  PIPTR_COPY_DATA_REFERENCE, PIPTR_PROCESS_TYPE , PIPTR_AUTO_PROPAPITION_FLAG ,\r\n" + 
					"  policy.transaction_code TRANSACTION_CODE,\r\n" + 
					"  k_transaction_management.f_get_simple_transaction_code(policy.transaction_code,policy.renewal_counter) TRANSACTION_TYPE,\r\n" + 
					"  DECODE(k_transaction_management.f_is_booked(PIPTR_ENTITY_TYPE,PIPTR_TRANSACTION_ID),'Y','Y','N' ) IS_BOOKED\r\n" + 
					"FROM PIMIS_POLICY_TRANS_REQ,\r\n" + 
					"  vw_mis_quote_policies policy\r\n" + 
					"WHERE PIptr_status       = 'READY'\r\n" + 
					"AND PIPTR_TRANSACTION_ID = policy.entity_reference\r\n" + 
					"ORDER BY 1 ASC   ";  


			// If last execution id is present then fetch the record after the last executed WFH_ID
			conn = ConnectionPool.getConnection(user);
			pstmt = conn.prepareStatement(sql);

		
			rs = pstmt.executeQuery();

    		while (rs.next()){
    			ResultSetMetaData metaData = rs.getMetaData();
    			String key = null;
    			Map parameters = new HashMap();
    			
    			for (int i = 1; i <= metaData.getColumnCount(); i++) {
    				if(null != metaData.getColumnTypeName(i) && metaData.getColumnTypeName(i).equalsIgnoreCase("DATE")) {
    					
    			    	key = metaData.getColumnName(i);
        				java.sql.Date value = rs.getDate(key); 
        				parameters.put(key, value);

    				}
    				else {
    				 key = metaData.getColumnName(i);
    				 String value = rs.getString(key);
     			     parameters.put(key, value);

    				}
    				

    			}
    			
    			getRecordList.add(parameters);

    		}

		


		} catch (Exception e) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					getClass().getName(),
					e.getStackTrace()[0].toString(),
					ServletConfigUtil.COMPONENT_FRAMEWORK,
					new Object[] { user},
					"Error occured while getRecordsForNotification",
					e, LogMinderDOMUtil.VALUE_SCHEDULAR);


		} finally {
			try {
				DBUtil.close(rs, pstmt, conn);
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}

		return getRecordList;

	}




	private  Map getRecordsParameters(User user,long requestId) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Map parameters = null;

		try {
			String sql = "  select PIPTRP_PARAMETER_NAME , PIPTRP_PARAMETER_VALUE from PIMIS_POL_TRANS_REQ_PARAM where PIPTRP_REQUEST_ID = ?  ";  


			// If last execution id is present then fetch the record after the last executed WFH_ID
			conn = ConnectionPool.getConnection(user);
			pstmt = conn.prepareStatement(sql);
			pstmt.setLong(1, requestId);
		
			rs = pstmt.executeQuery();
			parameters = new HashMap();
    		while (rs.next()){
    		    			            
    			   parameters.put(rs.getString("PIPTRP_PARAMETER_NAME"), rs.getString("PIPTRP_PARAMETER_VALUE"));

    				}
 

		} catch (Exception e) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					getClass().getName(),
					e.getStackTrace()[0].toString(),
					ServletConfigUtil.COMPONENT_FRAMEWORK,
					new Object[] { user},
					"Error occured while getting getRecordsParameters",
					e, LogMinderDOMUtil.VALUE_SCHEDULAR);


		} finally {
			try {
				DBUtil.close(rs, pstmt, conn);
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}

		return parameters;

	}
	

	public static boolean checkIfPolicyBooked(User user,  String entityReference ) throws Exception {
		boolean isPolicyBooked = false;
        Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sqlQuery = " SELECT decode(count(gid),0,'false','true') isPolicyBooked FROM vw_mis_quote_policies,mis_policies\r\n" + 
				"WHERE vw_mis_quote_policies.entity_reference = mis_policies.mpo_policy_reference\r\n" + 
				"AND mis_policies.mpo_book_flag = 'Y'\r\n" + 
				"AND vw_mis_quote_policies.entity_reference = ?\r\n" + 
				"AND booking_status = 'COMPLETE'  ";
		
		try {
			conn = ConnectionPool.getConnection(user);
			stmt = conn.prepareStatement(sqlQuery);
			stmt.setString(1, entityReference);
			rs = stmt.executeQuery();

			while (rs.next()) {
				isPolicyBooked =   new Boolean( rs.getString("isPolicyBooked")).booleanValue();
				
			}

			
			

		} catch (SQLException e) {
			 LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					 "GenericTransactionService",
                     new Exception().getStackTrace()[0].toString(),
                     ServletConfigUtil.COMPONENT_FRAMEWORK,
                     new Object[] { "taskName =" +
                  		   "Booking" },
                     "Error in getStageDesc",
                     e,
                     LogMinderDOMUtil.VALUE_MIC);			
			 e.printStackTrace();
		} finally {
			

			try {
                  DBUtil.close(rs,stmt,conn);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return isPolicyBooked;
	}
	
	
	
	
}
