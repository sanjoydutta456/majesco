package com.majesco.pi.ri.services;

import com.coverall.mt.http.User;


public interface IGenericTransactionPropagation {
	
	public void processTransaction(User user,
			PolicyTransactionRequest transactionRequest, String taskId, String userName, String password ) throws Exception; 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
