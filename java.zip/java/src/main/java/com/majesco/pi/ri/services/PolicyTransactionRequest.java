package com.majesco.pi.ri.services;

import java.util.Map;

public class PolicyTransactionRequest {

	private long requestId = 0L;
	private String transactionID;
	private String requestType;
	private String productCode;
	private String entityType;
	private String autoPropagationFlag;
	private String shouldCopayData;
	private String copyDataReference;
	private String transactionCode;
	private String transactionType;
	private String isReporterRewrite;
	private String isBooked;
	private String taskDescription;

	private Map requestParameterMap ;
	private long requestGid = 0L;
	
	
	
	public String getIsBooked() {
		return isBooked;
	}
	public void setIsBooked(String isBooked) {
		this.isBooked = isBooked;
	}

	public long getRequestGid() {
		return requestGid;
	}
	public void setRequestGid(long requestGid) {
		this.requestGid = requestGid;
	}
	public Map getRequestParameterMap() {
		return requestParameterMap;
	}
	public void setRequestParameterMap(Map requestParameterMap) {
		this.requestParameterMap = requestParameterMap;
	}
	public long getRequestId() {
		return requestId;
	}
	public String getTransactionID() {
		return transactionID;
	}
	public String getRequestType() {
		return requestType;
	}
	public String getProductCode() {
		return productCode;
	}
	public String getEntityType() {
		return entityType;
	}
	public String getAutoPropagationFlag() {
		return autoPropagationFlag;
	}
	public String getShouldCopayData() {
		return shouldCopayData;
	}
	public String getCopyDataReference() {
		return copyDataReference;
	}
	public String getTransactionCode() {
		return transactionCode;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public String getIsReporterRewrite() {
		return isReporterRewrite;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}
	public void setAutoPropagationFlag(String autoPropagationFlag) {
		this.autoPropagationFlag = autoPropagationFlag;
	}
	public void setShouldCopayData(String shouldCopayData) {
		this.shouldCopayData = shouldCopayData;
	}
	public void setCopyDataReference(String copyDataReference) {
		this.copyDataReference = copyDataReference;
	}
	public void setTransactionCode(String transactionCode) {
		this.transactionCode = transactionCode;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public void setIsReporterRewrite(String isReporterRewrite) {
		this.isReporterRewrite = isReporterRewrite;
	}
	
	public String getTaskDescription() {
		return taskDescription;
	}
	public void setTaskDescription(String taskDescription) {
		this.taskDescription = taskDescription;
	}
	
	
	
	public PolicyTransactionRequest(long requestId, String transactionID, String requestType, String productCode,
			String entityType, String autoPropagationFlag, String shouldCopayData, String copyDataReference,
			String transactionCode, String transactionType, String isReporterRewrite, long requestGid, String isBooked, String taskDescription) {
		super();
		this.requestId = requestId;
		this.transactionID = transactionID;
		this.requestType = requestType;
		this.productCode = productCode;
		this.entityType = entityType;
		this.autoPropagationFlag = autoPropagationFlag;
		this.shouldCopayData = shouldCopayData;
		this.copyDataReference = copyDataReference;
		this.transactionCode = transactionCode;
		this.transactionType = transactionType;
		this.isReporterRewrite = isReporterRewrite;
		this.requestGid = requestGid;
		this.isBooked = isBooked;
		this.taskDescription = taskDescription; 
	}

	
	@Override
	public String toString() {
		return "PolicyTransactionRequest [requestId=" + requestId + ", transactionID=" + transactionID
				+ ", requestType=" + requestType + ", productCode=" + productCode + ", entityType=" + entityType
				+ ", autoPropagationFlag=" + autoPropagationFlag + ", shouldCopayData=" + shouldCopayData
				+ ", copyDataReference=" + copyDataReference + ", transactionCode=" + transactionCode
				+ ", transactionType=" + transactionType + ", isReporterRewrite=" + isReporterRewrite + ", isBooked="
				+ isBooked + ", taskDescription=" + taskDescription + ", requestParameterMap=" + requestParameterMap
				+ ", requestGid=" + requestGid + "]";
	}
	
	
	
	
	
	
	
	

	

}
