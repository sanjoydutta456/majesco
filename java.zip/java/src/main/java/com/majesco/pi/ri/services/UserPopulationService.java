/*
 *                 Majesco Code License Notice
 *
 * The contents of this file are subject to the Majesco Code License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License
 *
 * The Original Code is for My Insurance Center. The Initial Developer
 * of the Original Code is Majesco, All Rights Reserved.
 */

package com.majesco.pi.ri.services;

import java.io.PrintWriter;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.w3c.dom.Document;

import java.util.*;
import java.util.Date;

import static com.coverall.mt.security.filters.SecurityConstants.SECURITY_MANAGEMENT_SERVICE_URL;
import static com.coverall.security.common.NsSecurityUtil.UNEXPECTED_EXCEPTION_ERRORCODE;
import static com.coverall.security.ns.commons.constant.AdminRestCallsConstants.NS_GET_ALL;
import static com.coverall.security.ns.commons.constant.AdminRestCallsConstants.NS_GET_ALL_ROLES_OF_USER_BY_ID;
import static com.coverall.security.ns.commons.constant.AdminRestCallsConstants.RESOURCE_BASE_USER;
import static com.coverall.security.util.commons.NsUrlUtils.appendToBaseUrl;
import static com.coverall.security.util.constants.NsMultiTenantConstants.CUSTOMER_KEY_RESTCALL;

import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;
import com.coverall.mt.nexgensecurity.NsRestClientUtil;
import com.coverall.mt.security.filters.SecurityConstants;
import com.coverall.mt.services.SchedulableService;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServicesDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.mt.security.securityclient.servicemgmt.SecurityMgmtServiceRestImpl;
import com.coverall.mt.security.securityclient.servicemgmt.SecurityMgmtServiceRestImplFactory;
import com.coverall.security.client.restimpl.util.SecurityClientUtil;
import com.coverall.security.exceptions.NsSecurityException;
import com.coverall.security.ns.commons.dto.AdminRoleTypeEnum;
import com.coverall.security.ns.commons.dto.NsRolesListDTO;
import com.coverall.security.ns.commons.dto.NsUsersListDTO;
import com.coverall.util.DBUtil;

import java.sql.*; 


public class UserPopulationService extends SchedulableService {

	public String domain;
	

	public UserPopulationService() throws RemoteException {
		super();
	}

	public String getComponentName() {
		return ServletConfigUtil.COMPONENT_RI;
	}

	public Document populateUserDetails(Document request, String logName) throws Throwable {
//        Connection conn              = null;
		User user = null;
		String insertSql = null;
		String insertSqlRoles = null;
		String updateSqlSHL_UW = null;
		Long shlUW_Count = null;
		
		String taskId = null;

		PrintWriter pw = null;

		Long gmu_Id = null;
		String gmu_User_Id = "";
		String gmu_User_Name = "";
		String gmu_Status = "";
		String gmu_Suspended = "";
		Date gmu_User_Created_Date = new Date();
		Long gmu_User_Created_By = null;
		Date gmu_User_Modified_Date = new Date();
		Long gmu_User_Modified_By = null;
		String gmu_Is_User_Modified = "";
		Date gmu_Last_Login_Date = new Date();
		
		Long gmur_Gmu_Id = null;
		Long gmur_Id = null;
		AdminRoleTypeEnum gmur_Role_Type;
		String gmur_Role_Name = "";
		String gmur_Desc = "";
		Date gmur_Created_Date = new Date();
		Long gmur_Created_By = null;
		Date gmur_Modified_Date = new Date();
		Long gmur_Modified_By = null;
		String userCretedDateStr = "";
		String userModifiedDateStr = "";
		String userLastLoginDateStr = "";
		String roleCretedDateStr = "";
		String roleModifiedDateStr = "";
		
		String role = null;
		
		
		ArrayList<String> insrtBatch = new ArrayList<String>();
		ArrayList<String> insrtBatchRoles = new ArrayList<String>();
		ArrayList<String> updateBatchUnderwriters = new ArrayList<String>();
		
		try {

			user = ServicesDOMUtil.getUser(request);
			domain = user.getDomain();
			role     = (String) ServicesDOMUtil.getRequestParameter(request,
                    "roleType");


			NsUsersListDTO nsUsersListDTO = this.getall();
			
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG, getClass().getName(), "UserPopulationService",
					ServletConfigUtil.COMPONENT_RI, new Object[] { nsUsersListDTO.getNsUsersDTOList().size() },
					"User " + user + " in PAS", null, LogMinderDOMUtil.VALUE_MIC);
			
			for (int i = 0; i < nsUsersListDTO.getNsUsersDTOList().size(); i++) {
				
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG, getClass().getName(), "UserPopulationService",
						ServletConfigUtil.COMPONENT_RI, new Object[] { nsUsersListDTO.getNsUsersDTOList().get(i).getId() },
						"User Roles " + nsUsersListDTO.getNsUsersDTOList().get(i).getModifiedDate() + " in PAS", null, LogMinderDOMUtil.VALUE_MIC);
				
				gmu_Id = nsUsersListDTO.getNsUsersDTOList().get(i).getId();
				gmu_User_Id = nsUsersListDTO.getNsUsersDTOList().get(i).getUserId();
				gmu_User_Id = gmu_User_Id.substring(0, gmu_User_Id.indexOf("@"));
				gmu_User_Name = nsUsersListDTO.getNsUsersDTOList().get(i).getName();
				
				if (nsUsersListDTO.getNsUsersDTOList().get(i).getStatus()) {
					gmu_Status = "Y";
				}else {
					gmu_Status = "N";
				}
				
				if (nsUsersListDTO.getNsUsersDTOList().get(i).getSuspended()) {
					gmu_Suspended = "Y";
				}else {
					gmu_Suspended = "N";
				}
				
				gmu_User_Created_Date = nsUsersListDTO.getNsUsersDTOList().get(i).getCreateDate();
				if(gmu_User_Created_Date != null) {
					userCretedDateStr = dateFormatter(gmu_User_Created_Date.toString());
				}
				gmu_User_Created_By = nsUsersListDTO.getNsUsersDTOList().get(i).getCreatedBy();
				gmu_User_Modified_Date = nsUsersListDTO.getNsUsersDTOList().get(i).getModifiedDate();
				if(gmu_User_Modified_Date != null) {
					userModifiedDateStr = dateFormatter(gmu_User_Modified_Date.toString());
				}
				gmu_User_Modified_By = nsUsersListDTO.getNsUsersDTOList().get(i).getModifiedBy();
				
				if (gmu_User_Modified_Date != null) {
					gmu_Is_User_Modified = "Y";
				}else {
					gmu_Is_User_Modified = "N";
				}
				
				if ((gmu_User_Modified_Date != null) && ("Y".equalsIgnoreCase(gmu_Is_User_Modified))) {
					shlUW_Count = getSHLUnderwriterCount(gmu_User_Id, userModifiedDateStr, gmu_User_Name, user);
					if(shlUW_Count > 0) {
						updateSqlSHL_UW = createSHLUpdateStatement(gmu_User_Id, gmu_User_Name, userModifiedDateStr);
						LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG, getClass().getName(), "UserPopulationService",
								ServletConfigUtil.COMPONENT_RI, new Object[] { shlUW_Count },
								"SHL Underwriters shlUW_Count "+shlUW_Count+" updateSqlSHL_UW " + updateSqlSHL_UW + " gmu_User_Id "+gmu_User_Id+" gmu_User_Name "+gmu_User_Name+" userModifiedDateStr "+userModifiedDateStr+" in PAS", null, LogMinderDOMUtil.VALUE_MIC);
						
						if(updateSqlSHL_UW != null && !"".equals(updateSqlSHL_UW)){
							updateBatchUnderwriters.add(updateSqlSHL_UW);
				        	updateSqlSHL_UW = null;
				        }
					}
				}
				
				gmu_Last_Login_Date = nsUsersListDTO.getNsUsersDTOList().get(i).getLastLoginDate();
				if(gmu_Last_Login_Date != null) {
					userLastLoginDateStr = dateFormatter(gmu_Last_Login_Date.toString());
				}
				
				insertSql = createUserInsertStatement(gmu_Id, gmu_User_Id, gmu_User_Name, gmu_Status, gmu_Suspended, userCretedDateStr, gmu_User_Created_By, userModifiedDateStr, gmu_User_Modified_By, gmu_Is_User_Modified, userLastLoginDateStr);
				
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG, getClass().getName(), "UserPopulationService",
						ServletConfigUtil.COMPONENT_RI, new Object[] { nsUsersListDTO.getNsUsersDTOList().size() },
						"User " + user + " gmu_Id "+gmu_Id+" gmu_User_Id "+gmu_User_Id+" gmu_User_Name "+gmu_User_Name+" gmu_Status "+gmu_Status+" gmu_Suspended "+gmu_Suspended+" userCretedDateStr "+userCretedDateStr+" gmu_User_Created_By "+gmu_User_Created_By+" userModifiedDateStr "+userModifiedDateStr+" gmu_User_Modified_By "+gmu_User_Modified_By+" gmu_Is_User_Modified "+gmu_Is_User_Modified+" userLastLoginDateStr "+userLastLoginDateStr+" in PAS getall() method", null, LogMinderDOMUtil.VALUE_MIC);
				
				userCretedDateStr = "";
				userModifiedDateStr = "";
				userLastLoginDateStr = "";
				gmur_Gmu_Id = nsUsersListDTO.getNsUsersDTOList().get(i).getId();
				NsRolesListDTO nsRolesListDTO = this.getallrolesofuserbyid(gmur_Gmu_Id);
				
				for (int j = 0; j < nsRolesListDTO.getNsRolesDTOList().size(); j++) {
					
					LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG, getClass().getName(), "UserPopulationService",
							ServletConfigUtil.COMPONENT_RI, new Object[] { nsRolesListDTO.getNsRolesDTOList().get(j).getId() },
							"User Roles " + nsRolesListDTO.getNsRolesDTOList().get(j).getRoleType() + " in PAS", null, LogMinderDOMUtil.VALUE_MIC);
					
					gmur_Id = nsRolesListDTO.getNsRolesDTOList().get(j).getId();
					gmur_Role_Type = nsRolesListDTO.getNsRolesDTOList().get(j).getRoleType();
					gmur_Role_Name = nsRolesListDTO.getNsRolesDTOList().get(j).getRoleName();
					gmur_Desc = nsRolesListDTO.getNsRolesDTOList().get(j).getDescription();
					gmur_Created_By = nsRolesListDTO.getNsRolesDTOList().get(j).getCreatedBy();
					gmur_Created_Date = nsRolesListDTO.getNsRolesDTOList().get(j).getCreateDate();
					if(gmur_Created_Date != null) {
						roleCretedDateStr = dateFormatter(gmur_Created_Date.toString());
					}
					gmur_Modified_By = nsRolesListDTO.getNsRolesDTOList().get(j).getModifiedBy();
					gmur_Modified_Date = nsRolesListDTO.getNsRolesDTOList().get(j).getModifiedDate();
					if(gmur_Modified_Date != null) {
						roleModifiedDateStr = dateFormatter(gmur_Modified_Date.toString());
					}
					
					
					if (null != role && !"".equalsIgnoreCase(role) && (null != gmur_Role_Name && !"".equalsIgnoreCase(gmur_Role_Name))) {
						if(isRoleType(role, gmur_Role_Name)) {
							insertSqlRoles = createRoleInsertStatement(gmur_Gmu_Id, gmur_Id, gmur_Role_Type, gmur_Role_Name, gmur_Desc, roleCretedDateStr, gmur_Created_By, roleModifiedDateStr, gmur_Modified_By);
							LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG, getClass().getName(), "Inside isRoleType Check",
									ServletConfigUtil.COMPONENT_RI, new Object[] { nsRolesListDTO.getNsRolesDTOList().size() },
									"User Roles " + user + " roleType "+role+" gmur_Gmu_Id "+gmur_Gmu_Id+" gmur_Id "+gmur_Id+" gmur_Role_Type "+gmur_Role_Type+" gmur_Role_Name "+gmur_Role_Name+" gmur_Desc "+gmur_Desc+" roleCretedDateStr "+roleCretedDateStr+" gmur_Created_By "+gmur_Created_By+" roleModifiedDateStr "+roleModifiedDateStr+" gmur_Modified_By "+gmur_Modified_By+" in PAS getallrolesofuserbyid() method", null, LogMinderDOMUtil.VALUE_MIC);
						}
					}
					
					/*if (null != role && !"".equalsIgnoreCase(role)) {
						if(role.equalsIgnoreCase(gmur_Role_Name)) {
							insertSqlRoles = createRoleInsertStatement(gmur_Gmu_Id, gmur_Id, gmur_Role_Type, gmur_Role_Name, gmur_Desc, roleCretedDateStr, gmur_Created_By, roleModifiedDateStr, gmur_Modified_By);
							LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG, getClass().getName(), "Inside Equals Check",
									ServletConfigUtil.COMPONENT_RI, new Object[] { nsRolesListDTO.getNsRolesDTOList().size() },
									"User Roles " + user + " roleType "+role+" gmur_Gmu_Id "+gmur_Gmu_Id+" gmur_Id "+gmur_Id+" gmur_Role_Type "+gmur_Role_Type+" gmur_Role_Name "+gmur_Role_Name+" gmur_Desc "+gmur_Desc+" roleCretedDateStr "+roleCretedDateStr+" gmur_Created_By "+gmur_Created_By+" roleModifiedDateStr "+roleModifiedDateStr+" gmur_Modified_By "+gmur_Modified_By+" in PAS getallrolesofuserbyid() method", null, LogMinderDOMUtil.VALUE_MIC);
						}
					}*/
										
					LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG, getClass().getName(), "After isRoleType Check",
							ServletConfigUtil.COMPONENT_RI, new Object[] { nsRolesListDTO.getNsRolesDTOList().size() },
							"User Roles " + user + " roleType "+role+" gmur_Gmu_Id "+gmur_Gmu_Id+" gmur_Id "+gmur_Id+" gmur_Role_Type "+gmur_Role_Type+" gmur_Role_Name "+gmur_Role_Name+" gmur_Desc "+gmur_Desc+" roleCretedDateStr "+roleCretedDateStr+" gmur_Created_By "+gmur_Created_By+" roleModifiedDateStr "+roleModifiedDateStr+" gmur_Modified_By "+gmur_Modified_By+" in PAS getallrolesofuserbyid() method", null, LogMinderDOMUtil.VALUE_MIC);
					
					roleCretedDateStr = "";
					roleModifiedDateStr = "";
					if(insertSqlRoles != null && !"".equals(insertSqlRoles)){
						insrtBatchRoles.add(insertSqlRoles);
						insertSqlRoles = null;
			        }
					
					
				}
				
				if(insertSql != null && !"".equals(insertSql)){
		        	insrtBatch.add(insertSql);
		        	insertSql = null;
		        }
				
			}
			
			processBatchInsert (user,insrtBatch, "PI_MIC_USERS");
			processBatchInsert (user,insrtBatchRoles, "PI_MIC_USER_ROLES");
			
			if(updateBatchUnderwriters.size() > 0) {
				processBatchInsert (user,updateBatchUnderwriters, "");
			}

			LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG, getClass().getName(), "UserPopulationService",
					ServletConfigUtil.COMPONENT_RI, new Object[] { nsUsersListDTO.toString() },
					"User " + user + " in PAS", null, LogMinderDOMUtil.VALUE_MIC);

		} catch (Exception ex) {

			ServicesDOMUtil.setResponseParameter(request, ServicesDOMUtil.PARAM_STATUS,
					ServicesDOMUtil.VALUE_STATUS_FAIL);
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "processWFLNotification",
					ServletConfigUtil.COMPONENT_RI, new Object[] { taskId }, ex.getMessage(), ex,
					LogMinderDOMUtil.VALUE_SCHEDULAR);
		} finally {
			try {

			} catch (Exception ex) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "uploadProducers",
						ServletConfigUtil.COMPONENT_RI, new Object[] { pw }, ex.getMessage(), ex,
						LogMinderDOMUtil.VALUE_PRODUCER_UPLOAD);
			}
		}
		return request;
	}

	private NsUsersListDTO getall() throws NsSecurityException {
		NsUsersListDTO returnUsersDTOList = new NsUsersListDTO();
		SecurityMgmtServiceRestImpl service = (SecurityMgmtServiceRestImpl) SecurityMgmtServiceRestImplFactory
				.getInstance(SecurityConstants.getValue(domain, SECURITY_MANAGEMENT_SERVICE_URL), domain,
						NsRestClientUtil.MIC_SERVICE_NAME);

		try {
			String urlToHit = appendToBaseUrl(
					appendToBaseUrl(service.getRestUrlToSecurityService(), RESOURCE_BASE_USER), NS_GET_ALL);
			// urlToHit = appendToBaseUrl(urlToHit);
			urlToHit = urlToHit.replace(CUSTOMER_KEY_RESTCALL, domain);

			LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG, getClass().getName(), "UserPopulationService",
					ServletConfigUtil.COMPONENT_RI, new Object[] { returnUsersDTOList.toString() },
					"urlToHit " + urlToHit + " in getall()", null, LogMinderDOMUtil.VALUE_MIC);

			returnUsersDTOList = service.getRestClientUtil().getJSONObjectFromService(NsUsersListDTO.class, urlToHit);
			if (returnUsersDTOList == null || returnUsersDTOList.hasErrors()) {
				throw SecurityClientUtil.createSecurityException(returnUsersDTOList);
			}
		} catch (NsSecurityException se) {
			throw se;
		} catch (Exception e) {
			throw new NsSecurityException(UNEXPECTED_EXCEPTION_ERRORCODE);
		}

		return returnUsersDTOList;
	}
	
	private NsRolesListDTO getallrolesofuserbyid(Long id) throws NsSecurityException {
		NsRolesListDTO returnRolesDTOList = new NsRolesListDTO();
		SecurityMgmtServiceRestImpl service = (SecurityMgmtServiceRestImpl) SecurityMgmtServiceRestImplFactory
				.getInstance(SecurityConstants.getValue(domain, SECURITY_MANAGEMENT_SERVICE_URL), domain,
						NsRestClientUtil.MIC_SERVICE_NAME);

		try {
			String urlToHitforRoles = appendToBaseUrl(
					appendToBaseUrl(service.getRestUrlToSecurityService(), RESOURCE_BASE_USER), NS_GET_ALL_ROLES_OF_USER_BY_ID);
			String urlAppender = id+"";
			urlToHitforRoles = appendToBaseUrl(urlToHitforRoles, urlAppender);
			urlToHitforRoles = urlToHitforRoles.replace(CUSTOMER_KEY_RESTCALL, domain);

			LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG, getClass().getName(), "UserPopulationService",
					ServletConfigUtil.COMPONENT_RI, new Object[] { returnRolesDTOList.toString() },
					"urlToHitforRoles " + urlToHitforRoles + " in getall()", null, LogMinderDOMUtil.VALUE_MIC);

			returnRolesDTOList = service.getRestClientUtil().getJSONObjectFromService(NsRolesListDTO.class, urlToHitforRoles);
			if (returnRolesDTOList == null || returnRolesDTOList.hasErrors()) {
				throw SecurityClientUtil.createSecurityException(returnRolesDTOList);
			}
		} catch (NsSecurityException se) {
			throw se;
		} catch (Exception e) {
			throw new NsSecurityException(UNEXPECTED_EXCEPTION_ERRORCODE);
		}

		return returnRolesDTOList;
	}

	
	public static String createUserInsertStatement(Long gmu_Id, String gmu_User_Id, String gmu_User_Name, String gmu_Status, String gmu_Suspended, String gmu_User_Created_Date, Long gmu_User_Created_By, String gmu_User_Modified_Date, Long gmu_User_Modified_By, String gmu_Is_User_Modified, String gmu_Last_Login_Date)
			throws Exception {
		StringBuffer sqlQuery = new StringBuffer();
		sqlQuery.append(" INSERT INTO PI_MIC_USERS (PIMUS_ID, PIMUS_USER_ID, PIMUS_USER_NAME, PIMUS_STATUS, PIMUS_SUSPENDED, PIMUS_USER_CREATED_DATE, PIMUS_USER_CREATED_BY, PIMUS_USER_MODIFIED_DATE, PIMUS_USER_MODIFIED_BY, PIMUS_IS_USER_MODIFIED, PIMUS_LAST_LOGIN_DATE) VALUES (  ");
		sqlQuery.append(gmu_Id);
		sqlQuery.append(", '");
		sqlQuery.append(gmu_User_Id);
		sqlQuery.append("', '");
		sqlQuery.append(gmu_User_Name);
		sqlQuery.append("', '");
		sqlQuery.append(gmu_Status);
		sqlQuery.append("', '");
		sqlQuery.append(gmu_Suspended);
		sqlQuery.append("', to_date('");
		sqlQuery.append(gmu_User_Created_Date);
		sqlQuery.append("', 'DD-MON-RR'), ");
		sqlQuery.append(gmu_User_Created_By);
		sqlQuery.append(", to_date('");
		sqlQuery.append(gmu_User_Modified_Date);
		sqlQuery.append("', 'DD-MON-RR'), ");
		sqlQuery.append(gmu_User_Modified_By);
		sqlQuery.append(", '");
		sqlQuery.append(gmu_Is_User_Modified);
		sqlQuery.append("', to_date('");
		sqlQuery.append(gmu_Last_Login_Date);
		sqlQuery.append("', 'DD-MON-RR') ");
		sqlQuery.append(") ");

		return sqlQuery.toString();
		
	}
	
	
	public static String createRoleInsertStatement(Long gmur_Gmu_Id, Long gmur_Id, AdminRoleTypeEnum gmur_Role_Type, String gmur_Role_Name, String gmur_Desc, String gmur_Created_Date, Long gmur_Created_By, String gmur_Modified_Date, Long gmur_Modified_By)
			throws Exception {
		StringBuffer sqlQuery = new StringBuffer();
		sqlQuery.append(" INSERT INTO PI_MIC_USER_ROLES (PIMUR_PIMUS_ID, PIMUR_ID, PIMUR_ROLE_TYPE, PIMUR_ROLE_NAME, PIMUR_DESCRIPTION, PIMUR_ROLE_CREATED_DATE, PIMUR_ROLE_CREATED_BY, PIMUR_ROLE_MODIFIED_DATE, PIMUR_ROLE_MODIFIED_BY) VALUES (  ");
		sqlQuery.append(gmur_Gmu_Id);
		sqlQuery.append(", ");
		sqlQuery.append(gmur_Id);
		sqlQuery.append(", '");
		sqlQuery.append(gmur_Role_Type);
		sqlQuery.append("', '");
		sqlQuery.append(gmur_Role_Name);
		sqlQuery.append("', '");
		sqlQuery.append(gmur_Desc);
		sqlQuery.append("', to_date('");
		sqlQuery.append(gmur_Created_Date);
		sqlQuery.append("', 'DD-MON-RR'), ");
		sqlQuery.append(gmur_Created_By);
		sqlQuery.append(", to_date('");
		sqlQuery.append(gmur_Modified_Date);
		sqlQuery.append("', 'DD-MON-RR'), ");
		sqlQuery.append(gmur_Modified_By);
		sqlQuery.append(") ");

		return sqlQuery.toString();
		
	}
	
	public static String createSHLUpdateStatement(String gmu_User_Id, String gmu_User_Name, String userModifiedDateStr)
			throws Exception {
		StringBuffer sqlQuery = new StringBuffer();
		sqlQuery.append(" UPDATE SHL_UNDERWRITERS SET SUN_UNDERWRITER_NAME = '");
		sqlQuery.append(gmu_User_Name);
		sqlQuery.append("', SUN_DATE_MODIFIED = to_date('");
		sqlQuery.append(userModifiedDateStr);
		sqlQuery.append("', 'DD-MON-RR') WHERE SUN_USER_ID = '");
		sqlQuery.append(gmu_User_Id);
		sqlQuery.append("' ");
		
		return sqlQuery.toString();
		
	}
	
	public static String dateFormatter(String dateStr) throws ParseException {
		SimpleDateFormat parser = new SimpleDateFormat("EEE MMM d HH:mm:ss zzz yyyy");
		Date date = parser.parse(dateStr);
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");
		String formattedDate = formatter.format(date);
		return formattedDate;
	}
	
	public static boolean isRoleType(String role, String roleName) {
		if ( role.toLowerCase().indexOf(roleName.toLowerCase()) != -1 ) {
				return true;
			} else {
				return false;
			}
	}
	
    public static void processBatchInsert (User user, List<String> queryList, String tableName) throws Exception{
    	
        Connection connection               = null;
        Statement statement = null;
        String sql = "";
        try {
            connection = ConnectionPool.getOracleConnection(user);
            
            if(null != tableName && !"".equalsIgnoreCase(tableName)) {
            	sql = "DELETE FROM "+tableName;
                statement  = connection.createStatement();
                statement.execute(sql);
                statement.close();
                statement = null;            	
            }
            
            statement  = connection.createStatement();
            for(String  insrtSql :  queryList){
            	statement.addBatch(insrtSql);	
            }
            
            LogMinder.getLogMinder().log(
                    LogEntry.SEVERITY_DEBUG,
                    UserPopulationService.class.getName(),
                    "processBatchInsert",
                    ServletConfigUtil.COMPONENT_FRAMEWORK,
                    new Object[] { queryList },
                    "Before executeBatch and after DELETE TABLE SQL "+sql,
                    null, LogMinderDOMUtil.VALUE_MIC);
            
            statement.executeBatch();
        } catch (Exception ex) {
            LogMinder.getLogMinder().log(
                    LogEntry.SEVERITY_FATAL,
                    UserPopulationService.class.getName(),
                    "processBatchInsert",
                    ServletConfigUtil.COMPONENT_FRAMEWORK,
                    new Object[] { queryList },
                    "Failed to process batch insert ",
                    ex,
                    LogMinderDOMUtil.VALUE_MIC);
            throw ex;
        } finally {
            DBUtil.close(null, statement, connection);
        }
    }
    
    private Long getSHLUnderwriterCount(String userID, String modifiedDate, String userName, User user) {
        Long userCount = (long) 0;
        String sequenceQuery = "";
        PreparedStatement pst = null;
        Connection con = null;
        try {
                con = ConnectionPool.getConnection(user);
                sequenceQuery = "SELECT \r\n" +
                				"					COUNT(*) count \r\n" +
                				"					FROM SHL_UNDERWRITERS \r\n" +
                				"					WHERE sun_user_id = ? \r\n" +
                				"					AND ((sun_date_modified is null and to_char(sun_date_created, 'DD-MON-YY') <= ? and sun_underwriter_name <> ?) \r\n" +
                				"					OR (sun_date_modified is not null and to_char(sun_date_modified, 'DD-MON-YY') <= ? and sun_underwriter_name <> ?))";
                
                pst = con.prepareStatement(sequenceQuery);
                pst.setString(1, userID);
                pst.setString(2, modifiedDate);
                pst.setString(3, userName);
                pst.setString(4, modifiedDate);
                pst.setString(5, userName);
                
                LogMinder
                .getLogMinder()
                .log(LogEntry.SEVERITY_DEBUG,
                		UserPopulationService.class.getName(),
                                "getSHLUnderwriterDate",
                                ServletConfigUtil.COMPONENT_FRAMEWORK,
                                new Object[] { sequenceQuery },
                                "SHL Underwriter Count in UserPopulationService : ",
                                null, LogMinderDOMUtil.VALUE_MIC);
                ResultSet rs = pst.executeQuery();
                while (rs.next()) {
                	userCount = Long.parseLong(rs.getString("count"));
                }
        } catch (SQLException e) {
                LogMinder
                                .getLogMinder()
                                .log(LogEntry.SEVERITY_FATAL,
                                		UserPopulationService.class.getName(),
                                                "getSHLUnderwriterDate",
                                                ServletConfigUtil.COMPONENT_FRAMEWORK,
                                                new Object[] { sequenceQuery },
                                                "Error getting SHL Underwriter Count in UserPopulationService Exception : ",
                                                e, LogMinderDOMUtil.VALUE_MIC);
        } catch (Exception e) {
                LogMinder
                .getLogMinder()
                .log(LogEntry.SEVERITY_FATAL,
                		UserPopulationService.class.getName(),
                                "getSHLUnderwriterDate",
                                ServletConfigUtil.COMPONENT_FRAMEWORK,
                                new Object[] { sequenceQuery },
                                "Error getting SHL Underwriter Count in UserPopulationService Exception : ",
                                e, LogMinderDOMUtil.VALUE_MIC);
        } finally {
                try {
                        DBUtil.close(null, pst, con);
                } catch (Exception e) {
                        LogMinder.getLogMinder().log(
                                        LogEntry.SEVERITY_FATAL,
                                        UserPopulationService.class.getName(),
                                        "getSHLUnderwriterDate",
                                        ServletConfigUtil.COMPONENT_FRAMEWORK,
                                        new Object[] { sequenceQuery },
                                        "Error closing DB Objects while getting SHL Underwriter Count in UserPopulationService Exception : "
                                                        + e.getMessage(), e, LogMinderDOMUtil.VALUE_MIC);
                }
        }
        return userCount;
}


}
