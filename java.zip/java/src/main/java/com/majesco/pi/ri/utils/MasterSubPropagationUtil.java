package com.majesco.pi.ri.utils;

import java.io.IOException;
import java.net.InetAddress;
import java.rmi.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.web.util.UriComponentsBuilder;

import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.Base64;
import com.coverall.util.DBUtil;
import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;
import com.majesco.pi.ri.pojo.ChangeExpirationDate;
import com.majesco.pi.ri.pojo.ErrorObject;
import com.majesco.pi.ri.pojo.Policy;
import com.majesco.pi.ri.pojo.TransactionAttributesVO;
import com.majesco.pi.ri.pojo.TransactionResponseData;

public class MasterSubPropagationUtil {
	
	protected static final String MIC_API = "/mic/microservices/";
	protected static final String START_NEW_TRANSACTION = "startNewTransaction";
	protected static final String VALIDATE_TRANSACTION = "validateTransaction";
	protected static final String VALIDATE_TRANSACTION_ACK = "validateTransactionAck";

	protected static final String COMPLETE_TRANSACTION = "completeTransaction";
	protected static final String UPDATE_TRANSACTION = "update";
	protected static final String SUSPEND_TRANSACTION = "suspendTransaction";
	protected static final String BOOK_ALL_REVISIONS = "oose/book-all-revisions";
	protected static final String MIC_API_BOOKALL = "/mic/api/oas/policy-common/v1/";


	
	
	//Get Policy
	
	protected static final String GET_POLICY = "Policy";

	// Get Producer
	protected static final String GET_PRODUCER = "Producer";
	
	
	
	protected static String machineURL  = null;

	protected String logName = LogMinderDOMUtil.VALUE_WEBSERVICES;

	
	protected static final String END_POIMT_DELIM = "/";
	
	
	
	//Prepare the URL & Params
	protected String prepareUrl(String serverName, String RequestType, TransactionAttributesVO reporterRecords) 
			throws UnknownHostException {
		String url = null;
		UriComponentsBuilder builder = null;

		if (null != RequestType && RequestType.equalsIgnoreCase(START_NEW_TRANSACTION)) {
			url = serverName + MIC_API + START_NEW_TRANSACTION;
			builder = UriComponentsBuilder.fromUriString(url);
			builder.queryParam(reporterRecords.getEntityTypeParam(), reporterRecords.getEntityType());
			builder.queryParam(reporterRecords.getSendHiddenAttributesParam(), reporterRecords.getSendHiddenAttributes());
			builder.queryParam(reporterRecords.getTrnansationNameParam(), reporterRecords.getTransactionName());
			builder.queryParam(reporterRecords.getProductCodeParam(), reporterRecords.getProductCode());
			builder.queryParam(reporterRecords.getTransactionIdParam(), reporterRecords.getTrnsactionID());
			builder.queryParam(reporterRecords.getUseOptimizedFlowParam(), "true");
		

			url = builder.build().toUriString();
			

		} else if (null != RequestType && RequestType.equalsIgnoreCase(BOOK_ALL_REVISIONS)) {

			url = serverName + MIC_API_BOOKALL + reporterRecords.getEntityType().toLowerCase()  + END_POIMT_DELIM + "{PolicyId}" + END_POIMT_DELIM +BOOK_ALL_REVISIONS;

			builder = UriComponentsBuilder.fromUriString(url);
			Map<String, String> urlParams = new HashMap<>();
			urlParams.put("PolicyId", String.valueOf(reporterRecords.getTargetPolicyReference()));

			url = builder.buildAndExpand(urlParams).toUri().toString();    


		} else if (null != RequestType && RequestType.equalsIgnoreCase(VALIDATE_TRANSACTION)) {

			builder = UriComponentsBuilder.fromUriString(serverName + MIC_API + VALIDATE_TRANSACTION);
			builder.queryParam(reporterRecords.getUseOptimizedFlowParam(), "true");
			builder.queryParam(reporterRecords.getSendHiddenAttributesParam(), reporterRecords.getSendHiddenAttributes());

			url = builder.build().toUriString(); 


		} else if (null != RequestType && RequestType.equalsIgnoreCase(VALIDATE_TRANSACTION_ACK)) {

			builder = UriComponentsBuilder.fromUriString(serverName + MIC_API + VALIDATE_TRANSACTION);
			builder.queryParam(reporterRecords.getUseOptimizedFlowParam(), "true");
			builder.queryParam(reporterRecords.getSendHiddenAttributesParam(), reporterRecords.getSendHiddenAttributes());
			builder.queryParam("aknowledgeAlert", "Y");

			url = builder.build().toUriString(); 


		} else if (null != RequestType && RequestType.equalsIgnoreCase(COMPLETE_TRANSACTION)) {

			builder = UriComponentsBuilder.fromUriString(serverName + MIC_API + COMPLETE_TRANSACTION);
			builder.queryParam(reporterRecords.getUseOptimizedFlowParam(), "true");
			builder.queryParam(reporterRecords.getSendHiddenAttributesParam(), reporterRecords.getSendHiddenAttributes());

			url = builder.build().toUriString();


		} else if (null != RequestType && RequestType.equalsIgnoreCase(SUSPEND_TRANSACTION)) {

			builder = UriComponentsBuilder.fromUriString(serverName + MIC_API + SUSPEND_TRANSACTION);
			builder.queryParam(reporterRecords.getSendHiddenAttributesParam(), reporterRecords.getSendHiddenAttributes());

			url = builder.build().toUriString();


		} else if (null != RequestType && RequestType.equalsIgnoreCase(UPDATE_TRANSACTION)){

			url = serverName + MIC_API + "Policy" + END_POIMT_DELIM + "{PolicyId}" + END_POIMT_DELIM;

			builder = UriComponentsBuilder.fromUriString(url);
			builder.queryParam(reporterRecords.getUseOptimizedFlowParam(), "true");
			builder.queryParam(reporterRecords.getSendHiddenAttributesParam(), reporterRecords.getSendHiddenAttributes());

			Map<String, String> urlParams = new HashMap<>();
			urlParams.put("PolicyId", String.valueOf(reporterRecords.getNewPolicyGid()));

			url = builder.buildAndExpand(urlParams).toUri().toString(); 
			
			
        }else if (null != RequestType && RequestType.equalsIgnoreCase(GET_PRODUCER)){ 

			url = serverName + MIC_API + "Policy" + END_POIMT_DELIM + "{PolicyId}" + END_POIMT_DELIM+ GET_PRODUCER;
	
			builder = UriComponentsBuilder.fromUriString(url);
			builder.queryParam(reporterRecords.getUseOptimizedFlowParam(), "true");
			builder.queryParam(reporterRecords.getSendHiddenAttributesParam(), reporterRecords.getSendHiddenAttributes());

			Map<String, String> urlParams = new HashMap<>();
			urlParams.put("PolicyId", String.valueOf(reporterRecords.getNewPolicyGid()));
			url = builder.buildAndExpand(urlParams).toUri().toString(); 
			
			
        } else if (null != RequestType && RequestType.equalsIgnoreCase(GET_POLICY)){

			url = serverName + MIC_API + "Policy" + END_POIMT_DELIM + "{PolicyId}";

			builder = UriComponentsBuilder.fromUriString(url);
			builder.queryParam(reporterRecords.getUseOptimizedFlowParam(), "true");
			builder.queryParam(reporterRecords.getSendHiddenAttributesParam(), reporterRecords.getSendHiddenAttributes());

			Map<String, String> urlParams = new HashMap<>();
			urlParams.put("PolicyId", String.valueOf(reporterRecords.getNewPolicyGid()));

			url = builder.buildAndExpand(urlParams).toUri().toString(); 
			

		}
		

	LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG,getClass().getName(), "prepareUrl",
	    				ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[]{"url", url}, 
	    				"prepareUrl", null, LogMinderDOMUtil.VALUE_WEBSERVICES);
		
		return url;
	}
		
	  protected void setGetHeaders(HttpGet getRequest, TransactionAttributesVO monthlyRec, String userName, String password)
	  {

		  String authString = userName + ":" + password;
		  String authStringEnc = encodeStr(authString);

		  getRequest.setHeader(HttpHeaders.CONTENT_TYPE, "application/json");
		  getRequest.setHeader(HttpHeaders.ACCEPT, "application/json");
		  getRequest.setHeader(HttpHeaders.AUTHORIZATION, "Basic " + authStringEnc);

		  
		  if(null!= monthlyRec && null!= monthlyRec.getClientId()) {
		  
		  getRequest.setHeader("clientID", monthlyRec.getClientId());
		  
		  }
		  
		  if(null!= monthlyRec && null!= monthlyRec.getNewPolicyReference()) {
		  getRequest.setHeader("transactionID", monthlyRec.getNewPolicyReference());
		  
		  }
		  getRequest.setHeader("optimizedFlow", "Y");
		  getRequest.setHeader("sendHiddenAttributes", "N"); 



	  }
	
      
	
	  
	  
	  protected void setPutHeaders(HttpPut putRequest, TransactionAttributesVO monthlyRec, String userName, String password){

		  String authString = userName + ":" + password;
		  String authStringEnc = encodeStr(authString);

		  putRequest.setHeader(HttpHeaders.CONTENT_TYPE, "application/json");
		  putRequest.setHeader(HttpHeaders.ACCEPT, "application/json");
		  putRequest.setHeader(HttpHeaders.AUTHORIZATION, "Basic " + authStringEnc);

		  putRequest.setHeader("clientID", monthlyRec.getClientId());
		  putRequest.setHeader("transactionID", monthlyRec.getNewPolicyReference());
		  putRequest.setHeader("optimizedFlow", "Y"); 
		  putRequest.setHeader("sendHiddenAttributes", "N"); 



	  }
	  
		protected static String encodeStr(String authString) {
	        
	        StringBuffer base64DecodedArr = Base64.byteArrayToBase64Buffer(authString.getBytes());
	        String authStringEnc = new String(base64DecodedArr);
	        return authStringEnc;
	    }
		
		
		
		
		protected String invokeStartNewTransactionCallRequest(String url, TransactionAttributesVO monthlyRec, String userName,
				String password) throws Exception{
			String responseJson = "";

			try {

				HttpGet getRequest = new HttpGet(url);
				setGetHeaders(getRequest, monthlyRec, userName, password);
				DefaultHttpClient httpClient = new DefaultHttpClient();
				HttpResponse response = httpClient.execute(getRequest);
				responseJson = EntityUtils.toString(response.getEntity());
				logMessage(LogEntry.SEVERITY_INFO, "invokeStartNewTransactionCallRequest() : responseJson : " + responseJson, "");
			}catch (Exception ex) {
		        LogMinder.getLogMinder().log(
		                LogEntry.SEVERITY_FATAL,
		                getClass().getName(),
		                new Exception().getStackTrace()[0].toString(),
		                ServletConfigUtil.COMPONENT_FRAMEWORK,
		                new Object[] {},
		                "An exception occured in invokeStartNewTransactionCallRequest. ",
		                ex,
		                LogMinderDOMUtil.VALUE_MIC);
		     
		        throw new Exception(
		                "An exception occured in invokeStartNewTransactionCallRequest.",
		                ex);
		    }
			return responseJson;
		}
		

		
		
		protected TransactionResponseData startNewTransactionResponse(String serverName, TransactionAttributesVO monthlyRec, String userName,
				String password) throws Exception{
			String responseJson = "";
			TransactionResponseData responseDataInitiation = null;

			try {

				String url = prepareUrl(serverName, START_NEW_TRANSACTION, monthlyRec);
				responseJson = invokeStartNewTransactionCallRequest(url, monthlyRec, userName, password);
				if (responseJson != null && !responseJson.isEmpty()) {
					responseDataInitiation = populateResponseObject(responseJson);
					logMessage(LogEntry.SEVERITY_INFO, "startNewTransactionResponse() : TransactionResponseData : " + responseDataInitiation.toString(), "");
				}
				
				
				if (null!= responseDataInitiation && responseDataInitiation.getSourceSystemID() != null ) {
					monthlyRec.setNewPolicyGid(Long.valueOf(responseDataInitiation.getSourceSystemID()));
					monthlyRec.setNewPolicyReference(responseDataInitiation.getTransactionId());
					monthlyRec.setClientId(responseDataInitiation.getClientId());
					}else {
						if (null!= responseDataInitiation && responseDataInitiation.getGid() != null ) {
							monthlyRec.setNewPolicyGid(Long.valueOf(responseDataInitiation.getGid()));
							monthlyRec.setNewPolicyReference(responseDataInitiation.getTransactionId());
							monthlyRec.setClientId(responseDataInitiation.getClientId()); 
						}
					}

				if(null!= monthlyRec && null == monthlyRec.getNewPolicyReference()) {
					monthlyRec.setNewPolicyReference(responseDataInitiation.getPolicyReference());

				}
				
				
				
				
				
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG, getClass().getName(), "startNewTransactionResponse",
						ServletConfigUtil.COMPONENT_FRAMEWORK,
						new Object[] {"url"  + url +  " TransactionAttributesVO "+  monthlyRec + "serverName " 
								+  "responseJson" +responseJson, "TransactionResponseData" + responseDataInitiation.toString() },
						"startNewTransactionResponse", null, LogMinderDOMUtil.VALUE_WEBSERVICES);

			}catch (Exception ex) {
			        LogMinder.getLogMinder().log(
			                LogEntry.SEVERITY_FATAL,
			                getClass().getName(),
			                new Exception().getStackTrace()[0].toString(),
			                ServletConfigUtil.COMPONENT_FRAMEWORK,
			                new Object[] {},
			                "An exception occured in startNewTransactionResponse. ",
			                ex,
			                LogMinderDOMUtil.VALUE_MIC);
			     
			        throw new Exception(
			                "An exception occured in startNewTransactionResponse.",
			                ex);
			    }
			return responseDataInitiation;
		}

		
		protected String invokeUpdatePolicyTransactionCallRequest(String url, TransactionAttributesVO monthlyRec, String userName,
				String password, String jsonRequest) throws Exception {
			String responseJson = "";

			try {
				HttpPut putRequest = new HttpPut(url);
				setPutHeaders(putRequest, monthlyRec, userName, password);
				DefaultHttpClient httpClient = new DefaultHttpClient();
				logMessage(LogEntry.SEVERITY_INFO, "invokeUpdatePolicyTransactionCallRequest() : jsonRequest : " + jsonRequest, "");
				putRequest.setEntity(new StringEntity(jsonRequest));
				HttpResponse response = httpClient.execute(putRequest);
				responseJson = EntityUtils.toString(response.getEntity());

			}catch (Exception ex) {
		        LogMinder.getLogMinder().log(
		                LogEntry.SEVERITY_FATAL,
		                getClass().getName(),
		                new Exception().getStackTrace()[0].toString(),
		                ServletConfigUtil.COMPONENT_FRAMEWORK,
		                new Object[] {},
		                "An exception occured in invokeUpdatePolicyTransactionCallRequest. ",
		                ex,
		                LogMinderDOMUtil.VALUE_MIC);
		     
		        throw new Exception(
		                "An exception occured in invokeUpdatePolicyTransactionCallRequest.",
		                ex);
		    }
			return responseJson;
		}
		
		
		
		
		protected TransactionResponseData updatePolicyResponse(String serverName, TransactionAttributesVO monthlyRec, String userName,
				String password) throws Exception {
			String responseJson = "";
			TransactionResponseData responseDataUpdate = null;

			try {

				Policy policy = new Policy();
				
			
				
				ChangeExpirationDate changeExpirationDate = new ChangeExpirationDate();
				changeExpirationDate.setPolicy(policy); 

				Gson gson = new Gson();
				String jsonString = gson.toJson(changeExpirationDate); 



				String url = prepareUrl(serverName, UPDATE_TRANSACTION, monthlyRec);
				responseJson = invokeUpdatePolicyTransactionCallRequest(url, monthlyRec, userName, password, jsonString);
				responseDataUpdate = populateResponseObject(responseJson);



				LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG, getClass().getName(), "updatePolicyResponse",
						ServletConfigUtil.COMPONENT_FRAMEWORK,
						new Object[] {"url"  + url +  " TransactionAttributesVO "+  monthlyRec + "serverName " 
								+  "responseJson" +responseJson, "TransactionResponseData" + responseDataUpdate.toString() },
						"updatePolicyResponse", null, LogMinderDOMUtil.VALUE_WEBSERVICES);


			}catch (Exception ex) {
		        LogMinder.getLogMinder().log(
		                LogEntry.SEVERITY_FATAL,
		                getClass().getName(),
		                new Exception().getStackTrace()[0].toString(),
		                ServletConfigUtil.COMPONENT_FRAMEWORK,
		                new Object[] {},
		                "An exception occured in updatePolicyResponse. ",
		                ex,
		                LogMinderDOMUtil.VALUE_MIC);
		     
		        throw new Exception(
		                "An exception occured in updatePolicyResponse.",
		                ex);
		    }
			return responseDataUpdate;
		}
		
		
		
		
		
		protected String invokeValidateCompleteCallRequest(String url, TransactionAttributesVO monthlyRec, String userName,
				String password, String requestType) throws Exception {
			String responseJson = "";

			try {
				HttpGet getRequest = new HttpGet(url);
				setGetHeaders(getRequest, monthlyRec, userName, password);
				DefaultHttpClient httpClient = new DefaultHttpClient();
				HttpResponse response = httpClient.execute(getRequest);
				responseJson = EntityUtils.toString(response.getEntity());

			}catch (Exception ex) {
			        LogMinder.getLogMinder().log(
			                LogEntry.SEVERITY_FATAL,
			                MasterSubPropagationUtil.class.getName(),
			                new Exception().getStackTrace()[0].toString(),
			                ServletConfigUtil.COMPONENT_FRAMEWORK,
			                new Object[] {},
			                "An exception occured in invokeValidateCompleteCallRequest. ",
			                ex,
			                LogMinderDOMUtil.VALUE_MIC);
			     
			        throw new Exception(
			                "An exception occured in invokeValidateCompleteCallRequest.",
			                ex);
			    }
			return responseJson;
		}
		
		
		
		
		
		
		
		
		protected TransactionResponseData validateTransactionResponse(String serverName, TransactionAttributesVO monthlyRec, String userName,
				String password) throws Exception {
			String responseJson = "";
			TransactionResponseData responseDataValidate = null;

			try {

				String url = prepareUrl(serverName, VALIDATE_TRANSACTION, monthlyRec);
				responseJson = invokeValidateCompleteCallRequest(url, monthlyRec, userName, password, VALIDATE_TRANSACTION);
				responseDataValidate = populateResponseObject(responseJson);
				
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG, getClass().getName(), "validateTransactionResponse",
						ServletConfigUtil.COMPONENT_FRAMEWORK,
						new Object[] {"url"  + url +  " TransactionAttributesVO "+  monthlyRec + "serverName " 
								+  "responseJson" +responseJson, "TransactionResponseData" + responseDataValidate.toString() },
						"validateTransactionResponse", null, LogMinderDOMUtil.VALUE_WEBSERVICES);


			}catch (Exception ex) {
		        LogMinder.getLogMinder().log(
		                LogEntry.SEVERITY_FATAL,
		                getClass().getName(),
		                new Exception().getStackTrace()[0].toString(),
		                ServletConfigUtil.COMPONENT_FRAMEWORK,
		                new Object[] {},
		                "An exception occured in validateTransactionResponse. ",
		                ex,
		                LogMinderDOMUtil.VALUE_MIC);
		     
		        throw new Exception(
		                "An exception occured in validateTransactionResponse.",
		                ex);
		    }
			return responseDataValidate;
		}
		
		
		
		protected TransactionResponseData validateAckTransactionResponse(String serverName, TransactionAttributesVO monthlyRec, String userName,
				String password) throws Exception {
			String responseJson = "";
			TransactionResponseData responseDataValidate = null;

			try {

				String url = prepareUrl(serverName, VALIDATE_TRANSACTION_ACK, monthlyRec);
				responseJson = invokeValidateCompleteCallRequest(url, monthlyRec, userName, password, VALIDATE_TRANSACTION);
				responseDataValidate = populateResponseObjectValAck(responseJson);
				
				if (null!= responseDataValidate && responseDataValidate.getTransactionId() != null ) {
					
					if (null!= responseDataValidate.getSourceSystemID()) {
					monthlyRec.setNewPolicyGid(Long.valueOf(responseDataValidate.getSourceSystemID()));
					}
					 
					monthlyRec.setNewPolicyReference(responseDataValidate.getTransactionId());
					monthlyRec.setClientId(responseDataValidate.getClientId()); 
					}

		


			}catch (Exception ex) {
		        LogMinder.getLogMinder().log(
		                LogEntry.SEVERITY_FATAL,
		                getClass().getName(),
		                new Exception().getStackTrace()[0].toString(),
		                ServletConfigUtil.COMPONENT_FRAMEWORK,
		                new Object[] {},
		                "An exception occured in validateTransactionResponse. ",
		                ex,
		                LogMinderDOMUtil.VALUE_MIC);
		     
		        throw new Exception(
		                "An exception occured in validateTransactionResponse.",
		                ex);
		    }
			return responseDataValidate;
		}
		
		
		
		
		
		
		protected TransactionResponseData completeTransactionResponse(String serverName, TransactionAttributesVO monthlyRec, String userName,
				String password) throws Exception {
			String responseJson = "";
			TransactionResponseData responseDataComplete = null;

			try {

				String url = prepareUrl(serverName, COMPLETE_TRANSACTION, monthlyRec);
				responseJson = invokeValidateCompleteCallRequest(url, monthlyRec, userName, password, COMPLETE_TRANSACTION);
				responseDataComplete = populateResponseObject(responseJson);


				
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG, getClass().getName(), "completeTransactionResponse",
						ServletConfigUtil.COMPONENT_FRAMEWORK,
						new Object[] {"url"  + url +  " TransactionAttributesVO "+  monthlyRec + "serverName " 
								+  "responseJson" +responseJson, "TransactionResponseData" + responseDataComplete.toString() },
						"completeTransactionResponse", null, LogMinderDOMUtil.VALUE_WEBSERVICES);

			}catch (Exception ex) {
		        LogMinder.getLogMinder().log(
		                LogEntry.SEVERITY_FATAL,
		                getClass().getName(),
		                new Exception().getStackTrace()[0].toString(),
		                ServletConfigUtil.COMPONENT_FRAMEWORK,
		                new Object[] {},
		                "An exception occured in completeTransactionResponse. ",
		                ex,
		                LogMinderDOMUtil.VALUE_MIC);
		     
		        throw new Exception(
		                "An exception occured in completeTransactionResponse.",
		                ex);
		    }
			return responseDataComplete;
		}
		
		
		
		protected String invokeSuspendTrnsactionRequest(String url, TransactionAttributesVO monthlyRec, String userName,String password){
			String responseJson = "";

			try {
				HttpGet getRequest = new HttpGet(url);
				setGetHeaders(getRequest, monthlyRec, userName, password);
				DefaultHttpClient httpClient = new DefaultHttpClient();
				HttpResponse response = httpClient.execute(getRequest);
				responseJson = EntityUtils.toString(response.getEntity());

			} catch (Exception e) {
				e.printStackTrace();
			}
			return responseJson;
		}
		
		
		protected TransactionResponseData suspendTransactionResponse(String serverName, TransactionAttributesVO monthlyRec, String userName,
				String password) throws Exception {
			String responseJson = "";
			TransactionResponseData responseDataSuspend = null;

			try {

				String url = prepareUrl(serverName, SUSPEND_TRANSACTION, monthlyRec);
				responseJson = invokeSuspendTrnsactionRequest(url, monthlyRec, userName, password);
				responseDataSuspend = populateResponseObject(responseJson);

				
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG, getClass().getName(), "suspendTransactionResponse",
						ServletConfigUtil.COMPONENT_FRAMEWORK,
						new Object[] {"url"  + url +  " TransactionAttributesVO "+  monthlyRec + "serverName " 
								+  "responseJson" +responseJson, "TransactionResponseData" + responseDataSuspend.toString() },
						"suspendTransactionResponse", null, LogMinderDOMUtil.VALUE_WEBSERVICES);

			}catch (Exception ex) {
		        LogMinder.getLogMinder().log(
		                LogEntry.SEVERITY_FATAL,
		                getClass().getName(),
		                new Exception().getStackTrace()[0].toString(),
		                ServletConfigUtil.COMPONENT_FRAMEWORK,
		                new Object[] {},
		                "An exception occured in suspendTransactionResponse. ",
		                ex,
		                LogMinderDOMUtil.VALUE_MIC);
		     
		        throw new Exception(
		                "An exception occured in suspendTransactionResponse.",
		                ex);
		    }
			return responseDataSuspend;
		}
		
		

		
		
		protected String invokeGetObjectCall(String url, TransactionAttributesVO monthlyRec, String userName,String password) throws Exception{
			String responseJson = "";

			try {

				HttpGet getRequest = new HttpGet(url);
				setGetHeaders(getRequest, monthlyRec, userName, password);
				DefaultHttpClient httpClient = new DefaultHttpClient();
				HttpResponse response = httpClient.execute(getRequest);
				responseJson = EntityUtils.toString(response.getEntity());

			}catch (Exception ex) {
				LogMinder.getLogMinder().log(
						LogEntry.SEVERITY_FATAL,
						MasterSubPropagationUtil.class.getName(),
						new Exception().getStackTrace()[0].toString(),
						ServletConfigUtil.COMPONENT_FRAMEWORK,
						new Object[] {},
						"An exception occured in invokeGetObjectCall. ",
						ex,
						LogMinderDOMUtil.VALUE_MIC);

				throw new Exception(
						"An exception occured in invokeGetObjectCall.",
						ex);
			}
			return responseJson;
		}
		
		
		
		protected TransactionResponseData getObjectResponse(String serverName, String requestType, TransactionAttributesVO monthlyRec, String userName,
				String password) throws Exception{
			String responseJson = "";
			TransactionResponseData response = null;

			try {

				String url = prepareUrl(serverName, requestType, monthlyRec);
				responseJson = invokeGetObjectCall(url, monthlyRec, userName, password);
				response = populateResponseObject(responseJson);
				
		

			}catch (Exception ex) {
		        LogMinder.getLogMinder().log(
		                LogEntry.SEVERITY_FATAL,
		                getClass().getName(),
		                new Exception().getStackTrace()[0].toString(),
		                ServletConfigUtil.COMPONENT_FRAMEWORK,
		                new Object[] {},
		                "An exception occured in getLOBNTLResponse. ",
		                ex,
		                LogMinderDOMUtil.VALUE_MIC);
		     
		        throw new Exception(
		                "An exception occured in getObjectResponse.",
		                ex);
		    }
			return response;
		}
		
		
		

		
		
		protected TransactionResponseData populateResponseObject(String responseJson) throws Exception
		{ 
			TransactionResponseData transactionResponseData = new TransactionResponseData();
			try {
				logMessage(LogEntry.SEVERITY_INFO, "populateResponseObject() : responseJson : " + responseJson, "");
				JSONObject responseJsonObj = new JSONObject(responseJson);
				if (responseJson.contains("transactionID") ) {
					transactionResponseData.setTransactionId(responseJsonObj.getString("transactionID"));

				}

				if(responseJson.contains("clientID") ) {
					transactionResponseData.setClientId(responseJsonObj.getString("clientID"));
				}

				if(responseJson.contains("objectFieldValuesList") ) {
					JSONArray objectFieldValuesList = responseJsonObj.getJSONArray("objectFieldValuesList");

					for (int i = 0; i < objectFieldValuesList.length(); i++) {
						JSONObject objectFieldValue = (JSONObject) objectFieldValuesList.get(i);

						if (responseJson.contains("GID") && objectFieldValue.getString("GID") != null) {
							transactionResponseData.setGid(objectFieldValue.getString("GID"));
						}
						if (responseJson.contains("sourceSystemID") && objectFieldValue.getString("sourceSystemID") != null) {
							transactionResponseData.setSourceSystemID(objectFieldValue.getString("sourceSystemID"));
						}

						if (responseJson.contains("systemColumns") ) {
								if(objectFieldValue.getJSONObject("systemColumns").getString("EntityReference") != null) 
							transactionResponseData.setPolicyReference(objectFieldValue.getJSONObject("systemColumns").getString("EntityReference"));

								
						}
						
					}
				}
				
				
				
				
		
				
				ErrorObject errorObject = null;
				JSONArray ErrorsList = null;
				if(responseJson.contains("errors") ) {

					ErrorsList = responseJsonObj.getJSONArray("errors");

					int errosCount = ErrorsList.length();
					ErrorObject[] errorObjects = new ErrorObject[errosCount];

					for (int i = 0; i < ErrorsList.length(); i++) {
						JSONObject error = (JSONObject) ErrorsList.get(i);
						errorObject = new ErrorObject();
						if (responseJson.contains("jasonPath") ) {

							errorObject.setJasonPath(error.getString("jasonPath"));

						}

						if (responseJson.contains("message") ) {

							errorObject.setMessage(error.getString("message"));

						}

						if (responseJson.contains("messageType") ) {

							errorObject.setMessageType(error.getString("messageType"));
						}
						errorObjects[i] = errorObject;
					}
					transactionResponseData.setErrors(errorObjects);
				}
			}catch (Exception ex) {
		        LogMinder.getLogMinder().log(
		                LogEntry.SEVERITY_FATAL,
		                getClass().getName(),
		                new Exception().getStackTrace()[0].toString(),
		                ServletConfigUtil.COMPONENT_FRAMEWORK,
		                new Object[] {},
		                "An exception occured in populateResponseObject. ",
		                ex,
		                LogMinderDOMUtil.VALUE_MIC);
		     
		        throw new Exception(
		                "An exception occured in populateResponseObject.",
		                ex);
		    }

			return transactionResponseData;
		}
		
		

		protected TransactionResponseData populateResponseObjectValAck(String responseJson) throws Exception
		{ 
			TransactionResponseData transactionResponseData = new TransactionResponseData();
			try {
				JSONObject responseJsonObj = new JSONObject(responseJson);
				if (responseJson.contains("transactionID") ) {
					transactionResponseData.setTransactionId(responseJsonObj.getString("transactionID"));

				}

				if(responseJson.contains("clientID") ) {
					transactionResponseData.setClientId(responseJsonObj.getString("clientID"));
				}

				if(responseJson.contains("objectFieldValuesList") ) {
					JSONArray objectFieldValuesList = responseJsonObj.getJSONArray("objectFieldValuesList");

					for (int i = 0; i < objectFieldValuesList.length(); i++) {
						JSONObject objectFieldValue = (JSONObject) objectFieldValuesList.get(i);

						if (objectFieldValue.has("Gid") && objectFieldValue.getString("Gid") != null) {
							transactionResponseData.setGid(objectFieldValue.getString("Gid")); 
						}
						 
						
					}
				}
				ErrorObject errorObject = null;
				JSONArray ErrorsList = null;
				if(responseJson.contains("errors") ) {

					ErrorsList = responseJsonObj.getJSONArray("errors");

					int errosCount = ErrorsList.length();
					ErrorObject[] errorObjects = new ErrorObject[errosCount];

					for (int i = 0; i < ErrorsList.length(); i++) {
						JSONObject error = (JSONObject) ErrorsList.get(i);
						errorObject = new ErrorObject();
						if (responseJson.contains("jasonPath") ) {

							errorObject.setJasonPath(error.getString("jasonPath"));

						}

						if (responseJson.contains("message") ) {

							errorObject.setMessage(error.getString("message"));

						}

						if (responseJson.contains("messageType") ) {

							errorObject.setMessageType(error.getString("messageType"));
						}
						errorObjects[i] = errorObject;
					}
					transactionResponseData.setErrors(errorObjects);
				}
			}catch (Exception ex) {
		        LogMinder.getLogMinder().log(
		                LogEntry.SEVERITY_FATAL,
		                getClass().getName(),
		                new Exception().getStackTrace()[0].toString(),
		                ServletConfigUtil.COMPONENT_FRAMEWORK,
		                new Object[] {},
		                "An exception occured in populateResponseObject. ",
		                ex,
		                LogMinderDOMUtil.VALUE_MIC);
		     
		        throw new Exception(
		                "An exception occured in populateResponseObject.",
		                ex);
		    }

			return transactionResponseData;
		}
	


		protected String getServiceURLFromMahcineConfigs(){
			String ip = null;
			String serviceURL = null;
			Connection conn = null;
			PreparedStatement st = null;
			ResultSet rs = null;
			if(machineURL != null){
				return machineURL;
			}
			try {
				ip = InetAddress.getLocalHost().getHostAddress();
			}catch(IOException ex) {
				ex.printStackTrace();
			}
			String sql = "SELECT DECODE(AMA_SECURE,'Y','https://','http://') || NVL(AMA_VIRTUALHOST_NAME, AMA_NAME)  || '.' "+
					  " || DECODE(NVL(AMA_VIRTUALHOST_NAME,''),'',AMA_FQDN, AMA_USERDOMAIN) PDFServerPath, NVL(AMA_VIRTUALHOST_PORT, AMA_ADMIN_PORT) PDFServerPort "+
					" FROM ADM_MACHINES, ADM_INSTANCES	WHERE AMA_MACHINE_ID           = AIN_MACHINE_ID "+
					" AND AMA_IPADDRESS  =  ? 	AND rownum < 2 ";
			try{
				conn = ConnectionPool.getAdminConnection();
				st = conn.prepareStatement(sql);
				st.setString(1,ip);
				rs = st.executeQuery();
				if(rs != null && rs.next()){
					String pdfServerPath = rs.getString("PDFSERVERPATH");
					String pdfServerPort = rs.getString("PDFSERVERPORT");
					serviceURL = pdfServerPath + ":" + pdfServerPort;
				}
	            machineURL = serviceURL;					
			}catch(Exception e){
				
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
	                    getClass().getName(), "getServiceURLFromMahcineConfigs",
	                    ServletConfigUtil.COMPONENT_IMAGING,
	                    new Object[] { ip , serviceURL},
	                    "Not able to fetch the Service URL from IP, using the configured URL for the call ",
	                    e, logName);		
			}
			
			if(serviceURL == null || serviceURL.isEmpty()){
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
	                    getClass().getName(), "getServiceURLFromMahcineConfigs",
	                    ServletConfigUtil.COMPONENT_IMAGING,
	                    new Object[] { ip , serviceURL},
	                    "Not able to fetch the Service URL from IP, using the configured URL for the call ",
	                    null, logName);	
				serviceURL = null;
			}
			return serviceURL;
		}
		
		
		
		
		protected ErrorObject[] combineArray(ErrorObject[] source, ErrorObject[] destination) {
			int length = source.length + destination.length;
			ErrorObject[] result = new ErrorObject[length];
			System.arraycopy(source, 0, result, 0, source.length);
			System.arraycopy(destination, 0, result, source.length, destination.length);
			return result;
		}
		
		
		
		public void processSaveFailTask(String taskId, long failNotificationId,
				User user, String transactionType, String policyReference, String masterPolicyReference, String errorMessage, String processType) throws Exception {
			

		 	    Connection conn = null;
		        PreparedStatement pstmt = null;
		        ResultSet rs = null;
		        int maxNumberAttmpt = 1;
		        boolean shouldInsert = false;
		        String masterReferenceCopy;
		        try { 
		        	
		        	
		        	String newPolicyGid = getLatestPolicyGid(user, policyReference);  
		        	
		        	String shouldInsertQuery = " select decode(count(PITRF_ID),0,'true','false' ) should_insert from PIMIS_TRANSACTION_FAILURE  \r\n" + 
		        			"		        			 where PITRF_TASK_ID = ?  \r\n" + 
		        			"		        			 and PITRF_POLICY_REFERENCE = ? ";
		        	
		        	String insertSql = " INSERT INTO PIMIS_TRANSACTION_FAILURE (PITRF_ID, PITRF_TASK_ID, PITRF_WFH_ID,PITRF_NUM_ATTEMPTS,PITRF_DATE_MODIFIED,PITRF_TRANSACTION_TYPE,PITRF_ERROR_DESC,PITRF_PROCESS_TYPE,PITRF_POLICY_REFERENCE )\r\n" + 
		        			"	                          VALUES(PITRF_REQ_SEQ.nextval,?,?,?,sysdate, ?,? ,?,?) ";
		        	
		        	String selectSql = " select NVL(PITRF_NUM_ATTEMPTS,0) PITRF_NUM_ATTEMPTS from PIMIS_TRANSACTION_FAILURE where PITRF_TASK_ID = ? AND PITRF_POLICY_REFERENCE = ?   "; 
		        	
		        	conn = ConnectionPool.getConnection(user);
		        	 
		        	// If record exist for the given task id then update the record else insert new record
		        	
		        	   
		        	    
		        	    pstmt = conn.prepareStatement(shouldInsertQuery);
			            pstmt.setInt(1, Integer.parseInt(taskId));	
			            pstmt.setString(2, policyReference); 
			          
			            rs = pstmt.executeQuery();
			            
			            if (rs.next()){
			            	
			            	shouldInsert =  new Boolean(rs.getString(("should_insert"))).booleanValue();  	   
			            	
			         	}
			            pstmt.close();	   
		        	
		        	
		        		            
		            pstmt = conn.prepareStatement(selectSql);
		            pstmt.setInt(1, Integer.parseInt(taskId));	 
		            pstmt.setString(2, policyReference); 	            
		            rs = pstmt.executeQuery();
		            
		            if (rs.next()){
		            	
		            	maxNumberAttmpt = maxNumberAttmpt + rs.getInt("PITRF_NUM_ATTEMPTS");        	   
		            	
		         	}
		            pstmt.close();	        		
		        	
		            
		       
		            
		         if (shouldInsert)  {
		            pstmt = conn.prepareStatement(insertSql);
			        pstmt.setInt(1, Integer.parseInt(taskId));
			        pstmt.setLong(2, Long.valueOf(newPolicyGid));
			        pstmt.setInt(3, maxNumberAttmpt);
			        pstmt.setString(4, transactionType);
			        pstmt.setString(5, errorMessage); 
			        pstmt.setString(6, processType); 
			        pstmt.setString(7, policyReference); 
			       
			       

			        pstmt.execute();
			        pstmt.close();
			             
		         }
		         
		            
		        } catch (Exception ex) {
		            LogMinder.getLogMinder().log(
		                    LogEntry.SEVERITY_FATAL,
		                    getClass().getName(),
		                    new Exception().getStackTrace()[0].toString(),
		                    ServletConfigUtil.COMPONENT_FRAMEWORK,
		                    new Object[] {},
		                    "An exception occured in processSaveFailTask. ",
		                    ex,
		                    LogMinderDOMUtil.VALUE_MIC);
		            if (conn != null) {
		                 conn.rollback();
		    		 }
		            throw new Exception(
		                    "An exception occured in processSaveFailTask.",
		                    ex);
		        } finally {
		            try {
		                DBUtil.close(rs, pstmt,conn);
		            } catch (SQLException ex) {
		                throw new Exception(
		                        "Exception occured while try to close statement the excetpion"
		                                + MasterSubPropagationUtil.class.getName(),
		                        ex);
		            }
		        }
		    }	
		       	     		  
		    
			
		public void processOOSERecords(String taskId, long failNotificationId,
				User user, String transactionType, String policyReference) throws Exception {

			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			int maxNumberAttmpt = 1;
			boolean shouldInsert = false;
			try { 


				String insertSql = "INSERT INTO gamis_master_sub_oose (gamso_id,gamso_task_id,gamso_wfh_id,gamso_date_modified,gamso_transaction_type,"
						+ "gamso_oose_amnd_pol_ref,gamso_status)\r\n" + 
						"VALUES (master_sub_oose_seq.nextval,?,?,SYSDATE,?,?,'READY')";


				conn = ConnectionPool.getConnection(user);


				pstmt = conn.prepareStatement(insertSql);
				pstmt.setInt(1, Integer.parseInt(taskId));
				pstmt.setLong(2, failNotificationId);
				pstmt.setString(3, transactionType);
				pstmt.setString(4, policyReference); 
				pstmt.execute();
				pstmt.close();




			} catch (Exception ex) {
				LogMinder.getLogMinder().log(
						LogEntry.SEVERITY_FATAL,
						getClass().getName(),
						new Exception().getStackTrace()[0].toString(),
						ServletConfigUtil.COMPONENT_FRAMEWORK,
						new Object[] {},
						"An exception occured in processSaveFailTask. ",
						ex,
						LogMinderDOMUtil.VALUE_MIC);
				if (conn != null) {
					conn.rollback();
				}
				throw new Exception(
						"An exception occured in processSaveFailTask.",
						ex);
			} finally {
				try {
					DBUtil.close(rs, pstmt,conn);
				} catch (SQLException ex) {
					throw new Exception(
							"Exception occured while try to close statement the excetpion"
									+ MasterSubPropagationUtil.class.getName(),
									ex);
				}
			}
		}	
		
		public void deleteSaveFailTask(String taskId, long failNotificationId,
				User user) throws Exception{

		 	    Connection conn = null;
		        PreparedStatement pstmt = null;
		        ResultSet rs = null;
		     
		        try {
		        	
		        	String deleteSql = " DELETE FROM GAMIS_MASTER_SUB_FAILURE WHERE GAMSF_TASK_ID  = ? AND GAMSF_WFH_ID = ? ";
		        	
		        	conn = ConnectionPool.getConnection(user);
		        	
		        	// If record exist for the given task id then update the record else insert new record
		            pstmt = conn.prepareStatement(deleteSql);
		            pstmt.setInt(1, Integer.parseInt(taskId));	
		            pstmt.setLong(2, failNotificationId);	            
		            pstmt.executeUpdate();
		            conn.commit();
		            pstmt.close();	        		
		            
		        } catch (Exception ex) {
		            LogMinder.getLogMinder().log(
		                    LogEntry.SEVERITY_FATAL,
		                    getClass().getName(),
		                    new Exception().getStackTrace()[0].toString(),
		                    ServletConfigUtil.COMPONENT_FRAMEWORK,
		                    new Object[] {},
		                    "An exception occured in deleteSaveFailTask. ",
		                    ex,
		                    LogMinderDOMUtil.VALUE_MIC);
		            if (conn != null) {
		                 conn.rollback();
		    		 }
		            throw new Exception(
		                    "An exception occured in deleteSaveFailTask.",
		                    ex);
		        } finally {
		            try {
		                DBUtil.close(rs, pstmt,conn);
		            } catch (SQLException ex) {
		                throw new Exception(
		                        "Exception occured while try to close statement the excetpion"
		                                + MasterSubPropagationUtil.class.getName(),
		                        ex);
		            }
		        }
		    }	

		
		
		public void deleteSaveFailTaskUpdate(String taskId, long failNotificationId,
				User user, String masterPolicyRef) throws Exception{

		 	    Connection conn = null;
		        PreparedStatement pstmt = null;
		        ResultSet rs = null;
		     
		        try {
		        	
		        	String deleteSql = " DELETE FROM GAMIS_MASTER_SUB_FAILURE WHERE GAMSF_TASK_ID  = ?  AND GAMSF_MASTER_POLICY_REF = ? ";
		        	
		        	conn = ConnectionPool.getConnection(user);
		        	
		        	// If record exist for the given task id then update the record else insert new record
		            pstmt = conn.prepareStatement(deleteSql);
		            pstmt.setInt(1, Integer.parseInt(taskId));	
		            pstmt.setString(2, masterPolicyRef); 
		            pstmt.executeUpdate();
		            conn.commit();
		            pstmt.close();	        		
		            
		        } catch (Exception ex) {
		            LogMinder.getLogMinder().log(
		                    LogEntry.SEVERITY_FATAL,
		                    getClass().getName(),
		                    new Exception().getStackTrace()[0].toString(),
		                    ServletConfigUtil.COMPONENT_FRAMEWORK,
		                    new Object[] {},
		                    "An exception occured in deleteSaveFailTask. ",
		                    ex,
		                    LogMinderDOMUtil.VALUE_MIC);
		            if (conn != null) {
		                 conn.rollback();
		    		 }
		            throw new Exception(
		                    "An exception occured in deleteSaveFailTask.",
		                    ex);
		        } finally {
		            try {
		                DBUtil.close(rs, pstmt,conn);
		            } catch (SQLException ex) {
		                throw new Exception(
		                        "Exception occured while try to close statement the excetpion"
		                                + MasterSubPropagationUtil.class.getName(),
		                        ex);
		            }
		        }
		    }	
		
		
		
		public void updateFailedCount(String taskId, long notificationId ,  User user , String masterPolicyReference ) throws Exception {

		 	   Connection conn = null;
		       PreparedStatement pstmt = null;
		       ResultSet rs = null;
		       
		   	LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG, getClass().getName(), "updateFailedCount",
					ServletConfigUtil.COMPONENT_FRAMEWORK,
					new Object[] { "updateFailedCount" + notificationId, taskId  },
					"Files Upload updateFailedCount", null,
					LogMinderDOMUtil.VALUE_WEBSERVICES);

		       
		       try {
		        	
		             String updateSql = " UPDATE GAMIS_MASTER_SUB_FAILURE SET GAMSF_NUM_ATTEMPTS = GAMSF_NUM_ATTEMPTS + 1 WHERE GAMSF_TASK_ID  = ? \r\n" + 
		             		"AND GAMSF_WFH_ID = ? AND GAMSF_MASTER_POLICY_REF = ? ";  
		        	
		        	 conn = ConnectionPool.getConnection(user);
			    	 conn.setAutoCommit(false);

		             pstmt = conn.prepareStatement(updateSql);
		             pstmt.setInt(1, Integer.parseInt(taskId)); 	     
		             pstmt.setLong(2, notificationId);	             
		             
		             if (null!= masterPolicyReference) {
		             pstmt.setString(3, masterPolicyReference);	      
		             }else {
		             pstmt.setNull(3, java.sql.Types.VARCHAR);	 
		             }
		             pstmt.executeUpdate();
		             conn.commit();
		        } catch (Exception ex) {
		            LogMinder.getLogMinder().log(
		                    LogEntry.SEVERITY_FATAL,
		                    getClass().getName(),
		                    new Exception().getStackTrace()[0].toString(),
		                    ServletConfigUtil.COMPONENT_FRAMEWORK,
		                    new Object[] {},
		                    "An exception occured in updateFailedCount. ",
		                    ex,
		                    LogMinderDOMUtil.VALUE_MIC);
		            if (conn != null) {
		                 conn.rollback();
		    		 }
		            throw new Exception(
		                    "An exception occured in updateFailedCount.",
		                    ex);
		        } finally {
		            try {
		            	//conn.setAutoCommit(true);//Commented this code due to ERROR on Cloud-QA "java.sql.SQLException: IJ031020: You cannot commit with autocommit set" 
		                DBUtil.close(rs, pstmt,conn);
		            } catch (SQLException ex) {
		                throw new Exception(
		                        "Exception occured while try to close statement the excetpion"
		                                + MasterSubPropagationUtil.class.getName(),
		                        ex);
		            }
		        }
		    }	


		
		
		public  String getLatestPolicyRef(User user,  String entityReference ) throws Exception { 
			String latestPolicyReference = null;

			PreparedStatement stmt = null;
			Connection conn = null;
			ResultSet rs = null;
			String shouldEnableActualsQuery = " SELECT entity_reference\r\n" + 
					"FROM vw_mis_quote_policies\r\n" + 
					"WHERE revision_number =\r\n" + 
					"  (SELECT MAX(revision_number)\r\n" + 
					"  FROM vw_mis_quote_policies\r\n" + 
					"  WHERE org_entity_reference IN\r\n" + 
					"    (SELECT org_entity_reference\r\n" + 
					"    FROM vw_mis_quote_policies\r\n" + 
					"    WHERE entity_reference = ? \r\n" + 
					"    )\r\n" + 
					"  )\r\n" + 
					"AND org_entity_reference =\r\n" + 
					"  (SELECT org_entity_reference\r\n" + 
					"  FROM vw_mis_quote_policies\r\n" + 
					"  WHERE entity_reference = ? \r\n" + 
					"  ) ";


			try {
				conn = ConnectionPool.getConnection(user);
				stmt = conn.prepareStatement(shouldEnableActualsQuery); 
				stmt.setString(1, entityReference); 
				stmt.setString(2, entityReference); 

				rs = stmt.executeQuery();

				while (rs.next()) {
					latestPolicyReference =   rs.getString("entity_reference");

				}

			} catch (SQLException e) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
						this.getClass().toString(),
						new Exception().getStackTrace()[0].toString(),
						ServletConfigUtil.COMPONENT_FRAMEWORK,
						new Object[] { "taskName =" +
								"Booking" },
						"Error in getLatestPolicyRef",
						e,
						LogMinderDOMUtil.VALUE_MIC);			
				e.printStackTrace();
			} finally {


				try {
					DBUtil.close(rs,stmt,conn);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			return latestPolicyReference;
		}
		
		
		
		
		public  String getLatestPolicyGid(User user,  String entityReference ) throws Exception { 
			String latestPolicyGid = null;

			PreparedStatement stmt = null;
			Connection conn = null;
			ResultSet rs = null;
			String shouldEnableActualsQuery = " select gid from vw_mis_quote_policies where entity_reference = ? ";


			try {
				conn = ConnectionPool.getConnection(user);
				stmt = conn.prepareStatement(shouldEnableActualsQuery); 
				stmt.setString(1, entityReference); 

				rs = stmt.executeQuery();

				while (rs.next()) {
					latestPolicyGid =   rs.getString("gid");

				}

			} catch (SQLException e) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
						this.getClass().toString(),
						new Exception().getStackTrace()[0].toString(),
						ServletConfigUtil.COMPONENT_FRAMEWORK,
						new Object[] { "taskName =" +
								"Booking" },
						"Error in getLatestPolicyGid",
						e,
						LogMinderDOMUtil.VALUE_MIC);			
				e.printStackTrace();
			} finally {


				try {
					DBUtil.close(rs,stmt,conn);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			return latestPolicyGid;
		}
		
		private void logMessage(int logLevel, String inputMsg, String objMsg) {
			LogMinder.getLogMinder().log(logLevel, getClass().getName(), "populateResponseObject",
					ServletConfigUtil.COMPONENT_PORTAL, new Object[]{objMsg}, 
					inputMsg, null, LogMinderDOMUtil.VALUE_MIC);
		}	
}
