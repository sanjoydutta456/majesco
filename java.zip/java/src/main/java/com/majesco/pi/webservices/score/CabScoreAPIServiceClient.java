package com.majesco.pi.webservices.score;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.naming.NamingException;

import org.apache.cxf.helpers.IOUtils;
import org.codehaus.jackson.map.ObjectMapper;

import com.coverall.cms.client.RepositoryAccess;
import com.coverall.cms.client.impl.sling.http.SlingConstants;
import com.coverall.cms.utility.CustomerCmsUtil;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;
import com.majesco.custom.pi.integration.constants.CabScoreConstants;
import com.majesco.custom.pi.integration.model.CabScoreOutput;

public class CabScoreAPIServiceClient {

	private final String APPLICATION_NAME = "MIC";
	private final String MODULE_NAME = "PCT";
	private final String CMS_UPLOAD_PATH = "file cabinet";
	private final String VALEN_DETAILS = "VALEN_DETAILS";
	private final String CAB_SCORE_ID_SEQ = "CAB_SCORE_ID_SEQ.NEXTVAL";
	private final String Y = "Y";
	private final String N = "N";
	private final String E = "E";
	private final String FILE_EXTENSTION = ".pdf";
	private final String FILE_TYPE = "PDF";
	private final String MIME_TYPE = "application/pdf";

	private String applicationKey = "mic/mic docs";
	private final String MIC_DIRECTORY_NAME = "mic";
	private final String MIC_DOC_DIRECTORY_NAME = "mic docs/";

	private File uploadDir;
	private String filePath;

	public Map<String, String> cabScoreReport(String dotNumber, String entity_type, String entity_reference, User user,
			HashMap config) {
		String newFileName = null;
		Map<String, String> map = new HashMap<String, String>();
		Connection con = null;
		PreparedStatement pst = null;
		try {

			Long CAB_ID_SEQ = getNextSequence(CAB_SCORE_ID_SEQ, user);
			map.put("CAB_ID", CAB_ID_SEQ.toString());
			map.put("CAB_ENTITY_TYPE", entity_type);
			map.put("CAB_ENTITY_REFERENCE", entity_reference);
			CabScoreAPIServiceImpl serviceImpl = new CabScoreAPIServiceImpl(config);
			Map<String, String> responseMap = new HashMap<String, String>();
			responseMap = serviceImpl.cabScoreReport(dotNumber);
			String requestJson = responseMap.get(CabScoreConstants.WEB_SERVICE_REQUEST);
			String responseJson = responseMap.get(CabScoreConstants.WEB_SERVICE_RESPONSE);

			CabScoreOutput responseObj = null;
			try {

				responseObj = populateResponseObject(responseJson.toString());

				if (null != responseObj) {
					insertCabScoreDetails(CAB_ID_SEQ, entity_type, entity_reference, requestJson, responseJson,
							responseObj, "not defined pdf path", user);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			map.put("CAB_STATUS_CODE", responseMap.get(CabScoreAPIServiceImpl.STATUS_CODE).toString());

			map.put("score", responseObj.getScores().getIss().getScore());
			
			if (!"".equals(responseMap.get(CabScoreAPIServiceImpl.WEB_SERVICE_RESPONSE).toString())) {
				byte[] pdfData = serviceImpl.cabScoreReportPDF(dotNumber);
				if (null != pdfData) {
					LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, CabScoreAPIServiceClient.class.getName(),
							"cabScoreReport ", ServletConfigUtil.COMPONENT_FRAMEWORK,
							new Object[] { "Score ID : " + responseObj.getScores().getIss() },
							"Received PDF Data from Cab Service in CabScoreAPIServiceClient", null,
							LogMinderDOMUtil.VALUE_MIC);

					newFileName = entity_type + "_" + entity_reference + "_Cab_" + responseObj.getScores().getIss()
							+ FILE_EXTENSTION;

					uploadPDF(pdfData, entity_type, entity_reference, newFileName, user);

				} else {
					LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, CabScoreAPIServiceClient.class.getName(),
							"PPCReport ", ServletConfigUtil.COMPONENT_FRAMEWORK,
							new Object[] {
									"Entity Type : " + entity_type + ", Entity Reference : " + entity_reference },
							"Unable to get PDF Data from Cab Score  Report Service in CabScoreAPIServiceClient Event",
							null, LogMinderDOMUtil.VALUE_MIC);
				}

			}
			 
			map.put("ResponseReceived", Y);

		} catch (Exception e) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, CabScoreAPIServiceClient.class.getName(),
					"cabScoreReport", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { config.toString() },
					"Error in Cab Report XML Service from CabScoreAPIServiceClient Exception : ", e,
					LogMinderDOMUtil.VALUE_MIC);
			System.out.println("Exception in Client :" + e);
			map.put("ResponseReceived", E);
		} finally {
			try {
				DBUtil.close(null, pst, con);
			} catch (Exception e) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, CabScoreAPIServiceClient.class.getName(),
						"cabScoreReport", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { config.toString() },
						"Error closing DB Objects in PPC Report Service : " + e.getMessage(), e,
						LogMinderDOMUtil.VALUE_MIC);
			}
		}
		return map;
	}

	public void insertCabScoreDetails(long cabId, String entityType, String entityReference, String cabJsonRequest,
			String cabResponse, CabScoreOutput responseObj, String pdfPath, User user) {
		PreparedStatement pStmt = null;
		Connection conn = null;
		ResultSet rs = null;
		String cabScoreDetails = " INSERT INTO PI_CAB_DETAILS " + "  ( "
				+ "   CAB_ID,ENTITY_TYPE,ENTITY_REFERENCE,ISS_SCORE, " + "   CAB_REQUEST,CAB_RESPONSE,PDF_PATH ) "
				+ "  VALUES " + "  ( " + "   ?,?,?,?,?,?,? ) ";

		try {
			conn = ConnectionPool.getConnection(user);
			pStmt = conn.prepareStatement(cabScoreDetails);
			pStmt.setLong(1, cabId);
			pStmt.setString(2, entityType);
			pStmt.setString(3, entityReference);
			pStmt.setLong(4, Long.parseLong(responseObj.getScores().getIss().getScore()));
			pStmt.setString(5, cabJsonRequest);
			pStmt.setString(6, cabResponse);
			pStmt.setString(7, pdfPath);
			pStmt.executeUpdate();

		} catch (SQLException | NamingException e) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, this.getClass().toString(),
					new Exception().getStackTrace()[0].toString(), ServletConfigUtil.COMPONENT_FRAMEWORK,
					new Object[] { "insertCabScoreDetails" }, "Error in insertCabScoreDetails", e,
					LogMinderDOMUtil.VALUE_MIC);
			e.printStackTrace();
		} finally {

			try {
				DBUtil.close(rs, pStmt, conn);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	public CabScoreOutput populateResponseObject(String responseJson) throws Exception {
		CabScoreOutput cabScoreOutput = new CabScoreOutput();
		ObjectMapper mapper = new ObjectMapper();

		try {

			mapper.configure(org.codehaus.jackson.map.DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			cabScoreOutput = mapper.readValue(responseJson, CabScoreOutput.class);

		} catch (Exception e) {

			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "populateResponseObject",
					ServletConfigUtil.COMPONENT_PORTAL, new Object[] { responseJson },
					"Error while calling populateResponseObject from CabScoreAPIServiceClient." + e.getMessage(), e,
					LogMinderDOMUtil.VALUE_MIC);
			throw e;

		}

		return cabScoreOutput;
	}

	private Long getNextSequence(String Sequence, User user) {
		Long NextSequence = (long) 0;
		PreparedStatement pst = null;
		Connection con = null;
		try {
			con = ConnectionPool.getConnection(user);
			String sequenceQuery = "SELECT " + Sequence + " nextSeq FROM DUAL";
			pst = con.prepareStatement(sequenceQuery);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				NextSequence = Long.parseLong(rs.getString("nextSeq"));
			}
		} catch (SQLException e) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, CabScoreAPIServiceClient.class.getName(),
					"getNextSequence", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { Sequence },
					"Error getting next sequence in CabScoreAPIServiceClient Exception : ", e,
					LogMinderDOMUtil.VALUE_MIC);
			System.out.println("Error Getting Sequence : " + Sequence + " SQL Exception : " + e);
		} catch (Exception e) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, CabScoreAPIServiceClient.class.getName(),
					"getNextSequence", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { Sequence },
					"Error getting next sequence in CabScoreAPIServiceClient Exception : ", e,
					LogMinderDOMUtil.VALUE_MIC);
			System.out.println("Error Getting Sequence : " + Sequence + " Exception : " + e);
		} finally {
			try {
				DBUtil.close(null, pst, con);
			} catch (Exception e) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, CabScoreAPIServiceClient.class.getName(),
						"getNextSequence", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {},
						"Error closing DB Objects while getting next sequence : " + e.getMessage(), e,
						LogMinderDOMUtil.VALUE_MIC);
			}
		}
		return NextSequence;
	}

	String getEntityGID(String entityReference, String EntityType, User user) {
		String gid = "0";
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			con = ConnectionPool.getConnection(user);
			if (null != EntityType && ("QUOTE".equalsIgnoreCase(EntityType) || "POLICY".equalsIgnoreCase(EntityType))) {
				String gidQuery = "SELECT GID " + " FROM VW_MIS_QUOTE_POLICIES " + " WHERE ENTITY_REFERENCE = ?";
				pst = con.prepareStatement(gidQuery);
				pst.setString(1, entityReference);
				rs = pst.executeQuery();
				while (rs.next()) {
					gid = (String) rs.getString("GID");
				}
			} else if (null != EntityType && ("INSURED".equalsIgnoreCase(EntityType))) {
				String gidQuery = "SELECT GID FROM VW_MIS_INSUREDS WHERE ENTITY_REFERENCE = ?";
				pst = con.prepareStatement(gidQuery);
				pst.setString(1, entityReference);
				rs = pst.executeQuery();
				while (rs.next()) {
					gid = (String) rs.getString("GID");
				}
			}
		} catch (Exception e) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, CabScoreAPIServiceClient.class.getName(),
					"getNextSequence", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {},
					"Error getting next sequence in CabScoreAPIServiceClient Exception : ", e,
					LogMinderDOMUtil.VALUE_MIC);
			System.out.println("Error Getting Sequence : " + "Exception : " + e);
		} finally {
			try {
				DBUtil.close(rs, pst, con);
			} catch (Exception e) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, CabScoreAPIServiceClient.class.getName(),
						"getNextSequence", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {},
						"Error closing DB Objects in getEntityGID : " + e.getMessage(), e, LogMinderDOMUtil.VALUE_MIC);
			}
		}
		return gid;
	}

	public static long getBytes(String filename) {
		FileInputStream f_in = null;
		byte[] attachment = null;
		try {
			f_in = new FileInputStream(filename);
			attachment = IOUtils.readBytesFromStream(f_in);
			return attachment.length;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (f_in != null) {
					f_in.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return 0;
	}

	private void setPath(String filename, byte[] pdfData) {
		FileOutputStream fos = null;
		// Stream to write to
		try {
			/*
			 * String tempfilePath = System.getProperty("mic.system.home") + File.separator
			 * + "upload_" + System.currentTimeMillis();
			 */
			String tempfilePath = "C:\\Cab" + File.separator + "upload_" + System.currentTimeMillis();
			uploadDir = new File(tempfilePath); // if the directory does not
												// exist,create it
			if (!uploadDir.exists()) {
				uploadDir.mkdir();
			}
			filePath = uploadDir.getAbsolutePath() + File.separator + filename;
			fos = new FileOutputStream(filePath);
			try {
				fos.write(pdfData);
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (final java.io.FileNotFoundException e) {

		}
	}

	public String getCMSPath(String entityType, String entityReference) {
		StringBuilder returnPath = new StringBuilder(CMS_UPLOAD_PATH);
		if (null != entityType && !entityType.isEmpty()) {
			returnPath.append("/").append(entityType);
		}
		if (null != entityReference && !entityReference.isEmpty()) {
			returnPath.append("/").append(entityReference);
		}
		return returnPath.toString();
	}

	private void deleteTempRedirectory() {
		if (uploadDir != null && uploadDir.exists()) {
			String[] listOfChildFiles = uploadDir.list();
			for (String fileName : listOfChildFiles) {
				File childFile = new File(uploadDir, fileName);
				childFile.delete();
			}
			uploadDir.delete();
		}
	}

	private void uploadPDF(byte[] pdfData, String entityType, String entityReference, String fileName, User user) {

		try {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, CabScoreAPIServiceClient.class.getName(),
					"uploadPDF ", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { fileName },
					"Received PDF Data from Service in CabScoreAPIServiceClient", null, LogMinderDOMUtil.VALUE_MIC);
			Long FILES_SEQ = getNextSequence(CAB_SCORE_ID_SEQ, user);

			long fileSize = 0l;
			setPath(fileName, pdfData);
			fileSize = getBytes(filePath);
			String upload_entity_reference = getEntityGID(entityReference, entityType, user);
			String cmsPath = getCMSPath(entityType, upload_entity_reference);
			InputStream f_in = null;
			try {
				f_in = new FileInputStream(filePath);
				upload(cmsPath, fileName, f_in, fileSize, user);

			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} finally {
				try {
					if (f_in != null) {
						f_in.close();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			deleteTempRedirectory();

		} catch (Exception e) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, CabScoreAPIServiceClient.class.getName(), "uploadPDF",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { "Unable to upload pdf : " + fileName },
					"Error in Storing PDF in method uploadPDF Exception : " + e.getMessage(), e,
					LogMinderDOMUtil.VALUE_MIC);
		}
	}

	public void upload(String path, String fileName, InputStream data, long contentLength, User user) {
		RepositoryAccess newAccessPoint = getAccessPoint(user);
		path = MIC_DOC_DIRECTORY_NAME + CustomerConfigUtil.getInstance().getCustomerCode(user.getDomain()) + "/" + path;
		if (null != newAccessPoint) {
			newAccessPoint.upload(path, fileName, data, contentLength);

		}
	}

	private RepositoryAccess getAccessPoint(User user) {
		RepositoryAccess newAccessPoint = null;

		String customerCode = CustomerConfigUtil.getInstance().getCustomerCode(user.getDomain());
		try {
			HashMap<String, String> parameters = new HashMap<String, String>();
			parameters.put(SlingConstants.SLING_SERVER_URL, CustomerConfigUtil.getInstance().getCustomerProperty(
					customerCode, ServletConfigUtil.COMPONENT_IMAGING, SlingConstants.SLING_SERVER_URL));
			parameters.put(SlingConstants.SLING_USER_NAME, CustomerConfigUtil.getInstance().getCustomerProperty(
					customerCode, ServletConfigUtil.COMPONENT_IMAGING, SlingConstants.SLING_USER_NAME));
			parameters.put(SlingConstants.SLING_PASSWORD, CustomerConfigUtil.getInstance().getCustomerProperty(
					customerCode, ServletConfigUtil.COMPONENT_IMAGING, SlingConstants.SLING_PASSWORD));
			parameters.put(SlingConstants.SLING_WORKSPACE, CustomerConfigUtil.getInstance().getCustomerProperty(
					customerCode, ServletConfigUtil.COMPONENT_IMAGING, SlingConstants.SLING_WORKSPACE));

			newAccessPoint = CustomerCmsUtil.getInstance().getRepositoryAccess(customerCode, parameters,
					MIC_DIRECTORY_NAME);
		} catch (Exception ex) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, CabScoreAPIServiceClient.class.getName(),
					"getNextSequence", ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {},
					"Error getting Access Point for PDF Upload Exception : ", ex, LogMinderDOMUtil.VALUE_MIC);
		}
		return newAccessPoint;
	}

	protected boolean isNullorEmpty(String str) {
		return (null == str || str.isEmpty());
	}

	public static void main(String[] args) throws Exception {
		HashMap<String, String> configMap = new HashMap<String, String>();
		configMap.put("serviceURL", "https://qa.gnpapi.protectiveinsurance.com");
		configMap.put("grant_type", "client_credentials");
		configMap.put("client_id", "0oa3h231c4uyUOadk1d7");
		configMap.put("client_secret", "s0N7dC-8_cKJfoZwhxQg84i7NXRO-s-O9GVEsnTI");
		configMap.put("scope", "Majesco");
		configMap.put("basicAuthentication", "true");

		configMap.put("baseURL", "https://qa.gnpapi.protectiveinsurance.com");
		new CabScoreAPIServiceClient().cabScoreReport("70559", "quote", "1234", null, configMap);
	}

}
