package com.majesco.pi.webservices.score;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.coverall.util.DBUtil;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONObject;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.majesco.custom.pi.bulkupdate.model.PolicyErrorResponse;
import com.majesco.custom.pi.bulkupdate.service.BulkUnderwriterServiceHelper;
import com.majesco.custom.pi.integration.constants.ValenScoreConstants;
import com.majesco.custom.pi.integration.model.Classification;
import com.majesco.custom.pi.integration.model.Inputs;
import com.majesco.custom.pi.integration.model.Insured;
import com.majesco.custom.pi.integration.model.InsuredResponse;
import com.majesco.custom.pi.integration.model.Score;
import com.majesco.custom.pi.integration.model.State;
import com.majesco.custom.pi.integration.model.ValenScore;
import com.majesco.custom.pi.integration.model.ValenScoreOutput;

import org.apache.http.HttpHeaders;

public class ValenScoreAPIServiceImpl {
	public static final String STATUS_CODE = "STATUS_CODE";
	public static final String WEB_SERVICE_RESPONSE = "WEB_SERVICE_RESPONSE";

	public static final String CHAR_SET = "UTF-8";
	public static final String REQUEST_GET = "GET";
	public static final String REQUEST_POST = "POST";
	private static final String RiskID = null;

	private String SECURITY_TOKEN_BASE_URL;
	private String BASE_URL;
	private String ACCESS_TOKEN;
	private String EXPIRES_IN = "0";
	private String TOKEN_TYPE;

	private String ACCEPT;
	private String GRANT_TYPE;
	private String CLIENT_ID;
	private String CLIENT_SECRET;

	private Long TOKEN_CALL_TIME_MILLIS = (long) 0;
	static List<String> OccupantIds = new ArrayList<String>();

	ValenScoreAPIServiceImpl(HashMap config) throws Exception {

		System.setProperty("java.protocol.handler.pkgs", "javax.net.ssl");
		System.setProperty("javax.net.debug", "ssl");
		this.SECURITY_TOKEN_BASE_URL = config.get("serviceURL").toString().trim();
		this.BASE_URL = config.get("baseURL").toString().trim();
		this.GRANT_TYPE = config.get("grant_type").toString().trim();
		this.CLIENT_ID = config.get("client_id").toString().trim();
		this.CLIENT_SECRET = config.get("client_secret").toString().trim();
		this.TOKEN_TYPE = config.get("scope").toString().trim();
		
		securityToken();

	}

	public static HttpClient verifiedClient(HttpClient base) {
		try {
			SSLContext ctx = SSLContext.getInstance("SSL");
			X509TrustManager tm = new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return null;
				}

				@Override
				public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
				}

				@Override
				public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
				}
			};

			ctx.init(null, new TrustManager[] { tm }, null);
			SSLSocketFactory ssf = new SSLSocketFactory(ctx, SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
			ClientConnectionManager mgr = base.getConnectionManager();
			SchemeRegistry registry = mgr.getSchemeRegistry();
			registry.register(new Scheme("https", 443, ssf));
			return new DefaultHttpClient(mgr, base.getParams());
		} catch (Exception ex) {
			ex.printStackTrace();
			return new DefaultHttpClient();
		}
	}

	private void securityToken() {
		HttpClient httpclient = new DefaultHttpClient();
		httpclient = verifiedClient(httpclient);
		try {
			System.out.println("Log DEBUG : Executing Security Token Service");
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO, getClass().getName(), "securityToken",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Security Token Service execution Started",
					null, LogMinderDOMUtil.VALUE_MIC);
			URI uri = new URI(SECURITY_TOKEN_BASE_URL + "/authorization-service/accesstoken");

			HttpPost httpPost = new HttpPost(uri);
			httpPost.addHeader("Accept", ACCEPT);

			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(4);
			nameValuePairs.add(new BasicNameValuePair("grant_type", GRANT_TYPE));
			nameValuePairs.add(new BasicNameValuePair("client_id", CLIENT_ID));
			nameValuePairs.add(new BasicNameValuePair("client_secret", CLIENT_SECRET));
			nameValuePairs.add(new BasicNameValuePair("scope", TOKEN_TYPE));

			httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			TOKEN_CALL_TIME_MILLIS = System.currentTimeMillis();

			HttpResponse response = httpclient.execute(httpPost);

			HttpEntity resEntity = response.getEntity();
			if ((Integer) response.getStatusLine().getStatusCode() == 200) {

				String responseBody = "";
				if (resEntity != null) {
					responseBody = EntityUtils.toString(resEntity);
					System.out.println("Log DEBUG : Security Tokent Sevice Response : " + responseBody);

					setTokenElements(responseBody);
					EntityUtils.consume(resEntity);
					LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO, getClass().getName(), "securityToken",
							ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { responseBody },
							"Security Token Service executed Successfully", null, LogMinderDOMUtil.VALUE_MIC);
				}
			} else {
				throw new Exception("Error While Getting Security Token : " + response.getStatusLine());
			}
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO, getClass().getName(), "securityToken",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {},
					"Security Token Service executed Successfully.l", null, LogMinderDOMUtil.VALUE_MIC);
			System.out.println("Log DEBUG : Security Token Service executed Successfully.");
		} catch (Exception e) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "securityToken",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {},
					"Error while gatting security token in ScoreAPIServiceImpl Params : grant_type : " + GRANT_TYPE
							+ " username " + CLIENT_ID,
					e, LogMinderDOMUtil.VALUE_MIC);
			e.printStackTrace();
			System.out.println("---Log FATAL : " + e.getMessage());
		} finally {
			httpclient.getConnectionManager().shutdown();
		}
	}

	public HashMap<String, String> valenScoreReport(ValenScore vScore) {
		HashMap<String, String> responseMap = new HashMap<String, String>();
		String responseJson = "";
		String requestJson="";
		HttpClient httpclient = new DefaultHttpClient();
		httpclient = verifiedClient(httpclient);
		try {
			System.out.println("Log DEBUG : Executing Valen Score Service");
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO, getClass().getName(), "valenScoreReportXML",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { "Score  : " + vScore },
					"Valen Score Report Service execution Started", null, LogMinderDOMUtil.VALUE_MIC);

			URI serviceUrl = new URI(BASE_URL + "/riskreport-api/api/v1/riskreport/scoring?insuredId=123xyz");
			HttpPost postMethod = null;
			postMethod = new HttpPost(serviceUrl);
			postMethod.setHeader(HttpHeaders.CONTENT_TYPE, "application/json");
			postMethod.setHeader(HttpHeaders.ACCEPT, "application/json");
			postMethod.setHeader(HttpHeaders.AUTHORIZATION, "Bearer " + ACCESS_TOKEN);
			requestJson = getJson(vScore);
			StringEntity input = new StringEntity(requestJson);
			input.setContentType("application/json");
			postMethod.setEntity(input);
			HttpResponse response = httpclient.execute(postMethod);
			HttpEntity resEntity = response.getEntity();
			if ((Integer) response.getStatusLine().getStatusCode() == 200) {
				responseMap.put(STATUS_CODE, String.valueOf(response.getStatusLine().getStatusCode()));
				if (resEntity != null) {
					responseJson = EntityUtils.toString(resEntity);
					System.out.println("Log DEBUG :Valen Score Report Service Response : " + responseJson);
					LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO, getClass().getName(), "valenScoreReportXML",
							ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { responseJson },
							"valenScoreReportXML Service executed Successfully ", null, LogMinderDOMUtil.VALUE_MIC);
					EntityUtils.consume(resEntity);
				}
			} else {
				responseMap.put(STATUS_CODE, String.valueOf(response.getStatusLine().getStatusCode()));
				throw new Exception("---Log FATAL : Error Calling Valen Score Report Service : " + response.getStatusLine());
			}
			System.out.println("Log DEBUG : Valen Score Report Service executed successfully.");
			// 106856122
			

		} catch (Exception e) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "valenScoreReportXML",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { "valenScoreReport---"},
					"Error while executing PPC Report Service of ScoreAPIServiceImpl Exception : ", e,
					LogMinderDOMUtil.VALUE_MIC);
			System.out.println(e.getMessage());
		} finally {
			httpclient.getConnectionManager().shutdown();
		}

		responseMap.put(ValenScoreConstants.WEB_SERVICE_REQUEST, requestJson);
		responseMap.put(ValenScoreConstants.WEB_SERVICE_RESPONSE, responseJson);

		return responseMap;
	}

	

	public byte[] valenScoreReportPDF(String scoreId) {
		byte[] pdf = null;
		String methodName = "valenScoreReportPDF";
		DefaultHttpClient httpClient = new DefaultHttpClient();
		try {
			
			URI uri = new URI(BASE_URL + "/riskreport-api/api/v1/riskreport/" + scoreId + "/pdfreport?insuredId=cons");
			HttpGet httpGet = new HttpGet(uri);
			httpGet.setHeader(HttpHeaders.CONTENT_TYPE, "application/json");
			httpGet.setHeader(HttpHeaders.ACCEPT, "application/json");
			httpGet.setHeader(HttpHeaders.AUTHORIZATION, "Bearer " + ACCESS_TOKEN);
			HttpResponse response = httpClient.execute(httpGet);

			HttpEntity resEntity = response.getEntity();

			if ((Integer) response.getStatusLine().getStatusCode() == 200) {
				if (resEntity != null) {
					pdf = EntityUtils.toByteArray(resEntity);
					System.out.println("Log DEBUG : valenScoreReportPDF Response : " + pdf);
					EntityUtils.consume(resEntity);
				}
			} else {
				throw new Exception("---Log FATAL : Error Calling valenScoreReportPDF : " + response.getStatusLine());
			}

		} catch (Exception e) {

			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), methodName,
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { e.getMessage() },
					"Error while executing " + methodName + " of ScoreAPIServiceImpl:", e,
					LogMinderDOMUtil.VALUE_MIC);

		} finally {
			httpClient.getConnectionManager().shutdown();
		}

		return pdf;
	}

	private void setTokenElements(String jsonObject) {

		try {

			JSONObject obj = new JSONObject(jsonObject);
			ACCESS_TOKEN = obj.getString("access_token");
			EXPIRES_IN = obj.getString("expires_in");
			TOKEN_TYPE = obj.getString("scope");

		} catch (Exception e) {
			System.out.println("Exception while parsing token service response : " + e);
		}

	}

	private boolean isNullOrEmpty(String string) {
		boolean isNullOfEmpty = true;
		if (null != string && !string.equals(""))
			isNullOfEmpty = false;
		return isNullOfEmpty;
	}

	/**
	 * SSL certificate validation by pass
	 * 
	 * @throws Exception
	 */
	private void doTrustToCertificates() throws Exception {
		// Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
			public X509Certificate[] getAcceptedIssuers() {
				return null;
			}

			public void checkServerTrusted(X509Certificate[] certs, String authType) throws CertificateException {
				return;
			}

			public void checkClientTrusted(X509Certificate[] certs, String authType) throws CertificateException {
				return;
			}
		} };

		SSLContext sc = SSLContext.getInstance("SSL");
		sc.init(null, trustAllCerts, new SecureRandom());
		HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
		HostnameVerifier hv = new HostnameVerifier() {

			@Override
			public boolean verify(String urlHostName, SSLSession session) {
				if (!urlHostName.equalsIgnoreCase(session.getPeerHost())) {
					System.out.println("Warning: URL host '" + urlHostName + "' is different to SSLSession host '"
							+ session.getPeerHost() + "'.");
				}
				return true;
			}
		};
		HttpsURLConnection.setDefaultHostnameVerifier(hv);
	}
	public static String getJson(ValenScore obj) {
		ObjectMapper mapper = new ObjectMapper();
		StringWriter writer = new StringWriter();
		try {
			mapper.writeValue(writer, obj);
		} catch (IOException e) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, null, null, ServletConfigUtil.COMPONENT_FRAMEWORK,
					new Object[] { e.getMessage() },
					"Error while executing getJson of ScoreAPIServiceImpl Using proxy:", e,
					LogMinderDOMUtil.VALUE_MIC);
		}

		return writer.getBuffer().toString();

	}

	
	
	

}
