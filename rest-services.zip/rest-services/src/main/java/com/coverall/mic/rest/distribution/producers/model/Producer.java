package com.coverall.mic.rest.distribution.producers.model;

import java.util.List;

public class Producer {
	
//	  SELECT
//      SPR_PRODUCER_ID producerId,  
//      SPR_PRODUCER_CODE producerCode, 
//      SPR_PRODUCER_NAME producerName, 
//      SPR_ADDRESS_1 ||'@@'|| SPR_ADDRESS_2 ||'@@'|| SPR_ADDRESS_3 ||'@@'|| SPR_ADDRESS_4 addressLine,
//      SPR_CITY city,
//      SPR_STATE_PROVINCE state,
//      spr_country country,
//      SPR_POSTAL_CODE zipCode,
//      SPR_TELEPHONE telephone,
//      SPR_FAX fax,
//      spr_email_id email,
//      SPR_LICENSE_ID, 
//      SPR_TAX_STATE_PROVINCE taxState, 
//      SPR_TERRITORY territory, 
//      NVL2(SPR_PARENT_PRODUCER,'N','Y') isPrimaryProducer,
//      spr_producer_category producerCategory,
//      SPR_PRODUCER_CLASS producerClassification,
//      SPR_FEIN_NUMBER feinNumber,
//      NVL(SPR_DIRECT_BILL_INDICATOR,'N') directBillingIndicator,
//      spr_sub_agent subAgent
//  FROM
//    SHL_PRODUCERS Producers;                    	
	String sourceSystemUserId;
	String sourceSystemCode;
	long sourceSystemRequestNo;
	long producerId;
	String producerName;
	String producerCode;
	String addressLine;
	String city;
	String state;
	String zipCode;
	String country;
	String telephone;
	String fax;
	String email;
	String isPrimaryProducer;
	String producerCategory;
	String feinNumber;
	String producerClassification;
	String taxState;
	String territory;
	String directBillIndicator;
	String subAgent;
	String marketManager;
	String agreementDate;
	
	List<ProducerContact> producerContacts;
	List<ProducerAuthorities> producerAuthorities;
	List<ProducerLicense> producerLicenses;
    List<ProducerReplacement> producerReplacements;
    
    ProducerBillingInfo productBillongInfo;

	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}

	public void setSourceSystemUserId(String sourceSystemUserId) {
		this.sourceSystemUserId = sourceSystemUserId;
	}

	public String getSourceSystemCode() {
		return sourceSystemCode;
	}

	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}

	public long getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}

	public void setSourceSystemRequestNo(long sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}

	public long getProducerId() {
		return producerId;
	}

	public void setProducerId(long producerId) {
		this.producerId = producerId;
	}

	public String getProducerName() {
		return producerName;
	}

	public void setProducerName(String producerName) {
		this.producerName = producerName;
	}

	public String getProducerCode() {
		return producerCode;
	}

	public void setProducerCode(String producerCode) {
		this.producerCode = producerCode;
	}

	public String getAddressLine() {
		return addressLine;
	}

	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getIsPrimaryProducer() {
		return isPrimaryProducer;
	}

	public void setIsPrimaryProducer(String isPrimaryProducer) {
		this.isPrimaryProducer = isPrimaryProducer;
	}

	public String getProducerCategory() {
		return producerCategory;
	}

	public void setProducerCategory(String producerCategory) {
		this.producerCategory = producerCategory;
	}

	public String getFeinNumber() {
		return feinNumber;
	}

	public void setFeinNumber(String feinNumber) {
		this.feinNumber = feinNumber;
	}

	public String getProducerClassification() {
		return producerClassification;
	}

	public void setProducerClassification(String producerClassification) {
		this.producerClassification = producerClassification;
	}

	public String getTaxState() {
		return taxState;
	}

	public void setTaxState(String taxState) {
		this.taxState = taxState;
	}

	public String getTerritory() {
		return territory;
	}

	public void setTerritory(String territory) {
		this.territory = territory;
	}

	public String getDirectBillIndicator() {
		return directBillIndicator;
	}

	public void setDirectBillIndicator(String directBillIndicator) {
		this.directBillIndicator = directBillIndicator;
	}

	public String getSubAgent() {
		return subAgent;
	}

	public void setSubAgent(String subAgent) {
		this.subAgent = subAgent;
	}

	public String getMarketManager() {
		return marketManager;
	}

	public void setMarketManager(String marketManager) {
		this.marketManager = marketManager;
	}

	public String getAgreementDate() {
		return agreementDate;
	}

	public void setAgreementDate(String agreementDate) {
		this.agreementDate = agreementDate;
	}

	public List<ProducerContact> getProducerContacts() {
		return producerContacts;
	}

	public void setProducerContacts(List<ProducerContact> producerContacts) {
		this.producerContacts = producerContacts;
	}

	public List<ProducerAuthorities> getProducerAuthorities() {
		return producerAuthorities;
	}

	public void setProducerAuthorities(List<ProducerAuthorities> producerAuthorities) {
		this.producerAuthorities = producerAuthorities;
	}

	public List<ProducerLicense> getProducerLicenses() {
		return producerLicenses;
	}

	public void setProducerLicenses(List<ProducerLicense> producerLicenses) {
		this.producerLicenses = producerLicenses;
	}

	public List<ProducerReplacement> getProducerReplacements() {
		return producerReplacements;
	}

	public void setProducerReplacements(
			List<ProducerReplacement> producerReplacements) {
		this.producerReplacements = producerReplacements;
	}

	public ProducerBillingInfo getProductBillongInfo() {
		return productBillongInfo;
	}

	public void setProductBillongInfo(ProducerBillingInfo productBillongInfo) {
		this.productBillongInfo = productBillongInfo;
	}

}
