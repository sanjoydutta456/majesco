package com.coverall.mic.rest.distribution.producers.model;

public class ProducerAuthorities {
	
//	SELECT 
//    SPA_AUTHORITY_ID ID,
//    SPA_POLICY_SYMBOL PRODUCT,
//    (SELECT PPD_NAME FROM PS_PRODUCTS,DS_RESOURCE WHERE DSR_GID = PPD_ID AND DSR_DATE_DELETED IS NULL AND DSR_PRODUCT_CODE=SPA_POLICY_SYMBOL 
//    		AND  NVL(ppd_is_insurance_product, 'Y') = 'Y') PRODUCT_NAME,
//    nvl(SPA_COMMISSION_1, 0) COMMISSION_1,
//    nvl(SPA_COMMISSION_2, 0) COMMISSION_2,
//    NVL(TO_CHAR(SPA_DATE_MODIFIED, 'YYYY-MM-DD'), TO_CHAR(SPA_DATE_CREATED, 'YYYY-MM-DD')) DATE_MODIFIED
//FROM SHL_PRODUCER_AUTHORITIES 
//WHERE EXISTS (SELECT 1 FROM PS_PRODUCTS,DS_RESOURCE WHERE DSR_GID = PPD_ID AND DSR_DATE_DELETED IS NULL AND DSR_PRODUCT_CODE=SPA_POLICY_SYMBOL 
//		AND  NVL(ppd_is_insurance_product, 'Y') = 'Y')
//AND SPA_PRODUCER_ID = ?;
	
	String sourceSystemUserId;
	String sourceSystemCode;
	long sourceSystemRequestNo;
	String product;
	String productCode;
	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}
	public void setSourceSystemUserId(String sourceSystemUserId) {
		this.sourceSystemUserId = sourceSystemUserId;
	}
	public String getSourceSystemCode() {
		return sourceSystemCode;
	}
	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}
	public long getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}
	public void setSourceSystemRequestNo(long sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
}
