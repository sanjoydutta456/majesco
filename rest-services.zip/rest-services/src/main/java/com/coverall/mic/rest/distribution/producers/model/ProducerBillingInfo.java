package com.coverall.mic.rest.distribution.producers.model;

public class ProducerBillingInfo {
	
//ProducerBillInfo.xml
	
//	SELECT PBI_PAYMENT_METHOD paymentMethod,           
//    PBI_AGENT_TYPE agentType,     
//    PBI_PROCESS_1099_INDICATOR Indicator1099,
//    PBI_CREDIT_TERM_DAYS creditTermDays,
//    PBI_CREDIT_TERM_MONTHS creditTermMonths,       
//    PBI_STATEMENT_MAILING_DAY statementMailingDay,    
//    PBI_STATEMENT_FORMAT statementFormat,         
//    PBI_OUTPUT_DELIVERY_METHOD deliveryMethod,
//    PBI_NCAN_GRACE_DAYS graceDays,
//    PBI_COMMISSION_PAYMENT_METHOD commissionPaymentMethod,
//    PBI_INVOICING_CURRENCY invoicingCurrency,
//    PBI_COMMISSION_ENTITY commissionEntity,
//    PBI_BILLING_CONTACT_NAME billingContactName,
//    PBI_DOING_BUSINESS_AS DBA,
//    PBI_USER_REMARKS useRemarks,
//    PBI_STATEMENT_INDICATOR_YN statementIndicator,
//    PBI_PAYEE_ENTITY_TYPE payeeEntity,
//    PBI_VENDOR_CODE vendorCode,
//    PBI_STATEMENT_ENTITY_TYPE statementEnityType,
//    PBI_STATEMENT_ENTITY_CODE statementEntity,
//    PBI_AUTO_COMM_EXTRACTION autoCommissionExtraction
//FROM SHL_PRODUCER_BILLING_INFO
//WHERE PBI_PRODUCER_ID=?;	
	String sourceSystemUserId;
	String sourceSystemCode;
	long sourceSystemRequestNo;
	String paymentMethod;
	String agentType;
	int creditTermDays;
	int creditTermMonths;
	int statementMailingDay;
	String statementFormat;
	String deliveryMethod;
	int graceDays;
	String commissionPaymentMethod;
	String invoicingCurrency;
	String indicator1099;
	String statementIndicator;
	String commissionEntity;
	String billingContactName;
	String DBA;
	String userRemarks;
	String payeeEntityType;
	String payeeEntity;
	String statementEnityType;
	String statementEntity;
	String autoCommissionExtraction;
	String vendorCode;
	
	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}
	public void setSourceSystemUserId(String sourceSystemUserId) {
		this.sourceSystemUserId = sourceSystemUserId;
	}
	public String getSourceSystemCode() {
		return sourceSystemCode;
	}
	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}
	public long getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}
	public void setSourceSystemRequestNo(long sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public String getAgentType() {
		return agentType;
	}
	public void setAgentType(String agentType) {
		this.agentType = agentType;
	}
	public int getCreditTermDays() {
		return creditTermDays;
	}
	public void setCreditTermDays(int creditTermDays) {
		this.creditTermDays = creditTermDays;
	}
	public int getCreditTermMonths() {
		return creditTermMonths;
	}
	public void setCreditTermMonths(int creditTermMonths) {
		this.creditTermMonths = creditTermMonths;
	}
	public int getStatementMailingDay() {
		return statementMailingDay;
	}
	public void setStatementMailingDay(int statementMailingDay) {
		this.statementMailingDay = statementMailingDay;
	}
	public String getStatementFormat() {
		return statementFormat;
	}
	public void setStatementFormat(String statementFormat) {
		this.statementFormat = statementFormat;
	}
	public String getDeliveryMethod() {
		return deliveryMethod;
	}
	public void setDeliveryMethod(String deliveryMethod) {
		this.deliveryMethod = deliveryMethod;
	}
	public int getGraceDays() {
		return graceDays;
	}
	public void setGraceDays(int graceDays) {
		this.graceDays = graceDays;
	}
	public String getCommissionPaymentMethod() {
		return commissionPaymentMethod;
	}
	public void setCommissionPaymentMethod(String commissionPaymentMethod) {
		this.commissionPaymentMethod = commissionPaymentMethod;
	}
	public String getInvoicingCurrency() {
		return invoicingCurrency;
	}
	public void setInvoicingCurrency(String invoicingCurrency) {
		this.invoicingCurrency = invoicingCurrency;
	}
	public String getIndicator1099() {
		return indicator1099;
	}
	public void setIndicator1099(String indicator1099) {
		indicator1099 = indicator1099;
	}
	public String getStatementIndicator() {
		return statementIndicator;
	}
	public void setStatementIndicator(String statementIndicator) {
		this.statementIndicator = statementIndicator;
	}
	public String getCommissionEntity() {
		return commissionEntity;
	}
	public void setCommissionEntity(String commissionEntity) {
		this.commissionEntity = commissionEntity;
	}
	public String getBillingContactName() {
		return billingContactName;
	}
	public void setBillingContactName(String billingContactName) {
		this.billingContactName = billingContactName;
	}
	public String getDBA() {
		return DBA;
	}
	public void setDBA(String dBA) {
		DBA = dBA;
	}
	public String getUserRemarks() {
		return userRemarks;
	}
	public void setUserRemarks(String userRemarks) {
		this.userRemarks = userRemarks;
	}
	public String getPayeeEntityType() {
		return payeeEntityType;
	}
	public void setPayeeEntityType(String payeeEntityType) {
		this.payeeEntityType = payeeEntityType;
	}
	public String getPayeeEntity() {
		return payeeEntity;
	}
	public void setPayeeEntity(String payeeEntity) {
		this.payeeEntity = payeeEntity;
	}
	public String getStatementEnityType() {
		return statementEnityType;
	}
	public void setStatementEnityType(String statementEnityType) {
		this.statementEnityType = statementEnityType;
	}
	public String getStatementEntity() {
		return statementEntity;
	}
	public void setStatementEntity(String statementEntity) {
		this.statementEntity = statementEntity;
	}
	public String getAutoCommissionExtraction() {
		return autoCommissionExtraction;
	}
	public void setAutoCommissionExtraction(String autoCommissionExtraction) {
		this.autoCommissionExtraction = autoCommissionExtraction;
	}
	public String getVendorCode() {
		return vendorCode;
	}
	public void setVendorCode(String vendorCode) {
		this.vendorCode = vendorCode;
	}
}
