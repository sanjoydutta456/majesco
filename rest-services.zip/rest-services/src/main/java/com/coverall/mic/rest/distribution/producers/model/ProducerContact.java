package com.coverall.mic.rest.distribution.producers.model;

public class ProducerContact {
	
	
//	SELECT MFC_ID ,
//    SCO_ROLE,
//    SDB_CONTACTS.SCO_NAME_TYPE contactType,
//    TRIM(DECODE(SCO_NAME_TYPE,'Business',SCO_COMPANY,(SCO_TITLE || ' ' || SCO_FIRST_NAME || ' ' ||SCO_MIDDLE_NAME|| ' ' ||
//    SCO_LAST_NAME|| ' ' || SCO_SUFFIX))) contactName,
//    SCO_COMPANY company,
//    SCO_DOING_BUSINESS_AS dbaName,
//    to_char(SCO_DATE_OF_BIRTH,'YYYY-MM-DD') dateOfBirth,
//    sco_title jobTitle,
//    sco_occupation occupation,
//    to_char(sco_business_since,'YYYY-MM-DD') inBusinessSince,
//    sco_tax_id taxId,
//    sco_db_rating dAndBRating,
//    sco_ssn ssn,
//    sco_gender gender,
//    SCO_PHONE_1 dayTimePhone,
//    sco_phone_1_ext dayTimePhoneExt,
//    SCO_PHONE_2 businessPhone,
//    sco_phone_2_ext businessPhoneExt,
//    sco_fax fax,
//    SCO_EMAIL email,
//    sco_url website,
//    SCO_ACTIVE isActive,
//    sco_language language,
//    sco_marital_status maritalStatus,
//    sco_code code,
//    MFC_ROLE role,
//    sco_number_dependants numberDependents,
//    sco_stock_trading_symbol stockTradingSymbol,
//    sco_stock_market stockMarket,
//    sco_annual_revenue annualRevenue,
//    sco_number_employees numberOfEmployee,
//    NVL(MFC_USER_MODIFIED, MFC_USER_CREATED) MFC_USER_MODIFIED,
//    TO_CHAR(NVL(MFC_DATE_MODIFIED,MFC_DATE_CREATED), 'MM/DD/YYYY') MFC_DATE_MODIFIED,
//    SCO_ID,MFC_ROLE role                        
//   FROM MIS_FOLDER_OBJ_CONTACTS_ASSN ,SDB_CONTACTS  
//   WHERE MFC_CONTACT_ID = SCO_ID
//   AND MFC_ENTITY_REFERENCE=?;
	
	String sourceSystemUserId;
	String sourceSystemCode;
	long  sourceSystemRequestNo;
	String contactType;
	String company;
	String contactName;
	String dbaName;
	String dateOfBirth;
	String jobTitle;
	String typeOfBusiness;
	String inBusinessSince;
	String taxId;
	String dAndbRating;
	String ssn;
	String isActive;
	String gender;
	String dayTimePhone;
	String dayTimePhoneExt;
	String mobilePhone;
	String businessPhone;
	String businessPhoneExt;
	String businessPhone2;
	String businessPhone2Ext;
	String fax;
	String webSite;
	String email;
	String occupation;
	String maritalStatus;
	String language;
	int numberDependants;
	String code;
	String stockTradingSymbol;
	String stockMarket;
	double annualRevenue;
	int numberOfEmployee;
	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}
	public void setSourceSystemUserId(String sourceSystemUserId) {
		this.sourceSystemUserId = sourceSystemUserId;
	}
	public String getSourceSystemCode() {
		return sourceSystemCode;
	}
	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}
	public long getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}
	public void setSourceSystemRequestNo(long sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}
	public String getContactType() {
		return contactType;
	}
	public void setContactType(String contactType) {
		this.contactType = contactType;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getContactName() {
		return contactName;
	}
	public void setContactName(String contactName) {
		this.contactName = contactName;
	}
	public String getDbaName() {
		return dbaName;
	}
	public void setDbaName(String dbaName) {
		this.dbaName = dbaName;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getJobTitle() {
		return jobTitle;
	}
	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}
	public String getTypeOfBusiness() {
		return typeOfBusiness;
	}
	public void setTypeOfBusiness(String typeOfBusiness) {
		this.typeOfBusiness = typeOfBusiness;
	}
	public String getInBusinessSince() {
		return inBusinessSince;
	}
	public void setInBusinessSince(String inBusinessSince) {
		this.inBusinessSince = inBusinessSince;
	}
	public String getTaxId() {
		return taxId;
	}
	public void setTaxId(String taxId) {
		this.taxId = taxId;
	}
	public String getdAndbRating() {
		return dAndbRating;
	}
	public void setdAndbRating(String dAndbRating) {
		this.dAndbRating = dAndbRating;
	}
	public String getSsn() {
		return ssn;
	}
	public void setSsn(String ssn) {
		this.ssn = ssn;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDayTimePhone() {
		return dayTimePhone;
	}
	public void setDayTimePhone(String dayTimePhone) {
		this.dayTimePhone = dayTimePhone;
	}
	public String getDayTimePhoneExt() {
		return dayTimePhoneExt;
	}
	public void setDayTimePhoneExt(String dayTimePhoneExt) {
		this.dayTimePhoneExt = dayTimePhoneExt;
	}
	public String getMobilePhone() {
		return mobilePhone;
	}
	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}
	public String getBusinessPhone() {
		return businessPhone;
	}
	public void setBusinessPhone(String businessPhone) {
		this.businessPhone = businessPhone;
	}
	public String getBusinessPhoneExt() {
		return businessPhoneExt;
	}
	public void setBusinessPhoneExt(String businessPhoneExt) {
		this.businessPhoneExt = businessPhoneExt;
	}
	public String getBusinessPhone2() {
		return businessPhone2;
	}
	public void setBusinessPhone2(String businessPhone2) {
		this.businessPhone2 = businessPhone2;
	}
	public String getBusinessPhone2Ext() {
		return businessPhone2Ext;
	}
	public void setBusinessPhone2Ext(String businessPhone2Ext) {
		this.businessPhone2Ext = businessPhone2Ext;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getWebSite() {
		return webSite;
	}
	public void setWebSite(String webSite) {
		this.webSite = webSite;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public int getNumberDependants() {
		return numberDependants;
	}
	public void setNumberDependants(int numberDependants) {
		this.numberDependants = numberDependants;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getStockTradingSymbol() {
		return stockTradingSymbol;
	}
	public void setStockTradingSymbol(String stockTradingSymbol) {
		this.stockTradingSymbol = stockTradingSymbol;
	}
	public String getStockMarket() {
		return stockMarket;
	}
	public void setStockMarket(String stockMarket) {
		this.stockMarket = stockMarket;
	}
	public double getAnnualRevenue() {
		return annualRevenue;
	}
	public void setAnnualRevenue(double annualRevenue) {
		this.annualRevenue = annualRevenue;
	}
	public int getNumberOfEmployee() {
		return numberOfEmployee;
	}
	public void setNumberOfEmployee(int numberOfEmployee) {
		this.numberOfEmployee = numberOfEmployee;
	}
}
