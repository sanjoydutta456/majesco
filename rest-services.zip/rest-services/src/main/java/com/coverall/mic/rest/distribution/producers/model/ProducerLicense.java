package com.coverall.mic.rest.distribution.producers.model;

public class ProducerLicense {
	
//	ProducerLicenses.xml
//	
//   	SELECT 
//    SPI_ID ID,
//    SPI_STATE STATE,
//    SPI_LICENSE_NO licenseNo,
//    TO_CHAR(SPI_EFFECTIVE_DATE,'YYYY-MM-DD') effectiveDate,
//    TO_CHAR(SPI_EXPIRATION_DATE,'YYYY-MM-DD') expirationDate,
//    NVL(TO_CHAR(SPI_DATE_MODIFIED, 'MM/DD/YYYY HH:MM'), TO_CHAR(SPI_DATE_CREATED, 'MM/DD/YYYY HH:MM')) DATE_MODIFIED,
//    SPI_LICENSE_TYPE licenseType,
//    SPI_LICENSE_HOLDER licenseHolder
//    FROM SHL_PRODUCER_LICENSES 
//    WHERE SPI_PRODUCER_ID =?;
	
	String sourceSystemUserId;
	String sourceSystemCode;
	long sourceSystemRequestNo;
	String licenseNo;
	String licenseType;
	String effectiveDate;
	String expirationDate;
	String licenseHolder;
	String state;
	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}
	public void setSourceSystemUserId(String sourceSystemUserId) {
		this.sourceSystemUserId = sourceSystemUserId;
	}
	public String getSourceSystemCode() {
		return sourceSystemCode;
	}
	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}
	public long getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}
	public void setSourceSystemRequestNo(long sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}
	public String getLicenseNo() {
		return licenseNo;
	}
	public void setLicenseNo(String licenseNo) {
		this.licenseNo = licenseNo;
	}
	public String getLicenseType() {
		return licenseType;
	}
	public void setLicenseType(String licenseType) {
		this.licenseType = licenseType;
	}
	public String getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}
	public String getLicenseHolder() {
		return licenseHolder;
	}
	public void setLicenseHolder(String licanseHolder) {
		this.licenseHolder = licanseHolder;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}

}
