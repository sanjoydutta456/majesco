package com.coverall.mic.rest.distribution.producers.model;

import java.util.List;

import com.coverall.mic.rest.policy.api.service.model.QuotePolicyPagination;

public class ProducerListingResponse {
	
	QuotePolicyPagination pagination;
	
	List <Producer> producers;

	public QuotePolicyPagination getPagination() {
		return pagination;
	}

	public void setPagination(QuotePolicyPagination pagination) {
		this.pagination = pagination;
	}

	public List<Producer> getProducers() {
		return producers;
	}

	public void setProducers(List<Producer> producers) {
		this.producers = producers;
	}

	
}
