package com.coverall.mic.rest.distribution.producers.model;

public class ProducerReplacement {
	
//ProducerReplacements.xml
	
//	SELECT distinct SPE_PRODUCER_ID,(SELECT SPR_PRODUCER_CODE FROM SHL_PRODUCERS WHERE SPR_PRODUCER_ID = SPE_REPLACEMENT_PRODUCER_ID) replacementProducerCode,
//	(SELECT spe_replacement_effective_date FROM SHL_PRODUCER_REPLACEMENTS WHERE SPE_PRODUCER_ID=outer.SPE_PRODUCER_ID AND spe_replacement_type='N') terminationDateNB,
//	(SELECT spe_replacement_effective_date FROM SHL_PRODUCER_REPLACEMENTS WHERE SPE_PRODUCER_ID=outer.SPE_PRODUCER_ID AND spe_replacement_type='R') terminationDateRN
//	FROM SHL_PRODUCER_REPLACEMENTS outer
//	WHERE SPE_PRODUCER_ID =?
	
	String sourceSystemUserId;
	String sourceSystemCode;
	long sourceSystemRequestNo;
	String replacementProducerCode;
	String terminationDateNB;
	String terminationDateRN;
	
	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}
	public void setSourceSystemUserId(String sourceSystemUserId) {
		this.sourceSystemUserId = sourceSystemUserId;
	}
	public String getSourceSystemCode() {
		return sourceSystemCode;
	}
	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}
	public long getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}
	public void setSourceSystemRequestNo(long sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}
	public String getReplacementProducerCode() {
		return replacementProducerCode;
	}
	public void setReplacementProducerCode(String replacementProducerCode) {
		this.replacementProducerCode = replacementProducerCode;
	}
	public String getTerminationDateNB() {
		return terminationDateNB;
	}
	public void setTerminationDateNB(String terminationDateNB) {
		this.terminationDateNB = terminationDateNB;
	}
	public String getTerminationDateRN() {
		return terminationDateRN;
	}
	public void setTerminationDateRN(String terminationDateRN) {
		this.terminationDateRN = terminationDateRN;
	}
}
