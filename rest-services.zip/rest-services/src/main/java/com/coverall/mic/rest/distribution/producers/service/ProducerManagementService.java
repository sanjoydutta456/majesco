package com.coverall.mic.rest.distribution.producers.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.coverall.mic.rest.distribution.producers.model.Producer;
import com.coverall.mic.rest.distribution.producers.model.ProducerListingResponse;

public interface ProducerManagementService {
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({ 
		MediaType.APPLICATION_JSON})
	@GET
	ProducerListingResponse getProducerInformation(@Context HttpServletRequest request,@QueryParam("pageSize") int pageSize,
			@QueryParam("pageNumber") int pageNumber)  throws Exception;
	
}
