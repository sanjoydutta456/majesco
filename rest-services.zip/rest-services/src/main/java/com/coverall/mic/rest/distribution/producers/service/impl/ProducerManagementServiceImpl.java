package com.coverall.mic.rest.distribution.producers.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import com.coverall.mic.rest.distribution.producers.model.Producer;
import com.coverall.mic.rest.distribution.producers.model.ProducerAuthorities;
import com.coverall.mic.rest.distribution.producers.model.ProducerBillingInfo;
import com.coverall.mic.rest.distribution.producers.model.ProducerContact;
import com.coverall.mic.rest.distribution.producers.model.ProducerLicense;
import com.coverall.mic.rest.distribution.producers.model.ProducerListingResponse;
import com.coverall.mic.rest.distribution.producers.model.ProducerReplacement;
import com.coverall.mic.rest.distribution.producers.service.ProducerManagementService;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyPagination;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mic.rest.policy.api.service.util.WorkflowUtil;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.security.authentication.User;
import com.coverall.util.DBUtil;

public class ProducerManagementServiceImpl implements ProducerManagementService{

	private String queryForFetchingProducers="SELECT * FROM (SELECT SPR_PRODUCER_ID producerId,SPR_PRODUCER_CODE producerCode,SPR_PRODUCER_CODE AGENT_CODE,SPR_PRODUCER_NAME producerName,"+ 
			"SPR_ADDRESS_1 ||'@@'|| SPR_ADDRESS_2 ||'@@'|| SPR_ADDRESS_3 ||'@@'|| SPR_ADDRESS_4 addressLine,SPR_CITY city,"+
			"SPR_STATE_PROVINCE state,spr_country country,SPR_POSTAL_CODE zipCode,SPR_TELEPHONE telephone,SPR_FAX fax,spr_email_id email,"+
			"SPR_LICENSE_ID,SPR_TAX_STATE_PROVINCE taxState,SPR_TERRITORY territory,NVL2(SPR_PARENT_PRODUCER,'N','Y') isPrimaryProducer,"+
			"spr_producer_category producerCategory,SPR_PRODUCER_CLASS producerClassification,SPR_FEIN_NUMBER feinNumber,NVL(SPR_DIRECT_BILL_INDICATOR,'N') directBillingIndicator,"+
			"spr_sub_agent subAgent,spr_sub_agent SUB_AGENT_ID,SPR_MARKET_MANAGER marketManager FROM SHL_PRODUCERS Producers ORDER BY producerId) WHERE 1=1";                    	

	private String queryForFetchingAuthorities="SELECT SPA_AUTHORITY_ID ID,SPA_POLICY_SYMBOL PRODUCT,(SELECT PPD_NAME FROM PS_PRODUCTS,DS_RESOURCE WHERE DSR_GID = PPD_ID AND DSR_DATE_DELETED IS NULL AND DSR_PRODUCT_CODE=SPA_POLICY_SYMBOL"+ 
			" AND  NVL(ppd_is_insurance_product, 'Y') = 'Y') productName, nvl(SPA_COMMISSION_1, 0) COMMISSION_1,nvl(SPA_COMMISSION_2, 0) COMMISSION_2,NVL(TO_CHAR(SPA_DATE_MODIFIED, 'YYYY-MM-DD'),"+
			"TO_CHAR(SPA_DATE_CREATED, 'YYYY-MM-DD')) DATE_MODIFIED FROM SHL_PRODUCER_AUTHORITIES WHERE EXISTS (SELECT 1 FROM PS_PRODUCTS,DS_RESOURCE WHERE DSR_GID = PPD_ID AND DSR_DATE_DELETED IS NULL"+
			" AND DSR_PRODUCT_CODE=SPA_POLICY_SYMBOL AND  NVL(ppd_is_insurance_product, 'Y') = 'Y') AND SPA_PRODUCER_ID = ?";

	private String queryForFetchingLicenseInfo="SELECT SPI_ID ID,SPI_STATE STATE,SPI_LICENSE_NO licenseNo,TO_CHAR(SPI_EFFECTIVE_DATE,'YYYY-MM-DD') effectiveDate,TO_CHAR(SPI_EXPIRATION_DATE,'YYYY-MM-DD') expirationDate,"+
			"NVL(TO_CHAR(SPI_DATE_MODIFIED, 'MM/DD/YYYY HH:MM'), TO_CHAR(SPI_DATE_CREATED, 'MM/DD/YYYY HH:MM')) DATE_MODIFIED,SPI_LICENSE_TYPE licenseType,SPI_LICENSE_HOLDER licenseHolder"+
			" FROM SHL_PRODUCER_LICENSES WHERE SPI_PRODUCER_ID =?";

	private String queryForFetchingBillingInfo="SELECT PBI_PAYMENT_METHOD paymentMethod,PBI_AGENT_TYPE agentType,PBI_PROCESS_1099_INDICATOR Indicator1099,PBI_CREDIT_TERM_DAYS creditTermDays,PBI_CREDIT_TERM_MONTHS creditTermMonths,"+       
			"PBI_STATEMENT_MAILING_DAY statementMailingDay,PBI_STATEMENT_FORMAT statementFormat,PBI_OUTPUT_DELIVERY_METHOD deliveryMethod,PBI_NCAN_GRACE_DAYS graceDays,PBI_COMMISSION_PAYMENT_METHOD commissionPaymentMethod,"+
			"PBI_INVOICING_CURRENCY invoicingCurrency,PBI_COMMISSION_ENTITY commissionEntity,PBI_BILLING_CONTACT_NAME billingContactName,PBI_DOING_BUSINESS_AS DBA,PBI_USER_REMARKS userRemarks,PBI_STATEMENT_INDICATOR_YN statementIndicator,"+
			"PBI_PAYEE_ENTITY_TYPE payeeEntityType,PBI_PAYEE_ENTITY_CODE payeeEntity,PBI_VENDOR_CODE vendorCode,PBI_STATEMENT_ENTITY_TYPE statementEnityType,PBI_STATEMENT_ENTITY_CODE statementEntity,PBI_AUTO_COMM_EXTRACTION autoCommissionExtraction FROM SHL_PRODUCER_BILLING_INFO"+
			" WHERE PBI_PRODUCER_ID=?";

	private String queryForFetchingProducerContactInfo="SELECT MFC_ID,SCO_ROLE,SDB_CONTACTS.SCO_NAME_TYPE contactType,TRIM(DECODE(SCO_NAME_TYPE,'Business',SCO_COMPANY,(SCO_TITLE || ' ' || SCO_FIRST_NAME || ' ' ||SCO_MIDDLE_NAME|| ' ' ||SCO_LAST_NAME|| ' ' || SCO_SUFFIX))) contactName,"+
			"SCO_COMPANY company,SCO_DOING_BUSINESS_AS dbaName,to_char(SCO_DATE_OF_BIRTH,'YYYY-MM-DD') dateOfBirth,sco_title jobTitle,sco_occupation occupation,to_char(sco_business_since,'YYYY-MM-DD') inBusinessSince,sco_tax_id taxId,"+
			"sco_db_rating dAndBRating,sco_ssn ssn,sco_gender gender,SCO_PHONE_1 dayTimePhone,sco_phone_1_ext dayTimePhoneExt,SCO_PHONE_2 businessPhone,sco_phone_2_ext businessPhoneExt,sco_fax fax,SCO_EMAIL email,sco_url website,SCO_ACTIVE isActive,"+
			"sco_language language,sco_marital_status maritalStatus,sco_code code,MFC_ROLE role,sco_number_dependants numberDependents,sco_stock_trading_symbol stockTradingSymbol,sco_stock_market stockMarket,sco_annual_revenue annualRevenue,"+
			"sco_number_employees numberOfEmployee,NVL(MFC_USER_MODIFIED, MFC_USER_CREATED) MFC_USER_MODIFIED,TO_CHAR(NVL(MFC_DATE_MODIFIED,MFC_DATE_CREATED), 'MM/DD/YYYY') MFC_DATE_MODIFIED,SCO_ID,MFC_ROLE role FROM MIS_FOLDER_OBJ_CONTACTS_ASSN ,SDB_CONTACTS"+  
			" WHERE MFC_CONTACT_ID = SCO_ID AND MFC_ENTITY_REFERENCE=?";

	private String queryForFetchingProducerReplacementInfo="SELECT distinct SPE_PRODUCER_ID,(SELECT SPR_PRODUCER_CODE FROM SHL_PRODUCERS WHERE SPR_PRODUCER_ID = SPE_REPLACEMENT_PRODUCER_ID) replacementProducerCode,(SELECT spe_replacement_effective_date FROM SHL_PRODUCER_REPLACEMENTS WHERE SPE_PRODUCER_ID=outer.SPE_PRODUCER_ID AND spe_replacement_type='N') terminationDateNB,"+
			"(SELECT spe_replacement_effective_date FROM SHL_PRODUCER_REPLACEMENTS WHERE SPE_PRODUCER_ID=outer.SPE_PRODUCER_ID AND spe_replacement_type='R') terminationDateRN FROM SHL_PRODUCER_REPLACEMENTS outer WHERE SPE_PRODUCER_ID =?";





	@Override
	public ProducerListingResponse getProducerInformation(HttpServletRequest request,int pageSize,int pageNumber) throws Exception {
		ProducerListingResponse responseObject=new ProducerListingResponse();
		QuotePolicyPagination paginationInfo=null;
		
		//This url is used for producing pagination links
		String url = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getRequestURI()+"?"+(request.getQueryString()==null?"":request.getQueryString());
		
		if(pageSize==0){
			pageSize=10;
		}
		if(pageNumber==0){
			pageNumber=1;
		}
		
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		User user=requestContext.getUser();
		List<Producer> producerList=new ArrayList<Producer>();
		Connection conn=null;
		PreparedStatement psProducerInfo=null;
		ResultSet rsProducerInfo=null;

		String sourceSystemUserId="";
		long sourceSystemRequestNo=System.currentTimeMillis();
		
		//DLS Check
		queryForFetchingProducers+=APIOperationUtil.resolveDLSExpression(com.coverall.mt.http.User.getUser(request), APIConstant.DLS_EXPRESSION_STRING_PRODUCER);
		
		if(!WorkflowUtil.checkIfUserHasTheRequiredPermission(user, APIConstant.VIEW_PRODUCER_PERMISSION)) {
			String errMsg = user.getUserId()+" doesn't have permission to view producers.";
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			WebServiceLoggerUtil.logInfo("ProducerManagementServiceImpl", "getProducerInformation", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
		}

		try{
			conn=requestContext.getConnection();
			
			paginationInfo=APIOperationUtil.populatePaginationInformation(url, conn, queryForFetchingProducers, pageNumber, pageSize);
			
			String finalExecutableQueryForResults="SELECT  *  FROM (SELECT ROWNUM rnum, z.* FROM ("+queryForFetchingProducers+") z WHERE ROWNUM<= ?) WHERE rnum>= ?";
			//Fetching results
			psProducerInfo=conn.prepareStatement(finalExecutableQueryForResults);
			psProducerInfo.setString(1, paginationInfo.getEndIndex());
			psProducerInfo.setString(2, paginationInfo.getStartIndex());
			rsProducerInfo=psProducerInfo.executeQuery();

			while(rsProducerInfo.next()){
				Producer producer=new Producer();
				String producerReference=rsProducerInfo.getLong("producerId")+"";
				producer.setSourceSystemRequestNo(sourceSystemRequestNo);
				producer.setSourceSystemUserId(sourceSystemUserId);
				producer.setSourceSystemCode("");
				producer.setProducerId(rsProducerInfo.getLong("producerId"));
				producer.setProducerName(rsProducerInfo.getString("producerName"));
				producer.setProducerCode(rsProducerInfo.getString("producerCode"));
				producer.setAddressLine(rsProducerInfo.getString("addressLine"));
				producer.setCity(rsProducerInfo.getString("city"));
				producer.setState(rsProducerInfo.getString("state"));
				producer.setCountry(rsProducerInfo.getString("country"));
				producer.setZipCode(rsProducerInfo.getString("zipCode"));
				producer.setTelephone(rsProducerInfo.getString("telephone"));
				producer.setEmail(rsProducerInfo.getString("email"));
				producer.setFax(rsProducerInfo.getString("fax"));
				producer.setTaxState(rsProducerInfo.getString("taxState"));
				producer.setTerritory(rsProducerInfo.getString("territory"));
				producer.setProducerCategory(rsProducerInfo.getString("producerCategory"));
				producer.setIsPrimaryProducer(rsProducerInfo.getString("isPrimaryProducer"));
				producer.setProducerClassification(rsProducerInfo.getString("producerClassification"));
				producer.setFeinNumber(rsProducerInfo.getString("feinNumber"));
				producer.setDirectBillIndicator(rsProducerInfo.getString("directBillingIndicator"));
				producer.setSubAgent(rsProducerInfo.getString("subAgent"));
				producer.setMarketManager(rsProducerInfo.getString("marketManager"));
				//producer.setAgreementDate(agreementDate);
				producer.setProducerAuthorities(getProducerAuthorities(conn,producerReference));
				producer.setProducerLicenses(getProducerLicenseInfo(conn, producerReference));
				producer.setProductBillongInfo(getProducerBillingInfo(conn, producerReference));
				producer.setProducerContacts(getProducerContactInfo(conn, producerReference));
				producer.setProducerReplacements(getProducerReplacementInfo(conn, producerReference));

				producerList.add(producer);
			}
			
			responseObject.setPagination(paginationInfo);
			responseObject.setProducers(producerList);
		}catch(APIException exp){
			throw exp;
		}catch(Exception exp){
			WebServiceLoggerUtil.logError("ProducerManagementServiceImpl", "getProducerInformation", "Exception occurred while fetching producers information", new Object[] { queryForFetchingProducers }, exp);
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(exp.getMessage()));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,exp);

		}finally{
			try{
				DBUtil.close(rsProducerInfo, psProducerInfo);
			}catch(Exception exp){
				WebServiceLoggerUtil.logInfo("ProducerManagementServiceImpl", "getProducerInformation", exp.getLocalizedMessage(), new Object[] { exp.getMessage() });	
			}

		}
		return responseObject;
	}

	private List<ProducerAuthorities> getProducerAuthorities(Connection conn, String producerReference) throws APIException{
		List<ProducerAuthorities> producerAuthoritiesList=new ArrayList<ProducerAuthorities>();
		PreparedStatement psAuthorities=null;
		ResultSet rsAuthorities=null;

		try{
			psAuthorities=conn.prepareStatement(queryForFetchingAuthorities);
			psAuthorities.setString(1, producerReference+"");
			rsAuthorities=psAuthorities.executeQuery();

			while(rsAuthorities.next()){
				ProducerAuthorities authorities=new ProducerAuthorities();
				authorities.setProduct(rsAuthorities.getString("product"));
				authorities.setProductCode(rsAuthorities.getString("productName"));
				producerAuthoritiesList.add(authorities);
			}
		}catch(Exception exp){
			WebServiceLoggerUtil.logError("ProducerManagementServiceImpl", "getProducerAuthorities", "Exception occurred while fetching producer authorities for "+producerReference, new Object[] { queryForFetchingAuthorities }, exp);
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(exp.getMessage()));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,exp);

		}finally{
			try{
				DBUtil.close(rsAuthorities, psAuthorities);
			}catch(Exception exp){
				WebServiceLoggerUtil.logInfo("ProducerManagementServiceImpl", "getProducerAuthorities", exp.getLocalizedMessage(), new Object[] { exp.getMessage() });	
			}
		}
		return producerAuthoritiesList;
	}

	private List<ProducerLicense> getProducerLicenseInfo(Connection conn, String producerReference) throws APIException{
		List<ProducerLicense> producerLicenses=new ArrayList<ProducerLicense>();
		PreparedStatement psLicenses=null;
		ResultSet rsLicenses=null;

		try{
			psLicenses=conn.prepareStatement(queryForFetchingLicenseInfo);
			psLicenses.setString(1, producerReference+"");
			rsLicenses=psLicenses.executeQuery();

			while(rsLicenses.next()){
				ProducerLicense license=new ProducerLicense();

				license.setEffectiveDate(rsLicenses.getString("effectiveDate"));
				license.setExpirationDate(rsLicenses.getString("expirationDate"));
				license.setLicenseHolder(rsLicenses.getString("licenseHolder"));
				license.setLicenseNo(rsLicenses.getString("licenseNo"));
				license.setLicenseType(rsLicenses.getString("licenseType"));
				license.setState(rsLicenses.getString("state"));

				producerLicenses.add(license);
			}
		}catch(Exception exp){
			WebServiceLoggerUtil.logError("ProducerManagementServiceImpl", "getProducerLicenseInfo", "Exception occurred while fetching producer licenses for "+producerReference, new Object[] { queryForFetchingLicenseInfo }, exp);
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(exp.getMessage()));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,exp);

		}finally{
			try{
				DBUtil.close(rsLicenses, psLicenses);
			}catch(Exception exp){
				WebServiceLoggerUtil.logInfo("ProducerManagementServiceImpl", "getProducerLicenseInfo", exp.getLocalizedMessage(), new Object[] { exp.getMessage() });	
			}
		}
		return producerLicenses;
	}

	private ProducerBillingInfo getProducerBillingInfo(Connection conn, String producerReference) throws APIException{
		ProducerBillingInfo billingInfo=null;
		PreparedStatement psBillingInfo=null;
		ResultSet rsBillingInfo=null;

		try{
			psBillingInfo=conn.prepareStatement(queryForFetchingBillingInfo);
			psBillingInfo.setString(1, producerReference+"");
			rsBillingInfo=psBillingInfo.executeQuery();

			while(rsBillingInfo.next()){
				billingInfo=new ProducerBillingInfo();

				billingInfo.setAgentType(rsBillingInfo.getString("agentType"));
				billingInfo.setAutoCommissionExtraction(rsBillingInfo.getString("autoCommissionExtraction"));
				billingInfo.setBillingContactName(rsBillingInfo.getString("billingContactName"));
				billingInfo.setCommissionEntity(rsBillingInfo.getString("commissionEntity"));
				billingInfo.setCommissionPaymentMethod(rsBillingInfo.getString("commissionPaymentMethod"));
				billingInfo.setCreditTermDays(rsBillingInfo.getInt("creditTermDays"));
				billingInfo.setCreditTermMonths(rsBillingInfo.getInt("creditTermMonths"));
				billingInfo.setDBA(rsBillingInfo.getString("DBA"));
				billingInfo.setDeliveryMethod(rsBillingInfo.getString("deliveryMethod"));
				billingInfo.setGraceDays(rsBillingInfo.getInt("graceDays"));
				billingInfo.setIndicator1099(rsBillingInfo.getString("indicator1099"));
				billingInfo.setInvoicingCurrency(rsBillingInfo.getString("invoicingCurrency"));
				billingInfo.setPayeeEntity(rsBillingInfo.getString("payeeEntity"));
				billingInfo.setPayeeEntityType(rsBillingInfo.getString("payeeEntityType"));
				billingInfo.setPaymentMethod(rsBillingInfo.getString("paymentMethod"));
				billingInfo.setStatementEnityType(rsBillingInfo.getString("statementEnityType"));
				billingInfo.setStatementEntity(rsBillingInfo.getString("statementEntity"));
				billingInfo.setStatementFormat(rsBillingInfo.getString("statementFormat"));
				billingInfo.setStatementIndicator(rsBillingInfo.getString("statementIndicator"));
				billingInfo.setStatementMailingDay(rsBillingInfo.getInt("statementMailingDay"));
				billingInfo.setUserRemarks(rsBillingInfo.getString("userRemarks"));
				billingInfo.setVendorCode(rsBillingInfo.getString("vendorCode"));
			}
		}catch(Exception exp){
			WebServiceLoggerUtil.logError("ProducerManagementServiceImpl", "getProducerBillingInfo", "Exception occurred while fetching producer Billing Info for "+producerReference, new Object[] { queryForFetchingBillingInfo }, exp);
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(exp.getMessage()));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,exp);

		}finally{
			try{
				DBUtil.close(rsBillingInfo, psBillingInfo);
			}catch(Exception exp){
				WebServiceLoggerUtil.logInfo("ProducerManagementServiceImpl", "getProducerBillingInfo", exp.getLocalizedMessage(), new Object[] { exp.getMessage() });	
			}
		}
		return billingInfo;
	}

	private List<ProducerContact> getProducerContactInfo(Connection conn, String producerReference) throws APIException{
		List<ProducerContact> producerContactInfo=new ArrayList<ProducerContact>();
		PreparedStatement psContactInfo=null;
		ResultSet rsContactInfo=null;

		try{
			psContactInfo=conn.prepareStatement(queryForFetchingProducerContactInfo);
			psContactInfo.setString(1, producerReference+"");
			rsContactInfo=psContactInfo.executeQuery();

			while(rsContactInfo.next()){
				ProducerContact contactInfo=new ProducerContact();

				contactInfo.setAnnualRevenue(rsContactInfo.getDouble("annualRevenue"));
				contactInfo.setBusinessPhone(rsContactInfo.getString("businessPhone"));
				contactInfo.setBusinessPhoneExt(rsContactInfo.getString("businessPhoneExt"));
				//contactInfo.setBusinessPhone2(rsContactInfo.getString("businessPhone2"));
				//contactInfo.setBusinessPhone2Ext(rsContactInfo.getString("businessPhone2Ext"));
				contactInfo.setCode(rsContactInfo.getString("code"));
				contactInfo.setCompany(rsContactInfo.getString("company"));
				contactInfo.setContactName(rsContactInfo.getString("contactName"));
				contactInfo.setContactType(rsContactInfo.getString("contactType"));
				contactInfo.setdAndbRating(rsContactInfo.getString("dAndbRating"));
				contactInfo.setDateOfBirth(rsContactInfo.getString("dateOfBirth"));
				contactInfo.setDayTimePhone(rsContactInfo.getString("dayTimePhone"));
				contactInfo.setDayTimePhoneExt(rsContactInfo.getString("dayTimePhoneExt"));
				contactInfo.setDbaName(rsContactInfo.getString("dbaName"));
				contactInfo.setEmail(rsContactInfo.getString("email"));
				contactInfo.setFax(rsContactInfo.getString("fax"));
				contactInfo.setGender(rsContactInfo.getString("gender"));
				contactInfo.setInBusinessSince(rsContactInfo.getString("inBusinessSince"));
				contactInfo.setIsActive(rsContactInfo.getString("isActive"));
				contactInfo.setJobTitle(rsContactInfo.getString("jobTitle"));
				contactInfo.setLanguage(rsContactInfo.getString("language"));
				contactInfo.setMaritalStatus(rsContactInfo.getString("maritalStatus"));
				//contactInfo.setMobilePhone(rsContactInfo.getString("mobilePhone"));
				contactInfo.setNumberDependants(rsContactInfo.getInt("numberDependents"));
				contactInfo.setNumberOfEmployee(rsContactInfo.getInt("numberOfEmployee"));
				contactInfo.setOccupation(rsContactInfo.getString("occupation"));
				contactInfo.setSsn(rsContactInfo.getString("ssn"));
				contactInfo.setStockMarket(rsContactInfo.getString("stockMarket"));
				contactInfo.setStockTradingSymbol(rsContactInfo.getString("stockTradingSymbol"));
				contactInfo.setTaxId(rsContactInfo.getString("taxId"));
				//contactInfo.setTypeOfBusiness(rsContactInfo.getString("typeOfBusiness"));
				contactInfo.setWebSite(rsContactInfo.getString("webSite"));


				producerContactInfo.add(contactInfo);
			}
		}catch(Exception exp){
			WebServiceLoggerUtil.logError("ProducerManagementServiceImpl", "getProducerContactInfo", "Exception occurred while fetching producer contact info for "+producerReference, new Object[] { queryForFetchingProducerContactInfo }, exp);
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(exp.getMessage()));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,exp);

		}finally{
			try{
				DBUtil.close(rsContactInfo, psContactInfo);
			}catch(Exception exp){
				WebServiceLoggerUtil.logInfo("ProducerManagementServiceImpl", "getProducerContactInfo", exp.getLocalizedMessage(), new Object[] { exp.getMessage() });	
			}
		}
		return producerContactInfo;
	}
	
	private List<ProducerReplacement> getProducerReplacementInfo(Connection conn, String producerReference) throws APIException{
		List<ProducerReplacement> producerReplacements=new ArrayList<ProducerReplacement>();
		PreparedStatement psReplacement=null;
		ResultSet rsReplacement=null;

		try{
			psReplacement=conn.prepareStatement(queryForFetchingProducerReplacementInfo);
			psReplacement.setString(1, producerReference+"");
			rsReplacement=psReplacement.executeQuery();

			while(rsReplacement.next()){
				ProducerReplacement replacementInfo=new ProducerReplacement();
				replacementInfo.setReplacementProducerCode(rsReplacement.getString("replacementProducerCode"));
				replacementInfo.setTerminationDateNB(rsReplacement.getString("terminationDateNB"));
				replacementInfo.setTerminationDateRN(rsReplacement.getString("terminationDateRN"));


				producerReplacements.add(replacementInfo);
			}
		}catch(Exception exp){
			WebServiceLoggerUtil.logError("ProducerManagementServiceImpl", "getProducerReplacementInfo", "Exception occurred while fetching producer replacement info for "+producerReference, new Object[] { queryForFetchingProducerReplacementInfo }, exp);
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(exp.getMessage()));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,exp);

		}finally{
			try{
				DBUtil.close(rsReplacement, psReplacement);
			}catch(Exception exp){
				WebServiceLoggerUtil.logInfo("ProducerManagementServiceImpl", "getProducerReplacementInfo", exp.getLocalizedMessage(), new Object[] { exp.getMessage() });	
			}
		}
		return producerReplacements;
	}


	private List<Message> getErrorMessageList(List<String> strMessages)	{
		if(strMessages == null)	{
			return null;
		}
		List<Message> errorMessageList = new ArrayList<Message>(strMessages.size());
		for(String aMsg : strMessages)	{
			Message message = new Message();
			message.setMoreinfo(aMsg);
			errorMessageList.add(message);
		}
		return errorMessageList;
	}

}
