package com.coverall.mic.rest.document.mgmt.model;

public class DocumentPackageV2 extends DocumentPackage {
	
	String sourceSystemUserId;
	String sourceSystemCode;
	long sourceSystemRequestNo;
	long documentPackageId;
	String documentPackageName;
	String documentPackageDate;
	
	public String getDocumentPackageDate() {
		return documentPackageDate;
	}
	public void setDocumentPackageDate(String documentPackageDate) {
		this.documentPackageDate = documentPackageDate;
	}
	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}
	public void setSourceSystemUserId(String sourceSystemUserId) {
		this.sourceSystemUserId = sourceSystemUserId;
	}
	public String getSourceSystemCode() {
		return sourceSystemCode;
	}
	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}
	public long getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}
	public void setSourceSystemRequestNo(long sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}
	public long getDocumentPackageId() {
		return documentPackageId;
	}
	public void setDocumentPackageId(long documentPackageId) {
		this.documentPackageId = documentPackageId;
	}
	public String getDocumentPackageName() {
		return documentPackageName;
	}
	public void setDocumentPackageName(String documentPackageName) {
		this.documentPackageName = documentPackageName;
	}
	
}
