package com.coverall.mic.rest.document.mgmt.model;

public class DocumentPackageV3 extends DocumentPackageV2{

	String documentOccurrenceNo;

	public String getDocumentOccurrenceNo() {
		return documentOccurrenceNo;
	}

	public void setDocumentOccurrenceNo(String documentOccurrenceNo) {
		this.documentOccurrenceNo = documentOccurrenceNo;
	}
	
	@Override
	public String toString () {
		return "DocumentPackageV3:[documentPackageId="+ getDocumentPackageId() + ",documentOccurrenceNo=" + getDocumentOccurrenceNo()
				+ ",documentPackageName="+ getDocumentPackageName() + ",documentCreatedDate=" + getDocumentPackageDate() + "]";
	}
}
