package com.coverall.mic.rest.document.mgmt.service;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;



@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON , MediaType.MULTIPART_FORM_DATA })
@Produces({ MediaType.APPLICATION_JSON , MediaType.MULTIPART_FORM_DATA, MediaType.APPLICATION_OCTET_STREAM,"application/pdf"})
public interface DocumentPackageManagementService {

	String RESOURCE_TYPE="Document Package";
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@GET
	@Path("/")
	public Object listAllDocumentPackages(@Context HttpServletRequest request) throws Exception;
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({MediaType.APPLICATION_OCTET_STREAM})
	@GET
	@Path("/download")
	public Response downloadDocumentPackage(@Context HttpServletRequest request,
			@QueryParam("documentPackageId") String documentPackageId,
			@QueryParam("printDuplex") String printDuplex,
            @QueryParam("printAllRevisions") String printAllRevisions
            ) throws Exception;
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@POST
	@Path("/generate")
	public Object generateDocumentPackage(@Context HttpServletRequest request) throws Exception;
	
	@GET
	@Path("ping")
	public String ping();
}
