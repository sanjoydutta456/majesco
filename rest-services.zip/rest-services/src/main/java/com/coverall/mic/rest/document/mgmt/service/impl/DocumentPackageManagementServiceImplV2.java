package com.coverall.mic.rest.document.mgmt.service.impl;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.StreamingOutput;

import org.apache.cxf.helpers.IOUtils;
import org.codehaus.jackson.map.ObjectMapper;

import oracle.jdbc.OracleTypes;

import com.coverall.mic.rest.document.mgmt.model.DocumentPackage;
import com.coverall.mic.rest.document.mgmt.model.DocumentPackageV2;
import com.coverall.mic.rest.document.mgmt.service.DocumentPackageManagementService;
import com.coverall.mt.util.APIAuditTrailLog;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.factory.impl.PolicyAPIFactoryServiceImpl;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.ConfirmationMessage;
import com.coverall.mic.rest.policy.api.service.model.SourceSystemInformationBean;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mic.rest.policy.api.service.util.WorkflowUtil;
import com.coverall.mt.http.User;
import com.coverall.mt.security.AdminX;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.util.DBUtil;

public class DocumentPackageManagementServiceImplV2 extends DocumentPackageManagementServiceImpl{

	
	public DocumentPackageManagementServiceImplV2(String entityType, HttpServletRequest request, String entityReference) {
		super(entityType, request, entityReference);
	}



	@Override
	public List<DocumentPackage> listAllDocumentPackages(HttpServletRequest request) throws Exception {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		List<DocumentPackage> listOfPackages=new ArrayList<DocumentPackage>();
		Connection conn=null;
		ResultSet rs=null;
		CallableStatement callStmt=null;
		try{
			conn=requestContext.getConnection();
			if(!WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)){
				String errMsg = entityType + " " + entityReference + " was not found. Please check input parameters.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("DocumentPackageManagementServiceImpl", "listAllDocumentPackages", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}

			//Call package for getting document package information
			callStmt = conn.prepareCall("{ ? = call k_document_package_management.f_get_available_packages(?,?,?,?)}");
			callStmt.registerOutParameter(1, OracleTypes.CURSOR);
			callStmt.registerOutParameter(5, Types.INTEGER);
			callStmt.setString(2, entityType);
			callStmt.setString(3, entityReference);
			callStmt.setString(4, user.getFullName());
			callStmt.execute();

			long count=callStmt.getInt(5);

			if (count>0) {
				rs = (ResultSet) callStmt.getObject(1);
				while (rs.next()) {
					DocumentPackageV2 docPackage=new DocumentPackageV2();

					String packageId = rs.getString("dpa_id");
					String packageDisplayName = rs.getString("dpa_display_name");
					String packageDateCreate = rs.getString("dpa_date_created");
					String userHasPrivilege= "N";
		    		try{
		    			userHasPrivilege = user.hasPrivileges(Long.parseLong(packageId), "Document Package", AdminX.VIEW_PRIVILEGE);
		    		}
		    		catch(Exception e){
		    			WebServiceLoggerUtil.logInfo("DocumentPackageManagementServiceImpl", "listAllDocumentPackages", e.getLocalizedMessage(), new Object[] { e.getMessage() });
		    		}
		    		if("Y".equals(userHasPrivilege)){
		    			docPackage.setDocumentPackageId(Long.parseLong(packageId));
		    			docPackage.setDocumentPackageName(packageDisplayName);
		    			docPackage.setDocumentPackageDate(packageDateCreate);
		    			listOfPackages.add(docPackage);
		    		}
				}
			}

		}catch(Exception e){
			WebServiceLoggerUtil.logError("DocumentPackageManagementServiceImpl", "listAllDocumentPackages", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw e;
		}finally{
			try{
				DBUtil.close(rs, callStmt);
			}catch(Exception e){
				WebServiceLoggerUtil.logError("DocumentPackageManagementServiceImpl", "listAllDocumentPackages", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			}
		}
		return listOfPackages;
	}



	@Override
	public String ping() {
		return "Document Packager Service v2 Working";
	}

	private List<Message> getErrorMessageList(List<String> strMessages)	{
		if(strMessages == null)	{
			return null;
		}
		List<Message> errorMessageList = new ArrayList<Message>(strMessages.size());
		for(String aMsg : strMessages)	{
			Message message = new Message();
			message.setMoreinfo(aMsg);
			errorMessageList.add(message);
		}
		return errorMessageList;
	}
}
