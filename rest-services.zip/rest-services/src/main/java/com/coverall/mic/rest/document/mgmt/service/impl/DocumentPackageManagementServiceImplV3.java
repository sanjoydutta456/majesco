package com.coverall.mic.rest.document.mgmt.service.impl;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.StreamingOutput;

import org.apache.cxf.helpers.IOUtils;

import oracle.jdbc.OracleTypes;

import com.coverall.mic.rest.document.mgmt.model.DocumentPackage;
import com.coverall.mic.rest.document.mgmt.model.DocumentPackageV3;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.WorkflowUtil;
import com.coverall.mt.security.AdminX;
import com.coverall.mt.util.DocumentPackageUtil;
import com.coverall.mt.util.MachineInfoUtil;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.util.DBUtil;

public class DocumentPackageManagementServiceImplV3 extends DocumentPackageManagementServiceImplV2 {

	public DocumentPackageManagementServiceImplV3(String entityType,
			HttpServletRequest request, String entityReference) {
		super(entityType, request, entityReference);
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<DocumentPackage> listAllDocumentPackages(HttpServletRequest request) throws Exception {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		List<DocumentPackage> listOfPackages=new ArrayList<DocumentPackage>();
		Connection conn=null;
		ResultSet rs=null;
		CallableStatement callStmt=null;
		try{
			conn=requestContext.getConnection();
			if(!WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)){
				String errMsg = entityType + " " + entityReference + " was not found. Please check input parameters.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("DocumentPackageManagementServiceImplV3", "listAllDocumentPackages", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}

			//Call package for getting document package information
			callStmt = conn.prepareCall("{ ? = call k_document_package_management.f_get_available_packages(?,?,?,?)}");
			callStmt.registerOutParameter(1, OracleTypes.CURSOR);
			callStmt.registerOutParameter(5, Types.INTEGER);
			callStmt.setString(2, entityType);
			callStmt.setString(3, entityReference);
			callStmt.setString(4, user.getFullName());
			callStmt.execute();

			long count=callStmt.getInt(5);

			if (count>0) {
				rs = (ResultSet) callStmt.getObject(1);
				while (rs.next()) {
					DocumentPackageV3 docPackage=new DocumentPackageV3();

					String packageId = rs.getString("dpa_id");
					String packageDisplayName = rs.getString("dpa_display_name");
					String packageDateCreate = rs.getString("dpa_date_created");
					String userHasPrivilege= "N";
					String isMultiOccurring = rs.getString("dpa_is_multi_occ");
					String formNumbers = rs.getString("dpa_multiocc_forms");
		    		try{
		    			userHasPrivilege = user.hasPrivileges(Long.parseLong(packageId), "Document Package", AdminX.VIEW_PRIVILEGE);
		    		}
		    		catch(Exception e){
		    			WebServiceLoggerUtil.logInfo("DocumentPackageManagementServiceImplV3", "listAllDocumentPackages", e.getLocalizedMessage(), new Object[] { e.getMessage() });
		    		}
		    		if("Y".equals(userHasPrivilege)){
		    			if ("Y".equals(isMultiOccurring) && (null != formNumbers || !"".equals(formNumbers))) {
		    				String formNumbersSplit [] = formNumbers.split(";");
		    				String firstFormName = formNumbersSplit[0];
		    				List<String > occurrenceData = DocumentPackageUtil.getOccurrenceSQLResult(firstFormName, entityReference, entityType, user);
		    				if( occurrenceData.isEmpty()) {
				    			docPackage.setDocumentPackageId(Long.parseLong(packageId));
				    			docPackage.setDocumentPackageName(packageDisplayName);
				    			docPackage.setDocumentPackageDate(packageDateCreate);
				    			docPackage.setDocumentOccurrenceNo(null);
				    			listOfPackages.add(docPackage);
		    				} else {
			    				for (String data : occurrenceData) {
			    					DocumentPackageV3 newDoc = new DocumentPackageV3();
			    					String [] splitData = data.split("~");
			    	    			String formOccurrence = splitData[0];
			    	    			String formTitle = splitData[1];
			    	    			int index = formTitle.lastIndexOf("-");
			    	    			if(index != -1 ) {
			    	    				formTitle = formTitle.substring(index);
			    	    			} else {
			    	    				formTitle = "-" + formOccurrence;
			    	    			}
			    	    			newDoc.setDocumentPackageName(packageDisplayName + formTitle);
			    	        		newDoc.setDocumentPackageId(Long.parseLong(packageId));
			    	        		newDoc.setDocumentOccurrenceNo(formOccurrence);
			    	        		newDoc.setDocumentPackageDate(packageDateCreate);
			    	        		listOfPackages.add(newDoc);
			    				}
		    				}
		    			}else {
			    			docPackage.setDocumentPackageId(Long.parseLong(packageId));
			    			docPackage.setDocumentPackageName(packageDisplayName);
			    			docPackage.setDocumentPackageDate(packageDateCreate);
			    			docPackage.setDocumentOccurrenceNo(null);
			    			listOfPackages.add(docPackage);
			    			
		    			}
		    			
		    		}
				}
			}

		}catch(Exception e){
			WebServiceLoggerUtil.logError("DocumentPackageManagementServiceImplV3", "listAllDocumentPackages", e.getLocalizedMessage(), new Object[] {  }, e);
			throw e;
		}finally{
			try{
				DBUtil.close(rs, callStmt);
			}catch(Exception e){
				WebServiceLoggerUtil.logError("DocumentPackageManagementServiceImplV3", "listAllDocumentPackages", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			}
		}
		return listOfPackages;
	}

	@Override
	public Response downloadDocumentPackage(HttpServletRequest request,String documentPackageId,String printDuplex, String printAllRevisions) throws Exception{
		boolean invalid=false;
		String errMsg = "";

		String occurrenceNo = request.getParameter("documentOccurrenceNo");
		
		//Check document Package Id
		if(documentPackageId==null || documentPackageId.equalsIgnoreCase("")){
			invalid=true;
			errMsg+="documentPackageId is a required parameter.";
		}

		long validatedPackageId=0;

		try{
			validatedPackageId=Long.parseLong(documentPackageId);
		}catch(Exception exp){
			invalid=true;
			errMsg+="Invalid value for documentPackageId.";
		}

		//Check print all revisions
		if(printAllRevisions==null){
			printAllRevisions="false";
		} else if(printAllRevisions.equalsIgnoreCase("Y") || printAllRevisions.equalsIgnoreCase("N")){
			printAllRevisions=printAllRevisions.equalsIgnoreCase("Y")?"true":"false";
		}else{
			invalid=true;
			errMsg+="Invalid value of printAllRevisions- it should be Y or N.";   
		}

		//Check printDuplex
		if(printDuplex==null){
			printDuplex="false";
		} else if(printDuplex.equalsIgnoreCase("Y") || printDuplex.equalsIgnoreCase("N")){
			printDuplex=printDuplex.equalsIgnoreCase("Y")?"true":"false";
		}else{
			invalid=true;
			errMsg+="Invalid value of printDuplex- it should be Y or N.";   
		}
		
		long validatedOccurenceNo = 0;
		try {
			if(null != occurrenceNo)// occurrenceNo is not a required field hence it can be null for non multi-occurring documents.
				validatedOccurenceNo = Long.parseLong(occurrenceNo);
		}catch(Exception e ) {
			invalid = true;
			errMsg+="Invalid value for documentOccurrenceNo.";
		}
		
		if(invalid){
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
			WebServiceLoggerUtil.logInfo("DocumentPackageManagementServiceImplV3", "downloadDocumentPackage", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}

		//Check package existence
		boolean packageIdExists=false;
		List<DocumentPackage> docPackages=listAllDocumentPackages(request);
		for(DocumentPackage docPackage:docPackages){
			if(docPackage.getDocumentPackageId()==validatedPackageId){
				packageIdExists=true;
				break;
			}
		}

		if(!packageIdExists){
			String errMsgPackage = documentPackageId + " doesn't exist for " + entityReference;
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsgPackage));
			String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
			WebServiceLoggerUtil.logInfo("DocumentPackageManagementServiceImplV3", "downloadDocumentPackage", errMsgPackage, new Object[] { errMsgPackage });
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}

		try{
			String serverName = null;	
			String serverEndPoint = null;
			if(MachineInfoUtil.isContainerMode()){
				serverName  = MachineInfoUtil.getSiteName();
				
			}else{
				InetAddress ipAddr = InetAddress.getLocalHost();
				serverName = "http://"+ipAddr.getCanonicalHostName();
			}
			serverEndPoint=DOCUMENT_SERVLET_ENDPOINT+"?entityReference="+entityReference+
					"&packageId="+documentPackageId+"&isStandalone=Y&userDomain="+user.getDomain()+
					"&useDuplex="+printDuplex+"&full="+printAllRevisions+ "&occurrenceNo="+occurrenceNo;

			final String serverNameForLog = serverName;
			URL url = new URL(serverName+serverEndPoint);
			final HttpURLConnection urlConn = (HttpURLConnection) url.openConnection();
			urlConn.setRequestMethod("POST");
			String fileName=entityReference+"_Package_"+documentPackageId+".pdf";
			StreamingOutput fileStream =  new StreamingOutput()
			{
				@Override
				public void write(java.io.OutputStream output) throws IOException
				{
					try{
						byte[] data = IOUtils.readBytesFromStream(urlConn.getInputStream());
						output.write(data);
						output.flush();
					}catch (Exception e){
						String errMsgPackage ="Failed while downloading document package from host-"+serverNameForLog
								+" isContainerMode:" +MachineInfoUtil.isContainerMode() 
								+" url:" +url.toString();
						List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsgPackage));
						String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
						WebServiceLoggerUtil.logError("DocumentPackageManagementServiceImplV3", "downloadDocumentPackage", errMsgPackage, new Object[] { errMsgPackage }, e);
						throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
					}
				}
			};
			return Response
					.ok(fileStream, MediaType.APPLICATION_OCTET_STREAM)
					.header("content-disposition","attachment; filename = "+fileName+"")
					.build();
		}catch(Exception exp){
			WebServiceLoggerUtil.logError("DocumentPackageManagementServiceImplV3", "downloadDocumentPackage", exp.getMessage(), new Object[] {  "Error while calling servlet for retrieveing package"+exp.getMessage() }, exp);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(exp.getLocalizedMessage())),exp);
		}
	}	

	
	private List<Message> getErrorMessageList(List<String> strMessages)	{
		if(strMessages == null)	{
			return null;
		}
		List<Message> errorMessageList = new ArrayList<Message>(strMessages.size());
		for(String aMsg : strMessages)	{
			Message message = new Message();
			message.setMoreinfo(aMsg);
			errorMessageList.add(message);
		}
		return errorMessageList;
	}
	
	@Override
	public String ping() {
		return "Document Packager Service v3 Working";
	}
	
	
}
