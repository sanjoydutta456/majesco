
package com.coverall.mic.rest.http;


import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;

import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;

public class BasicAuthenticationFilterChallenge implements Filter {

    private FilterConfig filterConfig;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        this.filterConfig = filterConfig;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException,
            ServletException {

        if (request instanceof HttpServletRequest) {
            try {
                boolean hasBasicAuthenticationCredentials = hasBasicAuthenticationCredentials((HttpServletRequest) request);
                if (!hasBasicAuthenticationCredentials) {
                    // this prompts for password on browser
                    ((HttpServletResponse) response).setHeader("WWW-Authenticate", "Basic realm=\"RestServices\"");
                    ((HttpServletResponse) response).sendError(HttpServletResponse.SC_UNAUTHORIZED, "");
                    return;
                }
            } catch (Exception ex) {
                LogMinder.getLogMinder().log(
                        LogEntry.SEVERITY_FATAL,
                        getClass().getName(),
                        new Exception().getStackTrace()[0].toString(),
                        ServletConfigUtil.COMPONENT_PORTAL,
                        new Object[] {},
                        "User could not be authenticated " + ex.getMessage(),
                        null,
                        LogMinderDOMUtil.VALUE_MIC);
                ((HttpServletResponse) response).setHeader("WWW-Authenticate", "Basic realm=\"RestServices\"");
                ((HttpServletResponse) response).sendError(HttpServletResponse.SC_UNAUTHORIZED, "");
                return;
            }
        }

        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {
        this.filterConfig = null;
    }

    FilterConfig getFilterConfig() {
        return filterConfig;
    }

    void setFilterConfig(FilterConfig filterConfig) {
        this.filterConfig = filterConfig;
    }

    private boolean hasBasicAuthenticationCredentials(HttpServletRequest request) {
        String authhead = request.getHeader("Authorization");
        if (authhead != null) {
            // *****Decode the authorisation String*****
            String usernpass = new String(new Base64().decode(authhead.substring(6)));
            // *****Split the username from the password*****
            if (null != usernpass && !"".equals(usernpass)) {
                return true;
            }

        }
        return false;
    }
}
