package com.coverall.mic.rest.parties.underwriter.model;

public class UnderwriterAssignment {
	
	String sourceSystemUserId;
	String sourceSystemCode;
	long sourceSystemRequestNo;
	int uwAssignmentId;
	String underWriterCode;
	double ruleweight;
	String premiumLowRange;
	String premiumHighRange;
	String policyEffectiveDate;
	String programCode;
	String policySymbol;
	String serviceCenter;
	String district;
	String businessType;
	String producerCode;
	String producerStateProvince;
	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}
	public void setSourceSystemUserId(String sourceSystemUserId) {
		this.sourceSystemUserId = sourceSystemUserId;
	}
	public String getSourceSystemCode() {
		return sourceSystemCode;
	}
	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}
	public long getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}
	public void setSourceSystemRequestNo(long sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}
	public int getUwAssignmentId() {
		return uwAssignmentId;
	}
	public void setUwAssignmentId(int uwAssignmentId) {
		this.uwAssignmentId = uwAssignmentId;
	}
	public String getUnderWriterCode() {
		return underWriterCode;
	}
	public void setUnderWriterCode(String underWriterCode) {
		this.underWriterCode = underWriterCode;
	}
	public double getRuleweight() {
		return ruleweight;
	}
	public void setRuleweight(double ruleweight) {
		this.ruleweight = ruleweight;
	}
	public String getPremiumLowRange() {
		return premiumLowRange;
	}
	public void setPremiumLowRange(String premiumLowRange) {
		this.premiumLowRange = premiumLowRange;
	}
	public String getPremiumHighRange() {
		return premiumHighRange;
	}
	public void setPremiumHighRange(String premiumHighRange) {
		this.premiumHighRange = premiumHighRange;
	}
	public String getPolicyEffectiveDate() {
		return policyEffectiveDate;
	}
	public void setPolicyEffectiveDate(String policyEffectiveDate) {
		this.policyEffectiveDate = policyEffectiveDate;
	}
	public String getProgramCode() {
		return programCode;
	}
	public void setProgramCode(String programCode) {
		this.programCode = programCode;
	}
	public String getPolicySymbol() {
		return policySymbol;
	}
	public void setPolicySymbol(String policySymbol) {
		this.policySymbol = policySymbol;
	}
	public String getServiceCenter() {
		return serviceCenter;
	}
	public void setServiceCenter(String serviceCenter) {
		this.serviceCenter = serviceCenter;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getBusinessType() {
		return businessType;
	}
	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}
	public String getProducerCode() {
		return producerCode;
	}
	public void setProducerCode(String producerCode) {
		this.producerCode = producerCode;
	}
	public String getProducerStateProvince() {
		return producerStateProvince;
	}
	public void setProducerStateProvince(String producerStateProvince) {
		this.producerStateProvince = producerStateProvince;
	}
}
