package com.coverall.mic.rest.parties.underwriter.model;

import java.util.List;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyPagination;

public class UnderwriterListResponse {
	
	List<Underwriter> underwiters; 
	QuotePolicyPagination pagination;
	
	public List<Underwriter> getUnderwiters() {
		return underwiters;
	}
	public void setUnderwiters(List<Underwriter> underwiters) {
		this.underwiters = underwiters;
	}
	public QuotePolicyPagination getPagination() {
		return pagination;
	}
	public void setPagination(QuotePolicyPagination pagination) {
		this.pagination = pagination;
	}
}
