package com.coverall.mic.rest.parties.underwriter.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import com.coverall.mic.rest.distribution.producers.model.Producer;
import com.coverall.mic.rest.distribution.producers.model.ProducerListingResponse;
import com.coverall.mic.rest.parties.underwriter.model.Underwriter;
import com.coverall.mic.rest.parties.underwriter.model.UnderwriterAssignment;
import com.coverall.mic.rest.parties.underwriter.model.UnderwriterListResponse;
import com.coverall.mic.rest.parties.underwriter.service.UnderwriterManagementService;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyPagination;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mic.rest.policy.api.service.util.WorkflowUtil;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.security.authentication.User;
import com.coverall.util.DBUtil;

public class UnderwriterManagementServiceImpl implements UnderwriterManagementService {
	
	private String queryForFetchingUnderwriterInfo="SELECT * FROM (SELECT SUN_UNDERWRITER_ID underwriterId, SUN_UNDERWRITER_CODE underwriterCode,SUN_UNDERWRITER_CODE UNDERWRITER_CODE, SUN_UNDERWRITER_NAME underwriterName,"+
												   "to_char(SUN_EXPIRATION_DATE,'YYYY-MM-DD') expirationDate, SUN_USER_ID userId, (SUN_ADDRESS_1||' '||SUN_ADDRESS_2) addressLine,SUN_CITY city, SUN_STATE_PROVINCE state,"+ 
												   "SUN_COUNTRY country, SUN_POSTAL_CODE zipCode, SUN_TELEPHONE telephone, SUN_EMAIL_ID email, SUN_LICENSE_ID licenseId,case when (SUN_EXPIRATION_DATE<SYSDATE) then 'Y' ELSE 'N'"+
												   " END isExpired FROM shl_underwriters) WHERE 1=1 AND underwriterCode != '99'";
	
	private String queryForFetchingUnderwriterAssignmentInfo="SELECT * FROM (SELECT SUA_ASSIGNMENT_ID uwAssignmentId, (SELECT sun_underwriter_code FROM SHL_UNDERWRITERS WHERE sun_underwriter_id=sua_underwriter_id AND rownum<2) UNDERWRITER_CODE,"+
															 "sua_rule_weight ruleweight, sua_premium_high_range premiumHighRange,sua_premium_low_range premiumLowRange,to_char(sua_policy_effective_date,'YYYY-MM-DD') policyEffectiveDate,"+
															 "sua_program_code programCode,sua_policy_symbol policySymbol,sua_service_center_number serviceCenter,sua_district_number district,sua_business_type businessType,sua_producer_id producerCode,"+
															 "sua_producer_state_province producerStateProvince FROM SHL_UNDERWRITER_ASSIGNMENTS WHERE sua_underwriter_id=?) WHERE 1=1";

	@Override
	public UnderwriterListResponse getUnderwriterInformation(
			HttpServletRequest request, int pageSize, int pageNumber)
			throws Exception {
		UnderwriterListResponse responseObject=new UnderwriterListResponse();
		QuotePolicyPagination paginationInfo=null;
		
		//This url is used for producing pagination links
		String url = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getRequestURI()+"?"+(request.getQueryString()==null?"":request.getQueryString());
		
		if(pageSize==0){
			pageSize=10;
		}
		if(pageNumber==0){
			pageNumber=1;
		}
		
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		User user=requestContext.getUser();
		List<Underwriter> underwriterList=new ArrayList<Underwriter>();
		Connection conn=null;
		PreparedStatement psUnderwriterInfo=null;
		ResultSet rsUnderwriterInfo=null;

		String sourceSystemUserId="";
		long sourceSystemRequestNo=System.currentTimeMillis();
		
		//DLS check
		queryForFetchingUnderwriterInfo+=APIOperationUtil.resolveDLSExpression(com.coverall.mt.http.User.getUser(request), APIConstant.DLS_EXPRESSION_STRING_UNDERWRITER);
		
		if(!WorkflowUtil.checkIfUserHasTheRequiredPermission(user, APIConstant.VIEW_UNDERWRITER_PERMISSION)) {
			String errMsg = user.getUserId()+" doesn't have permission to view underwriters.";
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			WebServiceLoggerUtil.logInfo("UnderwriterManagementServiceImpl", "getUnderwriterInformation", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
		}

		try{
			conn=requestContext.getConnection();
			
			paginationInfo=APIOperationUtil.populatePaginationInformation(url, conn, queryForFetchingUnderwriterInfo, pageNumber, pageSize);
			
			String finalExecutableQueryForResults="SELECT  *  FROM (SELECT ROWNUM rnum, z.* FROM ("+queryForFetchingUnderwriterInfo+") z WHERE ROWNUM<= ?) WHERE rnum>= ?";
			//Fetching results
			psUnderwriterInfo=conn.prepareStatement(finalExecutableQueryForResults);
			psUnderwriterInfo.setString(1, paginationInfo.getEndIndex());
			psUnderwriterInfo.setString(2, paginationInfo.getStartIndex());
			rsUnderwriterInfo=psUnderwriterInfo.executeQuery();

			while(rsUnderwriterInfo.next()){
				Underwriter underwriter=new Underwriter();
				
				underwriter.setSourceSystemRequestNo(sourceSystemRequestNo);
				underwriter.setSourceSystemUserId(user.getName());
				underwriter.setSourceSystemCode("MIC");
				underwriter.setAddressLine(rsUnderwriterInfo.getString("addressLine"));
				underwriter.setCity(rsUnderwriterInfo.getString("city"));
				underwriter.setState(rsUnderwriterInfo.getString("state"));
				underwriter.setCountry(rsUnderwriterInfo.getString("country"));
				underwriter.setEmail(rsUnderwriterInfo.getString("email"));
				underwriter.setTelephone(rsUnderwriterInfo.getString("telephone"));
				underwriter.setUnderWriterCode(rsUnderwriterInfo.getString("underwriterCode"));
				underwriter.setUnderWriterId(rsUnderwriterInfo.getInt("underwriterId"));
				underwriter.setExpirationDate(rsUnderwriterInfo.getString("expirationDate"));
				underwriter.setIsExpired(rsUnderwriterInfo.getString("isExpired"));
				underwriter.setUnderwriterName(rsUnderwriterInfo.getString("underwriterName"));
				underwriter.setZipCode(rsUnderwriterInfo.getString("zipCode"));
				underwriter.setUserId(rsUnderwriterInfo.getString("userId"));
				underwriter.setLicenseId(rsUnderwriterInfo.getString("licenseId"));
				
				underwriterList.add(underwriter);

			}
			
			responseObject.setPagination(paginationInfo);
			responseObject.setUnderwiters(underwriterList);
		}catch(APIException exp){
			throw exp;
		}catch(Exception exp){
			WebServiceLoggerUtil.logError("UnderwriterManagementServiceImpl", "getUnderwriterInformation", "Exception occurred while fetching underwriter information", new Object[] { queryForFetchingUnderwriterInfo }, exp);
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(exp.getMessage()));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,exp);

		}finally{
			try{
				DBUtil.close(rsUnderwriterInfo, psUnderwriterInfo);
			}catch(Exception exp){
				WebServiceLoggerUtil.logInfo("UnderwriterManagementServiceImpl", "getUnderwriterInformation", exp.getLocalizedMessage(), new Object[] { exp.getMessage() });	
			}

		}
		return responseObject;

	}

	@Override
	public Underwriter getSpecificUnderwriterInformation(HttpServletRequest request,String underwriterId) throws Exception {
		Underwriter underwriterObject=new Underwriter();
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		User user=requestContext.getUser();
		Connection conn=null;
		PreparedStatement psUnderwriterInfo=null;
		ResultSet rsUnderwriterInfo=null;
		long sourceSystemRequestNo=System.currentTimeMillis();
		
		//DLS check
		queryForFetchingUnderwriterInfo+=" AND underwriterId=? "+APIOperationUtil.resolveDLSExpression(com.coverall.mt.http.User.getUser(request), APIConstant.DLS_EXPRESSION_STRING_UNDERWRITER)+" AND rownum<2";
		
		if(!WorkflowUtil.checkIfUserHasTheRequiredPermission(user, APIConstant.VIEW_UNDERWRITER_PERMISSION)) {
			String errMsg = user.getUserId()+" doesn't have permission to view underwriters.";
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			WebServiceLoggerUtil.logInfo("UnderwriterManagementServiceImpl", "getUnderwriterInformation", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
		}

		try{
			conn=requestContext.getConnection();
			boolean underwriterPresent=false;
			String finalExecutableQueryForResults=queryForFetchingUnderwriterInfo;
			//Fetching results
			psUnderwriterInfo=conn.prepareStatement(finalExecutableQueryForResults);
			
			psUnderwriterInfo.setString(1, underwriterId);
			
			rsUnderwriterInfo=psUnderwriterInfo.executeQuery();

			while(rsUnderwriterInfo.next()){
				underwriterPresent=true;
				Underwriter underwriter=new Underwriter();
				underwriter.setSourceSystemRequestNo(sourceSystemRequestNo);
				underwriter.setSourceSystemUserId(user.getName());
				underwriter.setSourceSystemCode("MIC");
				underwriter.setAddressLine(rsUnderwriterInfo.getString("addressLine"));
				underwriter.setCity(rsUnderwriterInfo.getString("city"));
				underwriter.setState(rsUnderwriterInfo.getString("state"));
				underwriter.setCountry(rsUnderwriterInfo.getString("country"));
				underwriter.setEmail(rsUnderwriterInfo.getString("email"));
				underwriter.setTelephone(rsUnderwriterInfo.getString("telephone"));
				underwriter.setUnderWriterCode(rsUnderwriterInfo.getString("underwriterCode"));
				underwriter.setUnderWriterId(rsUnderwriterInfo.getInt("underwriterId"));
				underwriter.setExpirationDate(rsUnderwriterInfo.getString("expirationDate"));
				underwriter.setIsExpired(rsUnderwriterInfo.getString("isExpired"));
				underwriter.setUnderwriterName(rsUnderwriterInfo.getString("underwriterName"));
				underwriter.setZipCode(rsUnderwriterInfo.getString("zipCode"));
				underwriter.setUserId(rsUnderwriterInfo.getString("userId"));
				underwriter.setLicenseId(rsUnderwriterInfo.getString("licenseId"));
				
				underwriterObject=underwriter;

			}
			if(!underwriterPresent){
				String errMsg = "Either there is no underwriter in the system with id:"+underwriterId+" or is inaccessible to the user "+user.getUserId()+". Please verify underwriter id.";
				List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("UnderwriterManagementServiceImpl", "getSpecificUnderwriterInformation", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.UNDERWRITER_NOT_FOUND,errorMessageList,null);
			}
			
		}catch(APIException exp){
			throw exp;
		}catch(Exception exp){
			WebServiceLoggerUtil.logError("UnderwriterManagementServiceImpl", "getSpecificUnderwriterInformation", "Exception occurred while fetching underwriter information", new Object[] { queryForFetchingUnderwriterInfo }, exp);
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(exp.getMessage()));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,exp);

		}finally{
			try{
				DBUtil.close(rsUnderwriterInfo, psUnderwriterInfo);
			}catch(Exception exp){
				WebServiceLoggerUtil.logInfo("UnderwriterManagementServiceImpl", "getSpecificUnderwriterInformation", exp.getLocalizedMessage(), new Object[] { exp.getMessage() });	
			}

		}
		return underwriterObject;
	}

	@Override
	public List<UnderwriterAssignment> getUnderwriterAssignmentInformation(
			HttpServletRequest request, String underwriterId) throws Exception {
		List<UnderwriterAssignment> underwriterAssignments=new ArrayList<UnderwriterAssignment>();
		
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		User user=requestContext.getUser();
		Connection conn=null;
		PreparedStatement psUnderwriterAssignment=null;
		ResultSet rsUnderwriterAssignment=null;

		long sourceSystemRequestNo=System.currentTimeMillis();
		
		
		//This method will check if underwriter Id is valid and user has access to it.
		getSpecificUnderwriterInformation(request, underwriterId);
		//DLS check
		//queryForFetchingUnderwriterAssignmentInfo+=APIOperationUtil.resolveDLSExpression(com.coverall.mt.http.User.getUser(request), APIConstant.DLS_EXPRESSION_STRING_UNDERWRITER);
		
		if(!WorkflowUtil.checkIfUserHasTheRequiredPermission(user, APIConstant.VIEW_UNDERWRITER_PERMISSION)) {
			String errMsg = user.getUserId()+" doesn't have permission to view underwriters.";
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			WebServiceLoggerUtil.logInfo("UnderwriterManagementServiceImpl", "getUnderwriterAssignmentInformation", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
		}

		try{
			conn=requestContext.getConnection();
			boolean underwriterAssignmentPresent=false;
			String finalExecutableQueryForResults=queryForFetchingUnderwriterAssignmentInfo;
			//Fetching results
			psUnderwriterAssignment=conn.prepareStatement(finalExecutableQueryForResults);
			psUnderwriterAssignment.setString(1, underwriterId);
			rsUnderwriterAssignment=psUnderwriterAssignment.executeQuery();

			while(rsUnderwriterAssignment.next()){
				underwriterAssignmentPresent=true;
				UnderwriterAssignment uwAssignment=new UnderwriterAssignment();
				uwAssignment.setSourceSystemRequestNo(sourceSystemRequestNo);
				uwAssignment.setSourceSystemUserId(user.getName());
				uwAssignment.setSourceSystemCode("MIC");
				uwAssignment.setUwAssignmentId(rsUnderwriterAssignment.getInt("uwAssignmentId"));
				uwAssignment.setBusinessType(rsUnderwriterAssignment.getString("businessType"));
				uwAssignment.setDistrict(rsUnderwriterAssignment.getString("district"));
				uwAssignment.setPolicyEffectiveDate(rsUnderwriterAssignment.getString("policyEffectiveDate"));
				uwAssignment.setPolicySymbol(rsUnderwriterAssignment.getString("policySymbol"));
				uwAssignment.setPremiumHighRange(rsUnderwriterAssignment.getString("premiumHighRange"));
				uwAssignment.setPremiumLowRange(rsUnderwriterAssignment.getString("premiumLowRange"));
				uwAssignment.setProducerCode(rsUnderwriterAssignment.getString("producerCode"));
				uwAssignment.setProducerStateProvince(rsUnderwriterAssignment.getString("producerStateProvince"));
				uwAssignment.setProgramCode(rsUnderwriterAssignment.getString("programCode"));
				uwAssignment.setRuleweight(rsUnderwriterAssignment.getDouble("ruleweight"));
				uwAssignment.setServiceCenter(rsUnderwriterAssignment.getString("serviceCenter"));
				uwAssignment.setUnderWriterCode(rsUnderwriterAssignment.getString("UNDERWRITER_CODE"));
				
				underwriterAssignments.add(uwAssignment);

			}
			if(!underwriterAssignmentPresent){
				String errMsg = "There is no assignment in system for underwriter id:"+underwriterId;
				List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("UnderwriterManagementServiceImpl", "getUnderwriterAssignmentInformation", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.UNDERWRITER_NOT_FOUND,errorMessageList,null);
			}
			
		}catch(APIException exp){
			throw exp;
		}catch(Exception exp){
			WebServiceLoggerUtil.logError("UnderwriterManagementServiceImpl", "getUnderwriterAssignmentInformation", "Exception occurred while fetching underwriter assignment information", new Object[] { queryForFetchingUnderwriterAssignmentInfo }, exp);
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(exp.getMessage()));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,exp);

		}finally{
			try{
				DBUtil.close(rsUnderwriterAssignment, psUnderwriterAssignment);
			}catch(Exception exp){
				WebServiceLoggerUtil.logInfo("UnderwriterManagementServiceImpl", "getUnderwriterAssignmentInformation", exp.getLocalizedMessage(), new Object[] { exp.getMessage() });	
			}

		}
		return underwriterAssignments;
	}

}
