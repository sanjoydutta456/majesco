package com.coverall.mic.rest.policy.api.customer.model;

import javax.xml.bind.annotation.XmlRootElement;

public class ConfiguredEvent {
	/*protected String requestDate;
	protected String sourceSystemRequestNo;
	protected String sourceSystemUserId;
	protected String sourceSystemUserName;
	protected String sourceSystemCode;*/
	//protected String eventCode;
	protected String eventName;
	protected String isDefaultEvent;
	
	


	/*public String getRequestDate() {
		return requestDate;
	}


	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}


	public String getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}


	public void setSourceSystemRequestNo(String sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}


	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}


	public void setSourceSystemUserId(String sourceSystemUserId) {
		this.sourceSystemUserId = sourceSystemUserId;
	}


	public String getSourceSystemUserName() {
		return sourceSystemUserName;
	}


	public void setSourceSystemUserName(String sourceSystemUserName) {
		this.sourceSystemUserName = sourceSystemUserName;
	}


	public String getSourceSystemCode() {
		return sourceSystemCode;
	}


	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}*/


	/*public String getEventCode() {
		return eventCode;
	}


	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}*/


	public String getEventName() {
		return eventName;
	}


	public void setEventName(String eventName) {
		this.eventName = eventName;
	}


	public String getIsDefaultEvent() {
		return isDefaultEvent;
	}


	public void setIsDefaultEvent(String isDefaultEvent) {
		this.isDefaultEvent = isDefaultEvent;
	}

	
	@Override
	public String toString() {
		return "CustomerConfiguredEvent [eventName="	+ eventName + "]";
	}

}
