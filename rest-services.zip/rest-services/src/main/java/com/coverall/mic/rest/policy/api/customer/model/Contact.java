package com.coverall.mic.rest.policy.api.customer.model;

public class Contact {
	String contactJson;
	String ConatctAddressJson;
	
	
	public String getContactJson() {
		return contactJson;
	}
	public void setContactJson(String contactJson) {
		this.contactJson = contactJson;
	}
	public String getConatctAddressJson() {
		return ConatctAddressJson;
	}
	public void setConatctAddressJson(String conatctAddressJson) {
		ConatctAddressJson = conatctAddressJson;
	}
}
