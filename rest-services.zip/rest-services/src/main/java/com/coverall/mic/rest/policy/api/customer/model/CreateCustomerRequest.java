package com.coverall.mic.rest.policy.api.customer.model;

import javax.xml.bind.annotation.XmlRootElement;

@SuppressWarnings("serial")
@XmlRootElement(name="CreateCustomerRequest")

public class CreateCustomerRequest implements java.io.Serializable {
	private String json;
	
	public CreateCustomerRequest(){
	}
	
	public CreateCustomerRequest(String json) {
		super(); 
		this.json = json;
	}
	
	public String getJson() {
		return json;
	}

	public void setJson(String json) {
		this.json = json;
	}

	@Override
	public String toString() {
		return "CreateCustomerRequest [json=" + json + "]";
	}
	
}