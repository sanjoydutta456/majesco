package com.coverall.mic.rest.policy.api.customer.model;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlRootElement;

public class CustomerEvent {
	
	// Need to change varaible nameas as per Event object response definition 
	protected String customerNo;
	protected String eventFromDate;
	protected String eventToDate;
	protected ArrayList<EventDetail> eventDetails;

	
	public String getCustomerNo() {
		return customerNo;
	}


	public void setCustomerNo(String customerNo) {
		this.customerNo = customerNo;
	}


	public String getEventFromDate() {
		return eventFromDate;
	}


	public void setEventFromDate(String eventFromDate) {
		this.eventFromDate = eventFromDate;
	}


	public String getEventToDate() {
		return eventToDate;
	}


	public void setEventToDate(String eventToDate) {
		this.eventToDate = eventToDate;
	}


	public ArrayList<EventDetail> getEventDetails() {
		return eventDetails;
	}


	public void setEventDetails(ArrayList<EventDetail> eventDetails) {
		this.eventDetails = eventDetails;
	}


	@Override
	public String toString() {
		return "CustomerEvent [customerNo=" + customerNo 
				+ ", eventFromDate=" + eventFromDate 
				+ ", eventToDate=" + eventToDate
				+ ", eventDetails=" + eventDetails +"]";
	}

}
