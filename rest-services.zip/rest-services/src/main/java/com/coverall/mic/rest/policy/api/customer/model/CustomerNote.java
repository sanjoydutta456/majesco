package com.coverall.mic.rest.policy.api.customer.model;

import java.util.ArrayList;
import java.util.HashMap;


public class CustomerNote {
	protected String application;
	protected String policyNo;
	protected String noteDate;
	protected String noteText;
	
	public enum attachments {N,Y}
	
	protected attachments hasAttachment = attachments.N;
	
	//protected ArrayList<HashMap> actions = new ArrayList<HashMap>();
	protected ArrayList<HashMap> navigation = new ArrayList<HashMap>();
	
	public CustomerNote(){
		
	}
	
	public String getApplication() {
		return application;
	}
	public void setApplication(String application) {
		this.application = application;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getNoteDate() {
		return noteDate;
	}
	public void setNoteDate(String noteDate) {
		this.noteDate = noteDate;
	}
	public String getNoteText() {
		return noteText;
	}
	public void setNoteText(String noteText) {
		this.noteText = noteText;
	}
	
	
	
	public attachments getHasAttachment() {
		return hasAttachment;
	}
	public void setHasAttachment(attachments hasAttachment) {
		this.hasAttachment = hasAttachment;
	}
	/*public ArrayList<HashMap> getActions() {
		return actions;
	}

	public void setActions(ArrayList<HashMap> actions) {
		this.actions = actions;
	}*/

	public ArrayList<HashMap> getNavigation() {
		return navigation;
	}

	public void setNavigation(ArrayList<HashMap> navigations) {
		this.navigation = navigations;
	}

	@Override
	public String toString() {
		return "CustomerNotes [application=" + application + ", policyNo="
				+ policyNo + ", noteDate=" + noteDate + ", noteText="
				+ noteText + ", hasAttachment=" + hasAttachment + "]";
	}
	
	
	

}
