package com.coverall.mic.rest.policy.api.customer.model;

import java.util.List;
import java.util.ArrayList;

public class CustomerNotes {

	private List <CustomerNote> notes =  new ArrayList <CustomerNote>() ;
	
	public CustomerNotes() {
		super();
	}

	public List<CustomerNote> getNotes() {
		return notes;
	}

	public void setNotes(List<CustomerNote> notes) {
		this.notes = notes;
	}
}
