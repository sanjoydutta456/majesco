package com.coverall.mic.rest.policy.api.customer.model;

import javax.xml.bind.annotation.XmlRootElement;

import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mt.http.User;
import com.google.gson.Gson;

@SuppressWarnings("serial")
@XmlRootElement(name="CustomerRequest")
public class CustomerRequest  implements java.io.Serializable  {	
	
	public CustomerRequest(){
		
	}

	public CustomerRequest(String json) {
		super(); 
		Gson gson = new Gson();
		CustomerRequest request = gson.fromJson(json, CustomerRequest.class);
		this.customerId = request.customerId;
		this.sourceSystemUserId = request.sourceSystemUserId;
		this.requestDate = request.requestDate;
		this.sourceSystemRequestNo = request.sourceSystemRequestNo;
		this.sourceSystemUserName = request.sourceSystemUserName;
		this.pageSize = request.pageSize;
		this.sourceSystemCode = request.sourceSystemCode;
		this.pageNumber = request.pageNumber;
		this.correlationid = request.correlationid;		
		this.eventFromDate = request.eventFromDate;
		this.eventToDate = request.eventToDate;
		this.eventCode = request.eventCode;
		this.accountNo = request.accountNo;
	}
	
	
	String customerId;
	String requestDate;   
	String sourceSystemRequestNo;
	String sourceSystemUserId;
	String sourceSystemUserName;
	String sourceSystemCode;
	Long pageSize;
	Long pageNumber;
	String correlationid;
	String eventFromDate;
	String eventToDate;
	String eventCode;
	String accountNo;
	User user;
	String numberOfNotes;
	
	
	
	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}
	public void setSourceSystemUserId(String userID) {
		this.sourceSystemUserId = userID;
	}

	
	public String getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}

	public String getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}

	public void setSourceSystemRequestNo(String sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}

	public String getSourceSystemUserName() {
		return sourceSystemUserName;
	}

	public void setSourceSystemUserName(String sourceSystemUserName) {
		this.sourceSystemUserName = sourceSystemUserName;
	}

	public String getSourceSystemCode() {
		return sourceSystemCode;
	}

	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}

	public long getPageSize() {
		return pageSize;
	}

	public void setPageSize(long pageSize) {
		this.pageSize = pageSize;
	}

	public long getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(long pageNumber) {
		this.pageNumber = pageNumber;
	}

	public String getCorrelationid() {
		return correlationid;
	}

	public void setCorrelationid(String correlationid) {
		this.correlationid = correlationid;
	}

	public String getEventFromDate() {
		return eventFromDate;
	}

	public void setEventFromDate(String eventFromDate) {
		this.eventFromDate = eventFromDate;
	}

	public String getEventToDate() {
		return eventToDate;
	}

	public void setEventToDate(String eventToDate) {
		this.eventToDate = eventToDate;
	}

	public String getEventCode() {
		return eventCode;
	}

	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	
	

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}	

	public String getNumberOfNotes() {
		return numberOfNotes;
	}

	public void setNumberOfNotes(String numberOfNotes) {
		this.numberOfNotes = numberOfNotes;
	}

	@Override
	public String toString() {
		return "CustomerRequest [customerId=" + customerId + ", requestDate="
				+ requestDate + ", sourceSystemRequestNo="
				+ sourceSystemRequestNo + ", sourceSystemUserId="
				+ sourceSystemUserId + ", sourceSystemUserName="
				+ sourceSystemUserName + ", sourceSystemCode="
				+ sourceSystemCode + ", pageSize=" + pageSize + ", pageNumber="
				+ pageNumber + ", correlationid=" + correlationid
				+ ", eventFromDate=" + eventFromDate + ", eventToDate="
				+ eventToDate + ", eventCode=" + eventCode + ", accountNo="
				+ accountNo + ", user=" + user + ", numberOfNotes="
				+ numberOfNotes + "]";
	}

}
