package com.coverall.mic.rest.policy.api.customer.model;

public class CustomerSummary {
	protected String customerId;
	protected int inforcePolicies;
	protected double inforcePremium;
	
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public int getInforcePolicies() {
		return inforcePolicies;
	}
	public void setInforcePolicies(int inforcePolicies) {
		this.inforcePolicies = inforcePolicies;
	}
	public double getInforcePremium() {
		return inforcePremium;
	}
	public void setInforcePremium(double inforcePremium) {
		this.inforcePremium = inforcePremium;
	}
	
	@Override
	public String toString() {
		return "CustomerSummary [customerId=" + customerId
				+ ", inforcePolicies=" + inforcePolicies + ", inforcePremium="
				+ inforcePremium + "]";
	}
	
}
