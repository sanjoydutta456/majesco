package com.coverall.mic.rest.policy.api.customer.model;

import java.util.HashMap;

public class CustomerTransactions {
	
	private HashMap customerData; 
	private String customerId;
	private boolean isValidTransaction;
	private String message;
	private boolean isLocked;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public boolean isValidTransaction() {
		return isValidTransaction;
	}

	public void setValidTransaction(boolean isValidTransaction) {
		this.isValidTransaction = isValidTransaction;
	}

	
	public HashMap getCustomerData() {
		return customerData;
	}

	public void setCustomerData(HashMap customerData) {
		this.customerData = customerData;
	}
	
	public boolean isLocked() {
		return isLocked;
	}

	public void setLocked(boolean isLocked) {
		this.isLocked = isLocked;
	}

	@Override
	public String toString() {
		return "CustomerTransactionDetails [ customerId= "
				+ customerId + ", isValidTransaction=" +isValidTransaction+ ", customerData="+customerData+", isLocked=" +isLocked+ "]";
	}

}
