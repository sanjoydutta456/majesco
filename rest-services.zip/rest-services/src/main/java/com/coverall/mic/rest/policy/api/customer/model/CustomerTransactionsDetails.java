package com.coverall.mic.rest.policy.api.customer.model;

public class CustomerTransactionsDetails {
	private String transactionName;
	private String customerId;
	private String transUrl;
	private boolean isValidTransaction;
	private String message;
	private boolean isLocked;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getTransactionName() {
		return transactionName;
	}

	public void setTransactionName(String transactionName) {
		this.transactionName = transactionName;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getTransUrl() {
		return transUrl;
	}

	public void setTransUrl(String transUrl) {
		this.transUrl = transUrl;
	}

	public boolean isValidTransaction() {
		return isValidTransaction;
	}

	public void setValidTransaction(boolean isValidTransaction) {
		this.isValidTransaction = isValidTransaction;
	}
	
	public boolean isLocked() {
		return isLocked;
	}

	public void setLocked(boolean isLocked) {
		this.isLocked = isLocked;
	}

	@Override
	public String toString() {
		return "CustomerTransactionDetails [transactionName=" + transactionName + ", customerId="
				+ customerId + ", transUrl=" + transUrl + ", isValidTransaction=" +isValidTransaction+ ", isLocked=" +isLocked+ "]";
	} 

}
