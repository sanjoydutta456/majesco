package com.coverall.mic.rest.policy.api.customer.model;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlRootElement;

public class EventDetail {
	
	// Need to change varaible nameas as per Event object response definition 
	//protected String eventCode;
	protected String eventDescription;
	protected String policyNo;
	protected String policyEffectiveDate;
	protected String amount;  //Need to check type 
	protected String eventDate;
	//protected ArrayList <EventKey> eventKeys;


	
	/*public String getEventCode() {
		return eventCode;
	}



	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}
*/


	public String getEventDescription() {
		return eventDescription;
	}



	public void setEventDescription(String eventDescription) {
		this.eventDescription = eventDescription;
	}



	public String getPolicyNo() {
		return policyNo;
	}



	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}



	public String getPolicyEffectiveDate() {
		return policyEffectiveDate;
	}



	public void setPolicyEffectiveDate(String policyEffectiveDate) {
		this.policyEffectiveDate = policyEffectiveDate;
	}



	public String getAmount() {
		return amount;
	}



	public void setAmount(String amount) {
		this.amount = amount;
	}



	public String getEventDate() {
		return eventDate;
	}



	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}



	@Override
	public String toString() {
		return "EventDetail [eventDescription=" + eventDescription 
				+ ", policyNo=" + policyNo 
				+ ", policyEffectiveDate=" + policyEffectiveDate
				+ ", amount=" + amount 
				+ ", eventDate=" + eventDate + "]";
	}

}
