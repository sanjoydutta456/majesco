package com.coverall.mic.rest.policy.api.customer.model;

import javax.xml.bind.annotation.XmlRootElement;

public class EventKey {
	
	// Need to change varaible nameas as per Event object response definition 
	protected String fullName;
	protected String customerId;
	protected String customerSince;
	protected String mailingAddress;
	protected String contactPerson;
	protected String contactAddress;
	protected String contactPhone;
	protected String contactEmail;

	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCustomerSince() {
		return customerSince;
	}
	public void setCustomerSince(String customerSince) {
		this.customerSince = customerSince;
	}
	public String getMailingAddress() {
		return mailingAddress;
	}
	public void setMailingAddress(String mailingAddress) {
		this.mailingAddress = mailingAddress;
	}
	public String getContactPerson() {
		return contactPerson;
	}
	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}
	public String getContactAddress() {
		return contactAddress;
	}
	public void setContactAddress(String contactAddress) {
		this.contactAddress = contactAddress;
	}
	public String getContactPhone() {
		return contactPhone;
	}
	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}
	public String getContactEmail() {
		return contactEmail;
	}
	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}
	
	@Override
	public String toString() {
		return "CustomerDetails [fullName=" + fullName + ", customerId="
				+ customerId + ", customerSince=" + customerSince
				+ ", mailingAddress=" + mailingAddress + ", contactPerson=" + contactPerson
				+ ", contactAddress=" + contactAddress + ", contactPhone="
				+ contactPhone + ", contactEmail=" + contactEmail + "]";
	}

}
