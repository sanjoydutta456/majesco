package com.coverall.mic.rest.policy.api.customer.model;
import java.util.Arrays;
import org.json.JSONArray;
import org.json.JSONObject;

public class JsonRequest {
	String customerJson;
	String customerAddressJson;
	String agencyJson;
	Contact[] Contacts;
	
	public JsonRequest() {
		super();
	}


	public Contact[] getContacts() {
		return Contacts;
	}
	public void setContacts(Contact[] contacts) {
		Contacts = contacts;
	}
	public String getCustomerJson() {
		return customerJson;
	}
	public void setCustomerJson(String customerJson) {
		this.customerJson = customerJson;
	}
	public String getCustomerAddressJson() {
		return customerAddressJson;
	}
	public void setCustomerAddressJson(String customerAddressJson) {
		this.customerAddressJson = customerAddressJson;
	}
	public String getAgencyJson() {
		return agencyJson;
	}
	public void setAgencyJson(String agencyJson) {
		this.agencyJson = agencyJson;
	}

	
	@Override
	public String toString() {
		return "JsonRequest [customerJson=" + customerJson + ", customerAddressJson=" + customerAddressJson
				+ ", agencyJson=" + agencyJson + ", Contacts=" + Arrays.toString(Contacts) + "]";
	}	

}
