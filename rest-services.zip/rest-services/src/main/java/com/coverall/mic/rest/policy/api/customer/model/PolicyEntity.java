package com.coverall.mic.rest.policy.api.customer.model;

import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.bind.annotation.XmlRootElement;

public class PolicyEntity
{
	// Need to change varaible nameas as per Event object response definition
	
	public String customerId;
	public String accountNumber;
	public String policyNumber;
	public String entityType;
	//public String fullName;
	public String effectiveDate;
	public String productName;
	public String status;
	public String billType;
	public double premium;
	//public String paid;
	//public String oepnClaimNumber;
	public ArrayList<HashMap> actions = new ArrayList<HashMap>();
	public ArrayList<HashMap> navigations = new ArrayList<HashMap>();
	


	
	public String getCustomerId() {
		return customerId;
	}




	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}




	public String getAccountNumber() {
		return accountNumber;
	}




	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}




	public String getPolicyNumber() {
		return policyNumber;
	}




	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}




	/*public String getFullName() {
		return fullName;
	}




	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
*/



	public String getEffectiveDate() {
		return effectiveDate;
	}




	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}




	public String getProductName() {
		return productName;
	}




	public void setProductName(String productName) {
		this.productName = productName;
	}




	public String getStatus() {
		return status;
	}




	public void setStatus(String status) {
		this.status = status;
	}




	public String getBillType() {
		return billType;
	}




	public void setBillType(String billType) {
		this.billType = billType;
	}




	public double getPremium() {
		return premium;
	}




	public void setPremium(double premium) {
		this.premium = premium;
	}




	/*public String getPaid() {
		return paid;
	}




	public void setPaid(String paid) {
		this.paid = paid;
	}




	public String getOepnClaimNumber() {
		return oepnClaimNumber;
	}




	public void setOepnClaimNumber(String oepnClaimNumber) {
		this.oepnClaimNumber = oepnClaimNumber;
	}*/




	public ArrayList<HashMap> getActions() {
		return actions;
	}




	public void setActions(ArrayList<HashMap> actions) {
		this.actions = actions;
	}




	public ArrayList<HashMap> getNavigations() {
		return navigations;
	}




	public void setNavigations(ArrayList<HashMap> navigations) {
		this.navigations = navigations;
	}




	public String getEntityType() {
		return entityType;
	}




	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}




	@Override
	public String toString() {
		return "CustomerEntity [customerId=" + customerId 
				+ ", accountNumber=" + accountNumber 
				+ ", policyNumber=" + policyNumber
				//+ ", fullName=" + fullName 
				+ ", effectiveDate=" + effectiveDate
				+ ", Product Name=" + productName 
				+ ", status=" + status 
				+ ", billType=" + billType 
				+ ", premium=" + premium 
				//+ ", paid=" + paid 
				+ ", entityType=" + entityType + "]";
	}

}
