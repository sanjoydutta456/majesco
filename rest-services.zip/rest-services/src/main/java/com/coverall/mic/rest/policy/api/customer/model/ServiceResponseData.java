package com.coverall.mic.rest.policy.api.customer.model;
import java.util.Arrays;

public class ServiceResponseData {
	private String clientId;
	private String transactionId;
	private String customerId;
	private String sourceSystemID;
	private String gid;
	private ErrorObject[] Errors;
	private String statusCode;
	private String responseMessage;
		
	
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public String getGid() {
		return gid;
	}
	public void setGid(String gid) {
		this.gid = gid;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getSourceSystemID() {
		return sourceSystemID;
	}
	public void setSourceSystemID(String sourceSystemID) {
		this.sourceSystemID = sourceSystemID;
	}
	public ErrorObject[] getErrors() {
		return Errors;
	}
	public void setErrors(ErrorObject[] errors) {
		Errors = errors;
	}
	@Override
	public String toString() {
		return "ServiceResponseData [clientId=" + clientId + ", transactionId=" + transactionId + ", customerId="
				+ customerId + ", sourceSystemID=" + sourceSystemID + ", gid=" + gid + ", Errors="
				+ Arrays.toString(Errors) + ", statusCode=" + statusCode + ", responseMessage=" + responseMessage + "]";
	}
}
