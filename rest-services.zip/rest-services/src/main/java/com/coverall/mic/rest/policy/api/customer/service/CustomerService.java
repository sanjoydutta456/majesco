package com.coverall.mic.rest.policy.api.customer.service;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.DELETE;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.coverall.mic.rest.policy.api.customer.model.CreateCustomerRequest;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.UnifiedSearchRequest;



@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON , MediaType.MULTIPART_FORM_DATA })
@Produces({ MediaType.APPLICATION_JSON , MediaType.MULTIPART_FORM_DATA })
public interface CustomerService {

	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML ,MediaType.MULTIPART_FORM_DATA})
	@Path("{customerId}")
	@GET
	public Object getCustomer(@PathParam("customerId") String customerId, @Context HttpServletRequest request);
	

	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML ,MediaType.MULTIPART_FORM_DATA})
	@Path("{customerId}/events")
	@GET
	public Object getCustomerEvents(@PathParam("customerId") String customerId, @Context HttpServletRequest request);

	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML ,MediaType.MULTIPART_FORM_DATA})
	@Path("configuredEvents")
	@GET
	public Object getCustomerConfiguredEvents(@Context HttpServletRequest request);

	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML ,MediaType.MULTIPART_FORM_DATA})
	@Path("{customerId}/summary")
	@GET
	public Object getCustomerSummary(@PathParam("customerId") String customerId, @Context HttpServletRequest request);

	

	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML ,MediaType.MULTIPART_FORM_DATA})
	@Path("{customerId}/entities")
	@GET
	public Object getCustomerEntities(@PathParam("customerId") String customerId, @Context HttpServletRequest request);
	
	@Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.MULTIPART_FORM_DATA})
	@Path("{customerId}/notes/{noOfNotes}")
	@GET
	public Object getCustomerNotes(@PathParam("customerId") String customerId, @PathParam("noOfNotes") String size, @Context HttpServletRequest request );
	
	@Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.MULTIPART_FORM_DATA})
	@Path("createCustomer")
	@POST
	public Object createCustomer(@Context HttpServletRequest request ) throws Exception;
	
/*	@Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.MULTIPART_FORM_DATA})
	@Path("updateCustomer")
	@POST
	public Object updateCustomer(@Context HttpServletRequest request )*/;
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML ,MediaType.MULTIPART_FORM_DATA})
	@Path("{customerId}/transactionUrl/{transactionName}")
	@GET
	public Object getCustomerTransactionUrl(@PathParam("customerId") String customerId, @PathParam("transactionName") String transName, @Context HttpServletRequest request);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML ,MediaType.MULTIPART_FORM_DATA})
	@Path("{customerId}/transactions")
	@GET
	public Object getCustomerTransactions(@PathParam("customerId") String customerId, @Context HttpServletRequest request);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML ,MediaType.MULTIPART_FORM_DATA})
	@Path("{customerId}")
	@DELETE
	public Object deleteCustomer(@PathParam("customerId") String customerId, @Context HttpServletRequest request);
	
	@GET
	@Path("ping")
	public String ping();
}
