package com.coverall.mic.rest.policy.api.customer.service.impl;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import com.coverall.el.QueryWithBindVariables;
import com.coverall.mic.rest.policy.api.customer.model.ConfiguredEvent;
import com.coverall.mic.rest.policy.api.customer.model.Contact;
import com.coverall.mic.rest.policy.api.customer.model.CustomerDetails;
import com.coverall.mic.rest.policy.api.customer.model.CustomerNote;
import com.coverall.mic.rest.policy.api.customer.model.CustomerNote.attachments;
import com.coverall.mic.rest.policy.api.customer.model.CustomerNotes;
import com.coverall.mic.rest.policy.api.customer.model.CustomerRequest;
import com.coverall.mic.rest.policy.api.customer.model.CustomerSummary;
import com.coverall.mic.rest.policy.api.customer.model.CustomerTransactions;
import com.coverall.mic.rest.policy.api.customer.model.CustomerTransactionsDetails;
import com.coverall.mic.rest.policy.api.customer.model.ErrorObject;
import com.coverall.mic.rest.policy.api.customer.model.EventDetail;
import com.coverall.mic.rest.policy.api.customer.model.JsonRequest;
import com.coverall.mic.rest.policy.api.customer.model.PolicyEntity;
import com.coverall.mic.rest.policy.api.customer.model.ServiceResponseData;
import com.coverall.mic.rest.policy.api.customer.model.TransactionResponseData;
import com.coverall.mic.rest.policy.api.customer.service.CustomerService;
import com.coverall.mic.rest.policy.api.customer.service.impl.CustomerUtil;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;
import com.coverall.mt.policytrans.PolicyTransactionDetailsVO;
import com.coverall.mt.policytrans.TransactionService;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.pctv2.server.service.IPCTRequestContext;
import com.coverall.util.DBUtil;
import com.coverall.portal.dao.CustomerDAO;

public class CustomerServiceImpl implements CustomerService {
	
static final String CUSTOMER_DETAILS_QUERY_ID =	"CustomerDetailsQuery";	
static final String CUSTOMER_SUMMARY_QUERY_ID = "CustomerSummaryQuery";
static final String POLICY_ENTITIES_QUERY_ID = "PolicyEntities";
static final String CUSTOMER_EVENTS_CODE_QUERY_ID = "CustomerEventsCode";
static final String CUSTOMER_EVENTS_QUERY_ID = "CustomerEvents";
static final String CUSTOMER_EVENTS_UW_APPROVE_QUERY_ID = "CustomerUWApproveEvents";
static final String CUSTOMER_EVENTS_UW_REJECT_QUERY_ID = "CustomerUWRejectEvents";
static final String CUSTOMER_CONFIGURED_EVENTS_QUERY_ID = "CustomerConfiguredEvents";
static final String CUSTOMER_CONFIGURED_NOTES_QUERY_ID = "CustomerConfiguredNotes";
static final String CUSTOMER_ENTITY_REFERENCE_QUERY_ID = "CustomerEntityReferenceQuery";
static final String SOURCE_SYSTEM_USER_ID="SourceSystemUserId";
	
	public CustomerServiceImpl() {
	
	}

	@Override
	public CustomerDetails getCustomer(String customerId, HttpServletRequest request) {
		
		CustomerDetails customerDetails = new CustomerDetails();
		HashMap params = new HashMap();
		
		try {
			String sourceSystemUserId = request.getParameter("sourceSystemUserId")!=null ? request.getParameter("sourceSystemUserId"): null;
			
			if(!CustomerUtil.customerExist(customerId,sourceSystemUserId)) {
				
				String errMsg = customerId + APIConstant.CUSTOMER_NOT_EXISTS;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				WebServiceLoggerUtil.logInfo("CustomerServiceImpl", "getCustomer", errMsg, new Object[] { errMsg });
				throw new APIException(String.valueOf(Response.Status.NOT_FOUND.getStatusCode()),
						APIConstant.FAILED, errorMessageList, null);
			}
						
			params.put("CUSTOMER_ID", customerId);
			if(sourceSystemUserId!=null){
				params.put(SOURCE_SYSTEM_USER_ID, sourceSystemUserId);
			}
			QueryWithBindVariables queryWithBindVariablesCustomerDetails = CustomerUtil.resolveQueryExpression(params, CUSTOMER_DETAILS_QUERY_ID, true);
			ArrayList<HashMap<String, String>> dataList = new ArrayList<HashMap<String, String>>();	
			dataList = CustomerUtil.executeQuery(queryWithBindVariablesCustomerDetails);				
					
			for (Map<String, String> row : dataList) {
				customerDetails.setFullName(row.get("FULL_NAME"));
				customerDetails.setCustomerId(row.get("DISPLAY_CUSTOMER_NUMBER"));
				customerDetails.setCustomerSince(row.get("CUSTOMERSINCE"));
				customerDetails.setCustomerPhone(row.get("CUSTOMER_PHONE"));
				customerDetails.setMailingAddress(row.get("MAILINGADDRESS"));
				customerDetails.setContactPerson(row.get("CONTACTNAME"));
				customerDetails.setContactAddress(row.get("CONTACTADDRESS"));
				customerDetails.setContactPhone(row.get("PHONE"));
				customerDetails.setContactEmail(row.get("EMAIL"));
				customerDetails.setCustomerRating(row.get("CUSTOMERRATING"));
				customerDetails.setMergeStatus(row.get("STATUS"));
			}
			
		} catch (APIException e) {
			WebServiceLoggerUtil.logError("CustomerServiceImpl", "getCustomer", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw e;
		} catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));
			WebServiceLoggerUtil.logError("CustomerServiceImpl", "getCustomer", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
					APIConstant.FAILED, errorMessageList,e);
		} 	
		return customerDetails;
	}
	
	public CustomerSummary getCustomerSummary( String customerId, HttpServletRequest request) {

		CustomerSummary customerSummary = new CustomerSummary();
		HashMap params = new HashMap();
		
		try {
			String sourceSystemUserId = request.getParameter("sourceSystemUserId")!=null ? request.getParameter("sourceSystemUserId"): null;
			if(!CustomerUtil.customerExist(customerId,sourceSystemUserId)) {
				
				String errMsg = customerId + APIConstant.CUSTOMER_NOT_EXISTS;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				WebServiceLoggerUtil.logInfo("CustomerServiceImpl", "getCustomerSummary", errMsg, new Object[] { errMsg });
				throw new APIException(String.valueOf(Response.Status.NOT_FOUND.getStatusCode()),
						APIConstant.FAILED, errorMessageList, null);
			}
			params.put("CUSTOMER_ID", customerId);
			if(sourceSystemUserId!=null){
				params.put(SOURCE_SYSTEM_USER_ID, sourceSystemUserId);
			}
			QueryWithBindVariables queryWithBindVariablesCustomerSummary = CustomerUtil.resolveQueryExpression(params, CUSTOMER_SUMMARY_QUERY_ID, true);
			ArrayList<HashMap<String, String>> dataList = new ArrayList<HashMap<String, String>>();	
			dataList = CustomerUtil.executeQuery(queryWithBindVariablesCustomerSummary);				
					
			for (Map<String, String> row : dataList) {
				customerSummary.setCustomerId(customerId);
				customerSummary.setInforcePolicies(Integer.parseInt(row.get("INFORCEPOLICIES")));
				customerSummary.setInforcePremium(Double.parseDouble(row.get("INFORCEPREMIUM")));							
			}
			
		} catch (APIException e) {
			WebServiceLoggerUtil.logError("CustomerServiceImpl", "getCustomerSummary", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw e;
		} catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));
			WebServiceLoggerUtil.logError("CustomerServiceImpl", "getCustomerSummary", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
					APIConstant.FAILED, errorMessageList,e);
		} 	
		return customerSummary;
	}
	
	@Override
	public CustomerNotes getCustomerNotes(String customerId, String size, HttpServletRequest request) { 		
		CustomerNotes notes = new CustomerNotes();
		CustomerNote note = null;		
		PreparedStatement ps = null;
		ResultSet rs = null;
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		User user = APIRequestContext.getApiRequestContext().getMtUser();
		List<CustomerNote> getApplicableNotesList = new ArrayList<CustomerNote>();	
		HashMap params = new HashMap();
		
		try {			 	
				CustomerRequest customerRequest = new CustomerRequest();
				customerRequest.setCustomerId(customerId);
				customerRequest.setUser(user);
				customerRequest.setNumberOfNotes(size);
				Connection conn = requestContext.getConnection();
				
				params.put("CUSTOMER_ID", customerRequest.getCustomerId());				
				params.put("user", customerRequest.getUser());			
				params.put("size", customerRequest.getNumberOfNotes());
				
				String sourceSystemUserId = request.getParameter("sourceSystemUserId")!=null ? request.getParameter("sourceSystemUserId"): null;
				CustomerUtil.validateCustomerNotesRequest(customerRequest);
				
				if(!CustomerUtil.customerExist(customerId,sourceSystemUserId)) {
					
					String errMsg = customerId + APIConstant.CUSTOMER_NOT_EXISTS;
					List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
					WebServiceLoggerUtil.logInfo("CustomerServiceImpl", "getCustomerNote", errMsg, new Object[] { errMsg });
					throw new APIException(String.valueOf(Response.Status.NOT_FOUND.getStatusCode()),
							APIConstant.FAILED, errorMessageList, null);
				}
				QueryWithBindVariables queryWithBindVariablesCustomerNotes = CustomerUtil.resolveQueryExpression(params, CUSTOMER_CONFIGURED_NOTES_QUERY_ID, true);
				int noOfNotes = Integer.parseInt(size);
				String filterQuery = CustomerUtil.WRAPPER_QUERY_WO_RNUM_START;
				String orderQuery =  CustomerUtil.WRAPPER_QUERY_ORDER_BY + "NOTEDATE" + CustomerUtil.WRAPPER_QUERY_DESC + CustomerUtil.WRAPPER_QUERY_ROW_NO + noOfNotes;
				String finalQuery = filterQuery + (queryWithBindVariablesCustomerNotes.getQuery()) + orderQuery;
				
				queryWithBindVariablesCustomerNotes.setQuery(finalQuery);
				/*ps = conn.prepareStatement(finalQuery);				
				rs = ps.executeQuery();
				while (rs.next()) {
					note = new CustomerNote();
					note.setApplication(rs.getString("application"));
					note.setPolicyNo(rs.getString("policyNo"));
					note.setNoteDate(rs.getString("noteDate"));
					note.setNoteText(rs.getString("noteText"));
					note.setHasAttachment(attachments.N);
					CustomerUtil.addNavigationAndActionNotes(note);					
					getApplicableNotesList.add(note);
				}*/
				ArrayList<HashMap<String, String>> dataList = new ArrayList<HashMap<String, String>>();					
				dataList = CustomerUtil.executeQuery(queryWithBindVariablesCustomerNotes);						
				for (Map<String, String> row : dataList) {
					note = new CustomerNote();
					note.setApplication(row.get("APPLICATION"));
					note.setPolicyNo(row.get("POLICYNO"));
					note.setNoteDate(row.get("NOTEDATE"));
					note.setNoteText(row.get("NOTETEXT"));
					note.setHasAttachment(attachments.N);
					CustomerUtil.addNavigationAndActionNotes(note,row);					
					getApplicableNotesList.add(note);					
				}
			} catch (APIException e) {
				WebServiceLoggerUtil.logError("CustomerServiceImpl", "getCustomerNote", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
				throw e;
			} catch (Exception e) {
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));
				WebServiceLoggerUtil.logError("CustomerServiceImpl", "getCustomerNote", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
				throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
						APIConstant.FAILED, errorMessageList,e);
			} /*finally {
				try {
					DBUtil.close(rs, ps, null);
				} catch (SQLException e) {
					e.printStackTrace();
				}
				requestContext.releaseContext();
			}*/
			
			if(getApplicableNotesList.isEmpty()) {
				
				String errMsg = APIConstant.NOTES_NOT_EXIST + customerId +".";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				WebServiceLoggerUtil.logInfo("CustomerServiceImpl", "getCustomerNotes", errMsg, new Object[] { errMsg });
				throw new APIException(String.valueOf(Response.Status.NOT_FOUND.getStatusCode()),
						APIConstant.FAILED, errorMessageList, null);
			
			}
			notes.setNotes(getApplicableNotesList);
		
			return notes;
			}
	
	@Override
	public ArrayList<ConfiguredEvent> getCustomerConfiguredEvents(HttpServletRequest request) {		
		ArrayList<ConfiguredEvent> configuredEvents = new ArrayList<ConfiguredEvent>();
		ConfiguredEvent customerConfiguredEvent = null;
		Long pageSize = null;
		Long pageNumber = null;
		String custConfEventsPaginationQuery = null;
		HashMap<String, String> params = new HashMap<String, String>();
		
		try {			
			String requestDate = request.getParameter("requestDate")!=null ? request.getParameter("requestDate"): null;   
			String sourceSystemRequestNo = request.getParameter("sourceSystemRequestNo")!=null ? request.getParameter("sourceSystemRequestNo"): null;
			String sourceSystemUserId = request.getParameter("sourceSystemUserId")!=null ? request.getParameter("sourceSystemUserId"): null;
			String sourceSystemUserName = request.getParameter("sourceSystemUserName")!=null ? request.getParameter("sourceSystemUserName"): null;
			String sourceSystemCode = request.getParameter("sourceSystemCode")!=null ? request.getParameter("sourceSystemCode"): null;
			String correlationid = request.getParameter("correlationid")!=null ? request.getParameter("correlationid"): null;
			
			CustomerRequest customerRequest = new CustomerRequest();
			//customerRequest.setCustomerId(userId);
			customerRequest.setRequestDate(requestDate);
			customerRequest.setSourceSystemRequestNo(sourceSystemRequestNo);
			customerRequest.setSourceSystemUserId(sourceSystemUserId);
			customerRequest.setSourceSystemUserName(sourceSystemUserName);
			customerRequest.setSourceSystemCode(sourceSystemCode);		
			if(request.getParameter("pageSize")!=null){
				pageSize = Long.parseLong(request.getParameter("pageSize"));
				customerRequest.setPageSize(pageSize);
			}
			if(request.getParameter("pageNumber")!=null){
				pageNumber = Long.parseLong(request.getParameter("pageNumber"));
				customerRequest.setPageNumber(pageNumber);
			}		
			customerRequest.setCorrelationid(correlationid);			
			
			String custConfEventsQuery = CustomerUtil.resolveQueryExpression(params, CUSTOMER_CONFIGURED_EVENTS_QUERY_ID);
			if(pageNumber!= null && pageSize != null){
				custConfEventsPaginationQuery = CustomerUtil.generateQueryWithPagination(custConfEventsQuery,pageNumber,pageSize);
			}		
			ArrayList<HashMap<String, String>> dataList = new ArrayList<HashMap<String, String>>();	
			if(custConfEventsPaginationQuery!=null){
				dataList = CustomerUtil.executeQuery(custConfEventsPaginationQuery);	
			}else{
				dataList = CustomerUtil.executeQuery(custConfEventsQuery);
			}
			
			for (Map<String, String> row : dataList) {
				customerConfiguredEvent = new ConfiguredEvent();
				customerConfiguredEvent.setEventName(row.get("EVENT_DESCRIPTION"));
				//customerConfiguredEvent.setIsDefaultEvent(row.get("IS_DEFAULT_EVENT"));
				if(customerConfiguredEvent.getEventName().equals("New Quote") ||
						customerConfiguredEvent.getEventName().equals("Underwriting Rejection") ||
						customerConfiguredEvent.getEventName().equals("Pending Cancellation") ||
						customerConfiguredEvent.getEventName().equals("Renewal") ){
					customerConfiguredEvent.setIsDefaultEvent("Y");
				}else{
					customerConfiguredEvent.setIsDefaultEvent("N");
				}
				configuredEvents.add(customerConfiguredEvent);
			}
		
		} catch (APIException e) {
			WebServiceLoggerUtil.logError("CustomerServiceImpl", "getCustomerConfiguredEvents", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw e;
		} catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError("CustomerServiceImpl", "getCustomerConfiguredEvents", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);

			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		} 
		return configuredEvents;
	}

	
	@Override
	public ArrayList<EventDetail> getCustomerEvents(String customerId, HttpServletRequest request) {
		ArrayList<EventDetail> eventDetails = new ArrayList<EventDetail>();
		EventDetail eventDetail = null;
		Long pageSize = null;
		Long pageNumber = null;
		String custEventsPaginationQuery = null;
		String custEventsQuery= null;
		HashMap<String, String> params = new HashMap<String, String>();		
		String appendedValue = null;
		String eventCodeArgument = null;
		String uwApproveCode = null;
		String uwRejectCode = null;
		StringBuffer strFinalQuery = new StringBuffer();
		ArrayList<String> eventCodes = new ArrayList<String>();
		List<String> bindVariableList = new ArrayList<String>();
		QueryWithBindVariables queryWithBindVariables = new QueryWithBindVariables();
		try {
			String requestDate = request.getParameter("requestDate")!=null ? request.getParameter("requestDate"): null;   
			String sourceSystemRequestNo = request.getParameter("sourceSystemRequestNo")!=null ? request.getParameter("sourceSystemRequestNo"): null;
			String sourceSystemUserId = request.getParameter("sourceSystemUserId")!=null ? request.getParameter("sourceSystemUserId"): null;
			String sourceSystemUserName = request.getParameter("sourceSystemUserName")!=null ? request.getParameter("sourceSystemUserName"): null;
			String sourceSystemCode = request.getParameter("sourceSystemCode")!=null ? request.getParameter("sourceSystemCode"): null;
			String correlationid = request.getParameter("correlationid")!=null ? request.getParameter("correlationid"): null;			
			String eventFromDate = request.getParameter("eventFromDate")!=null ? request.getParameter("eventFromDate"): null;
			String eventToDate = request.getParameter("eventToDate")!=null ? request.getParameter("eventToDate"): null;
			String eventCodeReq = request.getParameter("eventName")!=null ? request.getParameter("eventName"): null;
			String accountNo = request.getParameter("accountNo")!=null ? request.getParameter("accountNo"): null;
			
			CustomerRequest customerRequest = new CustomerRequest();
			customerRequest.setCustomerId(customerId);
			customerRequest.setRequestDate(requestDate);
			customerRequest.setSourceSystemRequestNo(sourceSystemRequestNo);
			customerRequest.setSourceSystemUserId(sourceSystemUserId);
			customerRequest.setSourceSystemUserName(sourceSystemUserName);
			customerRequest.setSourceSystemCode(sourceSystemCode);		
			if(request.getParameter("pageSize")!=null){
				pageSize = Long.parseLong(request.getParameter("pageSize"));
				customerRequest.setPageSize(pageSize);
			}
			if(request.getParameter("pageNumber")!=null){
				pageNumber = Long.parseLong(request.getParameter("pageNumber"));
				customerRequest.setPageNumber(pageNumber);
			}		
			customerRequest.setCorrelationid(correlationid);
			customerRequest.setEventFromDate(eventFromDate);
			customerRequest.setEventToDate(eventToDate);
			customerRequest.setEventCode(eventCodeReq);
			customerRequest.setAccountNo(accountNo);
			
			CustomerUtil.validateCustomerEventsRequest(customerRequest);
			if(!CustomerUtil.customerExist(customerId,sourceSystemUserId)) {				
				String errMsg = customerId + APIConstant.CUSTOMER_NOT_EXISTS;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				WebServiceLoggerUtil.logInfo("CustomerServiceImpl", "getCustomerNote", errMsg, new Object[] { errMsg });
				throw new APIException(String.valueOf(Response.Status.NOT_FOUND.getStatusCode()),
						APIConstant.FAILED, errorMessageList, null);
			}
			
			if(eventCodeReq !=null){
				String[] split_value = eventCodeReq.split(CustomerUtil.PIPE_SEPARATOR);
				//System.out.println("Before: "+Arrays.toString(split_value));
				ArrayList<String> eventList = new ArrayList<String>(Arrays.asList(split_value));
				appendedValue=CustomerUtil.getAppendedValueList(eventList);
			}
			if(appendedValue!= null){
				params.put("EVENT_DESCRIPTION", appendedValue);
				QueryWithBindVariables queryWithBindVariablesCustomerEventsCode = CustomerUtil.resolveQueryExpression(params, CUSTOMER_EVENTS_CODE_QUERY_ID, true);
				ArrayList<HashMap<String, String>> dataList = new ArrayList<HashMap<String, String>>();	
				if((null != queryWithBindVariablesCustomerEventsCode) && (null != (queryWithBindVariablesCustomerEventsCode.getQuery()))){
					dataList = CustomerUtil.executeQuery(queryWithBindVariablesCustomerEventsCode);
				}
				for (Map<String, String> row : dataList) {
					if(row.get("EVENT_TYPE").equals("CUSTOMER_DASHBOARD")){
						eventCodes.add(row.get("EVENT_CODE"));
					}
					if(row.get("EVENT_TYPE").equals("CUSTOMER_DASHBOARD_UW_APPROVE")){
						uwApproveCode = row.get("EVENT_CODE");
					}
					if(row.get("EVENT_TYPE").equals("CUSTOMER_DASHBOARD_UW_REJECT")){
						uwRejectCode = row.get("EVENT_CODE");
					}
					
				}					
			}
			
			if(eventCodes.size()>0){
				eventCodeArgument = CustomerUtil.getAppendedValueList(eventCodes);
				HashMap<String, String> eventParams = new HashMap<String, String>();
				if(sourceSystemUserId!=null){
					eventParams.put(SOURCE_SYSTEM_USER_ID, sourceSystemUserId);
				}
				eventParams.put("CUSTOMER_ID", customerRequest.getCustomerId());
				eventParams.put("EVENT_CODE", eventCodeArgument);
				eventParams.put("EVENT_FROM_DATE", customerRequest.getEventFromDate());
				eventParams.put("EVENT_TO_DATE", customerRequest.getEventToDate());
				queryWithBindVariables = CustomerUtil.resolveQueryExpression(eventParams, CUSTOMER_EVENTS_QUERY_ID, true);
				strFinalQuery.append(queryWithBindVariables.getQuery());
				bindVariableList.addAll(queryWithBindVariables.getBindVariablesValues());
			}
			if(uwApproveCode!= null){
				HashMap<String, String> eventParams = new HashMap<String, String>();
				if(sourceSystemUserId!=null){
					eventParams.put(SOURCE_SYSTEM_USER_ID, sourceSystemUserId);
				}
				eventParams.put("CUSTOMER_ID", customerRequest.getCustomerId());
				eventParams.put("EVENT_CODE", uwApproveCode);
				eventParams.put("EVENT_FROM_DATE", customerRequest.getEventFromDate());
				eventParams.put("EVENT_TO_DATE", customerRequest.getEventToDate());
				queryWithBindVariables = CustomerUtil.resolveQueryExpression(eventParams, CUSTOMER_EVENTS_UW_APPROVE_QUERY_ID, true);
				if(!strFinalQuery.toString().isEmpty()){
					strFinalQuery.append(CustomerUtil.UNION);
					strFinalQuery.append(queryWithBindVariables.getQuery());
				}else{
					strFinalQuery.append(queryWithBindVariables.getQuery());
				}
				bindVariableList.addAll(queryWithBindVariables.getBindVariablesValues());
			}
			if(uwRejectCode!= null){
				HashMap<String, String> eventParams = new HashMap<String, String>();
				if(sourceSystemUserId!=null){
					eventParams.put(SOURCE_SYSTEM_USER_ID, sourceSystemUserId);
				}
				eventParams.put("CUSTOMER_ID", customerRequest.getCustomerId());
				eventParams.put("EVENT_CODE", uwRejectCode);
				eventParams.put("EVENT_FROM_DATE", customerRequest.getEventFromDate());
				eventParams.put("EVENT_TO_DATE", customerRequest.getEventToDate());
				queryWithBindVariables = CustomerUtil.resolveQueryExpression(eventParams, CUSTOMER_EVENTS_UW_REJECT_QUERY_ID, true);
				if(!strFinalQuery.toString().isEmpty()){
					strFinalQuery.append(CustomerUtil.UNION);
					strFinalQuery.append(queryWithBindVariables.getQuery());
				}else{
					strFinalQuery.append(queryWithBindVariables.getQuery());
				}
				bindVariableList.addAll(queryWithBindVariables.getBindVariablesValues());
			}
			
			
			if(pageNumber!= null && pageSize != null){
				custEventsPaginationQuery = CustomerUtil.generateQueryWithPagination(strFinalQuery.toString(),pageNumber,pageSize);
			}		
			ArrayList<HashMap<String, String>> dataList = new ArrayList<HashMap<String, String>>();	
			if(custEventsPaginationQuery!=null){
				queryWithBindVariables.setQuery(custEventsPaginationQuery);
			}else{
				queryWithBindVariables.setQuery(strFinalQuery.toString());
			}			
			
			dataList = CustomerUtil.executeQuery(new QueryWithBindVariables((queryWithBindVariables.getQuery()), true, bindVariableList, null));
			
			for (Map<String, String> row : dataList) {
				eventDetail = new EventDetail();
				eventDetail.setEventDescription(row.get("EVENT_DESCRIPTION"));
				eventDetail.setPolicyNo(row.get("POLICY_NUMBER"));
				eventDetail.setPolicyEffectiveDate(row.get("EFFECTIVE_DATE"));
				eventDetail.setAmount(row.get("PREMIUM"));
				eventDetail.setEventDate(row.get("EVENT_DATE"));
				eventDetails.add(eventDetail);
			}			
		
		} catch (APIException e) {
			WebServiceLoggerUtil.logError("CustomerServiceImpl", "getCustomerEvents", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw e;
		} catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError("CustomerServiceImpl", "getCustomerEvents", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		} 	
		return eventDetails;
	}
	
	
	@Override
	public ArrayList<PolicyEntity> getCustomerEntities(String customerId, HttpServletRequest request) {
		
		ArrayList<PolicyEntity> policyEntities = new ArrayList<PolicyEntity>();
		PolicyEntity policyEntity = null;
		Long pageSize = null;
		Long pageNumber = null;
		String polEntPaginationQuery = null;
		HashMap<String, String> params = new HashMap<String, String>();
		try {
			
			
		if(CustomerUtil.getHostURL() == null && request.getRequestURI() != null){
			  String requestURL = request.getScheme()+"://"+request.getServerName();
			  CustomerUtil.setHostURL(requestURL);
		}
		
		String requestDate = request.getParameter("requestDate")!=null ? request.getParameter("requestDate"): null;   
		String sourceSystemRequestNo = request.getParameter("sourceSystemRequestNo")!=null ? request.getParameter("sourceSystemRequestNo"): null;
		String sourceSystemUserId = request.getParameter("sourceSystemUserId")!=null ? request.getParameter("sourceSystemUserId"): null;
		String sourceSystemUserName = request.getParameter("sourceSystemUserName")!=null ? request.getParameter("sourceSystemUserName"): null;
		String sourceSystemCode = request.getParameter("requestDate")!=null ? request.getParameter("sourceSystemCode"): null;			
		String correlationid = request.getParameter("correlationid")!=null ? request.getParameter("correlationid"): null;		
		
		CustomerRequest customerRequest = new CustomerRequest();
		customerRequest.setCustomerId(customerId);
		customerRequest.setRequestDate(requestDate);
		customerRequest.setSourceSystemRequestNo(sourceSystemRequestNo);
		customerRequest.setSourceSystemUserId(sourceSystemUserId);
		customerRequest.setSourceSystemUserName(sourceSystemUserName);
		customerRequest.setSourceSystemCode(sourceSystemCode);		
		if(request.getParameter("pageSize")!=null){
			pageSize = Long.parseLong(request.getParameter("pageSize"));
			customerRequest.setPageSize(pageSize);
		}
		if(request.getParameter("pageNumber")!=null){
			pageNumber = Long.parseLong(request.getParameter("pageNumber"));
			customerRequest.setPageNumber(pageNumber);
		}		
		customerRequest.setCorrelationid(correlationid);		
		CustomerUtil.validatePolicyEntityRequest(customerRequest);		
		if(!CustomerUtil.customerExist(customerId,sourceSystemUserId)) {
			
			String errMsg = customerId + APIConstant.CUSTOMER_NOT_EXISTS;
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
			WebServiceLoggerUtil.logInfo("CustomerServiceImpl", "getCustomerEntities", errMsg, new Object[] { errMsg });
			throw new APIException(String.valueOf(Response.Status.NOT_FOUND.getStatusCode()),
					APIConstant.FAILED, errorMessageList, null);
		}
		
		params.put("CUSTOMER_ID", customerRequest.getCustomerId());
		if(sourceSystemUserId!=null){
			params.put(SOURCE_SYSTEM_USER_ID, sourceSystemUserId);
		}
		QueryWithBindVariables queryWithBindVariablesPolicyEntity = CustomerUtil.resolveQueryExpression(params, POLICY_ENTITIES_QUERY_ID, true);
		if(pageNumber!= null && pageSize != null){
			polEntPaginationQuery = CustomerUtil.generateQueryWithPagination((queryWithBindVariablesPolicyEntity.getQuery()),pageNumber,pageSize);
		}		
		ArrayList<HashMap<String, String>> dataList = new ArrayList<HashMap<String, String>>();	
		if(polEntPaginationQuery!=null){
			queryWithBindVariablesPolicyEntity.setQuery(polEntPaginationQuery);
		}
		
		dataList = CustomerUtil.executeQuery(queryWithBindVariablesPolicyEntity);
			
				
		for (Map<String, String> row : dataList) {
			policyEntity = new PolicyEntity();
			policyEntity.setCustomerId(row.get("CUSTOMER_ID"));
			policyEntity.setAccountNumber(row.get("ACCOUNT_NUMBER"));
			policyEntity.setEntityType(row.get("ENTITY_TYPE"));
			policyEntity.setPolicyNumber(row.get("POLICY_NUMBER"));
			policyEntity.setStatus(row.get("STATUS"));
			policyEntity.setEffectiveDate(row.get("EFFECTIVE_DATE"));
			policyEntity.setProductName(row.get("PRODUCT_NAME"));
			policyEntity.setBillType(row.get("BILL_TYPE"));
			policyEntity.setPremium(Double.parseDouble(row.get("PREMIUM")));
			CustomerUtil.addNavigationAndAction(policyEntity,row);
			policyEntities.add(policyEntity);
		}
		} catch (APIException e) {
			WebServiceLoggerUtil.logError("CustomerServiceImpl", "getCustomerEntities", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw e;
		} catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError("CustomerServiceImpl", "getCustomerEntities", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);

			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		} 
		return policyEntities;		
	}
	
	private List<Message> getErrorMessageList(List<String> strMessages)	{
		if(strMessages == null)	{
			return null;
		}
		List<Message> errorMessageList = new ArrayList<Message>(strMessages.size());
		for(String aMsg : strMessages)	{
			Message message = new Message();
			message.setMoreinfo(aMsg);
			errorMessageList.add(message);
		}
		return errorMessageList;
	}
	
	@Override
	public ServiceResponseData createCustomer(HttpServletRequest request) throws Exception {
		ServiceResponseData serviceResponseData = new ServiceResponseData();
		try {
			//String requestJson = null; 
			String fileName = "d:/json/CreateCustomerRequestJson.txt"; 
			String requestJson = readFile(fileName);
			//= searchRequest.getJson();
		    System.out.println("Input Request JSON=" + requestJson);
			JsonRequest jsonRequest = populateJsonRequest(requestJson);
			
			TransactionResponseData transactionResponseDataDummy = new TransactionResponseData();
			String createCustomerJsonResponse = invokeCreateCustomer(request, jsonRequest,transactionResponseDataDummy);
			System.out.println("createCustomerJsonResponse :" + createCustomerJsonResponse);
			TransactionResponseData createCustomerResponseData = populateResponseObject(createCustomerJsonResponse);
			if (createCustomerResponseData.getErrors() != null) {
				invokeSuspendTrnsaction(request, jsonRequest, createCustomerResponseData);
			}
	
			String createAddressJsonResponse = invokeCreateCustomerAddress(request, jsonRequest, createCustomerResponseData);
			System.out.println("createCustomerAddressJsonResponse :" + createAddressJsonResponse);
			TransactionResponseData createCustomerAddressResponseData = populateResponseObject(createAddressJsonResponse);
			if (createCustomerResponseData.getErrors() != null || createCustomerResponseData.getErrors().length > 0) {
				invokeSuspendTrnsaction(request, jsonRequest, createCustomerAddressResponseData);
			}
			
			String createAGencyJsonResponse = invokeCreateAgency(request, jsonRequest, createCustomerAddressResponseData);
			System.out.println("createAgencyResponse :" + createAGencyJsonResponse);
			TransactionResponseData createAgencyResponseData = populateResponseObject(createAGencyJsonResponse);
			if (createCustomerResponseData.getErrors() != null) {
				invokeSuspendTrnsaction(request, jsonRequest, createAgencyResponseData);
			}
			
			String createContactJsonResponse = invokeCreateCustomerAddress(request, jsonRequest, createAgencyResponseData);
			System.out.println("createContactJsonResponse :" + createContactJsonResponse);
			TransactionResponseData createContactJsonResponseData = populateResponseObject(createCustomerJsonResponse);
			if (createCustomerResponseData.getErrors() != null) {
				invokeSuspendTrnsaction(request, jsonRequest, createContactJsonResponseData);
			}
			String createContactAddressJsonResponse = invokeCreateCustomerAddress(request, jsonRequest, createContactJsonResponseData);
			System.out.println("createCustomerAddressJsonResponse :" + createContactAddressJsonResponse);
			TransactionResponseData createContactAddressJsonResponseData = populateResponseObject(createCustomerJsonResponse);
			if (createCustomerResponseData.getErrors() != null) {
				invokeSuspendTrnsaction(request, jsonRequest, createContactAddressJsonResponseData);
			}
			
			if (createCustomerResponseData.getErrors() != null || createCustomerResponseData.getErrors().length == 0) {
				invokeCompleteTransaction(request, jsonRequest, createCustomerResponseData);
			}
	
			serviceResponseData.setClientId(createCustomerResponseData.getClientId());
			serviceResponseData.setTransactionId(createCustomerResponseData.getTransactionId());
			serviceResponseData.setTransactionId(createCustomerResponseData.getGid());
			serviceResponseData.setTransactionId(createCustomerResponseData.getSourceSystemID());
			
			ErrorObject[] createCustomerErrorObjects = createCustomerResponseData.getErrors();
			ErrorObject[] createCustomerAddressErrorObjects = createCustomerAddressResponseData.getErrors();
			ErrorObject[] createAgencyErrorObjects = createAgencyResponseData.getErrors();
			ErrorObject[] createContactErrorObjects = createContactJsonResponseData.getErrors();
			ErrorObject[] createContactAddressErrorObjects = createContactAddressJsonResponseData.getErrors();
			
			ErrorObject[] serviceErrorObjects = combineArray(createCustomerErrorObjects, createCustomerAddressErrorObjects);
			serviceErrorObjects = combineArray(serviceErrorObjects, createAgencyErrorObjects);
			serviceErrorObjects = combineArray(serviceErrorObjects, createContactErrorObjects);
			serviceErrorObjects = combineArray(serviceErrorObjects, createContactAddressErrorObjects);
			serviceResponseData.setErrors(serviceErrorObjects);			
			//formServiceResponseJson(serviceResponseData);
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return serviceResponseData;
	}
	
	public String formGenericURL(HttpServletRequest request, String genericURL){
		String scheme = null;		String host = null;		String port = null;
		if(CustomerUtil.getHostURL() == null && request.getRequestURI() != null){
			  scheme = request.getScheme();
			  host = request.getServerName();
			  port = Integer.toString(request.getServerPort());
		}
		genericURL = genericURL.replaceAll("~scheme~", scheme);
		genericURL = genericURL.replaceAll("~host~", host);
		genericURL = genericURL.replaceAll("~port~", port);
		return genericURL;
	}
		public String invokeCreateCustomer(HttpServletRequest request, JsonRequest jsonRequest, TransactionResponseData transactionResponseData)
		{
			String createCustomerURL = "~scheme~://~host~:~port~/mic/microservices/startNewTransaction?transactionName=CreateQuote&entityType=CUSTOMER&sendHiddenAttributes=Y";
			createCustomerURL = formGenericURL(request, createCustomerURL);
			String responseJson = "";
			String requestJson = jsonRequest.getCustomerJson();
			//String url = "http://localhost:8080/testWebProject/createCustomerResponse";
			try {
				HttpPost postRequest = new HttpPost(createCustomerURL);
				setHeaders(request, postRequest, transactionResponseData); 
				postRequest.setEntity(new StringEntity(requestJson));
				DefaultHttpClient httpClient = new DefaultHttpClient();
				HttpResponse setCustomerResponse = httpClient.execute(postRequest);
				responseJson = EntityUtils.toString(setCustomerResponse.getEntity());
			}catch (Exception e)
			{
				e.printStackTrace();
			}
			return responseJson;
		}

		public String invokeCreateCustomerAddress(HttpServletRequest request, JsonRequest jsonRequest, TransactionResponseData transactionResponseData)
		{
			String customerId = transactionResponseData.getGid();
			String addressId = transactionResponseData.getSourceSystemID();			
			String createCustomerAddressURL = "~scheme~://~host~/mic/microservices/Customer/:~customerId~/CustomerAddress/:~AddressID~";
			createCustomerAddressURL = createCustomerAddressURL.replaceAll("~customerId~", customerId);
			createCustomerAddressURL = createCustomerAddressURL.replaceAll("~AddressID~", addressId);
			createCustomerAddressURL = formGenericURL(request, createCustomerAddressURL);
			String responseJson = "";
			String requestJson = jsonRequest.getCustomerAddressJson();
			//String url = "http://localhost:8080/testWebProject/createCustomerResponse";
			try {
				HttpPost postRequest = new HttpPost(createCustomerAddressURL);
				setHeaders(request, postRequest, transactionResponseData);	
				postRequest.setEntity(new StringEntity(requestJson));
				DefaultHttpClient httpClient = new DefaultHttpClient();
				HttpResponse setCreateCustomerResponse = httpClient.execute(postRequest);
				responseJson = EntityUtils.toString(setCreateCustomerResponse.getEntity());
			}catch (Exception e)
			{
				e.printStackTrace();
			}
			return responseJson;
		}

		public String invokeCreateAgency(HttpServletRequest request, JsonRequest jsonRequest,TransactionResponseData transactionResponseData)
		{
			String createCustomerAgencyAddressURL = "{{scheme}}://{{host}}/mic/microservices/Customer/:customerId/CustomerAgentInfo/:ProducerId";
			createCustomerAgencyAddressURL = formGenericURL(request, createCustomerAgencyAddressURL);
			String responseJson = "";
			String requestJson = jsonRequest.getAgencyJson();
			//String url = "http://localhost:8080/testWebProject/createCustomerResponse";
			try {
				HttpPost postRequest = new HttpPost(createCustomerAgencyAddressURL);
				setHeaders(request, postRequest, transactionResponseData);		
				postRequest.setEntity(new StringEntity(requestJson));
				DefaultHttpClient httpClient = new DefaultHttpClient();
				HttpResponse setCreateCustomerAgencyResponse = httpClient.execute(postRequest);
				responseJson = EntityUtils.toString(setCreateCustomerAgencyResponse.getEntity());
			}catch (Exception e)
			{
				e.printStackTrace();
			}
			return responseJson;
		}
		
		public String invokeSuspendTrnsaction(HttpServletRequest request, JsonRequest jsonRequest,TransactionResponseData transactionResponseData)
		{
			String suspendTransactionURL = "{{scheme}}://{{host}}/mic/microservices/Customer/:customerId/CustomerAgentInfo/:ProducerId";
			suspendTransactionURL = formGenericURL(request, suspendTransactionURL);
			String responseJson = "";
			//String url = "http://localhost:8080/testWebProject/createCustomerResponse";
			try {
				HttpGet getRequest = new HttpGet(suspendTransactionURL);
				setHeadersForGetType(request, getRequest, transactionResponseData);	
				DefaultHttpClient httpClient = new DefaultHttpClient();
				HttpResponse setSuspendTransactionResponse = httpClient.execute(getRequest);
				responseJson = EntityUtils.toString(setSuspendTransactionResponse.getEntity());
			}catch (Exception e)
			{
				e.printStackTrace();
			}
			return responseJson;
		}
		
		public String invokeCompleteTransaction (HttpServletRequest request, JsonRequest jsonRequest,TransactionResponseData transactionResponseData)
		{
			String completeTransactionURL = "{{scheme}}://{{host}}/mic/microservices/completeTransaction";
			completeTransactionURL = formGenericURL(request, completeTransactionURL);
			String responseJson = "";
			//String url = "http://localhost:8080/testWebProject/createCustomerResponse";
			try {
				HttpGet getRequest = new HttpGet(completeTransactionURL);
				setHeadersForGetType(request, getRequest, transactionResponseData);		
				DefaultHttpClient httpClient = new DefaultHttpClient();
				HttpResponse setCompleteTransactionResponse = httpClient.execute(getRequest);
				responseJson = EntityUtils.toString(setCompleteTransactionResponse.getEntity());
			}catch (Exception e)
			{
				e.printStackTrace();
			}
			return responseJson;
		}
		
		public ErrorObject[] combineArray(ErrorObject[] source, ErrorObject[] destination) {
			int length = source.length + destination.length;
			ErrorObject[] result = new ErrorObject[length];
			System.arraycopy(source, 0, result, 0, source.length);
			System.arraycopy(destination, 0, result, source.length, destination.length);
			return result;
		}

	/*	public String formServiceResponseJson(ServiceResponseData serviceResponseData)
		{
			String serviceResponseJson= "";
			try {
			ObjectMapper Obj = new ObjectMapper();
			serviceResponseJson =  Obj.writeValueAsString(serviceResponseData);
			System.out.println(serviceResponseJson);
			}catch (Exception e)
			{
				System.out.println(e);
			}
			return serviceResponseJson;
		}*/
		public void setHeaders(HttpServletRequest request, HttpPost postRequest, TransactionResponseData transactionResponseData)
		{
			postRequest.setHeader(HttpHeaders.CONTENT_TYPE, "application/json");
			postRequest.setHeader("optimizedFlow", "Y");
			postRequest.setHeader(HttpHeaders.AUTHORIZATION, request.getHeader(HttpHeaders.AUTHORIZATION)); //encoding retrived header
			if(transactionResponseData!=null)
			{
				if(transactionResponseData.getTransactionId() != null)
				{
					postRequest.setHeader("transactionID", transactionResponseData.getTransactionId());
				}
				if(transactionResponseData.getClientId() != null)
				{
					postRequest.setHeader("clientID", transactionResponseData.getClientId());
				}
			}
		}
		
		public void setHeadersForGetType(HttpServletRequest request, HttpGet getRequest, TransactionResponseData transactionResponseData)
		{
			getRequest.setHeader(HttpHeaders.CONTENT_TYPE, "application/json");
			getRequest.setHeader("optimizedFlow", "Y");
			getRequest.setHeader(HttpHeaders.AUTHORIZATION, "Basic " + request.getHeader(HttpHeaders.AUTHORIZATION)); //encoding retrived header
			if(transactionResponseData!=null)
			{
				if(transactionResponseData.getTransactionId() != null)
				{
					getRequest.setHeader("transactionID", transactionResponseData.getTransactionId());
					
				}
				if(transactionResponseData.getClientId() != null)
				{
					getRequest.setHeader("clientID", transactionResponseData.getClientId());
				}
			}
		}
		
		
		public TransactionResponseData populateResponseObject(String responseJson)
		{
			TransactionResponseData transactionResponseData = new TransactionResponseData();
			try {
		        JSONObject responseJsonObj = new JSONObject(responseJson);
		        transactionResponseData.setTransactionId(responseJsonObj.getString("transactionID"));
		        transactionResponseData.setClientId(responseJsonObj.getString("clientID"));
		
		        JSONArray objectFieldValuesList = responseJsonObj.getJSONArray("objectFieldValuesList");
		
		        for (int i = 0; i < objectFieldValuesList.length(); i++) {
		        	JSONObject objectFieldValue = (JSONObject)objectFieldValuesList.get(i);
		        	
		        	if(objectFieldValue.getString("GID")!= null)
		        	{	
		        		transactionResponseData.setGid(objectFieldValue.getString("GID"));
		        	}
		        	if(objectFieldValue.getString("sourceSystemID")!= null)
		        	{	
		        		transactionResponseData.setSourceSystemID(objectFieldValue.getString("sourceSystemID"));
		        	}
		        }
		        ErrorObject errorObject = new ErrorObject();
		        if(responseJsonObj.opt("errors") == JSONObject.NULL){
		        	JSONArray ErrorsList = responseJsonObj.getJSONArray("errors");
		        	int errosCount = ErrorsList.length();
			        ErrorObject[] errorObjects = new ErrorObject[errosCount];
			        for (int i = 0; i < ErrorsList.length(); i++) {
			        	JSONObject error = (JSONObject)ErrorsList.get(i);
			        	errorObject.setJasonPath(error.getString("jasonPath"));
			        	errorObject.setMessage(error.getString("message"));
			        	errorObject.setMessageType(error.getString("messageType"));
			        	errorObjects[i] = errorObject;
			        }
			        transactionResponseData.setErrors(errorObjects);
		        }
			}catch(Exception e)
			{
				e.printStackTrace();
			}
			
			return transactionResponseData;
		}
		
		public JsonRequest populateJsonRequest(String requestJson)
		{
			JsonRequest jsonRequest = new JsonRequest();
			try {
				JSONObject requestObj = new JSONObject(requestJson);
		        JSONObject customerObj = requestObj.getJSONObject("Customer");
		        String customerjson = new String(customerObj.toString());
		        JSONObject customerObjCopy =  new JSONObject(customerjson);
		        //From Customer request by remove other objects
		        customerObjCopy.remove("Address");
		        customerObjCopy.remove("Contacts");
		        customerObjCopy.remove("Producer");
		        jsonRequest.setCustomerJson("{\"Customer\": " + customerObjCopy.toString() + "}");
		        System.out.println("Customer Json =" + jsonRequest.getCustomerJson());
		        JSONObject addressObj = customerObj.getJSONObject("Address");
		        String addressjson = new String(addressObj.toString());
		        jsonRequest.setCustomerAddressJson("{\"Address\": " + addressObj.toString() + "}");
		        System.out.println("Customer Address Json=" + jsonRequest.getCustomerAddressJson());
		
		        JSONObject producerObj = customerObj.getJSONObject("Producer");
		        String producerjson = new String(producerObj.toString());
		        jsonRequest.setAgencyJson("{\"Address\": " + producerjson.toString() + "}");
		        System.out.println("Agency Json=" + jsonRequest.getAgencyJson());
		        JSONArray contactList = customerObj.getJSONArray("Contacts");
		    	
		        int contactCount = contactList.length();
		        Contact contacts[] = new Contact[contactCount]; 
		        for (int i = 0; i < contactCount; i++) {
		        	
		        	Contact contact = new Contact();
		        	JSONObject contactsObj = (JSONObject)contactList.get(i);
		        	        	
			        String contactjson = new String(contactsObj.toString());
			        JSONObject contactObjCopy =  new JSONObject(contactjson);
				        
			        //From Contact request by removing other objects
			        contactObjCopy.remove("Address");
			        contact.setContactJson("{\"Contact\": " + contactObjCopy.toString() + "}");
			        System.out.println("Contact Json=" + contact.getContactJson());
			        		        
			        JSONObject contactAddressObj = contactsObj.getJSONObject("Address");
			        contact.setConatctAddressJson("{\"Address\": " + contactAddressObj.toString() + "}");
			        System.out.println("Contact Address Json=" +contact.getConatctAddressJson());	
			        contacts[i] = contact;
		        }
		        jsonRequest.setContacts(contacts);
			}catch (Exception e)
			{
				e.printStackTrace();
			}
			return jsonRequest;
		}

		String readFile(String fileName)
		{
			String fileAsString = ""; 
			try {
				InputStream is = new FileInputStream(fileName); 
				BufferedReader buf = new BufferedReader(new InputStreamReader(is)); 
				String line = buf.readLine(); 
				StringBuilder sb = new StringBuilder(); 
				while(line != null)
				{ 	sb.append(line).append("\n"); 
					line = buf.readLine(); 
				} 
				fileAsString = sb.toString(); 
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			return fileAsString;
		}

	/*@Override
	public CustomerResponse updateCustomer(HttpServletRequest request) {
		
	}*/
	
	@Override
	public String ping() {
		return "This is Customer service";
	}

	@Override
	public CustomerTransactionsDetails getCustomerTransactionUrl(String customerId, String transName, HttpServletRequest request) {
		// TODO Auto-generated method stub
		CustomerTransactionsDetails customerTransactionDetails = new CustomerTransactionsDetails();
		boolean isSuccess = false;
		String url = null;
		String entityReference = null;
		String entityType = null;
		
		try {
			
			String sourceSystemUserId = request.getParameter("sourceSystemUserId")!=null ? request.getParameter("sourceSystemUserId"): null;
			
			if(!CustomerUtil.customerExist(customerId,sourceSystemUserId)) {
				
				String errMsg = customerId + APIConstant.CUSTOMER_NOT_EXISTS;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				WebServiceLoggerUtil.logInfo("CustomerServiceImpl", "getCustomer", errMsg, new Object[] { errMsg });
				throw new APIException(String.valueOf(Response.Status.NOT_FOUND.getStatusCode()),
						APIConstant.FAILED, errorMessageList, null);
			}
			if(CustomerUtil.customerExist(customerId,sourceSystemUserId)) {
				HashMap params = new HashMap();
				
				params.put("CUSTOMER_ID", customerId);
				QueryWithBindVariables queryWithBindVariablesCustomerEntityReference = CustomerUtil.resolveQueryExpression(params, CUSTOMER_ENTITY_REFERENCE_QUERY_ID, true);
				ArrayList<HashMap<String, String>> dataList = new ArrayList<HashMap<String, String>>();	
				dataList = CustomerUtil.executeQuery(queryWithBindVariablesCustomerEntityReference);			
				
				for (Map<String, String> row : dataList) {
					entityReference = row.get("ENTITY_REFERENCE");
					entityType = row.get("ENTITY_TYPE");
				}
				
				//IPCTRequestContext context = PCTRequestContext.getContext();
				User user = APIRequestContext.getApiRequestContext().getMtUser();
				if(sourceSystemUserId != null && sourceSystemUserId.length() > 0){
					user = APIRequestContext.getApiRequestContext().getSourceSystemUser(sourceSystemUserId);
				}
				
		        TransactionService transactionService = new TransactionService();
		        List<PolicyTransactionDetailsVO> availableTransactionList = null;
		        try {
		            // Start Changes for SR#74270
		            String roles = user.getRoleList();
		            availableTransactionList = transactionService.getAvailableTransactions(
		                    entityType,
		                    entityReference,
		                    user,
		                    "N",
		                    roles,
		                    transName);
		            // End Changes for SR#74270
		            if(availableTransactionList.isEmpty()) {
		            	/*String errMsg = APIConstant.TRANSACTION_NOT_AVAILABLE + customerId;
						List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
						WebServiceLoggerUtil.logInfo("CustomerServiceImpl", "getCustomer", errMsg, new Object[] { errMsg });
						throw new APIException(String.valueOf(Response.Status.NOT_FOUND.getStatusCode()),
								APIConstant.FAILED, errorMessageList, null);*/
		            	customerTransactionDetails.setCustomerId(customerId);
						customerTransactionDetails.setTransactionName(transName);
						customerTransactionDetails.setTransUrl(url);
						customerTransactionDetails.setMessage("Invalid Transaction : "+transName);
						customerTransactionDetails.setValidTransaction(false);
						return customerTransactionDetails;
		            }
		            Map<String, String> transParams = new HashMap<String, String>();
		            PolicyTransactionDetailsVO transVo = availableTransactionList.get(0);
		            transParams = transVo.getParams();
		            if(!transParams.isEmpty()) {
		            	String dbTransName = transParams.get("mic_transaction_name");
			            String transId = transParams.get("mic_transaction_id");
			            String permissionClass =  transParams.get("str_permission_class");
			            String permissionName = transParams.get("str_permission_name");
			            String operationMode = transParams.get("_operationMode");
			            String transDisplayName = transParams.get("trans_display_name");
			            String ctiComponent = transParams.get("ctiComponent");
			            String isCustom = (String)transParams.get("str_is_custom");
			            
			            if(null != dbTransName && !dbTransName.isEmpty()) {
			            	if(dbTransName.equalsIgnoreCase(transName)) {
			            		if(transName.equalsIgnoreCase("Modify")) {
			            			url = "/mic/pct/#!pct&ENTITY_TYPE="+entityType+"&ENCODED_PARAMS=1&ctiComponent="+ctiComponent+"&displayRCSuccessPopup=false&mic_transaction_name="
			            					+dbTransName+"&str_permission_class="+permissionClass+"&str_permission_name="+permissionName+"&_operationMode="
			            					+operationMode+"&mic_transaction_id="+transId+"&trans_display_name="+transDisplayName
			            					+"&folderId=null&entityStatusName=Not available&ctiPageId=null&_parentRegion=null&breadCrumbInfo=null&ENTITY_DISPLAY_TYPE="
			            					+entityType+"&ENTITY_DISPLAY_NAME="+customerId+ "&ENTITY_REFERENCE="+entityReference+"&OPERATION_MODE=" 
			            					+operationMode+"&PORTLET_ID=null&FIXED_HEIGHT=417&FIXED_WIDTH=1346";
			            			isSuccess = true;
			            		} else if(transName.equalsIgnoreCase("Merge")) {
			            			url = "/mic/portal/CustomerMerge.jsp?_entityType="+entityType+"&_entityReference="+entityReference+"&_operationMode="
			            					+operationMode+"&_entityDisplayName="+entityType+"&1=1&ctiComponent="+ctiComponent+"&mic_transaction_name="
			            					+dbTransName+"&str_permission_class="+permissionClass+"&action=merge&formAction=/mic/portal/CustomerMerge.jsp&title=Merge Customer"
			            					+"&str_permission_name="+permissionName+"&_operationMode="+operationMode+"&mic_transaction_id="+transId+"&trans_display_name="+transDisplayName
			            					+"&folderId=null&entityStatusName=Not available&ctiPageId=null&_parentRegion=null&breadCrumbInfo=null";
			            			isSuccess = true;
			            		} else if(transName.equalsIgnoreCase("Delete")) {
			            			
			            			String folderId = CustomerUtil.getFolderId(entityType, entityReference);
			            			
			            			url = "/mic/portal/ModifyEntity.jsp?action=OK&portletId=modifyEntityDetails&title=Delete%20Customer&_entityType=" 
			            					+ entityType +"&str_permission_class="
			            					+ permissionClass + "&_parentRegion=null&daoName=com.coverall.portal.dao.CustomerDAO&str_permission_name="
			            					+ permissionName + "&_operationMode="
			            					+ operationMode + "&mic_transaction_id="
			            					+ transId + "&trans_display_name="
			            					+ transDisplayName + "&folderId="
			            					+ folderId + "&_entityDisplayName="
			            					+ customerId + "&breadCrumbInfo=null&1=1&ctiComponent=portal&_entityReference="
			            					+ entityReference + "&mic_transaction_name="
			            					+ dbTransName + "&ctiPageId=null&entityStatusName=Not%20available&";
			            			isSuccess = true;
			            		} else if(transName.equalsIgnoreCase("View")) {
			            			
			            			String folderId = CustomerUtil.getFolderId(entityType, entityReference);
			            			
			            			url = "/mic/pct#!pct&ENTITY_TYPE="+entityType+"&ENCODED_PARAMS=1&ctiComponent="+ctiComponent+"&mic_transaction_name="
						            		 +dbTransName+"&str_permission_class="+permissionClass+"&action=inquireCustomer&str_is_custom=" +isCustom+"&str_permission_name="+permissionName+"&_operationMode="
						            		 +operationMode+"&mic_transaction_id="+transId+"&trans_display_name="+transDisplayName
						            		 +"&folderId="+folderId+"&entityStatusName=Open&ctiPageId=null&_parentRegion=null&breadCrumbInfo=null&ENTITY_DISPLAY_TYPE="
						            		 +entityType+"&ENTITY_REFERENCE="+entityReference+"&OPERATION_MODE=" 
						            		 +operationMode+"&PORTLET_ID=null&FIXED_HEIGHT=417&FIXED_WIDTH=1346";
			            			isSuccess = true;
			            		}
			            		
			            	}		            	
			            }
		            }
	    			
		        } catch (Exception e) {
		        	/*String errMsg = APIConstant.TRANSACTION_NOT_AVAILABLE + customerId;
					List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
					WebServiceLoggerUtil.logInfo("CustomerServiceImpl", "getCustomer", errMsg, new Object[] { errMsg });
					throw new APIException(String.valueOf(Response.Status.NOT_FOUND.getStatusCode()),
							APIConstant.FAILED, errorMessageList, null);*/
		        	customerTransactionDetails.setCustomerId(customerId);
					customerTransactionDetails.setTransactionName(transName);
					customerTransactionDetails.setTransUrl(url);
					customerTransactionDetails.setMessage( APIConstant.TRANSACTION_NOT_AVAILABLE + customerId);
					customerTransactionDetails.setValidTransaction(false);
					return customerTransactionDetails;
		        }
		        if(isSuccess) {
		        	customerTransactionDetails.setCustomerId(customerId);
					customerTransactionDetails.setTransactionName(transName);
					customerTransactionDetails.setTransUrl(url);
					customerTransactionDetails.setMessage("Success");
					customerTransactionDetails.setValidTransaction(true);
					customerTransactionDetails.setLocked(isEntityLocked(customerId,user));
		        }else {
		        	customerTransactionDetails.setCustomerId(customerId);
					customerTransactionDetails.setTransactionName(transName );
					customerTransactionDetails.setTransUrl(url);
					customerTransactionDetails.setMessage("Invalid Transaction ");
					customerTransactionDetails.setValidTransaction(false);
		        }
			
		}}catch(APIException e){
			WebServiceLoggerUtil.logError("CustomerServiceImpl", "getCustomerTransactionUrl", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw e;
		}
			
			
		return customerTransactionDetails;
	}

	@Override
	public Object getCustomerTransactions(String customerId, HttpServletRequest request) {
		// TODO Auto-generated method stub
		CustomerTransactions custTrans = new CustomerTransactions();
		boolean isSuccess = false;
		Map<String, String> allTransDetails = new HashMap<String, String>(); 
		try {
			String sourceSystemUserId = request.getParameter("sourceSystemUserId")!=null ? request.getParameter("sourceSystemUserId"): null;
			if(!CustomerUtil.customerExist(customerId,sourceSystemUserId)) {
				
				String errMsg = customerId + APIConstant.CUSTOMER_NOT_EXISTS;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				WebServiceLoggerUtil.logInfo("CustomerServiceImpl", "getCustomer", errMsg, new Object[] { errMsg });
				throw new APIException(String.valueOf(Response.Status.NOT_FOUND.getStatusCode()),
						APIConstant.FAILED, errorMessageList, null);
			}
			if(CustomerUtil.customerExist(customerId,sourceSystemUserId)) {
				HashMap params = new HashMap();
				
				params.put("CUSTOMER_ID", customerId);
				QueryWithBindVariables queryWithBindVariablesCustomerEntityReference = CustomerUtil.resolveQueryExpression(params, CUSTOMER_ENTITY_REFERENCE_QUERY_ID, true);
				ArrayList<HashMap<String, String>> dataList = new ArrayList<HashMap<String, String>>();	
				dataList = CustomerUtil.executeQuery(queryWithBindVariablesCustomerEntityReference);			
				
				String url = null;
				String entityReference = null;
				String entityType = null;
				for (Map<String, String> row : dataList) {
					entityReference = row.get("ENTITY_REFERENCE");
					entityType = row.get("ENTITY_TYPE");
				}
				
				//IPCTRequestContext context = PCTRequestContext.getContext();
				User user = APIRequestContext.getApiRequestContext().getMtUser();
				if(sourceSystemUserId != null && sourceSystemUserId.length() > 0){
					user = APIRequestContext.getApiRequestContext().getSourceSystemUser(sourceSystemUserId);
				}

		        TransactionService transactionService = new TransactionService();
		        List<PolicyTransactionDetailsVO> availableTransactionList = null;
		        try {
		            // Start Changes for SR#74270
		            String roles = user.getRoleList();
		            availableTransactionList = transactionService.getAvailableTransactions(
		                    entityType,
		                    entityReference,
		                    user,
		                    "N",
		                    roles,
		                    null);
		            // End Changes for SR#74270
		            Map<String, String> transParams = new HashMap<String, String>();
		            for(int i =0;i< availableTransactionList.size();i++) {
		            	PolicyTransactionDetailsVO transVo = availableTransactionList.get(i);
			            transParams = transVo.getParams();
			            if(!transParams.isEmpty()) {
			            	String dbTransName = transParams.get("mic_transaction_name");
				            String transId = transParams.get("mic_transaction_id");
				            String permissionClass =  transParams.get("str_permission_class");
				            String permissionName = transParams.get("str_permission_name");
				            String operationMode = transParams.get("_operationMode");
				            String transDisplayName = transParams.get("trans_display_name");
				            String ctiComponent = transParams.get("ctiComponent");
				            String isCustom = (String)transParams.get("str_is_custom");
				            
				            if(dbTransName.equalsIgnoreCase("Modify")) {
				            	url = "/mic/pct#!pct&ENTITY_TYPE="+entityType+"&ENCODED_PARAMS=1&ctiComponent="+ctiComponent+"&displayRCSuccessPopup=false&mic_transaction_name="
				            		 +dbTransName+"&str_permission_class="+permissionClass+"&str_permission_name="+permissionName+"&_operationMode="
				            		 +operationMode+"&mic_transaction_id="+transId+"&trans_display_name="+transDisplayName
				            		 +"&folderId=null&entityStatusName=Not available&ctiPageId=null&_parentRegion=null&breadCrumbInfo=null&ENTITY_DISPLAY_TYPE="
				            		 +entityType+"&ENTITY_DISPLAY_NAME="+customerId+ "&ENTITY_REFERENCE="+entityReference+"&OPERATION_MODE=" 
				            		 +operationMode+"&PORTLET_ID=null&FIXED_HEIGHT=417&FIXED_WIDTH=1346";
				            		isSuccess = true;
				            	allTransDetails.put(dbTransName, url);
				            } else if(dbTransName.equalsIgnoreCase("Merge")) {
				            	url = "/mic/portal/CustomerMerge.jsp?_entityType="+entityType+"&_entityReference="+entityReference+"&_operationMode="
				            		 +operationMode+"&_entityDisplayName="+entityType+"&1=1&ctiComponent="+ctiComponent+"&mic_transaction_name="
				            		 +dbTransName+"&str_permission_class="+permissionClass+"&action=merge&formAction=/mic/portal/CustomerMerge.jsp&title=Merge Customer"
				            		 +"&str_permission_name="+permissionName+"&_operationMode="+operationMode+"&mic_transaction_id="+transId+"&trans_display_name="+transDisplayName
				            		 +"&folderId=null&entityStatusName=Not available&ctiPageId=null&_parentRegion=null&breadCrumbInfo=null";
				            		isSuccess = true;
				            	allTransDetails.put(dbTransName, url);
				            } else if(dbTransName.equalsIgnoreCase("Delete")) {
		            			
		            			String folderId = CustomerUtil.getFolderId(entityType, entityReference);
		            			
		            			url = "/mic/portal/ModifyEntity.jsp?action=OK&portletId=modifyEntityDetails&title=Delete%20Customer&_entityType=" 
		            					+ entityType +"&str_permission_class="
		            					+ permissionClass + "&_parentRegion=null&daoName=com.coverall.portal.dao.CustomerDAO&str_permission_name="
		            					+ permissionName + "&_operationMode="
		            					+ operationMode + "&mic_transaction_id="
		            					+ transId + "&trans_display_name="
		            					+ transDisplayName + "&folderId="
		            					+ folderId + "&_entityDisplayName="
		            					+ customerId + "&breadCrumbInfo=null&1=1&ctiComponent=portal&_entityReference="
		            					+ entityReference + "&mic_transaction_name="
		            					+ dbTransName + "&ctiPageId=null&entityStatusName=Not%20available&";
		            			isSuccess = true;
		            			allTransDetails.put(dbTransName, url);
		            		} else if(dbTransName.equalsIgnoreCase("View")) {
		            			
		            			String folderId = CustomerUtil.getFolderId(entityType, entityReference);
		            			
		            			url = "/mic/pct#!pct&ENTITY_TYPE="+entityType+"&ENCODED_PARAMS=1&ctiComponent="+ctiComponent+"&mic_transaction_name="
					            		 +dbTransName+"&str_permission_class="+permissionClass+"&action=inquireCustomer&str_is_custom=" +isCustom+"&str_permission_name="+permissionName+"&_operationMode="
					            		 +operationMode+"&mic_transaction_id="+transId+"&trans_display_name="+transDisplayName
					            		 +"&folderId="+folderId+"&entityStatusName=Open&ctiPageId=null&_parentRegion=null&breadCrumbInfo=null&ENTITY_DISPLAY_TYPE="
					            		 +entityType+"&ENTITY_REFERENCE="+entityReference+"&OPERATION_MODE=" 
					            		 +operationMode+"&PORTLET_ID=null&FIXED_HEIGHT=417&FIXED_WIDTH=1346";
		            			isSuccess = true;
		            			allTransDetails.put(dbTransName, url);
		            		}
				            
			            }
		            
		            }
	    			
		        } catch (Exception e) {
		        	/*String errMsg = APIConstant.TRANSACTION_NOT_AVAILABLE + customerId;
					List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
					WebServiceLoggerUtil.logInfo("CustomerServiceImpl", "getCustomer", errMsg, new Object[] { errMsg });
					throw new APIException(String.valueOf(Response.Status.NOT_FOUND.getStatusCode()),
							APIConstant.FAILED, errorMessageList, null);*/
		        	custTrans.setCustomerId(customerId);
		        	custTrans.setCustomerData((HashMap) allTransDetails);
		        	custTrans.setMessage(APIConstant.TRANSACTION_NOT_AVAILABLE + customerId);
					custTrans.setValidTransaction(false);
					return custTrans;
		        }
		        if(isSuccess) {
		        	custTrans.setCustomerId(customerId);
		        	custTrans.setCustomerData((HashMap) allTransDetails);
		        	custTrans.setMessage("Success");
					custTrans.setValidTransaction(true);
					custTrans.setLocked(isEntityLocked(customerId, user));
		        }else {
		        	custTrans.setCustomerId(customerId);
		        	custTrans.setCustomerData((HashMap) allTransDetails);
		        	custTrans.setMessage("No Transactions Available for : "+customerId);
					custTrans.setValidTransaction(false);
		        }
			}
			
	        
		}catch(APIException e){
			WebServiceLoggerUtil.logError("CustomerServiceImpl", "getCustomerTransactions", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw e;
		}
		return custTrans;
	}
	
	public boolean isEntityLocked(String customerId, User user) {
		PreparedStatement pst = null;
		ResultSet rs = null;
		IPCTRequestContext context = null;
		boolean isEntityLocked = false;
		Connection connection = null;
		int recordCount = 0;
		
		try {
			connection = ConnectionPool.getConnection(user);
			
			String query = "SELECT count(*) FROM VW_MIS_CUSTOMERS WHERE ENTITY_TYPE = 'CUSTOMER' AND entity_is_locked = 'Y' AND DISPLAY_CUSTOMER_NUMBER = ?";

			pst = connection.prepareStatement(query);
            pst.setString(1, customerId);

            rs = pst.executeQuery();

            if(rs != null){
	   	       	 while (rs.next()) {
	   	       		 recordCount = rs.getInt(1);
	   	       	 }
			}
			if(recordCount > 0){
				isEntityLocked = true;
			}
            
		} catch (Exception ex) {
			WebServiceLoggerUtil.logError("CustomerServiceImpl", "isEntityLocked", ex.getLocalizedMessage(), new Object[] { ex.getMessage() }, ex);
					
		} finally {
			try {
				DBUtil.close(rs, pst, connection);

			} catch (Exception ex) {
			}
		}
		return isEntityLocked;
	}
	
	@Override
	public Object deleteCustomer(String customerId, HttpServletRequest request) {
		
		ServiceResponseData serviceResponseData = new ServiceResponseData();
		HashMap params = new HashMap();
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		String customerReference = "";
		try {
			User user = APIRequestContext.getApiRequestContext().getMtUser();
			String sourceSystemUserId = request.getParameter("sourceSystemUserId")!=null ? request.getParameter("sourceSystemUserId"): null;
			Connection conn = requestContext.getConnection();
			

			if(!CustomerUtil.customerExist(customerId,sourceSystemUserId)) {
				
				String errMsg = customerId + APIConstant.CUSTOMER_NOT_EXISTS;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				WebServiceLoggerUtil.logInfo("CustomerServiceImpl", "deleteCustomer", errMsg, new Object[] { errMsg });
				throw new APIException(String.valueOf(Response.Status.NOT_FOUND.getStatusCode()),
						APIConstant.FAILED, errorMessageList, null);
			}
			
			customerReference = CustomerUtil.getCustomerEntityReference(customerId);
			
			if(!CustomerUtil.checkIfDeleteTransactionAvaiable(user,customerReference)) {
				
				String errMsg = customerId + APIConstant.CUSTOMER_DELETE;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				WebServiceLoggerUtil.logInfo("CustomerServiceImpl", "deleteCustomer", errMsg, new Object[] { errMsg });
				throw new APIException(String.valueOf(Response.Status.NOT_FOUND.getStatusCode()),
						APIConstant.FAILED, errorMessageList, null);
			}
			
			
			CustomerDAO customerDao=new CustomerDAO();
			HashMap<String, String> userData=new HashMap<String, String>();
			userData.put("_entityType", "CUSTOMER");
			userData.put("_entityReference", customerReference);
			
			customerDao.initialise(user,userData);
			customerDao.delete(conn);
			
			serviceResponseData.setStatusCode("200");
			serviceResponseData.setResponseMessage(customerId+" customer is deleted successfully.");
			serviceResponseData.setCustomerId(customerId);
			
			
		} catch (APIException e) {
			WebServiceLoggerUtil.logError("CustomerServiceImpl", "deleteCustomer", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw e;
		} catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));
			WebServiceLoggerUtil.logError("CustomerServiceImpl", "deleteCustomer", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
					APIConstant.FAILED, errorMessageList,e);
		} 	
		return serviceResponseData;
	}

}
