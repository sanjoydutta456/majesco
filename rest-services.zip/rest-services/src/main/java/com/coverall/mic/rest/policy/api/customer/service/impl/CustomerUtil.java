package com.coverall.mic.rest.policy.api.customer.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

import javax.ws.rs.core.Response;

import com.coverall.el.FunctionResolver;
import com.coverall.el.InlineExpression;
import com.coverall.el.QueryWithBindVariables;
import com.coverall.el.VariableResolver;
import com.coverall.el.function.DefaultFunctionResolver;
import com.coverall.mic.rest.policy.api.customer.model.CustomerNote;
import com.coverall.mic.rest.policy.api.customer.model.CustomerRequest;
import com.coverall.mic.rest.policy.api.customer.model.PolicyEntity;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.UnifiedSearchErrors;
import com.coverall.mt.dao.QueriesCache;
import com.coverall.mt.el.variable.VariableResolverImpl;
import com.coverall.mt.http.HTTPConstants;
import com.coverall.mt.http.MICSession;
import com.coverall.mt.http.User;
import com.coverall.mt.policytrans.PolicyTransactionDetailsVO;
import com.coverall.mt.policytrans.TransactionService;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;
import com.coverall.util.GeneralUtil;

public class CustomerUtil {
	static final String RNUM = "rnum";
	static final String PARAM_USER = "user";
	static final String SEARCH_TYPE = "searchType";
	static final String SEARCH_VALUE = "searchValue";
	static final String WRAPPER_COUNT_QUERY_START = "SELECT COUNT(1) ROW_COUNT FROM ( " ;
	static final String WRAPPER_QUERY_END = ") " ;
	static final String WRAPPER_QUERY_START = "SELECT z.*, ROWNUM "+RNUM+"  FROM ( ";
	static final String WRAPPER_QUERY_WO_RNUM_START = "SELECT *  FROM ( ";
	static final String WRAPPER_QUERY_WO_RNUM_WHERE = ")  WHERE 1 = 1  ";
	static final String WRAPPER_QUERY_WHERE = ") z WHERE 1 = 1 " ;
	static final String WRAPPER_QUERY_AND = " AND ";
	static final String WRAPPER_QUERY_DESC = " DESC ";
	static final String WRAPPER_QUERY_ASC = " ASC ";
	static final String WRAPPER_QUERY_EQUALS = " = ";
	static final String WRAPPER_QUERY_ORDER_BY = " ORDER BY ";
	static final String DESCENDING = "DESCENDING";
	static final String ASCENDING = "ASCENDING";
	static final String DESC = "DESC";
	static final String ROWNUM = " ROWNUM ";
	static final String GREATER_THAN = " > ";
	static final String LESS_THAN = " < ";
	static final String LESS_THAN_EQUALS = " <= ";
	static final String GREATER_THAN_EQUALS = " >= ";
	static final String SINGLE_QUOTE = "\'";	
	static final String WRAPPER_QUERY_ROW_NO = " ) WHERE ROWNUM <= ";
	
	static final String ENTITY = "ENTITY";
	static final String LINKS_QUERY_ID = "entityNavigationLinks";
	static final String LINK ="LINK";
	static final String TYPE ="TYPE";
	static final String NAME = "NAME";
	static final String ACTION = "actions";
	static final String NAVIGATIONS = "navigations";
	static final String HOST_PLACEHODLER = "$HOST$";
	static final String COMMA = ",";
	static final String UNION = " union ";
	static final String PIPE_SEPARATOR = "\\|";
	
	private static ConcurrentHashMap<String,ArrayList<HashMap<String,String>>> commonEntityProperties = new ConcurrentHashMap<String, ArrayList<HashMap<String,String>>>();
	private static ConcurrentHashMap<String,ArrayList<HashMap<String,String>>> commonEntityPropertiesNotes = new ConcurrentHashMap<String, ArrayList<HashMap<String,String>>>();
	
	private static String hostURL ;
	
	static final String CUSTOMER_EXIST_QUERY_ID="CustomerExistQuery";	
	static final String IS_VALID_REQUEST="ISVALIDREQUEST";
	static final String SOURCE_SYSTEM_USER_ID="SourceSystemUserId";
	static final String NOTE_LINKS_QUERY_ID = "entityNoteActionLinks";
	
	
	
	public static boolean customerExist(String customerId,String sourceSystemUserId) {
		boolean customerExist = false;
		HashMap params = new HashMap();
		
		try {
			params.put("CUSTOMER_ID", customerId);
			if(sourceSystemUserId!=null){
				params.put(SOURCE_SYSTEM_USER_ID, sourceSystemUserId);
			}
			QueryWithBindVariables queryWithBindVariables = resolveQueryExpression(params, CUSTOMER_EXIST_QUERY_ID, true);
			ArrayList<HashMap<String, String>> dataList = new ArrayList<HashMap<String, String>>();	
			dataList = executeQuery(queryWithBindVariables);				
					
			for (Map<String, String> row : dataList) {
				customerExist = new Boolean(row.get(IS_VALID_REQUEST)).booleanValue();														
			}
			
		} catch (APIException e) {
			WebServiceLoggerUtil.logError("CustomerUtil", "customerExist", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw e;
		} catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));
			WebServiceLoggerUtil.logError("CustomerUtil", "customerExist", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
					APIConstant.FAILED, errorMessageList,e);
		}
		return customerExist;
	}
	
	
	public static String generateQueryWithPagination(String query,Long pgNumber,Long pgSize){

		String sortOrder  = "ASCENDING";
		String sortColumn = null;
		Long startIndex = null; 
		Long endIndex = null;
		if(pgNumber!=null && pgSize!= null ){
			startIndex = pgNumber*pgSize +1; 
			endIndex = startIndex+pgSize-1;
		}
		
		StringBuffer  wrapperQuery = new StringBuffer();
		StringBuffer  rownumWrapperQuery = new StringBuffer(); 
		StringBuffer  rownumEndIndexWrapperQuery = null; 
		
		wrapperQuery.append(WRAPPER_QUERY_WO_RNUM_START);
		wrapperQuery.append(query);
		wrapperQuery.append(WRAPPER_QUERY_WO_RNUM_WHERE);
		
		if(sortColumn != null){
			wrapperQuery.append(WRAPPER_QUERY_ORDER_BY);
			wrapperQuery.append(sortColumn);
			if(ASCENDING.equalsIgnoreCase(sortOrder) || "ASC".equalsIgnoreCase(sortOrder)){
				wrapperQuery.append(WRAPPER_QUERY_ASC);
			}
		}
		if(startIndex != null || endIndex != null ){
			if(endIndex != null){
				rownumEndIndexWrapperQuery = new StringBuffer();
				rownumEndIndexWrapperQuery.append(WRAPPER_QUERY_START);
				rownumEndIndexWrapperQuery.append(wrapperQuery);
				rownumEndIndexWrapperQuery.append(WRAPPER_QUERY_WHERE);
				rownumEndIndexWrapperQuery.append(WRAPPER_QUERY_AND);
				rownumEndIndexWrapperQuery.append(ROWNUM);
				rownumEndIndexWrapperQuery.append(LESS_THAN_EQUALS);
				rownumEndIndexWrapperQuery.append(endIndex);
				wrapperQuery = rownumEndIndexWrapperQuery;
			}else if(startIndex != null){
				rownumEndIndexWrapperQuery = new StringBuffer();
				rownumEndIndexWrapperQuery.append(WRAPPER_QUERY_START);
				rownumEndIndexWrapperQuery.append(wrapperQuery);
				rownumEndIndexWrapperQuery.append(WRAPPER_QUERY_WHERE);
				wrapperQuery = rownumEndIndexWrapperQuery;
			}
			
			if(startIndex != null){
				rownumWrapperQuery.append(WRAPPER_QUERY_WO_RNUM_START);
				rownumWrapperQuery.append(wrapperQuery);
				rownumWrapperQuery.append(WRAPPER_QUERY_WO_RNUM_WHERE);
				rownumWrapperQuery.append(WRAPPER_QUERY_AND);
				rownumWrapperQuery.append(RNUM);
				rownumWrapperQuery.append(GREATER_THAN_EQUALS);
				rownumWrapperQuery.append(startIndex);
				return rownumWrapperQuery.toString();
			}
		}
		
		return wrapperQuery.toString();
	}
	
	public static String resolveQueryExpression(HashMap params, String queryId) {
		return ((resolveQueryExpression(params, queryId, true)).getQuery());
	}
	
	public static QueryWithBindVariables resolveQueryExpression(HashMap params, String queryId, boolean bindVariableStatus) {

		User user = APIRequestContext.getApiRequestContext().getMtUser();
		String sqlQuery = null;
		HashMap variableMap = new HashMap();
		String sourceSystemUserId=null;
		try {
			/*DAOManager daoManager = DAOManager.getInstance(ServletConfigUtil.COMPONENT_PORTAL);
			Query query = daoManager.getQuery(ServletConfigUtil.COMPONENT_PORTAL, user, queryId);
			if(query == null){
				Exception apiException  = new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,null,null);
				WebServiceLoggerUtil.logError("CustomerUtil", "resolveQueryExpression", "Query not found in queries.xml file" , new Object[] {queryId},apiException);
				throw new APIException();
			}
			sqlQuery = query.toString();*/
			String customerCode = CustomerConfigUtil.getInstance().getCustomerCode(user.getDomain());
			sqlQuery = QueriesCache.getCustomerPanaromicViewQueries(customerCode + "_" + queryId);
			if(sqlQuery == null || sqlQuery.length() == 0 ){
				Exception apiException  = new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,null,null);
				WebServiceLoggerUtil.logError("CustomerUtil", "resolveQueryExpression", "Query not found in queries.xml file" , new Object[] {queryId},apiException);
				throw new APIException();
			}
			Random randomizer = new Random();
			MICSession session = new MICSession(randomizer.nextInt() + "", null);
			
			if(params.get(SOURCE_SYSTEM_USER_ID)!= null){
				sourceSystemUserId = params.get(SOURCE_SYSTEM_USER_ID).toString();
			}	
			
			if(sourceSystemUserId != null){
			  User simulatedUser = APIRequestContext.getApiRequestContext().getSourceSystemUser(sourceSystemUserId);
			  if(simulatedUser != null){
				  user = simulatedUser;  
			  }else{
				  WebServiceLoggerUtil.logError("CustomerUtil", "resolveQueryExpression","simulatedUser is null, using the autheticated user", new Object[] {}, new Exception());
			  }
			}
			WebServiceLoggerUtil.logInfo("CustomerUtil","resolveQueryExpression", "User gettng used for DLS filter", new Object[] {user});
						
			//HashMap params = new HashMap();
			params.put(PARAM_USER, user);
			params.put("domain", user.getDomain());
			params.put("userName", user.getUserId());
			//params.put("CUSTOMER_ID", policyEntityRequest.getCustomerId());
			params.put(ServletConfigUtil.COMPONENT, "portal");
						
			variableMap.put(VariableResolverImpl.REQUESTPARAMS_PARAMETER, params);
			session.setAttribute(HTTPConstants.SESSION_USER, user);
			variableMap.put(VariableResolverImpl.SESSION_PARAMETER, session);
			VariableResolver varResolver = new VariableResolverImpl(variableMap);
			FunctionResolver funcResolver = new DefaultFunctionResolver();
			
			try {
				varResolver.setDynamicBind(true);
				
				InlineExpression expression = new InlineExpression(sqlQuery, varResolver, funcResolver);
				
				return (expression.getQueryWithBindVariables());
			} catch (Exception e) {
				e.printStackTrace();
				
				WebServiceLoggerUtil.logError("CustomerUtil", "resolveQueryExpression", e.getLocalizedMessage(), new Object[] {queryId , sqlQuery , variableMap}, e);
				throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);
			} finally {
				varResolver.setDynamicBind(false);
			}
		}  catch (Exception e) {
			WebServiceLoggerUtil.logError("CustomerUtil", "resolveQueryExpression", e.getLocalizedMessage(), new Object[] {queryId , sqlQuery , variableMap}, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);
		}
	}
	
	public static ArrayList<HashMap<String, String>> executeQuery(String query) {
		QueryWithBindVariables queryWithBindVariables = new QueryWithBindVariables();
		
		queryWithBindVariables.setQuery(query);
		
		return (executeQuery(queryWithBindVariables));
	}
	
	public static ArrayList<HashMap<String, String>> executeQuery(QueryWithBindVariables queryWithBindVariables){
		String query = queryWithBindVariables.getQuery();
		List<String> bindVariableList = queryWithBindVariables.getBindVariablesValues();
		
		ArrayList<HashMap<String, String>> dataList = new ArrayList<HashMap<String, String>>();
		Connection conn = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		HashMap<String, String> row = null;
		try {
			conn = APIRequestContext.getApiRequestContext().getConnection();
			statement = conn.prepareStatement(query);
			
			if (null != bindVariableList) {
				GeneralUtil.bindVariablesToStatement(bindVariableList, statement, 0);
			}
			
			WebServiceLoggerUtil.logInfo("CustomerUtil", "executeQuery", query, new Object[] { query, bindVariableList });
			
			rs = statement.executeQuery();
			if (rs != null) {
				rsmd = rs.getMetaData();
				while (rs.next()) {
					row = new HashMap<String, String>();
					int columnCount = rsmd.getColumnCount();
					for (int i = 1; i <= columnCount; i++) {
						String columnName = rsmd.getColumnName(i);
						row.put(columnName.toUpperCase(), rs.getString(columnName));
					}
					dataList.add(row);
				}
			}
		} catch (Exception e) {
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);

		}finally {
			try {
                DBUtil.close(rs, statement, null);                
			} catch (SQLException e) {
				WebServiceLoggerUtil.logError("CustomerUtil", "executeQuery", e.getLocalizedMessage(), new Object[] { query, conn }, e);
				throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);
			}
		}
		return dataList;
	}
	
	public static String getFolderId(String entityType, String entityReference){
		String folderId = "";
		String query = "";
		Connection conn = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		HashMap<String, String> row = null;
		try {
			conn = APIRequestContext.getApiRequestContext().getConnection();
			
			query = "select FEF_FOLDER_ID from FOM_ENTITY_FOLDERS where FEF_ENTITY_TYPE = ? and FEF_ENTITY_REFERENCE = ? ";

			statement = conn.prepareStatement(query);
			statement.setString(1, entityType);
			statement.setString(2, entityReference);
			WebServiceLoggerUtil.logInfo("CustomerUtil", "getFolderId", query, new Object[] { query });
			rs = statement.executeQuery();
			
			while (rs.next()){
				folderId = rs.getString("FEF_FOLDER_ID");            
	        }
			
		} catch (Exception e) {
			WebServiceLoggerUtil.logError("CustomerUtil", "getFolderId", e.getLocalizedMessage(), new Object[] { query, conn }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);

		}finally {
			try {
                DBUtil.close(rs, statement, null);                
			} catch (SQLException e) {
				WebServiceLoggerUtil.logError("CustomerUtil", "getFolderId", e.getLocalizedMessage(), new Object[] { query, conn }, e);
				throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);
			}
		}
		return folderId;
	}
	
	
	
	public static List<Message> getErrorMessageList(List<String> strMessages)	{
		if(strMessages == null)	{
			return null;
		}
		List<Message> errorMessageList = new ArrayList<Message>(strMessages.size());
		for(String aMsg : strMessages)	{
			Message message = new Message();
			message.setMoreinfo(aMsg);
			errorMessageList.add(message);
		}
		return errorMessageList;
	}
	
	public static void validatePolicyEntityRequest(CustomerRequest custRequest){		
		if(custRequest.getCustomerId().equals(null) || custRequest.getCustomerId().isEmpty()) {
			List <Message> errorMessageList =  new ArrayList<Message>();
			Message message = new Message();
			message.setMoreinfo(APIConstant.MANDATORY_CUSTOMER_ID);
			errorMessageList.add(message);
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			throw new APIException(httpStatusCode,APIConstant.FAILED,errorMessageList,new Throwable());
		}		
	}
	public static void validateCustomerEventsRequest(CustomerRequest custRequest){		
		if(custRequest.getCustomerId().equals(null) || custRequest.getCustomerId().isEmpty()) {
			List <Message> errorMessageList =  new ArrayList<Message>();
			Message message = new Message();
			message.setMoreinfo(APIConstant.MANDATORY_CUSTOMER_ID);
			errorMessageList.add(message);
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			throw new APIException(httpStatusCode,APIConstant.FAILED,errorMessageList,new Throwable());
		}
		if(custRequest.getEventCode().equals(null) || custRequest.getEventCode().isEmpty()) {
			List <Message> errorMessageList =  new ArrayList<Message>();
			Message message = new Message();
			message.setMoreinfo(APIConstant.MANDATORY_EVENT_CODE);
			errorMessageList.add(message);
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			throw new APIException(httpStatusCode,APIConstant.FAILED,errorMessageList,new Throwable());
		}
		if(custRequest.getEventFromDate().equals(null) || custRequest.getEventFromDate().isEmpty()) {
			List <Message> errorMessageList =  new ArrayList<Message>();
			Message message = new Message();
			message.setMoreinfo(APIConstant.MANDATORY_EVENT_FROM_DATE);
			errorMessageList.add(message);
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			throw new APIException(httpStatusCode,APIConstant.FAILED,errorMessageList,new Throwable());
		}
		if(custRequest.getEventToDate().equals(null) || custRequest.getEventToDate().isEmpty()) {
			List <Message> errorMessageList =  new ArrayList<Message>();
			Message message = new Message();
			message.setMoreinfo(APIConstant.MANDATORY_EVENT_TO_DATE);
			errorMessageList.add(message);
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			throw new APIException(httpStatusCode,APIConstant.FAILED,errorMessageList,new Throwable());
		}
	}
		
	public static void validateCustomerNotesRequest(CustomerRequest custRequest){		
		if((custRequest.getCustomerId().equals(null) || custRequest.getCustomerId().isEmpty()) && 
				( null == custRequest.getNumberOfNotes() || custRequest.getNumberOfNotes().isEmpty())) {
			List <Message> errorMessageList =  new ArrayList<Message>();
			Message message = new Message();
			message.setMoreinfo(APIConstant.MANDATORY_REQUEST_PARAM_SEARCH_TYPE);
			errorMessageList.add(message);
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			throw new APIException(httpStatusCode,APIConstant.FAILED,errorMessageList,new Throwable());
		}		
	}

	public static String getHostURL() {
		return hostURL;
	}

	public static void setHostURL(String hostURL) {
		CustomerUtil.hostURL = hostURL;
	}

		
	public static void addNavigationAndAction(PolicyEntity policyEntity, Map<String, String> dataRow) {
		
		ArrayList<HashMap> navigationList = new ArrayList<HashMap>();
		ArrayList<HashMap> actionList = new ArrayList<HashMap>();
		try {
			loadCommonEntityProperties();
			ArrayList<HashMap<String, String>> entityProperties = commonEntityProperties.get(dataRow.get("ENTITY_TYPE"));
			if (entityProperties != null) {
				for (HashMap<String, String> entityMap : entityProperties) {
					HashMap<String, String> linkMap = new HashMap<String, String>();
					String link = entityMap.get(LINK);
					// Replace HOST
					/*if (hostURL != null) {
						link = link.replace(HOST_PLACEHODLER, hostURL);
					}*/
					// Replace placeholder in the link
					for (String key : dataRow.keySet()) {
						String placeHolder = "$" + key + "$";
						if (link != null && link.indexOf(placeHolder) != -1) {
							link = link.replace(placeHolder, dataRow.get(key));
						}
					}

					String name = entityMap.get(NAME);
					//linkMap.put(name, link);
					if (ACTION.equalsIgnoreCase(entityMap.get(TYPE))) {
						linkMap.put("actionName", "PAS View");
						linkMap.put("actionLink", link);
						ArrayList<HashMap> exitsingActionList = policyEntity.getActions();
						if (exitsingActionList != null) {
							exitsingActionList.add(linkMap);
						} else {
							actionList.add(linkMap);
							policyEntity.setActions(actionList);
						}
					} else if (NAVIGATIONS.equalsIgnoreCase(entityMap.get(TYPE))) {
						linkMap.put(name, link);
						ArrayList<HashMap> exitsingNavigationList = policyEntity.getNavigations();
						if (exitsingNavigationList != null) {
							exitsingNavigationList.add(linkMap);
						} else {
							navigationList.add(linkMap);
							policyEntity.setNavigations(navigationList);
						}
					}
				}
			}
		} catch (Exception e) {
			WebServiceLoggerUtil.logError("CustomerUtil", "addNavigationAndAction", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);
		}
	}
		
		public static void addNavigationAndActionNotes(CustomerNote customerNote, Map<String, String> dataRow) {
			
			ArrayList<HashMap> navigationList = new ArrayList<HashMap>();
			ArrayList<HashMap> actionList = new ArrayList<HashMap>();
			try {
				loadCommonEntityPropertiesNotes();
				ArrayList<HashMap<String, String>> entityProperties = commonEntityPropertiesNotes.get(dataRow.get("ENTITY_TYPE"));
				if (entityProperties != null) {
					for (HashMap<String, String> entityMap : entityProperties) {
						HashMap<String, String> linkMap = new HashMap<String, String>();
						String link = entityMap.get(LINK);
						// Replace HOST
						/*if (hostURL != null) {
							link = link.replace(HOST_PLACEHODLER, hostURL);
						}*/
						// Replace placeholder in the link
						for (String key : dataRow.keySet()) {
							String placeHolder = "$" + key + "$";
							if (link != null && link.indexOf(placeHolder) != -1) {
								link = link.replace(placeHolder, dataRow.get(key));
							}
						}

						String name = entityMap.get(NAME);
						//linkMap.put(name, link);
						if (NAVIGATIONS.equalsIgnoreCase(entityMap.get(TYPE))) {
							linkMap.put("attributeName", name);
							linkMap.put("navigationLink", link);							
							ArrayList<HashMap> exitsingNavigationList = customerNote.getNavigation();
							if (exitsingNavigationList != null) {
								exitsingNavigationList.add(linkMap);
							} else {
								navigationList.add(linkMap);
								customerNote.setNavigation(navigationList);
							}
						} /*else if (ACTION.equalsIgnoreCase(entityMap.get(TYPE))) {
							//linkMap.put("actionName", "View Policy");
							linkMap.put("actionLink", link);
							ArrayList<HashMap> exitsingActionList = customerNote.getActions();
							if (exitsingActionList != null) {
								exitsingActionList.add(linkMap);
							} else {
								actionList.add(linkMap);
								customerNote.setActions(actionList);
							}
						}*/
					}
				}
			} catch (Exception e) {
				WebServiceLoggerUtil.logError("CustomerUtil", "addNavigationAndActionNotes", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
				throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);
			}

	}
	public static void loadCommonEntityProperties() {
		if(!commonEntityProperties.isEmpty()){
			// The properties are already loaded
			return ;
		}
		HashMap params = new HashMap();
		String linkQuery = resolveQueryExpression(params, LINKS_QUERY_ID);
		ArrayList<HashMap<String, String>> dataRecords = executeQuery(linkQuery);
		for (HashMap<String, String> row : dataRecords) {
			if (row != null) {
				String entityId = row.get(ENTITY);
				ArrayList<HashMap<String, String>> loadedData = commonEntityProperties.get(entityId);
				if(loadedData == null){
					ArrayList<HashMap<String, String>> initialRow = new ArrayList<HashMap<String,String>>();
					initialRow.add(row);
					commonEntityProperties.put(entityId, initialRow);
				}else{
					loadedData.add(row);
				}
			}
		}
	}
	
	public static void loadCommonEntityPropertiesNotes() {
		if(!commonEntityPropertiesNotes.isEmpty()){
			// The properties are already loaded
			return ;
		}
		HashMap params = new HashMap();
		String linkQuery = resolveQueryExpression(params, NOTE_LINKS_QUERY_ID);
		ArrayList<HashMap<String, String>> dataRecords = executeQuery(linkQuery);
		for (HashMap<String, String> row : dataRecords) {
			if (row != null) {
				String entityId = row.get(ENTITY);
				ArrayList<HashMap<String, String>> loadedData = commonEntityPropertiesNotes.get(entityId);
				if(loadedData == null){
					ArrayList<HashMap<String, String>> initialRow = new ArrayList<HashMap<String,String>>();
					initialRow.add(row);
					commonEntityPropertiesNotes.put(entityId, initialRow);
				}else{
					loadedData.add(row);
				}
			}
		}
	}
	
	public static String getAppendedValueList(ArrayList<String> eventCode) {
		StringBuffer strInQuery = new StringBuffer();
		String result= null;
		int counter = 0;	   
	    for (String value : eventCode) {	    	
	    	counter++;
	    	strInQuery.append(SINGLE_QUOTE);
	    	strInQuery.append(value);
	    	strInQuery.append(SINGLE_QUOTE);
	    	if(eventCode.size() >1 && counter != eventCode.size()){
	    		strInQuery.append(COMMA);
	    	}
	    }
	    result=strInQuery.toString();
	    //System.out.println(result);	    
	    return result;		
	}
	
	public static String getAppendedPlaceholderList(ArrayList<String> eventCode) {
		StringBuffer strInQuery = new StringBuffer();
		String result= null;
		int counter = 0;	   
	    for (String value : eventCode) {	    	
	    	counter++;
	    	strInQuery.append("?");
	    	if(eventCode.size() >1 && counter != eventCode.size()){
	    		strInQuery.append(COMMA);
	    	}
	    }
	    result=strInQuery.toString();
	    //System.out.println(result);	    
	    return result;		
	}
	
	public static boolean checkIfDeleteTransactionAvaiable(User user,String entityReference) {
		boolean deleteTransactionAvaiable = false;
		TransactionService transactionService = new TransactionService();
        List<PolicyTransactionDetailsVO> availableTransactionList = null;
		
		try {
			String roles = user.getRoleList();
            availableTransactionList = transactionService.getAvailableTransactions(
                    "CUSTOMER",
                    entityReference,
                    user,
                    "N",
                    roles,
                    null);
            Map<String, String> transParams = new HashMap<String, String>();
            for(int i =0;i< availableTransactionList.size();i++) {
            	PolicyTransactionDetailsVO transVo = availableTransactionList.get(i);
            	transParams = transVo.getParams();
	            if(!transParams.isEmpty()) {
	            	String dbTransName = transParams.get("mic_transaction_name");
	            	if(dbTransName.equalsIgnoreCase("Delete")) {
	            		deleteTransactionAvaiable=true;
	            	}
	            }
            	
            }
			
			
		} catch (APIException e) {
			WebServiceLoggerUtil.logError("CustomerUtil", "checkIfDeleteTransactionAvaiable", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw e;
		} catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));
			WebServiceLoggerUtil.logError("CustomerUtil", "checkIfDeleteTransactionAvaiable", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
					APIConstant.FAILED, errorMessageList,e);
		}
		return deleteTransactionAvaiable;
	}
	
	public static String getCustomerEntityReference(String customerId){
		String entityRef = "";
		String query = "";
		Connection conn = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		HashMap<String, String> row = null;
		try {
			conn = APIRequestContext.getApiRequestContext().getConnection();
			
			query = "select ENTITY_REFERENCE from vw_mis_customers where DISPLAY_CUSTOMER_NUMBER=? and ENTITY_TYPE=? ";

			statement = conn.prepareStatement(query);
			statement.setString(1, customerId);
			statement.setString(2, "CUSTOMER");
			WebServiceLoggerUtil.logInfo("CustomerUtil", "getCustomerEntityReference", query, new Object[] { query });
			rs = statement.executeQuery();
			
			while (rs.next()){
				entityRef = rs.getString("ENTITY_REFERENCE");            
	        }
			
		} catch (Exception e) {
			WebServiceLoggerUtil.logError("CustomerUtil", "getCustomerEntityReference", e.getLocalizedMessage(), new Object[] { query, conn }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);

		}finally {
			try {
                DBUtil.close(rs, statement, null);                
			} catch (SQLException e) {
				WebServiceLoggerUtil.logError("CustomerUtil", "getCustomerEntityReference", e.getLocalizedMessage(), new Object[] { query, conn }, e);
				throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);
			}
		}
		return entityRef;
	}

}
