package com.coverall.mic.rest.policy.api.esign.model;

import javax.xml.bind.annotation.XmlRootElement;

import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.UnifiedSearchRequest;
import com.google.gson.Gson;


@SuppressWarnings("serial")
@XmlRootElement(name="UnifiedSearchRequest")
public class ESignRequest implements java.io.Serializable {
	
	
	public ESignRequest(){
		
	}

	public ESignRequest(String json) {
		super(); 
		Gson gson = new Gson();
		ESignRequest request = gson.fromJson(json, ESignRequest.class);
		this.envelopeStatus = request.envelopeStatus;
		this.envelopeId = request.envelopeId;
		this.envelopeDate = request.envelopeDate;
	}
	
	private String envelopeStatus; 
	private String envelopeId;
	private String envelopeDate;
	

	public String getEnvelopeStatus() {
		return envelopeStatus;
	}


	public void setEnvelopeStatus(String envelopeStatus) {
		this.envelopeStatus = envelopeStatus;
	}


	public String getEnvelopeId() {
		return envelopeId;
	}


	public void setEnvelopeId(String envelopeId) {
		this.envelopeId = envelopeId;
	}


	public String getEnvelopeDate() {
		return envelopeDate;
	}



	public void setEnvelopeDate(String envelopeDate) {
		this.envelopeDate = envelopeDate;
	}



	@Override
	public String toString() {
		return "WebhookData [ envelopeStatus= "
				+ envelopeStatus + ", envelopeId=" +envelopeId+ ", envelopeDate=" +envelopeDate+ "]";
	}

}
