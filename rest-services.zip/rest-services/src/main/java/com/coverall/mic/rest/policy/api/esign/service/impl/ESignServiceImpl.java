package com.coverall.mic.rest.policy.api.esign.service.impl;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.StreamingOutput;

import com.coverall.mic.rest.policy.api.esign.model.ESignRequest;
import com.coverall.mic.rest.policy.api.esign.service.ESignService;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mt.events.EventProcessor;
import com.coverall.mt.http.User;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.mt.webservices.esig.clients.EsigDownloadDocumentVO;
import com.coverall.mt.webservices.esig.clients.EsigServiceClient;
import com.coverall.util.DBUtil;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;

public class ESignServiceImpl implements ESignService {

	
	public ESignServiceImpl() {
	
	}
	
	public static final Map _returnStatus = new HashMap() { 
        {
            put("envelopeCompleted", "Complete");
            put("envelopeExpired", "Expire");
            put("envelopeDeclined", "Decline");
        }
    };

	@Override
	public Object updateeSignStatus(HttpServletRequest request) {

		boolean isSuccess = false;
		String status = "";
		
		String requestJson=APIOperationUtil.fetchRequestBody(request);
		ESignRequest eSignRequest=new ESignRequest(requestJson);
		
		try {
								
			String envelopeStatus =eSignRequest.getEnvelopeStatus(); 
			String envelopeId = eSignRequest.getEnvelopeId();
			String envelopeDate = eSignRequest.getEnvelopeDate();
			
			//get status from IEL_MIC_ESIGN_DATA_MAP
			if(null != envelopeStatus){
				status = getStatus(envelopeStatus);
			}
			
							
			if(!status.isEmpty() && !envelopeDate.isEmpty() && !envelopeId.isEmpty()){				
				
				if("envelopeCompleted".equalsIgnoreCase(envelopeStatus)){
					EsigServiceClient client = new EsigServiceClient();
					User user = APIRequestContext.getApiRequestContext().getMtUser();
					
					HashMap info = EventProcessor.getWebServiceParameters("MIC - WS - ESIGNATURE - INTEGRATION", user);
					
					EsigDownloadDocumentVO esigDownloadDocumentVO = new EsigDownloadDocumentVO();
					esigDownloadDocumentVO.setEnvelopId(envelopeId);
					esigDownloadDocumentVO.setEsignAPIURL((String)info.get("eSignatureEnvelopDownloadURL"));
					esigDownloadDocumentVO.setSlingUploadAPI((String)info.get("eSignatureSlingUploadURL"));
					esigDownloadDocumentVO.setSlingDownloadAPI((String)info.get("eSignatureSlingDownloadURL"));
					esigDownloadDocumentVO.setSlingPath((String)info.get("eSignatureSlingPath"));
					esigDownloadDocumentVO.setFileOverwriteFlag((String)info.get("eSignatureSlingUploadOverwrite"));
					
					info = EventProcessor.getWebServiceParameters("MIC - Next Generation - Advanced Document Generation", user);
					esigDownloadDocumentVO.setSlingUserName((String)info.get("serviceUsername"));
					esigDownloadDocumentVO.setSlingPassword((String)info.get("servicePassword"));
					
					
					try {
						client.downloadSignedDocFromEsign(esigDownloadDocumentVO,user);
						updateESignatureDocuments(status, envelopeDate,envelopeId);
						isSuccess = true;
					}catch(Exception e)
					{
						WebServiceLoggerUtil.logError("ESignServiceImpl", "updateeSignStatus", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
						isSuccess = false;
						e.printStackTrace();
					}
				}
				else
				{
					try {
						updateESignatureDocuments(status, envelopeDate,envelopeId);
						isSuccess = true;
					}catch(Exception e)
					{
						WebServiceLoggerUtil.logError("ESignServiceImpl", "updateeSignStatus", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
						isSuccess = false;
						e.printStackTrace();
					}
					
				}
				
			}			
			
			
		
		} catch (APIException e) {
			WebServiceLoggerUtil.logError("ESignServiceImpl", "updateeSignStatus", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw e;
		} catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError("ESignServiceImpl", "updateeSignStatus", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);

			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		} 
		return isSuccess;
	}

	@Override
	public String ping() {
		// TODO Auto-generated method stub
		return "This is eSign service";
	}
	
	public String getStatus(String envelopeStatus){
		String status = "";
		String query = "";
		Connection conn = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		HashMap<String, String> row = null;
		try {
			conn = APIRequestContext.getApiRequestContext().getConnection();
			
			query = "select MAPPING from IEL_MIC_ESIGN_DATA_MAP where KEY_ID = ? ";

			statement = conn.prepareStatement(query);
			statement.setString(1, envelopeStatus);
			WebServiceLoggerUtil.logInfo("ESignServiceImpl", "getStatus", query, new Object[] { query });
			rs = statement.executeQuery();
			
			while (rs.next()){
				status = rs.getString("MAPPING");            
	        }
			
		} catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));
			WebServiceLoggerUtil.logError("ESignServiceImpl", "getStatus", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
					APIConstant.FAILED, errorMessageList,e);
		}finally {
			try {
                DBUtil.close(rs, statement, null);                
			} catch (SQLException e) {
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));
				WebServiceLoggerUtil.logError("ESignServiceImpl", "getStatus", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
				throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
						APIConstant.FAILED, errorMessageList,e);
			}
		}
		return status;
	}
	private List<Message> getErrorMessageList(List<String> strMessages)	{
		if(strMessages == null)	{
			return null;
		}
		List<Message> errorMessageList = new ArrayList<Message>(strMessages.size());
		for(String aMsg : strMessages)	{
			Message message = new Message();
			message.setMoreinfo(aMsg);
			errorMessageList.add(message);
		}
		return errorMessageList;
	}
	
	
	public int updateESignatureDocuments(String status, String date, String envelopeId){
		String query = "";
		Connection conn = null;
		PreparedStatement statement = null;
		int rowsUpdated = 0;
		try {
			conn = APIRequestContext.getApiRequestContext().getConnection();
			
			query = "update WS_ESIGNATURE_DOCUMENTS set " +
					" WES_STATUS = ?, "+
					" WES_STATUS_DATE = TO_DATE(?, 'YYYY-MM-DD\"T\"HH24:MI:SS')  "+
					" where WES_VENDOR_ENVELOPE_ID = ? ";
			
			statement = conn.prepareStatement(query);
			statement.setString(1, status);
			statement.setString(2, date);
			statement.setString(3, envelopeId);
			WebServiceLoggerUtil.logInfo("ESignServiceImpl", "updateESignatureDocuments", query, new Object[] { query });
			rowsUpdated = statement.executeUpdate();
			conn.commit();
			
			
		} catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));
			WebServiceLoggerUtil.logError("ESignServiceImpl", "updateESignatureDocuments", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
					APIConstant.FAILED, errorMessageList,e);
		}finally {
			try {
                DBUtil.close(null, statement, null);                
			} catch (SQLException e) {
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));
				WebServiceLoggerUtil.logError("ESignServiceImpl", "updateESignatureDocuments", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
				throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
						APIConstant.FAILED, errorMessageList,e);
			}
		}
		return rowsUpdated;
	}
	
	private void callEsignClient(String envelopeId,EsigDownloadDocumentVO esigDownloadDocumentVO) throws Exception{
		
		EsigServiceClient client = new EsigServiceClient();
		User user = APIRequestContext.getApiRequestContext().getMtUser();
		
		HashMap info = EventProcessor.getWebServiceParameters("MIC - WS - ESIGNATURE - INTEGRATION", user);
		
		//EsigDownloadDocumentVO esigDownloadDocumentVO = new EsigDownloadDocumentVO();
		esigDownloadDocumentVO.setEnvelopId(envelopeId);
		esigDownloadDocumentVO.setEsignAPIURL((String)info.get("eSignatureEnvelopDownloadURL"));
		esigDownloadDocumentVO.setSlingUploadAPI((String)info.get("eSignatureSlingUploadURL"));
		esigDownloadDocumentVO.setSlingDownloadAPI((String)info.get("eSignatureSlingDownloadURL"));
		esigDownloadDocumentVO.setSlingPath((String)info.get("eSignatureSlingPath"));
		esigDownloadDocumentVO.setFileOverwriteFlag((String)info.get("eSignatureSlingUploadOverwrite"));
		
		info = EventProcessor.getWebServiceParameters("MIC - Next Generation - Advanced Document Generation", user);
		esigDownloadDocumentVO.setSlingUserName((String)info.get("serviceUsername"));
		esigDownloadDocumentVO.setSlingPassword((String)info.get("servicePassword"));
		
		client.downloadSignedDocFromSling(esigDownloadDocumentVO,user);
		
	}

	
	@Override
	public Response downloadEsignedDocuments(HttpServletRequest request,String policyId) throws Exception{
		boolean invalid=false;
		String errMsg = "";

		//Check document Package Id
		if(policyId==null || policyId.equalsIgnoreCase("")){
			invalid=true;
			errMsg+="policyId is a required parameter.";
		}

		if(invalid){
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
			WebServiceLoggerUtil.logInfo("ESignServiceImpl", "downloadEsignedDocuments", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}
		
		try {
			String envelopeId = getEnvelopeId(policyId);
			EsigDownloadDocumentVO esigDownloadDocumentVO = new EsigDownloadDocumentVO();					
			callEsignClient(envelopeId, esigDownloadDocumentVO);		
			
			String fileName=policyId+".zip";
			StreamingOutput fileStream =  new StreamingOutput()
			{
				public void write(java.io.OutputStream output) throws IOException
				{
					try{
						byte[] data = esigDownloadDocumentVO.getSlingZipbyteArray();
						output.write(data);
						output.flush();
					}catch (Exception e){
						String errMsgPackage ="Failed while downloading document package from host";
						List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsgPackage));
						String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
						WebServiceLoggerUtil.logError("DocumentPackageManagementServiceImpl", "downloadDocumentPackage", errMsgPackage, new Object[] { errMsgPackage }, e);
						throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
					}
				}
			};
			return Response
					.ok(fileStream, MediaType.APPLICATION_OCTET_STREAM)
					.header("content-disposition","attachment; filename = "+fileName+"")
					.build();
			
		} catch (Exception error) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList("Error downloading envelope.Please contact system administrator."));
			WebServiceLoggerUtil.logError("ESignServiceImpl", "downloadEsignedDocuments", error.getMessage(), 
					new Object[] {  "Error downloading envelope.Please contact system administrator. "+error.getMessage() }, error);
			
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), 
					APIConstant.FAILED,errorMessageList,error);
			
            
        }

	}	


	public String getEnvelopeId(String entityReference){
		String envelopeId = "";
		String query = "";
		Connection conn = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		HashMap<String, String> row = null;
		try {
			conn = APIRequestContext.getApiRequestContext().getConnection();
			
			query = "select WES_ID,WES_VENDOR_ENVELOPE_ID envelopeId from WS_ESIGNATURE_DOCUMENTS where rownum=1 and WES_ENTITY_REFERENCE = ? order by 1 desc ";

			statement = conn.prepareStatement(query);
			statement.setString(1, entityReference);
			WebServiceLoggerUtil.logInfo("ESignServiceImpl", "getEnvelopeId", query, new Object[] { query });
			rs = statement.executeQuery();
			
			while (rs.next()){
				envelopeId = rs.getString("envelopeId");            
	        }
			
		} catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));
			WebServiceLoggerUtil.logError("ESignServiceImpl", "getEnvelopeId", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
					APIConstant.FAILED, errorMessageList,e);
		}finally {
			try {
                DBUtil.close(rs, statement, null);                
			} catch (SQLException e) {
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));
				WebServiceLoggerUtil.logError("ESignServiceImpl", "getEnvelopeId", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
				throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
						APIConstant.FAILED, errorMessageList,e);
			}
		}
		return envelopeId;
	}

	
}
