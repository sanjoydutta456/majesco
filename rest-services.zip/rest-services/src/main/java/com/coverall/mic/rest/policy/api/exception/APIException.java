package com.coverall.mic.rest.policy.api.exception;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.coverall.mic.rest.policy.api.service.model.common.Message;

public class APIException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String errorCode;
	String errorMessage;
	Throwable underlyingException;
	List <Message> errorMessageList;
	String id;
	String moreInfo;
	
	
	public APIException(){
		
	}
	
	public APIException(String errorMessage, Throwable e){ 
		this.errorMessage = errorMessage;
		this.underlyingException = e;
	}
	
	public APIException(String errorCode, String errorMessage, List <Message> errorMessageList,Throwable e){
		this.errorMessage = errorMessage;
		this.errorCode = errorCode;
		this.underlyingException = e;
		this.errorMessageList = errorMessageList; 
	}
	
	public APIException(String errorCode, String errorMessage, List <Message> errorMessageList,Throwable e, String id){
		this.errorMessage = errorMessage;
		this.errorCode = errorCode;
		this.underlyingException = e;
		this.errorMessageList = errorMessageList;
		this.id = id;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Throwable getUnderlyingException() {
		return underlyingException;
	}

	public void setUnderlyingException(Throwable underlyingException) {
		this.underlyingException = underlyingException;
	}

	public List<Message> getErrorMessageList() {
		return errorMessageList;
	}

	public void setErrorMessageList(List<Message> errorMessageList) {
		this.errorMessageList = errorMessageList;
	}
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMoreInfo() {
		return moreInfo;
	}

	public void setMoreInfo(String moreInfo) {
		this.moreInfo = moreInfo;
	}
	
	

}
