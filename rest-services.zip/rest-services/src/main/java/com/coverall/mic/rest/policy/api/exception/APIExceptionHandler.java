package com.coverall.mic.rest.policy.api.exception;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import com.coverall.mic.rest.policy.api.service.model.common.Error;

@Provider
public class APIExceptionHandler implements ExceptionMapper<APIException>{
	public String CONTENT_TYPE_APPLICATION_JSON = "application/json";

	public APIExceptionHandler() {
		// TODO Auto-generated constructor stub
	}
	
	public Response toResponse(APIException exception){
	    Error errorObj = new Error();
	    com.coverall.mic.rest.policy.api.service.quotepolicy.impl.Error idErrorMsg = null;
	    errorObj.setStatus(exception.getErrorMessage());
	    errorObj.setStatuscode(exception.getErrorCode());
	    errorObj.setMessage(exception.getErrorMessageList());
	    errorObj.setMoreinfo(exception.getMoreInfo());
	    
		if (exception.getId() != null) {
			idErrorMsg = new  com.coverall.mic.rest.policy.api.service.quotepolicy.impl.Error();
			idErrorMsg.setStatus(exception.getErrorMessage());
			idErrorMsg.setStatuscode(exception.getErrorCode());
			idErrorMsg.setMessage(exception.getErrorMessageList());
			idErrorMsg.setId(exception.getId());
			idErrorMsg.setMoreinfo(exception.getMoreInfo());
			
		}
	    Response.Status rsStatus = null;
	    try	{
	    	//Try to set Status based on exception error code
	    	
	    	rsStatus = Response.Status.fromStatusCode(Integer.valueOf(exception.getErrorCode()));
	    }catch(Exception e){
	    	//By default Exception means 500 Internal Server Error
	    	rsStatus = Response.Status.INTERNAL_SERVER_ERROR;
	    }
	    if(idErrorMsg != null){
	    	return Response.status(rsStatus)
	    			.entity(idErrorMsg)
	    			.type(CONTENT_TYPE_APPLICATION_JSON)
	    			.build();
	    }
	    
    	return Response.status(rsStatus)
    			.entity(errorObj)
    			.type(CONTENT_TYPE_APPLICATION_JSON)
    			.build();
	    
	}
	
	
}
