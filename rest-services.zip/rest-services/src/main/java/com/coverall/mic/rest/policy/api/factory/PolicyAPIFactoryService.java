package com.coverall.mic.rest.policy.api.factory;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;


public interface PolicyAPIFactoryService {
	
	public Object getHOQuotePolicyFactoryServicePolicy( HttpServletRequest request);
	
	public Object getCAQuotePolicyFactoryServicePolicy( HttpServletRequest request);
	
	public Object getHOQuotePolicyFactoryServiceQuote( HttpServletRequest request);
	
	public Object getCAQuotePolicyFactoryServiceQuote( HttpServletRequest request);
	
	public Object documentPackageManagementQuotesFactory( HttpServletRequest request, String entityReference);
	
	public Object documentPackageManagementPolicyFactory( HttpServletRequest request, String entityReference);
	
	public Object unifiedSearchFactory( HttpServletRequest request);
	
	public Object getCustomerResourceFactory( HttpServletRequest request);
	
	public Object producerManagementFactory( HttpServletRequest request);
	
	public Object getAllProductsFactory( HttpServletRequest request);
	
	public Object getEndorsementTransactionFactory( HttpServletRequest request);
	
	public Object getRenewTransactionFactory( HttpServletRequest request);
	
	public Object underwiterTransactionFactory( HttpServletRequest request);
	
	public Object listAllQuotesFactory( HttpServletRequest request,
			String exactMatch,
            String policyNo,
            String product,            
            int pageSize,
            int pageNumber,
            String correlationid,
            String effectiveStartDateRange,
            String effectiveEndDateRange,
            String company,
            String agencyNumber,
            String agencyName,
            String marketManager,
            String insured,
            String underwriter,
            String status,
            String entityType);
	
	public Object getFormResourceFactory(String quoteId,  HttpServletRequest request, String entityType);
	
	public Object getQuotePolicyStatusResouceFactory(String quoteId,  HttpServletRequest request,String entityType);
	
	public Object getTransactionsFactory(String quoteId,  HttpServletRequest request, String entityType);
	
	public Object getCommunicationAttachmentsFactory(String quoteId,  HttpServletRequest request, String entityType);
	
	public Object processCommissionsFactory(String quoteId,  HttpServletRequest request, String entityType);
	
	public Object processUWRuleFactory(String quoteId,  HttpServletRequest request, String entityType);
	
	public Object processBillingAttributesFactory(String quoteId,  HttpServletRequest request, String entityType);
	
	public Object getSurchargeDetailsFactory(String quoteId,  HttpServletRequest request, String entityType);
	
	public Object bookPolicyBinderFactory(String policyId,  HttpServletRequest request, String entityType);
	
	public Object issueBinderFactory(String policyId,  HttpServletRequest request, String entityType);
	
	public Object getQuotePolicyFactoryServiceQuote(HttpServletRequest request, String productCode);
	
	public Object getQuotePolicyFactoryServicePolicy(HttpServletRequest request, String productCode);
	
	public Object getAttachedDocuments(String policyId,  HttpServletRequest request, String entityType);
	
	public Object getTemplatePlaceHolderServiceFactory(HttpServletRequest request,String reference,String referenceType,String templateName,String sourceSystemUserId);
	
	public Object getPolicyTemplateServiceFactory(HttpServletRequest request,String category,String referenceType,String reference);

	public Object geteSignServiceFactory( HttpServletRequest request);
	
	public Object getPaymentPlanInformation(String policyId,HttpServletRequest request,String entityType);
	
	public Object getReportData(HttpServletRequest request,String versionId,String apiEndpoint,int pageNumber,int pageSize,String countOnly);

	public Object getOOSEResource(HttpServletRequest request,  String policyId, String entityType);
	
	public Object getPolicyProductUsageDetails(HttpServletRequest request, String versionId);
	
	public Object getFormsAndDocumentInformation(HttpServletRequest request);

	public Object getPolicyHeartBeatDetails(HttpServletRequest request, String versionId);
	
	public Object getQuoteExtractDetails(HttpServletRequest request, String versionId,String entityReference, String policyAdditionalDetails);
	
	public Object getPolicyExtractDetails(HttpServletRequest request, String versionId,String entityReference, String policyAdditionalDetails);
	
	public Object getQuoteImportDetails(HttpServletRequest request, String versionId,String entityReference, String dontBook,String allowTransaction);
	
	public Object getPolicyImportDetails(HttpServletRequest request, String versionId,String entityReference, String dontBook,String allowTransaction);

	public Object getQuoteChangeSummary(HttpServletRequest request, String versionId,String entityReference);
	
	public Object getPolicyChangeSummary(HttpServletRequest request, String versionId,String entityReference);

	public Object getCommunicationNoteFactory(String quoteId,  HttpServletRequest request, String entityType);
	
	public Object performPurgeOperation(String quoteId,HttpServletRequest request, String entityType);
	
	public Object getInsuredResourceFactory( HttpServletRequest request);

}
