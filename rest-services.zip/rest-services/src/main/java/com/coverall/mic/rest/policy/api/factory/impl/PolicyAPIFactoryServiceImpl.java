package com.coverall.mic.rest.policy.api.factory.impl;

import javax.servlet.http.HttpServletRequest;

import com.coverall.mic.rest.distribution.producers.service.impl.ProducerManagementServiceImpl;
import com.coverall.mic.rest.document.mgmt.service.impl.DocumentPackageManagementServiceImpl;
import com.coverall.mic.rest.document.mgmt.service.impl.DocumentPackageManagementServiceImplV2;
import com.coverall.mic.rest.document.mgmt.service.impl.DocumentPackageManagementServiceImplV3;
import com.coverall.mic.rest.parties.underwriter.service.impl.UnderwriterManagementServiceImpl;
import com.coverall.mic.rest.policy.api.customer.service.impl.CustomerServiceImpl;
import com.coverall.mic.rest.policy.api.esign.service.impl.ESignServiceImpl;
import com.coverall.mic.rest.policy.api.factory.PolicyAPIFactoryService;
import com.coverall.mic.rest.policy.api.forms.service.impl.FormsServiceImpl;
import com.coverall.mic.rest.policy.api.forms.service.impl.FormsServiceImplVersion3;
import com.coverall.mic.rest.policy.api.insured.service.impl.InsuredServiceImpl;
import com.coverall.mic.rest.policy.api.service.chatbot.impl.ChatbotApiServiceImpl;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.impl.FormDocumentInfoServiceImpl;
import com.coverall.mic.rest.policy.api.service.impl.IssueBinderServiceImpl;
import com.coverall.mic.rest.policy.api.service.impl.PolicyAPIServiceImpl;
import com.coverall.mic.rest.policy.api.service.impl.PolicyBinderBookingServiceImpl;
import com.coverall.mic.rest.policy.api.service.impl.PolicyHeartBeatImpl;
import com.coverall.mic.rest.policy.api.service.impl.PolicyProductUsageImpl;
import com.coverall.mic.rest.policy.api.service.impl.PurgeServiceImpl;
import com.coverall.mic.rest.policy.api.service.impl.QuotePolicyAttachmentServiceImpl;
import com.coverall.mic.rest.policy.api.service.impl.QuotePolicyBillingAttributeServiceImpl;
import com.coverall.mic.rest.policy.api.service.impl.QuotePolicyBillingAttributeServiceImplV2;
import com.coverall.mic.rest.policy.api.service.impl.QuotePolicyChangeSummaryServiceImpl;
import com.coverall.mic.rest.policy.api.service.impl.QuotePolicyCommissionServiceImpl;
import com.coverall.mic.rest.policy.api.service.impl.QuotePolicyDocumentListingServiceImpl;
import com.coverall.mic.rest.policy.api.service.impl.QuotePolicyExtractImportServiceImpl;
import com.coverall.mic.rest.policy.api.service.impl.QuotePolicyNoteServiceImpl;
import com.coverall.mic.rest.policy.api.service.impl.QuotePolicyPaymentPlanInformationImpl;
import com.coverall.mic.rest.policy.api.service.impl.QuotePolicySearchServiceImpl;
import com.coverall.mic.rest.policy.api.service.impl.QuotePolicyStatusServiceImpl;
import com.coverall.mic.rest.policy.api.service.impl.QuotePolicySurchargeServiceImpl;
import com.coverall.mic.rest.policy.api.service.impl.QuotePolicyTransactionServiceImpl;
import com.coverall.mic.rest.policy.api.service.impl.QuotePolicyUWRulesServiceImpl;
import com.coverall.mic.rest.policy.api.service.losscontrol.impl.LossControlServiceImpl;
import com.coverall.mic.rest.policy.api.service.oose.impl.OOSEServiceImpl;
import com.coverall.mic.rest.policy.api.service.quotepolicy.impl.QuotePolicyServiceImpl;
import com.coverall.mic.rest.policy.api.service.reports.impl.ReportAPIServiceImpl;
import com.coverall.mic.rest.policy.api.service.unifiedemail.impl.PolicyTemplateServiceImpl;
import com.coverall.mic.rest.policy.api.service.unifiedemail.impl.TemplatePlaceHolderServiceImpl;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.impl.UnifiedSearchServiceImpl;
import com.coverall.mic.rest.policy.api.service.version2.attachment.service.impl.QuotePolicyAttachmentServiceImplVersion2;
import com.coverall.mic.rest.policy.api.service.version2.commissions.service.impl.QuotePolicyCommissionServiceImplVersion2;
import com.coverall.mic.rest.policy.api.service.version2.forms.service.impl.FormsServiceImplVersion2;
/*import com.coverall.mic.rest.policy.api.service.version3.forms.service.impl.FormsServiceImplVersion3;*/


public class PolicyAPIFactoryServiceImpl implements PolicyAPIFactoryService {
	
	@Override
	public Object getHOQuotePolicyFactoryServicePolicy(HttpServletRequest request) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new QuotePolicyServiceImpl("HO",PolicyAPIServiceImpl.ENTITY_TYPE_POLICY);
		}else{
			return new QuotePolicyServiceImpl("HO",PolicyAPIServiceImpl.ENTITY_TYPE_POLICY);
		}
	}

	@Override
	public Object getCAQuotePolicyFactoryServicePolicy(HttpServletRequest request) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new QuotePolicyServiceImpl("CA",PolicyAPIServiceImpl.ENTITY_TYPE_POLICY);
		}else{
			return new QuotePolicyServiceImpl("CA",PolicyAPIServiceImpl.ENTITY_TYPE_POLICY);
		}
	}
	
	@Override
	public Object getHOQuotePolicyFactoryServiceQuote(HttpServletRequest request) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new QuotePolicyServiceImpl("HO",PolicyAPIServiceImpl.ENTITY_TYPE_QUOTE);
		}else{
			return new QuotePolicyServiceImpl("HO",PolicyAPIServiceImpl.ENTITY_TYPE_QUOTE);
		}
	}

	@Override
	public Object getCAQuotePolicyFactoryServiceQuote(HttpServletRequest request) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new QuotePolicyServiceImpl("CA",PolicyAPIServiceImpl.ENTITY_TYPE_QUOTE);
		}else{
			return new QuotePolicyServiceImpl("CA",PolicyAPIServiceImpl.ENTITY_TYPE_QUOTE);
		}
	}
	
	@Override
	public Object documentPackageManagementQuotesFactory(
			HttpServletRequest request, String entityReference) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new DocumentPackageManagementServiceImpl("QUOTE",request, entityReference);
		}else if(providedInputVersion.equals("2")){
			return new DocumentPackageManagementServiceImplV2("QUOTE",request, entityReference);
		}else if(providedInputVersion.equals("3")){
			return new DocumentPackageManagementServiceImplV3("QUOTE",request, entityReference);
		}
		else{
			return new DocumentPackageManagementServiceImpl("QUOTE",request, entityReference);
		}
		
	}

	@Override
	public Object documentPackageManagementPolicyFactory(
			HttpServletRequest request, String entityReference) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new DocumentPackageManagementServiceImpl("POLICY",request, entityReference);
		}else if(providedInputVersion.equals("2")){
			return new DocumentPackageManagementServiceImplV2("POLICY",request, entityReference);
		}else if(providedInputVersion.equals("3")){
			return new DocumentPackageManagementServiceImplV3("POLICY",request, entityReference);
		}
		else{
			return new DocumentPackageManagementServiceImpl("POLICY",request, entityReference);
		}
		
	}

	@Override
	public Object unifiedSearchFactory(HttpServletRequest request) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new UnifiedSearchServiceImpl();
		}else{
			return new UnifiedSearchServiceImpl();
		}
	}

	@Override
	public Object getCustomerResourceFactory(HttpServletRequest request) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new CustomerServiceImpl();
		}else{
			return new CustomerServiceImpl();
		}
	}

	@Override
	public Object producerManagementFactory(HttpServletRequest request) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new ProducerManagementServiceImpl();
		}else{
			return new ProducerManagementServiceImpl();
		}
		
	}

	@Override
	public Object getAllProductsFactory(HttpServletRequest request) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new ChatbotApiServiceImpl();
		}else{
			return new ChatbotApiServiceImpl();
		}
	}

	@Override
	public Object getEndorsementTransactionFactory(HttpServletRequest request) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new ChatbotApiServiceImpl();
		}else{
			return new ChatbotApiServiceImpl();
		}
	}

	@Override
	public Object getRenewTransactionFactory(HttpServletRequest request) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new ChatbotApiServiceImpl();
		}else{
			return new ChatbotApiServiceImpl();
		}
	}

	@Override
	public Object underwiterTransactionFactory(HttpServletRequest request) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new UnderwriterManagementServiceImpl();
		}else{
			return new UnderwriterManagementServiceImpl();
		}
	}

	@Override
	public Object listAllQuotesFactory(HttpServletRequest request,
			String exactMatch, String policyNo, String product, int pageSize,
			int pageNumber, String correlationid,
			String effectiveStartDateRange, String effectiveEndDateRange,
			String company, String agencyNumber, String agencyName,
			String marketManager, String insured, String underwriter,
			String status, String entityType) {
		
		String providedInputVersion=getVersionFromRequest(request);
		
		if(providedInputVersion.equals("1")){
			return new QuotePolicySearchServiceImpl(request,exactMatch,policyNo, product,entityType, pageSize,pageNumber,
					correlationid, effectiveStartDateRange,effectiveEndDateRange,company,agencyNumber,
					agencyName, marketManager, insured,underwriter, status);
		}else{
			return new QuotePolicySearchServiceImpl(request,exactMatch,policyNo, product,entityType, pageSize,pageNumber,
					correlationid, effectiveStartDateRange,effectiveEndDateRange,company,agencyNumber,
					agencyName, marketManager, insured,underwriter, status);
		}
	}

	@Override
	public Object getFormResourceFactory(String quoteId,
			HttpServletRequest request, String entityType) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new FormsServiceImpl(quoteId,entityType,request);
		}else if(providedInputVersion.equals("2")){
			return new FormsServiceImplVersion2(quoteId,entityType,request);
		}else if(providedInputVersion.equals("3")){
			return new FormsServiceImplVersion3(quoteId,entityType,request);
		}else{
			return new FormsServiceImpl(quoteId,entityType,request);
		}
		
	}

	@Override
	public Object getQuotePolicyStatusResouceFactory(String quoteId,
			HttpServletRequest request, String entityType) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new QuotePolicyStatusServiceImpl(quoteId, entityType);
		}else{
			return new QuotePolicyStatusServiceImpl(quoteId, entityType);
		}
	}

	@Override
	public Object getTransactionsFactory(String quoteId,
			HttpServletRequest request, String entityType) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new QuotePolicyTransactionServiceImpl(quoteId, entityType,request);
		}else{
			return new QuotePolicyTransactionServiceImpl(quoteId, entityType,request);
		}
	}

	@Override
	public Object getCommunicationAttachmentsFactory(String quoteId,
			HttpServletRequest request, String entityType) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new QuotePolicyAttachmentServiceImpl(quoteId, entityType, request);
		}else if(providedInputVersion.equals("2")){
			return new QuotePolicyAttachmentServiceImplVersion2(quoteId,entityType,request);
		}else{
			return new QuotePolicyAttachmentServiceImpl(quoteId, entityType, request);
		}
	}

	@Override
	public Object processCommissionsFactory(String quoteId,
			HttpServletRequest request, String entityType) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new QuotePolicyCommissionServiceImpl(quoteId, entityType, request);
		}else if(providedInputVersion.equals("2")){
			return new QuotePolicyCommissionServiceImplVersion2(quoteId,entityType,request);
		}else{
			return new QuotePolicyCommissionServiceImpl(quoteId, entityType, request);
		}
	}

	@Override
	public Object processUWRuleFactory(String quoteId,
			HttpServletRequest request, String entityType) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new QuotePolicyUWRulesServiceImpl(quoteId, entityType, request);
		}else{
			return new QuotePolicyUWRulesServiceImpl(quoteId, entityType, request);
		}
	}

	@Override
	public Object processBillingAttributesFactory(String quoteId,
			HttpServletRequest request, String entityType) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new QuotePolicyBillingAttributeServiceImpl(quoteId,entityType,request);
		}
		else if(providedInputVersion.equals("2")){
			return new QuotePolicyBillingAttributeServiceImplV2(quoteId,entityType,request);
		}
		else{
			return new QuotePolicyBillingAttributeServiceImpl(quoteId,entityType,request);
		}
	}

	@Override
	public Object getSurchargeDetailsFactory(String quoteId,
			HttpServletRequest request, String entityType) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new QuotePolicySurchargeServiceImpl(quoteId, entityType,request);
		}else{
			return new QuotePolicySurchargeServiceImpl(quoteId, entityType,request);
		}
	}

	@Override
	public Object bookPolicyBinderFactory(String policyId,
			HttpServletRequest request, String entityType) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new PolicyBinderBookingServiceImpl(request,entityType,policyId);
		}else{
			return new PolicyBinderBookingServiceImpl(request,entityType,policyId);
		}
	}

	@Override
	public Object issueBinderFactory(String policyId, HttpServletRequest request, String entityType) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new IssueBinderServiceImpl(request,entityType,policyId);
		}else{
			return new IssueBinderServiceImpl(request,entityType,policyId);
		}
	}
	
	@Override
	public Object getAttachedDocuments(String policyId, HttpServletRequest request, String entityType) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new QuotePolicyDocumentListingServiceImpl(request,entityType,policyId);
		}else{
			return new QuotePolicyDocumentListingServiceImpl(request,entityType,policyId);
		}
	}
	
	public static String getVersionFromRequest(HttpServletRequest request){
		String providedInputVersion=(String)request.getAttribute(APIConstant.VERSION_REQUEST_ATTRIBUTE);
		providedInputVersion=providedInputVersion==null?"0":providedInputVersion;
		
		return providedInputVersion;
	}
	
	
	@Override
	public Object getQuotePolicyFactoryServicePolicy(HttpServletRequest request, String productCode) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new QuotePolicyServiceImpl(productCode,PolicyAPIServiceImpl.ENTITY_TYPE_POLICY);
		}else{
			return new QuotePolicyServiceImpl(productCode,PolicyAPIServiceImpl.ENTITY_TYPE_POLICY);
		}
	}
	
	
	@Override
	public Object getQuotePolicyFactoryServiceQuote(HttpServletRequest request, String productCode) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new QuotePolicyServiceImpl(productCode,PolicyAPIServiceImpl.ENTITY_TYPE_QUOTE);
		}else{
			return new QuotePolicyServiceImpl(productCode,PolicyAPIServiceImpl.ENTITY_TYPE_QUOTE);
		}
	}
	
	@Override
	public Object geteSignServiceFactory(HttpServletRequest request) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new ESignServiceImpl();
		}else{
			return new ESignServiceImpl();
		}
	}
	
	@Override
	public Object getPaymentPlanInformation(String policyId,
			HttpServletRequest request, String entityType) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new QuotePolicyPaymentPlanInformationImpl(request,entityType,policyId);
		}else{
			return new QuotePolicyPaymentPlanInformationImpl(request,entityType,policyId);
		}
	}

	@Override
	public Object getTemplatePlaceHolderServiceFactory(HttpServletRequest request,String reference,String referenceType,String templateName,String sourceSystemUserId) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new TemplatePlaceHolderServiceImpl(request,reference,referenceType,templateName,sourceSystemUserId);
		}else{
			return new TemplatePlaceHolderServiceImpl(request,reference,referenceType,templateName,sourceSystemUserId);
		}
	}
	
	@Override
	public Object getPolicyTemplateServiceFactory(HttpServletRequest request,String category,String referenceType,String reference) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new PolicyTemplateServiceImpl(request,category,referenceType,reference);
		}else{
			return new PolicyTemplateServiceImpl(request,category,referenceType,reference);
		}
	}

	@Override
	public Object getReportData(HttpServletRequest request, String versionId,String apiEndpoint,int pageNumber,int pageSize,String countOnly) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new ReportAPIServiceImpl(apiEndpoint, request, pageNumber, pageSize,countOnly);
		}else{
			return new ReportAPIServiceImpl(apiEndpoint, request, pageNumber, pageSize,countOnly);
		}
		
		
	}

	@Override
	public Object getOOSEResource(HttpServletRequest request, String policyId, String entityType) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new OOSEServiceImpl(request,entityType,policyId);
		}else{
			return new OOSEServiceImpl(request,entityType,policyId);
		}
	}
	
	@Override
	public Object getPolicyProductUsageDetails(HttpServletRequest request, String versionId) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new PolicyProductUsageImpl(request);
		}else{
			return new PolicyProductUsageImpl(request);
		}
	}
	
	@Override
	public Object getPolicyHeartBeatDetails(HttpServletRequest request, String versionId) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new PolicyHeartBeatImpl(request);
		}else{
			return new PolicyHeartBeatImpl(request);
		}
	}
	
	@Override
	public Object getQuoteExtractDetails(HttpServletRequest request, String versionId,String entityReference, String policyAdditionalDetails) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new QuotePolicyExtractImportServiceImpl(request,entityReference,policyAdditionalDetails);
		}else{
			return new QuotePolicyExtractImportServiceImpl(request,entityReference,policyAdditionalDetails);
		}
	}
	
	@Override
	public Object getPolicyExtractDetails(HttpServletRequest request, String versionId,String entityReference, String policyAdditionalDetails) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new QuotePolicyExtractImportServiceImpl(request,entityReference,policyAdditionalDetails);
		}else{
			return new QuotePolicyExtractImportServiceImpl(request,entityReference,policyAdditionalDetails);
		}
	}
	
	@Override
	public Object getQuoteImportDetails(HttpServletRequest request, String versionId,String entityReference, String dontBook,String allowTransaction) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new QuotePolicyExtractImportServiceImpl(request,entityReference,dontBook,allowTransaction);
		}else{
			return new QuotePolicyExtractImportServiceImpl(request,entityReference,dontBook,allowTransaction);
		}
	}
	
	@Override
	public Object getPolicyImportDetails(HttpServletRequest request, String versionId,String entityReference, String dontBook,String allowTransaction) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new QuotePolicyExtractImportServiceImpl(request,entityReference,dontBook,allowTransaction);
		}else{
			return new QuotePolicyExtractImportServiceImpl(request,entityReference,dontBook,allowTransaction);
		}
	}
	
	@Override
	public Object getQuoteChangeSummary(HttpServletRequest request, String versionId,String entityReference) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new QuotePolicyChangeSummaryServiceImpl(request,entityReference,PolicyAPIServiceImpl.ENTITY_TYPE_QUOTE);
		}else{
			return new QuotePolicyChangeSummaryServiceImpl(request,entityReference,PolicyAPIServiceImpl.ENTITY_TYPE_QUOTE);
		}
	}
	
	@Override
	public Object getPolicyChangeSummary(HttpServletRequest request, String versionId,String entityReference) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new QuotePolicyChangeSummaryServiceImpl(request,entityReference,PolicyAPIServiceImpl.ENTITY_TYPE_POLICY);
		}else{
			return new QuotePolicyChangeSummaryServiceImpl(request,entityReference,PolicyAPIServiceImpl.ENTITY_TYPE_POLICY);
		}
	}
	
	@Override
	public Object getFormsAndDocumentInformation(HttpServletRequest request) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new FormDocumentInfoServiceImpl(request);
		}else{
			return new FormDocumentInfoServiceImpl(request);
		}
	}

	@Override
	public Object getCommunicationNoteFactory(String quoteId,
			HttpServletRequest request, String entityType) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new QuotePolicyNoteServiceImpl(quoteId, entityType, request);
		}else{
			return new QuotePolicyNoteServiceImpl(quoteId, entityType, request);
		}
	}
	
	@Override
	public Object performPurgeOperation(String quoteId,HttpServletRequest request, String entityType) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new PurgeServiceImpl(entityType,quoteId, request);
		}else{
			return new PurgeServiceImpl(entityType,quoteId, request);
		}
		
	}
	
	@Override
	public Object getInsuredResourceFactory(HttpServletRequest request) {
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new InsuredServiceImpl();
		}else{
			return new InsuredServiceImpl();
		}
	}

	public Object lossControlFactory(HttpServletRequest request)
	{
		String providedInputVersion=getVersionFromRequest(request);
		if(providedInputVersion.equals("1")){
			return new LossControlServiceImpl();
		}else{
			return new LossControlServiceImpl();
		}
	}
	
}
