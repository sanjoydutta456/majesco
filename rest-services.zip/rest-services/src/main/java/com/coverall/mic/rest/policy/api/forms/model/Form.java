package com.coverall.mic.rest.policy.api.forms.model;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class Form {
	
	protected long formId ;
	protected String sourceSystemUserId;
	protected String sourceSystemCode;
	protected long  sourceSystemRequestNo;
	protected String  formName;
	protected String formDescription;
	protected String occurrence;
	protected String revision;
	protected String coveragePart;
	protected String coveragePartReference;
	protected String status;
	protected String modifiedRevision;
	protected String editionDate;
	protected String customFormNumber;
	protected String customTitle;
	protected String customEditionDate;
	protected String userOverride;
	protected String isManualUpload;
	protected String isAutoAttach;
	
	
	public enum  formVariableIsPresent {
		N,Y
	}
	protected formVariableIsPresent formVariablePresent = formVariableIsPresent.N;
	protected FormVariables formVariables;
	
	//POLT-16056, POLT-16060
	protected String isMultiAttach;
	protected int noOfCopies;
	
	// POLT-16569
	protected String qualifyingLOBs;
	protected String isInterline;
	
	public formVariableIsPresent getFormVariablePresent() {
		return formVariablePresent;
	}
	public void setFormVariablePresent(formVariableIsPresent isVariablePresent) {
		this.formVariablePresent = isVariablePresent;
	}
	public long getFormId() {
		return formId;
	}
	public void setFormId(long formId) {
		this.formId = formId;
	}
	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}

	public void setSourceSystemUserId(String sourceSystemUserId) {
		this.sourceSystemUserId = sourceSystemUserId;
	}
	public String getSourceSystemCode() {
		return sourceSystemCode;
	}
	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}
	public long getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}
	public void setSourceSystemRequestNo(long sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}
	public String getFormName() {
		return formName;
	}
	public void setFormName(String formName) {
		this.formName = formName;
	}
	public String getFormDescription() {
		return formDescription;
	}
	public void setFormDescription(String formDescription) {
		this.formDescription = formDescription;
	}
	public String getRevision() {
		return revision;
	}
	public void setRevision(String revision) {
		this.revision = revision;
	}
	public String getCoveragePart() {
		return coveragePart;
	}
	public void setCoveragePart(String coveragePart) {
		this.coveragePart = coveragePart;
	}
	public String getCoveragePartReference() {
		return coveragePartReference;
	}
	public void setCoveragePartReference(String coveragePartReference) {
		this.coveragePartReference = coveragePartReference;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getOccurrence() {
		return occurrence;
	}
	public void setOccurrence(String occurance) {
		this.occurrence = occurance;
	}
	public String getModifiedRevision() {
		return modifiedRevision;
	}
	public void setModifiedRevision(String modifiedRevision) {
		this.modifiedRevision = modifiedRevision;
	}
	public String getEditionDate() {
		return editionDate;
	}
	public void setEditionDate(String editionDate) {
		this.editionDate = editionDate;
	}
	public FormVariables getFormVariables() {
		return formVariables;
	}
	public void setFormVariables(FormVariables formVariables) {
		this.formVariables = formVariables;
	}
	public String getCustomFormNumber() {
		return customFormNumber;
	}
	public void setCustomFormNumber(String customFormNumber) {
		this.customFormNumber = customFormNumber;
	}
	public String getCustomTitle() {
		return customTitle;
	}
	public void setCustomTitle(String customTitle) {
		this.customTitle = customTitle;
	}
	public String getUserOverride() {
		return userOverride;
	}
	public void setUserOverride(String userOverride) {
		this.userOverride = userOverride;
	}
	public String getCustomEditionDate() {
		return customEditionDate;
	}
	public void setCustomEditionDate(String customEditionDate) {
		this.customEditionDate = customEditionDate;
	}
	public String getIsManualUpload() {
		return isManualUpload;
	}
	public void setIsManualUpload(String isManualUpload) {
		this.isManualUpload = isManualUpload;
	}
	
	// POLT-16569
	/*@Override
	public String toString() {
		return "Form [formId=" + formId + ", sourceSystemUserId="
				+ sourceSystemUserId + ", sourceSystemCode=" + sourceSystemCode
				+ ", sourceSystemRequestNo=" + sourceSystemRequestNo
				+ ", formName=" + formName + ", formDescription="
				+ formDescription + ", revision=" + revision
				+ ", coveragePart=" + coveragePart + ", coveragePartReference="
				+ coveragePartReference + ", status=" + status
				+ ", modifiedRevision=" + modifiedRevision + ", editionDate="
				+ editionDate + ", customFormNumber=" + customFormNumber
				+ ", customTitle=" + customTitle + ", customEditionDate="
				+ customEditionDate + ", userOverride=" + userOverride
				+ ", isManualUpload=" + isManualUpload + ", isVariablePresent="
				+ formVariablePresent + ", formVariables=" + formVariables + "]";
	}*/	

	@Override
	public String toString() {
		return "Form [formId=" + formId + ", sourceSystemUserId=" + sourceSystemUserId + ", sourceSystemCode="
				+ sourceSystemCode + ", sourceSystemRequestNo=" + sourceSystemRequestNo + ", formName=" + formName
				+ ", formDescription=" + formDescription + ", occurrence=" + occurrence + ", revision=" + revision
				+ ", coveragePart=" + coveragePart + ", coveragePartReference=" + coveragePartReference + ", status="
				+ status + ", modifiedRevision=" + modifiedRevision + ", editionDate=" + editionDate
				+ ", customFormNumber=" + customFormNumber + ", customTitle=" + customTitle + ", customEditionDate="
				+ customEditionDate + ", userOverride=" + userOverride + ", isManualUpload=" + isManualUpload
				+ ", formVariablePresent=" + formVariablePresent + ", formVariables=" + formVariables
				+ ", isMultiAttach=" + isMultiAttach + ", noOfCopies=" + noOfCopies + ", qualifyingLOBs="
				+ qualifyingLOBs + ", isInterline=" + isInterline + "]";
	}
	
	//POLT-16056, POLT-16060
	public String getIsMultiAttach() {
		return isMultiAttach;
	}
	public void setIsMultiAttach(String isMultiAttach) {
		this.isMultiAttach = isMultiAttach;
	}
	public int getNoOfCopies() {
		return noOfCopies;
	}
	public void setNoOfCopies(int noOfCopies) {
		this.noOfCopies = noOfCopies;
	}
	
	// POLT-16569
	public String getQualifyingLOBs() {
		return qualifyingLOBs;
	}
	public void setQualifyingLOBs(String qualifyingLOBs) {
		this.qualifyingLOBs = qualifyingLOBs;
	}
	public String getIsInterline() {
		return isInterline;
	}

	public void setIsInterline(String isInterline) {
		this.isInterline = isInterline;
	}
	public String getIsAutoAttach() {
		return isAutoAttach;
	}
	public void setIsAutoAttach(String isAutoAttach) {
		this.isAutoAttach = isAutoAttach;
	}
	
}