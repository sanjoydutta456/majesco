package com.coverall.mic.rest.policy.api.forms.model;

public class FormDeleteObj {
	
	String formId;
	String formName;
	String entityReference;
	String formCoveragePartReference;
	String formOccurance;
	String formModifiedReference;
	String formModifiedCoverage;
	public String getFormId() {
		return formId;
	}
	public void setFormId(String formId) {
		this.formId = formId;
	}
	public String getFormName() {
		return formName;
	}
	public void setFormName(String formName) {
		this.formName = formName;
	}
	public String getEntityReference() {
		return entityReference;
	}
	public void setEntityReference(String entityReference) {
		this.entityReference = entityReference;
	}
	public String getFormCoveragePartReference() {
		return formCoveragePartReference;
	}
	public void setFormCoveragePartReference(String formCoveragePartReference) {
		this.formCoveragePartReference = formCoveragePartReference;
	}
	public String getFormOccurance() {
		return formOccurance;
	}
	public void setFormOccurance(String formOccurance) {
		this.formOccurance = formOccurance;
	}
	public String getFormModifiedReference() {
		return formModifiedReference;
	}
	public void setFormModifiedReference(String formModifiedReference) {
		this.formModifiedReference = formModifiedReference;
	}
	public String getFormModifiedCoverage() {
		return formModifiedCoverage;
	}
	public void setFormModifiedCoverage(String formModifiedCoverage) {
		this.formModifiedCoverage = formModifiedCoverage;
	}
	
}
