package com.coverall.mic.rest.policy.api.forms.model;

import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@XmlRootElement
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class FormVariable {
	protected String sourceSystemUserId;
	protected String sourceSystemCode;
	protected long sourceSystemRequestNo;
	protected String variableName;
	protected String variableValue;
	protected String variableOccurrence;
	protected String variableNameDesc;

	public enum requiredValues {N,Y}
	 
	protected  requiredValues required = requiredValues.N ;
	
	
	public requiredValues getRequired() {
		return required;
	}
	public void setRequired(requiredValues isRequired) {
		this.required = isRequired;
	}
	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}
	public void setSourceSystemUserId(String sourceSystemUserId) {
		this.sourceSystemUserId = sourceSystemUserId;
	}
	public String getSourceSystemCode() {
		return sourceSystemCode;
	}
	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}
	public long getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}
	public void setSourceSystemRequestNo(long sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}
	public String getVariableName() {
		return variableName;
	}
	public void setVariableName(String variableName) {
		this.variableName = variableName;
	}
	public String getVariableNameDesc() {
		return variableNameDesc;
	}
	public void setVariableNameDesc(String variableNameDesc) {
		this.variableNameDesc = variableNameDesc;
	}
	public String getVariableValue() {
		return variableValue;
	}
	public void setVariableValue(String variableValue) {
		this.variableValue = variableValue;
	}
	public String getVariableOccurrence() {
		return variableOccurrence;
	}
	public void setVariableOccurrence(String variableOccurrence) {
		this.variableOccurrence = variableOccurrence;
	}
	@Override
	public String toString() {
		return "FormVariable [sourceSystemUserId=" + sourceSystemUserId + ", sourceSystemCode=" + sourceSystemCode
				+ ", sourceSystemRequestNo=" + sourceSystemRequestNo + ", variableName=" + variableName + ", variableNameDesc=" + variableNameDesc
				+ ", variableValue=" + variableValue + ", variableOccurrence=" + variableOccurrence + ", isRequired="
				+ required + "]";
	};
	
	
	
	

}
