package com.coverall.mic.rest.policy.api.forms.model;

import java.util.List;
import java.util.ArrayList;

import javax.xml.bind.annotation.XmlRootElement;

import com.google.gson.Gson;
@XmlRootElement(name="formVariables")
public class FormVariables {

	private List <FormVariable> formVariables =  new ArrayList <FormVariable>() ;

	public List<FormVariable> getFormVariables() {
		return formVariables;
	}

	public void setFormVariables(List<FormVariable> formVariableList) { 
		this.formVariables = formVariableList; 
	}
	
	public FormVariables() {
		super();
	}

	public FormVariables(String json) {
		super();
		Gson gson = new Gson();
		FormVariables request = gson.fromJson(json, FormVariables.class);
        this.formVariables = request.formVariables;
	}

	static FormVariables valueOf(String json) {
		Gson gson = new Gson();
        return gson.fromJson(json, FormVariables.class);
	}
}
