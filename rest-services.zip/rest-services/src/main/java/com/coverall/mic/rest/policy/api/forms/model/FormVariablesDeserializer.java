package com.coverall.mic.rest.policy.api.forms.model;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

public class FormVariablesDeserializer {

	public static FormVariable convertJsonToObject(String json, Class<FormVariables> type) {
		GsonBuilder gsonBuilder = new GsonBuilder();
		JsonDeserializer<FormVariable> deserializer = new FormVariableDeserializer();
		gsonBuilder.registerTypeAdapter(FormVariable.class, deserializer);
		Gson customGson = gsonBuilder.create();
		return customGson.fromJson(json, FormVariable.class);
	}

	
	
	
	private static class FormVariableDeserializer implements JsonDeserializer<FormVariable> {

		@Override
		public FormVariable deserialize(JsonElement json, Type type, JsonDeserializationContext context)
				throws JsonParseException {
			FormVariable response = new FormVariable();
			JsonObject responseJsonObject = (JsonObject) json; 
			Gson gson = new Gson();
			JsonObject jsonObject = responseJsonObject.getAsJsonObject("docGenResponseObj");
			JsonElement element = jsonObject.get("processedDocuments");
			JsonElement element2 = jsonObject.get("numberOfProcessedDocuments");
			
			List<FormVariable> list;
			if (element instanceof JsonArray) {
				list = new ArrayList<FormVariable>(((JsonArray)element).size());
				JsonArray jsonArray = jsonObject.getAsJsonArray("processedDocuments");
				Iterator<JsonElement> processedDocsIter = jsonArray.iterator();
				while (processedDocsIter.hasNext()) {
					JsonElement elem = processedDocsIter.next();
					FormVariable res = gson.fromJson(elem, FormVariable.class);
					list.add(res);
					//response.setProcessedDocuments(list);
				}
			} else if (element instanceof JsonElement) {
				FormVariable res = gson.fromJson((JsonElement) element, FormVariable.class);
				list = new ArrayList<FormVariable>();
				list.add(res);
				//response.setProcessedDocuments(list);
			}
			
			return response;
		}

		
		
	}
}
