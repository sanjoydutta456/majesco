package com.coverall.mic.rest.policy.api.forms.model;

import java.util.ArrayList;
import java.util.List;

public class Forms {

	public List<Form> forms = new ArrayList<Form>();;

	public List<Form> getForms() {
		return forms;
	}

	public void setForms(List<Form> formList) {
		this.forms = formList;
	}

}
