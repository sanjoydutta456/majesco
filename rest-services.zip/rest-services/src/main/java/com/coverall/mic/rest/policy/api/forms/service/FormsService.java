package com.coverall.mic.rest.policy.api.forms.service;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.coverall.mic.rest.policy.api.forms.model.FormVariables;


@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON , MediaType.MULTIPART_FORM_DATA })
@Produces({ MediaType.APPLICATION_JSON , MediaType.MULTIPART_FORM_DATA })
public interface FormsService {
	
	String SOURCE_SYSTEM_CODE="MIC";
	String RESOURCE_TYPE="Forms";

	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({ 
		MediaType.APPLICATION_JSON})
	@Path("attached-forms")
	@GET
	public Object getAttachedForms();
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({ 
		MediaType.APPLICATION_JSON})
	@Path("{formId}/form-variables")
	@GET
	public Object getAttachedFormsVariables(@PathParam("formId") String formId);
	
	//{formId}/form-variables
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({ 
		MediaType.APPLICATION_JSON})
	@Path("{formId}/form-variables")
	@PUT
	public Object updateFormVariables(@PathParam("formId") String formId,
			@Context HttpServletRequest request);
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({ 
		MediaType.APPLICATION_JSON})
	@Path("qualifying-forms")
	@GET
	public Object qualifyingForms(@QueryParam("showAll") String showAll,
			@QueryParam("manuscript") String manuscript);
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_OCTET_STREAM})
	@Path("{formId}/preview")
	@POST
	public Response previewForm(@PathParam("formId") String formId) throws Exception;
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({ 
		MediaType.APPLICATION_JSON})
	@POST
	public Object addFormToQuotePolicy();
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({ 
		MediaType.APPLICATION_JSON})
	@DELETE
	public Object deleteFormFromQuotePolicy(@QueryParam(value = "formIds[]") String[] formIds) throws Exception;
	
	@GET
	@Path("ping")
	public String ping();
	
	//POLT-16056, POLT-16060
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_JSON})
	@Path("copy")
	@POST
	public Object copyFormToQuotePolicy();
}