package com.coverall.mic.rest.policy.api.forms.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.StreamingOutput;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.cxf.helpers.IOUtils;
import org.codehaus.jackson.map.ObjectMapper;

import com.coverall.exceptions.DOMCreationException;
import com.coverall.imaging.dao.DocumentTemplate;
import com.coverall.imaging.docgenclient.DocgenServiceFacade;
import com.coverall.imaging.docgenclient.DocgenServiceFacadeImpl;
import com.coverall.imaging.servlet.FileCabinetDownloadServlet;
import com.coverall.imaging.util.ImagingUtil;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.forms.model.Form;
import com.coverall.mic.rest.policy.api.forms.model.FormDeleteObj;
import com.coverall.mic.rest.policy.api.forms.model.FormVariable;
import com.coverall.mic.rest.policy.api.forms.model.FormVariables;
import com.coverall.mic.rest.policy.api.forms.model.Forms;
import com.coverall.mic.rest.policy.api.forms.service.FormsService;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.forms.dao.FormVariableVo;
import com.coverall.mic.rest.policy.api.service.forms.util.FormUtil;
import com.coverall.mic.rest.policy.api.service.model.ConfirmationMessage;
import com.coverall.mic.rest.policy.api.service.model.common.Items;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.WorkflowUtil;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.HTTPConstants;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.util.MachineInfoUtil;
import com.coverall.mt.util.MachineInfoUtil.MachineType;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.DOMUtil;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.portal.dao.FormsAssociationDAO;
import com.coverall.portal.services.FormsWorkFlowService;
import com.coverall.security.authentication.User;
import com.coverall.util.DBUtil;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;


public class FormsServiceImpl implements FormsService {
	public String entityReference;
	public String entityType;
	public Message message ;
	public HttpServletRequest request;
	public final String FORM_PREVIEW_URL="/mic/imaging/FileCabinetDownloadServlet";
	/* Changes not done for same name document as query is based on PDT_ID */
	public String queryForGettingFormSpecifics="SELECT pdt_id,MFO_FORM_NUMBER,MFO_COVERAGE_PART_REFERENCE,MFO_OCCURRENCE FROM MIS_FORMS, PS_DOCUMENT_TEMPLATE"+
			" WHERE 1=1 AND MFO_FORM_NUMBER=pdt_name AND mfo_policy_reference=? AND to_char(pdt_id)||LPAD(to_char(NVL(MIS_FORMS.MFO_OCCURRENCE,0)),3, '0') IN (";

	private static final String TEMPLATE_DOWNLOAD = "templateDownload";
	private static final String TEMP = "temp";
	private static final Random randomizer = new Random();
	private boolean isServicesBoth = false;
	private String pdfServerPath = null; 
	private String pdfServerPort = null;
	public FormsServiceImpl() {

	}

	public FormsServiceImpl(String entityReference, String entityType, HttpServletRequest request) {
		this.entityReference = entityReference;
		this.entityType = entityType;
		this.request=request;

	}
	
	
	public List <Message> errorMessageList;

	@Override
	public Forms getAttachedForms() {

        Message message = new Message();

		boolean isBinder = false;

		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		Forms forms = new Forms();
		try {
			Connection conn = requestContext.getConnection();
			
			
			if(!WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)) {
				errorMessageList = new ArrayList<Message>();
				message.setMoreinfo(APIConstant.INVALID_REQUEST);
				errorMessageList.add(message);

				throw new APIException(APIConstant.POLICY_NOT_EXISTS_CODE,APIConstant.FAILED,errorMessageList,new Throwable());
			}
			
			String entityType = APIConstant.ENTITY_QUOTE;  
		
			boolean isPolicyEntity = WorkflowUtil.getEntityType(conn, entityReference);

			if (isPolicyEntity) {
				entityType = APIConstant.ENTITY_POLICY; }

			isBinder = WorkflowUtil.checkIfBinder(conn, entityReference);


			if (!WorkflowUtil.isWorkflowStageReached(conn, entityType, APIConstant.FORMSMANAGEMENT_TASK,
					entityReference)) {
				errorMessageList = new ArrayList<Message>();
				message.setMoreinfo(APIConstant.WORKFLOW_NOT_EXISTS);
				errorMessageList.add(message);

				throw new APIException(APIConstant.WORKFLOW_NOT_EXISTS_CODE,APIConstant.FAILED,errorMessageList,new Throwable());
			}

//			if (!WorkflowUtil.checkIfFormPresent(conn, entityReference)) {
//				errorMessageList = new ArrayList<Message>();
//				message.setMoreinfo(APIConstant.FORM_NOT_EXISTS);
//				errorMessageList.add(message);
//
//				throw new APIException(APIConstant.FORM_NOT_EXISTS_CODE,APIConstant.FAILED,errorMessageList,new Throwable());
//			}


			forms.setForms(FormUtil.getAttachedForms(conn, entityReference, entityType,isBinder));

			return forms;


		} catch (APIException e ) {


			throw new APIException(e.getErrorCode(),e.getErrorMessage(),e.getErrorMessageList(),new Throwable());
		}catch (java.lang.Exception e) {
			errorMessageList = new ArrayList<Message>();
			message.setMoreinfo(e.getMessage());
			errorMessageList.add(message);

			throw new APIException(APIConstant.RUNTIME_EXCEPTION,APIConstant.FAILED,errorMessageList,new Throwable());	
		}
	}

	@Override
	public Object updateFormVariables(String formId, HttpServletRequest request) {
		
		String occurance="0";
		long activityID = 0;
		boolean isBinder = false;

		boolean shouldExecute = false;
		Message message = new Message();

		try {
			
			if(!FormUtil.validatFormIdFormat(formId)){
				String errMsg = formId+APIConstant.INVALID_FORM_ID_FORMAT;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "updateFormVariables", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}
			
			IAPIContext requestContext = APIRequestContext.getApiRequestContext();
			//requestContext.setAuditTrailLog(null);

			Connection conn = requestContext.getConnection();
			
			ObjectMapper mapper=new ObjectMapper();
			String inputJson=APIOperationUtil.fetchRequestBody(request);
			FormVariables formVariables=mapper.readValue(inputJson, FormVariables.class);
			
			if(!WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)) {
				errorMessageList = new ArrayList<Message>();
				message.setMoreinfo(APIConstant.INVALID_REQUEST);
				errorMessageList.add(message);

				throw new APIException(APIConstant.POLICY_NOT_EXISTS_CODE,APIConstant.FAILED,errorMessageList,new Throwable());
			}
			
			String entityType = APIConstant.ENTITY_QUOTE;

			boolean isPolicyEntity = WorkflowUtil.getEntityType(conn, entityReference);
			isBinder = WorkflowUtil.checkIfBinder(conn, entityReference);

			if (isPolicyEntity) {
				entityType = APIConstant.ENTITY_POLICY;
			}
			
			occurance=formId.substring(formId.length()-3);
			formId=formId.substring(0, formId.length()-3);
			

			if (!WorkflowUtil.checkIfFormPresent(conn, entityReference,formId,occurance)) {
				errorMessageList = new ArrayList<Message>();
				message.setMoreinfo(APIConstant.WORKFLOW_NOT_EXISTS);
				errorMessageList.add(message);

				throw new APIException(APIConstant.WORKFLOW_NOT_EXISTS_CODE, APIConstant.FAILED, errorMessageList,
						new Throwable());
			}

			if (!WorkflowUtil.isWorkflowStageReached(conn, entityType, APIConstant.FORMSMANAGEMENT_TASK,
					entityReference)) {
				errorMessageList = new ArrayList<Message>();
				message.setMoreinfo(APIConstant.WORKFLOW_NOT_EXISTS);
				errorMessageList.add(message);

				throw new APIException(APIConstant.WORKFLOW_NOT_EXISTS_CODE, APIConstant.FAILED, errorMessageList,
						new Throwable());
			}

			if (isPolicyEntity) {
				if (WorkflowUtil.checkIfPolicyBooked(conn, entityReference)) {
					errorMessageList = new ArrayList<Message>();
					message.setMoreinfo(APIConstant.POLICY_BOOKED);
					errorMessageList.add(message);

					throw new APIException(APIConstant.POLICY_BOOKED_CODE, APIConstant.FAILED, errorMessageList,
							new Throwable());
				}
			} else {
				if (APIConstant.CONVERTED_TO_POLICY
						.equalsIgnoreCase(WorkflowUtil.getCurrentPolicyStatus(entityReference, entityType, conn))) {
					errorMessageList = new ArrayList<Message>();
					message.setMoreinfo(APIConstant.QUOTE_HAVING_NEW_REVISION);
					errorMessageList.add(message);

					throw new APIException(APIConstant.INVALID_REQUEST_CODE, APIConstant.FAILED,
							errorMessageList, new Throwable());
				}

			}

			if (null != formVariables && formVariables.getFormVariables().size() == 0) {
				errorMessageList = new ArrayList<Message>();
				message.setMoreinfo(APIConstant.FORM_VAR_NOT_EXISTS);
				errorMessageList.add(message);

				throw new APIException(APIConstant.FORM_VAR_NOT_EXISTS_CODE, APIConstant.FAILED, errorMessageList,
						new Throwable());
			} 
			
			if (!WorkflowUtil.hasFormModifyPermission(requestContext.getUser().getDomain(),
					requestContext.getUser().getUserId().substring(0,requestContext.getUser().getUserId().indexOf("@") ))) {
				errorMessageList = new ArrayList<Message>();
				message.setMoreinfo(APIConstant.USER_PERMISSION_NOT_EXISTS);
				errorMessageList.add(message);

				throw new APIException(APIConstant.USER_PERMISSION_NOT_EXISTS_CODE, APIConstant.FAILED,
						errorMessageList, new Throwable());

			}
			
			List <FormVariableVo> formVariableVO=new ArrayList<FormVariableVo>();
			//Validating if the variables and creating list of varialble VO
			for (int i = 0; i < formVariables.getFormVariables().size(); i++) {
				
				
				String formVariableOccurance=occurance;
				String providedVariableOccurnace=formVariables.getFormVariables().get(i).getVariableOccurrence();
				if(providedVariableOccurnace!=null && providedVariableOccurnace.trim().length() != 0){
					formVariableOccurance=providedVariableOccurnace;
				}
				
				if (!WorkflowUtil.checkIfFormVariableIsAvailable(conn, entityReference, Integer.parseInt(formId),
						formVariables.getFormVariables().get(i).getVariableName(),formVariableOccurance)) {
					errorMessageList = new ArrayList<Message>();
					message.setMoreinfo(APIConstant.FORM_VAR_DATA_INVALID);
					errorMessageList.add(message);

					throw new APIException(APIConstant.FORM_VAR_DATA_INVALID_CODE, APIConstant.FAILED, errorMessageList,
							new Throwable());
				}
				
				FormVariableVo variableVo = FormUtil.getFormVaraibleDetailData(conn, entityReference,
						Integer.parseInt(formId), formVariables.getFormVariables().get(i),
						entityType, isBinder, formVariableOccurance);
				
				// Validating Form Variables
				FormUtil.validateFormVariables(variableVo,
						formVariables.getFormVariables().get(i).getVariableValue());
				
				formVariableVO.add(variableVo);
			}

			for (int i = 0; i < formVariableVO.size(); i++) {
				
				FormVariableVo variableVo =formVariableVO.get(i);

					// Check the stage
					// Block the Stage

					activityID = WorkflowUtil.getActivityID(conn, entityType, entityReference,
							APIConstant.FORMSMANAGEMENT_TASK);

					// WorkflowUtil.getStageDesc(conn, policyReference, activityID);
					Map<String, String> status = WorkflowUtil.getCurrentWorkflowStatus(conn, entityType,
							entityReference, APIConstant.FORMSMANAGEMENT_TASK);

					if (null != status && !status.isEmpty()
							&& !status.get(APIConstant.TASK_STATUS).trim().toUpperCase().equalsIgnoreCase("BLOCK")) {
						WorkflowUtil.setBlocked(conn, activityID, status.get(APIConstant.TASK_STATUS));
						shouldExecute = true;
					} else {
						shouldExecute = true;

					}

					if (shouldExecute) {
						if (variableVo.getFormVarType().equalsIgnoreCase("RICHTEXT")) {
							FormUtil.updateFormRichTextVariable(conn, entityReference, variableVo,
									Integer.parseInt(formId),
									formVariableVO.get(i).getFormVarModifiedValue());
						} else {
							FormUtil.updateFormVariable(conn, entityReference, variableVo, Integer.parseInt(formId),
									formVariableVO.get(i).getFormVarModifiedValue());
						}

					}
				}

			if (FormUtil.isAnyVariableIncomplete(entityReference, entityType, conn)) {

			    errorMessageList = new ArrayList<Message>();
			    message.setMoreinfo(APIConstant.MANDATORY_VARIABLE_EXISTS);
				errorMessageList.add(message);

				throw new APIException(APIConstant.MANDATORY_VARIABLE_EXISTS_CODE, APIConstant.PARTIALLY_SUCCESSFUL,
						errorMessageList, new Throwable());
			    

			} else {
			    
				WorkflowUtil.setComplete(activityID, conn, requestContext.getUser().getUserId());
                Items item = new Items();
                item.setSystemerrcode("Successful");
                message.setItem(item);
				message.setMoreinfo("Successfully updated the form variables and triggered the next workflow. ");
				

			}

		} catch (APIException e) {
			throw e;
		}catch (java.lang.Exception e) {
			errorMessageList = new ArrayList<Message>();
			message.setMoreinfo(e.getMessage());
			errorMessageList.add(message);

			throw new APIException(APIConstant.RUNTIME_EXCEPTION, APIConstant.FAILED, errorMessageList,
					new Throwable());

		}

		return message;

	}

	@Override
	public String ping() {
		// TODO Auto-generated method stub
		throw new APIException();
		//return "This is Policy API Forms service";
	}

	
	private Forms createDummyFormsObject(){
		Forms formsObj = new Forms();
		FormVariable formVarObj = new FormVariable();
		FormVariable formVarObj2 = new FormVariable();
		FormVariables formVarsObj2 = new FormVariables();
		
		Form formObj = new Form();
		
		formObj.setFormName("TEST FORM");
		formObj.setFormId(1245);
		formObj.setRevision("001");
		
		formVarObj.setRequired(FormVariable.requiredValues.Y);
		formVarObj.setVariableName("TEST VAR");
		formVarObj.setVariableValue("TEST VAR VALUE");
		
		formVarObj2.setRequired(FormVariable.requiredValues.N);
		formVarObj2.setVariableName("TEST VAR 2");
		formVarObj2.setVariableValue("TEST VAR VALUE 2");
		
		formVarsObj2.getFormVariables().add(formVarObj);
		formVarsObj2.getFormVariables().add(formVarObj2);
		formObj.setFormVariables(formVarsObj2);
		formsObj.getForms().add(formObj);
		return formsObj;
	}

	@Override
	public FormVariables getAttachedFormsVariables(String formId) {
		String occurance="0";
		Message message = new Message();
		FormVariables formVariables = new FormVariables();
		boolean isBinder = false;
		
		try {
			
			if(!FormUtil.validatFormIdFormat(formId)){
				String errMsg = formId+APIConstant.INVALID_FORM_ID_FORMAT;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "getAttachedFormsVariables", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}
			
			Connection conn = APIRequestContext.getApiRequestContext().getConnection();
			
			if(!WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)) {
				errorMessageList = new ArrayList<Message>();
				message.setMoreinfo(APIConstant.INVALID_REQUEST);
				errorMessageList.add(message);

				throw new APIException(APIConstant.POLICY_NOT_EXISTS_CODE,APIConstant.FAILED,errorMessageList,new Throwable());
			}
			
			occurance=formId.substring(formId.length()-3);
			formId=formId.substring(0, formId.length()-3);
			
			
			if (!WorkflowUtil.checkIfFormPresent(conn, entityReference,formId, occurance)) {
				errorMessageList = new ArrayList<Message>();
				message.setMoreinfo(APIConstant.FORM_NOT_EXISTS);
				errorMessageList.add(message);
				throw new APIException(APIConstant.FORM_NOT_EXISTS_CODE,APIConstant.FAILED,errorMessageList,new Throwable());		
			}
			
			
			String entityType = APIConstant.ENTITY_QUOTE;

			boolean isPolicyEntity = WorkflowUtil.getEntityType(conn, entityReference);

			if (isPolicyEntity) {
				entityType = APIConstant.ENTITY_POLICY;
			}

			isBinder = WorkflowUtil.checkIfBinder(conn, entityReference);


			if (!WorkflowUtil.isWorkflowStageReached(conn, entityType, APIConstant.FORMSMANAGEMENT_TASK,
					entityReference)) {
				errorMessageList = new ArrayList<Message>();
				message.setMoreinfo(APIConstant.WORKFLOW_NOT_EXISTS);
				errorMessageList.add(message);

				throw new APIException(APIConstant.WORKFLOW_NOT_EXISTS_CODE,APIConstant.FAILED,errorMessageList,new Throwable());		

			}
			
			List<FormVariable> formVariablesFromDB=FormUtil.getFormVaraibles(conn, entityReference, formId , isBinder, entityType,occurance);

			if(formVariablesFromDB.size() == 0) {
				errorMessageList = new ArrayList<Message>();
				message.setMoreinfo(APIConstant.FORM_VAR_NOT_EXISTS);
				errorMessageList.add(message);

				throw new APIException(APIConstant.FORM_VAR_NOT_EXISTS_CODE,APIConstant.FAILED,errorMessageList,new Throwable());		


			}

			formVariables.setFormVariables(formVariablesFromDB);

			return formVariables;

		} catch (APIException e) {
			throw new APIException(e.getErrorCode(),e.getErrorMessage(),e.getErrorMessageList(),new Throwable());

		}



		catch (java.lang.Exception e) {
			errorMessageList = new ArrayList<Message>();
			message.setMoreinfo(e.getMessage());
			errorMessageList.add(message);

			throw new APIException(APIConstant.RUNTIME_EXCEPTION,APIConstant.FAILED,errorMessageList,new Throwable());	
		}
	}

	@Override
	public Forms qualifyingForms(String showAll,String manuscript){
		Forms qualifyingForms=new Forms();
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		User user=requestContext.getUser();
		CallableStatement callStmt=null;
		ResultSet rs=null;

		long sourceSystemRequestNo=System.currentTimeMillis();

		try {
			Connection conn = requestContext.getConnection();

			if(!WorkflowUtil.checkIfUserHasTheRequiredPermission(user, APIConstant.FORM_MODIFY_PERMISSION)) {
				String errMsg = user.getUserId()+" doesn't have permission to modify the forms.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "qualifyingForms", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}

			if(!WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)) {
				String errMsg = entityReference+" doesn't exists please check input parameter.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "qualifyingForms", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}

			if (!WorkflowUtil.isWorkflowStageReached(conn, entityType, APIConstant.FORMSMANAGEMENT_TASK,
					entityReference)) {
				String errMsg = "Form Management stage is not yet reached for the "+entityReference+". Please check status of "+entityType;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "qualifyingForms", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}

			if (!WorkflowUtil.checkIfFormCanBeModifiedForTheEntity(user.getUserId().substring(0, user.getUserId().indexOf("@")),conn, entityType, entityReference)) {
				String errMsg = "Forms under "+entityReference+" cannot be modified/deleted. Please check the status of the "+entityType;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "qualifyingForms", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}

			
			//Validating input parameters			
			String invalidInput=null;

			if(null!=showAll && null!=manuscript && "Y".equalsIgnoreCase(manuscript)){
				invalidInput="showAll is not applicable for manuscripts. Please remove showAll parameter.";
			}

			if(null==showAll){
				showAll="N";
			}else if(!("Y".equalsIgnoreCase(showAll)|| "N".equalsIgnoreCase(showAll))){
				invalidInput="Invalid value of showAll. It should be Y or N.";
			}

			if(null==manuscript){
				manuscript="N";
			}else if(!("Y".equalsIgnoreCase(manuscript)|| "N".equalsIgnoreCase(manuscript))){
				invalidInput="Invalid value of manuscript. It should be Y or N.";
			}

			if(invalidInput!=null){
				String errMsg = invalidInput;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "qualifyingForms", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}
			
			
			try{
			qualifyingForms.setForms(FormUtil.getQualifyingFormsForQuotePolicy(user, conn, entityType, entityReference, showAll, manuscript, sourceSystemRequestNo));
			}catch(Exception exp){
				String errMsg = "Error while fetching qualifying form for the "+entityReference;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "qualifyingForms", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
			
		}catch(APIException e){
			throw new APIException(e.getErrorCode(),e.getErrorMessage(),e.getErrorMessageList(),new Throwable());
		}catch(Exception exp){
			WebServiceLoggerUtil.logError("FormServiceImpl", "qualifyingForms", exp.getMessage(), new Object[] {  "Error while getting list of qualifying forms "+exp.getMessage() }, exp);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(exp.getLocalizedMessage())),exp);
		}finally {
			try{
				DBUtil.close(rs, callStmt);
			}catch(Exception e){
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "qualifyingForms", e.getLocalizedMessage(), new Object[] { e.getMessage() });
			}
		}


		return qualifyingForms;
	}

	@Override
	public Response previewForm(String formId) throws Exception{

		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		User user=requestContext.getUser();
		int validatedFormId=0;

		if(!FormUtil.validatFormIdFormat(formId)){
			String errMsg = formId+APIConstant.INVALID_FORM_ID_FORMAT;
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			WebServiceLoggerUtil.logInfo("FormServiceImpl", "previewForm", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
		}

		if(!WorkflowUtil.checkIfUserHasTheRequiredPermission(user, APIConstant.FORM_PREVIEW_PERMISSION)) {
			String errMsg = user.getUserId()+" doesn't have permission to preview the forms.";
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			WebServiceLoggerUtil.logInfo("FormServiceImpl", "previewForm", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
		}
		// Removing validation as per the requirements and behaviour from UI
		//			Connection conn = requestContext.getConnection();
		//			if(!WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)) {
		//				errMsg = entityReference+" doesn't exists please check input parameter.";
		//				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
		//				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
		//				WebServiceLoggerUtil.logInfo("FormServiceImpl", "previewForm", errMsg, new Object[] { errMsg });
		//				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
		//			}
		//
		//			//Check existence of form Id
		//			boolean formIdExists=false;
		//			Forms formList=getAttachedForms();
		//			for(Form form:formList.getForms()){
		//				if(form.getFormId()==validatedFormId){
		//					formIdExists=true;
		//					break;
		//				}
		//			}
		//
		//			if(!formIdExists){
		//				String errMsgPackage = validatedFormId + " form doesn't exist for " + entityReference;
		//				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsgPackage));
		//				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
		//				WebServiceLoggerUtil.logInfo("FormServiceImpl", "previewForm", errMsg, new Object[] { errMsg });
		//				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
		//			}
		//
		//		}catch(APIException e){
		//			throw new APIException(e.getErrorCode(),e.getErrorMessage(),e.getErrorMessageList(),new Throwable());
		//		}

		try{
			String validatedId=formId;
			String occurance=validatedId.substring(formId.length()-3);
			String templateId=validatedId.substring(0, formId.length()-3);

				DocumentTemplate mtDocgenDAO = new DocumentTemplate();
				mtDocgenDAO.initialise(requestContext.getMtUser(), templateId);
				DocgenServiceFacade service = new DocgenServiceFacadeImpl();
				String stringOccurrence = request.getParameter(HTTPConstants.REQUEST_OCCURRENCE); 
				Map documentTemplateInfo = null;
				String templateFileName = "";
				File tempDirectory = null;
				String custom = null;
				String base = null;
				String fileType = "";
				String micRiHome = "";
				InputStream fileInputStream = null;
				long occurrence = 0;
				int fileSize =  0;
				if (null != stringOccurrence && !stringOccurrence.isEmpty()) {
					occurrence = Long.valueOf(stringOccurrence);
				}
				micRiHome = System.getProperty(DOMUtil.MIC_SYSTEM_HOME) +
						File.separator + ServletConfigUtil.COMPONENT_RI + File.separator +
						CustomerConfigUtil.getInstance().getCustomerCode(user.getDomain());
				tempDirectory =
						new File(micRiHome + File.separator +
								TEMP + File.separator + TEMPLATE_DOWNLOAD + File.separator +
								randomizer.nextLong());
				tempDirectory.mkdirs();	
				documentTemplateInfo = ImagingUtil.getDocumentTemplateInfo(requestContext.getMtUser(), templateId);
				String custCode = CustomerConfigUtil.getInstance().getCustomerCode(user.getDomain());

				Iterator entries = documentTemplateInfo.keySet().iterator();
				while (entries.hasNext()) {
					String fileName = entries.next().toString();
					if ((fileName.toLowerCase()).indexOf(HTTPConstants.SUPPLEMENT_DOCX) > 0) {
						//Nothing
					} else {
						if ((fileName.toLowerCase()).indexOf("CUST_" + custCode) > 0) {
							custom = fileName;
						} else {
							base = fileName;
						}
					}
				}

				if (custom != null) {
					templateFileName = custom;
				} else {
					templateFileName = base;
				}
				
				String overriddenServiceUrl = null;
				String ip = null;
				try {
					ip = InetAddress.getLocalHost().getHostAddress();
				}catch(IOException ex) {
					ex.printStackTrace();
				}
				
				isServicesBoth = isThisServicesBothMachine(ip);	
				
				if(isServicesBoth) {
					overriddenServiceUrl = null;
				}else {
					if(!isServicesBoth) {
						String[] pdfServerInfo = getPDFServerInfo(ip);	
						
						if(pdfServerInfo == null) {
							throw new ServletException("The service server is mis-configured, no server path or server port, current application server ip=" + ip);
						} else {
							pdfServerPath = pdfServerInfo[0];
							pdfServerPort = pdfServerInfo[1];
						}
						
						if(null != pdfServerPort) {
							overriddenServiceUrl = pdfServerPath+ ":" + pdfServerPort;
						}else {
							overriddenServiceUrl = pdfServerPath;
						}
					}
				}
				
				byte[] convertedPDF = service.processPreview(
						entityReference, entityType,
						templateId, "" + occurrence, requestContext.getMtUser(), overriddenServiceUrl);
				if (templateFileName == null
						|| templateFileName.trim().isEmpty()) {
					templateFileName = "Preview";
				}
				File tempFile = File
						.createTempFile(templateFileName,
								".pdf", tempDirectory);
				FileUtils.writeByteArrayToFile(tempFile,
						convertedPDF);
				fileType = "application/pdf";
				fileSize = (int) tempFile.length();
				fileInputStream = new FileInputStream(tempFile);
				
				if(templateFileName.toLowerCase().contains(".docx")) {
					templateFileName = templateFileName.substring(0, templateFileName.lastIndexOf(".")) + ".pdf";
				}
				
				return Response
						.ok(fileInputStream, MediaType.APPLICATION_OCTET_STREAM)
						.header("content-disposition","inline; filename =\""+templateFileName+"\"")
						.build();

		}catch(Exception exp){
			WebServiceLoggerUtil.logError("FormServiceImpl", "previewForm", exp.getMessage(), new Object[] {  "Error while calling servlet for retrieveing form "+exp.getMessage() }, exp);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(exp.getLocalizedMessage())),exp);
		}
	}
	
	private String[] getPDFServerInfo(String ip){
		Connection conn = null;
		PreparedStatement st   = null;
		ResultSet rs = null;
		String[] serverInfo = null;
		String serverPath = null;
		String serverPort = null;
		
		LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
				FileCabinetDownloadServlet.class.getName(),
				"isThisServicesBothMachine",
				ServletConfigUtil.COMPONENT_IMAGING,
				new Object[] {"Check for First Service or both machines path"}, null, null,
				LogMinderDOMUtil.VALUE_MIC);
		try {
			String sql =
	                " SELECT DECODE(AMA_SECURE,'Y','https://','http://') || NVL(AMA_VIRTUALHOST_NAME, AMA_NAME) || '.' || DECODE(NVL(AMA_VIRTUALHOST_NAME,''),'',AMA_FQDN, AMA_USERDOMAIN) PDFServerPath," + 
	                		"NVL(AMA_VIRTUALHOST_PORT, AMA_ADMIN_PORT) PDFServerPort " +
							" FROM ADM_MACHINES, ADM_INSTANCES, ADM_CONFIGURATION_TYPES " +
							" WHERE AMA_MACHINE_ID = AIN_MACHINE_ID ";
			
			if(ip != null && !"".equalsIgnoreCase(ip)) {
				sql = sql + " AND AMA_IPADDRESS != '" + ip + "' ";
			}
			
			sql = sql +	" AND AIN_CONFIGURATION_TYPE_ID = ACT_CONFIGURATION_TYPE_ID " +
							" AND AIN_CONFIGURATION_TYPE_ID IN ( SELECT ACT_CONFIGURATION_TYPE_ID " +
							" FROM ADM_CONFIGURATION_TYPES " +
							" WHERE UPPER(ACT_NAME) IN ( " +
							" UPPER('Both'), " +
							" UPPER('Services Handler') ) ) AND rownum < 2 ORDER BY ACT_NAME DESC ";
			
			conn = ConnectionPool.getAdminConnection();
			st = conn.prepareStatement(sql);
			st.execute();
			rs = st.getResultSet();
			while (rs.next()) {
				serverPath = rs.getString("PDFServerPath");
				serverPort = rs.getString("PDFServerPort");
			}
			
			if (serverPath == null || "".equalsIgnoreCase(serverPath)
					|| serverPort == null || "".equalsIgnoreCase(serverPath)) {
				LogMinder.getLogMinder().log(
						LogEntry.SEVERITY_FATAL,
						FileCabinetDownloadServlet.class.getName(),
						"getPDFServerInfo",
						ServletConfigUtil.COMPONENT_IMAGING,
						null,
						"No server Path or Server Port return, serverPath="
								+ serverPath + ", serverPort=" + serverPort
								+ ",the sql is " + sql, null,
						LogMinderDOMUtil.VALUE_MIC);
			} else {
				serverInfo = new String[2];
				serverInfo[0] = serverPath;
				serverInfo[1] = serverPort;
			}
		}catch (DOMCreationException ex) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					FileCabinetDownloadServlet.class.getName(), "getPDFServerPath",
					ServletConfigUtil.COMPONENT_IMAGING,
					null, "Error in Fetching PDFServerPath", ex,
					LogMinderDOMUtil.VALUE_MIC);
		}
		catch (NamingException namingException) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					FileCabinetDownloadServlet.class.getName(), "getPDFServerPath",
					ServletConfigUtil.COMPONENT_IMAGING,
					null,
					"Error in Fetching PDFServerPath", namingException,
					LogMinderDOMUtil.VALUE_MIC);
		} catch (SQLException sqlException) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					FileCabinetDownloadServlet.class.getName(), "getPDFServerPath",
					ServletConfigUtil.COMPONENT_IMAGING,
					null, "Error in Fetching PDFServerPath", sqlException,
					LogMinderDOMUtil.VALUE_MIC);
		} catch (Exception sqlException) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					FileCabinetDownloadServlet.class.getName(), "getPDFServerPath",
					ServletConfigUtil.COMPONENT_IMAGING,
					null, "Class Not found", sqlException,
					LogMinderDOMUtil.VALUE_MIC);
		}
		finally {
			try {
				DBUtil.close(rs, st);
				ConnectionPool.releaseConnection(conn);
			} catch (Exception ex) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
						FileCabinetDownloadServlet.class.getName(), "getPDFServerPath",
						ServletConfigUtil.COMPONENT_IMAGING,
						null,
						"Error in Closing DB connection", ex,
						LogMinderDOMUtil.VALUE_MIC);
			}
		}
		return serverInfo;
	}
	
	private boolean isThisServicesBothMachine(String ip) {
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		boolean isServiceOrBoth = false;
		isServiceOrBoth = MachineInfoUtil.checkMachineType(MachineType.MACHINE_TYPE_SERVICE_SERVER, true);
		/*
		try {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
					FileCabinetDownloadServlet.class.getName(),
					"isThisServicesBothMachine",
					ServletConfigUtil.COMPONENT_IMAGING,
					new Object[] {"Check for Service or both machines"}, null, null,
					LogMinderDOMUtil.VALUE_MIC);
			String sql =
					"SELECT AMA_MACHINE_ID FROM ADM_MACHINES, ADM_INSTANCES, ADM_CONFIGURATION_TYPES " +
							"WHERE AMA_IPADDRESS ='" + ip + "' AND " +
							"AMA_MACHINE_ID = AIN_MACHINE_ID " +
							" AND AIN_CONFIGURATION_TYPE_ID = ACT_CONFIGURATION_TYPE_ID " +
							" AND AIN_CONFIGURATION_TYPE_ID IN ( SELECT ACT_CONFIGURATION_TYPE_ID " +
							" FROM ADM_CONFIGURATION_TYPES " +
							" WHERE UPPER(ACT_NAME) IN ( " +
							" UPPER('Both'), " +
							" UPPER('Services Handler') ) )";
			conn = ConnectionPool.getAdminConnection();
			st = conn.createStatement();
			st.execute(sql);
			rs = st.getResultSet();
			if (rs.next()) {
				isServiceOrBoth = true;
			}
		} catch (Throwable e) {
			isServiceOrBoth = false;
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,
					FileCabinetDownloadServlet.class.getName(),
					"isThisServicesBothMachine",
					"Imaging",
					null, "Unexpected error", e,
					LogMinderDOMUtil.VALUE_MIC);
		} finally {
			try {
				DBUtil.close(rs, st, conn);
			} catch (Exception ex) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
						FileCabinetDownloadServlet.class.getName(), "isThisServicesBothMachine",
						ServletConfigUtil.COMPONENT_IMAGING,
						null,
						"Error in Closing DB connection", ex,
						LogMinderDOMUtil.VALUE_MIC);
			}
		}
		*/
		return isServiceOrBoth;
	}

	@Override
	public Object addFormToQuotePolicy() {
		ConfirmationMessage response=null;
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		User user=requestContext.getUser();
		long sourceSystemRequestNo=System.currentTimeMillis();
		//requestContext.setAuditTrailLog(null);
		try {
			Connection conn = requestContext.getConnection();

			if(!WorkflowUtil.checkIfUserHasTheRequiredPermission(user, APIConstant.FORM_MODIFY_PERMISSION)) {
				String errMsg = user.getUserId()+" doesn't have permission to delete the forms.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "addFormToQuotePolicy", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}

			if(!WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)) {
				String errMsg = entityReference+" doesn't exists please check input parameter.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "addFormToQuotePolicy", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}

			if (!WorkflowUtil.isWorkflowStageReached(conn, entityType, APIConstant.FORMSMANAGEMENT_TASK,
					entityReference)) {
				String errMsg = "Form Management stage is not yet reached for the "+entityReference+". Please check status of "+entityType;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "addFormToQuotePolicy", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}

			if (!WorkflowUtil.checkIfFormCanBeModifiedForTheEntity(user.getName(),conn, entityType, entityReference)) {
				String errMsg = "Forms under "+entityReference+" cannot be modified/deleted. Please check the status of the "+entityType;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "addFormToQuotePolicy", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}
			
			ObjectMapper mapper=new ObjectMapper();
			String inputJson=APIOperationUtil.fetchRequestBody(request);
			Forms formsToBeAdded=mapper.readValue(inputJson, Forms.class);
			
			List<Form> listOfFormsToBeAdded=new ArrayList<Form>();
			List<Form> listOfManuscriptsToBeAdded=new ArrayList<Form>();
			validateAndListFormsToBeAddedToQuotePolicy(user,conn,formsToBeAdded,sourceSystemRequestNo,listOfFormsToBeAdded,listOfManuscriptsToBeAdded);
			
			
			Map<String,Form> formMapWithIssues=new HashMap<String, Form>();
			Map<String,Form> formMapAddedSuccessfully=new HashMap<String, Form>();
			
			for(Form manuscriptForms:listOfManuscriptsToBeAdded){
				try{
					FormUtil.addFormToQuotePolicy(user, conn, entityType, entityReference, manuscriptForms, "Y");
					formMapAddedSuccessfully.put(manuscriptForms.getFormId()+"",manuscriptForms);
				}catch(APIException exp){
					formMapWithIssues.put(manuscriptForms.getFormId()+"",manuscriptForms);
				}
			}
			
			for(Form formToBeAdded:listOfFormsToBeAdded){
				try{
					FormUtil.addFormToQuotePolicy(user, conn, entityType, entityReference, formToBeAdded, "N");
					formMapAddedSuccessfully.put(formToBeAdded.getFormId()+"",formToBeAdded);
				}catch(APIException exp){
					formMapWithIssues.put(formToBeAdded.getFormId()+"",formToBeAdded);
				}
			}
			
			try{
			  Map emptyParamMap=new HashMap();
			  FormsWorkFlowService.updateFormExpressionVariables(conn,
					  entityReference,
					  com.coverall.mt.http.User.getUser(request),
					  emptyParamMap);
			}catch (Exception exc){
			    conn.rollback();
			  	String errMsg = "Error resolving form variable expressions:"+exc.getMessage()+". Changes will be rolledback.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "addFormToQuotePolicy", errMsg, new Object[] { exc.getStackTrace() });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
		  
		  conn.commit();
		  FormUtil.reRankFormsForQuotePolicy(conn, entityReference);
		  boolean isBinder = WorkflowUtil.checkIfBinder(conn, entityReference);
		  
		  //boolean exceptionOccuredWhileAddingVariables=false;
		  response=new ConfirmationMessage();
		
		  
		  //Merging 2 lists
		  List<Form> combinedList=new ArrayList<Form>();
		  combinedList.addAll(listOfManuscriptsToBeAdded);
		  combinedList.addAll(listOfFormsToBeAdded);
		  List<String> varsWithIssues=new ArrayList<String>();
		  Map<String,Form> formMapFaliedWhileAddingVariable=new HashMap<String, Form>();

		  for(Form formInFocus:combinedList){
			  if(!formMapWithIssues.containsKey(formInFocus.getFormId()+"")){	  
				  FormVariables variableList=formInFocus.getFormVariables();
				  if(variableList != null && variableList.getFormVariables() != null) {
					  for(int i=0;i<variableList.getFormVariables().size();i++){
						  if(formInFocus.getFormVariables().getFormVariables().get(i).getVariableValue()!=null){
							  try{

								  String formId = formInFocus.getFormId()+"";
								  String occurance=formId.substring(formId.length()-3);
								  formId=formId.substring(0, formId.length()-3);


								  FormVariableVo variableVo = FormUtil.getFormVaraibleDetailData(conn, entityReference,
										  Integer.parseInt(formId), variableList.getFormVariables().get(i),
										  entityType, isBinder, occurance);
								  // Validating Form Variables
								  FormUtil.validateFormVariables(variableVo,
										  variableList.getFormVariables().get(i).getVariableValue());

								  if ("RICHTEXT".equalsIgnoreCase(variableVo.getFormVarType())) {
									  FormUtil.updateFormRichTextVariable(conn, entityReference, variableVo,
											  formInFocus.getFormId(),
											  variableList.getFormVariables().get(i).getVariableValue());

								  } else {
									  FormUtil.updateFormVariable(conn, entityReference, variableVo, formInFocus.getFormId(),
											  variableList.getFormVariables().get(i).getVariableValue());
								  }
								  formMapAddedSuccessfully.put(formInFocus.getFormId()+"",formInFocus);
							  }catch(Exception exp){
								  formMapFaliedWhileAddingVariable.put(formInFocus.getFormId()+"", formInFocus);
								  varsWithIssues.add(formInFocus.getFormVariables().getFormVariables().get(i).getVariableName()+" under "+formInFocus.getFormId());
								  formMapAddedSuccessfully.remove(formInFocus.getFormId()+"");
								  break;
								  //exceptionOccuredWhileAddingVariables=true;
							  }
						  }
					  }
				  }
			  }
		  }
		  
		  if (FormUtil.isAnyVariableIncomplete(entityReference, entityType, conn)) {
			  WorkflowUtil.setBlocked(conn, WorkflowUtil.getActivityID(conn, entityType, entityReference, APIConstant.FORMSMANAGEMENT_TASK), "Forms Management - User input required");
		  }
		  

		  if(formMapFaliedWhileAddingVariable.size()>0){
			  Object[] formIdsToBedeleted= formMapFaliedWhileAddingVariable.keySet().toArray();
			  String[] finalListToBeDeleted = new String[formIdsToBedeleted.length];
			  System.arraycopy(formIdsToBedeleted, 0, finalListToBeDeleted, 0, formIdsToBedeleted.length);
			  deleteFormFromQuotePolicy(finalListToBeDeleted);
		  }

		  String responseMessage="";
		  String code="200";
		  if(formMapAddedSuccessfully.size()>0){
			  responseMessage="Forms "+StringUtils.join(formMapAddedSuccessfully.keySet(), ',')+" added successfully.";
		  }

		  if(formMapWithIssues.size()>0){
			  responseMessage+=" There is an issue while adding "+StringUtils.join(formMapWithIssues.keySet(), ',')+" forms initially.";
		  }

		  if(formMapFaliedWhileAddingVariable.size()>0){
			  responseMessage+=" Forms failed while adding variables, listed are variables and corresponding forms :"+StringUtils.join(varsWithIssues, ','); 
		  }

		  if(formMapAddedSuccessfully.size()>0 && (formMapFaliedWhileAddingVariable.size()>0 || formMapWithIssues.size()>0)){
			  code+="- Partially Successful";
		  }else if(formMapAddedSuccessfully.size()==0){
			  code+="- No Form Added";
		  }

		  response.setCode(code);
		  response.setDescription(responseMessage);
			  
		} catch (APIException e) {
			throw new APIException(e.getErrorCode(),e.getErrorMessage(),e.getErrorMessageList(),new Throwable());
		}catch (Exception e) {
			errorMessageList = new ArrayList<Message>();
			message.setMoreinfo(e.getLocalizedMessage());
			errorMessageList.add(message);
			throw new APIException(APIConstant.RUNTIME_EXCEPTION,APIConstant.FAILED,errorMessageList,new Throwable());	
		}
		return response;
	}

	@Override
	public Object deleteFormFromQuotePolicy(String[] formIds) throws Exception{
		ConfirmationMessage response=null;
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		User user=requestContext.getUser();
		PreparedStatement pStmt=null;
		ResultSet rs=null;
		
		try {

			for(String formId:formIds){
				if(!FormUtil.validatFormIdFormat(formId)){
					String errMsg = formId+APIConstant.INVALID_FORM_ID_FORMAT;
					List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
					String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
					WebServiceLoggerUtil.logInfo("FormServiceImpl", "deleteFormFromQuotePolicy", errMsg, new Object[] { errMsg });
					throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
				}
			}

			Connection conn = requestContext.getConnection();

			if(!WorkflowUtil.checkIfUserHasTheRequiredPermission(user, APIConstant.FORM_DELETE_PERMISSION)) {
				String errMsg = user.getUserId()+" doesn't have permission to delete the forms.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "deleteFormFromQuotePolicy", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}

			if(!WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)) {
				String errMsg = entityReference+" doesn't exists please check input parameter.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "deleteFormFromQuotePolicy", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}

			if (!WorkflowUtil.isWorkflowStageReached(conn, entityType, APIConstant.FORMSMANAGEMENT_TASK,
					entityReference)) {
				String errMsg = "Form Management stage is not yet reached for the "+entityReference+". Please check status of "+entityType;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "deleteFormFromQuotePolicy", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}

			if (!WorkflowUtil.checkIfFormCanBeModifiedForTheEntity(user.getName(),conn, entityType, entityReference)) {
				String errMsg = "Forms under "+entityReference+" cannot be modified/deleted. Please check the status of the "+entityType;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "deleteFormFromQuotePolicy", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}

			String formIdListCommaSeparated=StringUtils.join(formIds, ','); 
			queryForGettingFormSpecifics+=formIdListCommaSeparated+")";
			//Array array = conn.createArrayOf("VARCHAR", new Object[]{"1", "2","3"});
			pStmt=conn.prepareStatement(queryForGettingFormSpecifics);
			pStmt.setString(1, entityReference);

			rs=pStmt.executeQuery();
			List<String> listofFormIds=new ArrayList<String>();
			List<FormDeleteObj> fileDeleteObjList=new ArrayList<FormDeleteObj>();

			while(rs.next()){
				FormDeleteObj formObj=new FormDeleteObj();
				listofFormIds.add(rs.getString("pdt_id"));
				formObj.setFormId(rs.getString("pdt_id"));
				formObj.setFormName(rs.getString("MFO_FORM_NUMBER"));
				formObj.setEntityReference(entityReference);
				formObj.setFormOccurance(rs.getString("MFO_OCCURRENCE"));
				formObj.setFormCoveragePartReference(rs.getString("MFO_COVERAGE_PART_REFERENCE"));
				formObj.setFormModifiedReference(entityReference);
				formObj.setFormModifiedCoverage(rs.getString("MFO_COVERAGE_PART_REFERENCE"));

				fileDeleteObjList.add(formObj);
			}

			String invalidFormId=null;
			for(String formId:formIds){
				String occurance=formId.substring(formId.length()-3);
				formId=formId!=null?formId.substring(0,formId.length()-3):null;
				if(!listofFormIds.contains(formId)){
					invalidFormId=formId+occurance;
					break;
				}
			}
			if(null!=invalidFormId){
				String errMsg = invalidFormId+APIConstant.FORM_ID_NOT_EXISTS+entityReference+".";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "deleteFormFromQuotePolicy", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}
			for(FormDeleteObj formObject:fileDeleteObjList){

				FormsAssociationDAO formAssociationDao=new FormsAssociationDAO();
				HashMap<String, String> userData=new HashMap<String, String>();
				userData.put("MFO_POLICY_REFERENCE", entityReference);
				userData.put("MFO_COVERAGE_PART_REFERENCE", formObject.getFormCoveragePartReference());
				userData.put("MFO_FORM_NUMBER", formObject.getFormName());
				userData.put("MFO_OCCURRENCE", formObject.getFormOccurance());
				userData.put("MFO_REFERENCE_MODIFIED", formObject.getFormModifiedReference());
				userData.put("MFO_COVERAGE_MODIFIED", formObject.getFormModifiedCoverage());

				formAssociationDao.initialise(com.coverall.mt.http.User.getUser(request), userData);
				formAssociationDao.delete(conn);

			}
			response=new ConfirmationMessage();
			response.setCode("200");
			response.setDescription(formIdListCommaSeparated+" is/are deleted successfully for the "+entityType+" "+entityReference);

		} catch (APIException e) {
			throw new APIException(e.getErrorCode(),e.getErrorMessage(),e.getErrorMessageList(),null);
		}catch (Exception e) {
			errorMessageList = new ArrayList<Message>();
			message.setMoreinfo(e.getLocalizedMessage());
			errorMessageList.add(message);
			throw new APIException(APIConstant.RUNTIME_EXCEPTION,APIConstant.FAILED,errorMessageList,null);
		} finally {
			try {
				DBUtil.close(rs, pStmt);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return response;
	}

	public List<Message> getErrorMessageList(List<String> strMessages)	{
		if(strMessages == null)	{
			return null;
		}
		List<Message> errorMessageList = new ArrayList<Message>(strMessages.size());
		for(String aMsg : strMessages)	{
			Message message = new Message();
			message.setMoreinfo(aMsg);
			errorMessageList.add(message);
		}
		return errorMessageList;
	}

	public void validateAndListFormsToBeAddedToQuotePolicy(User user,Connection conn,Forms addedFormsInput, long sourceSystemRequestNo,List<Form> listOfFormsToBeAdded,
			List<Form> listOfManuscriptsToBeAdded) throws Exception{

		boolean isBinder = WorkflowUtil.checkIfBinder(conn, entityReference);

		if(addedFormsInput!=null && addedFormsInput.getForms()!=null && addedFormsInput.getForms().size()>0){
			//Fetching all attached forms
			Forms attachedForms=new Forms();
			attachedForms.setForms(FormUtil.getAttachedForms(conn, entityReference, entityType,isBinder));

			//Fetching all qualifying forms using showALL as Y
			Forms qualifyingFormsWithShowALL=new Forms();
			qualifyingFormsWithShowALL.setForms(FormUtil.getQualifyingFormsForQuotePolicy(user, conn, entityType, entityReference, "Y", "N", sourceSystemRequestNo));

			//Fetching all manuscripts
			Forms qualifyingManuscript=new Forms();
			qualifyingManuscript.setForms(FormUtil.getQualifyingFormsForQuotePolicy(user, conn, entityType, entityReference, "N", "Y", sourceSystemRequestNo));


			//Verify if form being added is getting qualified or is already attached or not. The form should be available under qualifying forms, attachedForms and manuscript.
			for(Form addedForm:addedFormsInput.getForms()){
				boolean foundEntry=false;
				//Verify if added form is manuscript if yes then checking its mandatory parameter customTitle and variables
				for(Form manuscriptForm:qualifyingManuscript.getForms()){
					if(manuscriptForm.getFormId()==addedForm.getFormId()){
						foundEntry=true;
						if(null==addedForm.getCustomTitle()){
							String errMsg = "customTitle is missing from "+addedForm.getFormId()+", it is a required field for the manuscripts";
							List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
							String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
							WebServiceLoggerUtil.logInfo("FormServiceImpl", "validateFormsToBeAddedToQuotePolicy", errMsg, new Object[] { errMsg });
							throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
						}
						manuscriptForm.setCustomTitle(addedForm.getCustomTitle());
						manuscriptForm.setCustomFormNumber(addedForm.getCustomFormNumber());
						manuscriptForm.setCustomEditionDate(addedForm.getCustomEditionDate());

						validateFormVariableExistenceForForm(addedForm, manuscriptForm);
						listOfManuscriptsToBeAdded.add(manuscriptForm);
						break;
					}

				}

				if(!foundEntry){
					//Checking if form being added is already attached if so then throw error
					for(Form attachedForm:attachedForms.getForms()){
						String formIdfetched=attachedForm.getFormId()+"";
						long formIdToBeCompared=Long.parseLong(formIdfetched.substring(0,formIdfetched.length()-3));
						String newlyAddedFormId=addedForm.getFormId()+"";
						long newlyAddedFormIdToBeCompared=Long.parseLong(newlyAddedFormId);
						if(newlyAddedFormIdToBeCompared==formIdToBeCompared){
							addedForm.setFormId(newlyAddedFormIdToBeCompared);
							addedForm.setFormName(attachedForm.getFormName());
							addedForm.setRevision(attachedForm.getRevision());
							addedForm.setEditionDate(attachedForm.getEditionDate());
							addedForm.setCoveragePartReference(attachedForm.getCoveragePartReference());
							addedForm.setCoveragePart(attachedForm.getCoveragePart());
							addedForm.setUserOverride(attachedForm.getUserOverride());
							foundEntry=true;
							validateFormVariableExistenceForForm(addedForm, attachedForm);
							listOfFormsToBeAdded.add(addedForm);
							break;
						}
					}
				}

				//If not found under manuscript and attached then verifying if it is available under other qualified forms it yes then verify its variables
				if(!foundEntry){
					for(Form qualifyingForm:qualifyingFormsWithShowALL.getForms()){
						if(qualifyingForm.getFormId()==addedForm.getFormId()){
							foundEntry=true;
							validateFormVariableExistenceForForm(addedForm, qualifyingForm);
							listOfFormsToBeAdded.add(qualifyingForm);
							break;
						}
					}
				}

				//If added form not found all of them then throwing an exception
				if(!foundEntry){
					String errMsg = addedForm.getFormId()+" is not getting qualified for "+entityType+" "+entityReference+". It can't be added.";
					List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
					String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
					WebServiceLoggerUtil.logInfo("FormServiceImpl", "validateFormsToBeAddedToQuotePolicy", errMsg, new Object[] { errMsg });
					throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
				}
			}
		}else{
			String errMsg = "Form list is needed, it can't be empty.";
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			WebServiceLoggerUtil.logInfo("FormServiceImpl", "validateFormsToBeAddedToQuotePolicy", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
		}
	}

	public void validateFormVariableExistenceForForm(Form addedForm, Form formInSystem) throws APIException{
		
		//Checking if the variable getting added in the added form is available in the original form stored in system
		//And its value is not null.
		if(addedForm.getFormVariables()!=null && addedForm.getFormVariables().getFormVariables()!=null && addedForm.getFormVariables().getFormVariables().size()>0 
				&& formInSystem.getFormVariables()!=null &&  formInSystem.getFormVariables().getFormVariables()!=null && formInSystem.getFormVariables().getFormVariables().size()>0){
			for(FormVariable addedFormVariable:addedForm.getFormVariables().getFormVariables()){
				boolean foundValidEntry=false;
				for(FormVariable formVariableInSystem:formInSystem.getFormVariables().getFormVariables()){
					if(formVariableInSystem.getVariableName().equalsIgnoreCase(addedFormVariable.getVariableName())){
						if(addedFormVariable.getVariableValue()!=null){
							foundValidEntry=true;
							formVariableInSystem.setVariableValue(addedFormVariable.getVariableValue());
						}
						break;
					}
				}
				if(!foundValidEntry){
					String errMsg = "Variable "+addedFormVariable.getVariableName()+" is not found (or found with null value) under "+addedForm.getFormId();
					List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
					String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
					WebServiceLoggerUtil.logInfo("FormServiceImpl", "validateFormVariableExistenceForForm", errMsg, new Object[] { errMsg });
					throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
				}
			}
		}
	}
	
	//POLT-16056, POLT-16060
	@Override
	public Object copyFormToQuotePolicy()
	{
		ConfirmationMessage confirmationMessage = new ConfirmationMessage();
		
		Message message = new Message();
		
		try
		{
			IAPIContext requestContext = APIRequestContext.getApiRequestContext();
			
			User user = requestContext.getUser();
			
			Connection connection = requestContext.getConnection();
			
			requestContext.setAuditTrailLog(null);
			
			//POLT-16569
			validateCopyFeature(connection);
						
			validateRequest(user, connection);
			
			List<Form> formList = ((new ObjectMapper()).readValue((IOUtils.toString((request.getInputStream()), "UTF-8")), (Forms.class))).getForms();
			
			// POLT-16569
			//List<Form> attachedFormList = FormUtil.getAttachedForms(connection, entityReference, entityType, isBinder, true);
			List<Form> attachedFormList = FormUtil.extractCopyEligibleForms(connection, entityReference, entityType);
			
			Map<String, Object> validateFormsMap = validateForms(formList, attachedFormList);
			
			List<String> invalidFormList = (List<String>) validateFormsMap.get("INVALID");
			
			if ((null != invalidFormList) && ((invalidFormList.size()) > 0))
			{
				throw new APIException((APIConstant.INVALID_REQUEST_CODE), ("The operation has been aborted since the following Forms are invalid: " + invalidFormList), null, new Throwable());
			}
			else
			{
				List<Form> validFormList = (List<Form>) validateFormsMap.get("VALID");
				
				for (Form form : validFormList)
				{
					// POLT-16569
					//HashMap parameterMap = constructParameterMap(form, connection);
					
					//parameterMap = constructParameterMap(parameterMap, form, connection, (WorkflowUtil.checkIfBinder(connection, entityReference)));
					
					com.coverall.portal.soa.FormsService formsService = new com.coverall.portal.soa.FormsService();
					
					formsService.addManualAttachForms((requestContext.getMtUser()), (constructParameterMap(form, connection)));
				}
			}
			
			confirmationMessage.setCode(APIConstant.HTTP_CODE_SUCCESS);
			confirmationMessage.setDescription("The Forms have been copied successfully.");
		}
		catch (APIException e)
		{			
			throw new APIException(e.getErrorCode(), e.getErrorMessage(), e.getErrorMessageList(), new Throwable());
		}
		catch (Exception e)
		{
			errorMessageList = new ArrayList<Message>();
			
			message.setMoreinfo(e.getMessage());
			
			errorMessageList.add(message);

			throw new APIException(APIConstant.RUNTIME_EXCEPTION, APIConstant.FAILED, errorMessageList, e);
		}
		finally
		{
			APIRequestContext.getApiRequestContext().releaseContext();
		}
		
		return confirmationMessage;
	}

	//POLT-16056, POLT-16060
	private void validateRequest(User user, Connection connection)
	{
		String errorMessage = null;
		String httpStatusCode = null;
		
		try
		{
			if(!WorkflowUtil.checkIfUserHasTheRequiredPermission(user, APIConstant.FORM_MODIFY_PERMISSION))
			{
				errorMessage = user.getUserId() + " doesn't have permission to copy the forms.";
				
				httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			}

			if(!WorkflowUtil.checkIfPolicyExists(connection, entityReference, entityType))
			{
				errorMessage = entityReference + " doesn't exists please check input parameter.";

				httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
			}

			if (!WorkflowUtil.isWorkflowStageReached(connection, entityType, APIConstant.FORMSMANAGEMENT_TASK, entityReference))
			{
				errorMessage = "Form Management stage is not yet reached for the " + entityReference + ". Please check status of " + entityType;

				httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			}

			if (!WorkflowUtil.checkIfFormCanBeModifiedForTheEntity(user.getName(),connection, entityType, entityReference))
			{
				errorMessage = "Forms under " + entityReference + " cannot be modified/deleted. Please check the status of the " + entityType;

				httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			}
			
			if (null != httpStatusCode)
			{
				errorMessageList = getErrorMessageList(Collections.singletonList(errorMessage));
				
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "copyFormToQuotePolicy", errorMessage, new Object[] { errorMessage });
				
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST, errorMessageList, null);
			}
		}
		catch (Exception e)
		{
			throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST, errorMessageList, null);
		}
	}

	//POLT-16056, POLT-16060
	private Map<String, Object> validateForms(List<Form> formList, List<Form> attachedFormList)
	{
		Map<String, Object> validateFormsMap = new HashMap<String, Object>();
		
		try
		{
			boolean validityStatus;
			
			List<String> invalidFormList = new ArrayList<String>();
			
			List<Form> validFormList = new ArrayList<Form>();
			
			for (Form form: formList)
			{
				validityStatus = false;
				
				int copyCount = form.getNoOfCopies();
				
				for (Form attachedForm: attachedFormList)
				{					
					if ((form.getFormId()) == (attachedForm.getFormId()))
					{
						validityStatus = true;
						
						if ((!("Y".equalsIgnoreCase(attachedForm.getIsMultiAttach()))) || (copyCount < 1))
						{
							validityStatus = false;
							
							break;
						}
						
						if (validityStatus)
						{
							attachedForm.setNoOfCopies(copyCount);
							
							validFormList.add(attachedForm);
							
							break;
						}
					}
				}
				
				if (!validityStatus)
				{
					invalidFormList.add(String.valueOf(form.getFormId()));
				}
			}
			
			validateFormsMap.put("VALID", validFormList);
			validateFormsMap.put("INVALID", invalidFormList);
		}
		catch (Exception e)
		{
			errorMessageList = new ArrayList<Message>();
			
			message.setMoreinfo(e.getMessage());
			
			errorMessageList.add(message);

			throw new APIException(APIConstant.RUNTIME_EXCEPTION, APIConstant.FAILED, errorMessageList, e);
		}
		
		return validateFormsMap;
	}

	//POLT-16056, POLT-16060
	private HashMap constructParameterMap(Form form, Connection connection)
	{
		Map<String, String> parameterMap = new HashMap<String, String>();
		
		try
		{
			parameterMap.put(APIConstant.PARAMETER_FORM_INCLUSION, null);
			parameterMap.put(APIConstant.PARAMETER_SUB_ACTION, null);			
			parameterMap.put(APIConstant.PARAMETER_IS_MANUSCRIPT, "false");
			parameterMap.put(APIConstant.PARAMETER_IS_COPY_FORM, "true");
			parameterMap.put(APIConstant.PARAMETER_APPLICABLE_LOB_LISTS, "");
			
			parameterMap.put(APIConstant.PARAMETER_ID_LIST, (String.valueOf(form.getFormId())));
			parameterMap.put((APIConstant.PARAMETER_COPY_COUNT + "_" + (form.getFormId())), (String.valueOf(form.getNoOfCopies())));
			parameterMap.put(APIConstant.PARAMETER_MFO_POLICY_REFERENCE, entityReference);
			parameterMap.put((APIConstant.PARAMETER_MFO_ENTITY_TYPE + "_" + (form.getFormId())), entityType);
			parameterMap.put((APIConstant.PARAMETER_MFO_INCLUDE + "_" + (form.getFormId())), null);
			parameterMap.put((APIConstant.PARAMETER_MFO_RANK + "_" + (form.getFormId())), null);
			
			parameterMap.put((APIConstant.PARAMETER_MFO_COVERAGE_PART_REFERENCE + "_" + (form.getFormId())), (form.getCoveragePartReference()));
			parameterMap.put((APIConstant.PARAMETER_MFO_FORM_NUMBER + "_" + (form.getFormId())), (form.getFormName()));
			parameterMap.put((APIConstant.PARAMETER_MFO_FORM_EDITION_DATE + "_" + (form.getFormId())), (form.getEditionDate()));
			parameterMap.put((APIConstant.PARAMETER_MFV_OCCR + "_" + (form.getFormId())), "");
			parameterMap.put((APIConstant.PARAMETER_MFO_OCCURRENCE + "_" + (form.getFormId())), "");
			parameterMap.put((APIConstant.PARAMETER_MFO_REVISION_NUMBER + "_" + (form.getFormId())), "");
			
			// POLT-16569
			parameterMap.put((HTTPConstants.REQUEST_ACTIVITY_ID), (String.valueOf(WorkflowUtil.getActivityIdForTheTask(connection, (APIConstant.FORMSMANAGEMENT_TASK), entityReference, entityType))));
			parameterMap.put(APIConstant.PARAMETER_IS_FORM_INTERLINE, (form.getIsInterline()));
			parameterMap.put((APIConstant.PARAMETER_MFO_QUALIFYING_LOBS + "_" + (form.getFormId())), (form.getQualifyingLOBs()));
			parameterMap.put((APIConstant.PARAMETER_MFO_USER_DELETE_OVERRIDE + "_" + (form.getFormId())), (form.getUserOverride()));
		}
		catch (Exception e)
		{
			errorMessageList = new ArrayList<Message>();
			
			message.setMoreinfo(e.getMessage());
			
			errorMessageList.add(message);

			throw new APIException(APIConstant.RUNTIME_EXCEPTION, APIConstant.FAILED, errorMessageList, e);
		}
		
		return ((HashMap) parameterMap);
	}

	//POLT-16056, POLT-16060
	private HashMap constructParameterMap(HashMap parameterMap, Form form, Connection connection, boolean isBinder)
	{
		PreparedStatement preparedStatement = null;
		
		ResultSet resultSet = null;
		
		try
		{
			StringBuilder constructParameterMapSQL = new StringBuilder("");
			
			constructParameterMapSQL.append("SELECT MFO_QUALIFYING_LOBS, PDT_IS_INTERLINE AS IS_FORM_INTERLINE, MFO_USER_DELETE_OVERRIDE ");
			constructParameterMapSQL.append("FROM MIS_FORMS, PS_DOCUMENT_TEMPLATE ");
			constructParameterMapSQL.append("WHERE PDT_NAME = MFO_FORM_NUMBER ");
			constructParameterMapSQL.append("AND MFO_COVERAGE_PART_REFERENCE = ? ");
			constructParameterMapSQL.append("AND MFO_POLICY_REFERENCE = ? ");
			constructParameterMapSQL.append("AND MFO_FORM_NUMBER = ? ");
			constructParameterMapSQL.append("AND MFO_ENTITY_TYPE  = ? ");
			constructParameterMapSQL.append("AND ROWNUM  < 2");
			
			preparedStatement = connection.prepareStatement(String.valueOf(constructParameterMapSQL));
			
			preparedStatement.setString(1, (form.getCoveragePartReference()));
			preparedStatement.setString(2,  entityReference);
			preparedStatement.setString(3, (form.getFormName()));
			
			if(isBinder)
			{
				preparedStatement.setString(4, "BINDER");
			}
			else
			{
				preparedStatement.setString(4, entityType);
			}
			
			resultSet = preparedStatement.executeQuery();
			
			while (resultSet.next())
			{
				parameterMap.put(APIConstant.PARAMETER_IS_FORM_INTERLINE, (resultSet.getString(APIConstant.PARAMETER_IS_FORM_INTERLINE)));
				parameterMap.put((APIConstant.PARAMETER_MFO_QUALIFYING_LOBS + "_" + (form.getFormId())), (resultSet.getString(APIConstant.PARAMETER_MFO_QUALIFYING_LOBS)));
				parameterMap.put((APIConstant.PARAMETER_MFO_USER_DELETE_OVERRIDE + "_" + (form.getFormId())), (resultSet.getString(APIConstant.PARAMETER_MFO_USER_DELETE_OVERRIDE)));
			}
		}
		catch (Exception e)
		{
			errorMessageList = new ArrayList<Message>();
			
			message.setMoreinfo(e.getMessage());
			
			errorMessageList.add(message);

			throw new APIException(APIConstant.RUNTIME_EXCEPTION, APIConstant.FAILED, errorMessageList, e);
		}
		finally
		{
			try
			{
				if (preparedStatement != null)
				{
					preparedStatement.close();
				}
				
				if (resultSet != null)
				{
					resultSet.close();
				}
			}
			catch (SQLException e)
			{
				e.printStackTrace();
			}
		}
		
		return parameterMap;
	}

	//POLT-16569
	private void validateCopyFeature(Connection connection)
	{
		PreparedStatement preparedStatement = null;
		
		ResultSet resultSet = null;
		
		try
		{
			StringBuilder validateCopyFeatureSQL = new StringBuilder("");
			
			validateCopyFeatureSQL.append("SELECT DECODE(COUNT(1),0,'N','Y') COPY_FORM_OPTION_VALUE ");
			validateCopyFeatureSQL.append("FROM MIS_PRODUCT_OPTIONS_ASSN ");
			validateCopyFeatureSQL.append("WHERE IPI_FEATURE_CODE = ? ");
			validateCopyFeatureSQL.append("AND IPI_PRODUCT_CODE = ( ");
			validateCopyFeatureSQL.append("SELECT PRODUCT_CODE ");
			validateCopyFeatureSQL.append("FROM VW_MIS_QUOTE_POLICIES ");
			validateCopyFeatureSQL.append("WHERE ENTITY_REFERENCE = ? ");
			validateCopyFeatureSQL.append("AND ENTITY_TYPE = ? ) ");
			validateCopyFeatureSQL.append("AND NVL(IPI_FEATURE_SELECTED, IPI_FEATURE_DEFAULT) = 'Y'");
			
			preparedStatement = connection.prepareStatement(String.valueOf(validateCopyFeatureSQL));
			
			preparedStatement.setString(1, "COPY_FORM");
			preparedStatement.setString(2, entityReference);
			preparedStatement.setString(3, entityType);
			
			resultSet = preparedStatement.executeQuery();
			
			while (resultSet.next())
			{
				if (!("Y".equalsIgnoreCase(resultSet.getString("COPY_FORM_OPTION_VALUE"))))
				{
					throw new APIException((APIConstant.INVALID_REQUEST_CODE), ("The feature of Copying Forms has been disabled for this Product."), null, new Throwable());
				}
			}			
		}
		catch (Exception e)
		{
			throw new APIException((APIConstant.INVALID_REQUEST_CODE), ("The feature of Copying Forms has been disabled for this Product."), null, new Throwable());
		}
		finally
		{
			try
			{
				if (preparedStatement != null)
				{
					preparedStatement.close();
				}
				
				if (resultSet != null)
				{
					resultSet.close();
				}
			}
			catch (SQLException e)
			{
				e.printStackTrace();
			}
		}
	}
}