package com.coverall.mic.rest.policy.api.forms.service.impl;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import org.apache.commons.lang.StringUtils;
import org.apache.cxf.helpers.IOUtils;
import org.codehaus.jackson.map.ObjectMapper;

import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.forms.model.Form;
import com.coverall.mic.rest.policy.api.forms.model.FormVariable;
import com.coverall.mic.rest.policy.api.forms.model.FormVariables;
import com.coverall.mic.rest.policy.api.forms.model.Forms;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.forms.dao.FormVariableVo;
import com.coverall.mic.rest.policy.api.service.forms.util.FormUtil;
import com.coverall.mic.rest.policy.api.service.model.ConfirmationMessage;
import com.coverall.mic.rest.policy.api.service.model.common.Items;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.WorkflowUtil;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.portal.services.FormsWorkFlowService;
import com.coverall.security.authentication.User;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;

public class FormsServiceImplVersion3 extends FormsServiceImpl {

	public FormsServiceImplVersion3(String entityReference, String entityType, HttpServletRequest request) {
		this.entityReference = entityReference;
		this.entityType = entityType;
		this.request=request;
	}
	
	@Override
	public FormVariables getAttachedFormsVariables(String formId) {
		String occurance="0";
		Message message = new Message();
		FormVariables formVariables = new FormVariables();
		boolean isBinder = false;
		
		try {
			
			if(!FormUtil.validatFormIdFormat(formId)){
				String errMsg = formId+APIConstant.INVALID_FORM_ID_FORMAT;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "getAttachedFormsVariables", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}
			
			Connection conn = APIRequestContext.getApiRequestContext().getConnection();
			
			if(!WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)) {
				errorMessageList = new ArrayList<Message>();
				message.setMoreinfo(APIConstant.INVALID_REQUEST);
				errorMessageList.add(message);

				throw new APIException(APIConstant.POLICY_NOT_EXISTS_CODE,APIConstant.FAILED,errorMessageList,new Throwable());
			}
			
			occurance=formId.substring(formId.length()-3);
			formId=formId.substring(0, formId.length()-3);
			
			
			if (!WorkflowUtil.checkIfFormPresent(conn, entityReference,formId, occurance)) {
				errorMessageList = new ArrayList<Message>();
				message.setMoreinfo(APIConstant.FORM_NOT_EXISTS);
				errorMessageList.add(message);
				throw new APIException(APIConstant.FORM_NOT_EXISTS_CODE,APIConstant.FAILED,errorMessageList,new Throwable());		
			}
			
			
			String entityType = APIConstant.ENTITY_QUOTE;

			boolean isPolicyEntity = WorkflowUtil.getEntityType(conn, entityReference);

			if (isPolicyEntity) {
				entityType = APIConstant.ENTITY_POLICY;
			}

			isBinder = WorkflowUtil.checkIfBinder(conn, entityReference);


			if (!WorkflowUtil.isWorkflowStageReached(conn, entityType, APIConstant.FORMSMANAGEMENT_TASK,
					entityReference)) {
				errorMessageList = new ArrayList<Message>();
				message.setMoreinfo(APIConstant.WORKFLOW_NOT_EXISTS);
				errorMessageList.add(message);

				throw new APIException(APIConstant.WORKFLOW_NOT_EXISTS_CODE,APIConstant.FAILED,errorMessageList,new Throwable());		

			}
			
			List<FormVariable> formVariablesFromDB=FormUtil.getFormVaraiblesV3(conn, entityReference, formId , isBinder, entityType,occurance);

			if(formVariablesFromDB.size() == 0) {
				errorMessageList = new ArrayList<Message>();
				message.setMoreinfo(APIConstant.FORM_VAR_NOT_EXISTS);
				errorMessageList.add(message);

				throw new APIException(APIConstant.FORM_VAR_NOT_EXISTS_CODE,APIConstant.FAILED,errorMessageList,new Throwable());		


			}

			formVariables.setFormVariables(formVariablesFromDB);

			return formVariables;

		} catch (APIException e) {
			throw new APIException(e.getErrorCode(),e.getErrorMessage(),e.getErrorMessageList(),new Throwable());

		}



		catch (java.lang.Exception e) {
			errorMessageList = new ArrayList<Message>();
			message.setMoreinfo(e.getMessage());
			errorMessageList.add(message);

			throw new APIException(APIConstant.RUNTIME_EXCEPTION,APIConstant.FAILED,errorMessageList,new Throwable());	
		}
	}
	
	@Override
	public Object addFormToQuotePolicy() {
		ConfirmationMessage response=null;
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		User user=requestContext.getUser();
		long sourceSystemRequestNo=System.currentTimeMillis();
		//requestContext.setAuditTrailLog(null);
		try {
			Connection conn = requestContext.getConnection();

			if(!WorkflowUtil.checkIfUserHasTheRequiredPermission(user, APIConstant.FORM_MODIFY_PERMISSION)) {
				String errMsg = user.getUserId()+" doesn't have permission to delete the forms.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "addFormToQuotePolicy", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}

			if(!WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)) {
				String errMsg = entityReference+" doesn't exists please check input parameter.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "addFormToQuotePolicy", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}

			if (!WorkflowUtil.isWorkflowStageReached(conn, entityType, APIConstant.FORMSMANAGEMENT_TASK,
					entityReference)) {
				String errMsg = "Form Management stage is not yet reached for the "+entityReference+". Please check status of "+entityType;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "addFormToQuotePolicy", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}

			if (!WorkflowUtil.checkIfFormCanBeModifiedForTheEntity(user.getName(),conn, entityType, entityReference)) {
				String errMsg = "Forms under "+entityReference+" cannot be modified/deleted. Please check the status of the "+entityType;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "addFormToQuotePolicy", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}
			
			ObjectMapper mapper=new ObjectMapper();
			String inputJson=APIOperationUtil.fetchRequestBody(request);
			Forms formsToBeAdded=mapper.readValue(inputJson, Forms.class);
			
			List<Form> listOfFormsToBeAdded=new ArrayList<Form>();
			List<Form> listOfManuscriptsToBeAdded=new ArrayList<Form>();
			validateAndListFormsToBeAddedToQuotePolicy(user,conn,formsToBeAdded,sourceSystemRequestNo,listOfFormsToBeAdded,listOfManuscriptsToBeAdded);
			
			
			Map<String,Form> formMapWithIssues=new HashMap<String, Form>();
			Map<String,Form> formMapAddedSuccessfully=new HashMap<String, Form>();
			
			for(Form manuscriptForms:listOfManuscriptsToBeAdded){
				try{
					FormUtil.addFormToQuotePolicy(user, conn, entityType, entityReference, manuscriptForms, "Y");
					formMapAddedSuccessfully.put(manuscriptForms.getFormId()+"",manuscriptForms);
				}catch(APIException exp){
					formMapWithIssues.put(manuscriptForms.getFormId()+"",manuscriptForms);
				}
			}
			
			for(Form formToBeAdded:listOfFormsToBeAdded){
				try{
					FormUtil.addFormToQuotePolicy(user, conn, entityType, entityReference, formToBeAdded, "N");
					formMapAddedSuccessfully.put(formToBeAdded.getFormId()+"",formToBeAdded);
				}catch(APIException exp){
					formMapWithIssues.put(formToBeAdded.getFormId()+"",formToBeAdded);
				}
			}
			
			try{
			  Map emptyParamMap=new HashMap();
			  FormsWorkFlowService.updateFormExpressionVariables(conn,
					  entityReference,
					  com.coverall.mt.http.User.getUser(request),
					  emptyParamMap);
			}catch (Exception exc){
			    conn.rollback();
			  	String errMsg = "Error resolving form variable expressions:"+exc.getMessage()+". Changes will be rolledback.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "addFormToQuotePolicy", errMsg, new Object[] { exc.getStackTrace() });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
		  
		  conn.commit();
		  FormUtil.reRankFormsForQuotePolicy(conn, entityReference);
		  boolean isBinder = WorkflowUtil.checkIfBinder(conn, entityReference);
		  
		  //boolean exceptionOccuredWhileAddingVariables=false;
		  response=new ConfirmationMessage();
		
		  
		  //Merging 2 lists
		  List<Form> combinedList=new ArrayList<Form>();
		  combinedList.addAll(listOfManuscriptsToBeAdded);
		  combinedList.addAll(listOfFormsToBeAdded);
		  List<String> varsWithIssues=new ArrayList<String>();
		  Map<String,Form> formMapFaliedWhileAddingVariable=new HashMap<String, Form>();

		  for(Form formInFocus:combinedList){
			  if(!formMapWithIssues.containsKey(formInFocus.getFormId()+"")){	  
				  FormVariables variableList=formInFocus.getFormVariables();
				  if(variableList != null && variableList.getFormVariables() != null) {
					  for(int i=0;i<variableList.getFormVariables().size();i++){
						  if(formInFocus.getFormVariables().getFormVariables().get(i).getVariableValue()!=null){
							  try{

								  String formId = formInFocus.getFormId()+"";
								  String occurance=formId.substring(formId.length()-3);
								  formId=formId.substring(0, formId.length()-3);


								  FormVariableVo variableVo = FormUtil.getFormVaraibleDetailDataV3(conn, entityReference,
										  Integer.parseInt(formId), variableList.getFormVariables().get(i),
										  entityType, isBinder, occurance);
								  // Validating Form Variables
								  FormUtil.validateFormVariables(variableVo,
										  variableList.getFormVariables().get(i).getVariableValue());

								  if ("RICHTEXT".equalsIgnoreCase(variableVo.getFormVarType())) {
									  FormUtil.updateFormRichTextVariable(conn, entityReference, variableVo,
											  formInFocus.getFormId(),
											  variableList.getFormVariables().get(i).getVariableValue());

								  } else {
									  FormUtil.updateFormVariable(conn, entityReference, variableVo, formInFocus.getFormId(),
											  variableList.getFormVariables().get(i).getVariableValue());
								  }
								  formMapAddedSuccessfully.put(formInFocus.getFormId()+"",formInFocus);
							  }catch(Exception exp){
								  formMapFaliedWhileAddingVariable.put(formInFocus.getFormId()+"", formInFocus);
								  varsWithIssues.add(formInFocus.getFormVariables().getFormVariables().get(i).getVariableName()+" under "+formInFocus.getFormId());
								  formMapAddedSuccessfully.remove(formInFocus.getFormId()+"");
								  break;
								  //exceptionOccuredWhileAddingVariables=true;
							  }
						  }
					  }
				  }
			  }
		  }
		  
		  if (FormUtil.isAnyVariableIncomplete(entityReference, entityType, conn)) {
			  WorkflowUtil.setBlocked(conn, WorkflowUtil.getActivityID(conn, entityType, entityReference, APIConstant.FORMSMANAGEMENT_TASK), "Forms Management - User input required");
		  }
		  

		  if(formMapFaliedWhileAddingVariable.size()>0){
			  Object[] formIdsToBedeleted= formMapFaliedWhileAddingVariable.keySet().toArray();
			  String[] finalListToBeDeleted = new String[formIdsToBedeleted.length];
			  System.arraycopy(formIdsToBedeleted, 0, finalListToBeDeleted, 0, formIdsToBedeleted.length);
			  deleteFormFromQuotePolicy(finalListToBeDeleted);
		  }

		  String responseMessage="";
		  String code="200";
		  if(formMapAddedSuccessfully.size()>0){
			  responseMessage="Forms "+StringUtils.join(formMapAddedSuccessfully.keySet(), ',')+" added successfully.";
		  }

		  if(formMapWithIssues.size()>0){
			  responseMessage+=" There is an issue while adding "+StringUtils.join(formMapWithIssues.keySet(), ',')+" forms initially.";
		  }

		  if(formMapFaliedWhileAddingVariable.size()>0){
			  responseMessage+=" Forms failed while adding variables, listed are variables and corresponding forms :"+StringUtils.join(varsWithIssues, ','); 
		  }

		  if(formMapAddedSuccessfully.size()>0 && (formMapFaliedWhileAddingVariable.size()>0 || formMapWithIssues.size()>0)){
			  code+="- Partially Successful";
		  }else if(formMapAddedSuccessfully.size()==0){
			  code+="- No Form Added";
		  }

		  response.setCode(code);
		  response.setDescription(responseMessage);
			  
		} catch (APIException e) {
			throw new APIException(e.getErrorCode(),e.getErrorMessage(),e.getErrorMessageList(),new Throwable());
		}catch (Exception e) {
			errorMessageList = new ArrayList<Message>();
			message.setMoreinfo(e.getLocalizedMessage());
			errorMessageList.add(message);
			throw new APIException(APIConstant.RUNTIME_EXCEPTION,APIConstant.FAILED,errorMessageList,new Throwable());	
		}
		return response;
	}

	@Override
	public Object updateFormVariables(String formId, HttpServletRequest request) {
		
		String occurance="0";
		long activityID = 0;
		boolean isBinder = false;

		boolean shouldExecute = false;
		Message message = new Message();

		try {
			
			if(!FormUtil.validatFormIdFormat(formId)){
				String errMsg = formId+APIConstant.INVALID_FORM_ID_FORMAT;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "updateFormVariables", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}
			
			IAPIContext requestContext = APIRequestContext.getApiRequestContext();
			//requestContext.setAuditTrailLog(null);

			Connection conn = requestContext.getConnection();
			
			ObjectMapper mapper=new ObjectMapper();
			String inputJson=APIOperationUtil.fetchRequestBody(request);
			FormVariables formVariables=mapper.readValue(inputJson, FormVariables.class);
			
			if(!WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)) {
				errorMessageList = new ArrayList<Message>();
				message.setMoreinfo(APIConstant.INVALID_REQUEST);
				errorMessageList.add(message);

				throw new APIException(APIConstant.POLICY_NOT_EXISTS_CODE,APIConstant.FAILED,errorMessageList,new Throwable());
			}
			
			String entityType = APIConstant.ENTITY_QUOTE;

			boolean isPolicyEntity = WorkflowUtil.getEntityType(conn, entityReference);
			isBinder = WorkflowUtil.checkIfBinder(conn, entityReference);

			if (isPolicyEntity) {
				entityType = APIConstant.ENTITY_POLICY;
			}
			
			occurance=formId.substring(formId.length()-3);
			formId=formId.substring(0, formId.length()-3);
			

			if (!WorkflowUtil.checkIfFormPresent(conn, entityReference,formId,occurance)) {
				errorMessageList = new ArrayList<Message>();
				message.setMoreinfo(APIConstant.WORKFLOW_NOT_EXISTS);
				errorMessageList.add(message);

				throw new APIException(APIConstant.WORKFLOW_NOT_EXISTS_CODE, APIConstant.FAILED, errorMessageList,
						new Throwable());
			}

			if (!WorkflowUtil.isWorkflowStageReached(conn, entityType, APIConstant.FORMSMANAGEMENT_TASK,
					entityReference)) {
				errorMessageList = new ArrayList<Message>();
				message.setMoreinfo(APIConstant.WORKFLOW_NOT_EXISTS);
				errorMessageList.add(message);

				throw new APIException(APIConstant.WORKFLOW_NOT_EXISTS_CODE, APIConstant.FAILED, errorMessageList,
						new Throwable());
			}

			if (isPolicyEntity) {
				if (WorkflowUtil.checkIfPolicyBooked(conn, entityReference)) {
					errorMessageList = new ArrayList<Message>();
					message.setMoreinfo(APIConstant.POLICY_BOOKED);
					errorMessageList.add(message);

					throw new APIException(APIConstant.POLICY_BOOKED_CODE, APIConstant.FAILED, errorMessageList,
							new Throwable());
				}
			} else {
				if (APIConstant.CONVERTED_TO_POLICY
						.equalsIgnoreCase(WorkflowUtil.getCurrentPolicyStatus(entityReference, entityType, conn))) {
					errorMessageList = new ArrayList<Message>();
					message.setMoreinfo(APIConstant.QUOTE_HAVING_NEW_REVISION);
					errorMessageList.add(message);

					throw new APIException(APIConstant.INVALID_REQUEST_CODE, APIConstant.FAILED,
							errorMessageList, new Throwable());
				}

			}

			if (null != formVariables && formVariables.getFormVariables().size() == 0) {
				errorMessageList = new ArrayList<Message>();
				message.setMoreinfo(APIConstant.FORM_VAR_NOT_EXISTS);
				errorMessageList.add(message);

				throw new APIException(APIConstant.FORM_VAR_NOT_EXISTS_CODE, APIConstant.FAILED, errorMessageList,
						new Throwable());
			} 
			
			if (!WorkflowUtil.hasFormModifyPermission(requestContext.getUser().getDomain(),
					requestContext.getUser().getUserId().substring(0,requestContext.getUser().getUserId().indexOf("@") ))) {
				errorMessageList = new ArrayList<Message>();
				message.setMoreinfo(APIConstant.USER_PERMISSION_NOT_EXISTS);
				errorMessageList.add(message);

				throw new APIException(APIConstant.USER_PERMISSION_NOT_EXISTS_CODE, APIConstant.FAILED,
						errorMessageList, new Throwable());

			}
			
			List <FormVariableVo> formVariableVO=new ArrayList<FormVariableVo>();
			//Validating if the variables and creating list of varialble VO
			for (int i = 0; i < formVariables.getFormVariables().size(); i++) {
				
				
				String formVariableOccurance=occurance;
				String providedVariableOccurnace=formVariables.getFormVariables().get(i).getVariableOccurrence();
				if(providedVariableOccurnace!=null && providedVariableOccurnace.trim().length() != 0){
					formVariableOccurance=providedVariableOccurnace;
				}
				
				if (!WorkflowUtil.checkIfFormVariableIsAvailableV3(conn, entityReference, Integer.parseInt(formId),
						formVariables.getFormVariables().get(i).getVariableName(),formVariableOccurance)) {
					errorMessageList = new ArrayList<Message>();
					message.setMoreinfo(APIConstant.FORM_VAR_DATA_INVALID);
					errorMessageList.add(message);

					throw new APIException(APIConstant.FORM_VAR_DATA_INVALID_CODE, APIConstant.FAILED, errorMessageList,
							new Throwable());
				}
				
				FormVariableVo variableVo = FormUtil.getFormVaraibleDetailDataV3(conn, entityReference,
						Integer.parseInt(formId), formVariables.getFormVariables().get(i),
						entityType, isBinder, formVariableOccurance);
				
				// Validating Form Variables
				FormUtil.validateFormVariables(variableVo,
						formVariables.getFormVariables().get(i).getVariableValue());
				
				formVariableVO.add(variableVo);
			}

			for (int i = 0; i < formVariableVO.size(); i++) {
				
				FormVariableVo variableVo =formVariableVO.get(i);

					// Check the stage
					// Block the Stage

					activityID = WorkflowUtil.getActivityID(conn, entityType, entityReference,
							APIConstant.FORMSMANAGEMENT_TASK);

					// WorkflowUtil.getStageDesc(conn, policyReference, activityID);
					Map<String, String> status = WorkflowUtil.getCurrentWorkflowStatus(conn, entityType,
							entityReference, APIConstant.FORMSMANAGEMENT_TASK);

					if (null != status && !status.isEmpty()
							&& !status.get(APIConstant.TASK_STATUS).trim().toUpperCase().equalsIgnoreCase("BLOCK")) {
						WorkflowUtil.setBlocked(conn, activityID, status.get(APIConstant.TASK_STATUS));
						shouldExecute = true;
					} else {
						shouldExecute = true;

					}

					if (shouldExecute) {
						if (variableVo.getFormVarType().equalsIgnoreCase("RICHTEXT")) {
							FormUtil.updateFormRichTextVariable(conn, entityReference, variableVo,
									Integer.parseInt(formId),
									formVariableVO.get(i).getFormVarModifiedValue());
						} else {
							FormUtil.updateFormVariable(conn, entityReference, variableVo, Integer.parseInt(formId),
									formVariableVO.get(i).getFormVarModifiedValue());
						}

					}
				}

			if (FormUtil.isAnyVariableIncomplete(entityReference, entityType, conn)) {

			    errorMessageList = new ArrayList<Message>();
			    message.setMoreinfo(APIConstant.MANDATORY_VARIABLE_EXISTS);
				errorMessageList.add(message);

				throw new APIException(APIConstant.MANDATORY_VARIABLE_EXISTS_CODE, APIConstant.PARTIALLY_SUCCESSFUL,
						errorMessageList, new Throwable());
			    

			} else {
			    
				WorkflowUtil.setComplete(activityID, conn, requestContext.getUser().getUserId());
                Items item = new Items();
                item.setSystemerrcode("Successful");
                message.setItem(item);
				message.setMoreinfo("Successfully updated the form variables and triggered the next workflow. ");
				

			}

		} catch (APIException e) {
			throw e;
		}catch (java.lang.Exception e) {
			errorMessageList = new ArrayList<Message>();
			message.setMoreinfo(e.getMessage());
			errorMessageList.add(message);

			throw new APIException(APIConstant.RUNTIME_EXCEPTION, APIConstant.FAILED, errorMessageList,
					new Throwable());

		}

		return message;

	}
}
