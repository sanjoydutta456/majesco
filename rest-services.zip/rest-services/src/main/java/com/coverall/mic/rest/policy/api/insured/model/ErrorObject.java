package com.coverall.mic.rest.policy.api.insured.model;

public class ErrorObject {
	private String jasonPath;
	private String message;
	private String messageType;
	
	
	public String getJasonPath() {
		return jasonPath;
	}
	public void setJasonPath(String jasonPath) {
		this.jasonPath = jasonPath;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getMessageType() {
		return messageType;
	}
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}
	@Override
	public String toString() {
		return "ErrorObject [jasonPath=" + jasonPath + ", message=" + message + ", messageType=" + messageType + "]";
	}

}
