package com.coverall.mic.rest.policy.api.insured.service.impl;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import com.coverall.el.QueryWithBindVariables;
import com.coverall.mic.rest.policy.api.customer.service.impl.CustomerUtil;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.insured.model.ServiceResponseData;
import com.coverall.mic.rest.policy.api.insured.service.InsuredService;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.pctv2.server.service.IPCTRequestContext;
import com.coverall.portal.dao.InsuredDAO;
import com.coverall.util.DBUtil;
import com.coverall.mt.fm.FolderManager;

public class InsuredServiceImpl implements InsuredService {

	
	public InsuredServiceImpl() {
	
	}

		
	@Override
	public Object deleteInsured(String insuredId, HttpServletRequest request) {
		
		ServiceResponseData serviceResponseData = new ServiceResponseData();
		HashMap params = new HashMap();
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		String insuredReference = "";
		try {
			User user = APIRequestContext.getApiRequestContext().getMtUser();
			String sourceSystemUserId = request.getParameter("sourceSystemUserId")!=null ? request.getParameter("sourceSystemUserId"): null;
			Connection conn = requestContext.getConnection();			
			
			if(!InsuredUtil.insuredExist(insuredId,sourceSystemUserId)) {
				
				String errMsg = insuredId + APIConstant.INSURED_NOT_EXISTS;
				List <Message> errorMessageList = InsuredUtil.getErrorMessageList(Collections.singletonList(errMsg));
				WebServiceLoggerUtil.logInfo("InsuredServiceImpl", "deleteInsured", errMsg, new Object[] { errMsg });
				throw new APIException(String.valueOf(Response.Status.NOT_FOUND.getStatusCode()),
						APIConstant.FAILED, errorMessageList, null);
			}
			
			insuredReference = InsuredUtil.getInsuredEntityReference(insuredId);
			
			if(!InsuredUtil.checkIfDeleteTransactionAvaiable(user,insuredReference)) {
				
				String errMsg = insuredId + APIConstant.INSURED_DELETE;
				List <Message> errorMessageList = InsuredUtil.getErrorMessageList(Collections.singletonList(errMsg));
				WebServiceLoggerUtil.logInfo("InsuredServiceImpl", "deleteInsured", errMsg, new Object[] { errMsg });
				throw new APIException(String.valueOf(Response.Status.NOT_FOUND.getStatusCode()),
						APIConstant.FAILED, errorMessageList, null);
			}
			
			String folderId = InsuredUtil.getFolderId(insuredId);
			
			if(null != folderId && !"".equalsIgnoreCase(folderId)){
				long sourceFolderId = Long.parseLong(folderId); 
				FolderManager folderManager = FolderManager.getInstance(user);
				folderManager.deleteFolder(sourceFolderId, user);
			}
			
			InsuredDAO insuredDao=new InsuredDAO();
			HashMap<String, String> userData=new HashMap<String, String>();
			userData.put("_entityType", "INSURED");
			userData.put("_entityReference", insuredReference);
			
			insuredDao.initialise(user,userData);
			insuredDao.delete(conn);
			
			serviceResponseData.setStatusCode("200");
			serviceResponseData.setResponseMessage(insuredId+" insured is deleted successfully.");
			serviceResponseData.setInsuredId(insuredId);

			
			
		} catch (APIException e) {
			WebServiceLoggerUtil.logError("InsuredServiceImpl", "deleteInsured", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw e;
		} catch (Exception e) {
			List <Message> errorMessageList = InsuredUtil.getErrorMessageList(Collections.singletonList(e.getMessage()));
			WebServiceLoggerUtil.logError("InsuredServiceImpl", "deleteInsured", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
					APIConstant.FAILED, errorMessageList,e);
		} 	
		return serviceResponseData;
	}



	@Override
	public String ping() {
		// TODO Auto-generated method stub
		return null;
	}

}
