package com.coverall.mic.rest.policy.api.insured.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

import javax.ws.rs.core.Response;

import com.coverall.el.FunctionResolver;
import com.coverall.el.InlineExpression;
import com.coverall.el.QueryWithBindVariables;
import com.coverall.el.VariableResolver;
import com.coverall.el.function.DefaultFunctionResolver;
import com.coverall.mic.rest.policy.api.customer.model.CustomerNote;
import com.coverall.mic.rest.policy.api.customer.model.CustomerRequest;
import com.coverall.mic.rest.policy.api.customer.model.PolicyEntity;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.UnifiedSearchErrors;
import com.coverall.mt.dao.QueriesCache;
import com.coverall.mt.el.variable.VariableResolverImpl;
import com.coverall.mt.http.HTTPConstants;
import com.coverall.mt.http.MICSession;
import com.coverall.mt.http.User;
import com.coverall.mt.policytrans.PolicyTransactionDetailsVO;
import com.coverall.mt.policytrans.TransactionService;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;
import com.coverall.util.GeneralUtil;

public class InsuredUtil {
	
	
	public static boolean insuredExist(String insuredId,String sourceSystemUserId) {
		boolean insuredExist = false;
		int count = 0;
		String query = "";
		Connection conn = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		HashMap<String, String> row = null;
		try {
			conn = APIRequestContext.getApiRequestContext().getConnection();
			
			query = "select count(*) COUNT from VW_MIS_INSUREDS where GID=? and ENTITY_TYPE=? ";

			statement = conn.prepareStatement(query);
			statement.setString(1, insuredId);
			statement.setString(2, "INSURED");
			WebServiceLoggerUtil.logInfo("InsuredUtil", "insuredExist", query, new Object[] { query });
			rs = statement.executeQuery();
			
			while (rs.next()){
				count = rs.getInt("COUNT");            
	        }
			
			if(count>0){
				insuredExist = true;
			}
			
		} catch (Exception e) {
			WebServiceLoggerUtil.logError("InsuredUtil", "insuredExist", e.getLocalizedMessage(), new Object[] { query, conn }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);

		}finally {
			try {
                DBUtil.close(rs, statement, null);                
			} catch (SQLException e) {
				WebServiceLoggerUtil.logError("InsuredUtil", "insuredExist", e.getLocalizedMessage(), new Object[] { query, conn }, e);
				throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);
			}
		}
		return insuredExist;
	}
	
	
	
		
	public static boolean checkIfDeleteTransactionAvaiable(User user,String entityReference) {
		boolean deleteTransactionAvaiable = false;
		TransactionService transactionService = new TransactionService();
        List<PolicyTransactionDetailsVO> availableTransactionList = null;
		
		try {
			String roles = user.getRoleList();
            availableTransactionList = transactionService.getAvailableTransactions(
                    "INSURED",
                    entityReference,
                    user,
                    "N",
                    roles,
                    null);
            Map<String, String> transParams = new HashMap<String, String>();
            for(int i =0;i< availableTransactionList.size();i++) {
            	PolicyTransactionDetailsVO transVo = availableTransactionList.get(i);
            	transParams = transVo.getParams();
	            if(!transParams.isEmpty()) {
	            	String dbTransName = transParams.get("mic_transaction_name");
	            	if(dbTransName.equalsIgnoreCase("Delete")) {
	            		deleteTransactionAvaiable=true;
	            	}
	            }
            	
            }
			
			
		} catch (APIException e) {
			WebServiceLoggerUtil.logError("CustomerUtil", "checkIfDeleteTransactionAvaiable", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw e;
		} catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));
			WebServiceLoggerUtil.logError("CustomerUtil", "checkIfDeleteTransactionAvaiable", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
					APIConstant.FAILED, errorMessageList,e);
		}
		return deleteTransactionAvaiable;
	}
	
	public static List<Message> getErrorMessageList(List<String> strMessages)	{
		if(strMessages == null)	{
			return null;
		}
		List<Message> errorMessageList = new ArrayList<Message>(strMessages.size());
		for(String aMsg : strMessages)	{
			Message message = new Message();
			message.setMoreinfo(aMsg);
			errorMessageList.add(message);
		}
		return errorMessageList;
	}
	
	public static String getInsuredEntityReference(String insuredId){
		String entityRef = "";
		String query = "";
		Connection conn = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		HashMap<String, String> row = null;
		try {
			conn = APIRequestContext.getApiRequestContext().getConnection();
			
			query = "select ENTITY_REFERENCE from VW_MIS_INSUREDS where GID=? and ENTITY_TYPE=? ";

			statement = conn.prepareStatement(query);
			statement.setString(1, insuredId);
			statement.setString(2, "INSURED");
			WebServiceLoggerUtil.logInfo("InsuredUtil", "getInsuredEntityReference", query, new Object[] { query });
			rs = statement.executeQuery();
			
			while (rs.next()){
				entityRef = rs.getString("ENTITY_REFERENCE");            
	        }
			
		} catch (Exception e) {
			WebServiceLoggerUtil.logError("InsuredUtil", "getInsuredEntityReference", e.getLocalizedMessage(), new Object[] { query, conn }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);

		}finally {
			try {
                DBUtil.close(rs, statement, null);                
			} catch (SQLException e) {
				WebServiceLoggerUtil.logError("InsuredUtil", "getInsuredEntityReference", e.getLocalizedMessage(), new Object[] { query, conn }, e);
				throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);
			}
		}
		return entityRef;
	}
	
	public static String getFolderId(String insuredId){
		
		
		String folderId = "";
		String query = "";
		Connection conn = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		HashMap<String, String> row = null;
		try {
			conn = APIRequestContext.getApiRequestContext().getConnection();
			query = "SELECT FOB_FOLDER_ID FROM FOM_FOLDER_OBJECTS WHERE " +
					" FOB_FOLDER_OBJECT_ID in (select MFF_FOLDER_OBJECT_ID from MIS_FOLDER_OBJECTS_FILES_ASSN where " +
					" MFF_ENTITY_REFERENCE = ? ) " +
					" UNION "+
					" SELECT FOB_FOLDER_ID FROM FOM_FOLDER_OBJECTS WHERE " +
					" FOB_FOLDER_OBJECT_ID in (select MFN_FOLDER_OBJECT_ID from MIS_FOLDER_OBJECTS_NOTES_ASSN where " +
					" MFN_ENTITY_REFERENCE = ? ) ";
			
			statement = conn.prepareStatement(query);
			statement.setString(1, insuredId);
			statement.setString(2, insuredId);
			WebServiceLoggerUtil.logInfo("InsuredUtil", "getFolderId", query, new Object[] { query });
			rs = statement.executeQuery();
			
			while (rs.next()){
				folderId = rs.getString("FOB_FOLDER_ID");            
	        }
			
		} catch (Exception e) {
			WebServiceLoggerUtil.logError("InsuredUtil", "getFolderId", e.getLocalizedMessage(), new Object[] { query, conn }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);

		}finally {
			try {
                DBUtil.close(rs, statement, null);                
			} catch (SQLException e) {
				WebServiceLoggerUtil.logError("InsuredUtil", "getFolderId", e.getLocalizedMessage(), new Object[] { query, conn }, e);
				throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);
			}
		}
		return folderId;
	}

}
