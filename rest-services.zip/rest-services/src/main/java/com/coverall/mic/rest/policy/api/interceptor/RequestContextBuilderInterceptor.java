package com.coverall.mic.rest.policy.api.interceptor;

import static com.coverall.security.util.constants.SSOConstants.NS_USER;

import java.util.ArrayList;

import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.apache.cxf.transport.http.AbstractHTTPDestination;

import com.coverall.mt.util.APIAuditTrailLogSpecifics;
import com.coverall.mt.util.APIAuditTrailLog;

import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.factory.impl.PolicyAPIFactoryServiceImpl;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.security.authentication.User;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.IOUtils;
import com.coverall.mt.util.APILoggerUtil;
import com.coverall.mt.util.APIAuditTrailLogSpecifics;
import com.coverall.mt.util.MachineInfoUtil;

public class RequestContextBuilderInterceptor extends AbstractPhaseInterceptor<Message> {

	public RequestContextBuilderInterceptor(){
		super(Phase.PRE_INVOKE);
	}

	@Override
	public void handleMessage(Message message) throws Fault {
		// TODO Auto-generated method stub
		HttpServletRequest request = (HttpServletRequest) message.get(AbstractHTTPDestination.HTTP_REQUEST);
		try {
			User user = (User) request.getSession().getAttribute(NS_USER);
			IAPIContext requestContext = APIRequestContext.getApiRequestContext(user);
			com.coverall.mt.http.User mtUser = com.coverall.mt.http.User.getUser(request);
			requestContext.setMtUser(mtUser);
			
			if(APILoggerUtil.createAPILog() && !request.getMethod().equalsIgnoreCase("GET") && !request.getRequestURI().startsWith("/mic/lookupservice")){
				APIAuditTrailLog auditTrailLog=new APIAuditTrailLog();
				auditTrailLog.setUrl(request.getRequestURI()+(request.getQueryString()==null?"":"?"+request.getQueryString()));
				auditTrailLog.setRequestTime(new java.sql.Timestamp(System.currentTimeMillis()));
				auditTrailLog.setUser(user.getUserId());
				auditTrailLog.setServiceCategory("API");
				auditTrailLog.setOperationType(request.getMethod().toUpperCase());
				auditTrailLog.setMachineInfo(MachineInfoUtil.getMachineHostName());
				//creating request specifics
				String inputJson=IOUtils.toString(request.getInputStream(), "UTF-8");
				request.setAttribute(IAPIContext.INPUT_JSON, inputJson);
				
				
				APIAuditTrailLogSpecifics logSpecifics=new APIAuditTrailLogSpecifics();
				logSpecifics.setRequestSpecifics(inputJson);
				logSpecifics.setRequestHeaders(APILoggerUtil.getDelimitedValueOfStringHeadersFromRequest(request));
				auditTrailLog.setLogSpecifics(logSpecifics);
				
				//creating blank response specifics
				requestContext.setAuditTrailLog(auditTrailLog);
			}
			message.put(IAPIContext.REQUEST_CONTEXT,requestContext);
		} catch (Exception e) {
            throw  new APIException();
		}
	}

}
