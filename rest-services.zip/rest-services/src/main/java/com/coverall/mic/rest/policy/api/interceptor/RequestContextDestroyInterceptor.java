package com.coverall.mic.rest.policy.api.interceptor;

import java.io.IOException;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.jaxrs.impl.ResponseImpl;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.apache.cxf.transport.http.AbstractHTTPDestination;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.coverall.mt.util.APIAuditTrailLog;
import com.coverall.mt.util.APIAuditTrailLogSpecifics;
import com.coverall.mt.util.APILoggerUtil;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.model.ConfirmationMessage;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mt.webservices.WebServiceLoggerUtil;

public class RequestContextDestroyInterceptor extends AbstractPhaseInterceptor<Message> {

	public RequestContextDestroyInterceptor() {
		super(Phase.POST_LOGICAL);
	}

	@Override
	public void handleMessage(Message message) throws Fault {
		/*
		 * Releasing the context here as the API processing is complete.
		 * This will close all the connections and will release the context
		 */
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		try {
			APIAuditTrailLog auditTrailLog=requestContext.getAuditTrailLog();
			if (auditTrailLog != null) {
				Object responseObject = message.getContent(java.util.List.class).get(0);
				populateAndTriggerAuditLogging(responseObject, auditTrailLog, requestContext);
			}
		} catch (Throwable t) {
			WebServiceLoggerUtil.logError("RequestContextDestroyInterceptor",
					"handleMessage", "Exception occurred while generating audit trails", 
					new Object[] { }, t);
		}
		try{
			if( requestContext != null){
			  requestContext.releaseContext();
			}
		}catch(Exception e ){
			WebServiceLoggerUtil.logError("RequestContextDestroyInterceptor",
					"handleMessage", "Exception occurred while releasing the Context", 
					new Object[] { }, e);
		}
	}
	
	public void populateAndTriggerAuditLogging(Object responseObject,APIAuditTrailLog auditTrailLog,IAPIContext requestContext){
		try{
			String responseJson=null;
			int statusCode=0;
			if(responseObject instanceof ResponseImpl && ((ResponseImpl)responseObject).getEntity()!=null){
				if((((ResponseImpl)responseObject).getEntity()) instanceof com.coverall.mic.rest.policy.api.service.model.common.Error){
					com.coverall.mic.rest.policy.api.service.model.common.Error errorEntity=(com.coverall.mic.rest.policy.api.service.model.common.Error)(((ResponseImpl)responseObject).getEntity());
					try {
						responseJson = (new ObjectMapper()).writeValueAsString(errorEntity);
					} catch (Exception e) {
						responseJson=(errorEntity.getStatus());
					}
					statusCode=Integer.parseInt(errorEntity.getStatuscode());
				}else{
					statusCode=((ResponseImpl)responseObject).getStatus();
					try {
						responseJson=(new ObjectMapper()).writeValueAsString(((ResponseImpl)responseObject).getEntity());
					}catch(Exception exp) {
						responseJson="Response Object can't be decoded";	
					}
				}
			}else {
				try {
					responseJson = (new ObjectMapper()).writeValueAsString(responseObject);
				} catch (Exception e) {
					responseJson="Request completed successfully. Response Object can't be decoded";
				}
				statusCode=200;
			}

			auditTrailLog.setResponseTime(new java.sql.Timestamp(System.currentTimeMillis()));
			auditTrailLog.setStatusCode(statusCode);
			APIAuditTrailLogSpecifics logSpecifics=auditTrailLog.getLogSpecifics();
			logSpecifics.setResponseSpecifics(responseJson);

		}catch(Exception exp){
			WebServiceLoggerUtil.logError("RequestContextDestroyInterceptor",
					"populateAndTriggerAuditLogging", "Exception while creating API Audit log for - "+auditTrailLog.getUrl(), 
					new Object[] { }, exp);
		}finally {
			if(APILoggerUtil.createAPILog()) {
			 APILoggerUtil.getLoggerQueryMap().get(requestContext.getUserDomain().toLowerCase()).offer(auditTrailLog);
			}
		}

	}

}
