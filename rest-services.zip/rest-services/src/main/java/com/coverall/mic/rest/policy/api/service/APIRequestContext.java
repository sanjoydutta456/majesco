package com.coverall.mic.rest.policy.api.service;

import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.naming.NamingException;

import com.coverall.mt.util.APIAuditTrailLog;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.mt.xml.DOMUtil;
import com.coverall.security.authentication.User;
import com.coverall.util.DBUtil;

public class APIRequestContext implements IAPIContext {
	private Connection conn;
	private User user;
	private com.coverall.mt.http.User mtUser;
	private APIAuditTrailLog auditTrailLog;

	

	private APIRequestContext() {
	}

	protected static final ThreadLocal<APIRequestContext> apiRequestContext = new ThreadLocal<APIRequestContext>() {
		protected synchronized APIRequestContext initialValue() {
			return new APIRequestContext();
		}
	};

	private static APIRequestContext getNewContext() {
		try {
			APIRequestContext retrievedContext = apiRequestContext.get();
			retrievedContext.releaseContext();
		} catch (Throwable e) {
			throw new APIException("Error while initializing the Request Context", e);
		}
		apiRequestContext.remove();
		return apiRequestContext.get();
	}

	public static APIRequestContext getApiRequestContext(User user) {
		APIRequestContext ctx = getNewContext();
		ctx.setUser(user);
		return ctx;
	}

	public static APIRequestContext getApiRequestContext() {
		APIRequestContext ctx = apiRequestContext.get();
		return ctx;
	}

	public void releaseContext() {
		try {
			if (conn != null && !conn.isClosed()) {
				DBUtil.close(conn);
			}
		} catch (Exception e) {

		}
		user = null;
		conn = null;
		mtUser= null;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	public String getUserName(){
		return user.getUserId();
	}
	
	public String getUserDomain(){
		return user.getDomain();
	}
	
	public com.coverall.mt.http.User getMtUser() {
		return mtUser;
	}

	public void setMtUser(com.coverall.mt.http.User mtUser) {
		this.mtUser = mtUser;
	}
	
	/**
	 * Gets the simulated user for requested User ID
	 * As we do not have password for the requested user, we need to use batchuser 
	 * credentials to create an User object
	 * @param sourceSystemUserId
	 * @return
	 */
	public com.coverall.mt.http.User getSourceSystemUser(String sourceSystemUserId) {
		com.coverall.mt.http.User user = null;
		try {
			if(sourceSystemUserId != null && sourceSystemUserId.indexOf('@') == -1 ){
				sourceSystemUserId = sourceSystemUserId + "@" + APIRequestContext.getApiRequestContext().getMtUser().getDomain();
			}
			com.coverall.mt.http.User batchUser = new com.coverall.mt.http.User(DOMUtil.BATCH_USER + "@" + mtUser.getDomain(),
                    DOMUtil.BATCH_PASSWORD);
            Method mGetSimulatedUser = com.coverall.mt.http.User.class.getDeclaredMethod("getSimulatedUser", String.class);
            mGetSimulatedUser.setAccessible(true);
            user = (com.coverall.mt.http.User) mGetSimulatedUser.invoke(batchUser, sourceSystemUserId);
        } catch (Exception e) {
        	WebServiceLoggerUtil.logError("AbstractUnifiedEntitySearch", "getSimulatedUser", e.getLocalizedMessage(), new Object[] {sourceSystemUserId}, e);
            
        }
		return user;
	}

	public Connection getConnection() {
		if (conn == null) {
			try {
				conn = ConnectionPool.getConnection(getUser().getDomain());

			} catch (Exception e) {
				// TODO Auto-generated catch block
				throw new APIException("Error while getting the Connection",e);
			} 
		}
		return conn;
	}

	
	private Connection getJDBCConnection() throws Exception {
		String host = "micdb-p15qa10.zeal.cover-all.com";
		String sid = "p15qa10";
		String port = "1521";
		String userId = "MIC_99";
		String password = "MIC_99";

		Connection conn = null;
		String jdbcURL = "jdbc:oracle:thin:@" + host + ":" + port + ":" + sid;
		String driverName = "oracle.jdbc.driver.OracleDriver";
		Class.forName(driverName);
		conn = DriverManager.getConnection(jdbcURL, userId, password);

		return conn;
	}

	@Override
	public void setAuditTrailLog(APIAuditTrailLog auditTrailLog) {
		this.auditTrailLog=auditTrailLog;
		
	}

	@Override
	public APIAuditTrailLog getAuditTrailLog() {
		return auditTrailLog;
	}

	
}
