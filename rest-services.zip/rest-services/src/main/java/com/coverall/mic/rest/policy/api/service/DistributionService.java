package com.coverall.mic.rest.policy.api.service;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

public interface DistributionService {
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({ 
		MediaType.APPLICATION_JSON})
	@Path("/producers")
	public Object producerManagement(@Context HttpServletRequest request);
	
}
