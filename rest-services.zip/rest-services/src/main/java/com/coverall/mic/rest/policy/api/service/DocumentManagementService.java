package com.coverall.mic.rest.policy.api.service;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

public interface DocumentManagementService {
	
	String RESOURCE_TYPE="Document Package";
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({ 
		MediaType.APPLICATION_JSON})
	@Path("/quote/{quoteId}")
	public Object quoteDocumentManagement(@Context HttpServletRequest request,@PathParam("quoteId") String quoteId);
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({ 
		MediaType.APPLICATION_JSON})
	@Path("/policy/{policyId}")
	public Object policyDocumentManagement(@Context HttpServletRequest request,@PathParam("policyId") String quoteId);
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({ 
		MediaType.APPLICATION_JSON})
	@Path("/esign")
	public Object esign(@Context HttpServletRequest request);
}
