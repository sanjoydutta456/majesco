package com.coverall.mic.rest.policy.api.service;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

public interface FormDocumentInfoService {
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({ 
		MediaType.APPLICATION_JSON})
	@GET
	public Object getFormDocumentInfo(@QueryParam("templateName") String templateName,@QueryParam("documentId") String documentId,@QueryParam("productcode") String productCode,@QueryParam("lobCode") String lobCode,
			@QueryParam("stateCode") String stateCode,@QueryParam("customerCode") String customerCode,@QueryParam("wordFormat") String wordFormat,
			@QueryParam("isStatic") String isStatic,@QueryParam("isForm") String isForm,
			@QueryParam("isInterline") String isInterline,@QueryParam("isManuscript") String isManuscript,
			@QueryParam("isMultiAttach") String isMultiAttach,@QueryParam("requireAdoption") String requireAdoption
			);
	
}
