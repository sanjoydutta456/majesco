package com.coverall.mic.rest.policy.api.service;

import java.sql.Connection;

import com.coverall.mt.util.APIAuditTrailLog;
import com.coverall.security.authentication.User;

public interface IAPIContext {
	
	String REQUEST_CONTEXT = "requestContext";
	
	String INPUT_JSON="inputJSON";
	
	public void releaseContext();

	public User getUser();
	
	public void setUser(User user);
	
	public Connection getConnection(); 
	
	public String getUserName();
	
	public String getUserDomain();
	
	public com.coverall.mt.http.User getMtUser() ;

	public void setMtUser(com.coverall.mt.http.User mtUser);
	
	public void setAuditTrailLog(APIAuditTrailLog auditTrailLog);
	
	public APIAuditTrailLog getAuditTrailLog();
	
}
