package com.coverall.mic.rest.policy.api.service;

public interface ICustomPolicyService {

	
	public Object getCustomAPIServiceHandler(String apiFileName, String apiVersion);
	
	
}
