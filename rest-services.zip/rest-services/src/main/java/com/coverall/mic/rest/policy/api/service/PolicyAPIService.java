package com.coverall.mic.rest.policy.api.service;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;


@Path("/")
@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON , MediaType.MULTIPART_FORM_DATA })
@Produces({ MediaType.APPLICATION_JSON , MediaType.MULTIPART_FORM_DATA, MediaType.APPLICATION_OCTET_STREAM})
public interface PolicyAPIService {

	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("policy-homeowners")
	public Object getHOQuotePolicyService(@Context HttpServletRequest request);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("policy-commercial-auto")
	public Object getCAQuotePolicyService(@Context HttpServletRequest request);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("quotes-homeowners")
	public Object getHOQuotePolicyServiceQuotes(@Context HttpServletRequest request);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("quotes-commercial-auto")
	public Object getCAQuotePolicyServiceQuotes(@Context HttpServletRequest request);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("quotes-all-lines")
	public Object getQuoteAllLinesResource(@Context HttpServletRequest request);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("policy-all-lines")
	public Object getPolicyAllLinesResource(@Context HttpServletRequest request);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA,
	    MediaType.APPLICATION_OCTET_STREAM})
	@Path("document-mgmt-quotes/{quoteId}")
	public Object documentPackageManagementQuotes(@Context HttpServletRequest request,@PathParam("quoteId") String quoteId);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA,
	    MediaType.APPLICATION_OCTET_STREAM})
	@Path("document-mgmt-policy/{policyId}")
	public Object documentPackageManagementPolicy(@Context HttpServletRequest request,@PathParam("policyId") String policyId);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA,
	    MediaType.APPLICATION_OCTET_STREAM})
	@Path("unified-search")
	public Object unifiedSearch(@Context HttpServletRequest request);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA,
	    MediaType.APPLICATION_OCTET_STREAM})
	@Path("parties-customer")
	public Object getCustomerResource(@Context HttpServletRequest request);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA,
	    MediaType.APPLICATION_OCTET_STREAM})
	@Path("distribution-producers")
	public Object producerManagement(@Context HttpServletRequest request);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("quote-all-product")
	public Object getAllProducts(@Context HttpServletRequest request);
	

	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("transactions")
	public Object getEndorsementTransaction(@Context HttpServletRequest request);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("transactions")
	public Object getRenewTransaction(@Context HttpServletRequest request);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("parties-underwriter")
	public Object underwiterTransaction(@Context HttpServletRequest request);
	
	@Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
    @Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
    @Path("ping")
    @GET
    public String ping();
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA,
	    MediaType.APPLICATION_OCTET_STREAM})
	@Path("oas/policy-distribution/v{versionId}")
	public Object distributionManagement(@Context HttpServletRequest request, @PathParam("versionId") String versionId);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/policy-parties/v{versionId}")
	public Object partiesManagement(@Context HttpServletRequest request, @PathParam("versionId") String versionId);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/policy-homeowners/deprecated/v{versionId}/policy")
	public Object getHOPolicyService(@Context HttpServletRequest request, @PathParam("versionId") String versionId);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/policy-commercialauto/deprecated/v{versionId}/policy")
	public Object getCAPolicyService(@Context HttpServletRequest request, @PathParam("versionId") String versionId);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/quote-homeowners/deprecated/v{versionId}/quote")
	public Object getHOQuoteService(@Context HttpServletRequest request, @PathParam("versionId") String versionId);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/quote-commercialauto/deprecated/v{versionId}/quote")
	public Object getCAQuoteService(@Context HttpServletRequest request, @PathParam("versionId") String versionId);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/{apiFileName}/v{versionId}/quote")
	public Object getApplicableQuoteService(@Context HttpServletRequest request,@PathParam("apiFileName") String apiFileName , @PathParam("versionId") String versionId);
	
	

	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/{apiFileName}/v{versionId}/policy")
	public Object getApplicablePolicyService(@Context HttpServletRequest request,@PathParam("apiFileName") String apiFileName , @PathParam("versionId") String versionId);
	
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/quote-common/deprecated/v{versionId}/quote")
	public Object getQuoteCommonAllLinesResource(@Context HttpServletRequest request, @PathParam("versionId") String versionId);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/policy-common/deprecated/v{versionId}/policy")
	public Object getPolicyCommonAllLinesResource(@Context HttpServletRequest request, @PathParam("versionId") String versionId);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA,
	    MediaType.APPLICATION_OCTET_STREAM})
	@Path("oas/policy-document-management/v{versionId}")
	public Object documentPackageManagement(@Context HttpServletRequest request, @PathParam("versionId") String versionId);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA,
	    MediaType.APPLICATION_OCTET_STREAM})
	@Path("oas/policy-communication/v{versionId}")
	public Object communicationManagement(@Context HttpServletRequest request, @PathParam("versionId") String versionId);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("policy-workers-compensation")
	public Object getWKQuotePolicyService(@Context HttpServletRequest request);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("quotes-workers-compensation")
	public Object getWKQuotePolicyServiceQuotes(@Context HttpServletRequest request);
	
	
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("policy-personal-auto")
	public Object getPAQuotePolicyService(@Context HttpServletRequest request);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("quotes-personal-auto")
	public Object getPAQuotePolicyServiceQuotes(@Context HttpServletRequest request);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("policy-dwelling-fire")
	public Object getDFQuotePolicyService(@Context HttpServletRequest request);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("quotes-dwelling-fire")
	public Object getDFQuotePolicyServiceQuotes(@Context HttpServletRequest request);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("policy-commercial-package")
	public Object getCPQuotePolicyService(@Context HttpServletRequest request);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("quotes-commercial-package")
	public Object getCPQuotePolicyServiceQuotes(@Context HttpServletRequest request);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("policy-business-owners")
	public Object getBPQuotePolicyService(@Context HttpServletRequest request);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("quotes-business-owners")
	public Object getBPQuotePolicyServiceQuotes(@Context HttpServletRequest request);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA,
	    MediaType.APPLICATION_OCTET_STREAM})
	@Path("esign")
	public Object geteSignService(@Context HttpServletRequest request);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/quotes-general-liability/v{versionId}")
	public Object getGLQuoteService(@Context HttpServletRequest request, @PathParam("versionId") String versionId);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/policy-general-liability/v{versionId}")
	public Object getGLPolicyService(@Context HttpServletRequest request, @PathParam("versionId") String versionId);
	
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/quotes-commercial-property/v{versionId}")
	public Object getPRQuoteService(@Context HttpServletRequest request, @PathParam("versionId") String versionId);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/policy-commercial-property/v{versionId}")
	public Object getPRPolicyService(@Context HttpServletRequest request, @PathParam("versionId") String versionId);
	
	
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/quotes-commercial-inland-marine/v{versionId}")
	public Object getIMQuoteService(@Context HttpServletRequest request, @PathParam("versionId") String versionId);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/policy-commercial-inland-marine/v{versionId}")
	public Object getIMPolicyService(@Context HttpServletRequest request, @PathParam("versionId") String versionId);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/quotes-crime-and-fidelity/v{versionId}")
	public Object getCFQuoteService(@Context HttpServletRequest request, @PathParam("versionId") String versionId);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/policy-crime-and-fidelity/v{versionId}")
	public Object getCFPolicyService(@Context HttpServletRequest request, @PathParam("versionId") String versionId);
	
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/{apiFileName}/custom/v{versionId}")
	public Object getCustomPolicyService(@Context HttpServletRequest request,@PathParam("apiFileName") String apiFileName , @PathParam("versionId") String versionId);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/v{versionId}/reports/{apiEndpoint}")
	public Object getReportData(@Context HttpServletRequest request,@PathParam("versionId") String versionId,@PathParam("apiEndpoint") String apiEndpoint,
            @QueryParam("pageNumber") int pageNumber,@QueryParam("pageSize") int pageSize,@QueryParam("countOnly") String countOnly);
	
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/policy-reports/v{versionId}/reports/{apiEndpoint}")
	public Object getOASReportData(@Context HttpServletRequest request,@PathParam("versionId") String versionId,@PathParam("apiEndpoint") String apiEndpoint,
            @QueryParam("pageNumber") int pageNumber,@QueryParam("pageSize") int pageSize,@QueryParam("countOnly") String countOnly);
	
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("atpApiTransaction")
	public Object atpSpecificTasks(@Context HttpServletRequest request);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/emailtemplates/v{versionId}/placeholders")
	public Object getTemplatePlaceHolderService(@Context HttpServletRequest request, @PathParam("versionId") String versionId,
			@QueryParam("reference") String reference,@QueryParam("referenceType") String referenceType,@QueryParam("templateName") String templateName,@QueryParam("sourceSystemUserId") String sourceSystemUserId);
			
			
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/emailtemplates/v{versionId}/valid-templates")
	public Object getPolicyTemplateService(@Context HttpServletRequest request, @PathParam("versionId") String versionId,@QueryParam("category") String category,@QueryParam("referenceType") String referenceType,@QueryParam("reference") String reference);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA,
	    MediaType.APPLICATION_OCTET_STREAM})
	@Path("oas/policy-search/v{versionId}/unified")
	public Object oasUnifiedSearch(@Context HttpServletRequest request);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA,
	    MediaType.APPLICATION_OCTET_STREAM})
	@Path("oas/parties-customer/v{versionId}/customer")
	public Object getOASCustomerResource(@Context HttpServletRequest request);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/policy-product-usage/v{versionId}")
	public Object getPolicyProductUsageDetails(@Context HttpServletRequest request,@PathParam("versionId") String versionId);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/policy/v{versionId}")
	public Object getPolicyHeartBeatDetails(@Context HttpServletRequest request,@PathParam("versionId") String versionId);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/quote-common/v{versionId}/quote/{entityReference}/extractTransaction")
	public Object getQuoteExtractDetails(@Context HttpServletRequest request,@PathParam("versionId") String versionId,@PathParam("entityReference") String entityReference,@QueryParam("policyAdditionalDetails") String policyAdditionalDetails);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/policy-common/v{versionId}/policy/{entityReference}/extractTransaction")
	public Object getPolicyExtractDetails(@Context HttpServletRequest request,@PathParam("versionId") String versionId,@PathParam("entityReference") String entityReference,@QueryParam("policyAdditionalDetails") String policyAdditionalDetails);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/quote-common/v{versionId}/quote/{entityReference}/importTransaction")
	public Object getQuoteImportDetails(@Context HttpServletRequest request,@PathParam("versionId") String versionId,@PathParam("entityReference") String entityReference,@QueryParam("dontBook") String dontBook,@QueryParam("allowTransaction") String allowTransaction);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/policy-common/v{versionId}/policy/{entityReference}/importTransaction")
	public Object getPolicyImportDetails(@Context HttpServletRequest request,@PathParam("versionId") String versionId,@PathParam("entityReference") String entityReference,@QueryParam("dontBook") String dontBook,@QueryParam("allowTransaction") String allowTransaction);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/quote-common/v{versionId}/quote/{entityReference}/changeSummary")
	public Object getQuoteChangeSummary(@Context HttpServletRequest request,@PathParam("versionId") String versionId,@PathParam("entityReference") String entityReference);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/policy-common/v{versionId}/policy/{entityReference}/changeSummary")
	public Object getPolicyChangeSummary(@Context HttpServletRequest request,@PathParam("versionId") String versionId,@PathParam("entityReference") String entityReference);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/quote-common/v{versionId}/quote/forms-document-info")
	public Object getQuoteFormsAndDocumentInformation(@Context HttpServletRequest request, @PathParam("versionId") String versionId) throws Exception;
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("oas/policy-common/v{versionId}/policy/forms-document-info")
	public Object getPolicyFormsAndDocumentInformation(@Context HttpServletRequest request, @PathParam("versionId") String versionId) throws Exception;

	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("scaledown")
	public Object initiateInstanceScaledown(@Context HttpServletRequest request,@QueryParam(value = "timeoutInSec") String timeoutInSec) throws Exception;
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA,
	    MediaType.APPLICATION_OCTET_STREAM})
	@Path("oas/policy-parties/v{versionId}/insured")
	public Object getOASInsuredResource(@Context HttpServletRequest request);

	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA,
	    MediaType.APPLICATION_OCTET_STREAM})
	@Path("lc360")
	public Object lossControl(@Context HttpServletRequest request);
}
