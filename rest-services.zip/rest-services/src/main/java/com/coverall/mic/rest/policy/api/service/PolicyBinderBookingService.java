/**
 * 
 */
package com.coverall.mic.rest.policy.api.service;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.coverall.mic.rest.policy.api.exception.APIException;

/**
 * @author aayush87156
 *
 */
public interface PolicyBinderBookingService {
	
	String RESOURCE_TYPE="Booking";

	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({ 
		MediaType.APPLICATION_JSON})
	@POST
	Object bookPolicyBinder() throws APIException;
}
