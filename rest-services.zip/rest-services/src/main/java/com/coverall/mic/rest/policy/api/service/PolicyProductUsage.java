package com.coverall.mic.rest.policy.api.service;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicySearch;

public interface PolicyProductUsage {
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({ 
		MediaType.APPLICATION_JSON})
	@GET
	@Path("/pay-per-usage-details")
	Object getPayPerUsageDetails(@QueryParam("asOfDate") String asOfDate,@QueryParam("dataOption") String dataOption,
            @QueryParam("sourceSystemRequestNo") String sourceSystemRequestNo,@QueryParam("requestDate") String requestDate,@QueryParam("sourceSystemCode") String sourceSystemCode,
            @QueryParam("sourceSystemUserId") String sourceSystemUserId,@QueryParam("sourceSystemUserName") String sourceSystemUserName, @QueryParam("noOfMonths") int noOfMonths)  throws Exception;
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({ 
		MediaType.APPLICATION_JSON})
	@GET
	@Path("/in-force-policies")
	Object getInforcePoliciesDetails(@QueryParam("asOfDate") String asOfDate,
            @QueryParam("sourceSystemRequestNo") String sourceSystemRequestNo,@QueryParam("requestDate") String requestDate,@QueryParam("sourceSystemCode") String sourceSystemCode,
            @QueryParam("sourceSystemUserId") String sourceSystemUserId,@QueryParam("sourceSystemUserName") String sourceSystemUserName)  throws Exception;
	
}
