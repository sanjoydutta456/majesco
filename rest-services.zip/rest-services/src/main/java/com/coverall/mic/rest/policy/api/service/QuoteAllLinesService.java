package com.coverall.mic.rest.policy.api.service;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;



@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON , MediaType.MULTIPART_FORM_DATA })
@Produces({ MediaType.APPLICATION_JSON , MediaType.MULTIPART_FORM_DATA })
public interface QuoteAllLinesService {

	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("/")
	public Object listAllQuotes(@Context HttpServletRequest request,
			@QueryParam("exactMatch") String exactMatch,
            @QueryParam("policyNo") String policyNo,
            @QueryParam("product") String product,            
            @QueryParam("pageSize") int pageSize,
            @QueryParam("pageNumber") int pageNumber,
            @QueryParam("correlationid") String correlationid,
            @QueryParam("effectiveStartDateRange") String effectiveStartDateRange,
            @QueryParam("effectiveEndDateRange") String effectiveEndDateRange,
            @QueryParam("company") String company,
            @QueryParam("agencyNumber") String agencyNumber,
            @QueryParam("agencyName") String agencyName,
            @QueryParam("marketManager") String marketManager,
            @QueryParam("insured") String insured,
            @QueryParam("underwriter") String underwriter,
            @QueryParam("status") String status);
	
//	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
//	@Produces({ 
//		MediaType.APPLICATION_JSON, 
//		MediaType.APPLICATION_XML ,
//	    MediaType.MULTIPART_FORM_DATA})
//	@GET
//	@Path("/list")
//	public Object ListAllQuotesAdvanced(@Context HttpServletRequest request,
//			@QueryParam("exactMatch") String exactMatch,
//            @QueryParam("policyId") String policyId,
//            @QueryParam("pageSize") int pageSize,
//            @QueryParam("pageNumber") int pageNumber,
//            @QueryParam("correlationid") String correlationid,
//            @QueryParam("effectiveStartDateRange") String effectiveStartDateRange,
//            @QueryParam("effectiveEndDateRange") String effectiveEndDateRange,
//            @QueryParam("company") String company,
//            @QueryParam("agencyNumber") String agencyNumber,
//            @QueryParam("agencyName") String agencyName,
//            @QueryParam("marketManager") String marketManager,
//            @QueryParam("insured") String insured,
//            @QueryParam("underwriter") String underwriter,
//            @QueryParam("status") String status);
	
//	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
//	@Produces({ 
//		MediaType.APPLICATION_JSON, 
//		MediaType.APPLICATION_XML ,
//	    MediaType.MULTIPART_FORM_DATA})
//	@Path("/version")
//	public Object listAllQuotesVersions(@Context HttpServletRequest request,
//			@QueryParam("pageSize") int pageSize,
//            @QueryParam("pageNumber") int pageNumber,
//            @QueryParam("correlationid") String correlationid);
	
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("{quoteId}/forms")
	public Object getFormResource(@PathParam("quoteId") String quoteId, @Context HttpServletRequest request);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("{quoteId}/status")
	public Object getQuotePolicyStatusResouce(@PathParam("quoteId") String quoteId, @Context HttpServletRequest request);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("{quoteId}/transactions")
	public Object getTransactions(@PathParam("quoteId") String quoteId, @Context HttpServletRequest request);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("{quoteId}/communication-attachments")
	public Object getCommunicationAttachments(@PathParam("quoteId") String quoteId, @Context HttpServletRequest request);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("{quoteId}/commissions")
	public Object processCommissions(@PathParam("quoteId") String quoteId, @Context HttpServletRequest request);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("{quoteId}/uw-rules")
	public Object processUWRule(@PathParam("quoteId") String quoteId, @Context HttpServletRequest request);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("{quoteId}/billing")
	public Object processBillingAttributes(@PathParam("quoteId") String quoteId, @Context HttpServletRequest request);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("{quoteId}/surcharge")
	public Object getSurchargeDetails(@PathParam("quoteId") String quoteId, @Context HttpServletRequest request);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("{policyId}/book")
	public Object bookPolicyBinder(@PathParam("policyId") String policyId, @Context HttpServletRequest request);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("{policyId}/issue")
	public Object issueBinder(@PathParam("policyId") String policyId, @Context HttpServletRequest request);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("{policyId}/documents")
	public Object attachedDocuments(@PathParam("policyId") String policyId, @Context HttpServletRequest request);
	
//	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
//	@Produces({ 
//		MediaType.APPLICATION_JSON, 
//		MediaType.APPLICATION_XML ,
//	    MediaType.MULTIPART_FORM_DATA})
//	@Path("{quoteId}/cancel")
//	@POST
//	public Object cancelPolicy(@PathParam("quoteId") String policyId, @Context HttpServletRequest request);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@POST
	@Path("{quoteId}/convert")
	public Object converQuoteToPolicy(@PathParam("quoteId") String quoteId,String requestJson, @Context HttpServletRequest request)  throws Exception;
	
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@POST
	@Path("{quoteId}/bind")
	public Object converQuoteToBinder(@PathParam("quoteId") String quoteId,String requestJson, @Context HttpServletRequest request)  throws Exception;
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@POST
	@Path("{quoteId}/convertQFE")
	public Object convertQFEToEndorsement(@PathParam("quoteId") String quoteId,String requestJson, @Context HttpServletRequest request)  throws Exception;
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("{quoteId}/payment-plan")
	public Object getPaymentPlanInformation(@PathParam("quoteId") String quoteId,@Context HttpServletRequest request);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("{policyId}/oose")
	public Object getOOSEResource(@PathParam("policyId") String policyId, @Context HttpServletRequest request);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("{quoteId}/communication-note")
	public Object getCommunicationNote(@PathParam("quoteId") String quoteId, @Context HttpServletRequest request);
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("{quoteId}/purge")
	public Object performPurgeOperation(@PathParam("quoteId") String quoteId, @Context HttpServletRequest request);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@POST
	@Path("{quoteId}/decline")
	public Object declineQuote(@PathParam("quoteId") String quoteId,String requestJson, @Context HttpServletRequest request)  throws Exception;
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@POST
	@Path("{quoteId}/openquote")
	public Object openQuote(@PathParam("quoteId") String quoteId,String requestJson, @Context HttpServletRequest request)  throws Exception;
	
	
	@GET
	@Path("ping")
	public String ping();
}
