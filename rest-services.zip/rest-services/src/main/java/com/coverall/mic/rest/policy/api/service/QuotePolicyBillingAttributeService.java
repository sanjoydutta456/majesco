package com.coverall.mic.rest.policy.api.service;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

public interface QuotePolicyBillingAttributeService {
	
	String SOURCE_SYSTEM_CODE="MIC";
	
	String RESOURCE_TYPE="Payment Plan";
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_JSON})
	@GET
	Object getBillingAttributeList()  throws Exception;
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_JSON})
	@POST
	Object addBillingAttribute() throws Exception;
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_JSON})
	@PUT
	Object updateBillingAttribute() throws Exception;

}
