package com.coverall.mic.rest.policy.api.service;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

public interface QuotePolicyCommissionService {
	
	String SOURCE_SYSTEM_CODE="MIC";
	String RESOURCE_TYPE="Commission";
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_JSON})
	@GET
	Object getCommissionsList()  throws Exception;
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_JSON})
	@POST
	@Path("/process")
	Object processCommissionCalculation() throws Exception;
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_JSON})
	@PUT
	Object modifyCommissions() throws Exception;

}
