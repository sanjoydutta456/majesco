package com.coverall.mic.rest.policy.api.service;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.coverall.mic.rest.policy.api.service.model.QuotePolicyAttachmentResponse;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyAttachmentDelete;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyTransactions;

public interface QuotePolicyNoteService {
	
	String SOURCE_SYSTEM_CODE="MIC";
	String RESOURCE_TYPE="Note";
	String SPACE_REPLACEMENT="$$";
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({ 
		MediaType.APPLICATION_JSON})
	@GET
	Object getQuotePolicyAllNotesList()  throws Exception;
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({ 
		MediaType.APPLICATION_JSON})
	@GET
	@Path("/{noteId}")
	Object getQuotePolicyNote(@PathParam("noteId") String noteId)  throws Exception;
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({ 
		MediaType.APPLICATION_JSON})
	@PUT
	@Path("/{noteId}")
	Object updateQuotePolicyNote(@PathParam("noteId") String noteId)  throws Exception;
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({ 
		MediaType.APPLICATION_JSON})
	@DELETE
	@Path("/{noteId}")
	Object deleteQuotePolicyNote(@PathParam("noteId") String noteId)  throws Exception;
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({ 
		MediaType.APPLICATION_JSON})
	@POST
	Object addQuotePolicyNote()  throws Exception;
}
