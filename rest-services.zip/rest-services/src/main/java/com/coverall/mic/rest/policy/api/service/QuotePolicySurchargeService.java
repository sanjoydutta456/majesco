package com.coverall.mic.rest.policy.api.service;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

public interface QuotePolicySurchargeService {
	
	String SOURCE_SYSTEM_CODE="MIC";
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({ 
		MediaType.APPLICATION_JSON})
	@GET
	Object getQuotePolicySurchargenResult()  throws Exception;
}
