package com.coverall.mic.rest.policy.api.service;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


public interface QuotePolicyUWRulesService {
	
	String SOURCE_SYSTEM_CODE="MIC";
	
	String RESOURCE_TYPE="Underwriter Rule";
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_JSON})
	@GET
	Object getUWRulesList()  throws Exception;
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_JSON})
	@POST
	@Path("/process")
	Object processUWRules() throws Exception;
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_JSON})
	@POST
	@Path("/approve")
	Object approveUWRules() throws Exception;
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_JSON})
	@POST
	@Path("/reject")
	Object rejectUWRules() throws Exception;
	
}
