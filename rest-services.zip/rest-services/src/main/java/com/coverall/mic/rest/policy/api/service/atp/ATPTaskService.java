package com.coverall.mic.rest.policy.api.service.atp;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.coverall.mic.rest.policy.api.exception.APIException;

public interface ATPTaskService {
	
	String RESOURCE_TYPE="ATP Task";

	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({ 
		MediaType.APPLICATION_JSON})
	@POST
	Object addATPRequest() throws APIException;
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({ 
		MediaType.APPLICATION_JSON})
	@PUT
	Object updateATPResponse() throws APIException;
	
	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({ 
		MediaType.APPLICATION_JSON})
	@GET
	Object getRequestSpecifics(@QueryParam("requestId") int requestId,@QueryParam("requestType") String requestType,@QueryParam("policyReference") String policyReference,
			@QueryParam("productCode") String productCode,@QueryParam("status") String status,
			@QueryParam("failedAttempts") int failedAttempts,@QueryParam("transactionName") String transactionName,@QueryParam("requestName") String requestName,
			@QueryParam("dateModifiedStart") String dateModifiedStart,@QueryParam("dateModifiedEnd") String dateModifiedEnd,@QueryParam("maxFailedAttempts") int maxFailedAttempts,@QueryParam("prepareEndPoint") String prepareEndPoint)
	throws APIException;

}
