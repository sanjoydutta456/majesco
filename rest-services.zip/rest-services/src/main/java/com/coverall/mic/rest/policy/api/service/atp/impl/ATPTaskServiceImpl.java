package com.coverall.mic.rest.policy.api.service.atp.impl;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringWriter;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.type.CollectionType;

import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.atp.ATPTaskService;
import com.coverall.mic.rest.policy.api.service.atp.model.PolicyTransaction;
import com.coverall.mic.rest.policy.api.service.atp.model.PolicyTransactionConfirmation;
import com.coverall.mic.rest.policy.api.service.atp.model.PolicyTransactionRequestDetail;
import com.coverall.mic.rest.policy.api.service.atp.model.PolicyTransactionResponseDetail;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mt.http.User;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.util.DBUtil;
import com.coverall.util.GeneralUtil;



public class ATPTaskServiceImpl implements ATPTaskService{
	private HttpServletRequest request;
	private User user;
	private boolean checkingRequest=false;
	private static String queryToFetchPolicyTransaction="SELECT WBN_REQUEST_ID,WBN_REQUEST_TYPE,WBN_POLICY_REFERENCE,WBN_USER_CREATED,to_char(WBN_DATE_CREATED,'MM/DD/YYYY') dateCreated,WBN_USER_MODIFIED,to_char(WBN_DATE_MODIFIED,'MM/DD/YYYY') dateModified,WBN_PRODUCT_CODE,WBN_REQUEST_NAME,WBN_STATUS,WBN_FAILED_ATTEMPTS,WBN_NEW_ENTITY_REFERENCE,WBN_TRANSACTION_NAME,WBN_MAX_FAILED_ATTEMPTS"+ 
			" FROM WS_POLICY_TRANSACTION_REQUESTS WHERE 1=1";
	private static String queryForRequestDetails="SELECT WPTR_REQUEST_DETAILS_ID,WPTR_REQUEST_ID,WPTR_TXN_REQUEST_INPUT,WPTR_USER_CREATED,"+
			"to_char(WPTR_DATE_CREATED,'MM/DD/YYYY') dateCreated,WPTR_USER_MODIFIED,to_char(WPTR_DATE_MODIFIED,'MM/DD/YYYY') dateModified FROM WS_POLICY_TXN_REQUESTS_DETAILS"+
			" WHERE 1=1 AND WPTR_REQUEST_ID=?";

	private static String queryForResponseDetails="SELECT WPTS_RESPONSE_ID,WPTS_REQUEST_ID,WPTS_TXN_RESPONSE_OUTPUT,WPTS_USER_CREATED,"+
			"to_char(WPTS_DATE_CREATED,'MM/DD/YYYY') dateCreated,WPTS_USER_MODIFIED,to_char(WPTS_DATE_MODIFIED,'MM/DD/YYYY') dateModified"+
			" FROM WS_POLICY_TRANSACTION_RESPONSE WHERE 1=1 AND WPTS_REQUEST_ID=?";
	
	private static String queryForProductDesc="SELECT lower(replace(ppd_name,' ','-')) ProductDesc FROM ps_products, ds_resource "+
			" WHERE 1=1 AND ppd_id = dsr_gid AND dsr_product_code=?";

	public ATPTaskServiceImpl(HttpServletRequest request){
		super();
		this.request=request;
		this.user=User.getUser(request);
	}

	@Override
	public Object addATPRequest() throws APIException {
		PolicyTransactionConfirmation confirmation=new PolicyTransactionConfirmation();
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		Connection conn = null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		String generatedColumns[] = { "WBN_REQUEST_ID" };
		List<Integer> addedRequests=new ArrayList<Integer>();

		try{
			ObjectMapper mapper=new ObjectMapper();
			String inputJson=APIOperationUtil.fetchRequestBody(request);
			CollectionType listType = mapper.getTypeFactory().constructCollectionType(ArrayList.class, PolicyTransaction.class);
			ArrayList<PolicyTransaction> policyTransactionList=mapper.readValue(inputJson, listType);

			String queryForInsertingTransaction="INSERT INTO WS_POLICY_TRANSACTION_REQUESTS (WBN_REQUEST_ID,WBN_REQUEST_TYPE,WBN_POLICY_REFERENCE,"+
					"WBN_USER_CREATED,WBN_USER_MODIFIED,WBN_PRODUCT_CODE,WBN_REQUEST_NAME,WBN_NEW_ENTITY_REFERENCE,WBN_TRANSACTION_NAME,WBN_DATE_MODIFIED,WBN_DATE_CREATED,WBN_MAX_FAILED_ATTEMPTS)values(S_WBN_REQUEST_ID_SEQ.NEXTVAL,?,?,?,?,?,?,?,?,SYSDATE,SYSDATE,?)";

			String queryForInsertingRequestDetails="INSERT INTO WS_POLICY_TXN_REQUESTS_DETAILS(WPTR_REQUEST_DETAILS_ID,WPTR_REQUEST_ID,WPTR_TXN_REQUEST_INPUT,"+
					"WPTR_USER_CREATED,WPTR_USER_MODIFIED,WPTR_DATE_CREATED,WPTR_DATE_MODIFIED) values (S_WPTR_REQUEST_ID_SEQ.NEXTVAL,?,?,?,?,SYSDATE,SYSDATE)";

			conn=requestContext.getConnection();

			for(PolicyTransaction policytransaction:policyTransactionList){
				pst=conn.prepareStatement(queryForInsertingTransaction,generatedColumns);
				pst.setString(1, policytransaction.getRequestType());
				pst.setString(2, policytransaction.getEntityReference());
				pst.setString(3, user.getFullName());
				pst.setString(4, user.getFullName());
				pst.setString(5, policytransaction.getProductCode().toUpperCase());
				pst.setString(6, policytransaction.getRequestName());
				pst.setString(7, policytransaction.getNewEntityReference());
				pst.setString(8, policytransaction.getTransactionName());
				pst.setInt(9, policytransaction.getMaxFailedAttempts());
				pst.execute();
				rs=pst.getGeneratedKeys();

				int requestId=0;

				while(rs.next()){
					requestId=rs.getInt(1);
				}
				addedRequests.add(requestId);
				if(policytransaction.getRequestDetail()!=null){
					PreparedStatement pstRequestDetails=null;
					ResultSet rsRequestDetail=null;
					try{
						pstRequestDetails=conn.prepareStatement(queryForInsertingRequestDetails);
						pstRequestDetails.setInt(1, requestId);
						Clob clob = conn.createClob();
						clob.setString(1, policytransaction.getRequestDetail().getRequestInput());
						pstRequestDetails.setClob(2, clob);
						pstRequestDetails.setString(3, user.getFullName());
						pstRequestDetails.setString(4, user.getFullName());
						pstRequestDetails.execute();
					}catch(Exception e){
						List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(e.getMessage()));
						String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
						WebServiceLoggerUtil.logError("ATPTaskServiceImpl", "getRequestSpecifics", "Failed:", new Object[] { "While inserting request details for requestId:"+requestId }, e);
						throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);	
					}finally{
						DBUtil.close(rsRequestDetail, pstRequestDetails);
					}
				}
			}
			confirmation.setCode("200");
			confirmation.setApiRequestIds(addedRequests);
			confirmation.setDescription("Request created successfully with Id:"+StringUtils.join(addedRequests, ","));

		}catch (APIException e) {
			WebServiceLoggerUtil.logError("ATPTaskServiceImpl", "addATPRequest", "Failed:"+e.getErrorMessage(), new Object[] { null }, e);
			throw e;
		} catch (Exception e) {
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(e.getMessage()));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError("ATPTaskServiceImpl", "addATPRequest", "Failed:", new Object[] { e.getMessage() }, e);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		}finally{
			try {
				DBUtil.close(rs, pst, conn);
			} catch (SQLException e) {
				// TjODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return confirmation;
	}

	@Override
	public Object updateATPResponse() throws APIException {
		PolicyTransactionConfirmation confirmation=new PolicyTransactionConfirmation();
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		Connection conn = null;
		PreparedStatement pstResponse=null;
		ResultSet rsResponse=null;

		PreparedStatement pst=null;
		ResultSet rs=null;
		try{
			ObjectMapper mapper=new ObjectMapper();
			String inputJson=APIOperationUtil.fetchRequestBody(request);
			PolicyTransaction inputPolicyTransaction=mapper.readValue(inputJson, PolicyTransaction.class);

			checkingRequest=true;
			List<PolicyTransaction> listOfExisting=(List<PolicyTransaction>)getRequestSpecifics(inputPolicyTransaction.getRequestId(), null, null, null, null, 0, null, null, null, null,0,null);

			if(inputPolicyTransaction.getRequestId()!=0 && listOfExisting!=null && listOfExisting.size()>0){

				conn=requestContext.getConnection();
				PolicyTransactionResponseDetail responseDetail=listOfExisting.get(0).getResponseDetail();
				String upsertQueryOperation=null;

				PolicyTransactionResponseDetail inputResponseDetails=inputPolicyTransaction.getResponseDetail();
				//byte[] fileInput = Base64.decodeBase64(inputResponseDetails.getResponseOutput());
				Clob clob = conn.createClob();
				clob.setString(1, inputResponseDetails.getResponseOutput());

				if(responseDetail!=null && responseDetail.getResponseId()>0){
					upsertQueryOperation="UPDATE WS_POLICY_TRANSACTION_RESPONSE SET WPTS_TXN_RESPONSE_OUTPUT=?,"+
							"WPTS_USER_MODIFIED=?,WPTS_DATE_MODIFIED=sysdate WHERE WPTS_RESPONSE_ID=?"+
							" AND WPTS_REQUEST_ID=? ";
					pstResponse=conn.prepareStatement(upsertQueryOperation);
					pstResponse.setClob(1, clob);
					pstResponse.setString(2, user.getFullName());
					pstResponse.setInt(3, responseDetail.getResponseId());
					pstResponse.setInt(4, responseDetail.getRequestId());


				}else{
					upsertQueryOperation="INSERT INTO WS_POLICY_TRANSACTION_RESPONSE (WPTS_RESPONSE_ID,WPTS_REQUEST_ID,WPTS_TXN_RESPONSE_OUTPUT,WPTS_USER_CREATED,"+
							"WPTS_USER_MODIFIED,WPTS_DATE_CREATED,WPTS_DATE_MODIFIED) values (S_WPTS_REQUEST_ID_SEQ.NEXTVAL,?,?,?,?,SYSDATE,SYSDATE)";

					pstResponse=conn.prepareStatement(upsertQueryOperation);
					pstResponse.setInt(1, inputPolicyTransaction.getRequestId());
					pstResponse.setClob(2, clob);
					pstResponse.setString(3, user.getFullName());
					pstResponse.setString(4, user.getFullName());
				}
				//int executed=pstResponse.executeUpdate();
				pstResponse.execute();
				//if(){
				String updateRequest="UPDATE WS_POLICY_TRANSACTION_REQUESTS SET WBN_DATE_MODIFIED=SYSDATE,WBN_USER_MODIFIED=?,WBN_STATUS=?,WBN_FAILED_ATTEMPTS=?,WBN_NEW_ENTITY_REFERENCE=?"+
						" WHERE WBN_REQUEST_ID=?";

				pst=conn.prepareStatement(updateRequest);
				pst.setString(1, user.getFullName());
				pst.setString(2, inputPolicyTransaction.getStatus());
				int failedAttempts=listOfExisting.get(0).getFailedAttempts();//inputPolicyTransaction.getFailedAttempts();
				if(inputPolicyTransaction.getStatus().equalsIgnoreCase("FAILED")){
					failedAttempts++;
				}
				pst.setInt(3, failedAttempts);
				pst.setString(4, inputPolicyTransaction.getNewEntityReference());
				pst.setInt(5, inputPolicyTransaction.getRequestId());

				pst.execute();
				confirmation.setCode("200");
				List<Integer> updatedIds=new ArrayList<Integer>();
				updatedIds.add(inputPolicyTransaction.getRequestId());
				confirmation.setApiRequestIds(updatedIds);
				confirmation.setDescription("Request "+inputPolicyTransaction.getRequestId()+" is updated successfully.");
			}else{
				List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList("Please provide a vaild existing request it. Invalid requestId:"+inputPolicyTransaction.getRequestId()));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logError("ATPTaskServiceImpl", "updateATPResponse", "Failed:", new Object[] { null }, null);
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);	
			}
		}catch (APIException e) {
			WebServiceLoggerUtil.logError("QuotePolicyAttachmentServiceImpl", "getQuotePolicyAllAttachmentsList", "Failed:"+e.getErrorMessage(), new Object[] { null }, e);
			throw e;
		} catch (Exception e) {
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(e.getMessage()));

			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError("QuotePolicyAttachmentServiceImpl", "getQuotePolicyAllAttachmentsList", "Failed:", new Object[] { e.getMessage() }, e);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		}finally{
			try{
				DBUtil.close(rs, pst);
			}catch(Exception exp){
				//do nothing
			}
			try{
				DBUtil.close(rsResponse, pstResponse, conn);
			}catch(Exception exp){
				//do nothing
			}
		}

		return confirmation;
	}

	@Override
	public Object getRequestSpecifics(
			int requestId,String requestType,
			String policyReference, String productCode, String status,
			int failedAttempts, String transactionName,String requestName,
			String dateModifiedStart, String dateModifiedEnd,int maxFailedAttempts,String prepareEndPoint)  throws APIException {
		
		
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		Connection conn = null;
		PreparedStatement pst=null;
		ResultSet rs=null;

		List<PolicyTransaction> policyTransactionList=new ArrayList<PolicyTransaction>();
		
		if(null!=prepareEndPoint && "Y".equalsIgnoreCase(prepareEndPoint)){

			try{
				String finalExecutableQuery=queryForProductDesc;
				String productDesc = "";
				String endPointURL=null;
				String httpMethod=null;
				
				conn=requestContext.getConnection();
				pst=conn.prepareStatement(finalExecutableQuery);
				pst.setString(1, productCode);
				rs=pst.executeQuery();
				while(rs.next()){				
					productDesc = rs.getString("ProductDesc");
				}
				
				if(!"".equalsIgnoreCase(transactionName)){
					if(transactionName.equalsIgnoreCase("CreateQuote")){
						endPointURL="/mic/api/oas/quote-~productName~/v1/quote";
						httpMethod = "POST";
					}else if(transactionName.equalsIgnoreCase("CreatePolicy")){
						endPointURL="/mic/api/oas/policy-~productName~/v1/policy";
						httpMethod = "POST";
					}else if(transactionName.equalsIgnoreCase("EndorsePolicy")){
						endPointURL="/mic/api/oas/policy-~productName~/v1/policy/~entity-ref~/endorse";
						endPointURL = endPointURL.replaceAll("~entity-ref~",policyReference);
						httpMethod = "POST";
					}else if(transactionName.equalsIgnoreCase("UpdateQuote")){
						endPointURL="/mic/api/oas/quote/v1/quote-~productName~/~entity-ref~";
						endPointURL = endPointURL.replaceAll("~entity-ref~",policyReference);
						httpMethod = "PUT";
					}else if(transactionName.equalsIgnoreCase("GetQuote")){
						endPointURL="/mic/api/oas/quote/v1/quote-~productName~/~entity-ref~";
						endPointURL = endPointURL.replaceAll("~entity-ref~",policyReference);
						httpMethod = "GET";
					}else if(transactionName.equalsIgnoreCase("UpdatePolicy")){
						endPointURL="/mic/api/oas/policy/v1/policy-~productName~/~entity-ref~";
						endPointURL = endPointURL.replaceAll("~entity-ref~",policyReference);
						httpMethod = "PUT";
					}else if(transactionName.equalsIgnoreCase("GetPolicy")){
						endPointURL="/mic/api/oas/policy/v1/policy-~productName~/~entity-ref~";
						endPointURL = endPointURL.replaceAll("~entity-ref~",policyReference);
						httpMethod = "GET";
					}else if(transactionName.equalsIgnoreCase("PurgeQuote")){
						endPointURL="/mic/api/oas/quote/v1/quote-common/~quoteId~";
						endPointURL = endPointURL.replaceAll("~quoteId~",policyReference);
						httpMethod = "DELETE";
					}else if(transactionName.equalsIgnoreCase("PurgePolicy")){
						endPointURL="/mic/api/oas/policy/v1/policy-common/~policyId~";
						endPointURL = endPointURL.replaceAll("~policyId~",policyReference);
						httpMethod = "DELETE";
					}else if(transactionName.equalsIgnoreCase("PendingCancellation")){
						endPointURL="/mic/api/oas/policy/v1/policy-common/~policyId~/pending-cancellation";
						endPointURL = endPointURL.replaceAll("~policyId~",policyReference);
						httpMethod = "POST";
					}else if(transactionName.equalsIgnoreCase("RemovePendingCancellation")){
						endPointURL="/mic/api/oas/policy/v1/policy-common/~policyId~/remove-pending-cancellation";
						endPointURL = endPointURL.replaceAll("~policyId~",policyReference);
						httpMethod = "POST";
					}else if(transactionName.equalsIgnoreCase("MarkRenewable")){
						endPointURL="/mic/api/oas/policy/v1/policy-common/~policyId~/mark-renewable";
						endPointURL = endPointURL.replaceAll("~policyId~",policyReference);
						httpMethod = "POST";
					}else if(transactionName.equalsIgnoreCase("MarkNonRenewable")){
						endPointURL="/mic/api/oas/policy/v1/policy-common/~policyId~/mark-non-renewable";
						endPointURL = endPointURL.replaceAll("~policyId~",policyReference);
						httpMethod = "POST";
					}else if(transactionName.equalsIgnoreCase("InterimAudit")){
						endPointURL="/mic/api/oas/policy-~productName~/v1/policy/~entity-ref~/interimAudit";
						endPointURL = endPointURL.replaceAll("~entity-ref~",policyReference);
						httpMethod = "POST";
					}else if(transactionName.equalsIgnoreCase("FinalAudit")){
						endPointURL="/mic/api/oas/policy-~productName~/v1/policy/~entity-ref~/finalAudit";
						endPointURL = endPointURL.replaceAll("~entity-ref~",policyReference);
						httpMethod = "POST";
					}
				}
				
				if(endPointURL!=null || !"".equalsIgnoreCase(endPointURL)){
					endPointURL = endPointURL.replaceAll("~productName~",productDesc);
				}
								
				Map result = new HashMap();
				result.put("endPointURL", endPointURL);
				result.put("httpMethod", httpMethod);		
				return result;
				
			}catch(APIException e){
				throw e;
			}catch(Exception e){
				List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(e.getMessage()));
				String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
				WebServiceLoggerUtil.logError("ATPTaskServiceImpl", "getRequestSpecifics", "Failed:", new Object[] { e.getMessage() }, e);
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
			}finally{
				try{
					DBUtil.close(rs, pst, conn);
				}catch(Exception exp){
					//do nothing
				}
				
			}
			
		}else{

			try{
				List<Object> bindVariables = new ArrayList<Object>();
				String finalExecutableQuery=queryToFetchPolicyTransaction;
				if(requestId>0){
					finalExecutableQuery+=" AND WBN_REQUEST_ID= ?";
					bindVariables.add(requestId);
				}

				if(requestType!=null && !"".equalsIgnoreCase(requestType)){
					finalExecutableQuery+=" AND UPPER(WBN_REQUEST_TYPE)=UPPER(?)";
					bindVariables.add(requestType);
				}

				if(policyReference!=null && !"".equalsIgnoreCase(policyReference)){
					finalExecutableQuery+=" AND UPPER(WBN_POLICY_REFERENCE)=UPPER(?)";
					bindVariables.add(policyReference);
				}

				if(productCode!=null && !"".equalsIgnoreCase(productCode)){
					finalExecutableQuery+=" AND UPPER(WBN_PRODUCT_CODE)=UPPER(?)";
					bindVariables.add(productCode);
				}

				if(status!=null && !"".equalsIgnoreCase(status)){
					finalExecutableQuery+=" AND UPPER(WBN_STATUS)=UPPER(?)";
					bindVariables.add(status);
				}

				if(failedAttempts>0){
					finalExecutableQuery+=" AND WBN_FAILED_ATTEMPTS= ?";
					bindVariables.add(failedAttempts);
				}

				if(status!=null && !"".equalsIgnoreCase(status)){
					finalExecutableQuery+=" AND UPPER(WBN_STATUS)=UPPER(?)";
					bindVariables.add(status);
				}

				if(transactionName!=null && !"".equalsIgnoreCase(transactionName)){
					finalExecutableQuery+=" AND UPPER(WBN_TRANSACTION_NAME)=UPPER(?)";
					bindVariables.add(transactionName);
				}

				if(requestName!=null && !"".equalsIgnoreCase(requestName)){
					finalExecutableQuery+=" AND UPPER(WBN_REQUEST_NAME)=UPPER(?)";
					bindVariables.add(requestName);
				}

				if(dateModifiedStart!=null && !"".equalsIgnoreCase(dateModifiedStart)){
					finalExecutableQuery+=" AND to_char(NVL(WBN_DATE_MODIFIED,WBN_DATE_CREATED),'MM/DD/YYYY')>=to_date(?,'MM/DD/YYYY')";
					bindVariables.add(dateModifiedStart);
				}

				if(dateModifiedEnd!=null && !"".equalsIgnoreCase(dateModifiedEnd)){
					finalExecutableQuery+=" AND to_char(NVL(WBN_DATE_MODIFIED,WBN_DATE_CREATED),'MM/DD/YYYY')<=to_date(?,'MM/DD/YYYY')";
					bindVariables.add(dateModifiedEnd);
				}
				
				if(maxFailedAttempts>0){
					finalExecutableQuery+=" AND WBN_MAX_FAILED_ATTEMPTS= ?";
					bindVariables.add(maxFailedAttempts);
				}
				
				conn=requestContext.getConnection();
				pst=conn.prepareStatement(finalExecutableQuery);
				GeneralUtil.bindVariablesToStatementGeneric(bindVariables, pst, 0);
				rs=pst.executeQuery();

				while(rs.next()){
					PolicyTransaction transaction=new PolicyTransaction();

					transaction.setRequestId(rs.getInt("WBN_REQUEST_ID"));
					transaction.setRequestType(rs.getString("WBN_REQUEST_TYPE"));
					transaction.setEntityReference(rs.getString("WBN_POLICY_REFERENCE"));
					transaction.setUserCreated(rs.getString("WBN_USER_CREATED"));
					transaction.setUserModified(rs.getString("WBN_USER_MODIFIED"));
					transaction.setDateCreated(rs.getString("dateCreated"));
					transaction.setDateModified(rs.getString("dateModified"));
					transaction.setProductCode(rs.getString("WBN_PRODUCT_CODE"));
					transaction.setRequestName(rs.getString("WBN_REQUEST_NAME"));
					transaction.setStatus(rs.getString("WBN_STATUS"));
					transaction.setFailedAttempts(rs.getInt("WBN_FAILED_ATTEMPTS"));
					transaction.setNewEntityReference(rs.getString("WBN_NEW_ENTITY_REFERENCE"));
					transaction.setTransactionName(rs.getString("WBN_TRANSACTION_NAME"));
					transaction.setMaxFailedAttempts(rs.getInt("WBN_MAX_FAILED_ATTEMPTS"));

					if(!checkingRequest){
						PreparedStatement pstRequestDetail=null;
						ResultSet rsRequestDetail=null;

						try{
							pstRequestDetail=conn.prepareStatement(queryForRequestDetails);
							pstRequestDetail.setInt(1, transaction.getRequestId());
							rsRequestDetail=pstRequestDetail.executeQuery();

							while(rsRequestDetail.next()){
								PolicyTransactionRequestDetail requestDetail=new PolicyTransactionRequestDetail();
								requestDetail.setDateCreated(rsRequestDetail.getString("dateCreated"));
								requestDetail.setDateModified(rsRequestDetail.getString("dateModified"));
								requestDetail.setRequestDetailsId(rsRequestDetail.getInt("WPTR_REQUEST_DETAILS_ID"));
								requestDetail.setRequestId(rsRequestDetail.getInt("WPTR_REQUEST_ID"));
								Clob requestInput=rsRequestDetail.getClob("WPTR_TXN_REQUEST_INPUT");
								String savedFile=(String)requestInput.getSubString(1,(int)requestInput.length());
								requestDetail.setRequestInput(savedFile);
								requestDetail.setUserCreated(rsRequestDetail.getString("WPTR_USER_CREATED"));
								requestDetail.setUserModified(rsRequestDetail.getString("WPTR_USER_MODIFIED"));
								transaction.setRequestDetail(requestDetail);
							}
						}catch(Exception e){
							List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(e.getMessage()));
							String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
							WebServiceLoggerUtil.logError("ATPTaskServiceImpl", "getRequestSpecifics", "Failed:", new Object[] { "While fetching request details for requestId:"+transaction.getRequestId() }, e);
							throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
						}
						finally{
							DBUtil.close(rsRequestDetail, pstRequestDetail);
						}
					}

					PreparedStatement pstResponseDetail=null;
					ResultSet rsResponseDetail=null;
					try{
						pstResponseDetail=conn.prepareStatement(queryForResponseDetails);
						pstResponseDetail.setInt(1, transaction.getRequestId());
						rsResponseDetail=pstResponseDetail.executeQuery();
						while(rsResponseDetail.next()){
							PolicyTransactionResponseDetail responseDetail=new PolicyTransactionResponseDetail();

							responseDetail.setDateCreated(rsResponseDetail.getString("dateCreated"));
							responseDetail.setDateModified(rsResponseDetail.getString("dateModified"));
							responseDetail.setRequestId(rsResponseDetail.getInt("WPTS_REQUEST_ID"));
							responseDetail.setResponseId(rsResponseDetail.getInt("WPTS_RESPONSE_ID"));
							Clob responseOutput=rsResponseDetail.getClob("WPTS_TXN_RESPONSE_OUTPUT");
							String savedFile=responseOutput.getSubString(1,(int)responseOutput.length());
							responseDetail.setResponseOutput(savedFile);
							responseDetail.setUserCreated(rsResponseDetail.getString("WPTS_USER_CREATED"));
							responseDetail.setUserModified(rsResponseDetail.getString("WPTS_USER_MODIFIED"));

							transaction.setResponseDetail(responseDetail);

						}
					}catch(Exception e){
						List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(e.getMessage()));
						String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
						WebServiceLoggerUtil.logError("ATPTaskServiceImpl", "getRequestSpecifics", "Failed:", new Object[] { "While fetching response details for requestId:"+transaction.getRequestId() }, e);
						throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
					}
					finally{
						DBUtil.close(rsResponseDetail, pstResponseDetail);
					}

					policyTransactionList.add(transaction);
				}
			}catch(APIException e){
				throw e;
			}catch(Exception e){
				List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(e.getMessage()));
				String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
				WebServiceLoggerUtil.logError("ATPTaskServiceImpl", "getRequestSpecifics", "Failed:", new Object[] { e.getMessage() }, e);
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
			}finally{
				try{
					DBUtil.close(rs, pst);
				}catch(Exception exp){
					//do nothing
				}
				if(!checkingRequest){
					try{
						DBUtil.close(conn);
					}catch(Exception exp){}
				}
			}
		}


		return policyTransactionList;
	}

}
