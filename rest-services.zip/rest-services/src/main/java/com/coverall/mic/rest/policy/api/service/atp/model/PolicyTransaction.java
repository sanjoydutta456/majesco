package com.coverall.mic.rest.policy.api.service.atp.model;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class PolicyTransaction {
	
	private int requestId;
	private String requestType;    
	private String entityReference;
	private String userCreated;
	private String dateCreated;
	private String userModified;
	private String dateModified;
	private String requestName;
	private String productCode;	
	private String status;
	private int failedAttempts;
	private int maxFailedAttempts;
	private String newEntityReference;
	private String transactionName;
	
	private PolicyTransactionRequestDetail requestDetail;
	private PolicyTransactionResponseDetail responseDetail;
	public int getRequestId() {
		return requestId;
	}
	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	public String getEntityReference() {
		return entityReference;
	}
	public void setEntityReference(String entityReference) {
		this.entityReference = entityReference;
	}
	public String getUserCreated() {
		return userCreated;
	}
	public void setUserCreated(String userCreated) {
		this.userCreated = userCreated;
	}
	public String getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(String dateCreated) {
		this.dateCreated = dateCreated;
	}
	public String getUserModified() {
		return userModified;
	}
	public void setUserModified(String userModified) {
		this.userModified = userModified;
	}
	public String getDateModified() {
		return dateModified;
	}
	public void setDateModified(String dateModified) {
		this.dateModified = dateModified;
	}
	public String getRequestName() {
		return requestName;
	}
	public void setRequestName(String requestName) {
		this.requestName = requestName;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getFailedAttempts() {
		return failedAttempts;
	}
	public void setFailedAttempts(int failedAttempts) {
		this.failedAttempts = failedAttempts;
	}
	public int getMaxFailedAttempts() {
		return maxFailedAttempts;
	}
	public void setMaxFailedAttempts(int maxFailedAttempts) {
		this.maxFailedAttempts = maxFailedAttempts;
	}
	public String getNewEntityReference() {
		return newEntityReference;
	}
	public void setNewEntityReference(String newEntityReference) {
		this.newEntityReference = newEntityReference;
	}
	public String getTransactionName() {
		return transactionName;
	}
	public void setTransactionName(String transactionName) {
		this.transactionName = transactionName;
	}
	public PolicyTransactionRequestDetail getRequestDetail() {
		return requestDetail;
	}
	public void setRequestDetail(PolicyTransactionRequestDetail requestDetail) {
		this.requestDetail = requestDetail;
	}
	public PolicyTransactionResponseDetail getResponseDetail() {
		return responseDetail;
	}
	public void setResponseDetail(PolicyTransactionResponseDetail responseDetail) {
		this.responseDetail = responseDetail;
	}
		
}

