package com.coverall.mic.rest.policy.api.service.atp.model;

import java.util.List;

public class PolicyTransactionConfirmation {
	
	String code;
	String description;
	List<Integer> apiRequestIds;

	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<Integer> getApiRequestIds() {
		return apiRequestIds;
	}
	public void setApiRequestIds(List<Integer> apiRequestIds) {
		this.apiRequestIds = apiRequestIds;
	}
}
