package com.coverall.mic.rest.policy.api.service.atp.model;

public class PolicyTransactionRequestDetail {
	
	
	private int requestDetailsId;
	private int requestId;
	private String requestInput;
	private String userCreated;
	private String dateCreated;
	private String userModified;
	private String dateModified;
	public int getRequestDetailsId() {
		return requestDetailsId;
	}
	public void setRequestDetailsId(int requestDetailsId) {
		this.requestDetailsId = requestDetailsId;
	}
	public int getRequestId() {
		return requestId;
	}
	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}
	public String getRequestInput() {
		return requestInput;
	}
	public void setRequestInput(String requestInput) {
		this.requestInput = requestInput;
	}
	public String getUserCreated() {
		return userCreated;
	}
	public void setUserCreated(String userCreated) {
		this.userCreated = userCreated;
	}
	public String getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(String dateCreated) {
		this.dateCreated = dateCreated;
	}
	public String getUserModified() {
		return userModified;
	}
	public void setUserModified(String userModified) {
		this.userModified = userModified;
	}
	public String getDateModified() {
		return dateModified;
	}
	public void setDateModified(String dateModified) {
		this.dateModified = dateModified;
	}
	
}
