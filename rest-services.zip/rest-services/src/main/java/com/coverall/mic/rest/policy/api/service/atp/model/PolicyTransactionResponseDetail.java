package com.coverall.mic.rest.policy.api.service.atp.model;

public class PolicyTransactionResponseDetail {
	
	private int responseId;
	private int requestId;
	private String responseOutput;
	private String userCreated;
	private String dateCreated;
	private String userModified;
	private String dateModified;

	public int getResponseId() {
		return responseId;
	}
	public void setResponseId(int responseId) {
		this.responseId = responseId;
	}
	public int getRequestId() {
		return requestId;
	}
	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}
	public String getResponseOutput() {
		return responseOutput;
	}
	public void setResponseOutput(String responseOutput) {
		this.responseOutput = responseOutput;
	}
	public String getUserCreated() {
		return userCreated;
	}
	public void setUserCreated(String userCreated) {
		this.userCreated = userCreated;
	}
	public String getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(String dateCreated) {
		this.dateCreated = dateCreated;
	}
	public String getUserModified() {
		return userModified;
	}
	public void setUserModified(String userModified) {
		this.userModified = userModified;
	}
	public String getDateModified() {
		return dateModified;
	}
	public void setDateModified(String dateModified) {
		this.dateModified = dateModified;
	}
}
