package com.coverall.mic.rest.policy.api.service.chatbot;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;


@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON , MediaType.MULTIPART_FORM_DATA })
@Produces({ MediaType.APPLICATION_JSON , MediaType.MULTIPART_FORM_DATA })
public interface ChatbotApiService {

	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@GET
	@Path("/productList")
	public Object getProductListForNewQuote(@Context HttpServletRequest request) throws Exception;
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@GET
	@Path("/getEndorseTransaction/{policyNumber}")
	public Object getEndormentTransactionForPolicies(@Context HttpServletRequest request, @PathParam("policyNumber") String policyNumber) throws Exception;
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@GET
	@Path("/getRenewTransaction/{policyNumber}")
	public Object getRenewTransactionForPolicies(@Context HttpServletRequest request, @PathParam("policyNumber") String policyNumber) throws Exception;
	
	@GET
	@Path("ping")
	public String ping();
	
}
