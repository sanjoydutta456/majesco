package com.coverall.mic.rest.policy.api.service.chatbot.impl;

import java.io.UnsupportedEncodingException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import com.coverall.exceptions.FolderException;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.chatbot.ChatbotApiService;
import com.coverall.mic.rest.policy.api.service.chatbot.model.NewQuoteProducts;
import com.coverall.mic.rest.policy.api.service.chatbot.model.QuoteAllProductSearch;
import com.coverall.mic.rest.policy.api.service.chatbot.model.SpecificTransaction;
import com.coverall.mic.rest.policy.api.service.chatbot.model.SpecificTransactionSearch;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mt.fm.FolderManager;
import com.coverall.mt.http.User;
import com.coverall.mt.nexgensecurity.NsRestClientUtil;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.mt.security.securityclient.AuthorizationService;
import com.coverall.security.model.NsRole;
import com.coverall.util.DBUtil;

import java.util.Arrays;

public class ChatbotApiServiceImpl extends ChatbotServiceSearch implements ChatbotApiService{
	String queryId = null;
	private String entityType;
	User user;
	ChatbotServiceSearch abstractService;
	private static final String RENEW_TRANSACTION = "Renew";
	private static final String ENDORSE_TRANSACTION = "Endorse";
	private static final String NEW_QUOTE_PRODUCT_SEARCH_QUERY_ID = "NewQuoteProductSearch";
	private static final String GET_AVAILABLE_TRANSACTION = "GetAvailableTransaction";
	
	
	@Override
	public Object getProductListForNewQuote( HttpServletRequest request) throws Exception {
		user = User.getUser(request);
		if(ChatbotServiceSearch.getHostURL() == null && request.getRequestURI() != null){
		  String requestURL = request.getScheme()+"://"+request.getServerName();
		  ChatbotServiceSearch.setHostURL(requestURL);
		}
		WebServiceLoggerUtil.logInfo("product list", " Request :", new Object[] { request });
		QuoteAllProductSearch quoteProducts = new QuoteAllProductSearch();
		NewQuoteProducts newProduct = null;
		ArrayList<Object> quoteProductList = new ArrayList<Object>();
		ArrayList<HashMap<String, String>> dataList = new ArrayList<HashMap<String, String>>();
		String query = getQuery(NEW_QUOTE_PRODUCT_SEARCH_QUERY_ID);
		dataList = executeQuery(query);
		
		for(Map<String, String> row : dataList) {
			newProduct = new NewQuoteProducts();
			newProduct.setProductName(row.get("PRODUCT_NAME"));
			addNavigationLink(newProduct, row);
			quoteProductList.add(newProduct);
			
		}
		quoteProducts.setProductList(quoteProductList);
		return quoteProducts;
	}
	
	@Override
	public String ping() {
		return "This returns list of all product accessible to user logged in.";
	}
	
	@Override
	public Object getEndormentTransactionForPolicies(HttpServletRequest request, String policyNumber)
			throws Exception {
		if (entityType == null) {
			entityType = "POLICY";
		}
		if (ChatbotServiceSearch.getHostURL() == null && request.getRequestURI() != null) {
			String requestURL = request.getScheme() + "://" + request.getServerName();
			ChatbotServiceSearch.setHostURL(requestURL);
		}
		SpecificTransactionSearch transaction = new SpecificTransactionSearch();
		String entityReference = getMaxEntityReference(policyNumber, request, user, entityType);
	
			user = User.getUser(request);
			Connection conn = null;
			CallableStatement callStmt = null;
			try {
				if (entityReference != null) {
					// Extracting user specific info
					conn = APIRequestContext.getApiRequestContext().getConnection();
					String userName = user.getUserId();
					String domain = user.getDomain();
					String rolesString = "";

					// Fetching roles list for the user
					AuthorizationService authorizationService = NsRestClientUtil
							.getAuthorizationServiceInstance(user.getDomain());
					Set<NsRole> roles = authorizationService.getAssignedRolesForUser(user.getFullName());
					// get user roles assigned to loggedin user
					for (NsRole role : roles) {
						rolesString += "''" + role.getName() + "'',";
					}
					rolesString = rolesString.substring(0, rolesString.length() - 1);

					// Firing Database Query for getting all transactions
					if (queryId == null) {
						queryId = GET_AVAILABLE_TRANSACTION;
					}
					String sqlQuery = getQuery(queryId);
					String transactions = executeTransactionQuery(sqlQuery, entityType, entityReference, domain,
							userName, rolesString, conn);

					ArrayList<SpecificTransaction> beans = getListOfEndorsementTransaction(transactions, request,
							policyNumber, entityReference, conn);
					ArrayList<Object> object = new ArrayList<Object>();
					object.add(beans);
					transaction.setSpecificTransactions(object);
				} else {
					String errMsg = entityType
							+ " was not found. Please check input parameters.";
					List<Message> errorMessageList = ChatbotServiceSearch
							.getErrorMessageList(Collections.singletonList(errMsg));
					String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
					WebServiceLoggerUtil.logInfo("ChatbotApiServiceImpl", "getEndormentTransactionForPolicies",
							errMsg, new Object[] { errMsg });
					throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, null);
				}
			} catch (APIException e) {
				WebServiceLoggerUtil.logError("ChatbotApiServiceImpl", "getEndormentTransactionForPolicies",
						e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
				throw e;
			} catch (Exception e) {
				List<Message> errorMessageList = ChatbotServiceSearch
						.getErrorMessageList(Collections.singletonList(e.getMessage()));
				String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
				WebServiceLoggerUtil.logError("ChatbotApiServiceImpl", "getEndormentTransactionForPolicies",
						e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
				throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, e);
			} finally {
				try {
					DBUtil.close(null, callStmt, conn);
				} catch (SQLException e) {
					WebServiceLoggerUtil.logInfo("ChatbotApiServiceImpl", "getEndormentTransactionForPolicies",
							e.getLocalizedMessage(), new Object[] { e.getMessage() });
				}
			}
		//}
		return transaction;
	}
	
	@Override
	public Object getRenewTransactionForPolicies(HttpServletRequest request, String policyNumber) throws Exception {
		if (entityType == null) {
			entityType = "POLICY";
		}
		if (ChatbotServiceSearch.getHostURL() == null && request.getRequestURI() != null) {
			String requestURL = request.getScheme() + "://" + request.getServerName();
			ChatbotServiceSearch.setHostURL(requestURL);
		}
		SpecificTransactionSearch transaction = new SpecificTransactionSearch();
		String entityReference = getMaxEntityReference(policyNumber, request, user, entityType);
	
			user = User.getUser(request);
			Connection conn = null;
			CallableStatement callStmt = null;

			try {
				conn = APIRequestContext.getApiRequestContext().getConnection();
				if (entityReference != null) {
					// Extracting user specific info
					String userName = user.getUserId();
					String domain = user.getDomain();
					String rolesString = "";

					// Fetching roles list for the user
					AuthorizationService authorizationService = NsRestClientUtil
							.getAuthorizationServiceInstance(user.getDomain());
					Set<NsRole> roles = authorizationService.getAssignedRolesForUser(user.getFullName());
					// get user roles assigned to loggedin user
					for (NsRole role : roles) {
						rolesString += "''" + role.getName() + "'',";
					}
					rolesString = rolesString.substring(0, rolesString.length() - 1);

					// Firing Database Query for getting all transactions
					if (queryId == null) {
						queryId = GET_AVAILABLE_TRANSACTION;
					}
					String sqlQuery = getQuery(queryId);
					String transactions = executeTransactionQuery(sqlQuery, entityType, entityReference, domain,
							userName, rolesString, conn);

					ArrayList<SpecificTransaction> beans = getListOfRenewTransaction(transactions, request,
							policyNumber, entityReference, conn);
					ArrayList<Object> object = new ArrayList<Object>();
					object.add(beans);
					transaction.setSpecificTransactions(object);
				} else {
					String errMsg = entityType
							+ " was not found. Please check input parameters.";
					List<Message> errorMessageList = ChatbotServiceSearch
							.getErrorMessageList(Collections.singletonList(errMsg));
					String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
					WebServiceLoggerUtil.logInfo("ChatbotApiServiceImpl", "getRenewTransactionForPolicies",
							errMsg, new Object[] { errMsg });
					throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, null);
				}
			} catch (APIException e) {
				WebServiceLoggerUtil.logError("ChatbotApiServiceImpl", "getRenewTransactionForPolicies",
						e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
				throw e;
			} catch (Exception e) {
				List<Message> errorMessageList = ChatbotServiceSearch
						.getErrorMessageList(Collections.singletonList(e.getMessage()));
				String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
				WebServiceLoggerUtil.logError("ChatbotApiServiceImpl", "getRenewTransactionForPolicies",
						e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
				throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, e);
			} finally {
				try {
					DBUtil.close(null, callStmt, conn);
				} catch (SQLException e) {
					WebServiceLoggerUtil.logInfo("ChatbotApiServiceImpl", "getRenewTransactionForPolicies",
							e.getLocalizedMessage(), new Object[] { e.getMessage() });
				}
		}
		return transaction;
	}
	
	public ArrayList<SpecificTransaction> getListOfEndorsementTransaction(String transactionResponse,
			HttpServletRequest request, String policyNumber, String entityReference, Connection conn)
			throws UnsupportedEncodingException, FolderException {
		ArrayList<SpecificTransaction> transactions = new ArrayList<SpecificTransaction>();
		final String TRANS_TYPE = "endorsement";
		int count = 0;
		ArrayList<HashMap<String, String>> policyDataList = new ArrayList<HashMap<String, String>>();
		HashMap<String, String> transactionDataList = new HashMap<String, String>();
		policyDataList = getEndorsePolicyDetails(policyNumber, request, entityReference, entityType, conn);
		transactionDataList = getEndorseTransactionDetails(policyNumber, request, entityReference, conn);
		List<String> allTransactionStrings = Arrays.asList(transactionResponse.split("~"));
		List<String> allTransactionNames = new ArrayList<String>();
		for(String transactionName : allTransactionStrings) {
			allTransactionNames.add(transactionName.split("\\?")[0]);
		}
		for (String transactionStrings : allTransactionStrings) {
			SpecificTransaction transactionBean = new SpecificTransaction();
			boolean flag = true;
			for (Map<String, String> row : policyDataList) {
				
				row.putAll(transactionDataList);
				String transactionName = transactionStrings.split("\\?")[0];
				if (flag) {
					if (allTransactionNames.contains(ENDORSE_TRANSACTION) && transactionName.equals(ENDORSE_TRANSACTION)) {
						transactionBean.setTransactionName(transactionName);
						FolderManager folderManager = FolderManager.getInstance(user);
						Long folderId = folderManager.getEntityFolderId(entityType, entityReference, user);
						addSpecificNavigationLink(transactionBean, row, TRANS_TYPE, folderId, null);
						transactions.add(transactionBean);
						flag = false;
					} else if(!allTransactionNames.contains(ENDORSE_TRANSACTION) && count == 0){
						transactionBean.setTransactionName("Dashboard");
						addSpecificNavigationLink(transactionBean, row, "policyDashboard", null, ENDORSE_TRANSACTION);
						transactions.add(transactionBean);
						flag = false;
						count = 1;
					}
				}
			}
		}
		return transactions;
	}
	
	public ArrayList<SpecificTransaction> getListOfRenewTransaction(String transactionResponse,
			HttpServletRequest request, String policyNumber, String entityReference, Connection conn)
			throws UnsupportedEncodingException, FolderException {
		ArrayList<SpecificTransaction> transactions = new ArrayList<SpecificTransaction>();
		final String TRANS_TYPE = "renew";
		int count = 0;
		ArrayList<HashMap<String, String>> policyDataList = new ArrayList<HashMap<String, String>>();
		HashMap<String, String> transactionDataList = new HashMap<String, String>();
		policyDataList = getRenewPolicyDetails(policyNumber, request, entityReference, entityType, conn);
		transactionDataList = getRenewTransactionDetails(policyNumber, request, entityReference, conn);
		List<String> allTransactionStrings = Arrays.asList(transactionResponse.split("~"));
		List<String> allTransactionNames = new ArrayList<String>();
		for(String transactionName : allTransactionStrings) {
			allTransactionNames.add(transactionName.split("\\?")[0]);
		}
		
		for (String transactionStrings : allTransactionStrings) {
			SpecificTransaction transactionBean = new SpecificTransaction();
			boolean flag = true;
			
			for (Map<String, String> row : policyDataList) {
				
				row.putAll(transactionDataList);
				String transactionName = transactionStrings.split("\\?")[0];
				if (flag) {
					if (allTransactionNames.contains(RENEW_TRANSACTION) && transactionName.equals(RENEW_TRANSACTION)) {
						transactionBean.setTransactionName(transactionName);
						FolderManager folderManager = FolderManager.getInstance(user);
						long folderId = folderManager.getEntityFolderId(entityType, entityReference, user);
						addSpecificNavigationLink(transactionBean, row, TRANS_TYPE, folderId, null);
						transactions.add(transactionBean);
						flag = false;
					} else if (!allTransactionNames.contains(RENEW_TRANSACTION) && count == 0) {
						transactionBean.setTransactionName("Dashboard");
						addSpecificNavigationLink(transactionBean, row, "policyDashboard", null, RENEW_TRANSACTION);
						transactions.add(transactionBean);
						flag = false;
						count = 1;
					}
				}
			}
		}
		return transactions;
	}
}
