package com.coverall.mic.rest.policy.api.service.chatbot.impl;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import com.coverall.el.FunctionResolver;
import com.coverall.el.InlineExpression;
import com.coverall.el.VariableResolver;
import com.coverall.el.function.DefaultFunctionResolver;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.chatbot.model.NewQuoteProducts;
import com.coverall.mic.rest.policy.api.service.chatbot.model.SpecificTransaction;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.model.common.MessageItems;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.UnifiedSearchErrors;
import com.coverall.mt.dao.QueriesCache;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.el.variable.VariableResolverImpl;
import com.coverall.mt.http.HTTPConstants;
import com.coverall.mt.http.MICSession;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.pctv2.server.util.BookOverrideEntity;
import com.coverall.util.DBUtil;

public class ChatbotServiceSearch {
	
	static final String PARAM_USER = "user";

	static final String LINKS_QUERY_ID = "ChatbotNavigationLinks";
	static final String LINK ="LINK";
	static final String TYPE ="TYPE";
	static final String NAME = "NAME";
	static final String ACTION = "actions";
	static final String NAVIGATIONS = "navigations";
	static final String HOST_PLACEHODLER = "$HOST$";
	private static final String GET_MAX_ENTITY_REFERENCE= "GetMAXEntityReference";
	private static final String GET_ENDORSE_POLICY_DETAILS = "GetEndorsePolicyDetails";
	private static final String GET_RENEW_POLICY_DETAILS = "GetRenewPolicyDetails";
	private static final String GET_ENDORSE_TRANSACTION_DETAILS = "GetEndorseTransactionDetails";
	private static final String GET_RENEW_TRANSACTION_DETAILS = "GetRenewTransactionDetails";
		
	private static String hostURL ;
	
	private static HashMap<String,ArrayList<HashMap<String,String>>> commonEntityProperties = new HashMap<String, ArrayList<HashMap<String,String>>>();
	
	
	public static String getHostURL() {
		return hostURL;
	}

	public static void setHostURL(String hostURL) {
		ChatbotServiceSearch.hostURL = hostURL;
	}
	
	public String getQuery(String queryId) {
		User user = APIRequestContext.getApiRequestContext().getMtUser();

		HashMap variableMap = new HashMap();
		String sqlQuery = null;
		try {
			/*DAOManager daoManager = DAOManager.getInstance(ServletConfigUtil.COMPONENT_PORTAL);
			Query query = daoManager.getQuery(ServletConfigUtil.COMPONENT_PORTAL, user, queryId);
			if (query == null) {
				Exception apiException = new APIException(
						String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED, null,
						null);
				WebServiceLoggerUtil.logError("ChatbotApiServiceImpl", "getQuery",
						"Query not found in queries.xml file", new Object[] { queryId }, apiException);
				throw new APIException();
			}
			sqlQuery = query.toString();*/
			String customerCode = CustomerConfigUtil.getInstance().getCustomerCode(user.getDomain());
			sqlQuery = QueriesCache.getChatbotServiceSearchQueries(customerCode + "_" + queryId);
			if(sqlQuery == null || sqlQuery.length() == 0 ){
				Exception apiException = new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED, null,null);
				WebServiceLoggerUtil.logError("ChatbotApiServiceImpl", "getQuery","Query not found in queries.xml file", new Object[] { queryId }, apiException);
				throw new APIException();
			}
			Random randomizer = new Random();
			MICSession session = new MICSession(randomizer.nextInt() + "", null);
			WebServiceLoggerUtil.logInfo("AbstractChatbotEntitySearch", "getQuery", "User gettng used for DLS filter",
					new Object[] { user });
			HashMap params = new HashMap();
			params.put(PARAM_USER, user);
			params.put("domain", user.getDomain());
			params.put("userName", user.getUserId());
			params.put(ServletConfigUtil.COMPONENT, "portal");
			variableMap.put(VariableResolverImpl.REQUESTPARAMS_PARAMETER, params);
			session.setAttribute(HTTPConstants.SESSION_USER, user);
			variableMap.put(VariableResolverImpl.SESSION_PARAMETER, session);
			VariableResolver varResolver = new VariableResolverImpl(variableMap);
			FunctionResolver funcResolver = new DefaultFunctionResolver();
			InlineExpression expression = new InlineExpression(sqlQuery, varResolver, funcResolver);
			return expression.getValue();

		} catch (Exception e) {
			WebServiceLoggerUtil.logError("ChatbotApiServiceImpl", "getQuery", e.getLocalizedMessage(),
					new Object[] { queryId, sqlQuery }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
					APIConstant.FAILED,
					getErrorMessageList(
							Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),
					e);
		}

	}
	
	public static List<Message> getErrorMessageList(List<String> strMessages) {
		if (strMessages == null) {
			return null;
		}
		List<Message> errorMessageList = new ArrayList<Message>(strMessages.size());
		for (String aMsg : strMessages) {
			MessageItems messageItem = new MessageItems();
			messageItem.setUser(aMsg);
			errorMessageList.add(messageItem);
		}
		return errorMessageList;
	}
	
	protected void addNavigationLink(NewQuoteProducts searchRequest, Map<String, String> dataRow)
			throws UnsupportedEncodingException {
		loadCommonEntityProperties(searchRequest);
		ArrayList<HashMap<String, String>> entityProperties = commonEntityProperties.get("product");
		ArrayList<HashMap> navigationList = new ArrayList<HashMap>();
		for (HashMap<String, String> entityMap : entityProperties) {
			HashMap<String, String> linkMap = new HashMap<String, String>();
			String link = entityMap.get(LINK);
			// Replace HOST
			if (hostURL != null) {
				link = link.replace(HOST_PLACEHODLER, hostURL);
			}
			// Replace placeholder in the link
			for (String key : dataRow.keySet()) {
				String placeHolder = "$" + key + "$";
				if (link != null && link.indexOf(placeHolder) != -1) {
					String linkValue = URLEncoder.encode(dataRow.get(key), "UTF-8");
					link = link.replace(placeHolder, linkValue);
				}
			}
			String name = entityMap.get(NAME);
			linkMap.put(name, link);
			if (NAVIGATIONS.equalsIgnoreCase(entityMap.get(TYPE))) {
				ArrayList<HashMap> exitsingNavigationList = searchRequest.getNavigations();
				if (exitsingNavigationList != null) {
					exitsingNavigationList.add(linkMap);
				} else {
					navigationList.add(linkMap);
					searchRequest.setNavigations(navigationList);
				}
			}
		}
	}
	
	protected void addSpecificNavigationLink(SpecificTransaction searchRequest, Map<String, String> dataRow, String trans_type, Long folderId, String dashboardView)
			throws UnsupportedEncodingException {
		loadCommonEntityProperties(searchRequest);
		ArrayList<HashMap<String, String>> entityProperties = commonEntityProperties.get(trans_type);
		
		ArrayList<HashMap> navigationList = new ArrayList<HashMap>();
		for (HashMap<String, String> entityMap : entityProperties) {
			HashMap<String, String> linkMap = new HashMap<String, String>();
			String link = entityMap.get(LINK);
			// Replace HOST
			if (hostURL != null) {
				link = link.replace(HOST_PLACEHODLER, hostURL);
			}
			// Replace placeholder in the link
			for (String key : dataRow.keySet()) {
				String placeHolder = "$" + key + "$";
				if (link != null && link.indexOf(placeHolder) != -1) {
					if(key.equals("POLICY_NUMBER")) {
						String value = String.format("%09d", Integer.parseInt(dataRow.get("POLICY_NUMBER")));
						String linkValue = URLEncoder.encode(value, "UTF-8");
						link = link.replace(placeHolder, linkValue);
					} else {
						String linkValue = URLEncoder.encode(dataRow.get(key), "UTF-8");
						link = link.replace(placeHolder, linkValue);
					}
					
				}
				if(folderId != null) {
					link = link.replace("$FOLDER_ID$", folderId.toString());
					link = link.replace("$PORTLET_ID$", "PORTLET_FOLDER_"+folderId.toString()+"_ENTITY");
				}
			}
			String name = entityMap.get(NAME);
			if(null !=name && !name.isEmpty() && name.equalsIgnoreCase("policyDashboard") && null != dashboardView && !dashboardView.isEmpty()) {
				if(dashboardView.equalsIgnoreCase("Endorse")) {
					name = "endorsement";
				}else{
					name = "renew";
				}
			}
			linkMap.put(name, link);
			if (NAVIGATIONS.equalsIgnoreCase(entityMap.get(TYPE))) {
				ArrayList<HashMap> exitsingNavigationList = searchRequest.getNavigations();
				if (exitsingNavigationList != null) {
					exitsingNavigationList.add(linkMap);
				} else {
					navigationList.add(linkMap);
					searchRequest.setNavigations(navigationList);
				}
			}
		}
	}
	
	protected void loadCommonEntityProperties(Object searchRequest) {
		if (!commonEntityProperties.isEmpty()) {
			// The properties are already loaded
			return;
		}
		String linkQuery = getQuery(LINKS_QUERY_ID);
		ArrayList<HashMap<String, String>> dataRecords = executeQuery(linkQuery);
		for (HashMap<String, String> row : dataRecords) {
			if (row != null) {
				String entityId = row.get("NAME");
				ArrayList<HashMap<String, String>> loadedData = commonEntityProperties.get(entityId);
				if (loadedData == null) {
					ArrayList<HashMap<String, String>> initialRow = new ArrayList<HashMap<String, String>>();
					initialRow.add(row);
					commonEntityProperties.put(entityId, initialRow);
				} else {
					loadedData.add(row);
				}
			}
		}
	}
	
	protected ArrayList<HashMap<String, String>> executeQuery(String query) {
		ArrayList<HashMap<String, String>> dataList = new ArrayList<HashMap<String, String>>();
		Connection conn = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		HashMap<String, String> row = null;
		try {
			conn = APIRequestContext.getApiRequestContext().getConnection();
			statement = conn.prepareStatement(query);
			rs = statement.executeQuery();
			if (rs != null) {
				ResultSetMetaData rsmd = rs.getMetaData();
				while (rs.next()) {
					row = new HashMap<String, String>();
					int columnCount = rsmd.getColumnCount();
					for (int i = 1; i <= columnCount; i++) {
						String columnName = rsmd.getColumnName(i);
						row.put(columnName.toUpperCase(), rs.getString(columnName));
					}
					dataList.add(row);
				}
			}
		} catch (Exception e) {
			WebServiceLoggerUtil.logError("ChatbotServiceSearch", "executeQuery", e.getLocalizedMessage(),
					new Object[] { query, conn }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
					APIConstant.FAILED, getErrorMessageList(Collections.singletonList(e.getLocalizedMessage())), e);

		}
		return dataList;
	}
	
	protected String executeTransactionQuery(String query, String entityType, String entityReference, String domain,
			String userName, String rolesString, Connection conn) {
		CallableStatement callStmt = null;
		String transactions = null;
		try {
			callStmt = conn.prepareCall(query);
			callStmt.registerOutParameter(1, Types.INTEGER);
			callStmt.setString(2, entityType);
			callStmt.setString(3, entityReference);
			callStmt.setString(4, domain);
			callStmt.setString(5, userName);
			callStmt.registerOutParameter(6, Types.VARCHAR);
			callStmt.registerOutParameter(7, Types.VARCHAR);
			callStmt.setString(8, "N");
			callStmt.setString(9, rolesString);
			callStmt.executeUpdate();
			transactions = callStmt.getString(6);

		} catch (Exception e) {
			WebServiceLoggerUtil.logError("ChatbotServiceSearch", "executeTransactionQuery", e.getLocalizedMessage(),
					new Object[] { query, conn }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
					APIConstant.FAILED, getErrorMessageList(Collections.singletonList(e.getLocalizedMessage())), e);

		}
		return transactions;
	}
	
	
	protected String getMaxEntityReference(String policyNumber, HttpServletRequest request, User user, String entityType) throws NamingException {

		String entityReference = null;
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		user = User.getUser(request);
		String sqlQuery = getQuery(GET_MAX_ENTITY_REFERENCE);
		try {
			conn = ConnectionPool.getConnection(user);
			stmt = conn.prepareStatement(sqlQuery);
			stmt.setString(1, entityType);
			stmt.setString(2, policyNumber);
			rs = stmt.executeQuery();
			while (rs.next()) {
				entityReference = rs.getString("ENTITY_REFERENCE");
			}
		} catch (SQLException e) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, BookOverrideEntity.class.getName(),
					new Exception().getStackTrace()[0].toString(), ServletConfigUtil.COMPONENT_FRAMEWORK,
					new Object[] { "taskName =" + "Booking" }, "Error in getStageDesc", e, LogMinderDOMUtil.VALUE_MIC);
			e.printStackTrace();
		} finally {
			try {
				DBUtil.close(null, stmt, conn);
			} catch (SQLException e) {
				WebServiceLoggerUtil.logInfo("ChatbotApiServiceImpl", "getMaxEntityReference",
						e.getLocalizedMessage(), new Object[] { e.getMessage() });
			}
	}
		return entityReference;

	}
	

protected ArrayList<HashMap<String, String>> getEndorsePolicyDetails(String policyNumber, HttpServletRequest request,
			String entityReference, String entityType, Connection conn) {
		ArrayList<HashMap<String, String>> dataList = new ArrayList<HashMap<String, String>>();
		String query = getQuery(GET_ENDORSE_POLICY_DETAILS);
		PreparedStatement statement = null;
		ResultSet rs = null;
		HashMap<String, String> row = null;
		try {
			statement = conn.prepareStatement(query);
			statement.setString(1, entityType);
			statement.setString(2, policyNumber);
			statement.setString(3, entityType);
			statement.setString(4, policyNumber);
			rs = statement.executeQuery();
			if (rs != null) {
				ResultSetMetaData rsmd = rs.getMetaData();
				while (rs.next()) {
					row = new HashMap<String, String>();
					int columnCount = rsmd.getColumnCount();
					for (int i = 1; i <= columnCount; i++) {
						String columnName = rsmd.getColumnName(i);
						row.put(columnName.toUpperCase(), rs.getString(columnName));
					}
					dataList.add(row);
				}
			}
		} catch (Exception e) {
			WebServiceLoggerUtil.logError("ChatbotServiceSearch", "getEndorsePolicyDetails", e.getLocalizedMessage(),
					new Object[] { query, conn }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
					APIConstant.FAILED, getErrorMessageList(Collections.singletonList(e.getLocalizedMessage())), e);
		}
		return dataList;
	}

protected ArrayList<HashMap<String, String>> getRenewPolicyDetails(String policyNumber, HttpServletRequest request,
		String entityReference, String entityType, Connection conn) {
	ArrayList<HashMap<String, String>> dataList = new ArrayList<HashMap<String, String>>();
	String query = getQuery(GET_RENEW_POLICY_DETAILS);
	PreparedStatement statement = null;
	ResultSet rs = null;
	HashMap<String, String> row = null;
	try {
		statement = conn.prepareStatement(query);
		statement.setString(1, entityType);
		statement.setString(2, policyNumber);
		statement.setString(3, entityType);
		statement.setString(4, policyNumber);
		rs = statement.executeQuery();
		if (rs != null) {
			ResultSetMetaData rsmd = rs.getMetaData();
			while (rs.next()) {
				row = new HashMap<String, String>();
				int columnCount = rsmd.getColumnCount();
				for (int i = 1; i <= columnCount; i++) {
					String columnName = rsmd.getColumnName(i);
					row.put(columnName.toUpperCase(), rs.getString(columnName));
				}
				dataList.add(row);
			}
		}
	} catch (Exception e) {
		WebServiceLoggerUtil.logError("ChatbotServiceSearch", "getRenewPolicyDetails", e.getLocalizedMessage(),
				new Object[] { query, conn }, e);
		throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
				APIConstant.FAILED, getErrorMessageList(Collections.singletonList(e.getLocalizedMessage())), e);
	}
	return dataList;
}

	

	protected HashMap<String, String> getEndorseTransactionDetails(String policyNumber, HttpServletRequest request,
			String entityReference, Connection conn) {
		String query = getQuery(GET_ENDORSE_TRANSACTION_DETAILS);
		PreparedStatement statement = null;
		ResultSet rs = null;
		HashMap<String, String> row = new HashMap<String, String>();
		try {
			statement = conn.prepareStatement(query);
			rs = statement.executeQuery();
			if (rs != null) {
				while (rs.next()) {
						row.put( rs.getString(1), rs.getString(2));
				}
			}
		} catch (Exception e) {
			WebServiceLoggerUtil.logError("ChatbotServiceSearch", "getEndorseTransactionDetails", e.getLocalizedMessage(),
					new Object[] { query, conn }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
					APIConstant.FAILED, getErrorMessageList(Collections.singletonList(e.getLocalizedMessage())), e);
		}
		return row;
	}
	
	protected HashMap<String, String> getRenewTransactionDetails(String policyNumber, HttpServletRequest request,
			String entityReference, Connection conn) {
		String query = getQuery(GET_RENEW_TRANSACTION_DETAILS);
		PreparedStatement statement = null;
		ResultSet rs = null;
		HashMap<String, String> row = new HashMap<String, String>();
		try {
			statement = conn.prepareStatement(query);
			rs = statement.executeQuery();
			if (rs != null) {
				while (rs.next()) {
						row.put( rs.getString(1), rs.getString(2));
				}
			}
		} catch (Exception e) {
			WebServiceLoggerUtil.logError("ChatbotServiceSearch", "getRenewTransactionDetails", e.getLocalizedMessage(),
					new Object[] { query, conn }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
					APIConstant.FAILED, getErrorMessageList(Collections.singletonList(e.getLocalizedMessage())), e);
		}
		return row;
	}
	

}
