package com.coverall.mic.rest.policy.api.service.chatbot.model;

import java.util.ArrayList;
import java.util.HashMap;

@SuppressWarnings("serial")
public class NewQuoteProducts {
	
	ArrayList<HashMap> navigations = new ArrayList<HashMap>();
	private String productName;

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}
	
	public ArrayList<HashMap> getNavigations() {
		return navigations;
	}

	public void setNavigations(ArrayList<HashMap> navigations) {
		this.navigations = navigations;
	}
}
