package com.coverall.mic.rest.policy.api.service.chatbot.model;

import java.util.ArrayList;
import java.util.HashMap;

@SuppressWarnings("serial")
public class QuoteAllProductSearch implements java.io.Serializable {

	ArrayList<Object> productList = new ArrayList<Object>();
	
	
	public ArrayList<Object> getProductList() {
		return productList;
	}

	public void setProductList(ArrayList<Object> productList) {
		this.productList = productList;
	}

	
	
}
