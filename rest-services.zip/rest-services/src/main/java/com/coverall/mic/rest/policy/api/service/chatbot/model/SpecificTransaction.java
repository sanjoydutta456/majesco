package com.coverall.mic.rest.policy.api.service.chatbot.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SpecificTransaction {
	String transactionName;
	ArrayList<HashMap> navigations = new ArrayList<HashMap>();
	

	public ArrayList<HashMap> getNavigations() {
		return navigations;
	}

	public void setNavigations(ArrayList<HashMap> navigations) {
		this.navigations = navigations;
	}

	public String getTransactionName() {
		return transactionName;
	}

	public void setTransactionName(String transactionName) {
		this.transactionName = transactionName;
	}
	
}
