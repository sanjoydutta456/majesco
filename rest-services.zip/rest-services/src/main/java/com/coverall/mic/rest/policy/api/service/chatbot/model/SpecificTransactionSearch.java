package com.coverall.mic.rest.policy.api.service.chatbot.model;

import java.util.ArrayList;

public class SpecificTransactionSearch {
	
	ArrayList<Object> specificTransactions;

	public ArrayList<Object> getSpecificTransactions() {
		return specificTransactions;
	}
	
	public void setSpecificTransactions(ArrayList<Object> specificTransactions) {
		this.specificTransactions = specificTransactions;
	}

}
