package com.coverall.mic.rest.policy.api.service.constant;

public interface APIConstant {
	
	public static final String ADMINISTRATOR_ROLE = "administrators";
	public static final String RATING_TASK = "RATING";
	public static final String BILLINFO_TASK = "BILLINFO";
	public static final String COMMISSIONMANAGEMENT_TASK = "COMMISSIONMANAGEMENT";
	public static final String DOCUMENTS_TASK = "DOCUMENTS";
	public static final String BOOKING_TASK = "BOOKING";
	public static final String UNDERWRITINGRULES_TASK = "UNDERWRITINGRULES";
	public static final String FORMSMANAGEMENT_TASK = "FORMSMANAGEMENT";
	public static final String ISSUANCE_TASK = "ISSUANCE";
	public static final String SUBJECTTO_TASK = "SUBJECTTO";
    public static final String TASK_STATUS = "TASK_STATUS";
    public static final String ENTITY_STATUS = "ENTITY_STATUS";
    public static final String CONSOLIDATE_FRM_VW = "CONSOLIDATE_FRM_VW";
    public static final String CONSOLIDATE_FRM_VW_QUERY_ID = "getConsolidateFormView";
    public static final String NON_CONSOLIDATE_FRM_VW_QUERY_ID = "GET_NON_CONSOLIDATE_FRM_VW";
    public static final String QUOTE_REFERENCE = "quoteId";
    public static final String POLICY_REFERENCE = "policyId";
    public static final String OPERATION_ID = "operationId";  
    public static final String FORM_NAME = "formName";
    public static final String FORM_ID = "formId";
    public static final String FORM_DESCRIPTION = "formDescription";
    public static final String FORM_REVISION = "revision";
    public static final String FORM_COVERAGE_PART = "coveragePart";
    public static final String FORM_STATUS = "status";
    public static final String FORM_MODIFIED_REVISION = "modifiedRevision"; 
    public static final String FORM_EDITION_DATE = "editionDate";
    public static final String FORM_IS_VARIABLE_PRESENT = "isVariablePresent";
    public static final String FORM_VARIABLE_NAME = "variableName";
    public static final String FORM_VARIABLE_NAME_DESC = "variableNameDesc";
    public static final String FORM_VARIABLE_ID = "variableId";
    public static final String FORM_DELETE_PERMISSION ="Add Delete Any Form";
    public static final String FORM_PREVIEW_PERMISSION ="Preview Forms";
    public static final String FORM_MODIFY_PERMISSION ="Modify Forms";
    public static final String VIEW_PRODUCER_PERMISSION="View Producers";
    public static final String VIEW_UNDERWRITER_PERMISSION="View Underwriters";
    public static final String MANAGE_UNDERWRITER_PERMISSION="Manage Underwriters";
    public static final String MODIFY_BILLING_EFFECTIVE_DATE_PERMISSION="Modify Billing Effective Date";
    public static final String OVERRIDE_COMMISSION_PERMISSION="Override commision";
    public static final String VIEW_COMMISSION_REPORT_PERMISSION="View Commissions Report";
    public static final String UNDERWRITER_RULESET_PERMISSION="Underwriter Approval";
    public static final String ATTACH_FILE_PERMISSION="Attach File";
    public static final String REMOVE_FILE_PERMISSION="Remove File";
    public static final String CREATE_NOTE_PERMISSION="Create Note";
    public static final String REPLY_TO_NOTE_PERMISSION="Reply To Note";
    public static final String DELETE_NOTE_PERMISSION="Delete Note";
    public static final String IS_POLICY_ENTITY = "isPolicyEntity";
    public static final String ENTITY_QUOTE = "QUOTE";
    public static final String ENTITY_POLICY = "POLICY";
    public static final String IS_WORKFLOW_STAGE_REACHED = "isworkflowstagereached";
    public static final String IS_ENTITY_EXISTS = "ispolicyExists";
    public static final String IS_ENTITY_FORM_EXISTS = "isFormDataExists"; 
    public static final String IS_FORM_VAR_DATA_VALID = "isFormVarDataValid"; 
    public static final String IS_POLICY_BOOKED = "isPolicyBooked";
    public static final String IS_BINDER = "isBinder";

    public static final String FORM_VARIABLE_VALUE = "variableValue";
    public static final String FORM_VARIABLE_OCCURRENCE = "occurrence";
    public static final String IS_VALID_REQUEST = "isValidRequest";
    public static final String RICHTEXT_FORM_VARIABLE_TYPE = "RICHTEXT";


    public static final String FORM_IS_VARIABLE_REQUIRED = "isRequired";
    public static final String PARAM_MFV_ID = "MFV_ID";
    public static final String PARAM_MFV_POLICY_REFERENCE = "MFV_POLICY_REFERENCE";
    public static final String PARAM_MFV_ENTITY_TYPE = "MFV_ENTITY_TYPE";
    public static final String PARAM_MFV_COVERAGE_PART_REFERENCE = "MFV_COVERAGE_PART_REFERENCE";
    public static final String PARAM_MFV_REFERENCE_MODIFIED = "MFV_REFERENCE_MODIFIED";
    public static final String PARAM_MFV_COVERAGE_MODIFIED = "MFV_COVERAGE_MODIFIED";
    public static final String PARAM_MFV_FORM_NUMBER = "MFV_FORM_NUMBER";
    public static final String PARAM_MFV_FORM_OCCURRENCE = "MFV_FORM_OCCURRENCE";
    public static final String PARAM_MFV_OCCURRENCE = "MFV_OCCURRENCE";
    public static final String PARAM_MFV_REVISION_NUMBER = "MFV_REVISION_NUMBER";
    public static final String PARAM_MFV_VAR_NAME = "MFV_VAR_NAME";
    public static final String PARAM_MFV_VAR_DESC = "MFV_VAR_DESC";
    public static final String PARAM_MFV_VAR_TYPE = "MFV_VAR_TYPE";
    public static final String PARAM_MFV_VAR_SIZE = "MFV_VAR_SIZE";
    public static final String PARAM_MFV_VAR_VALUE = "MFV_VAR_VALUE";
    public static final String PARAM_MFV_VAR_DEFAULT_VALUE = "MFV_VAR_DEFAULT_VALUE";
    public static final String PARAM_MFV_REQUIRED = "MFV_REQUIRED";
    public static final String PARAM_MFV_VAR_ORDER = "MFV_VAR_ORDER";
    public static final String PARAM_MFV_VAR_GROUP = "MFV_VAR_GROUP";
    public static final String PARAM_MFV_VAR_GROUP_OCCR = "MFV_VAR_GROUP_OCCR";
    public static final String PARAM_MFV_VAR_ACTION = "MFV_VAR_ACTION";
    public static final String PARAM_MFV_ALLOW_SPACE = "MFV_ALLOW_SPACE";
    public static final String PARAM_MFV_FORM_NAME = "MFV_FORM_NUMBER";
    
    public static final String PARAM_MFV_VAR_TYPE_STRING = "STRING";
    public static final String PARAM_MFV_VAR_TYPE_RICHTEXT = "RICHTEXT";
    public static final String PARAM_MFV_VAR_TYPE_INTEGER = "INTEGER";
    public static final String PARAM_MFV_VAR_TYPE_LARGE_STRING = "LARGE STRING";
    public static final String PARAM_MFV_VAR_TYPE_DATE = "DATE";
    public static final String PARAM_MFV_VAR_TYPE_USD = "USD";
    
    public static final String INVALID_FORM_ID_FORMAT = " is invalid Form Id format. Please provide a valid integer for form Id.";
	

	public static final String POLICY_NOT_EXISTS = " Invalid Policy Reference.";
	public static final String POLICY_NOT_EXISTS_CODE = "404";

	public static final String WORKFLOW_NOT_EXISTS = " Form Workflow Not Exists. Please check the status. ";
	public static final String WORKFLOW_NOT_EXISTS_CODE = "404";

	public static final String FORM_NOT_EXISTS = " No Applicable Forms available for this Policy. ";
	public static final String FORM_NOT_EXISTS_CODE = "404";
	
	public static final String FORM_ID_NOT_EXISTS = " Form Id is not available for ";
	
	public static final String POLICY_BOOKED = "Policy is booked , Invalid Requset.";
	public static final String POLICY_BOOKED_CODE = "404";

	public static final String FORM_VAR_NOT_EXISTS = "Form Variables not Exists, Invalid Request. ";
	public static final String FORM_VAR_NOT_EXISTS_CODE = "404";

	public static final String USER_PERMISSION_NOT_EXISTS = "User Don't have permission to Modify Form & Varaibles.";
	public static final String USER_PERMISSION_NOT_EXISTS_CODE = "400";

	public static final String FORM_VAR_DATA_INVALID = "Invalid Form Variable Data , Request Invalid.";
	public static final String FORM_VAR_DATA_INVALID_CODE = "400";

	public static final String FORM_SECURITY_PERMISSION = " User Don't have permission to modify Forms.";
	public static final String FORM_SECURITY_PERMISSION_CODE = "400";
	public static final String RUNTIME_EXCEPTION = "500";
    public static final String CONVERTED_TO_POLICY = "Converted to Policy";
    
    public static final String FAILED = "FAILED";
    public static final String PARTIALLY_SUCCESSFUL = "PARTIALLY SUCCESSFUL";

	public static final String QUOTE_HAVING_NEW_REVISION = "Quote is either expired or having new Revision , Invalid Request. ";
	public static final String QUOTE_HAVING_NEW_REVISION_CODE = "400";
	
	
	public static final String INVALID_REQUEST_CODE = "400";
	public static final String INVALID_REQUEST = " Invalid Request.Please validate the Request.";
	public static final String ENTITY_NOT_IN_EXISTENCE = "No such transaction in existence.";
	
	//public static final String INVALID_REQUEST_CODE = "406";
	public static final String MANDATORY_VARIABLE_EXISTS_CODE = "200";
	public static final String MANDATORY_VARIABLE_EXISTS = 	"Forms variables updated but other mandatory form variable exists. ";
	
	public static final String SUCCESSFUL_MESSAGE = "Successfully updated the form variables and triggered the next workflow. ";
	
	public static final String MANDATORY_REQUEST_PARAM_SEARCH_VALUE = "search text value cannot be empty or null.";
	public static final String MANDATORY_REQUEST_PARAM_SEARCH_TYPE = "search type cannot be empty or null.";
	public static final String MANDATORY_REQUEST_PARAM_SEARCH_LENGTH = "Search text value should be greater than or equal to 3 characters.";
	public static final String MANDATORY_REQUEST_PARAM_MAX_SEARCH_LENGTH = "Search text value should not be greater than 250 characters.";
	public static final int    MANDATORY_REQUEST_ALLOWED_SEARCH_LENGTH = 3;
	public static final int    MANDATORY_REQUEST_ALLOWED_MAX_SEARCH_LENGTH = 250;
	public static final String MANDATORY_REQUEST_ALLOWED_SEARCH_TYPE = "allowed search types are startswith and contains only.";
	public static final String REQUEST_PARAM_SEARCH_TYPE_VALUE = "Please provide correct search type.";
	public static final String MANDATORY_REQUEST_PARAM_SEARCH_ENTITY = "Search Entity ID cannot be empty or null.";
	public static final String MANDATORY_REQUEST_PARAM_INDEX_VALUE = "Search Index value can not be negative or zero.";
	public static final String MANDATORY_REQUEST_PARAM_MAX_INDEX_VALUE = "Search Index value can not have more than 5 characters.";
	public static final String MANDATORY_REQUEST_PARAM_INVALID_INDEX_VALUE = "Search Index value can not have special characters or alphanumeric characters.";
	public static final String INVALID_REQUEST_PARAM = " Invalid Search Request. Please validate the Search Request.";
	public static String INVALID_REQUEST_PARAM_INDEX_CHARACTERS= "[0-9]+";
	
	public static final String CUSTOMER_NOT_EXISTS = " Record not found.";
	public static final String CUSTOMER_DELETE = " Customer delete transaction not allowed.";
	public static final String INSURED_NOT_EXISTS = " Record not found.";
	public static final String INSURED_DELETE = " Insured delete transaction not allowed.";
	public static final String NOTES_NOT_EXIST = " notes not available for: ";
	
	public static final String MANDATORY_CUSTOMER_ID = "Customer Id cannot be empty or null.";
	public static final String MANDATORY_EVENT_CODE = "Event Code cannot be empty or null.";
	public static final String MANDATORY_EVENT_FROM_DATE = "Event From Date cannot be empty or null.";
	public static final String MANDATORY_EVENT_TO_DATE = "Event To Date cannot be empty or null.";

	public static final String TRANSACTION_NOT_AVAILABLE = " Exception occurred while checking available transactions for : ";
	public static final String EXCEPTION_IN_QUERY_EXECUTION = " Exception occurred while getting Entity Reference for : ";
	public static final String EXCEPTION_IN_CUSTOMER_URL_API = " Exception occurred while getting URL for : ";
	
	public static final String DLS_EXPRESSION_STRING_QUOTE_POLICY="${var:user('DLSFILTER', ' AND ', '{operator=OPERATOR,state=STATE,underwriter=UNDERWRITER_CODE, producer=AGENT_CODE,insured=INSURED_NAME, policyref=ENTITY_REFERENCE,company=COMPANY_CODE,branch=PRODUCT_CODE,subproducer=SUB_AGENT_ID,programcode=PROGRAM_CODE}')}";
	public static final String DLS_EXPRESSION_STRING_UNDERWRITER="${var:user('DLSFILTER', ' AND ', '{underwriter=UNDERWRITER_CODE}')}";
	public static final String DLS_EXPRESSION_STRING_PRODUCER="${var:user('DLSFILTER', ' AND ', '{producer=AGENT_CODE}')}";
	
	public static final String UNDERWRITER_NOT_FOUND = "Underwriter not found";
	
	public static final String FOLDER_TAB_FILES = "Files";
	public static final String FOLDER_TAB_PAY_PLAN = "Payment Plan";
	public static final String FOLDER_TAB_COMMISSION = "Commissions";
	public static final String FOLDER_TAB_UW_RULES = "UW Rules";
	public static final String FOLDER_TAB_FORMS = "Forms";
	public static final String FOLDER_TAB_DOCUMENTS = "Documents";
	public static final String FOLDER_TAB_QUOTE_DOCUMENTS = "Quote Documents";
	
	public static final String REGEX_EMAIL_CHECK="^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$";
	
	public static final String VERSION_REQUEST_ATTRIBUTE="versionRequestAttribute";
	
	public static final String FILES_SECURITY_CHECK_GLOBAL_OPTION="FILES_SECURITY_CHECK";
	
	public static final String NOTES_SECURITY_CHECK_GLOBAL_OPTION="NOTES_SECURITY_CHECK";
	
	public static final String EXPORT_UNDERWRITER_FILENAME="Underwriter.csv";
	
	public static final String IMPORT_UNDERWRITER_FILENAME="ImportUnderwriter.csv";
	
	//POLT-16056, POLT-16060
	public static final String FORM_IS_MULTI_ATTACH = "isMultiAttach";
	public static final String PARAMETER_FORM_INCLUSION = "formInculsion";
	public static final String PARAMETER_SUB_ACTION = "subAction";
	public static final String PARAMETER_IS_MANUSCRIPT = "isManuscript";
	public static final String PARAMETER_IS_COPY_FORM = "isCopyForm";
	public static final String PARAMETER_ID_LIST = "idList";
	public static final String PARAMETER_COPY_COUNT = "noOfCopies";
	public static final String PARAMETER_APPLICABLE_LOB_LISTS = "applicableLobList";
	public static final String PARAMETER_IS_FORM_INTERLINE = "IS_FORM_INTERLINE";
	public static final String PARAMETER_MFO_POLICY_REFERENCE = "MFO_POLICY_REFERENCE";
	public static final String PARAMETER_MFO_COVERAGE_PART_REFERENCE = "MFO_COVERAGE_PART_REFERENCE";
	public static final String PARAMETER_MFO_FORM_NUMBER = "MFO_FORM_NUMBER";
	public static final String PARAMETER_MFO_ENTITY_TYPE = "MFO_ENTITY_TYPE";
	public static final String PARAMETER_MFV_OCCR = "MFV_OCCR";
	public static final String PARAMETER_MFO_INCLUDE = "MFO_INCLUDE";
	public static final String PARAMETER_MFO_OCCURRENCE = "MFO_OCCURRENCE";
	public static final String PARAMETER_MFO_REVISION_NUMBER = "MFO_REVISION_NUMBER";
	public static final String PARAMETER_MFO_FORM_EDITION_DATE = "MFO_FORM_EDITION_DATE";
	public static final String PARAMETER_MFO_USER_DELETE_OVERRIDE = "MFO_USER_DELETE_OVERRIDE";
	public static final String PARAMETER_MFO_RANK = "MFO_RANK";
	public static final String PARAMETER_MFO_QUALIFYING_LOBS = "MFO_QUALIFYING_LOBS";
	
	public static final String HTTP_CODE_SUCCESS = "200";
	public static final String API_OPERATION_SERVICE_CATEGORY="apioperations";
	public static final String API_PROCESSOR_ALL_REQUEST_TYPE="ALL";
	
	public static final String QUOTE_POLICY_SERVICE_IDENTIFIER="QUOTE_POLICY_SERVICE";
	public static final String JSON_PATH="JSON_PATH";
	public static final String MESSAGE="MESSAGE";
	public static final String MESSAGE_TYPE="MESSAGE_TYPE";
	
	public static enum SYSTEM_RESPONSE_CODE {
		ALERT,STOP,UNDERWRITING,BLOCKER,ERROR,SUCCESSFULL
 }
}	
