package com.coverall.mic.rest.policy.api.service.forms.dao;

public class FormVariableVo {
	
	protected int formVarID ; 
	protected String  formVarName;
	protected String formVarDesc;
	protected String formVarType;
	protected String formVarSize; 
	protected String formVarValue;
	protected String formVarModifiedValue;
	protected String formVarOccurrence;
	protected String formVarExpression;
	protected String formVarOrder;
	protected String formVarDefaultValue;
	protected String formValidationCriteria;
	protected String formAllowSpace;
	protected String formVarGroup;
	protected String formVarGroupOccurrence;
	protected String formVarUserCreated;
	protected String formVarUserModified;
	protected String formVarDateCreated;
	protected String formVarDateModified;
	protected String formCoveragePartReference;
	protected String formName;
	public String getFormName() {
		return formName;
	}
	public void setFormName(String formName) {
		this.formName = formName;
	}
	public String getFormCoveragePartReference() {
		return formCoveragePartReference;
	}
	public void setFormCoveragePartReference(String formCoveragePartReference) {
		this.formCoveragePartReference = formCoveragePartReference;
	}
	public int getFormVarID() {
		return formVarID;
	}
	public void setFormVarID(int formVarID) {
		this.formVarID = formVarID;
	}
	public String getFormVarName() {
		return formVarName;
	}
	public void setFormVarName(String formVarName) {
		this.formVarName = formVarName;
	}
	public String getFormVarDesc() {
		return formVarDesc;
	}
	public void setFormVarDesc(String formVarDesc) {
		this.formVarDesc = formVarDesc;
	}
	public String getFormVarType() {
		return formVarType;
	}
	public void setFormVarType(String formVarType) {
		this.formVarType = formVarType;
	}
	public String getFormVarSize() {
		return formVarSize;
	}
	public void setFormVarSize(String formVarSize) {
		this.formVarSize = formVarSize;
	}
	public String getFormVarValue() {
		return formVarValue;
	}
	public void setFormVarValue(String formVarValue) {
		this.formVarValue = formVarValue;
	}
	public String getFormVarOccurrence() {
		return formVarOccurrence;
	}
	public void setFormVarOccurrence(String formVarOccurrence) {
		this.formVarOccurrence = formVarOccurrence;
	}
	public String getFormVarExpression() {
		return formVarExpression;
	}
	public void setFormVarExpression(String formVarExpression) {
		this.formVarExpression = formVarExpression;
	}
	public String getFormVarOrder() {
		return formVarOrder;
	}
	public void setFormVarOrder(String formVarOrder) {
		this.formVarOrder = formVarOrder;
	}
	public String getFormVarDefaultValue() {
		return formVarDefaultValue;
	}
	public void setFormVarDefaultValue(String formVarDefaultValue) {
		this.formVarDefaultValue = formVarDefaultValue;
	}
	public String getFormValidationCriteria() {
		return formValidationCriteria;
	}
	public void setFormValidationCriteria(String formValidationCriteria) {
		this.formValidationCriteria = formValidationCriteria;
	}
	public String getFormAllowSpace() {
		return formAllowSpace;
	}
	public void setFormAllowSpace(String formAllowSpace) {
		this.formAllowSpace = formAllowSpace;
	}
	public String getFormVarGroup() {
		return formVarGroup;
	}
	public void setFormVarGroup(String formVarGroup) {
		this.formVarGroup = formVarGroup;
	}
	public String getFormVarGroupOccurrence() {
		return formVarGroupOccurrence;
	}
	public void setFormVarGroupOccurrence(String formVarGroupOccurrence) {
		this.formVarGroupOccurrence = formVarGroupOccurrence;
	}
	public String getFormVarUserCreated() {
		return formVarUserCreated;
	}
	public void setFormVarUserCreated(String formVarUserCreated) {
		this.formVarUserCreated = formVarUserCreated;
	}
	public String getFormVarUserModified() {
		return formVarUserModified;
	}
	public void setFormVarUserModified(String formVarUserModified) {
		this.formVarUserModified = formVarUserModified;
	}
	public String getFormVarDateCreated() {
		return formVarDateCreated;
	}
	public void setFormVarDateCreated(String formVarDateCreated) {
		this.formVarDateCreated = formVarDateCreated;
	}
	public String getFormVarDateModified() {
		return formVarDateModified;
	}
	public void setFormVarDateModified(String formVarDateModified) {
		this.formVarDateModified = formVarDateModified;
	}
	public String getFormVarModifiedValue() {
		return formVarModifiedValue;
	}
	public void setFormVarModifiedValue(String formVarModifiedValue) {
		this.formVarModifiedValue = formVarModifiedValue;
	}
	@Override
	public String toString() {
		return "FormVariableVo [formVarID=" + formVarID + ", formVarName=" + formVarName + ", formVarDesc="
				+ formVarDesc + ", formVarType=" + formVarType + ", formVarSize=" + formVarSize + ", formVarValue="
				+ formVarValue + ", formVarOccurrence=" + formVarOccurrence + ", formVarExpression=" + formVarExpression
				+ ", formVarOrder=" + formVarOrder + ", formVarDefaultValue=" + formVarDefaultValue
				+ ", formValidationCriteria=" + formValidationCriteria + ", formAllowSpace=" + formAllowSpace
				+ ", formVarGroup=" + formVarGroup + ", formVarGroupOccurrence=" + formVarGroupOccurrence
				+ ", formVarUserCreated=" + formVarUserCreated + ", formVarUserModified=" + formVarUserModified
				+ ", formVarDateCreated=" + formVarDateCreated + ", formVarDateModified=" + formVarDateModified
				+ ", formCoveragePartReference=" + formCoveragePartReference + ", formName=" + formName + "]";
	}

	
	

}
