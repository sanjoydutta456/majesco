package com.coverall.mic.rest.policy.api.service.forms.util;

import java.io.StringReader;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

import javax.ws.rs.core.Response;

import oracle.jdbc.OracleTypes;

import com.coverall.exceptions.JDBCException;
import com.coverall.exceptions.ServiceException;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.forms.model.Form;
import com.coverall.mic.rest.policy.api.forms.model.FormVariable;
import com.coverall.mic.rest.policy.api.forms.model.Forms;
import com.coverall.mic.rest.policy.api.forms.model.Form.formVariableIsPresent;
import com.coverall.mic.rest.policy.api.forms.model.FormVariable.requiredValues;
import com.coverall.mic.rest.policy.api.forms.model.FormVariables;
import com.coverall.mic.rest.policy.api.forms.service.FormsService;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.forms.dao.FormVariableVo;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mic.rest.policy.api.service.util.WorkflowUtil;
import com.coverall.security.authentication.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.DOMUtil;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.pctv2.server.util.BookOverrideEntity;
import com.coverall.portal.services.FormsWorkFlowService;
import com.coverall.util.Base64;
import com.coverall.util.DBUtil;
import com.coverall.util.StringUtil;

public class FormUtil extends Form {
	
	//Get List Of Form & Variables
	//Update Form Variable
	
	
	public static String getConsolidateFormView =  " select\r\n" + 
			"                    pdt_id||lpad(NVL(MIS_FORMS.MFO_OCCURRENCE,0),3,0) uniqueFormId,\r\n"+
			"                    PDT_ID formId ,\r\n" + 
			"                    MFO_FORM_NUMBER  formName, \r\n" + 
			"                    pdt_edition_date editionDate, \r\n  " +
			"					NVL(MFO_CUSTOM_FORM_NUMBER, MFO_FORM_NUMBER) CUSTOM_FORM_NUMBER,\r\n" + 
			"                    MFO_INCLUDE,\r\n" + 
			"                    MFO_ENTITY_TYPE,\r\n" + 
			"                    MFO_REVISION_NUMBER revision,\r\n" + 
			"                    NVL(MFO_OCCURRENCE,0) occurance,\r\n" + 
			"                    MFO_TITLE,\r\n" + 
			"                    (MFO_FORM_NUMBER || DECODE(MFO_TITLE,'','',' - ') || MFO_TITLE)MFO_FORM_NUMBER_TITLE_COMBINED,\r\n" + 
			"                    DECODE(MFO_POLICY_REFERENCE,NULL,'',NVL(MFO_POLICY_REFERENCE,'NULL') || '@' || NVL(MFO_COVERAGE_PART_REFERENCE,'NULL') || '@' || NVL(MFO_ENTITY_TYPE,'NULL') || '@' || NVL(MFO_FORM_NUMBER,'NULL') || '@' || TO_CHAR(NVL(MFO_OCCURRENCE,0))) MFO_UNIQUE_VALUE,\r\n" + 
			"                    DECODE(MFO_MANUAL_ATTACH, 'Y', 'Yes', 'No') MANUAL_ATTACH,\r\n" + 
			"                    DECODE(MFO_MANUAL_ATTACH, 'Y', 'No', 'Yes') AUTO_ATTACH,\r\n" +
			"					 DECODE(MFO_MANUAL_ATTACH, 'N', 'Y', 'N') isAutoAttach,\r\n"+					
			"                    NVL(TO_CHAR(MFO_DATE_MODIFIED, 'MM/DD/YYYY'), TO_CHAR(MFO_DATE_CREATED, 'MM/DD/YYYY')) modifiedRevision ,\r\n" + 
			"                    DECODE(MFO_COVERAGE_PART_REFERENCE,'99999999999999999','Package',\r\n" + 
			"                        (select PLB_DESCRIPTION from PS_LINES_OF_BUSINESS, DS_RESOURCE where DSR_GID = PLB_ID AND DSR_DATE_DELETED IS NULL AND DSR_LOB_CODE = substr(MFO_COVERAGE_PART_REFERENCE,3,2))) coveragePart ,\r\n" + 
			"                        MFO_COVERAGE_PART_REFERENCE,\r\n" + 
			"                    PDT_DESCRIPTION DOCUMENT_DESCRIPTION,\r\n" + 
			"                    NVL(MFO_TITLE, PDT_DESCRIPTION) formDescription,\r\n" + 
			"                    MFO_RANK FORM_RANK,\r\n" + 
			"                    (\r\n" + 
			"                      SELECT NVL(IPI_FEATURE_SELECTED, IPI_FEATURE_DEFAULT)\r\n" + 
			"                      FROM MIS_PRODUCT_OPTIONS_ASSN,MIS_POLICIES\r\n" + 
			"                      WHERE IPI_PRODUCT_CODE = MPO_POLICY_SYMBOL\r\n" + 
			"                        AND MPO_POLICY_REFERENCE = MFO_POLICY_REFERENCE\r\n" + 
			"                        AND IPI_FEATURE_CODE = 'FORM_DELETE_OVERRIDE'\r\n" + 
			"                        AND ROWNUM < 2\r\n" + 
			"                    ) PRODUCT_USER_DELETE_OVERRIDE,                    \r\n" + 
			"                    MFO_USER_DELETE_OVERRIDE USER_DELETE_OVERRIDE,\r\n" + 
			"                    (SELECT DECODE(COUNT(*), 0, 'false','true')\r\n" + 
			"                        FROM MIS_FORM_VARS \r\n" + 
			"                        WHERE MFV_POLICY_REFERENCE = ? AND MFV_COVERAGE_PART_REFERENCE  = MFO_COVERAGE_PART_REFERENCE\r\n" + 
			"                            AND MFV_FORM_NUMBER = MFO_FORM_NUMBER\r\n" + 
			"                            AND NVL(MFV_OCCURRENCE, 1) = NVL(MFO_OCCURRENCE, 1)) isVariablePresent, \r\n" + 
			"                    DECODE((SELECT COUNT(*) COUNT_FRM_VARS\r\n" + 
			"                        FROM MIS_FORM_VARS \r\n" + 
			"                        WHERE MFV_POLICY_REFERENCE = ? AND MFV_COVERAGE_PART_REFERENCE  = MFO_COVERAGE_PART_REFERENCE\r\n" + 
			"                            AND MFV_FORM_NUMBER = MFO_FORM_NUMBER\r\n" + 
			"                            AND NVL(MFV_OCCURRENCE, 1) = NVL(MFO_OCCURRENCE, 1)) , 0, 'N/A', \r\n" + 
			"              (CASE WHEN (PDT_IS_MANUSCRIPT = 'Y' AND MFO_MANUAL_ATTACH = 'Y') THEN 'Manuscript' ELSE  'Variable' END)) ENDORSMENT_TYPE,                              \r\n" + 
			"                    DECODE((SELECT COUNT(*) COUNT_MIS_FRM_VARS\r\n" + 
			"                         FROM MIS_FORM_VARS, MIS_FORM_RICHTEXT_VARS\r\n" + 
			"                         WHERE MFV_ID = MRV_FORM_VAR_ID (+)\r\n" + 
			"                             AND MFV_POLICY_REFERENCE = ? AND MFV_COVERAGE_PART_REFERENCE  = MFO_COVERAGE_PART_REFERENCE\r\n" + 
			"                             AND MFV_FORM_NUMBER = MFO_FORM_NUMBER\r\n" + 
			"                             AND NVL(MFV_OCCURRENCE, 1) = NVL(MFO_OCCURRENCE, 1)\r\n" + 
			"                             AND MFV_REQUIRED = 'Y'\r\n" + 
			"                             AND ((MFV_VAR_TYPE = 'RICHTEXT' AND MRV_FORM_VAR_VALUE IS NULL) \r\n" + 
			"                                  OR (MFV_VAR_TYPE != 'RICHTEXT' AND MFV_VAR_VALUE IS NULL))), 0, \r\n" + 
			"                             ( DECODE( (SELECT k_forms_management.f_get_form_status(\r\n" + 
			"                                        MFO_POLICY_REFERENCE,\r\n" + 
			"                                        MFO_COVERAGE_PART_REFERENCE,\r\n" + 
			"                                        MFO_FORM_NUMBER,\r\n" + 
			"                                        MFO_REVISION_NUMBER,\r\n" + 
			"                                        MFO_OCCURRENCE,\r\n" + 
			"                                        MFO_USER_CREATED) FROM DUAL), \r\n" + 
			"                               0, 'Complete','Incomplete') \r\n" + 
			"                             ),\r\n" + 
			"                             'Incomplete') status,  MFO_RANK SORT_ID,\r\n" + 
			"                              (SELECT '' from dual) VAR_DEFAULT_COUNT , \r\n" + 
			"                              (SELECT '' from dual) VAR_ID , \r\n" + 
			"                              (SELECT '' from dual) VAR_NAME , \r\n" + 
			"                              (SELECT '' from dual) VAR_DESC ,\r\n" + 
			"                              (SELECT '' from dual) VAR_TYPE ,\r\n" + 
			"                              (SELECT '' from dual) VAR_ALLOW_SPACE ,\r\n" + 
			"                              (SELECT '' from dual) VAR_SIZE ,\r\n" + 
			"                              (SELECT '' from dual) VAR_VALUE ,                                \r\n" + 
			"                              (SELECT '' from dual) VAR_ORDER ,\r\n" + 
			"                              (SELECT '' from dual) VAR_REQUIRED, \r\n" + 
			"                              (SELECT '' from dual) VAR_GROUP, \r\n" + 
			
			//POLT-16056, POLT-16060
			//"                              (SELECT '' from dual) VAR_GROUP_OCCR  FROM  \r\n" +
			"                              (SELECT '' from dual) VAR_GROUP_OCCR, \r\n" +
			"								PDT_IS_MULTI_ATTACH isMultiAttach \r\n" +
			"								FROM  \r\n" +
			
			"                    MIS_FORMS, \r\n" + 
			"                    VW_PS_DOCUMENT_TEMPLATE, DS_RESOURCE  WHERE \r\n" + 
			"                    PDT_NAME = MFO_FORM_NUMBER AND DSR_GID = PDT_ID AND DSR_DATE_DELETED IS NULL \r\n" + 
			"                AND MFO_POLICY_REFERENCE=?\r\n" + 
			"                AND ((MFO_ENTITY_TYPE IN \r\n" + 
			"                                DECODE((SELECT K_POLICY_MISC.f_get_polref_type (MFO_POLICY_REFERENCE) VAR_POLICY_REF FROM DUAL),\r\n" + 
			"                                    'B', 'BINDER', \r\n" + 
			"                    'P', 'POLICY', \r\n" + 
			"                                    'Q', 'QUOTE')) OR K_Transaction_Management.f_is_qfe(?,?) = 0)\r\n"+
		    "                       order by MFO_RANK asc " ;
		
	
/* Changes not done for same name document as query is based on PDT_ID */	
	      public static String formVariableData_ = " SELECT MFV_ID , \r\n " + 
	      		"	      		  MFV_POLICY_REFERENCE , \r\n " + 
	      		"	      		  MFV_COVERAGE_PART_REFERENCE , \r\n " + 
	      		"	      		  MFV_FORM_NUMBER , \r\n " + 
	      		"	      		  MFV_ENTITY_TYPE , \r\n " + 
	      		"	      		  MFV_REVISION_NUMBER , \r\n " + 
	      		"	      		  MFV_VAR_NAME , \r\n " + 
	      		"	      		  MFV_VAR_DESC , \r\n " + 
	      		"	      		  MFV_VAR_TYPE , \r\n " + 
	      		"	      		  MFV_VAR_SIZE , \r\n " + 
	      		"	      		  MFV_VAR_VALUE , \r\n " + 
	      		"	      		  MFV_REQUIRED , \r\n " + 
	      		"	      		  MFV_OCCURRENCE , \r\n " + 
	      		"	      		  MFV_VAR_EXPRESSION , \r\n " + 
	      		"	      		  MFV_VAR_ORDER , \r\n " + 
	      		"	      		  MFV_VAR_DEFAULT_VALUE , \r\n " + 
	      		"	      		  MFV_VALIDATION_CRITERIA , \r\n " + 
	      		"	      		  MFV_ALLOW_SPACE , \r\n " + 
	      		"	      		  MFV_VAR_GROUP , \r\n " + 
	      		"	      		  MFV_VAR_GROUP_OCCR , \r\n " + 
	      		"	      		  MFV_USER_CREATED , \r\n " + 
	      		"	      		  MFV_DATE_CREATED , \r\n " + 
	      		"	      		  MFV_USER_MODIFIED , \r\n " + 
	      		"	      		  MFV_DATE_MODIFIED \r\n " + 
	      		"	      		 FROM MIS_FORM_VARS \r\n " + 
	      		"	      		 WHERE mfv_policy_reference = ?   \r\n " + 
	      		"	      		 AND MFV_FORM_NUMBER        =   \r\n " + 
	      		"	      	      ( SELECT pdt_name  \r\n " + 
	      		"	      	        FROM ps_document_template \r\n " + 
	      		"	      	        WHERE pdt_id = ?     \r\n " + 
	      		"	      	        AND NVL(pdt_date_deleted,TO_DATE(' 1000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) = TO_DATE(' 1000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss') \r\n" + 
	      		"	      	     ) " ;
	
	      
	      
/* Changes not done for same name document as query is based on PDT_ID */	      
	      public static String formVariableData = " SELECT MFV_ID , \r\n " + 
		      		"	      		  MFV_POLICY_REFERENCE , \r\n " + 
		      		"	      		  MFV_COVERAGE_PART_REFERENCE , \r\n " + 
		      		"	      		  MFV_FORM_NUMBER , \r\n " + 
		      		"	      		  MFV_ENTITY_TYPE , \r\n " + 
		      		"	      		  MFV_REVISION_NUMBER , \r\n " + 
		      		"	      		  MFV_VAR_NAME , \r\n " + 
		      		"	      		  MFV_VAR_DESC , \r\n " + 
		      		"	      		  MFV_VAR_TYPE , \r\n " + 
		      		"	      		  MFV_VAR_SIZE , \r\n " + 
		      		"	      		  MFV_VAR_VALUE , \r\n " + 
		      		"	      		  MFV_REQUIRED , \r\n " + 
		      		"	      		  MFV_OCCURRENCE , \r\n " + 
		      		"	      		  MFV_VAR_EXPRESSION , \r\n " + 
		      		"	      		  MFV_VAR_ORDER , \r\n " + 
		      		"	      		  MFV_VAR_DEFAULT_VALUE , \r\n " + 
		      		"	      		  MFV_VALIDATION_CRITERIA , \r\n " + 
		      		"	      		  MFV_ALLOW_SPACE , \r\n " + 
		      		"	      		  MFV_VAR_GROUP , \r\n " + 
		      		"	      		  MFV_VAR_GROUP_OCCR , \r\n " + 
		      		"	      		  MFV_USER_CREATED , \r\n " + 
		      		"	      		  MFV_DATE_CREATED , \r\n " + 
		      		"	      		  MFV_USER_MODIFIED , \r\n " + 
		      		"	      		  MFV_DATE_MODIFIED \r\n " + 
		      		"	      		 FROM MIS_FORM_VARS \r\n " + 
		      		"	      		 WHERE mfv_policy_reference = ?   \r\n " + 
		      		"	      		 AND MFV_FORM_NUMBER        =   \r\n " + 
		      		"	      	      ( SELECT pdt_name  \r\n " + 
		      		"	      	        FROM ps_document_template \r\n " + 
		      		"	      	        WHERE pdt_id = ?     \r\n " + 
		      		"	      	        AND NVL(pdt_date_deleted,TO_DATE(' 1000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) = TO_DATE(' 1000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss') \r\n" + 
		      		"	      	     ) " +
		      		"                AND mfv_var_desc = ? " +
		      		"              AND mfv_entity_type = ?  "+
		      	    "              and NVL(MFV_OCCURRENCE,0) =  ? ";
	      
	      public static String formVariableDataV3 = " SELECT MFV_ID , \r\n " + 
		      		"	      		  MFV_POLICY_REFERENCE , \r\n " + 
		      		"	      		  MFV_COVERAGE_PART_REFERENCE , \r\n " + 
		      		"	      		  MFV_FORM_NUMBER , \r\n " + 
		      		"	      		  MFV_ENTITY_TYPE , \r\n " + 
		      		"	      		  MFV_REVISION_NUMBER , \r\n " + 
		      		"	      		  MFV_VAR_NAME , \r\n " + 
		      		"	      		  MFV_VAR_DESC , \r\n " + 
		      		"	      		  MFV_VAR_TYPE , \r\n " + 
		      		"	      		  MFV_VAR_SIZE , \r\n " + 
		      		"	      		  MFV_VAR_VALUE , \r\n " + 
		      		"	      		  MFV_REQUIRED , \r\n " + 
		      		"	      		  MFV_OCCURRENCE , \r\n " + 
		      		"	      		  MFV_VAR_EXPRESSION , \r\n " + 
		      		"	      		  MFV_VAR_ORDER , \r\n " + 
		      		"	      		  MFV_VAR_DEFAULT_VALUE , \r\n " + 
		      		"	      		  MFV_VALIDATION_CRITERIA , \r\n " + 
		      		"	      		  MFV_ALLOW_SPACE , \r\n " + 
		      		"	      		  MFV_VAR_GROUP , \r\n " + 
		      		"	      		  MFV_VAR_GROUP_OCCR , \r\n " + 
		      		"	      		  MFV_USER_CREATED , \r\n " + 
		      		"	      		  MFV_DATE_CREATED , \r\n " + 
		      		"	      		  MFV_USER_MODIFIED , \r\n " + 
		      		"	      		  MFV_DATE_MODIFIED \r\n " + 
		      		"	      		 FROM MIS_FORM_VARS \r\n " + 
		      		"	      		 WHERE mfv_policy_reference = ?   \r\n " + 
		      		"	      		 AND MFV_FORM_NUMBER        =   \r\n " + 
		      		"	      	      ( SELECT pdt_name  \r\n " + 
		      		"	      	        FROM ps_document_template \r\n " + 
		      		"	      	        WHERE pdt_id = ?     \r\n " + 
		      		"	      	        AND NVL(pdt_date_deleted,TO_DATE(' 1000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) = TO_DATE(' 1000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss') \r\n" + 
		      		"	      	     ) " +
		      		"                AND mfv_var_name = ? " +
		      		"              AND mfv_entity_type = ?  "+
		      	    "              and NVL(MFV_OCCURRENCE,0) =  ? ";
	      
	private static String queryForFetchingFormVaiablesForForms="SELECT outer.PTV_DOCUMENT_ID document_id,PTV_var_DESC||'@@'||NVL(PTV_required,'N')||'@@'||NVL(ptg_min_occurance,'') as varSpecifics"+
	  			" FROM VW_PS_DOCUMENT_TEMPLATE,PS_DOC_TEMPLATE_VARIABLE outer,PS_DOC_TEMPLATE_VAR_GROUP WHERE PTV_document_id = pdt_id  AND ptv_date_deleted is null AND pdt_date_deleted is null"+
	  			" AND ptg_id(+) = ptv_group_id AND (ptv_expiration_date IS NULL OR ptv_expiration_date > (SELECT CONTROL_DATE FROM ev_mis_quote_policies WHERE entity_reference=?)) AND (ptv_effective_date IS NULL OR ptv_effective_date <= (SELECT CONTROL_DATE FROM ev_mis_quote_policies WHERE entity_reference=?))"+
	  			" AND ( NVL(ptv_customer_code, '@@') = ? OR ( NVL(ptv_customer_code ,'@@')  = '@@' AND NOT EXISTS"+
	  			"(SELECT 1 FROM PS_DOC_TEMPLATE_VARIABLE p WHERE p.ptv_document_id = outer.ptv_document_id AND p.ptv_var_name=outer.ptv_var_name"+
	  			" AND NVL(p.ptv_customer_code, '@@') = ?))) AND pdt_id=?";
		
	
	//POLT-16056, POLT-16060
	public static List  getAttachedForms(Connection conn,  String entityReference , String entityType, boolean isBinder) throws Exception
	{
		return getAttachedForms(conn, entityReference, entityType, isBinder, false);
	}
	
	public static List  getAttachedForms(Connection conn,  String entityReference , String entityType, boolean isBinder, boolean provideCoveragePartReference) throws Exception {
		String stageDesc = null;
		Form getAppForm = null;
		Forms forms = new Forms();
		FormVariable formVariable = new  FormVariable(); 
		FormVariables formVariables ;
		List<Form> getApplicableFormList = new ArrayList<Form>();

		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try {
			stmt = conn.prepareStatement(getConsolidateFormView); 
			stmt.setString(1, entityReference);
			stmt.setString(2, entityReference);
			stmt.setString(3, entityReference);
			stmt.setString(4, entityReference);
			stmt.setString(5, entityType);
			stmt.setString(6, entityReference);

			

			rs = stmt.executeQuery();

			while (rs.next()) {
                   
				getAppForm = new Form();
				getAppForm.setFormId(rs.getInt(APIConstant.FORM_ID));
				getAppForm.setFormName(null != rs.getString(APIConstant.FORM_NAME) ? rs.getString(APIConstant.FORM_NAME) : "");
				getAppForm.setFormDescription(null != rs.getString(APIConstant.FORM_DESCRIPTION) ? rs.getString(APIConstant.FORM_DESCRIPTION) : "");
				getAppForm.setEditionDate(null != rs.getString(APIConstant.FORM_EDITION_DATE) ? rs.getString(APIConstant.FORM_EDITION_DATE) : "");
				getAppForm.setCoveragePart(null != rs.getString(APIConstant.FORM_COVERAGE_PART) ? rs.getString(APIConstant.FORM_COVERAGE_PART) : "");
				getAppForm.setRevision(null != rs.getString(APIConstant.FORM_REVISION) ? rs.getString(APIConstant.FORM_REVISION) : "");
				getAppForm.setOccurrence(rs.getString("occurance"));
				//We need to create a formId as the combination of formId and occurance as same form can be attached multiple times with a transaction
				getAppForm.setFormId(rs.getLong("uniqueFormId"));
				getAppForm.setIsAutoAttach(rs.getString("isAutoAttach"));
				getAppForm.setModifiedRevision(null != rs.getString(APIConstant.FORM_MODIFIED_REVISION) ? rs.getString(APIConstant.FORM_MODIFIED_REVISION) : "");
				getAppForm.setStatus(null != rs.getString(APIConstant.FORM_STATUS) ? rs.getString(APIConstant.FORM_STATUS) : "");
				
				//POLT-16056, POLT-16060
				if("Y".equalsIgnoreCase(rs.getString(APIConstant.FORM_IS_MULTI_ATTACH)))
				{
					getAppForm.setIsMultiAttach(rs.getString(APIConstant.FORM_IS_MULTI_ATTACH));
				}
				
				if(provideCoveragePartReference)
				{
					getAppForm.setCoveragePartReference(rs.getString(APIConstant.PARAMETER_MFO_COVERAGE_PART_REFERENCE));
				}
				
				if (null != rs.getString(APIConstant.FORM_IS_VARIABLE_PRESENT) && Boolean.valueOf((rs.getString(APIConstant.FORM_IS_VARIABLE_PRESENT)) )) {
					formVariables = new FormVariables();

					getAppForm.setFormVariablePresent(formVariableIsPresent.Y);
					formVariables.setFormVariables(FormUtil.getFormVaraibles(conn, entityReference, rs.getString(APIConstant.FORM_ID), isBinder, entityType,rs.getString("occurance")));
					getAppForm.setFormVariables(formVariables);
					
					
					
				} 
				
				getApplicableFormList.add(getAppForm); 
				
				
			}
            

		} catch (SQLException e) {
			 LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                     FormUtil.class.getName(),
                     new Exception().getStackTrace()[0].toString(),
                     ServletConfigUtil.COMPONENT_FRAMEWORK,
                     new Object[] { "entityReference = " + entityReference ,
                  		   "entityType = " + entityType },
                     "Error in getApplicableForms",
                     e,
                     LogMinderDOMUtil.VALUE_MIC);			
			 e.printStackTrace();
		} finally {
			

			try {
                  DBUtil.close(null, stmt, null);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return getApplicableFormList;


	}
	
	
	
	
	
	public static List getFormVaraibles(Connection conn,  String entityReference , String formID , boolean isBinder, String entityType,String occurance) throws Exception {
		FormVariable getAppFormVars = null;
		List<FormVariable> getApplicableFormVarList = new ArrayList<FormVariable>();

		PreparedStatement stmt = null;
		ResultSet rs = null;
		/* Changes not done for same name document as query is based on PDT_ID */
		String sqlQuery = "   SELECT mfv_id variableid , mfv_var_desc variablename , decode(MFV_VAR_TYPE,'RICHTEXT',(SELECT MRV_FORM_VAR_VALUE FROM MIS_FORM_RICHTEXT_VARS WHERE MRV_FORM_VAR_ID=mfv_id),mfv_var_value) variablevalue , mfv_required isrequired , mfv_occurrence occurrence, mfv_var_type varType  FROM mis_form_vars WHERE\r\n" + 
				" mfv_policy_reference =  ?  \r\n" + 
				" AND mfv_entity_type = ?  " +
				"AND mfv_form_number = ( SELECT pdt_name   \r\n" + 
				"	      			      	        FROM vw_ps_document_template  \r\n" + 
				"	      			      	        WHERE pdt_id = ?      \r\n" + 
				"	      			      	        AND nvl(pdt_date_deleted,to_date(' 1000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) = to_date(' 1000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss') \r\n" + 
				"	      			      	     )   "+
				" AND NVL(MFV_OCCURRENCE,0)=?";
		
		try {
			stmt = conn.prepareStatement(sqlQuery);  
			stmt.setString(1, entityReference);
			
			if(isBinder) {
			 stmt.setString(2, "BINDER");
	
			}else {
			 stmt.setString(2, entityType);

			}
			
			stmt.setString(3, formID);
			stmt.setString(4, occurance);

			
			rs = stmt.executeQuery();

			while (rs.next()) {
				
				getAppFormVars = new FormVariable();
				
			//	getAppFormVars.setVariableId( 0 != rs.getInt(APIConstant.FORM_VARIABLE_ID) ? rs.getInt(APIConstant.FORM_VARIABLE_ID) : 0 );
				String variableType=rs.getString("varType");
				String variableValue=null != rs.getString(APIConstant.FORM_VARIABLE_VALUE) ? rs.getString(APIConstant.FORM_VARIABLE_VALUE) : "";
				if(APIConstant.RICHTEXT_FORM_VARIABLE_TYPE.equalsIgnoreCase(variableType)){
					try{
					 variableValue=new String(Base64.base64ToByteArray(variableValue), DOMUtil.UTF_8);
					}catch(Exception exp){
					 variableValue=null;	
					}
				}
				getAppFormVars.setVariableName( null != rs.getString(APIConstant.FORM_VARIABLE_NAME) ? rs.getString(APIConstant.FORM_VARIABLE_NAME) : "" );
				getAppFormVars.setVariableValue(variableValue);
				getAppFormVars.setVariableOccurrence( null != rs.getString(APIConstant.FORM_VARIABLE_OCCURRENCE) ? rs.getString(APIConstant.FORM_VARIABLE_OCCURRENCE) : "" );
				if ( null != rs.getString(APIConstant.FORM_IS_VARIABLE_REQUIRED) && "Y".equalsIgnoreCase(rs.getString(APIConstant.FORM_IS_VARIABLE_REQUIRED)) ) {
					
					getAppFormVars.setRequired(requiredValues.Y); 
				}
				
				getApplicableFormVarList.add(getAppFormVars);
				
			}


		} catch (SQLException e) {
			 LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                     BookOverrideEntity.class.getName(),
                     new Exception().getStackTrace()[0].toString(),
                     ServletConfigUtil.COMPONENT_FRAMEWORK,
                     new Object[] { "formName =" + formID
                  		   , "entityReference =" + entityReference},
                     "Error in getFormVaraibles",
                     e,
                     LogMinderDOMUtil.VALUE_MIC);			
			 e.printStackTrace();
		} finally {
			

			try {
                  DBUtil.close(null, stmt, null);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return getApplicableFormVarList;


	}
	
	public static List getFormVaraiblesV3(Connection conn,  String entityReference , String formID , boolean isBinder, String entityType,String occurance) throws Exception {
		FormVariable getAppFormVars = null;
		List<FormVariable> getApplicableFormVarList = new ArrayList<FormVariable>();

		PreparedStatement stmt = null;
		ResultSet rs = null;
		/* Changes not done for same name document as query is based on PDT_ID */
		String sqlQuery = "   SELECT mfv_id variableid , mfv_var_desc variableNameDesc, mfv_var_name variablename , decode(MFV_VAR_TYPE,'RICHTEXT',(SELECT MRV_FORM_VAR_VALUE FROM MIS_FORM_RICHTEXT_VARS WHERE MRV_FORM_VAR_ID=mfv_id),mfv_var_value) variablevalue , mfv_required isrequired , mfv_occurrence occurrence, mfv_var_type varType  FROM mis_form_vars WHERE\r\n" + 
				" mfv_policy_reference =  ?  \r\n" + 
				" AND mfv_entity_type = ?  " +
				"AND mfv_form_number = ( SELECT pdt_name   \r\n" + 
				"	      			      	        FROM vw_ps_document_template  \r\n" + 
				"	      			      	        WHERE pdt_id = ?      \r\n" + 
				"	      			      	        AND nvl(pdt_date_deleted,to_date(' 1000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) = to_date(' 1000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss') \r\n" + 
				"	      			      	     )   "+
				" AND NVL(MFV_OCCURRENCE,0)=?";
		
		try {
			stmt = conn.prepareStatement(sqlQuery);  
			stmt.setString(1, entityReference);
			
			if(isBinder) {
			 stmt.setString(2, "BINDER");
	
			}else {
			 stmt.setString(2, entityType);

			}
			
			stmt.setString(3, formID);
			stmt.setString(4, occurance);

			
			rs = stmt.executeQuery();

			while (rs.next()) {
				
				getAppFormVars = new FormVariable();
				
			//	getAppFormVars.setVariableId( 0 != rs.getInt(APIConstant.FORM_VARIABLE_ID) ? rs.getInt(APIConstant.FORM_VARIABLE_ID) : 0 );
				String variableType=rs.getString("varType");
				String variableValue=null != rs.getString(APIConstant.FORM_VARIABLE_VALUE) ? rs.getString(APIConstant.FORM_VARIABLE_VALUE) : "";
				if(APIConstant.RICHTEXT_FORM_VARIABLE_TYPE.equalsIgnoreCase(variableType)){
					try{
					 variableValue=new String(Base64.base64ToByteArray(variableValue), DOMUtil.UTF_8);
					}catch(Exception exp){
					 variableValue=null;	
					}
				}
				getAppFormVars.setVariableName( null != rs.getString(APIConstant.FORM_VARIABLE_NAME) ? rs.getString(APIConstant.FORM_VARIABLE_NAME) : "" );
				getAppFormVars.setVariableNameDesc( null != rs.getString(APIConstant.FORM_VARIABLE_NAME_DESC) ? rs.getString(APIConstant.FORM_VARIABLE_NAME_DESC) : "" );
				getAppFormVars.setVariableValue(variableValue);
				getAppFormVars.setVariableOccurrence( null != rs.getString(APIConstant.FORM_VARIABLE_OCCURRENCE) ? rs.getString(APIConstant.FORM_VARIABLE_OCCURRENCE) : "" );
				if ( null != rs.getString(APIConstant.FORM_IS_VARIABLE_REQUIRED) && "Y".equalsIgnoreCase(rs.getString(APIConstant.FORM_IS_VARIABLE_REQUIRED)) ) {
					
					getAppFormVars.setRequired(requiredValues.Y); 
				}
				
				getApplicableFormVarList.add(getAppFormVars);
				
			}


		} catch (SQLException e) {
			 LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                     BookOverrideEntity.class.getName(),
                     new Exception().getStackTrace()[0].toString(),
                     ServletConfigUtil.COMPONENT_FRAMEWORK,
                     new Object[] { "formName =" + formID
                  		   , "entityReference =" + entityReference},
                     "Error in getFormVaraibles",
                     e,
                     LogMinderDOMUtil.VALUE_MIC);			
			 e.printStackTrace();
		} finally {
			

			try {
                  DBUtil.close(null, stmt, null);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return getApplicableFormVarList;


	}

	
	
	public static FormVariableVo getFormVaraibleDetailData(Connection conn,  String entityReference , int formID , FormVariable formVariable , String entityType,boolean isBinder, String occurrence) throws Exception {
		FormVariableVo getAppFormVarsData = null;

		PreparedStatement stmt = null;
		ResultSet rs = null;


		
		try {
			stmt = conn.prepareStatement(formVariableData); 
			stmt.setString(1, entityReference);
			stmt.setInt(2, formID);
			stmt.setString(3, formVariable.getVariableName());
			
			if (isBinder) {
			stmt.setString(4, "BINDER");
	
			}else {
			stmt.setString(4, entityType);

			}

			stmt.setString(5, occurrence);
			rs = stmt.executeQuery();

			while (rs.next()) {
				
				getAppFormVarsData = new FormVariableVo();
				getAppFormVarsData.setFormName( null != rs.getString(APIConstant.PARAM_MFV_FORM_NAME) ? rs.getString(APIConstant.PARAM_MFV_FORM_NAME) : "" );
				getAppFormVarsData.setFormCoveragePartReference( null != rs.getString(APIConstant.PARAM_MFV_COVERAGE_PART_REFERENCE) ? rs.getString(APIConstant.PARAM_MFV_COVERAGE_PART_REFERENCE) : "" );
				getAppFormVarsData.setFormVarOccurrence( null != rs.getString(APIConstant.PARAM_MFV_OCCURRENCE) ? rs.getString(APIConstant.PARAM_MFV_OCCURRENCE) : "" );
				
				getAppFormVarsData.setFormVarName( null != rs.getString(APIConstant.PARAM_MFV_VAR_NAME) ? rs.getString(APIConstant.PARAM_MFV_VAR_NAME) : "" );
				getAppFormVarsData.setFormVarValue( null != rs.getString(APIConstant.PARAM_MFV_VAR_VALUE) ? rs.getString(APIConstant.PARAM_MFV_VAR_VALUE) : "" );
				getAppFormVarsData.setFormVarType( null != rs.getString(APIConstant.PARAM_MFV_VAR_TYPE) ? rs.getString(APIConstant.PARAM_MFV_VAR_TYPE) : "" );
				getAppFormVarsData.setFormVarSize( null != rs.getString(APIConstant.PARAM_MFV_VAR_SIZE) ? rs.getString(APIConstant.PARAM_MFV_VAR_SIZE) : "" );
				getAppFormVarsData.setFormVarOrder( null != rs.getString(APIConstant.PARAM_MFV_VAR_ORDER) ? rs.getString(APIConstant.PARAM_MFV_VAR_ORDER) : "" );
				getAppFormVarsData.setFormVarDesc( null != rs.getString(APIConstant.PARAM_MFV_VAR_DESC) ? rs.getString(APIConstant.PARAM_MFV_VAR_DESC) : "" );
				getAppFormVarsData.setFormAllowSpace( null != rs.getString(APIConstant.PARAM_MFV_ALLOW_SPACE) ? rs.getString(APIConstant.PARAM_MFV_ALLOW_SPACE) : "" );
				getAppFormVarsData.setFormVarDefaultValue( null != rs.getString(APIConstant.PARAM_MFV_VAR_DEFAULT_VALUE) ? rs.getString(APIConstant.PARAM_MFV_VAR_DEFAULT_VALUE) : "" );
				getAppFormVarsData.setFormVarGroup( null != rs.getString(APIConstant.PARAM_MFV_VAR_GROUP) ? rs.getString(APIConstant.PARAM_MFV_VAR_GROUP) : "" );
				getAppFormVarsData.setFormVarGroupOccurrence( null != rs.getString(APIConstant.PARAM_MFV_VAR_GROUP_OCCR) ? rs.getString(APIConstant.PARAM_MFV_VAR_GROUP_OCCR) : "" );
				getAppFormVarsData.setFormVarModifiedValue(formVariable.getVariableValue());

				 
			}


		} catch (SQLException e) {
			 LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                     BookOverrideEntity.class.getName(),
                     new Exception().getStackTrace()[0].toString(),
                     ServletConfigUtil.COMPONENT_FRAMEWORK,
                     new Object[] { "taskName =" +
                  		   "Booking" },
                     "Error in getFormVaraibleDetailData",
                     e,
                     LogMinderDOMUtil.VALUE_MIC);			
			 e.printStackTrace();
		} finally {
			

			try {
                  DBUtil.close(null, stmt, null);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return getAppFormVarsData;


	}
	
	public static FormVariableVo getFormVaraibleDetailDataV3(Connection conn,  String entityReference , int formID , FormVariable formVariable , String entityType,boolean isBinder, String occurrence) throws Exception {
		FormVariableVo getAppFormVarsData = null;

		PreparedStatement stmt = null;
		ResultSet rs = null;


		
		try {
			stmt = conn.prepareStatement(formVariableDataV3); 
			stmt.setString(1, entityReference);
			stmt.setInt(2, formID);
			stmt.setString(3, formVariable.getVariableName());
			
			if (isBinder) {
			stmt.setString(4, "BINDER");
	
			}else {
			stmt.setString(4, entityType);

			}

			stmt.setString(5, occurrence);
			rs = stmt.executeQuery();

			while (rs.next()) {
				
				getAppFormVarsData = new FormVariableVo();
				getAppFormVarsData.setFormName( null != rs.getString(APIConstant.PARAM_MFV_FORM_NAME) ? rs.getString(APIConstant.PARAM_MFV_FORM_NAME) : "" );
				getAppFormVarsData.setFormCoveragePartReference( null != rs.getString(APIConstant.PARAM_MFV_COVERAGE_PART_REFERENCE) ? rs.getString(APIConstant.PARAM_MFV_COVERAGE_PART_REFERENCE) : "" );
				getAppFormVarsData.setFormVarOccurrence( null != rs.getString(APIConstant.PARAM_MFV_OCCURRENCE) ? rs.getString(APIConstant.PARAM_MFV_OCCURRENCE) : "" );
				
				getAppFormVarsData.setFormVarName( null != rs.getString(APIConstant.PARAM_MFV_VAR_NAME) ? rs.getString(APIConstant.PARAM_MFV_VAR_NAME) : "" );
				getAppFormVarsData.setFormVarValue( null != rs.getString(APIConstant.PARAM_MFV_VAR_VALUE) ? rs.getString(APIConstant.PARAM_MFV_VAR_VALUE) : "" );
				getAppFormVarsData.setFormVarType( null != rs.getString(APIConstant.PARAM_MFV_VAR_TYPE) ? rs.getString(APIConstant.PARAM_MFV_VAR_TYPE) : "" );
				getAppFormVarsData.setFormVarSize( null != rs.getString(APIConstant.PARAM_MFV_VAR_SIZE) ? rs.getString(APIConstant.PARAM_MFV_VAR_SIZE) : "" );
				getAppFormVarsData.setFormVarOrder( null != rs.getString(APIConstant.PARAM_MFV_VAR_ORDER) ? rs.getString(APIConstant.PARAM_MFV_VAR_ORDER) : "" );
				getAppFormVarsData.setFormVarDesc( null != rs.getString(APIConstant.PARAM_MFV_VAR_DESC) ? rs.getString(APIConstant.PARAM_MFV_VAR_DESC) : "" );
				getAppFormVarsData.setFormAllowSpace( null != rs.getString(APIConstant.PARAM_MFV_ALLOW_SPACE) ? rs.getString(APIConstant.PARAM_MFV_ALLOW_SPACE) : "" );
				getAppFormVarsData.setFormVarDefaultValue( null != rs.getString(APIConstant.PARAM_MFV_VAR_DEFAULT_VALUE) ? rs.getString(APIConstant.PARAM_MFV_VAR_DEFAULT_VALUE) : "" );
				getAppFormVarsData.setFormVarGroup( null != rs.getString(APIConstant.PARAM_MFV_VAR_GROUP) ? rs.getString(APIConstant.PARAM_MFV_VAR_GROUP) : "" );
				getAppFormVarsData.setFormVarGroupOccurrence( null != rs.getString(APIConstant.PARAM_MFV_VAR_GROUP_OCCR) ? rs.getString(APIConstant.PARAM_MFV_VAR_GROUP_OCCR) : "" );
				getAppFormVarsData.setFormVarModifiedValue(formVariable.getVariableValue());

				 
			}


		} catch (SQLException e) {
			 LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                     BookOverrideEntity.class.getName(),
                     new Exception().getStackTrace()[0].toString(),
                     ServletConfigUtil.COMPONENT_FRAMEWORK,
                     new Object[] { "taskName =" +
                  		   "Booking" },
                     "Error in getFormVaraibleDetailData",
                     e,
                     LogMinderDOMUtil.VALUE_MIC);			
			 e.printStackTrace();
		} finally {
			

			try {
                  DBUtil.close(null, stmt, null);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return getAppFormVarsData;


	}

	

	  public  static void updateFormVariable(Connection conn, String strPolicyReference , FormVariableVo variableVo , long FormId , String varValue ) {
          CallableStatement callStmt = null;

          try {
        	  callStmt = conn.prepareCall("{? = call K_FORMS_MANAGEMENT.f_mod_form_variable(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) }");
              callStmt.registerOutParameter(1, Types.BIGINT);

              callStmt.setString(2, strPolicyReference);
              callStmt.setString(3, variableVo.getFormCoveragePartReference());
              callStmt.setString(4, variableVo.getFormName());
              callStmt.setString(5, variableVo.getFormVarName());
              callStmt.setString(6, varValue);
              callStmt.setNull(7, Types.VARCHAR);

              if (variableVo.getFormVarOrder() == null ||
                  "".equalsIgnoreCase(variableVo.getFormVarOrder())) {
                  callStmt.setNull(8, Types.NUMERIC);
              } else {
                  int varOrder = StringUtil.parseInt(variableVo.getFormVarOrder());
                  callStmt.setInt(8, varOrder);
              }

              callStmt.setString(9, "");
              callStmt.setNull(10, Types.NULL);
              callStmt.setString(11, "Y");

              if (null != variableVo.getFormVarOccurrence() &&  variableVo.getFormVarOccurrence().trim().length() != 0 && Integer.parseInt(variableVo.getFormVarOccurrence()) > 0 ) {
                  callStmt.setInt(12, Integer.parseInt(variableVo.getFormVarOccurrence()) );
              } else {
                  callStmt.setNull(12, Types.NUMERIC);
              }
              callStmt.registerOutParameter(13, Types.VARCHAR);

              callStmt.execute();

              long errorCode = callStmt.getLong(1);
              if (errorCode != 0) { 
                      String errorMessage = callStmt.getString(13);
                  throw new APIException();
              }
          } catch (Throwable error) {
              LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                                           WorkflowUtil.class.getName(),
                                           new Exception().getStackTrace()[0].toString(),
                                           ServletConfigUtil.COMPONENT_FRAMEWORK,
                                           new Object[] { "variableVo =" +
                                        		   variableVo },
                                           "Error marking transaction as blocked",
                                           error,
                                           LogMinderDOMUtil.VALUE_MIC);
          } finally {
              try {
                  DBUtil.close(null, callStmt, null);
              } catch (Throwable error) {
              }
          }
  }
	
	
	  public  static void updateFormRichTextVariable(Connection conn, String strPolicyReference , FormVariableVo variableVo , long FormId ,
			  String varValue) {                    		
		
		// To handle special characters
		// Get bytes from a String using UTF-8 encoding then Base64 encode it 
      CallableStatement callStmt = null;
      String strVarValue; 

	  try {
		strVarValue = Base64.byteArrayToBase64(varValue.getBytes(DOMUtil.UTF_8));	
		callStmt = conn.prepareCall("{? = call K_FORMS_MANAGEMENT.f_mod_form_richtext_variable(?, ?, ?, ?, ?, ?, ?, ?, ?) }");
		varValue = wellFormHTML(varValue);


		callStmt.registerOutParameter(1, Types.BIGINT);
		callStmt.setString(2, strPolicyReference);
		callStmt.setString(3, variableVo.getFormCoveragePartReference());
		callStmt.setString(4, variableVo.getFormName());
		callStmt.setString(5, variableVo.getFormVarName());

		callStmt.setCharacterStream(6, new StringReader(strVarValue));       
		//callStmt.setString(6, varValue);                   

		callStmt.setString(7, APIRequestContext.getApiRequestContext().getUser().getUserId());

		callStmt.setString(8, "Y"); 
		if (null!=variableVo.getFormVarOccurrence() && variableVo.getFormVarOccurrence().trim().length() != 0 && Integer.parseInt(variableVo.getFormVarOccurrence()) > 0) {
			callStmt.setInt(9, Integer.parseInt(variableVo.getFormVarOccurrence()));
		} else {
			callStmt.setNull(9, Types.NUMERIC);
		}
		callStmt.registerOutParameter(10, Types.VARCHAR);

		callStmt.execute();

		long errorCode = callStmt.getLong(1);
		if (errorCode != 0) {
			String errorMessage = callStmt.getString(10);
			throw JDBCException.getExceptionFor(errorCode,
					errorMessage);
		}
	}catch (Exception e) {
		
		throw new APIException();
	}
	  
	  
	  
	  finally {
		try {
			if(conn != null){
      		conn.commit();
      	}
			DBUtil.close(null, callStmt, null);
		} catch (Exception ex) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					"",
					"updateObjectData",
					ServletConfigUtil.COMPONENT_PORTAL,
					new Object[] {  },
					"Error in closing DB connection while updating the rich text form variables." +
							ex.getMessage(), ex,
							LogMinderDOMUtil.VALUE_MIC);
		}
	}	
}

	  
	  
	  public static boolean isAnyVariableIncomplete(String entityReference,
			  String entityType,
			  Connection conn) throws ServiceException {

		  String incompleteVariablesQuery = "";
		  PreparedStatement pstmt = null;
		  ResultSet rs = null;
		  boolean isAnyVariableIncomplete = false;
		  try {
			  incompleteVariablesQuery =
					  " SELECT DECODE(COUNT(*), 0, 'false','true') " +
							  " FROM MIS_FORM_VARS, MIS_FORM_RICHTEXT_VARS " +
							  " WHERE MFV_ID = MRV_FORM_VAR_ID(+)" +
							  " AND MFV_POLICY_REFERENCE = ? " +
							  " AND MFV_REQUIRED = 'Y' " +
							  " AND ((MFV_VAR_TYPE = 'RICHTEXT' AND MRV_FORM_VAR_VALUE IS NULL)" +
							  "   OR (MFV_VAR_TYPE != 'RICHTEXT' AND MFV_VAR_VALUE IS NULL))";
			  pstmt = conn.prepareStatement(incompleteVariablesQuery);
			  pstmt.setString(1, entityReference);
			  rs = pstmt.executeQuery();
			  if (rs.next()) {
				  isAnyVariableIncomplete =
						  rs.getString(1).equals("true") ? true : false;
			  }

			  /* Check if the forms variable validation is to be validated.
If yes then validate the variables and if not validated make
the status of the form to Incomplete*/
			  if(isAnyVariableIncomplete == false){
				  String qryStr = "SELECT DECODE(COUNT(*),0,'false','true') " +
						  "FROM mis_forms " +
						  "WHERE mfo_entity_type = ? " +
						  "AND mfo_policy_reference = ?" +
						  "AND k_forms_management.f_get_form_status( mfo_policy_reference, " +
						  "mfo_coverage_part_reference, " +
						  "mfo_form_number,  " +
						  "mfo_revision_number, " +
						  "mfo_occurrence, " +
						  "mfo_user_created) = 1 ";

				  pstmt = conn.prepareStatement(qryStr);
				  pstmt.setString(1, entityType);
				  pstmt.setString(2, entityReference);
				  rs = pstmt.executeQuery();
				  if (rs.next()) {
					  isAnyVariableIncomplete =
							  rs.getString(1).equals("true") ? true : false;
				  }
			  }
		  } catch (Exception e) {
			  e.printStackTrace();
			  throw new ServiceException(e.getMessage(), e);
		  } finally {
			  try {
				  DBUtil.close(rs, pstmt, null);
			  } catch (Exception e) {
				  //ignore
			  }
		  }

		  return isAnyVariableIncomplete;
	  }

	  
	  
	  
	  public static String wellFormHTML(String varValue) {
	        StringBuffer returnBuffer = new StringBuffer();
	        String startHTML = "<HTML>";
	        String endHTML = "</HTML>";
	        if (varValue.indexOf("<") != -1 && varValue.indexOf(">") != -1) {
	            char startPattern = '=';
	            char endPattern = '>';
	            char middleEndPattern = ' ';
	            boolean processFlag = false;
	            int followCounter = 0;
	            for (int loopCounter = 0; loopCounter < varValue.length();
	                 loopCounter++) {
	                char eachChar = varValue.charAt(loopCounter);
	                returnBuffer.append(eachChar);
	                if (eachChar == startPattern && !processFlag) {
	                    if (varValue.charAt(loopCounter + 1) != '\"') {
	                        returnBuffer.append("\"");
	                        processFlag = true;
	                    }
	                }
	                int increment = (loopCounter + 1) + followCounter;
	                if ((eachChar == endPattern || eachChar == middleEndPattern) &&
	                    processFlag && returnBuffer.charAt(increment - 1) != ':') {
	                    returnBuffer.insert(increment, "\"");
	                    followCounter += 2;
	                    processFlag = false;
	                }
	            }
	        } else {
	            return varValue;
	        }
	        return startHTML + String.valueOf(returnBuffer) + endHTML;
	    }

	  
	  
	  public static void validateFormVariables(FormVariableVo variableVo , String varValue) throws APIException{
		  String errorMessage="";
		  try{
			  if (null != variableVo && varValue.trim().length() > 0) {

				  if (variableVo.getFormVarType().equalsIgnoreCase(APIConstant.PARAM_MFV_VAR_TYPE_INTEGER) || variableVo.getFormVarType().equalsIgnoreCase(APIConstant.PARAM_MFV_VAR_TYPE_USD)) {
					  try{ 
						  Integer.parseInt(varValue);
					  }catch (Exception e) {
						  errorMessage=varValue+" is not a valid integer. Please provide a valid integer value for "+variableVo.getFormVarDesc();
						  throw new APIException(); 
					  }
				  }

				  if (variableVo.getFormVarType().equalsIgnoreCase(APIConstant.PARAM_MFV_VAR_TYPE_DATE)){
					  try {
						  Calendar cal = Calendar.getInstance();
						  cal.setLenient(false);
						  cal.setTime(new SimpleDateFormat("MM/DD/yyyy").parse(varValue));

						  cal.getTime();
					  }catch (Exception e) {
						  errorMessage=varValue+" is not a valid date. Please provide a valid date value for "+variableVo.getFormVarDesc();
						  throw new APIException(); 
					  }

				  }

				  if(variableVo.getFormVarType().equalsIgnoreCase(APIConstant.PARAM_MFV_VAR_TYPE_LARGE_STRING) || variableVo.getFormVarType().equalsIgnoreCase(APIConstant.PARAM_MFV_VAR_TYPE_STRING)){
					  if(varValue.length()>4000){
						  errorMessage="Value of the variable cannot be more than 4000 characters. Please provide a valid value for "+variableVo.getFormVarDesc();
						  throw new APIException(); 
					  }
				  }

			  }else{
				  errorMessage="Value of the variable cannot be null or empty. Please provide a valid value for "+variableVo.getFormVarDesc();
				  throw new APIException();
			  }

		  }catch (Exception e) {
			  List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errorMessage));
			  String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			  WebServiceLoggerUtil.logError("FormUtil", "validateFormVariables", "Failed:", new Object[] { e.getMessage() }, e);
			  throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		  } 
	  } 
	  
	  public static List<Form> getQualifyingFormsForQuotePolicy(User user,Connection conn, String entityType,String entityReference,String showAll, String manuscript, long sourceSystemRequestNo) throws Exception{

		  String error=null;
		  CallableStatement callStmt=null;
		  ResultSet rs=null;
		  ArrayList<Form> listOfForms=new ArrayList<Form>();
		  try{
			  if(showAll.equalsIgnoreCase("N")){
				  callStmt = conn.prepareCall("{?= call k_document_template_management.f_get_qualifying_documents(?,?,?,?,?,?,?,?,?,?,?,?)}");
				  callStmt.registerOutParameter(1, OracleTypes.CURSOR);
				  callStmt.setString(2, entityType);
				  callStmt.setString(3, entityReference);
				  callStmt.setString(4, user.getUserId());
				  callStmt.setString(5, "pdt_name");
				  callStmt.setString(6, "");
				  callStmt.setString(7, "Y");
				  callStmt.setString(8, manuscript);
				  callStmt.setString(9, "MANUAL");
				  callStmt.setString(10, "N");
				  callStmt.setString(13, "N");
				  callStmt.setString(11, "pdt_name desc");
				  callStmt.registerOutParameter(12, Types.VARCHAR);
				  callStmt.execute();
				  error=callStmt.getString(12);
			  }else{
				  callStmt = conn.prepareCall("{?= call k_document_template_management.f_get_qualifying_forms(?,?,?,?,?,?,?,?,?,?)}");
				  callStmt.registerOutParameter(1, OracleTypes.CURSOR);
				  callStmt.setString(2, entityType);
				  callStmt.setString(3, entityReference);
				  callStmt.setString(4, user.getUserId());
				  callStmt.setString(5, "pdt_name");
				  callStmt.setString(6, "");
				  callStmt.setString(7, "N");
				  callStmt.setString(8, "N");
				  callStmt.setString(9, "MANUAL");
				  callStmt.setString(10, "pdt_name desc");
				  callStmt.registerOutParameter(11, Types.VARCHAR);
				  callStmt.execute();
				  error=callStmt.getString(11);
			  }

			  if (error!=null) {
				  String errMsg = error;
				  throw new SQLException();
			  }else{
				  rs = (ResultSet)callStmt.getObject(1);
				  while (rs.next()){
					  Form newForm=new Form();
					  newForm.setFormId(rs.getInt("pdt_id"));
					  newForm.setFormName(rs.getString("pdt_name"));
					  newForm.setFormDescription(rs.getString("pdt_description"));
					  newForm.setEditionDate(rs.getString("pdt_edition_date"));
					  newForm.setCoveragePart(rs.getString("mcp_coverage_part_symbol"));
					  newForm.setCoveragePartReference(rs.getString("MCP_COVERAGE_PART_REFERENCE"));
					  newForm.setUserOverride(rs.getString("pda_user_override"));
					  if(showAll.equalsIgnoreCase("N")){
					   newForm.setIsManualUpload(rs.getString("pdt_is_manual_upload"));
					  }
					  newForm.setSourceSystemRequestNo(sourceSystemRequestNo);
					  newForm.setSourceSystemCode(FormsService.SOURCE_SYSTEM_CODE);
					  newForm.setSourceSystemUserId(user.getUserId());
					  getFormVariablesPopulatedForForm(conn,user,entityType,entityReference,newForm,sourceSystemRequestNo);
					  listOfForms.add(newForm);
				  }
			  }
		  }catch (Exception e) {
			  LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					  FormUtil.class.getName(),
					  new Exception().getStackTrace()[0].toString(),
					  ServletConfigUtil.COMPONENT_FRAMEWORK,
					  new Object[] { "entityReference = " + entityReference ,
				  "entityType = " + entityType },
				  "Error in getQualifyingFormsForQuotePolicy",
				  e,
				  LogMinderDOMUtil.VALUE_MIC);			
			  throw e;
		  } finally {
			  try {
				  DBUtil.close(rs, callStmt, null);
			  } catch (SQLException e) {
				  // TODO Auto-generated catch block
				  e.printStackTrace();
			  }
		  }
		  return listOfForms;
	  }

	  /**
	   * 
	   * 
	   * Method is used to fetch variables for the specific form
	   * 
	   * @param conn
	   * @param user
	   * @param form
	   * @param sourceSystemRequestNo
	   * @throws APIException
	   */
	  public static void getFormVariablesPopulatedForForm(Connection conn,User user,String entityType, String entityReference,Form form, long sourceSystemRequestNo) throws Exception{

		  PreparedStatement psFormVariable=null;
		  ResultSet rsFormVariables=null;

		  try{
			  psFormVariable=conn.prepareStatement(queryForFetchingFormVaiablesForForms);
			  psFormVariable.setString(1, entityReference);
			  psFormVariable.setString(2, entityReference);
			  psFormVariable.setString(3, getCustomerCodeFromUser(user));
			  psFormVariable.setString(4, getCustomerCodeFromUser(user));
			  psFormVariable.setString(5, form.getFormId()+"");
			  rsFormVariables=psFormVariable.executeQuery();
			  FormVariables variables=new FormVariables();
			  List<FormVariable> listOfVars=null;
			  listOfVars=new ArrayList<FormVariable>();
			  variables.setFormVariables(listOfVars);
			  while(rsFormVariables.next()){
				  form.setFormVariables(variables);
				  form.setFormVariablePresent(formVariableIsPresent.Y);
				  String variableSpecifics=rsFormVariables.getString("varSpecifics");
				  String[] variableInfo=variableSpecifics.split("@@");
				  FormVariable newVariable=new FormVariable();
				  newVariable.setVariableName(variableInfo[0]);
				  newVariable.setRequired(variableInfo[1].equalsIgnoreCase("Y")?requiredValues.Y:requiredValues.N);
				  if(variableInfo.length > 2){
					  newVariable.setVariableOccurrence(variableInfo[2]);
				  }
				  newVariable.setSourceSystemRequestNo(sourceSystemRequestNo);
				  newVariable.setSourceSystemUserId(user.getUserId());
				  newVariable.setSourceSystemCode(FormsService.SOURCE_SYSTEM_CODE);
				  listOfVars.add(newVariable);
				  
			  }
		  }catch(Exception e){
			  LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					  FormUtil.class.getName(),
					  new Exception().getStackTrace()[0].toString(),
					  ServletConfigUtil.COMPONENT_FRAMEWORK,
					  new Object[] { "entityReference = " + entityReference ,
				  "entityType = " + entityType, "Form Id = "+form.getFormId() },
				  "Error while fetching variables",
				  e,
				  LogMinderDOMUtil.VALUE_MIC);			
			  throw e;
		  }finally{
			  try{
				  DBUtil.close(rsFormVariables, psFormVariable);
			  }catch(Exception e){
				  //Do nothing	
			  }
		  }

	  }
	  
	  public static void addFormToQuotePolicy(User user,Connection conn,String entityType, String entityReference, Form form,String isManuscript) throws APIException{
		  CallableStatement callStmt=null;
		  PreparedStatement psGetFormSpecifics=null;
		  ResultSet rsGetFormSpecifics=null;
		  String binderFlag = null;
		  try{
			  String excludeTypes =
					  CustomerConfigUtil.getInstance().getCustomerProperty(user.getDomain(),
							  ServletConfigUtil.COMPONENT_PORTAL,
							  CustomerConfigUtil.DEFAULT_FORM_EXCLUDE_TYPES);
			  String binderQuery = "SELECT binder_flag FROM ev_mis_quote_policies WHERE entity_reference = ? ";
			  psGetFormSpecifics = conn.prepareStatement(binderQuery); 
			  psGetFormSpecifics.setString(1, entityReference);
			  rsGetFormSpecifics = psGetFormSpecifics.executeQuery();
			  while (rsGetFormSpecifics.next()) {
				  binderFlag = rsGetFormSpecifics.getString(1);
			  }

			  if ("Y".equalsIgnoreCase(isManuscript)) {
				  callStmt =
						  conn.prepareCall("{? = call k_forms_management.f_add_fol_obj_manuscript_assn(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");
				  callStmt.registerOutParameter(1, Types.BIGINT);
				  callStmt.registerOutParameter(19, Types.VARCHAR);
			  } else {
				  callStmt =
						  conn.prepareCall("{? = call k_forms_management.f_add_fol_obj_forms_assn(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");
				  callStmt.registerOutParameter(1, Types.BIGINT);
				  callStmt.registerOutParameter(15, Types.VARCHAR);
			  }

			  callStmt.setString(2, entityReference);
			  callStmt.setString(3,form.getCoveragePartReference());
			  callStmt.setString(4,form.getFormName());
			  callStmt.setString(5,form.getRevision());
			  callStmt.setString(6,form.getEditionDate());
			  callStmt.setString(7,form.getUserOverride());
			  callStmt.setString(8,null);
			  if(null != binderFlag && "Y".equalsIgnoreCase(binderFlag)) {
				  callStmt.setString(9, "ALL");
			  }else {
				  callStmt.setString(9, entityType);
			  }
			  callStmt.setString(10, "Y");
			  	                    
			  if ("Y".equalsIgnoreCase(isManuscript)) {
				  callStmt.setString(11, form.getCustomTitle());
				  callStmt.setString(12, form.getCustomFormNumber());
				  callStmt.setString(13, form.getCustomEditionDate());
				  callStmt.setString(14, form.getIsManualUpload());
				  callStmt.setString(15, user.getUserId());
				  callStmt.setString(16, excludeTypes);
				  callStmt.setString(17, user.getUserId());
				  callStmt.setString(18, "N");
			  } else {
				  callStmt.setString(11, user.getUserId());
				  callStmt.setString(12, excludeTypes);
				  callStmt.setString(13, user.getUserId());
				  callStmt.setString(14, "N");
			  }
			  callStmt.execute();

			  long errorCode = callStmt.getLong(1);
			  if (errorCode != 0) {
				  String errorMessage = "";

				  if ("Y".equalsIgnoreCase(isManuscript)) {
					  errorMessage = callStmt.getString(19);
				  }else {
					  errorMessage = callStmt.getString(15);
				  }

				  List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errorMessage));
				  String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
				  WebServiceLoggerUtil.logError("FormUtil", "addFormToQuotePolicy", "Failed:", new Object[] { errorMessage }, null);
				  throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			  }
			  
			  
			  String queryForGettingAddedFormSpecifics="SELECT * FROM (SELECT pdt_id||lpad(NVL(MIS_FORMS.MFO_OCCURRENCE,0),3,0) uniqueFormId FROM MIS_FORMS, vw_ps_document_template"+
				        							   " WHERE MFO_POLICY_REFERENCE=? AND MFO_FORM_NUMBER=? AND pdt_name=MFO_FORM_NUMBER ORDER BY MFO_DATE_CREATED DESC)"+
				        							   " WHERE rownum<2";
			  
			  psGetFormSpecifics=conn.prepareStatement(queryForGettingAddedFormSpecifics);
			  psGetFormSpecifics.setString(1, entityReference);
			  psGetFormSpecifics.setString(2, form.getFormName());
			  rsGetFormSpecifics=psGetFormSpecifics.executeQuery();
			  while(rsGetFormSpecifics.next()){
				  form.setFormId(rsGetFormSpecifics.getLong(1));
			  }
		  }catch(Exception e){
			  if(e instanceof APIException){
				  String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
				  WebServiceLoggerUtil.logError("FormUtil", "addFormToQuotePolicy", "Failed:", new Object[] { e.getMessage() }, null);
				  throw new APIException(httpStatusCode, APIConstant.FAILED,((APIException) e).getErrorMessageList(),e);  
			  }else{
				  List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(e.getMessage()));
				  String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
				  WebServiceLoggerUtil.logError("FormUtil", "addFormToQuotePolicy", "Failed:", new Object[] { e.getLocalizedMessage() }, null);
				  throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			  }
			  
		  }finally{
			  try{
				  DBUtil.close(rsGetFormSpecifics,psGetFormSpecifics);
			  }catch(Exception e){
				  //Do nothing
			  }
			  try{
				  DBUtil.close(null,callStmt);
			  }catch(Exception e){
				  //Do nothing
			  }
		  }
	}
	  
	  public static void reRankFormsForQuotePolicy(Connection conn, String entityReference) throws Exception{
		  CallableStatement callStmt=null;
		  try{
			  callStmt =conn.prepareCall("{? = call k_document_template_management.f_update_forms_ranks(?) }");
			  callStmt.registerOutParameter(1, Types.VARCHAR);
			  callStmt.setString(2,entityReference);			
			  callStmt.execute();
		  	}catch(Exception e){
			  LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					  FormUtil.class.getName(),
					  new Exception().getStackTrace()[0].toString(),
					  ServletConfigUtil.COMPONENT_FRAMEWORK,
					  new Object[] { "entityReference = " + entityReference},
					  "Error while ranking  forms",
					  e,
					  LogMinderDOMUtil.VALUE_MIC);			
			  throw e;
		  }finally{
			  try{
				  DBUtil.close(null,callStmt);
			  }catch(Exception e){
				  //Do nothing
			  }
		  }
	  }
	  
	  public static String getCustomerCodeFromUser(User user){ 
		  final CustomerConfigUtil ccu = CustomerConfigUtil.getInstance();
		  String domain = user.getDomain();
		  return ccu.getCustomerCode(domain).toUpperCase();
	  }
	  
	  public static boolean validatFormIdFormat(String formId){
		  if(!"".equalsIgnoreCase(formId) && formId.matches("^[0-9]*$")){
			  return true;
		  }
		  return false;
	  }
	  
	  // POLT-16569
	  public static List extractCopyEligibleForms(Connection connection, String entityReference, String entityType) throws Exception
	  {
			Form form = null;
			
			List<Form> formList = new ArrayList<Form>();
			
			PreparedStatement preparedStatement = null;
			
			ResultSet resultSet = null;
			
			try {
				preparedStatement = connection.prepareStatement(generateExtractCopyEligibleFormsSQL());
				
				preparedStatement.setString(1, entityReference);
				preparedStatement.setString(2, entityReference);
				preparedStatement.setString(3, entityType);
				preparedStatement.setString(4, entityReference);				

				resultSet = preparedStatement.executeQuery();

				while (resultSet.next())
				{	                   
					form = new Form();
					
					form.setFormId((resultSet.getLong("uniqueFormId")));
					form.setFormName(null != resultSet.getString(APIConstant.FORM_NAME) ? resultSet.getString(APIConstant.FORM_NAME) : "");
					form.setEditionDate(null != resultSet.getString(APIConstant.FORM_EDITION_DATE) ? resultSet.getString(APIConstant.FORM_EDITION_DATE) : "");
					form.setIsMultiAttach(resultSet.getString(APIConstant.FORM_IS_MULTI_ATTACH));					
					form.setCoveragePartReference(resultSet.getString(APIConstant.PARAMETER_MFO_COVERAGE_PART_REFERENCE));
					
					form.setIsInterline(resultSet.getString(APIConstant.PARAMETER_IS_FORM_INTERLINE));
					form.setQualifyingLOBs(resultSet.getString(APIConstant.PARAMETER_MFO_QUALIFYING_LOBS));
					form.setUserOverride(resultSet.getString(APIConstant.PARAMETER_MFO_USER_DELETE_OVERRIDE));
					
					formList.add(form);
				}
			} catch (SQLException e) {
				 LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, FormUtil.class.getName(), new Exception().getStackTrace()[0].toString(), ServletConfigUtil.COMPONENT_FRAMEWORK,
	                     new Object[] { "entityReference = " + entityReference , "entityType = " + entityType }, "Error in getApplicableForms", e,
	                     LogMinderDOMUtil.VALUE_MIC);
				 
				 e.printStackTrace();
			} finally {			

				try {
	                  DBUtil.close(null, preparedStatement, null);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			return formList;
		}

	// POLT-16569
	private static String generateExtractCopyEligibleFormsSQL()
	{
		StringBuilder extractCopyEligibleFormsSQL = new StringBuilder("");
		
		try
		{
			extractCopyEligibleFormsSQL.append("SELECT DISTINCT pdt_id||lpad(NVL(MIS_FORMS.MFO_OCCURRENCE,0),3,0) uniqueFormId, mcp_coverage_part_reference MFO_COVERAGE_PART_REFERENCE, pdt_name formName, pdt_edition_date editionDate, PDT_IS_MULTI_ATTACH isMultiAttach, MFO_QUALIFYING_LOBS, PDT_IS_INTERLINE AS IS_FORM_INTERLINE, MFO_USER_DELETE_OVERRIDE ");
			extractCopyEligibleFormsSQL.append("FROM MIS_FORMS, mis_policies, mis_coverage_parts, PS_DOCUMENT_ASSOCIATION, VW_PS_DOCUMENT_TEMPLATE ");
			extractCopyEligibleFormsSQL.append("WHERE MFO_POLICY_REFERENCE IN ");
			extractCopyEligibleFormsSQL.append("(SELECT entity_reference FROM vw_mis_quote_policies WHERE org_entity_reference IN ");
			extractCopyEligibleFormsSQL.append("(SELECT org_entity_reference FROM vw_mis_quote_policies WHERE entity_reference = ?)) ");
			extractCopyEligibleFormsSQL.append("AND mpo_policy_reference = ? ");
			extractCopyEligibleFormsSQL.append("AND mcp_policy_reference = mpo_policy_reference ");
			extractCopyEligibleFormsSQL.append("AND (NVL(mcp_coverage_part_symbol, 'PACKAGE') IN ");
			extractCopyEligibleFormsSQL.append("(SELECT NVL(mcp_coverage_part_symbol, 'PACKAGE') FROM mis_coverage_parts ");
			extractCopyEligibleFormsSQL.append("WHERE MCP_POLICY_REFERENCE = MFO_POLICY_REFERENCE ");
			extractCopyEligibleFormsSQL.append("AND MCP_COVERAGE_PART_REFERENCE = MFO_COVERAGE_PART_REFERENCE ");
			extractCopyEligibleFormsSQL.append("AND MFO_COVERAGE_PART_REFERENCE != '99999999999999999') ");
			extractCopyEligibleFormsSQL.append("OR (MFO_COVERAGE_PART_REFERENCE = '99999999999999999' AND INSTR(','||MFO_QUALIFYING_LOBS||',',','||mcp_coverage_part_symbol||',') > 0)) ");
			extractCopyEligibleFormsSQL.append("AND pdt_name = mfo_form_number ");
			extractCopyEligibleFormsSQL.append("AND pda_document_id = pdt_id ");
			extractCopyEligibleFormsSQL.append("AND PDT_IS_MULTI_ATTACH = 'Y' ");
			extractCopyEligibleFormsSQL.append("AND PDT_DATE_DELETED IS NULL ");
			extractCopyEligibleFormsSQL.append("AND ((MFO_ENTITY_TYPE IN DECODE ( ");
			extractCopyEligibleFormsSQL.append("(SELECT K_POLICY_MISC.f_get_polref_type (MFO_POLICY_REFERENCE) VAR_POLICY_REF FROM DUAL), 'B', 'BINDER', 'P', 'POLICY', 'Q', 'QUOTE')) ");
			extractCopyEligibleFormsSQL.append("OR K_Transaction_Management.f_is_qfe(?, ?) = 0)");
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		return (String.valueOf(extractCopyEligibleFormsSQL));
	}
}