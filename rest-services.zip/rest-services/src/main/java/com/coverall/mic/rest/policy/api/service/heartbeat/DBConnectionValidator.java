package com.coverall.mic.rest.policy.api.service.heartbeat;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;*/
import com.coverall.mt.db.ConnectionPool;

public class DBConnectionValidator {
	
	private Logger logger = LoggerFactory.getLogger(DBConnectionValidator.class);
	
	/*private DataSource dataSource;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}*/

	public Boolean validateDatabaseConnection() {
		/*IAPIContext requestContext = APIRequestContext.getApiRequestContext();*/
		int count = -1;
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		String query = null;

		try {
			//conn = requestContext.getConnection();
			conn = ConnectionPool.getAdminConnection();
			stmt = conn.createStatement();
			query = "SELECT 1 FROM DUAL";
			rs = stmt.executeQuery(query);
				while(rs.next()){
					count = rs.getInt(1);
					break;
				}	
		} catch (Exception e) {
			count = -1;
			logger.error("DB Health Check : Error occurred.", e);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception sqlEx) {
					logger.error("DB Health Check : Error occurred while closing resultset.", sqlEx);
				} 

				rs = null;
			}

			if (stmt != null) {
				try {
					stmt.close();
				} catch (Exception sqlEx) {
					logger.error("DB Health Check : Error occurred while closing statement.", sqlEx);
				} 

				stmt = null;
			}
			
			if(conn != null) {
				try {
					conn.close();
				} catch (Exception sqlEx) {
					logger.error("DB Health Check : Error occurred while closing connection.", sqlEx);
				}

				conn = null;
			}
		}
		
		if (count == 1) {
			return true;
		} else {
			return false;
		}
	}

}
