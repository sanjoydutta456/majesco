package com.coverall.mic.rest.policy.api.service.heartbeat;

public class HeartBeatStatusDTO {
	
	private String status;
	
	private String executionTime;

	public HeartBeatStatusDTO() {
		
	}

	public HeartBeatStatusDTO(String status, String executionTime) {
		this.status = status;
		this.executionTime = executionTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getExecutionTime() {
		return executionTime;
	}

	public void setExecutionTime(String executionTime) {
		this.executionTime = executionTime;
	}
	
	@Override
	public String toString() {
		return "{\"status\":\"" + status + "\", \"executionTime\":\"" + executionTime + "\"}";
	}
}
