package com.coverall.mic.rest.policy.api.service.heartbeat;

import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;

public class PASHeartBeatController {
	
	private DBConnectionValidator dbConnectionValidator;

	public Response heartBeat(String applicationName) {
		long startTime = System.currentTimeMillis();
		HeartBeatStatusDTO heartBeatStatusDTO;
		
		dbConnectionValidator = new DBConnectionValidator();
		Boolean isValid = dbConnectionValidator.validateDatabaseConnection();
		if (isValid) {
			long executionTime = System.currentTimeMillis() - startTime;
			heartBeatStatusDTO = new HeartBeatStatusDTO(applicationName + " application is up", executionTime + " ms");
			GenericEntity<HeartBeatStatusDTO> genericEntity = new GenericEntity<HeartBeatStatusDTO>(heartBeatStatusDTO) {
			};
			return Response.ok(genericEntity, MediaType.APPLICATION_JSON).build();
		} else {
			long executionTime = System.currentTimeMillis() - startTime;
			heartBeatStatusDTO = new HeartBeatStatusDTO(applicationName + " application is down", executionTime + " ms");
			GenericEntity<HeartBeatStatusDTO> genericEntity = new GenericEntity<HeartBeatStatusDTO>(heartBeatStatusDTO){};
			return Response.serverError().entity(genericEntity).build();
		}
	}
}
