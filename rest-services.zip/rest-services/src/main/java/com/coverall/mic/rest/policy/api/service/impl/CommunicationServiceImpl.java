package com.coverall.mic.rest.policy.api.service.impl;

import javax.servlet.http.HttpServletRequest;

import com.coverall.mic.rest.policy.api.factory.impl.PolicyAPIFactoryServiceImpl;
import com.coverall.mic.rest.policy.api.service.CommunicationService;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mt.http.User;

public class CommunicationServiceImpl implements CommunicationService {

	@Override
	public Object quoteAttachment(HttpServletRequest request, String quoteId) {
		APIOperationUtil.verifyIfUserHasAccessToTransaction(User.getUser(request),quoteId,"QUOTE");
		//APIOperationUtil.verifyIfUserHasAccessToTheFolderUnderTransaction(User.getUser(request),PolicyAPIServiceImpl.ENTITY_TYPE_QUOTE,quoteId,APIConstant.FOLDER_TAB_FILES,false);
		return (new PolicyAPIFactoryServiceImpl()).getCommunicationAttachmentsFactory(quoteId, request, PolicyAPIServiceImpl.ENTITY_TYPE_QUOTE);
	}

	@Override
	public Object policyAttachment(HttpServletRequest request, String quoteId) {
		APIOperationUtil.verifyIfUserHasAccessToTransaction(User.getUser(request),quoteId,"POLICY");
		//APIOperationUtil.verifyIfUserHasAccessToTheFolderUnderTransaction(User.getUser(request),PolicyAPIServiceImpl.ENTITY_TYPE_POLICY,quoteId,APIConstant.FOLDER_TAB_FILES,false);
		return (new PolicyAPIFactoryServiceImpl()).getCommunicationAttachmentsFactory(quoteId, request, PolicyAPIServiceImpl.ENTITY_TYPE_POLICY);
	}
	
	@Override
	public Object quoteNote(HttpServletRequest request, String quoteId) {
		APIOperationUtil.verifyIfUserHasAccessToTransaction(User.getUser(request),quoteId,"QUOTE");
		//APIOperationUtil.verifyIfUserHasAccessToTheFolderUnderTransaction(User.getUser(request),PolicyAPIServiceImpl.ENTITY_TYPE_QUOTE,quoteId,APIConstant.FOLDER_TAB_FILES,false);
		return (new PolicyAPIFactoryServiceImpl()).getCommunicationNoteFactory(quoteId, request, PolicyAPIServiceImpl.ENTITY_TYPE_QUOTE);
	}

	@Override
	public Object policyNote(HttpServletRequest request, String quoteId) {
		APIOperationUtil.verifyIfUserHasAccessToTransaction(User.getUser(request),quoteId,"POLICY");
		//APIOperationUtil.verifyIfUserHasAccessToTheFolderUnderTransaction(User.getUser(request),PolicyAPIServiceImpl.ENTITY_TYPE_POLICY,quoteId,APIConstant.FOLDER_TAB_FILES,false);
		return (new PolicyAPIFactoryServiceImpl()).getCommunicationNoteFactory(quoteId, request, PolicyAPIServiceImpl.ENTITY_TYPE_POLICY);
	}

}
