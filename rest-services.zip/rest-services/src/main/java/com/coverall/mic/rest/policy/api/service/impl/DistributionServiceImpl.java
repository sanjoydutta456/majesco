package com.coverall.mic.rest.policy.api.service.impl;

import javax.servlet.http.HttpServletRequest;

import com.coverall.mic.rest.policy.api.factory.impl.PolicyAPIFactoryServiceImpl;
import com.coverall.mic.rest.policy.api.service.DistributionService;

public class DistributionServiceImpl implements DistributionService {

	@Override
	public Object producerManagement(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).producerManagementFactory(request);
	}

}
