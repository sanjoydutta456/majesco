package com.coverall.mic.rest.policy.api.service.impl;

import javax.servlet.http.HttpServletRequest;

import com.coverall.mic.rest.policy.api.factory.impl.PolicyAPIFactoryServiceImpl;
import com.coverall.mic.rest.policy.api.service.DocumentManagementService;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mt.http.User;

public class DocumentManagementServiceImpl implements DocumentManagementService {

	@Override
	public Object quoteDocumentManagement(HttpServletRequest request,
			String quoteId) {
		APIOperationUtil.verifyIfUserHasAccessToTransaction(User.getUser(request),quoteId,"QUOTE");
		//APIOperationUtil.verifyIfUserHasAccessToTheFolderUnderTransaction(User.getUser(request),PolicyAPIServiceImpl.ENTITY_TYPE_QUOTE,quoteId,APIConstant.FOLDER_TAB_QUOTE_DOCUMENTS,false);
		return (new PolicyAPIFactoryServiceImpl()).documentPackageManagementQuotesFactory(request,quoteId);
	}

	@Override
	public Object policyDocumentManagement(HttpServletRequest request,
			String policyId) {
		APIOperationUtil.verifyIfUserHasAccessToTransaction(User.getUser(request),policyId,"POLICY");
		//APIOperationUtil.verifyIfUserHasAccessToTheFolderUnderTransaction(User.getUser(request),PolicyAPIServiceImpl.ENTITY_TYPE_POLICY,policyId,APIConstant.FOLDER_TAB_DOCUMENTS,false);
		return (new PolicyAPIFactoryServiceImpl()).documentPackageManagementPolicyFactory(request,policyId);
	}

	@Override
	public Object esign(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).geteSignServiceFactory(request);
	}
}
