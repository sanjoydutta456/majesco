package com.coverall.mic.rest.policy.api.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.FormDocumentInfoService;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.DocumentTemplateInfo;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.util.DBUtil;
import com.coverall.util.GeneralUtil;

public class FormDocumentInfoServiceImpl implements FormDocumentInfoService {
	private HttpServletRequest request;
	public FormDocumentInfoServiceImpl() {}

	public FormDocumentInfoServiceImpl(HttpServletRequest request) {
		this.request=request;
	}

	@Override
	public Object getFormDocumentInfo(String templateName, String templateId, String productCode, String lobCode,
			String stateCode, String customerCode, String wordFormat, String isStatic, String isForm,
			String isInterline, String isManuscript, String isMultiAttach, String requireAdoption) {
		List<String> bindVariables = new ArrayList<String>();
		List<DocumentTemplateInfo> templateInfoList=new ArrayList<DocumentTemplateInfo>();

		String queryForFetchingTemplateInfo="SELECT pdt_id,pdt_name,pdt_document_id, pdt_description, \r\n" + 
				"pdt_mime_type,pdt_is_form,pdt_is_static,pdt_is_mic_document,\r\n" + 
				"pdt_edition_date, pdt_state_code, pdt_revision, \r\n" + 
				"pdt_is_manuscript,pdt_is_interline, pdt_requires_adoption,\r\n" + 
				"pdt_word_format,pdt_is_multi_attach, pdt_is_manual_upload,\r\n" + 
				"pdt_lob_code, pdt_product_code, pdt_customer_code,pdt_validate_variable\r\n" + 
				"FROM vw_ps_document_template\r\n" + 
				"WHERE 1=1\r\n" + 
				"AND pdt_date_deleted IS NULL";

		if(!APIOperationUtil.isNullOrEmptyString(templateName)) {
			queryForFetchingTemplateInfo+=" AND UPPER(pdt_name) LIKE UPPER(?)";
			bindVariables.add("%" + templateName + "%");
		}
		if(!APIOperationUtil.isNullOrEmptyString(templateId)) {
			queryForFetchingTemplateInfo+=" AND UPPER(pdt_document_id) LIKE UPPER(?)";
			bindVariables.add("%" + templateId + "%");
		}
		if(!APIOperationUtil.isNullOrEmptyString(wordFormat)) {
			queryForFetchingTemplateInfo+=" AND UPPER(pdt_word_format) LIKE UPPER(?)";
			bindVariables.add("%" + wordFormat + "%");
		}
		if(!APIOperationUtil.isNullOrEmptyString(productCode)) {
			queryForFetchingTemplateInfo+=" AND UPPER(pdt_product_code) = UPPER(?)";
			bindVariables.add(productCode);
		}
		if(!APIOperationUtil.isNullOrEmptyString(lobCode)) {
			queryForFetchingTemplateInfo+=" AND UPPER(pdt_lob_code) = UPPER(?)";
			bindVariables.add(lobCode);
		}
		if(!APIOperationUtil.isNullOrEmptyString(customerCode)) {
			queryForFetchingTemplateInfo+=" AND UPPER(pdt_customer_code) = UPPER(?)";
			bindVariables.add(customerCode);
		}
		if(!APIOperationUtil.isNullOrEmptyString(stateCode)) {
			queryForFetchingTemplateInfo+=" AND UPPER(pdt_state_code) = UPPER(?)";
			bindVariables.add(stateCode);
		}
		if(!APIOperationUtil.isNullOrEmptyString(isForm)) {
			queryForFetchingTemplateInfo+=" AND UPPER(pdt_is_form) = UPPER(?)";
			bindVariables.add(isForm);
		}
		if(!APIOperationUtil.isNullOrEmptyString(isStatic)) {
			queryForFetchingTemplateInfo+=" AND UPPER(pdt_is_static) = UPPER(?)";
			bindVariables.add(isStatic);
		}
		if(!APIOperationUtil.isNullOrEmptyString(isInterline)) {
			queryForFetchingTemplateInfo+=" AND UPPER(pdt_is_interline) = UPPER(?)";
			bindVariables.add(isInterline);
		}
		if(!APIOperationUtil.isNullOrEmptyString(isManuscript)) {
			queryForFetchingTemplateInfo+=" AND UPPER(pdt_is_manuscript) = UPPER(?)";
			bindVariables.add(isManuscript);
		}
		if(!APIOperationUtil.isNullOrEmptyString(isMultiAttach)) {
			queryForFetchingTemplateInfo+=" AND UPPER(pdt_is_multi_attach) = UPPER(?)";
			bindVariables.add(isMultiAttach);
		}
		if(!APIOperationUtil.isNullOrEmptyString(requireAdoption)) {
			queryForFetchingTemplateInfo+=" AND UPPER(pdt_requires_adoption) = UPPER(?)";
			bindVariables.add(requireAdoption);
		}

		queryForFetchingTemplateInfo+=" AND rownum<3000";
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;

		try{
			conn=requestContext.getConnection();
			ps=conn.prepareStatement(queryForFetchingTemplateInfo);
			GeneralUtil.bindVariablesToStatement(bindVariables, ps, 0);
			rs=ps.executeQuery();

			while(rs.next()){
				DocumentTemplateInfo templateInfo=new DocumentTemplateInfo();
				
				templateInfo.setTemplateId(rs.getLong("pdt_id"));
				long idGenerated=Long.parseLong(rs.getLong("pdt_id")+"000");
				templateInfo.setId(idGenerated);
				templateInfo.setTemplateName(rs.getString("pdt_name"));
				templateInfo.setDocumentId(rs.getString("pdt_document_id"));
				templateInfo.setDescription(rs.getString("pdt_description"));
				templateInfo.setMimeType(rs.getString("pdt_mime_type"));
				templateInfo.setIsForm(rs.getString("pdt_is_form"));
				templateInfo.setIsStatic(rs.getString("pdt_is_static"));
				templateInfo.setIsMicDocument(rs.getString("pdt_is_mic_document"));
				templateInfo.setEditionDate(rs.getString("pdt_edition_date"));
				templateInfo.setStateCode(rs.getString("pdt_state_code"));
				templateInfo.setRevision(rs.getString("pdt_revision"));
				templateInfo.setIsManuscipt(rs.getString("pdt_is_manuscript"));
				templateInfo.setIsInterline(rs.getString("pdt_is_interline"));
				templateInfo.setRequiresAdoption(rs.getString("pdt_requires_adoption"));
				templateInfo.setWordFormat(rs.getString("pdt_word_format"));
				templateInfo.setIsMultiAttach(rs.getString("pdt_is_multi_attach"));
				templateInfo.setIsManualUpload(rs.getString("pdt_is_manual_upload"));
				templateInfo.setLobCode(rs.getString("pdt_lob_code"));
				templateInfo.setProductCode(rs.getString("pdt_product_code"));
				templateInfo.setCustomerCode(rs.getString("pdt_customer_code"));
				templateInfo.setValidateVariable(rs.getString("pdt_validate_variable"));
				
				templateInfoList.add(templateInfo);

			}
		}catch(APIException e){
			throw e;
		}catch (Exception e) {
			String errMsg = e.getLocalizedMessage();
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError("FormDocumentInfoServiceImpl", "getFormDocumentInfo", "Exception occurred while fetching document template information:"+e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}finally{
			try{	
				DBUtil.close(rs, ps);
			}catch(Exception e){
				//do nothing
			}
		}
		return templateInfoList;
	}
}
