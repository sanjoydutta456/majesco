package com.coverall.mic.rest.policy.api.service.impl;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import org.apache.commons.io.IOUtils;
import org.codehaus.jackson.map.ObjectMapper;

import com.coverall.mt.util.APIAuditTrailLog;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.factory.impl.PolicyAPIFactoryServiceImpl;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.IssueBinderService;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.ConfirmationMessage;
import com.coverall.mic.rest.policy.api.service.model.SourceSystemInformationBean;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mic.rest.policy.api.service.util.WorkflowUtil;
import com.coverall.mt.http.User;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.ri.businessbeans.BBBinder;



public class IssueBinderServiceImpl implements IssueBinderService {
	public String entityType;
	public String entityReference;
	public User user;
	public HttpServletRequest request;

	public IssueBinderServiceImpl(HttpServletRequest request,String entityType, String entityReference){
		super();
		this.entityType=entityType;
		this.entityReference=entityReference;
		this.request=request;
		user = User.getUser(request);
	}

	@Override
	public Object issueBinder() throws APIException {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		ConfirmationMessage responseObj=new ConfirmationMessage();
		Connection conn = null;
		try {
			conn = requestContext.getConnection();
			
			String sourceSystemCode=null;
			String sourceSystemUserId=null;
			long sourceSystemRequestNo=0;
			try{
				ObjectMapper mapper=new ObjectMapper();
				String inputJson=APIOperationUtil.fetchRequestBody(request);
				SourceSystemInformationBean sourceSystem=mapper.readValue(inputJson, SourceSystemInformationBean.class);
				sourceSystemCode=sourceSystem.getSourceSystemCode();
				sourceSystemUserId=sourceSystem.getSourceSystemUserId();
				sourceSystemRequestNo=sourceSystem.getSourceSystemRequestNo();
			}catch(Exception exp){
				//do nothing as this is not a mandatory part of request but needed for audit logging
			}		
			//Auditing logic
			APIAuditTrailLog auditTrailLog=requestContext.getAuditTrailLog();
			APIOperationUtil.populateAPIAuditLog(auditTrailLog, sourceSystemCode, sourceSystemUserId, sourceSystemRequestNo, RESOURCE_TYPE, PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
			//Adding specifics
			APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, entityReference, null, "Issuance Transaction");

			if(!WorkflowUtil.checkIfBinder(conn, entityReference)){
				String errMsg = entityReference+" is not a Binder.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("IssueBinderServiceImpl", "issueBinder", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
			
			if(WorkflowUtil.checkIfPolicyBooked(conn, entityReference)){
			 BBBinder.bookIssuePolicy(user, entityReference);
			 responseObj.setCode("200");
			 responseObj.setDescription("Binder issued successfully: "+entityReference);
			}else{
				String errMsg = "Binder "+entityReference+" is not yet booked. It cannot be issued. Please check the status of binder.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("IssueBinderServiceImpl", "issueBinder", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
		} catch (APIException exp) {
			throw exp;
		} catch (Exception exp) {
			String errMsg = "An error occurred while issuing binder "+entityReference+" : "+exp.getMessage();
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logInfo("IssueBinderServiceImpl", "issueBinder", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}

		return responseObj;
	}

	private List<Message> getErrorMessageList(List<String> strMessages)	{
		if(strMessages == null)	{
			return null;
		}
		List<Message> errorMessageList = new ArrayList<Message>(strMessages.size());
		for(String aMsg : strMessages)	{
			Message message = new Message();
			message.setMoreinfo(aMsg);
			errorMessageList.add(message);
		}
		return errorMessageList;
	}
}
