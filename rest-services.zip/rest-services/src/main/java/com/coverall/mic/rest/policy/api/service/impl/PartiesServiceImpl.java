package com.coverall.mic.rest.policy.api.service.impl;

import javax.servlet.http.HttpServletRequest;

import com.coverall.mic.rest.policy.api.factory.impl.PolicyAPIFactoryServiceImpl;
import com.coverall.mic.rest.policy.api.service.PartiesService;

public class PartiesServiceImpl implements PartiesService {

	@Override
	public Object underwriterManagement(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).underwiterTransactionFactory(request);
	}

}
