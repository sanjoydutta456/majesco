package com.coverall.mic.rest.policy.api.service.impl;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.coverall.mic.rest.policy.api.factory.impl.PolicyAPIFactoryServiceImpl;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.ICustomPolicyService;
import com.coverall.mic.rest.policy.api.service.PolicyAPIService;
import com.coverall.mic.rest.policy.api.service.QuoteAllLinesService;
import com.coverall.mic.rest.policy.api.service.atp.impl.ATPTaskServiceImpl;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mic.rest.policy.service.impl.ATPServiceImpl;
import com.coverall.mt.http.User;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.pctv2.server.yaml.generation.APISpecObjectBean;

public class PolicyAPIServiceImpl implements PolicyAPIService{

	public static final String ENTITY_TYPE_QUOTE= "QUOTE";
	public static final String ENTITY_TYPE_POLICY= "POLICY";
	public static final String QUOTE_COMMON= "quote-common";
	public static final String POLICY_COMMON= "policy-common";
	Map<String,String> productAPIUrlMap ;
	
	@Override
	public Object getHOQuotePolicyService(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).getHOQuotePolicyFactoryServicePolicy(request);
	}
	
	@Override
	public Object getCAQuotePolicyService(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).getCAQuotePolicyFactoryServicePolicy(request);
	}
	
	@Override
	public Object getHOQuotePolicyServiceQuotes(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).getHOQuotePolicyFactoryServiceQuote(request);
	}
	
	@Override
	public Object getCAQuotePolicyServiceQuotes(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).getCAQuotePolicyFactoryServiceQuote(request);
	}

	@Override
	public QuoteAllLinesService getQuoteAllLinesResource(HttpServletRequest request) {
		return new QuotePolicyAllLinesServiceImpl("QUOTE");
	}

	@Override
	public QuotePolicyAllLinesServiceImpl getPolicyAllLinesResource(HttpServletRequest request) {
		// TODO Auto-generated method stub
		return new QuotePolicyAllLinesServiceImpl("POLICY");
	}
	
	@Override
	public Object documentPackageManagementQuotes(HttpServletRequest request, String quoteId) {
		APIOperationUtil.verifyIfUserHasAccessToTransaction(User.getUser(request),quoteId,"QUOTE");
		//APIOperationUtil.verifyIfUserHasAccessToTheFolderUnderTransaction(User.getUser(request),ENTITY_TYPE_QUOTE,quoteId,APIConstant.FOLDER_TAB_QUOTE_DOCUMENTS,false);
		return (new PolicyAPIFactoryServiceImpl()).documentPackageManagementQuotesFactory(request,quoteId);
		
	}

	@Override
	public Object documentPackageManagementPolicy(HttpServletRequest request, String policyId) {
		APIOperationUtil.verifyIfUserHasAccessToTransaction(User.getUser(request),policyId,"POLICY");
		//APIOperationUtil.verifyIfUserHasAccessToTheFolderUnderTransaction(User.getUser(request),ENTITY_TYPE_POLICY,policyId,APIConstant.FOLDER_TAB_DOCUMENTS,false);
		return (new PolicyAPIFactoryServiceImpl()).documentPackageManagementPolicyFactory(request,policyId);
	}

	@Override
	public Object unifiedSearch(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).unifiedSearchFactory(request);
	}
	
	@Override
	public Object getCustomerResource(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).getCustomerResourceFactory(request);
	}
	
	@Override
	public Object producerManagement(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).producerManagementFactory(request);
	}

	@Override
	public Object getAllProducts(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).getAllProductsFactory(request);
	}
	
	@Override
	public Object getEndorsementTransaction(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).getEndorsementTransactionFactory(request);
	}
	
	@Override
	public Object getRenewTransaction(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).getRenewTransactionFactory(request);
	}
	
	@Override
	public Object underwiterTransaction(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).underwiterTransactionFactory(request);
	}
	
	@Override
	public String ping() {
		return "This is Policy API service";
	}

	@Override
	public Object distributionManagement(HttpServletRequest request, String versionId) {
		APIOperationUtil.validateVersion(versionId);
		request.setAttribute(APIConstant.VERSION_REQUEST_ATTRIBUTE, versionId);
		return new DistributionServiceImpl();
	}
	
	@Override
	public Object partiesManagement(HttpServletRequest request, String versionId) {
		APIOperationUtil.validateVersion(versionId);
		request.setAttribute(APIConstant.VERSION_REQUEST_ATTRIBUTE, versionId);
		return new PartiesServiceImpl();
	}

	@Override
	public Object getHOPolicyService(HttpServletRequest request, String versionId) {
		APIOperationUtil.validateVersion(versionId);
		request.setAttribute(APIConstant.VERSION_REQUEST_ATTRIBUTE, versionId);
		return (new PolicyAPIFactoryServiceImpl()).getHOQuotePolicyFactoryServicePolicy(request);
	}

	@Override
	public Object getCAPolicyService(HttpServletRequest request, String versionId) {
		APIOperationUtil.validateVersion(versionId);
		request.setAttribute(APIConstant.VERSION_REQUEST_ATTRIBUTE, versionId);
		return (new PolicyAPIFactoryServiceImpl()).getCAQuotePolicyFactoryServicePolicy(request);
	}

	@Override
	public Object getHOQuoteService(HttpServletRequest request, String versionId) {
		APIOperationUtil.validateVersion(versionId);
		request.setAttribute(APIConstant.VERSION_REQUEST_ATTRIBUTE, versionId);
		return (new PolicyAPIFactoryServiceImpl()).getHOQuotePolicyFactoryServiceQuote(request);
	}

	@Override
	public Object getCAQuoteService(HttpServletRequest request, String versionId) {
		APIOperationUtil.validateVersion(versionId);
		request.setAttribute(APIConstant.VERSION_REQUEST_ATTRIBUTE, versionId);
		return (new PolicyAPIFactoryServiceImpl()).getCAQuotePolicyFactoryServiceQuote(request);
	}

	@Override
	public Object getQuoteCommonAllLinesResource(HttpServletRequest request, String versionId) {
		APIOperationUtil.validateVersion(versionId);
		request.setAttribute(APIConstant.VERSION_REQUEST_ATTRIBUTE, versionId);
		return new QuotePolicyAllLinesServiceImpl("QUOTE");
	}

	@Override
	public Object getPolicyCommonAllLinesResource(HttpServletRequest request, String versionId) {
		APIOperationUtil.validateVersion(versionId);
		request.setAttribute(APIConstant.VERSION_REQUEST_ATTRIBUTE, versionId);
		return new QuotePolicyAllLinesServiceImpl("POLICY");
	}

	@Override
	public Object documentPackageManagement(HttpServletRequest request, String versionId) {
		APIOperationUtil.validateVersion(versionId);
		request.setAttribute(APIConstant.VERSION_REQUEST_ATTRIBUTE, versionId);
		return new DocumentManagementServiceImpl();
	}

	@Override
	public Object communicationManagement(HttpServletRequest request,
			String versionId) {
		APIOperationUtil.validateVersion(versionId);
		request.setAttribute(APIConstant.VERSION_REQUEST_ATTRIBUTE, versionId);
		return new CommunicationServiceImpl();
	}

	@Override
	public Object getWKQuotePolicyService(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).getQuotePolicyFactoryServicePolicy(request,"WK");
	}

	@Override
	public Object getWKQuotePolicyServiceQuotes(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).getQuotePolicyFactoryServiceQuote(request,"WK");
	}

	@Override
	public Object getPAQuotePolicyService(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).getQuotePolicyFactoryServicePolicy(request,"PA");
	}

	@Override
	public Object getPAQuotePolicyServiceQuotes(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).getQuotePolicyFactoryServiceQuote(request,"PA");
	}

	@Override
	public Object getDFQuotePolicyService(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).getQuotePolicyFactoryServicePolicy(request,"DF");
	}

	@Override
	public Object getDFQuotePolicyServiceQuotes(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).getQuotePolicyFactoryServiceQuote(request,"DF");
	}

	@Override
	public Object getCPQuotePolicyService(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).getQuotePolicyFactoryServicePolicy(request,"CP");
	}

	@Override
	public Object getCPQuotePolicyServiceQuotes(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).getQuotePolicyFactoryServiceQuote(request,"CP");
	}

	@Override
	public Object getBPQuotePolicyService(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).getQuotePolicyFactoryServicePolicy(request,"BP");
	}

	@Override
	public Object getBPQuotePolicyServiceQuotes(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).getQuotePolicyFactoryServiceQuote(request,"BP");
	}
	
	@Override
	public Object geteSignService(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).geteSignServiceFactory(request);
	}

	@Override
	public Object getGLQuoteService(HttpServletRequest request, String versionId) {
		APIOperationUtil.validateVersion(versionId);
		request.setAttribute(APIConstant.VERSION_REQUEST_ATTRIBUTE, versionId);
		return (new PolicyAPIFactoryServiceImpl()).getQuotePolicyFactoryServiceQuote(request,"GL");
	}

	@Override
	public Object getGLPolicyService(HttpServletRequest request, String versionId) {
		APIOperationUtil.validateVersion(versionId);
		request.setAttribute(APIConstant.VERSION_REQUEST_ATTRIBUTE, versionId);
		return (new PolicyAPIFactoryServiceImpl()).getQuotePolicyFactoryServicePolicy(request,"GL");
	}

	@Override
	public Object getPRQuoteService(HttpServletRequest request, String versionId) {
		APIOperationUtil.validateVersion(versionId);
		request.setAttribute(APIConstant.VERSION_REQUEST_ATTRIBUTE, versionId);
		return (new PolicyAPIFactoryServiceImpl()).getQuotePolicyFactoryServiceQuote(request,"PR");
	}

	@Override
	public Object getPRPolicyService(HttpServletRequest request, String versionId) {
		APIOperationUtil.validateVersion(versionId);
		request.setAttribute(APIConstant.VERSION_REQUEST_ATTRIBUTE, versionId);
		return (new PolicyAPIFactoryServiceImpl()).getQuotePolicyFactoryServicePolicy(request,"PR");
	}

	@Override
	public Object getIMQuoteService(HttpServletRequest request, String versionId) {
		APIOperationUtil.validateVersion(versionId);
		request.setAttribute(APIConstant.VERSION_REQUEST_ATTRIBUTE, versionId);
		return (new PolicyAPIFactoryServiceImpl()).getQuotePolicyFactoryServiceQuote(request,"IM");
	}

	@Override
	public Object getIMPolicyService(HttpServletRequest request, String versionId) {
		APIOperationUtil.validateVersion(versionId);
		request.setAttribute(APIConstant.VERSION_REQUEST_ATTRIBUTE, versionId);
		return (new PolicyAPIFactoryServiceImpl()).getQuotePolicyFactoryServicePolicy(request,"IM");
	}

	@Override
	public Object getCFQuoteService(HttpServletRequest request, String versionId) {
		APIOperationUtil.validateVersion(versionId);
		request.setAttribute(APIConstant.VERSION_REQUEST_ATTRIBUTE, versionId);
		return (new PolicyAPIFactoryServiceImpl()).getQuotePolicyFactoryServiceQuote(request,"CF");
	}

	@Override
	public Object getCFPolicyService(HttpServletRequest request, String versionId) {
		APIOperationUtil.validateVersion(versionId);
		request.setAttribute(APIConstant.VERSION_REQUEST_ATTRIBUTE, versionId);
		return (new PolicyAPIFactoryServiceImpl()).getQuotePolicyFactoryServicePolicy(request,"CF");
	}
	
	@Override
	public Object getTemplatePlaceHolderService(HttpServletRequest request, String versionId,String reference,String referenceType,String templateName,String sourceSystemUserId) {
		APIOperationUtil.validateVersion(versionId);
		request.setAttribute(APIConstant.VERSION_REQUEST_ATTRIBUTE, versionId);
		return (new PolicyAPIFactoryServiceImpl()).getTemplatePlaceHolderServiceFactory(request,reference,referenceType,templateName,sourceSystemUserId);
	}
	
	@Override
	public Object getPolicyTemplateService(HttpServletRequest request, String versionId,String category,String referenceType,String reference) {
		APIOperationUtil.validateVersion(versionId);
		request.setAttribute(APIConstant.VERSION_REQUEST_ATTRIBUTE, versionId);
		return (new PolicyAPIFactoryServiceImpl()).getPolicyTemplateServiceFactory(request,category,referenceType,reference);
	}

	@Override
	public Object getApplicableQuoteService(HttpServletRequest request, String apiFileName, String versionId) {
		APIOperationUtil.validateVersion(versionId);
		request.setAttribute(APIConstant.VERSION_REQUEST_ATTRIBUTE, versionId);
		if(QUOTE_COMMON.equalsIgnoreCase(apiFileName)){
			return new QuotePolicyAllLinesServiceImpl("QUOTE");
		}else{
			String productCode = null;
			if(productAPIUrlMap != null && productAPIUrlMap.containsKey(apiFileName)){
				productCode = productAPIUrlMap.get(apiFileName);
			}else{
				productAPIUrlMap = APIOperationUtil.getProductURLDetails(APIRequestContext.getApiRequestContext().getConnection());
				if(productAPIUrlMap.containsKey(apiFileName)){
					productCode = productAPIUrlMap.get(apiFileName);
				}
			}
			if(productCode != null){
				return new PolicyAPIFactoryServiceImpl().getQuotePolicyFactoryServiceQuote(request, productCode);
			}
			
		}
		return null;
	}

	@Override
	public Object getApplicablePolicyService(HttpServletRequest request, String apiFileName, String versionId) {
		APIOperationUtil.validateVersion(versionId);
		request.setAttribute(APIConstant.VERSION_REQUEST_ATTRIBUTE, versionId);
		if(POLICY_COMMON.equalsIgnoreCase(apiFileName)){
			return new  QuotePolicyAllLinesServiceImpl("POLICY");
		}else{
			String productCode = null;
			if(productAPIUrlMap != null && productAPIUrlMap.containsKey(apiFileName)){
				productCode = productAPIUrlMap.get(apiFileName);
			}else{
				productAPIUrlMap = APIOperationUtil.getProductURLDetails(APIRequestContext.getApiRequestContext().getConnection());
				if(productAPIUrlMap.containsKey(apiFileName)){
					productCode = productAPIUrlMap.get(apiFileName);
				}
			}
			if(productCode != null){
				return  new PolicyAPIFactoryServiceImpl().getQuotePolicyFactoryServicePolicy(request, productCode);
			}
		}
		return null;
	}

	@Override
	public Object getCustomPolicyService(HttpServletRequest request, String apiFileName, String versionId) {
		ICustomPolicyService customServiceHandler;
		String userDomain = APIRequestContext.getApiRequestContext().getMtUser().getDomain();
		String customerCode = CustomerConfigUtil.getInstance().getCustomerCode(userDomain);
		if(customerCode != null){
			String customPolicyJavaImpl = "com.majesco."+customerCode.toLowerCase()+".oasapi.CustomPolicyService";
			WebServiceLoggerUtil.logInfo("PolicyAPIServiceImpl", "getCustomPolicyService", " Getting custom handler for ", new Object[] { userDomain, customerCode });
			Class theClass;
			try {
				theClass = Class.forName(customPolicyJavaImpl);
				customServiceHandler = (ICustomPolicyService)theClass.newInstance();
				return customServiceHandler.getCustomAPIServiceHandler(apiFileName, versionId);
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
				WebServiceLoggerUtil.logError("getCustomPolicyService", "Error creating instance for custom policy service handler", new Object[] { userDomain, customerCode, customPolicyJavaImpl }, e);
				customPolicyJavaImpl = "com.majesco.custom.oasapi.CustomPolicyService";
				try {
					theClass = Class.forName(customPolicyJavaImpl);
					customServiceHandler = (ICustomPolicyService) theClass.newInstance();
					return customServiceHandler.getCustomAPIServiceHandler(apiFileName, versionId);
				} catch (Exception ec) {
					WebServiceLoggerUtil.logError("getCustomPolicyService", "Error creating instance for custom policy service handler", new Object[] { userDomain, customerCode, customPolicyJavaImpl }, e);
				}
				return  "No CustomPolicyService implementation found for customer :" + customerCode;
			} catch (Exception e) {
				e.printStackTrace();
				WebServiceLoggerUtil.logError("getCustomPolicyService", "Error creating instance for custom policy service handler", new Object[] { userDomain, customerCode, customPolicyJavaImpl }, e);
			}
		}else{
			WebServiceLoggerUtil.logError("getCustomPolicyService", "Error getting custom handler, customer code not found", new Object[] { userDomain, customerCode }, new Exception());
		}
		return "No CustomPolicyService implementation found for domain :"+userDomain;
	}

	@Override
	public Object getReportData(HttpServletRequest request, String versionId,
			String apiEndpoint,int pageNumber,int pageSize,String countOnly) {
		APIOperationUtil.validateVersion(versionId);
		request.setAttribute(APIConstant.VERSION_REQUEST_ATTRIBUTE, versionId);
		return (new PolicyAPIFactoryServiceImpl()).getReportData(request, versionId, apiEndpoint,pageNumber,pageSize,countOnly);
	}

	@Override
	public Object getOASReportData(HttpServletRequest request, String versionId,
			String apiEndpoint,int pageNumber,int pageSize,String countOnly) {
		return getReportData( request,  versionId,
				 apiEndpoint, pageNumber, pageSize, countOnly);
	}

	@Override
	public Object atpSpecificTasks(HttpServletRequest request) {
		return new ATPTaskServiceImpl(request);
	}
	
	@Override
	public Object oasUnifiedSearch(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).unifiedSearchFactory(request);
	}
	
	@Override
	public Object getOASCustomerResource(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).getCustomerResourceFactory(request);
	}

	@Override
	public Object getPolicyProductUsageDetails(HttpServletRequest request, String versionId) {
		return (new PolicyAPIFactoryServiceImpl()).getPolicyProductUsageDetails(request, versionId);
	}
	
	@Override
	public Object getPolicyHeartBeatDetails(HttpServletRequest request, String versionId) {
		return (new PolicyAPIFactoryServiceImpl()).getPolicyHeartBeatDetails(request, versionId);
	}
	
	@Override
	public Object getQuoteExtractDetails(HttpServletRequest request, String versionId,String entityReference,String policyAdditionalDetails) {
		return (new PolicyAPIFactoryServiceImpl()).getQuoteExtractDetails(request, versionId, entityReference,policyAdditionalDetails);
	}
	
	@Override
	public Object getPolicyExtractDetails(HttpServletRequest request, String versionId,String entityReference,String policyAdditionalDetails) {
		return (new PolicyAPIFactoryServiceImpl()).getPolicyExtractDetails(request, versionId, entityReference,policyAdditionalDetails);
	}
	
	@Override
	public Object getQuoteImportDetails(HttpServletRequest request, String versionId,String entityReference,String dontBook,String allowTransaction) {
		return (new PolicyAPIFactoryServiceImpl()).getQuoteImportDetails(request, versionId, entityReference,dontBook, allowTransaction);
	}
	
	@Override
	public Object getPolicyImportDetails(HttpServletRequest request, String versionId,String entityReference,String dontBook,String allowTransaction) {
		return (new PolicyAPIFactoryServiceImpl()).getPolicyImportDetails(request, versionId, entityReference,dontBook, allowTransaction);
	}
	
	@Override
	public Object getQuoteChangeSummary(HttpServletRequest request, String versionId,String entityReference) {
		return (new PolicyAPIFactoryServiceImpl()).getQuoteChangeSummary(request, versionId, entityReference);
	}
	
	@Override
	public Object getPolicyChangeSummary(HttpServletRequest request, String versionId,String entityReference) {
		return (new PolicyAPIFactoryServiceImpl()).getPolicyChangeSummary(request, versionId, entityReference);
	}

	@Override
	public Object getQuoteFormsAndDocumentInformation(HttpServletRequest request, String versionId) throws Exception {
		APIOperationUtil.validateVersion(versionId);
		request.setAttribute(APIConstant.VERSION_REQUEST_ATTRIBUTE, versionId);
		return (new PolicyAPIFactoryServiceImpl()).getFormsAndDocumentInformation(request);
	}

	@Override
	public Object getPolicyFormsAndDocumentInformation(HttpServletRequest request, String versionId) throws Exception {
		APIOperationUtil.validateVersion(versionId);
		request.setAttribute(APIConstant.VERSION_REQUEST_ATTRIBUTE, versionId);
		return (new PolicyAPIFactoryServiceImpl()).getFormsAndDocumentInformation(request);
	}

	@Override
	public Object initiateInstanceScaledown(HttpServletRequest request, String timeout) throws Exception {
		return new ScaledownServiceImpl(request,timeout);
	}
	
	@Override
	public Object getOASInsuredResource(HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).getInsuredResourceFactory(request);
	}

	@Override
	public Object lossControl(HttpServletRequest request)
	{
		return (new PolicyAPIFactoryServiceImpl()).lossControlFactory(request);
	}
	
}
