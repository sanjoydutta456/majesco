package com.coverall.mic.rest.policy.api.service.impl;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.Response;

import com.coverall.mic.rest.policy.api.service.PolicyHeartBeat;
import com.coverall.mic.rest.policy.api.service.heartbeat.HeartBeatStatusDTO;
import com.coverall.mic.rest.policy.api.service.heartbeat.PASHeartBeatController;
import com.coverall.mt.webservices.WebServiceLoggerUtil;


public class PolicyHeartBeatImpl implements PolicyHeartBeat {

	public final String MODULE="Majesco Policy";
	HttpServletRequest request;

	public PolicyHeartBeatImpl(){}

	public PolicyHeartBeatImpl(HttpServletRequest request){
		this.request=request;
	}

	@Override
	public Object getHeartBeat() throws Exception {
		// TODO Auto-generated method stub
		WebServiceLoggerUtil.logInfo("PolicyHeartBeatImpl.java", "getHeartBeat", "entering heartBeat in service layer", null);
		long startTime = System.currentTimeMillis();
		String applicationName = null;
		applicationName = "Policy";
		Response response = null;
		try {
			PASHeartBeatController pasHeartBeat = new PASHeartBeatController();
			response = pasHeartBeat.heartBeat(applicationName);
		} catch (Exception e) {
			/*logger.error(applicationName + " application is down.");*/
			
			long executionTime = System.currentTimeMillis() - startTime;
			HeartBeatStatusDTO heartBeatStatusDTO = new HeartBeatStatusDTO(applicationName + " application is down", executionTime + " ms");
			GenericEntity<HeartBeatStatusDTO> genericEntity = new GenericEntity<HeartBeatStatusDTO>(heartBeatStatusDTO) {
			};
			response = Response.serverError().entity(genericEntity).build();
		}
		
		return response;
	}
}
