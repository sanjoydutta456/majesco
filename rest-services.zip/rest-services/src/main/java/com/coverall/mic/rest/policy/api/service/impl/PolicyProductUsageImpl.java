package com.coverall.mic.rest.policy.api.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.PolicyProductUsage;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.DWPReport;
import com.coverall.mic.rest.policy.api.service.model.DWPReportData;
import com.coverall.mic.rest.policy.api.service.model.InforcePremium;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyDocument;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mic.rest.policy.api.service.util.WorkflowUtil;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.util.DBUtil;


public class PolicyProductUsageImpl implements PolicyProductUsage {

	public final String PRODUCT="MAJESCO POLICY";
	public final String PRODUCTLINE="MAJESCO P&C";
	HttpServletRequest request;

	public PolicyProductUsageImpl(){}

	public PolicyProductUsageImpl(HttpServletRequest request){
		this.request=request;
	}


	@Override
	public Object getPayPerUsageDetails(String asOfDate, String dataOption,
			String sourceSystemRequestNo, String requestDate, String sourceSystemCode, String sourceSystemUserId,
			String sourceSystemUserName, int noOfMonths) throws Exception {
		DWPReport report=null;
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		String queryForFetchingInformation="SELECT accounting_yyyymm,\r\n" + 
				"sum(transaction_premium) dwp\r\n" + 
				"FROM (\r\n" + 
				"    SELECT mqp_entity_reference policy_reference, \r\n" + 
				"        mqp_effective_date policy_effective_date,\r\n" + 
				"        mqp_expiration_date policy_expiration_date,\r\n" + 
				"        mqp_booking_date policy_booking_date,\r\n" + 
				"        mqp_trans_effective_date transaction_effective_date, \r\n" + 
				"        mqp_booking_date transaction_date, \r\n" + 
				"        to_char(mqp_booking_date,'yyyymm') accounting_yyyymm, \r\n" + 
				"        mqp_transaction_premium transaction_premium,\r\n" + 
				"        mqp_org_entity_reference org_entity_reference,\r\n" + 
				"        TO_DATE(?, 'yyyymmdd') as_of_date\r\n" + 
				"    FROM mis_quote_policies a\r\n" + 
				"    WHERE mqp_entity_type = 'POLICY'\r\n" + 
				"        AND mqp_booking_status = 'COMPLETE'\r\n" + 
				")\r\n" + 
				" WHERE transaction_date < trunc(as_of_date, 'mm')\r\n" + 
				" AND transaction_date >= add_months(trunc(as_of_date, 'mm'),-?)";
		
		String queryForFetchingFromYearToYear="SELECT sum(transaction_premium) dwp, min(accounting_yyyymm) fromYearMonth, max(accounting_yyyymm) toYearMonth\r\n" +
				"FROM (\r\n" + 
				"    SELECT mqp_entity_reference policy_reference, \r\n" + 
				"        mqp_effective_date policy_effective_date,\r\n" + 
				"        mqp_expiration_date policy_expiration_date,\r\n" + 
				"        mqp_booking_date policy_booking_date,\r\n" + 
				"        mqp_trans_effective_date transaction_effective_date, \r\n" + 
				"        mqp_booking_date transaction_date, \r\n" + 
				"        to_char(mqp_booking_date,'yyyymm') accounting_yyyymm, \r\n" + 
				"        mqp_transaction_premium transaction_premium,\r\n" + 
				"        mqp_org_entity_reference org_entity_reference,\r\n" + 
				"        TO_DATE(?, 'yyyymmdd') as_of_date\r\n" + 
				"    FROM mis_quote_policies a\r\n" + 
				"    WHERE mqp_entity_type = 'POLICY'\r\n" + 
				"        AND mqp_booking_status = 'COMPLETE'\r\n" + 
				")\r\n" + 
				" WHERE transaction_date < trunc(as_of_date, 'mm')\r\n" + 
				" AND transaction_date >= add_months(trunc(as_of_date, 'mm'),-?)";
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;

		String errorMsg=null;
		if(asOfDate==null || "".equalsIgnoreCase(asOfDate)) {
			errorMsg="asOfDate is a required parameters.";
		}else if(sourceSystemCode==null || "".equalsIgnoreCase(sourceSystemCode)){
			errorMsg="sourceSystemCode is a required parameters.";
		}else if(sourceSystemUserId==null || "".equalsIgnoreCase(sourceSystemUserId)){
			errorMsg="sourceSystemUserId is a required parameters.";
		}else if(noOfMonths < 1 ) {
			errorMsg="noOfMonths can't be zero or less than zero";
		}

		String formattedAsOfDate =null;
		if(errorMsg==null) {
			try {
				DateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
				DateFormat targetFormat = new SimpleDateFormat("yyyyMMdd");
				Date date = originalFormat.parse(asOfDate);
				formattedAsOfDate = targetFormat.format(date);
			}catch(Exception exp) {
				errorMsg="asOfDate "+asOfDate+" is not in correct yyyy-mm-dd format.";
			}
		}
		if(errorMsg!=null) {
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errorMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			WebServiceLoggerUtil.logInfo("PolicyProductUsageImpl", "getPayPerUsageDetails", errorMsg, new Object[] {  errorMsg });
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}

		queryForFetchingInformation+=" group by accounting_yyyymm, as_of_date\r\n" + 
				" order by accounting_yyyymm desc";


		try{
			conn=requestContext.getConnection();
			ps=conn.prepareStatement(queryForFetchingInformation);
			ps.setString(1, formattedAsOfDate);
			ps.setInt(2, noOfMonths);
			rs=ps.executeQuery();

			report=new DWPReport();
			report.setProduct(PRODUCT);
			report.setProductLine(PRODUCTLINE);
			report.setAsOfDate(asOfDate);
			report.setNoOfMonths(noOfMonths);
			report.setSourceSystemRequestNo(System.currentTimeMillis()+"");
			List<DWPReportData> datalist=new ArrayList<DWPReportData>();

			while(rs.next()){


				DWPReportData entry=new DWPReportData();

				entry.setTransactionMonth(rs.getString("accounting_yyyymm"));
				entry.setDwpValue(Double.parseDouble(rs.getString("dwp")));
				datalist.add(entry);
			}
			ps=conn.prepareStatement(queryForFetchingFromYearToYear);
			ps.setString(1, formattedAsOfDate);
			ps.setInt(2, noOfMonths);
			rs=ps.executeQuery();
			
			while(rs.next()){
				report.setFromYearMonth(rs.getString("fromYearMonth"));
				report.setToYearMonth(rs.getString("toYearMonth"));
				report.setTotalDwpValue(rs.getString("dwp"));
			}
			
			report.setListData(datalist);
		}catch(APIException e){
			throw e;
		}catch (Exception e) {
			String errMsg = e.getLocalizedMessage();
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError("PolicyProductUsageImpl", "getPayPerUsageDetails", "Exception occurred while fetching dwp information:"+e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}finally{
			try{	
				DBUtil.close(rs, ps);
			}catch(Exception e){
				//do nothing
			}
		}
		return report;
	}

	@Override
	public Object getInforcePoliciesDetails(String asOfDate,
			String sourceSystemRequestNo, String requestDate, String sourceSystemCode, String sourceSystemUserId,
			String sourceSystemUserName) throws Exception {
		InforcePremium inforcePremiumReport=null;
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		String queryForFetchingInformation="SELECT \r\n" + 
				"as_of_date, \r\n" + 
				"sum(transaction_premium) inforce_premium,\r\n" + 
				"count(distinct org_entity_reference) inforce_policies\r\n" + 
				"FROM (\r\n" + 
				"    SELECT mqp_entity_reference policy_reference, \r\n" + 
				"        mqp_effective_date policy_effective_date,\r\n" + 
				"        mqp_expiration_date policy_expiration_date,\r\n" + 
				"        mqp_booking_date policy_booking_date,\r\n" + 
				"        mqp_trans_effective_date transaction_effective_date, \r\n" + 
				"        greatest(mqp_trans_effective_date, mqp_booking_date) transaction_date, \r\n" + 
				"        mqp_transaction_premium transaction_premium,\r\n" + 
				"        mqp_org_entity_reference org_entity_reference,\r\n" + 
				"        TO_DATE(?, 'yyyymmdd') as_of_date\r\n" + 
				"    FROM mis_quote_policies a\r\n" + 
				"    WHERE mqp_entity_type = 'POLICY' -- Policy \r\n" + 
				"        AND mqp_booking_status = 'COMPLETE' -- booked\r\n" + 
				"        AND k_transaction_management.f_is_cancelled_new(MQP_DISPLAY_POLICY_NUMBER) = 'N' " +
				")\r\n" + 
				"WHERE transaction_date <= as_of_date -- transaction_date <= as of date\r\n" + 
				"AND policy_expiration_date > as_of_date -- policy expiration date > as of date\r\n" ;
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;

		String errorMsg=null;
		if(asOfDate==null || "".equalsIgnoreCase(asOfDate)) {
			errorMsg="asOfDate is a required parameters.";
		}else if(sourceSystemCode==null || "".equalsIgnoreCase(sourceSystemCode)){
			errorMsg="sourceSystemCode is a required parameters.";
		}else if(sourceSystemUserId==null || "".equalsIgnoreCase(sourceSystemUserId)){
			errorMsg="sourceSystemUserId is a required parameters.";
		}

		String formattedAsOfDate =null;
		if(errorMsg==null) {
			try {
				DateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
				DateFormat targetFormat = new SimpleDateFormat("yyyyMMdd");
				Date date = originalFormat.parse(asOfDate);
				formattedAsOfDate = targetFormat.format(date);
			}catch(Exception exp) {
				errorMsg="asOfDate "+asOfDate+" is not in correct yyyy-mm-dd format.";
			}
		}
		if(errorMsg!=null) {
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errorMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			WebServiceLoggerUtil.logInfo("PolicyProductUsageImpl", "getInforcePoliciesDetails", errorMsg, new Object[] {  errorMsg });
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}

		/*if(underwritingCompanyCode!=null &&  !"".equalsIgnoreCase(underwritingCompanyCode)) {
			queryForFetchingInformation+=" AND COMPANY_CODE ='"+underwritingCompanyCode+"'";
		}

		if(productCode!=null && !"".equalsIgnoreCase(productCode)) {
			queryForFetchingInformation+=" AND PRODUCT_CODE ='"+productCode+"'";
		}

		queryForFetchingInformation+=" GROUP BY AS_OF_DATE";*/


		try{
			conn=requestContext.getConnection();
			ps=conn.prepareStatement(queryForFetchingInformation);
			ps.setString(1, formattedAsOfDate);
			rs=ps.executeQuery();

			inforcePremiumReport=new InforcePremium();
			inforcePremiumReport.setProduct(PRODUCT);
			inforcePremiumReport.setSourceSystemRequestNo(System.currentTimeMillis()+"");

			while(rs.next()){
				inforcePremiumReport.setInForcePolicyCount(rs.getInt("inforce_policies"));
				inforcePremiumReport.setInForcePremium(Double.parseDouble(rs.getString("inforce_premium")));
				inforcePremiumReport.setAsOfDate(asOfDate);
			}
		}catch(APIException e){
			throw e;
		}catch (Exception e) {
			String errMsg = e.getLocalizedMessage();
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError("PolicyProductUsageImpl", "getInforcePoliciesDetails", "Exception occurred while fetching inforce policies premiums:"+e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}finally{
			try{	
				DBUtil.close(rs, ps);
			}catch(Exception e){
				//do nothing
			}
		}
		return inforcePremiumReport;
	}
}
