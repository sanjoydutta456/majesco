package com.coverall.mic.rest.policy.api.service.impl;

import javax.servlet.http.HttpServletRequest;
import com.coverall.mic.rest.policy.api.service.PurgeService;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.ConfirmationMessage;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyTransactions;
import com.coverall.mic.rest.policy.api.service.model.Transaction;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mic.rest.policy.api.service.util.WorkflowUtil;

import static com.coverall.util.RepositoryConstants.MIC_DIRECTORY_NAME;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpSession;
import javax.ws.rs.core.Response;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.coverall.cms.client.RepositoryAccess;
import com.coverall.cms.client.RepositoryAccessResponse;
import com.coverall.cms.client.impl.sling.http.SlingConstants;
import com.coverall.cms.utility.CustomerCmsUtil;
import com.coverall.exceptions.ExceptionImpl;
import com.coverall.exceptions.FileSystemException;
import com.coverall.imaging.filesystem.CMSDirectory;
import com.coverall.imaging.filesystem.IDirectory;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.HTTPConstants;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.pctv2.server.ri.businessbeans.BBPurge;
import com.coverall.pctv2.server.util.PurgeEntity;
import com.coverall.util.DBUtil;
import com.coverall.mt.fm.FolderManager;

public class PurgeServiceImpl implements PurgeService {

	private String entityType;
	private String entityReference;
	private HttpServletRequest request;
	private static final String CLASS_NAME = "PurgeServiceImpl";
	private static final String B = "B";
	private User user;

	public PurgeServiceImpl(String entityType, String entityReference,HttpServletRequest request) {
		super();
		this.entityType = entityType;
		this.entityReference=entityReference;
		this.request=request;
		user = User.getUser(request);
	}

	@Override
	public Object purgeQuotePolicy() throws Exception {
		LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG,
				CLASS_NAME, "purgeQuotePolicy",
				ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {},
				"Inside purgeQuotePolicy. ", null,
				LogMinderDOMUtil.VALUE_WEBSERVICES);
		ConfirmationMessage confirmationMessage=new ConfirmationMessage();
		Connection conn=null;
		try {                   
			conn = ConnectionPool.getConnection(user);
			QuotePolicyTransactionServiceImpl transactionListingSevice=new QuotePolicyTransactionServiceImpl(entityReference, entityType, request);
			QuotePolicyTransactions transactions=transactionListingSevice.getQuotePolicyTransactionResult();
			boolean purgeAllowed=false;
			
			for(Transaction transaction:transactions.getTransactions()) {
				String transactionName=transaction.getTransactionName();
				if("Purge".equalsIgnoreCase(transactionName)) {
					purgeAllowed=true;
					break;
				}
			}
			if(!purgeAllowed) {
				String errMsg = "Cannot perform purge operation on "+entityReference+". Please verify state of "+entityType+" and operation permitted to user.";
				List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo(CLASS_NAME, "purgeQuotePolicy", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST_CODE,errorMessageList,null);

			}
			//			if(!WorkflowUtil.checkIfLatestRevision(conn, entityReference, entityType)) {
			//				String errMsg = entityReference+" is not the latest revision. Cannot perform purge operation on it.";
			//				List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			//				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			//				WebServiceLoggerUtil.logInfo(CLASS_NAME, "purgeQuotePolicy", errMsg, new Object[] { errMsg });
			//				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST_CODE,errorMessageList,null);
			//
			//			}
			Map policyData=getPolicyDetails(conn,entityReference);
			PurgeEntity.purge(user,entityType,entityReference,getPurgeAction(conn,entityReference, user, policyData), conn);
			
			//logic to delete folder structure
			long folderId=getFolderIdForTheEntity(conn, entityReference);
			if(folderId!=0) {
			 final FolderManager folderManager = FolderManager.getInstance(user);
			 folderManager.deleteFolder(folderId, user);
			}
			confirmationMessage.setCode("200");
			confirmationMessage.setDescription(entityReference+" deleted succssfully");
		}catch(APIException exp) {
			throw exp;  
		}catch (Throwable e1) {
			String errMsg = e1.getLocalizedMessage();
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			WebServiceLoggerUtil.logError(CLASS_NAME, "purgeQuotePolicy", "Failed while purging "+entityType+":"+entityReference, null, e1);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e1);
		}finally{
			DBUtil.close(null, null, conn);
		}
		return confirmationMessage;
	}

	@Override
	public Object purgeQuotePolicyFormDocuments() throws Exception {
		LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG,
				CLASS_NAME, "purgeQuotePolicyDocuments",
				ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {},
				"Inside purgeQuotePolicyDocuments. ", null,
				LogMinderDOMUtil.VALUE_WEBSERVICES);
		Connection conn=null;
		Boolean isQFEFlag=new Boolean(false);
		ConfirmationMessage message=new ConfirmationMessage();

		try{
			int count=0;
			conn = ConnectionPool.getConnection(user);
			
			if(WorkflowUtil.checkIfEntityIsConverted(conn, entityType,entityReference)) {
				String errMsg =""; 
				if("POLICY".equalsIgnoreCase(entityType)) {		
					errMsg=entityReference+" is booked. Cannot delete forms/documents attached with it.";
				}else {
					errMsg=entityReference+" is converted. Cannot delete forms/documents attached with it.";	
				}
				List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo(CLASS_NAME, "purgeQuotePolicy", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST_CODE,errorMessageList,null);

			}

			isQFEFlag=BBPurge.getQFEFlag(conn,entityType,entityReference);
			//count=deleteFormsAndDocFromDB(conn, entityReference);
			
			//if(count>0) {
			purgeImages(user, conn,  entityType, entityReference, isQFEFlag);
			//}
			String messageDescription="";
			//if(count==0) {
			//	messageDescription=" There are no forms/documents associated with "+entityReference;
			//}else {
			messageDescription="Successfully deleted forms/documents associated to "+entityReference+" from CMS.";
			//}

			message.setCode("200");
			message.setDescription(messageDescription);
		}catch(APIException exp) {
			throw exp;  
		}catch (Throwable e1) {
			String errMsg="Error while deleting documents for "+entityReference;
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError(CLASS_NAME, "purgeQuotePolicyDocuments", "Failed while deleting documents for  "+entityType+":"+entityReference, null, e1);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}finally{
			DBUtil.close(null, null, conn);
		}
		return message;
	}

	private String getPurgeAction(Connection conn,String entityReference,User user, Map policyData )
	{
		//Map policyData=getPolicyDetails( entityReference, user);		
		if((null  == policyData.get("BOOKING_STATUS") && ((String)policyData.get("ENTITY_TYPE")).equals("POLICY")  && !((String)policyData.get("TRANSACTION_CODE")).equals("03Q")) 
				&& ((isOosed(conn,entityReference, user)).equals("Y") || isAutoReverseTrans(conn,entityReference, user).equals("Y"))){
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG,
					CLASS_NAME, "getPurgeAction",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {"Action==purgeOOSE"},
					"EntityRefrence. "+entityReference, null,
					LogMinderDOMUtil.VALUE_WEBSERVICES);
			return "purgeOOSE";

		}else{
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG,
					CLASS_NAME, "getPurgeAction",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {"Action==purge"},
					"EntityRefrence. "+entityReference, null,
					LogMinderDOMUtil.VALUE_WEBSERVICES);
			return "purge";
		}		
	}


	private Map getPolicyDetails(Connection conn,String entityReference){
		PreparedStatement pst = null;
		ResultSet rs = null;

		HashMap<String,String> policydata=new HashMap<String,String>();
		String sql = "select TRANSACTION_ACTION,transaction_code,booking_status, entity_type from  VW_MIS_QUOTE_POLICIES where ENTITY_REFERENCE= ? " ;
		try{
			pst = conn.prepareStatement(sql);
			pst.setString(1, entityReference);
			rs = pst.executeQuery();
			while (rs.next()) {
				policydata.put("TRANSACTION_ACTION", rs.getString(1));
				policydata.put("TRANSACTION_CODE", rs.getString(2));
				policydata.put("BOOKING_STATUS", rs.getString(3));
				policydata.put("ENTITY_TYPE", rs.getString(4));
			}
		}
		catch(Exception e){
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					CLASS_NAME, "getPolicyDetails",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {},
					"POlicy Details. ", e,
					LogMinderDOMUtil.VALUE_WEBSERVICES);

		}finally{
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG,
					CLASS_NAME, "getPolicyDetails",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {"ENTITY_REFERENCE: "+ entityReference,"Transaction Action: "+ policydata.get("TRANSACTION_ACTION"),
							"TRANSACTION_CODE: "+ policydata.get("TRANSACTION_CODE"),
							"BOOKING_STATUS: "+ policydata.get("BOOKING_STATUS"),
							"ENTITY_TYPE: "+ policydata.get("ENTITY_TYPE")},
					" getPolicyDetails data. ", null,
					LogMinderDOMUtil.VALUE_WEBSERVICES);
			try {
				DBUtil.close(rs, pst, null);
			} catch (SQLException e) {
				//do nothinh	        	
			}
		}

		return policydata;
	}


	private String isAutoReverseTrans(Connection conn, String entityReference,User user){
		PreparedStatement pst = null;
		ResultSet rs = null;
		String isAutoRevTrans="";
		String sql = "SELECT DECODE(count(*),0,'N','Y')  " +
				"    FROM ev_mis_quote_policies aa     " +
				"WHERE aa.entity_reference = ? " +
				"AND aa.oos_number IS NULL " +
				"AND aa.oos_total IS NULL " +
				"AND aa.reverse_to IS NOT NULL  " +
				"AND exists (SELECT 1 FROM wfl_workload_items " +
				"WHERE wwi_target_entity_Reference =  ? " +
				"AND wwi_status NOT IN ('FAILED'))" ;
		try{
			pst = conn.prepareStatement(sql);
			pst.setString(1, entityReference);
			pst.setString(2, entityReference);
			rs = pst.executeQuery();
			while (rs.next()) {
				isAutoRevTrans = rs.getString(1);
			}
		}catch(Exception e){
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					CLASS_NAME, "isAutoReverseTrans",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {},
					"Error while executing isAutoReverseTrans. ", e,
					LogMinderDOMUtil.VALUE_WEBSERVICES);

		}finally{

			try {
				DBUtil.close(rs, pst, null);
			} catch (SQLException e) {
				//do nothing

			}
		}

		return isAutoRevTrans;
	}


	private String isOosed(Connection conn,String entityReference,User user){
		PreparedStatement pst = null;
		ResultSet rs = null;
		String isOosed="";
		String sql = "SELECT DECODE(count(*),0,'N','Y') " +
				" FROM ev_mis_quote_policies aa     " +
				"WHERE aa.entity_reference = ?      " +
				" AND aa.oos_number IS NOT NULL AND aa.oos_total IS NOT NULL" ;
		try{
			pst = conn.prepareStatement(sql);
			pst.setString(1, entityReference);
			rs = pst.executeQuery();
			while (rs.next()) {
				isOosed = rs.getString(1);
			}
		}catch(Exception e){
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					CLASS_NAME, "isOosed",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {},
					"Error while executing isOosed. ", e,
					LogMinderDOMUtil.VALUE_WEBSERVICES);

		}finally{
			try{
				DBUtil.close(rs, pst, null);
			}catch (SQLException e) {
				//do nothing
			}
		}
		return isOosed;
	}


	private void purgeImages(User user, Connection conn, String entityType,
			String entityReference, Boolean isQFEFlag) throws Exception {
		// TODO Auto-generated method stub
		String entityTypeFlag = 
				BBPurge.getEntityTypeFlag(conn, entityType, entityReference);
		Class imagingUtil = 
				Class.forName("com.coverall.imaging.util.ImagingUtil");
		Method deleteEntityFolders = 
				imagingUtil.getDeclaredMethod("deleteEntityFolders", 
						new Class[] { User.class, 
								String.class, 
								String.class, 
								Boolean.class });

		deleteEntityFolders.invoke(null, 
				new Object[] { user, entityReference, LogMinderDOMUtil.VALUE_MIC, 
						isQFEFlag });
		if (B.equals(entityTypeFlag)) {
			String binderReference = B + entityReference.substring(1);
			deleteEntityFolders.invoke(null, 
					new Object[] { user, binderReference, 
							LogMinderDOMUtil.VALUE_MIC, 
							isQFEFlag });
		}

	}

	/**
	 * Deletes the file from Sling for the user passed in the parameter
	 * @param user the user who wishes to delete the file
	 * @return the Sling directory of the deleted file
	 * @throws FileSystemException if any error occurs while processing
	 */
	private IDirectory deleteFileFromSling(User user,String entityReference) throws FileSystemException {
		RepositoryAccess repositoryAccess = null;

		String filePath = getFilePath(user,entityReference);
		IDirectory existingFile = getFileFromSling(user, filePath);
		if (existingFile == null || !existingFile.isFile()) {
			throw new FileSystemException(ExceptionImpl.FATAL, 
					"Cannot find file in path - " + 
							getFilePath(user,entityReference), null);
		} else {
			String dirPath = existingFile.getAbsolutePath().substring(0, existingFile.getAbsolutePath().lastIndexOf("/"));
			List<String> children = null;
			try {
				HashMap<String, String> parameters = new HashMap<String, String>();
				String customerCode = CustomerConfigUtil.getInstance().getCustomerCode(user.getDomain());
				parameters.put(SlingConstants.SLING_SERVER_URL, CustomerConfigUtil.getInstance().getCustomerProperty(customerCode, ServletConfigUtil.COMPONENT_IMAGING, SlingConstants.SLING_SERVER_URL));
				parameters.put(SlingConstants.SLING_USER_NAME, CustomerConfigUtil.getInstance().getCustomerProperty(customerCode, ServletConfigUtil.COMPONENT_IMAGING, SlingConstants.SLING_USER_NAME));
				parameters.put(SlingConstants.SLING_PASSWORD, CustomerConfigUtil.getInstance().getCustomerProperty(customerCode, ServletConfigUtil.COMPONENT_IMAGING, SlingConstants.SLING_PASSWORD));
				parameters.put(SlingConstants.SLING_WORKSPACE, CustomerConfigUtil.getInstance().getCustomerProperty(customerCode, ServletConfigUtil.COMPONENT_IMAGING, SlingConstants.SLING_WORKSPACE));			

				repositoryAccess = CustomerCmsUtil.getInstance().getRepositoryAccess(customerCode, parameters, MIC_DIRECTORY_NAME);
				if (repositoryAccess.exists(existingFile.getAbsolutePath()) == true) {
					if (!"".equalsIgnoreCase(dirPath)) {
						RepositoryAccessResponse accessResponse = repositoryAccess.list(dirPath);
						children = accessResponse.dir();
						// Delete the file from Sling first

						repositoryAccess.delete(dirPath);

					}
				} else {
					throw new FileSystemException(ExceptionImpl.FATAL, "Cannot find file in path - "
							+ getFilePath(user,entityReference), null);
				}
			} catch (Throwable ioe) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, 
						getClass().getName(), "deleteFileFromSling", 
						ServletConfigUtil.COMPONENT_IMAGING, 
						new Object[] { }, 
						"Error while closing...", 
						ioe, 
						LogMinderDOMUtil.VALUE_MIC);
			}
			return existingFile;
		}
	}
	private IDirectory getFileFromSling(User user, String fullFilePath) throws FileSystemException {

		CMSDirectory root = new CMSDirectory(user, LogMinderDOMUtil.VALUE_MIC);
		IDirectory file = root.getDirectory(fullFilePath);
		return file;
	}
	private String getFilePath(User user,String entityReference) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		String filePath="";
		String sql = "select mff_file_path from MIS_FOLDER_OBJECTS_FILES_ASSN where mff_entity_reference=? and rownum=1 " ;
		try
		{
			conn = ConnectionPool.getConnection(user);
			pst = conn.prepareStatement(sql);
			pst.setString(1, entityReference);
			rs = pst.executeQuery();
			while (rs.next()) {
				filePath = rs.getString(1);
			}
		}
		catch(Exception e)
		{
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					CLASS_NAME, "getFilePath",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {},
					" error whilegetFilePath. ", e,
					LogMinderDOMUtil.VALUE_WEBSERVICES);

		}
		finally
		{

			try {
				DBUtil.close(rs, pst, conn);
			} catch (SQLException e) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
						CLASS_NAME, "Get file path",
						ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {},
						"error whilegetFilePath. ", e,
						LogMinderDOMUtil.VALUE_WEBSERVICES);

			}
		}

		return filePath;
	}

	private int deleteFormsAndDocFromDB(Connection conn,String entityReference) {
		PreparedStatement pstForms = null;
		String sqlForms = "delete from mis_forms where mfo_policy_reference=? " ;
		
		PreparedStatement pstDocuments = null;
		String sqlDocuments = "delete from mis_documents where MDO_POLICY_REFERENCE=? " ;
		
		int count=0;
		try{
			pstForms = conn.prepareStatement(sqlForms);
			pstForms.setString(1, entityReference);
			count = pstForms.executeUpdate();
			
			pstDocuments=conn.prepareStatement(sqlDocuments);
			pstDocuments.setString(1, entityReference);
			count+=pstDocuments.executeUpdate();

		}catch(Exception e){
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					CLASS_NAME, "deleteFormsandDocFromDB",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {},
					" error while deleteFormsandDocFromDB. ", e,
					LogMinderDOMUtil.VALUE_WEBSERVICES);

		}finally{
			try {
				DBUtil.close(null, pstForms, null);
			} catch (SQLException e) {
				//do nothing
			}
			
			try {
				DBUtil.close(null, pstDocuments, null);
			} catch (SQLException e) {
				//do nothing
			}
		}
		return count;
	}

	private int deleteFilesRecordFromDB(User user,String entityReference) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		String filePath="";
		String sql = "delete from MIS_FOLDER_OBJECTS_FILES_ASSN  where mff_entity_reference=? " ;
		int count=0;
		try
		{
			conn = ConnectionPool.getConnection(user);
			pst = conn.prepareStatement(sql);
			pst.setString(1, entityReference);
			count = pst.executeUpdate();

		}
		catch(Exception e)
		{
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					CLASS_NAME, "deleteFilesRecordFromDB",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {},
					" error while deleteFilesRecordFromDB. ", e,
					LogMinderDOMUtil.VALUE_WEBSERVICES);

		}
		finally
		{

			try {
				DBUtil.close(rs, pst, conn);
			} catch (SQLException e) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
						CLASS_NAME, "deleteFilesRecordFromDB",
						ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {},
						"error while deleteFilesRecordFromDB. ", e,
						LogMinderDOMUtil.VALUE_WEBSERVICES);

			}
		}
		return count;

	}
	
	private long getFolderIdForTheEntity(Connection conn,String entityReference) {
		long folderId=0;
		PreparedStatement pst = null;
		ResultSet rs = null;
		String filePath="";
		String sql = "SELECT FEF_ENTITY_FOLDER_ID\r\n" + 
				"FROM FOM_ENTITY_FOLDERS\r\n" + 
				"WHERE FEF_ENTITY_REFERENCE=?" ;
		
		try
		{
			pst = conn.prepareStatement(sql);
			pst.setString(1, entityReference);
			rs=pst.executeQuery();
			if(rs.next()) {
				folderId=rs.getLong(1);
			}

		}
		catch(Exception e){
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					CLASS_NAME, "getFolderIdForTheEntity",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {},
					"Error while getFolderIdForTheEntity", e,
					LogMinderDOMUtil.VALUE_WEBSERVICES);
		}finally{

			try {
				DBUtil.close(rs, pst, null);
			} catch (SQLException e) {
				//do nothing
			}
		}
		return folderId;

	}

	/*public Object purgeFiles(HttpServletRequest request)
			throws Exception {


		LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
				CLASS_NAME, "purgePolicy",
				ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {},
				"Inside purgePolicy. ", null,
				LogMinderDOMUtil.VALUE_WEBSERVICES);
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute(HTTPConstants.SESSION_USER); // Reading
		//System.out.println(user.getUserId());

		String [] fileNameArray=getEntityRefrence(request);
		Connection cn=null;
		for (int i = 0; i < fileNameArray.length; i++) {	

              try {                   

                    IDirectory target=deleteFileFromSlingByFileName(user, fileNameArray[i]);  

              } catch (Throwable e1) {                        
              	LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
							CLASS_NAME, "purgePolicy",
							ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {},
							"Error while executing purgePolicy. ", e1,
							LogMinderDOMUtil.VALUE_WEBSERVICES);
              }finally{
                  // DBUtil.close(null, null, cn);
              }
			}
		purgepojo=new PurgePojo();
		purgepojo.setEntityReference(list);
		//purgepojo.setStatus("Purged File Sucessfully");
		return purgepojo;
	}*/
	/*
	private IDirectory deleteFileFromSlingByFileName(User user,String fileName) throws FileSystemException {
      RepositoryAccess repositoryAccess = null;

      String filePath = this.getFilePathByName(user, fileName);
      IDirectory existingFile = this.getFileFromSling(user, filePath);
      if (existingFile == null || !existingFile.isFile()) {
          throw new FileSystemException(ExceptionImpl.FATAL, 
                                        "Cannot find file in path - " + 
                                      		  filePath, null);
      } else {
          String dirPath = existingFile.getAbsolutePath().substring(0, existingFile.getAbsolutePath().lastIndexOf("/"));
          List<String> children = null;
          try {
				HashMap<String, String> parameters = new HashMap<String, String>();
				String customerCode = CustomerConfigUtil.getInstance().getCustomerCode(user.getDomain());
				parameters.put(SlingConstants.SLING_SERVER_URL, CustomerConfigUtil.getInstance().getCustomerProperty(customerCode, ServletConfigUtil.COMPONENT_IMAGING, SlingConstants.SLING_SERVER_URL));
				parameters.put(SlingConstants.SLING_USER_NAME, CustomerConfigUtil.getInstance().getCustomerProperty(customerCode, ServletConfigUtil.COMPONENT_IMAGING, SlingConstants.SLING_USER_NAME));
				parameters.put(SlingConstants.SLING_PASSWORD, CustomerConfigUtil.getInstance().getCustomerProperty(customerCode, ServletConfigUtil.COMPONENT_IMAGING, SlingConstants.SLING_PASSWORD));
				parameters.put(SlingConstants.SLING_WORKSPACE, CustomerConfigUtil.getInstance().getCustomerProperty(customerCode, ServletConfigUtil.COMPONENT_IMAGING, SlingConstants.SLING_WORKSPACE));			

              repositoryAccess = CustomerCmsUtil.getInstance().getRepositoryAccess(customerCode, parameters, MIC_DIRECTORY_NAME);
              if (repositoryAccess.exists(existingFile.getAbsolutePath()) == true) {
                  if (!"".equalsIgnoreCase(dirPath)) {
                      RepositoryAccessResponse accessResponse = repositoryAccess.list(dirPath);
                      children = accessResponse.dir();
                      // Delete the file from Sling first
                      if (children.size() > 1) {
                          repositoryAccess.delete(existingFile.getAbsolutePath());
                      } else {
                          repositoryAccess.delete(dirPath);
                      }
                  }
              } else {
                  throw new FileSystemException(ExceptionImpl.FATAL, "Cannot find file in path - "
                          + filePath, null);
              }
          } catch (Throwable ioe) {
              LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, 
                      getClass().getName(), "deleteFileFromSling", 
                      ServletConfigUtil.COMPONENT_IMAGING, 
                      new Object[] { }, 
                      "Error while closing...", 
                      ioe, 
                      LogMinderDOMUtil.VALUE_MIC);
          }
          return existingFile;
      }
  }

	private String getFilePathByName(User user,String fileName) {
		Connection conn = null;
      PreparedStatement pst = null;
      ResultSet rs = null;
      String filePath="";
      String sql = "select mff_file_path from MIS_FOLDER_OBJECTS_FILES_ASSN where mff_file_path like '%?%' and rownum=1 " ;
      try
      {
            conn = ConnectionPool.getConnection(user);
            pst = conn.prepareStatement(sql);
            pst.setString(1, fileName);
            rs = pst.executeQuery();
            while (rs.next()) {
          	  filePath = rs.getString(1);
            }
      }
      catch(Exception e)
      {
      	LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					CLASS_NAME, "getFilePath",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {},
					" error whilegetFilePath. ", e,
					LogMinderDOMUtil.VALUE_WEBSERVICES);

      }
      finally
      {

      	try {
				DBUtil.close(rs, pst, conn);
			} catch (SQLException e) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
						CLASS_NAME, "Get file path",
						ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {},
						"error whilegetFilePath. ", e,
						LogMinderDOMUtil.VALUE_WEBSERVICES);

			}
      }

  	return filePath;
	}*/


}
