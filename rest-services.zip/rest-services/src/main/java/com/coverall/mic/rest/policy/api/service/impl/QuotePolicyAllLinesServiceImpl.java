package com.coverall.mic.rest.policy.api.service.impl;

import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.coverall.mt.util.APIAuditTrailLog;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.factory.impl.PolicyAPIFactoryServiceImpl;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.QuoteAllLinesService;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.quotepolicy.QuotePolicyService;
import com.coverall.mic.rest.policy.api.service.quotepolicy.impl.QuotePolicyServiceImpl;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mt.http.User;
import com.coverall.mt.webservices.WebServiceLoggerUtil;


public class QuotePolicyAllLinesServiceImpl implements QuoteAllLinesService {
	
	String entityType ;
	
	
	public QuotePolicyAllLinesServiceImpl(String entityType){
		this.entityType = entityType;
	}
	
	public QuotePolicyAllLinesServiceImpl(){
		
	}

	@Override
	public Object listAllQuotes(HttpServletRequest request, String exactMatch,
			String policyNo,String product, int pageSize, int pageNumber,
			String correlationid, String effectiveStartDateRange,
			String effectiveEndDateRange, String company, String agencyNumber,
			String agencyName, String marketManager, String insured,
			String underwriter, String status) {
		return (new PolicyAPIFactoryServiceImpl()).listAllQuotesFactory(request, exactMatch, policyNo, product, pageSize, pageNumber, correlationid, effectiveStartDateRange, effectiveEndDateRange, company, agencyNumber, agencyName, marketManager, insured, underwriter, status, entityType);
	}
	
//	@Override
//	public Object ListAllQuotesAdvanced(HttpServletRequest request,
//			String exactMatch, String policyId, int pageSize, int pageNumber,
//			String correlationid, String effectiveStartDateRange,
//			String effectiveEndDateRange, String company, String agencyNumber,
//			String agencyName, String marketManager, String insured,
//			String underwriter, String status) {
//		return new QuotePolicySearchServiceImpl(request,exactMatch,policyId,entityType, pageSize,pageNumber,
//				correlationid, effectiveStartDateRange,effectiveEndDateRange,company,agencyNumber,
//				agencyName, marketManager, insured,underwriter, status);
//	}
	
//	@Override
//	public Object listAllQuotesVersions(HttpServletRequest request,
//			int pageSize, int pageNumber, String correlationid) {
//		return new QuotePolicySearchServiceImpl(request,null,null,null,entityType, pageSize,pageNumber,
//				correlationid, null,null,null,null,
//				null, null, null,null, null);
//	}

	@Override
	public Object getFormResource(String quoteId, HttpServletRequest request) {
		APIOperationUtil.verifyIfUserHasAccessToTransaction(User.getUser(request),quoteId,entityType);
		//APIOperationUtil.verifyIfUserHasAccessToTheFolderUnderTransaction(User.getUser(request),entityType,quoteId,APIConstant.FOLDER_TAB_FORMS,false);
		return (new PolicyAPIFactoryServiceImpl()).getFormResourceFactory(quoteId, request, entityType);
	}
	
	@Override
	public Object getTransactions(String quoteId, HttpServletRequest request){
		APIOperationUtil.verifyIfUserHasAccessToTransaction(User.getUser(request),quoteId,entityType);
		return (new PolicyAPIFactoryServiceImpl()).getTransactionsFactory(quoteId, request, entityType);
	}

	@Override
	public Object getQuotePolicyStatusResouce(String quoteId, HttpServletRequest request) {
		APIOperationUtil.verifyIfUserHasAccessToTransaction(User.getUser(request),quoteId,entityType);
		return (new PolicyAPIFactoryServiceImpl()).getQuotePolicyStatusResouceFactory(quoteId, request, entityType);
	}

	@Override
	public Object getCommunicationAttachments(String quoteId,
			HttpServletRequest request) {
		APIOperationUtil.verifyIfUserHasAccessToTransaction(User.getUser(request),quoteId,entityType);
		//APIOperationUtil.verifyIfUserHasAccessToTheFolderUnderTransaction(User.getUser(request),entityType,quoteId,APIConstant.FOLDER_TAB_FILES,false);
		return (new PolicyAPIFactoryServiceImpl()).getCommunicationAttachmentsFactory(quoteId, request, entityType);
	}

	@Override
	public Object processCommissions(String quoteId, HttpServletRequest request) {
		APIOperationUtil.verifyIfUserHasAccessToTransaction(User.getUser(request),quoteId,entityType);
		//APIOperationUtil.verifyIfUserHasAccessToTheFolderUnderTransaction(User.getUser(request),entityType,quoteId,APIConstant.FOLDER_TAB_COMMISSION,false);
		return (new PolicyAPIFactoryServiceImpl()).processCommissionsFactory(quoteId, request, entityType);
	}

	@Override
	public Object processUWRule(String quoteId, HttpServletRequest request) {
		APIOperationUtil.verifyIfUserHasAccessToTransaction(User.getUser(request),quoteId,entityType);
		//APIOperationUtil.verifyIfUserHasAccessToTheFolderUnderTransaction(User.getUser(request),entityType,quoteId,APIConstant.FOLDER_TAB_UW_RULES,false);
		return (new PolicyAPIFactoryServiceImpl()).processUWRuleFactory(quoteId, request, entityType);
	}

	@Override
	public Object processBillingAttributes(String quoteId,
			HttpServletRequest request) {
		APIOperationUtil.verifyIfUserHasAccessToTransaction(User.getUser(request),quoteId,entityType);
		//APIOperationUtil.verifyIfUserHasAccessToTheFolderUnderTransaction(User.getUser(request),entityType,quoteId,APIConstant.FOLDER_TAB_PAY_PLAN,false);
		return (new PolicyAPIFactoryServiceImpl()).processBillingAttributesFactory(quoteId, request, entityType);
	}

	@Override
	public Object getSurchargeDetails(String quoteId, HttpServletRequest request) {
		APIOperationUtil.verifyIfUserHasAccessToTransaction(User.getUser(request),quoteId,entityType);
		return (new PolicyAPIFactoryServiceImpl()).getSurchargeDetailsFactory(quoteId, request, entityType);
	}
	
	@Override
	public Object bookPolicyBinder(String policyId, HttpServletRequest request) {
		APIOperationUtil.verifyIfUserHasAccessToTransaction(User.getUser(request),policyId,entityType);
		return (new PolicyAPIFactoryServiceImpl()).bookPolicyBinderFactory(policyId, request, entityType);
	}
	
	@Override
	public Object issueBinder(String policyId, HttpServletRequest request) {
		APIOperationUtil.verifyIfUserHasAccessToTransaction(User.getUser(request),policyId,entityType);
		return (new PolicyAPIFactoryServiceImpl()).issueBinderFactory(policyId, request, entityType);
	}
	
	@Override
	public Object attachedDocuments(String policyId, HttpServletRequest request) {
		APIOperationUtil.verifyIfUserHasAccessToTransaction(User.getUser(request),policyId,entityType);
		return (new PolicyAPIFactoryServiceImpl()).getAttachedDocuments(policyId, request, entityType);
	}
//
//	@Override
//	public Object cancelPolicy(String quoteId, HttpServletRequest request) {
//		// TODO Auto-generated method stub
//		return null;
//	}

	@Override
	public Object converQuoteToPolicy(String quoteId,String requestJson, HttpServletRequest request) throws Exception {
		String productCode = APIOperationUtil.getProductCode(quoteId, APIRequestContext.getApiRequestContext().getConnection());
		if(productCode == null){
			String errMsg = " Invalid Quote ID "+quoteId;
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			WebServiceLoggerUtil.logInfo("QuotePolicyAllLinesServiceImpl", "converQuoteToPolicy", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
		}
		boolean rate = true;
		boolean fullModel = false;
		String errorMessagePlaceHolderType = "GID";
		//Auditing logic
		if(requestJson==null || "".equalsIgnoreCase(requestJson)) {
			requestJson=APIOperationUtil.fetchRequestBody(request);
		}
		if (requestJson != null && !requestJson.isEmpty()) {
			APIAuditTrailLog auditTrailLog = APIRequestContext.getApiRequestContext().getAuditTrailLog();
			JSONObject jsonObject = (JSONObject) new JSONParser().parse(requestJson);
			String sourceSystemUserId = null;
			String sourceSystemCode = null;
			long sourceSystemRequestNo = 0;

			try {
				rate = jsonObject.get("rate") != null ? "Y".equalsIgnoreCase(jsonObject.get("rate").toString()) : false;
				fullModel = jsonObject.get("fullModel") != null ? "Y".equalsIgnoreCase(jsonObject.get("fullModel").toString()) : false;
				sourceSystemUserId = jsonObject.get("sourceSystemUserId") != null ? jsonObject.get("sourceSystemUserId").toString() : null;
				sourceSystemCode = jsonObject.get("sourceSystemCode") != null ? jsonObject.get("sourceSystemCode").toString() : null;
				sourceSystemRequestNo = jsonObject.get("sourceSystemRequestNo") != null ? Long.parseLong(jsonObject.get("sourceSystemRequestNo").toString())
						: 0;
				errorMessagePlaceHolderType = jsonObject.get("errorMessagePlaceHolderType") != null ? jsonObject.get("errorMessagePlaceHolderType").toString() : "GID";
			} catch (Exception exp) {
				// do nothing as this is specifically for logging purpose
			}
			APIOperationUtil.populateAPIAuditLog(auditTrailLog, sourceSystemCode, sourceSystemUserId, sourceSystemRequestNo, entityType + "-" + productCode,
					PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
		}
		QuotePolicyServiceImpl quotePolicyService =  new QuotePolicyServiceImpl(productCode, entityType);
		Object response = quotePolicyService.processConvert(request, quoteId, false, rate , fullModel,errorMessagePlaceHolderType);
		return response;
	}

	@Override
	public Object converQuoteToBinder(String quoteId,String requestJson, HttpServletRequest request)  throws Exception{
		String productCode = APIOperationUtil.getProductCode(quoteId, APIRequestContext.getApiRequestContext().getConnection());
		if(productCode == null){
			String errMsg = " Invalid Quote ID "+quoteId;
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			WebServiceLoggerUtil.logInfo("QuotePolicyAllLinesServiceImpl", "converQuoteToBinder", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
		}
		boolean rate = true;
		boolean fullModel = false;
		String errorMessagePlaceHolderType = "GID";
		if(requestJson==null || "".equalsIgnoreCase(requestJson)) {
			requestJson=APIOperationUtil.fetchRequestBody(request);
		}
		if (requestJson != null && !requestJson.isEmpty()) {
			// Auditing logic
			APIAuditTrailLog auditTrailLog = APIRequestContext.getApiRequestContext().getAuditTrailLog();
			JSONObject jsonObject = (JSONObject) new JSONParser().parse(requestJson);
			String sourceSystemUserId = null;
			String sourceSystemCode = null;
			long sourceSystemRequestNo = 0;

			try {
				sourceSystemUserId = jsonObject.get("sourceSystemUserId") != null ? jsonObject.get("sourceSystemUserId").toString() : null;
				sourceSystemCode = jsonObject.get("sourceSystemCode") != null ? jsonObject.get("sourceSystemCode").toString() : null;
				sourceSystemRequestNo = jsonObject.get("sourceSystemRequestNo") != null ? Long.parseLong(jsonObject.get("sourceSystemRequestNo").toString())
						: 0;
				rate = jsonObject.get("rate") != null ? "Y".equalsIgnoreCase(jsonObject.get("rate").toString()) : false;
				fullModel = jsonObject.get("fullModel") != null ? "Y".equalsIgnoreCase(jsonObject.get("fullModel").toString()) : false;
				errorMessagePlaceHolderType = jsonObject.get("errorMessagePlaceHolderType") != null ? jsonObject.get("errorMessagePlaceHolderType").toString() : "GID";
			} catch (Exception exp) {
				// do nothing as this is specifically for logging purpose
			}
			APIOperationUtil.populateAPIAuditLog(auditTrailLog, sourceSystemCode, sourceSystemUserId, sourceSystemRequestNo, entityType + "-" + productCode,
					PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
		}
		QuotePolicyServiceImpl quotePolicyService =  new QuotePolicyServiceImpl(productCode, entityType);
		Object response = quotePolicyService.processConvert(request, quoteId, true, rate, fullModel,errorMessagePlaceHolderType);  
		return response;
	}
	
	@Override
	public Object convertQFEToEndorsement(String quoteId,String requestJson, HttpServletRequest request) throws Exception {
		WebServiceLoggerUtil.logInfo("QuotePolicyAllLinesServiceImpl", "convertQFEToEndorsement","requestJson : "+ requestJson, new Object[] { "quoteId : "+quoteId , request});
		String productCode = APIOperationUtil.getProductCode(quoteId, APIRequestContext.getApiRequestContext().getConnection());
		if(productCode == null){
			String errMsg = " Invalid Quote ID "+quoteId;
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			WebServiceLoggerUtil.logInfo("QuotePolicyAllLinesServiceImpl", "convertQFEToEndorsement", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
		}
		boolean rate = true;
		boolean fullModel = false;
		//Auditing logic
		if(requestJson==null || "".equalsIgnoreCase(requestJson)) {
			requestJson=APIOperationUtil.fetchRequestBody(request);
		}
		if (requestJson != null && !requestJson.isEmpty()) {
			APIAuditTrailLog auditTrailLog = APIRequestContext.getApiRequestContext().getAuditTrailLog();
			JSONObject jsonObject = (JSONObject) new JSONParser().parse(requestJson);
			String sourceSystemUserId = null;
			String sourceSystemCode = null;
			long sourceSystemRequestNo = 0;

			try {
				rate = jsonObject.get("rate") != null ? "Y".equalsIgnoreCase(jsonObject.get("rate").toString()) : false;
				fullModel = jsonObject.get("fullModel") != null ? "Y".equalsIgnoreCase(jsonObject.get("fullModel").toString()) : false;
				sourceSystemUserId = jsonObject.get("sourceSystemUserId") != null ? jsonObject.get("sourceSystemUserId").toString() : null;
				sourceSystemCode = jsonObject.get("sourceSystemCode") != null ? jsonObject.get("sourceSystemCode").toString() : null;
				sourceSystemRequestNo = jsonObject.get("sourceSystemRequestNo") != null ? Long.parseLong(jsonObject.get("sourceSystemRequestNo").toString())
						: 0;
			} catch (Exception exp) {
				// do nothing as this is specifically for logging purpose
			}
			APIOperationUtil.populateAPIAuditLog(auditTrailLog, sourceSystemCode, sourceSystemUserId, sourceSystemRequestNo, entityType + "-" + productCode,
					PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
		}
		QuotePolicyServiceImpl quotePolicyService =  new QuotePolicyServiceImpl(productCode, entityType);
		Object response = quotePolicyService.processConvertEndorsement(request, quoteId, "convertQFEToEndorsement", rate , fullModel);
		return response;
	}
	
	
	
	@Override
	public Object getPaymentPlanInformation(String policyId,HttpServletRequest request){
		APIOperationUtil.verifyIfUserHasAccessToTransaction(User.getUser(request),policyId,entityType);
		return (new PolicyAPIFactoryServiceImpl()).getPaymentPlanInformation(policyId, request, entityType);
	}
	
	@Override
	public Object getOOSEResource(String policyId, HttpServletRequest request) {
		return (new PolicyAPIFactoryServiceImpl()).getOOSEResource(request, policyId, entityType);
	}
	
	@Override
	public Object getCommunicationNote(String quoteId,
			HttpServletRequest request) {
		APIOperationUtil.verifyIfUserHasAccessToTransaction(User.getUser(request),quoteId,entityType);
		//APIOperationUtil.verifyIfUserHasAccessToTheFolderUnderTransaction(User.getUser(request),entityType,quoteId,APIConstant.FOLDER_TAB_FILES,false);
		return (new PolicyAPIFactoryServiceImpl()).getCommunicationNoteFactory(quoteId, request, entityType);
	}	
	
	@Override
	public Object performPurgeOperation(String quoteId, HttpServletRequest request) {
		APIOperationUtil.verifyIfUserHasAccessToTransaction(User.getUser(request),quoteId,entityType);
		//APIOperationUtil.verifyIfUserHasAccessToTheFolderUnderTransaction(User.getUser(request),entityType,quoteId,APIConstant.FOLDER_TAB_FILES,false);
		return (new PolicyAPIFactoryServiceImpl()).performPurgeOperation(quoteId, request, entityType);
	}
	
	@Override
	public Object declineQuote(String quoteId,String requestJson, HttpServletRequest request) throws Exception {
		String productCode = APIOperationUtil.getProductCode(quoteId, APIRequestContext.getApiRequestContext().getConnection());
		if(productCode == null){
			String errMsg = " Invalid Quote ID "+quoteId;
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			WebServiceLoggerUtil.logInfo("QuotePolicyAllLinesServiceImpl", "declineQuote", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
		}
		//Auditing logic
		if(requestJson==null || "".equalsIgnoreCase(requestJson)) {
			requestJson=APIOperationUtil.fetchRequestBody(request);
		}
		if (requestJson != null && !requestJson.isEmpty()) {
			APIAuditTrailLog auditTrailLog = APIRequestContext.getApiRequestContext().getAuditTrailLog();
			JSONObject jsonObject = (JSONObject) new JSONParser().parse(requestJson);
			String sourceSystemUserId = null;
			String sourceSystemCode = null;
			long sourceSystemRequestNo = 0;

			try {
				
				sourceSystemUserId = jsonObject.get("sourceSystemUserId") != null ? jsonObject.get("sourceSystemUserId").toString() : null;
				sourceSystemCode = jsonObject.get("sourceSystemCode") != null ? jsonObject.get("sourceSystemCode").toString() : null;
				sourceSystemRequestNo = jsonObject.get("sourceSystemRequestNo") != null ? Long.parseLong(jsonObject.get("sourceSystemRequestNo").toString())
						: 0;
			} catch (Exception exp) {
				// do nothing as this is specifically for logging purpose
			}
			APIOperationUtil.populateAPIAuditLog(auditTrailLog, sourceSystemCode, sourceSystemUserId, sourceSystemRequestNo, entityType + "-" + productCode,
					PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
		}
		QuotePolicyServiceImpl quotePolicyService =  new QuotePolicyServiceImpl(productCode, entityType);
		Object response = quotePolicyService.processDecline(request, quoteId, requestJson);
		return response;
	}
	
	@Override
	public Object openQuote(String quoteId,String requestJson, HttpServletRequest request) throws Exception {
		String productCode = APIOperationUtil.getProductCode(quoteId, APIRequestContext.getApiRequestContext().getConnection());
		if(productCode == null){
			String errMsg = " Invalid Quote ID "+quoteId;
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			WebServiceLoggerUtil.logInfo("QuotePolicyAllLinesServiceImpl", "openQuote", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
		}
		boolean rate = true;
		boolean fullModel = false;
		String errorMessagePlaceHolderType = "GID";
		boolean completeTransaction = false;
		//Auditing logic
		if(requestJson==null || "".equalsIgnoreCase(requestJson)) {
			requestJson=APIOperationUtil.fetchRequestBody(request);
		}
		if (requestJson != null && !requestJson.isEmpty()) {
			APIAuditTrailLog auditTrailLog = APIRequestContext.getApiRequestContext().getAuditTrailLog();
			JSONObject jsonObject = (JSONObject) new JSONParser().parse(requestJson);
			String sourceSystemUserId = null;
			String sourceSystemCode = null;
			long sourceSystemRequestNo = 0;

			try {
				rate = jsonObject.get("rate") != null ? "Y".equalsIgnoreCase(jsonObject.get("rate").toString()) : false;
				fullModel = jsonObject.get("fullModel") != null ? "Y".equalsIgnoreCase(jsonObject.get("fullModel").toString()) : false;
				completeTransaction = jsonObject.get("draft") != null ? "N".equalsIgnoreCase((String)jsonObject.get("draft")) : true;
				sourceSystemUserId = jsonObject.get("sourceSystemUserId") != null ? jsonObject.get("sourceSystemUserId").toString() : null;
				sourceSystemCode = jsonObject.get("sourceSystemCode") != null ? jsonObject.get("sourceSystemCode").toString() : null;
				sourceSystemRequestNo = jsonObject.get("sourceSystemRequestNo") != null ? Long.parseLong(jsonObject.get("sourceSystemRequestNo").toString())
						: 0;
				errorMessagePlaceHolderType = jsonObject.get("errorMessagePlaceHolderType") != null ? jsonObject.get("errorMessagePlaceHolderType").toString() : "GID";
			} catch (Exception exp) {
				// do nothing as this is specifically for logging purpose
			}
			APIOperationUtil.populateAPIAuditLog(auditTrailLog, sourceSystemCode, sourceSystemUserId, sourceSystemRequestNo, entityType + "-" + productCode,
					PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
		}
		QuotePolicyServiceImpl quotePolicyService =  new QuotePolicyServiceImpl(productCode, entityType);
		Object response = quotePolicyService.processOpenQuote(request, quoteId, completeTransaction, rate , fullModel,errorMessagePlaceHolderType);
		return response;
	}
	
	@Override
	public String ping() {
		return "This is quote-common/policy-common service.";
	}
	
	
}
