package com.coverall.mic.rest.policy.api.service.impl;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.type.CollectionType;

import com.coverall.exceptions.FileSystemException;
import com.coverall.mt.util.APIAuditTrailLog;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.factory.impl.PolicyAPIFactoryServiceImpl;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.QuotePolicyAttachmentService;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.ConfirmationMessage;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyAttachmentRequest;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyAttachmentResponse;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyAttachmentDelete;
import com.coverall.mic.rest.policy.api.service.model.SourceSystemInformationBean;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mic.rest.policy.api.service.util.WorkflowUtil;
import com.coverall.mt.cms.FileCabinetAssociation;
import com.coverall.mt.fm.FolderObject;
import com.coverall.mt.http.User;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.DOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;


public class QuotePolicyAttachmentServiceImpl implements QuotePolicyAttachmentService{

	public String entityReference;
	public String entityType;
	public HttpServletRequest request;
	public String customerCode;
	public User user;
	public final String FILE_CABINET_FOLDER="file cabinet"; 

	public static final String TEMP = "temp";
	public static final String TEMPLATE_DOWNLOAD = "templateDownload";
	public boolean isUpdateCall=false;
	
	
	public QuotePolicyAttachmentServiceImpl(String entityReference, String entityType,HttpServletRequest request) {
		super();
		this.entityReference = entityReference;
		this.entityType = entityType;
		this.request=request;

	}

	@Override
	public List<QuotePolicyAttachmentResponse> getQuotePolicyAllAttachmentsList()
			throws Exception {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		user = User.getUser(request);
		Connection conn = null;
		customerCode=getCustomerCodeFromUser(user).toUpperCase();
		List<QuotePolicyAttachmentResponse> attachmentList=new ArrayList<QuotePolicyAttachmentResponse>();
		try{
			conn=requestContext.getConnection();
			if(WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)){
				//policyNumber=getPolicyNumberFromEntityReference(conn,entityReference);
				String folderObjectId=getFolderObjectIdFromEntityReference(conn,entityReference);
				attachmentList=getFileSpecificMetaDataForEntity(conn, folderObjectId,null);

			}else{
				String errMsg = entityType + " " + entityReference + " was not found. Please check input parameters.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("QuotePolicyAttachmentServiceImpl", "getQuotePolicyAllAttachmentsList", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
		}catch (APIException e) {
			WebServiceLoggerUtil.logError("QuotePolicyAttachmentServiceImpl", "getQuotePolicyAllAttachmentsList", "Failed:"+e.getErrorMessage(), new Object[] { null }, e);
			throw e;
		} catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));

			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError("QuotePolicyAttachmentServiceImpl", "getQuotePolicyAllAttachmentsList", "Failed:", new Object[] { e.getMessage() }, e);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		}
		return attachmentList;
	}


	@Override
	public List<QuotePolicyAttachmentResponse> getQuotePolicyAttachmentFile(
			String fieldId) throws Exception {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		user = User.getUser(request);
		Connection conn = null;
		customerCode=getCustomerCodeFromUser(user).toUpperCase();
		List<QuotePolicyAttachmentResponse> attachmentList=new ArrayList<QuotePolicyAttachmentResponse>();
		try{
			conn=requestContext.getConnection();
			if(WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)){
				//policyNumber=getPolicyNumberFromEntityReference(conn,entityReference);
				String folderObjectId=getFolderObjectIdFromEntityReference(conn,entityReference);
				attachmentList=getFileSpecificMetaDataForEntity(conn, folderObjectId,fieldId);

			}else{
				String errMsg = entityType + " " + entityReference + " was not found. Please check input parameters.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
		}catch (APIException e) {
			WebServiceLoggerUtil.logError("QuotePolicyAttachmentServiceImpl", "getQuotePolicyAttachmentFile", "Failed:"+e.getErrorMessage(), new Object[] { null }, e);
			throw e;
		} catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));

			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError("QuotePolicyAttachmentServiceImpl", "getQuotePolicyAttachmentFile", "Failed:", new Object[] { e.getMessage() }, e);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		}
		return attachmentList;
	}


	@Override
	public Object deleteQuotePolicyAttachmentFile(
			String fieldId) throws APIException {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		ConfirmationMessage deleteObject=new ConfirmationMessage();
		user = User.getUser(request);
		Connection conn = null;
		customerCode=getCustomerCodeFromUser(user).toUpperCase();
		fieldId=fieldId.replace(SPACE_REPLACEMENT, " ");
		
		
		if(!isUpdateCall){
			String sourceSystemCode=null;
			String sourceSystemUserId=null;
			long sourceSystemRequestNo=0;
			try{
				ObjectMapper mapper=new ObjectMapper();
				String inputJson=APIOperationUtil.fetchRequestBody(request);
				SourceSystemInformationBean sourceSystem=mapper.readValue(inputJson, SourceSystemInformationBean.class);
				sourceSystemCode=sourceSystem.getSourceSystemCode();
				sourceSystemUserId=sourceSystem.getSourceSystemUserId();
				sourceSystemRequestNo=sourceSystem.getSourceSystemRequestNo();
			}catch(Exception exp){
				//do nothing as this is not a mandatory part of request but needed for audit logging
			}		
			//Auditing logic
			APIAuditTrailLog auditTrailLog=requestContext.getAuditTrailLog();
			APIOperationUtil.populateAPIAuditLog(auditTrailLog, sourceSystemCode, sourceSystemUserId, sourceSystemRequestNo, RESOURCE_TYPE, PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
			//Adding specifics
			APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, entityReference, fieldId, "Deleted File");
		}

		try{
			conn=requestContext.getConnection();
			if(checkSecurityFeatureInFileOperations(conn)){
				if(!WorkflowUtil.checkIfUserHasTheRequiredPermission(requestContext.getUser(), APIConstant.REMOVE_FILE_PERMISSION)) {
					String errMsg = user.getUserId()+" doesn't have permission to delete a file.";
					List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
					String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
					WebServiceLoggerUtil.logInfo("QuotePolicyAttachmentServiceImpl", "deleteQuotePolicyAttachmentFile", errMsg, new Object[] { errMsg });
					throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
				}
			}

			if(WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)){
				if(fieldId==null || fieldId.trim().equalsIgnoreCase("")){
					String errMsg = fieldId + " was not found. Please check input parameters.";
					List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
					String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
					WebServiceLoggerUtil.logInfo("QuotePolicyAttachmentServiceImpl", "deleteQuotePolicyAttachmentFile", errMsg, new Object[] { errMsg });
					throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
				}
				//policyNumber=getPolicyNumberFromEntityReference(conn,entityReference);
				String folderObjectId=getFolderObjectIdFromEntityReference(conn,entityReference);
				Map<String, String> fileSpecificMap=getFilePathFromFolderId(conn, folderObjectId,fieldId);
				if(fileSpecificMap.size()>0){
				 FileCabinetAssociation fileCabinetAssociation=new FileCabinetAssociation();
				 fileCabinetAssociation.setFolderObjectId(Long.parseLong(folderObjectId));
				 fileCabinetAssociation.setFilePath(fileSpecificMap.get("FILE_PATH"));
				 fileCabinetAssociation.setFileName(fileSpecificMap.get("FILE_NAME"));
				 fileCabinetAssociation.delete(user);
				 deleteObject.setCode("200");
				 deleteObject.setDescription(fileSpecificMap.get("FILE_NAME")+" is deleted.");
				 conn.commit();
				}else{
				 deleteObject.setCode("404");
				 deleteObject.setDescription("There is no such file "+fieldId+" for "+entityReference);	
				}
			}else{
				String errMsg = entityType + " " + entityReference + " was not found. Please check input parameters.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("QuotePolicyAttachmentServiceImpl", "deleteQuotePolicyAttachmentFile", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
		}catch (APIException e) {
			WebServiceLoggerUtil.logError("QuotePolicyAttachmentServiceImpl", "deleteQuotePolicyAttachmentFile", "Failed:"+e.getErrorMessage(), new Object[] { null }, e);
			throw e;
		} catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));

			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError("QuotePolicyAttachmentServiceImpl", "deleteQuotePolicyAttachmentFile", "Failed:", new Object[] { e.getMessage() }, e);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		}
		return deleteObject;
	}

	@Override
	public Object addQuotePolicyAttachmentFile()
			throws Exception {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		user = User.getUser(request);
		Connection conn = null;
		customerCode=getCustomerCodeFromUser(user).toUpperCase();
		List<QuotePolicyAttachmentResponse> filteredAttachmentList=new ArrayList<QuotePolicyAttachmentResponse>();
		//requestContext.setAuditTrailLog(null);

		try{
			conn=requestContext.getConnection();

			if(checkSecurityFeatureInFileOperations(conn)){
				if(!WorkflowUtil.checkIfUserHasTheRequiredPermission(requestContext.getUser(), APIConstant.ATTACH_FILE_PERMISSION)) {
					String errMsg = user.getUserId()+" doesn't have permission to attach a file.";
					List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
					String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
					WebServiceLoggerUtil.logInfo("QuotePolicyAttachmentServiceImpl", "addQuotePolicyAttachmentFile", errMsg, new Object[] { errMsg });
					throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
				}
			}

			if(WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)){
				String folderObjectId=getFolderObjectIdFromEntityReference(conn,entityReference);

				ObjectMapper mapper=new ObjectMapper();
				String inputJson=APIOperationUtil.fetchRequestBody(request);
				CollectionType listType = mapper.getTypeFactory().constructCollectionType(ArrayList.class, QuotePolicyAttachmentRequest.class);
				ArrayList<QuotePolicyAttachmentRequest> fileRequestList=mapper.readValue(inputJson, listType);

				Set<String> listOfFilesAdded=new HashSet<String>();
				for(QuotePolicyAttachmentRequest fileInput: fileRequestList){
					validateFileInputs(fileInput);
					//File Data
					String fileData=fileInput.getFile();
					byte[] fileDataByte = Base64.decodeBase64(fileData);
					InputStream targetStream = new ByteArrayInputStream(fileDataByte);

					//File meta-data
					String fileName=fileInput.getFilename();
					String fileExtension=fileName.contains(".")?"."+((fileName.split("\\.")[1]).toLowerCase()):"";
					fileName=fileName.contains(".")?(fileName.split("\\.")[0]):fileName;
					

					FileCabinetAssociation fileCabAsso = new FileCabinetAssociation();
					fileCabAsso.setFolderObjectId(Long.parseLong(folderObjectId));
					//Temporary folder created for uploading file to sling
					String temporaryFolderLocation=getTemporaryFolderLocation();
					fileCabAsso.setTempDirPath(temporaryFolderLocation);
					fileCabAsso.setFileName(fileName);
					fileCabAsso.setFileExtension(fileExtension);
					fileCabAsso.setFilePath(FILE_CABINET_FOLDER+"/"+entityType.toUpperCase()+"/"+entityReference.toUpperCase());
					fileCabAsso.setFileDescription(fileInput.getFileDescription());
					fileCabAsso.setUserCreated(user.getFullName());
					fileCabAsso.setEntityType(entityType);
					fileCabAsso.setEntityReference(entityReference);
					fileCabAsso.setFileInputStream(targetStream);
					fileCabAsso.setFileSize(targetStream.available());
					fileCabAsso.setFileType(getMimeTypeForFile(conn,fileExtension));
					fileCabAsso.insert(user);
					String fileId=fileCabAsso.getFilePath().substring(fileCabAsso.getFilePath().lastIndexOf("/"));
					listOfFilesAdded.add(fileId);
					conn.commit();
					deleteTemporaryFolder(temporaryFolderLocation);
					
				}
				
				for(String fieldId:listOfFilesAdded){
					filteredAttachmentList.add(getFileSpecificMetaDataForEntity(conn, folderObjectId,fieldId).get(0));
				}
				
			}else{
				String errMsg = entityType + " " + entityReference + " was not found. Please check input parameters.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("QuotePolicyAttachmentServiceImpl", "addQuotePolicyAttachmentFile", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
		}catch (APIException e) {
			WebServiceLoggerUtil.logError("QuotePolicyAttachmentServiceImpl", "addQuotePolicyAttachmentFile", e.getLocalizedMessage(), new Object[] { e.getErrorMessage() }, null);
			throw e;
		} catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));

			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError("QuotePolicyAttachmentServiceImpl", "addQuotePolicyAttachmentFile", "Failed:", new Object[] { e.getMessage() }, e);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		}
		return filteredAttachmentList;
	}

	@Override
	public Object updateQuotePolicyAttachmentFile(
			String fieldId) throws Exception {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();

		if(checkSecurityFeatureInFileOperations(requestContext.getConnection())){
		if(!WorkflowUtil.checkIfUserHasTheRequiredPermission(requestContext.getUser(), APIConstant.REMOVE_FILE_PERMISSION) && !WorkflowUtil.checkIfUserHasTheRequiredPermission(requestContext.getUser(), APIConstant.ATTACH_FILE_PERMISSION)){
			String errMsg = user.getUserId()+" doesn't have permission to both add and delete a file. Thus, update operation cannot be performed.";
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			WebServiceLoggerUtil.logInfo("QuotePolicyAttachmentServiceImpl", "updateQuotePolicyAttachmentFile", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
		 }
		}
		isUpdateCall=true;
		deleteQuotePolicyAttachmentFile(fieldId);
		return addQuotePolicyAttachmentFile();
	}

	public List<Message> getErrorMessageList(List<String> strMessages)	{
		if(strMessages == null)	{
			return null;
		}
		List<Message> errorMessageList = new ArrayList<Message>(strMessages.size());
		for(String aMsg : strMessages)	{
			Message message = new Message();
			message.setMoreinfo(aMsg);
			errorMessageList.add(message);
		}
		return errorMessageList;
	}

	public String getFolderObjectIdFromEntityReference(Connection conn,String entityReference) throws SQLException{

		PreparedStatement ps=null;
		ResultSet rs=null;
		String objectId="";
		String queryForFolderObjectId="SELECT FOB_FOLDER_OBJECT_ID FROM FOM_FOLDER_OBJECTS"+
				" WHERE FOB_FOLDER_ID=(SELECT FEF_FOLDER_ID FROM FOM_ENTITY_FOLDERS"+
				" WHERE FEF_ENTITY_REFERENCE=? AND FEF_ENTITY_TYPE=?) AND FOB_OBJECT_ID=("+
				" SELECT FBO_OBJECT_ID FROM FOM_BASIC_OBJECTS WHERE FBO_OBJECT_NAME='File Cabinet')";
		try {
			//Converting entity reference to new Business entity reference
			entityReference=FolderObject.getNewBusinessPolicyReferenceForAPI(conn,entityReference,User.getUser(request));
			
			ps=conn.prepareStatement(queryForFolderObjectId);
			ps.setString(1, entityReference);
			ps.setString(2, entityType);

			rs=ps.executeQuery();
			while(rs.next()){
				objectId=rs.getString("FOB_FOLDER_OBJECT_ID");
			}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			WebServiceLoggerUtil.logError("QuotePolicyAttachmentServiceImpl", "getFolderObjectIdFromEntityReference", "Failed:", new Object[] { e.getMessage() }, e);
			throw e;
		}finally{
			try{
				DBUtil.close(rs, ps);
			}catch(Exception e){
				WebServiceLoggerUtil.logInfo("QuotePolicyAttachmentServiceImpl", "deleteQuotePolicyAttachmentFile", e.getLocalizedMessage(), new Object[] { e.getMessage() });	
			}
		}

		return objectId;

	}

	public List<QuotePolicyAttachmentResponse> getFileSpecificMetaDataForEntity(Connection conn,String folderObjectId, String fieldId) throws Exception{
		PreparedStatement ps=null;
		ResultSet rs=null;

		//Fetching file specific meta-data
		List<QuotePolicyAttachmentResponse> attachmentsData=new ArrayList<QuotePolicyAttachmentResponse>();
		long sourceSystemRequestNo=System.currentTimeMillis();

		String queryForFileMetaData="SELECT MFF_FOLDER_OBJECT_ID,MFF_FILE_NAME||MFF_FILE_EXTENSION fileName, MFF_ENTITY_REFERENCE,MFF_FILE_DESCRIPTION,"+
				"substr(substr(MFF_FILE_PATH,INSTR(MFF_FILE_PATH, '/',-1)),2) mff_file_id,"+
				"MFF_FILE_PATH,k_string_utilities.urlencode(MFF_FILE_TYPE) MFF_FILE_TYPE,"+  
				"(CASE WHEN MFF_FILE_SIZE < 1024 THEN MFF_FILE_SIZE || ' Bytes'"+
				" WHEN MFF_FILE_SIZE/1024 < 1024 THEN TO_CHAR(MFF_FILE_SIZE/1024, 'FM9999.99') || ' KB'"+
				" WHEN MFF_FILE_SIZE/1024/1024 < 1024 THEN TO_CHAR(MFF_FILE_SIZE/1024/1024, 'FM9999.99') || ' MB'"+
				" WHEN MFF_FILE_SIZE/1024/1024/1024 < 1024 THEN TO_CHAR(MFF_FILE_SIZE/1024/1024/1024, 'FM9999.99') || ' GB'"+
				" END) MFF_FILE_SIZE_DISPLAY,MFF_FILE_SIZE, TO_CHAR(cast(MFF_DATE_CREATED as timestamp) at time zone 'UTC', 'YYYY-MM-DD\"T\"HH24:MI:SS\"Z\"') DATE_CREATED,"+
				" MFF_USER_CREATED USER_CREATED, TO_CHAR(cast(NVL(MFF_DATE_MODIFIED,MFF_DATE_CREATED) as timestamp) at time zone 'UTC', 'YYYY-MM-DD\"T\"HH24:MI:SS\"Z\"') DATE_MODIFIED,"+
				" MFF_USER_MODIFIED MFF_USER_MODIFIED,NVL(SMT_DISPLAY_NAME,(SELECT SMT_DISPLAY_NAME FROM SHL_MIME_TYPES"+  
				" WHERE SMT_MIME_TYPE = 'application/x-unknown')) SMT_DISPLAY_NAME,NVL(SMT_ICON, (SELECT SMT_ICON FROM SHL_MIME_TYPES"+  
				" WHERE SMT_MIME_TYPE = 'application/x-unknown')) SMT_ICON FROM MIS_FOLDER_OBJECTS_FILES_ASSN,SHL_MIME_TYPES"+  
				" WHERE MFF_FILE_TYPE = SMT_MIME_TYPE AND MFF_FOLDER_OBJECT_ID=?";

		if(fieldId !=null && !fieldId.equalsIgnoreCase("")){
			queryForFileMetaData+=" AND MIS_FOLDER_OBJECTS_FILES_ASSN.MFF_FILE_PATH LIKE (?)";
		}

		try {
			ps=conn.prepareStatement(queryForFileMetaData);
			ps.setString(1, folderObjectId);
			if (fieldId != null && !fieldId.equalsIgnoreCase("")) {
				ps.setString(2, "%" + fieldId);
			}

			rs=ps.executeQuery();
			while(rs.next()){
				QuotePolicyAttachmentResponse attachment=new QuotePolicyAttachmentResponse();
				
				attachment.setSourceSystemUserId(user.getUserId());
				attachment.setSourceSystemCode(SOURCE_SYSTEM_CODE);
				attachment.setSourceSystemRequestNo(sourceSystemRequestNo);
				
				
				String fileId=(rs.getString("mff_file_id")).replace(" ", SPACE_REPLACEMENT);
				attachment.setFileId(fileId);
				attachment.setFilename(rs.getString("fileName"));
				attachment.setFileDescription(rs.getString("MFF_FILE_DESCRIPTION"));
				attachment.setFileSize(rs.getString("MFF_FILE_SIZE_DISPLAY"));
				attachment.setFileType(rs.getString("SMT_DISPLAY_NAME"));
				attachment.setLastUpdated(rs.getString("DATE_MODIFIED"));
				attachment.setFileAddedBy(rs.getString("USER_CREATED"));
				attachment.setFile(fetchFileFromSlingInBase64aencodedString(rs.getString("MFF_FILE_PATH")));
				attachmentsData.add(attachment);
			}
		}catch (Exception e) {
			WebServiceLoggerUtil.logError("QuotePolicyAttachmentServiceImpl", "getFileSpecificMetaDataForEntity", "Failed:", new Object[] { e.getMessage() }, e);
			throw e;
		}finally{
			try{
				DBUtil.close(rs, ps);
			}catch(Exception e){
				WebServiceLoggerUtil.logInfo("QuotePolicyAttachmentServiceImpl", "getFileSpecificMetaDataForEntity", e.getLocalizedMessage(), new Object[] { e.getMessage() });	
			}
		}
		return attachmentsData;
	}


	private Map<String,String> getFilePathFromFolderId(Connection conn,String folderObjectId, String fieldId) throws Exception{
		PreparedStatement ps=null;
		ResultSet rs=null;

		//Fetching file specific meta-data
		Map<String, String> fileSpecifics=new HashMap<String, String>();

		String queryForFilePathData = "SELECT MFF_FILE_NAME,MFF_FILE_PATH FROM MIS_FOLDER_OBJECTS_FILES_ASSN WHERE MFF_FOLDER_OBJECT_ID = ? "
				+ " AND MIS_FOLDER_OBJECTS_FILES_ASSN.MFF_FILE_PATH LIKE (?)";

		try {
			ps=conn.prepareStatement(queryForFilePathData);
			ps.setString(1, folderObjectId);
			ps.setString(2, "%" + fieldId);
			rs=ps.executeQuery();
			while(rs.next()){
				fileSpecifics.put("FILE_NAME", rs.getString("MFF_FILE_NAME"));
				fileSpecifics.put("FILE_PATH", rs.getString("MFF_FILE_PATH"));

			}
		}catch (Exception e) {
			WebServiceLoggerUtil.logError("QuotePolicyAttachmentServiceImpl", "getFilePathFromFolderId", "Failed:", new Object[] { e.getMessage() }, e);
			throw e;
		}finally{
			try{
				DBUtil.close(rs, ps);
			}catch(Exception e){
				WebServiceLoggerUtil.logInfo("QuotePolicyAttachmentServiceImpl", "getFilePathFromFolderId", e.getLocalizedMessage(), new Object[] { e.getMessage() });	
			}
		}
		return fileSpecifics;
	}

	private String fetchFileFromSlingInBase64aencodedString(String filePath) throws SQLException,FileSystemException, IOException{
		FileCabinetAssociation fileCabinetAssociation = new FileCabinetAssociation();
		fileCabinetAssociation.fetchFileDataFromSling(user, filePath);
		InputStream in=fileCabinetAssociation.getFileInputStream();
		String fileString="";
		byte[] bytesEncoded = Base64.encodeBase64(IOUtils.toByteArray(in));
		fileString=new String(bytesEncoded);
		in.close();
		return fileString;
	}

	public String getCustomerCodeFromUser(User user){ 
		final CustomerConfigUtil ccu = CustomerConfigUtil.getInstance();
		String domain = user.getDomain();
		return ccu.getCustomerCode(domain);
	}


	public String getTemporaryFolderLocation(){
		Random randomizer = new Random();
		String micRiHome =
				System.getProperty(DOMUtil.MIC_SYSTEM_HOME) + File.separator +
				ServletConfigUtil.COMPONENT_RI + File.separator +
				CustomerConfigUtil.getInstance().getCustomerCode(user.getDomain());

		File tempDirectory =
				new File(micRiHome + File.separator + TEMP + File.separator +
						TEMPLATE_DOWNLOAD + File.separator +
						randomizer.nextLong());
		tempDirectory.mkdirs();
		return tempDirectory.getAbsolutePath();
	}
	
	public void deleteTemporaryFolder(String temporaryFolderLocation){
		File temporaryFolder=new File(temporaryFolderLocation);
		if(temporaryFolder.exists()){
			if (temporaryFolder.isDirectory()) {
				for (File subFile : temporaryFolder.listFiles()) {
					subFile.delete();
				}
			}
			temporaryFolder.delete();
		}
	}
	
	public String getMimeTypeForFile(Connection conn, String fileExternsion) throws Exception{
		
		String queryForMimeType="SELECT NVL2((SELECT SMT_MIME_TYPE FROM SHL_MIME_TYPES WHERE lower(SMT_FILE_EXTENSION)=lower(?)),"+
								"(SELECT SMT_MIME_TYPE FROM SHL_MIME_TYPES WHERE lower(SMT_FILE_EXTENSION)=lower(?)),"+ 
								"(SELECT SMT_MIME_TYPE FROM SHL_MIME_TYPES WHERE SMT_FILE_EXTENSION IS NULL AND ROWNUM<2)) mimeType FROM DUAL";
		PreparedStatement psMimeType=null;
		ResultSet rsMimeType=null;
		String mimeType=null;

		try{
			psMimeType=conn.prepareStatement(queryForMimeType);
			psMimeType.setString(1, fileExternsion);
			psMimeType.setString(2, fileExternsion);
			rsMimeType=psMimeType.executeQuery();

			while(rsMimeType.next()){
				mimeType=rsMimeType.getString("mimeType");
				break;	
			}

			return mimeType;

		}catch(Exception exp){
			WebServiceLoggerUtil.logError("QuotePolicyAttachmentServiceImpl", "getMimeTypeForFile", "Exception while fecthing mime type for the file: "+exp.getLocalizedMessage(), new Object[] { exp.getMessage() }, exp);
			throw exp;
		}finally{
			try{
				DBUtil.close(rsMimeType, psMimeType);
			}catch(Exception e){
				WebServiceLoggerUtil.logInfo("QuotePolicyAttachmentServiceImpl", "getMimeTypeForFile", e.getLocalizedMessage(), new Object[] { e.getMessage() });	
			}
		}
	}
	
	private boolean verifyIfFileNameExtensionIsValidString(String fileName){
		//String illegarCharacters="[\\,/:;*?"'`~!$%#<>+\^]/"; from JS fileCabinet.js used from UI
		if(fileName.contains("\\") || 
		fileName.contains(",")|| fileName.contains("/")|| fileName.contains(":")|| fileName.contains(";")|| fileName.contains("*")|| fileName.contains("?")
			|| fileName.contains("\"")|| fileName.contains("'")|| fileName.contains("`")|| fileName.contains("~")|| fileName.contains("!")
			|| fileName.contains("$")|| fileName.contains("%")|| fileName.contains("#")|| fileName.contains("<")|| fileName.contains(">")
			|| fileName.contains("+")|| fileName.contains("\\")|| fileName.contains("^")|| fileName.contains("[")|| fileName.contains("]")){
				return false;
			}	
		return true;
	}
	
	public void validateFileInputs(QuotePolicyAttachmentRequest fileInput) throws Exception{
		boolean gotException=true;
		String errorMessage="";
		
		String fileName=fileInput.getFilename();
		String fileExtension="";
		try{
		fileExtension=fileName.contains(".")?(fileName.substring(fileName.lastIndexOf("."))):"";
		}catch(ArrayIndexOutOfBoundsException exp){
			errorMessage="File extension is not provided. It should be provided in the file name example: Test.docx";
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errorMessage));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			WebServiceLoggerUtil.logInfo("QuotePolicyAttachmentServiceImpl", "addQuotePolicyAttachmentFile", errorMessage, new Object[] { errorMessage });
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}
		fileName=fileName.contains(".")?(fileName.substring(0,fileName.lastIndexOf("."))):fileName;
		
		boolean isAscii = Charset.forName("US-ASCII").newEncoder().canEncode(fileName);
		
		if(!isAscii) {
			errorMessage="File name contains the special/non-ascii characters. Please provide a valid file name";
		}else if(fileName.equalsIgnoreCase("")){
			errorMessage="File name cannot be empty. Please provide a valid file name";
		}else if(fileExtension.equalsIgnoreCase("")){
			errorMessage="File extension is not provided. It should be provided in the file name example: Test.docx";
		}else if(fileName.length()>255){
			errorMessage="File name cannot be more than 255 characters.";
		}else if(fileExtension.length()>32){
			errorMessage="File extension cannot be more than 32 characters.";
		}else if(!verifyIfFileNameExtensionIsValidString(fileName)){
			errorMessage="File name should not contain any special character. It should be alpha-numeric.";
		}else if(!verifyIfFileNameExtensionIsValidString(fileExtension.substring(1))){
			errorMessage="File extension should not contain any special character. It should be alpha-numeric.";
		}else if(fileInput.getFile().equalsIgnoreCase("")){
			errorMessage="File cannot be empty. Please provide a valid file.";
		}else if(fileInput.getFileDescription()!=null && fileInput.getFileDescription().length()>4000){
			errorMessage="File description cannot more than 4000 characters";
		}else{
			gotException=false;
		}
		
		if(gotException){
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errorMessage));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			WebServiceLoggerUtil.logInfo("QuotePolicyAttachmentServiceImpl", "addQuotePolicyAttachmentFile", errorMessage, new Object[] { errorMessage });
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}

	}

	public boolean checkSecurityFeatureInFileOperations(Connection conn){
		String securityCheckEnabled=APIOperationUtil.getProductGlobalOptionValue(conn, APIConstant.FILES_SECURITY_CHECK_GLOBAL_OPTION, true, entityReference);
		return "Y".equalsIgnoreCase(securityCheckEnabled)?true:false;

	}
}

