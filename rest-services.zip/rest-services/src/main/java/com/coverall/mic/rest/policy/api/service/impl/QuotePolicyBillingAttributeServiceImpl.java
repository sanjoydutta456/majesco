package com.coverall.mic.rest.policy.api.service.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import org.apache.commons.io.IOUtils;
import org.codehaus.jackson.map.ObjectMapper;

import com.coverall.billing.soa.BillingRestServiceIntegration;
import com.coverall.gwt.common.client.TimingSimple;
import com.coverall.mt.util.APIAuditTrailLog;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.factory.impl.PolicyAPIFactoryServiceImpl;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.QuotePolicyBillingAttributeService;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.BillingInstallment;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyBillingAttribute;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyBillingAttributeSuccessResponse;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mic.rest.policy.api.service.util.WorkflowUtil;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.HTTPConstants;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;

import oracle.jdbc.OracleTypes;

public class QuotePolicyBillingAttributeServiceImpl implements
		QuotePolicyBillingAttributeService {
	
	String entityReference;
	String entityType;
	HttpServletRequest request;
	User user;
		
	private final String BILLING_ACCOUNT="billingAccount";
	private final String BILLING_TYPE="billingType";
	private final String PAYER_DETAILS="payorDetails";
	private final String PAYER_ID="payorID";
	ArrayList<String> PayerDetails = new ArrayList<String>();
//	private static String displayBillTypeValue=null;
	
//	String queryForFetchingValueOfBillType="SELECT decode(count(wwp_value),0,'N','Y')  displayBillType from ws_webservices outer , ws_webserviceparameters WHERE wws_wsname = 'MIC - INTERNAL - WS - BILLING - INTEGRATION'"+
//										   " AND wwp_wsid  =  wws_id AND  lower(wwp_name ) = 'billingsysurl' AND EXISTS (SELECT 1   from  ws_webserviceparameters WHERE wws_wsname = 'MIC - INTERNAL - WS - BILLING - INTEGRATION'"+
//										   " AND wwp_wsid  =  outer.wws_id AND  lower(wwp_name ) = 'callwebservice' AND nvl(lower(wwp_value),'false' ) = 'true')";
	
	String queryForFetchingPaymentPlanInfo="SELECT NVL(MPF_PAYOR_NAME, MPF_PAYOR_NAME_2) payer,MPF_BILLING_EFFECTIVE_DATE billingEffectiveDate,(SELECT COLLECTOR_METHOD"+
										   " FROM IEL_COLLECTOR_METHOD WHERE IEL_LINK_ID=MPF_COLLECTION_METHOD_ID AND customer_code=? AND rownum<2) paymentMethod,(SELECT descr FROM VALID_PAY_OPTIONS"+
										   " WHERE VALID_PAY_OPTION_ID=MPF_VALID_PAY_OPTION_ID AND rownum<2) planName,MPF_ACCOUNT_NUMBER accountNumber,"+
										   "(SELECT BILL_TYPE FROM IEL_MIC_BILL_TYPES WHERE BILL_TYPE_CODE=MPF_BILL_TYPE AND customer_code=? AND product_code=(SELECT PRODUCT_CODE"+ 
										   " FROM ev_mis_quote_policies WHERE entity_reference=? AND rownum<2) AND rownum<2) billType,MPF_BILL_TYPE"+	
										   " FROM MIS_POLICY_FINANCIALS WHERE MPF_POLICY_REFERENCE=? AND rownum<2";		
	
	String queryForFecthingInstallments="SELECT MPI_DISPLAY_INSTALLMENT_ID installmentId, MPI_AMOUNT premiumDue,to_char(MPI_DUE_DATE, 'yyyy-mm-dd') dueDate,"+
										"to_char(MPI_SEND_DATE, 'yyyy-mm-dd') sendDate, MPI_SURCHARGE_ASSESS_AMOUNT taxesFeesSurcharge,MPI_INSTALLMENT_CHARGE installmentCharge,"+
										"(MPI_AMOUNT + MPI_SURCHARGE_ASSESS_AMOUNT + MPI_INSTALLMENT_CHARGE) totalAmount FROM MIS_POLICY_INSTALLMENTS"+ 
										" WHERE MPI_POLICY_REFERENCE=? ORDER BY MPI_DISPLAY_INSTALLMENT_ID";
	
	public QuotePolicyBillingAttributeServiceImpl(String entityReference, String entityType,HttpServletRequest request) {
		super();
		this.entityReference = entityReference;
		this.entityType = entityType;
		this.request=request;
		user=user.getUser(request);
	}

	@Override
	public Object getBillingAttributeList() throws Exception {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		TimingSimple simpleTimer = new TimingSimple();
		simpleTimer.start();
		QuotePolicyBillingAttribute billingAttribute=new QuotePolicyBillingAttribute();
		long sourceSystemRequestNo=System.currentTimeMillis();
		Connection conn=null;
	
		try{
			conn = requestContext.getConnection();
			if(!WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)){
				String errMsg = entityType + " " + entityReference + " was not found. Please check input parameters.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("QuotePolicyBillingAttributeServiceImpl", "getBillingAttributeList", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}

			if(!WorkflowUtil.isWorkflowStageReached(conn, entityType, APIConstant.BILLINFO_TASK,entityReference)){
				String errMsg = "Billing execution stage is yet not reached for the entity "+entityReference+". Please check the status.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("QuotePolicyBillingAttributeServiceImpl", "getBillingAttributeList", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
			billingAttribute=getListOfBillingInformation(conn,sourceSystemRequestNo);
		}catch (APIException e) {
			WebServiceLoggerUtil.logError("QuotePolicyBillingAttributeServiceImpl", "getBillingAttributeList", "Exception occurred while fetching Billing attributes:"+e.getLocalizedMessage(), new Object[] { e.getErrorMessage() }, e);
			throw e;
		}catch (Exception e) {
			WebServiceLoggerUtil.logError("QuotePolicyBillingAttributeServiceImpl", "getBillingAttributeList", "Exception occurred while fetching Billing attributes:", new Object[] { e.getLocalizedMessage() }, e);
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		}finally{
			simpleTimer.stop();
			String timeString="Execution time for getUWRulesList for "+entityReference+" by "+user.getUserId()+" is "+simpleTimer.getDurationAsString();
			WebServiceLoggerUtil.logInfo("QuotePolicyUWRulesServiceImpl", "getUWRulesList", timeString, new Object[] { timeString });
		}
		
		return billingAttribute;
	}

	@Override
	public Object addBillingAttribute() throws Exception {
		return updateBillingAttribute();
	}

	@Override
	public Object updateBillingAttribute() throws Exception {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		TimingSimple simpleTimer = new TimingSimple();
		simpleTimer.start();
		QuotePolicyBillingAttributeSuccessResponse billingResponse=new QuotePolicyBillingAttributeSuccessResponse();
		QuotePolicyBillingAttribute billingAttributeRequest;
		long sourceSystemRequestNo=System.currentTimeMillis();
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		ObjectMapper mapper;
		String inputJson;
		
		
		try{
			mapper=new ObjectMapper();
			inputJson=APIOperationUtil.fetchRequestBody(request);
			billingAttributeRequest=mapper.readValue(inputJson, QuotePolicyBillingAttribute.class);
		}catch(Exception exp){
			String errMsg = "Invalid JSON. Error while decoding input JSON file";
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			WebServiceLoggerUtil.logInfo("QuotePolicyBillingAttributeServiceImpl", "updateBillingAttribute", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,exp);
		}

		try{
			conn = requestContext.getConnection();
			
			//Auditing logic
			APIAuditTrailLog auditTrailLog=requestContext.getAuditTrailLog();
			APIOperationUtil.populateAPIAuditLog(auditTrailLog, billingAttributeRequest.getSourceSystemCode(), billingAttributeRequest.getSourceSystemUserId(), billingAttributeRequest.getSourceSystemRequestNo(), RESOURCE_TYPE, PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
			
			
			if(!WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)){
				String errMsg = entityType + " " + entityReference + " was not found. Please check input parameters.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("QuotePolicyBillingAttributeServiceImpl", "updateBillingAttribute", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
			
			if(!WorkflowUtil.isWorkflowStageReached(conn, entityType, APIConstant.BILLINFO_TASK,entityReference)){
				String errMsg = "Billing execution stage is yet not reached for the entity "+entityReference+". Please check the status.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("QuotePolicyBillingAttributeServiceImpl", "updateBillingAttribute", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
			
			if(!WorkflowUtil.checkIfBillingWorkflowIsApplicable(user,conn,entityReference,entityType)){
				String errMsg = "Billing Task is not applicable for " + entityReference + ". Please check status of the "+entityType;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("QuotePolicyBillingAttributeServiceImpl", "updateBillingAttribute", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
			
			//POLT-13228 Insert a record with default values in MIS_POLICY_FINANCIALS to simulate UI behavior
			insertDefaultsForBilling(entityReference);
			
			
						
			//Fetching saved Billing Information
			QuotePolicyBillingAttribute savedBillingAttributesInSystem=getListOfBillingInformation(conn,sourceSystemRequestNo);
			
			boolean modifyBillingEffectiveDate=false;
			
			boolean modifyBillingType=false;
			if(billingAttributeRequest.getBillingEffectiveDate()!=null && !"".equalsIgnoreCase(billingAttributeRequest.getBillingEffectiveDate())){
				if(!billingAttributeRequest.getBillingEffectiveDate().matches("^([0-9][0-9])?[0-9][0-9]-(0[0-9]||1[0-2])-([0-2][0-9]||3[0-1])$")){
					String errMsg = "Billing Effective date is not in correct format. Please pass date in YYYY-MM-DD format.";
					List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
					String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
					WebServiceLoggerUtil.logInfo("QuotePolicyBillingAttributeServiceImpl", "updateBillingAttribute", errMsg, new Object[] { errMsg });
					throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
				}else{
					if(!WorkflowUtil.checkIfUserHasTheRequiredPermission(requestContext.getUser(), APIConstant.MODIFY_BILLING_EFFECTIVE_DATE_PERMISSION)){
						String errMsg = "User don't have permission to modify Billing effective date. Please remove it from request.";
						List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
						String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
						WebServiceLoggerUtil.logInfo("QuotePolicyBillingAttributeServiceImpl", "updateBillingAttribute", errMsg, new Object[] { errMsg });
						throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
					}else{
						modifyBillingEffectiveDate=true;
						SimpleDateFormat inputFormat=new SimpleDateFormat("yyyy-MM-dd");
						Date inputDate=inputFormat.parse(billingAttributeRequest.getBillingEffectiveDate());
						billingAttributeRequest.setBillingEffectiveDate(new SimpleDateFormat("MM/dd/yyyy").format(inputDate));
					}
				}
			}else if("".equalsIgnoreCase(billingAttributeRequest.getBillingEffectiveDate())){
				modifyBillingEffectiveDate=true;
			}
			
			//Verifying provided payPlanId
			String payPlanId=null;
			if(billingAttributeRequest.getPayPlanName()!=null){
				payPlanId=verifyAndGetPaymentPlanID(conn,billingAttributeRequest.getPayPlanName());
				if(payPlanId==null){
					String errMsg = "Invalid value of Pay Plan Name. There is no such pay plan in system: " + billingAttributeRequest.getPayPlanName();
					List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
					String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
					WebServiceLoggerUtil.logInfo("QuotePolicyBillingAttributeServiceImpl", "updateBillingAttribute", errMsg, new Object[] { errMsg });
					throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
				}
			}else{
				payPlanId=verifyAndGetPaymentPlanID(conn,savedBillingAttributesInSystem.getPayPlanName());
			}
			
			//Verifying provided paymentMethod
			String collectionMethodId=null;
			if(billingAttributeRequest.getPaymentMethod()!=null){
				collectionMethodId=verifyAndGetBillingCollectionMethodID(conn,billingAttributeRequest.getPaymentMethod());
				if(collectionMethodId==null){
					String errMsg = "Invalid value of Billing Collection Method. There is no such billing collection method in system: " + billingAttributeRequest.getPaymentMethod();
					List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
					String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
					WebServiceLoggerUtil.logInfo("QuotePolicyBillingAttributeServiceImpl", "updateBillingAttribute", errMsg, new Object[] { errMsg });
					throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);	
				}
			}else{
				collectionMethodId=verifyAndGetBillingCollectionMethodID(conn,savedBillingAttributesInSystem.getPaymentMethod());
			}
			/*tpt added //Verify provided Billtype*/
			String billTypelatest = null;
			String billTypeFlaglatest= null;
			if(billingAttributeRequest.getBillType()!=null){
				if(!billingAttributeRequest.getBillType().equalsIgnoreCase(savedBillingAttributesInSystem.getBillType())) {
					billTypelatest =verifyAndGetBillType(conn,billingAttributeRequest.getBillType());
					if(billTypelatest==null){
						String errMsg = "Invalid value of Bill Type Name. There is no such bill type in system: " + billingAttributeRequest.getBillType();
						List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
						String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
						WebServiceLoggerUtil.logInfo("QuotePolicyBillingAttributeServiceImpl", "updateBillingAttribute", errMsg, new Object[] { errMsg });
						throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
					}else {
						modifyBillingType = true;
					}
				}
			}else{
				billTypelatest =verifyAndGetBillType(conn,savedBillingAttributesInSystem.getBillType());
				
			}
			
			billTypeFlaglatest=verifyAndGetBillTypeFlag(conn,billingAttributeRequest.getBillType()==null?savedBillingAttributesInSystem.getBillType():billingAttributeRequest.getBillType());
			
			
			
			//Verify provided account number
			String accountNumber=billingAttributeRequest.getAccount()==null?savedBillingAttributesInSystem.getAccount():billingAttributeRequest.getAccount();
			if(billingAttributeRequest.getAccount()!=null && !"".equalsIgnoreCase(billingAttributeRequest.getAccount())){
				// if("I".equalsIgnoreCase(savedBillingAttributesInSystem.getBillTypeFlag())){ //commented tpt for POLT-11630
				if("I".equalsIgnoreCase(billTypeFlaglatest)){	
					if(!verifyAccountNumberInput(conn, billingAttributeRequest.getAccount())){
						String errMsg = "Invalid value of account. There is no such account in system: " + billingAttributeRequest.getAccount();
						List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
						String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
						WebServiceLoggerUtil.logInfo("QuotePolicyBillingAttributeServiceImpl", "updateBillingAttribute", errMsg, new Object[] { errMsg });
						throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);	
					}
				}else{
					String errMsg = "Account cannot be updated for this billing type :"+ entityReference+". Please remove it from request.";
					List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
					String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
					WebServiceLoggerUtil.logInfo("QuotePolicyBillingAttributeServiceImpl", "updateBillingAttribute", errMsg, new Object[] { errMsg });
					throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);	
					
				}
			}else if(("".equalsIgnoreCase(billingAttributeRequest.getAccount()) || billingAttributeRequest.getAccount()==null) && billTypeFlaglatest.equalsIgnoreCase("I")){ // Added by tpt for POLT-11630
				String errMsg = "Account is mandatory for billing type Account for :"+ entityReference+". Please provide it from request.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("QuotePolicyBillingAttributeServiceImpl", "updateBillingAttribute", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);	
			}else {
				accountNumber=null;
			}
			
			
			// Verify Payeer to persist
			String payerdetails="";
			String payerid="";
			String payType = "";
			boolean modifyPayer=false;
			System.out.println("checking value for paye checkr"+billingAttributeRequest.getPayer() );
			if(billingAttributeRequest.getPayer()!=null){
				System.out.println("going for payer");
				// if(!billingAttributeRequest.getPayer().equalsIgnoreCase(savedBillingAttributesInSystem.getPayer())) {					
				PayerDetails =	verifyValidPayer(conn,entityReference,billTypeFlaglatest,billingAttributeRequest.getPayer(), accountNumber==null?savedBillingAttributesInSystem.getAccount():accountNumber);
				System.out.println("size"+PayerDetails.size() +" payerdetail"+PayerDetails);
			
				if (PayerDetails.size() ==5) {
					payerdetails = PayerDetails.get(4);		
					payerid =  PayerDetails.get(2);	
					if(PayerDetails.get(0).equalsIgnoreCase("true")){
						modifyPayer = true;		
					}else {
						modifyPayer = false;
						String errMsg = "Invalid value of payer. There is no such payer in this policy/quote: " + billingAttributeRequest.getPayer();
						List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
						String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
						WebServiceLoggerUtil.logInfo("QuotePolicyBillingAttributeServiceImpl", "updateBillingAttribute", errMsg, new Object[] { errMsg });
						throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);								
					}	
				}
				// }
			}else {
				System.out.println("else payer not pass");
				PayerDetails =	verifyValidPayer(conn,entityReference,billTypeFlaglatest,savedBillingAttributesInSystem.getPayer(), accountNumber==null?savedBillingAttributesInSystem.getAccount():accountNumber);
				if (PayerDetails.size() ==5) {
					payerdetails = PayerDetails.get(4);	
					payerid =  PayerDetails.get(2);	
					payType = PayerDetails.get(1);
				}
			}
			
			//Parameter for the Billing service
			Map<String,String> params=new HashMap<String, String>();
			
			params.put(HTTPConstants.PARAM_ENTITY_TYPE,entityType);
			params.put(HTTPConstants.PARAM_ENTITY_REFERENCE,entityReference);
			params.put(HTTPConstants.PARAM_PAY_PLAN,payPlanId);
			params.put(HTTPConstants.PARAM_BILL_COLLECTION_PLAN,collectionMethodId);
			params.put(BILLING_ACCOUNT,accountNumber);
			params.put(BILLING_TYPE,billTypeFlaglatest);
			params.put(PAYER_DETAILS,payerdetails);
			params.put(PAYER_ID,payerid);
			params.put("PAYER_TYPE",payType);
			
			BillingRestServiceIntegration integration=new BillingRestServiceIntegration();
			
			//Change Pay Plan
			integration.modifyPayPlan(user, params);
			//Adding specifics
			String auditSpecificString=HTTPConstants.PARAM_PAY_PLAN+":"+payPlanId+", "+HTTPConstants.PARAM_BILL_COLLECTION_PLAN+":"+collectionMethodId+", "+
									   BILLING_ACCOUNT+":"+accountNumber;
			
			if(modifyBillingEffectiveDate){
				params=new HashMap<String, String>();
				params.put(HTTPConstants.PARAM_ENTITY_TYPE,entityType);
				params.put(HTTPConstants.PARAM_ENTITY_REFERENCE,entityReference);
				params.put(HTTPConstants.PARAM_PAY_PLAN,payPlanId);
				params.put(HTTPConstants.PARAM_BILL_COLLECTION_PLAN,collectionMethodId);
				params.put(BILLING_ACCOUNT,accountNumber);
				params.put(HTTPConstants.PARAM_BILLING_EFF_DATE,billingAttributeRequest.getBillingEffectiveDate());
				
				auditSpecificString+=", "+HTTPConstants.PARAM_BILLING_EFF_DATE+":"+billingAttributeRequest.getBillingEffectiveDate();
				
				integration.modifyBillingEffectiveDate(user, params);
			}
			
		
		if(modifyBillingType){
			params=new HashMap<String, String>();
			params.put(HTTPConstants.PARAM_ENTITY_TYPE,entityType);
			params.put(HTTPConstants.PARAM_ENTITY_REFERENCE,entityReference);
			params.put(HTTPConstants.PARAM_PAY_PLAN,payPlanId);
			params.put(HTTPConstants.PARAM_BILL_COLLECTION_PLAN,collectionMethodId);
			params.put(BILLING_ACCOUNT,accountNumber);
			params.put(BILLING_TYPE,billTypeFlaglatest);//billingAttributeRequest.getBillType());
			params.put(HTTPConstants.PROPERTY_PARAM_BILL_TYPE,billingAttributeRequest.getBillType());
			
			auditSpecificString+=", "+HTTPConstants.PROPERTY_PARAM_BILL_TYPE+":"+billingAttributeRequest.getBillType();
			
			integration.modifyBillingType(user, params);
		}
		
			if(modifyPayer){
				params=new HashMap<String, String>();
				params.put(HTTPConstants.PARAM_ENTITY_TYPE,entityType);
				params.put(HTTPConstants.PARAM_ENTITY_REFERENCE,entityReference);
				params.put(HTTPConstants.PARAM_PAY_PLAN,payPlanId);
				params.put(HTTPConstants.PARAM_BILL_COLLECTION_PLAN,collectionMethodId);
				params.put("PAYER_TYPE",PayerDetails.get(1));
				params.put(BILLING_ACCOUNT,accountNumber);
				params.put(BILLING_TYPE,billTypeFlaglatest);
				params.put(PAYER_DETAILS,payerdetails);
				params.put(PAYER_ID,payerid);
				params.put(HTTPConstants.PROPERTY_PARAM_PAYOR_DETAILS,payerdetails);
				
				integration.modifyPayer(user, params);
			}
			/* payer */
			
			APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, entityReference, payPlanId,auditSpecificString);
			//Fetching the value of activity ID needed for marking task complete
			String activityId=WorkflowUtil.getActivityIdForTheTask(conn,APIConstant.BILLINFO_TASK,entityReference,entityType)+"";
			
			params.put(HTTPConstants.PARAM_ACTIVITY_ID, activityId);
			//Completing the transaction
			integration.completePayPlanModification(user, params);
			
			billingResponse.setCode("Success");
			billingResponse.setDescription("Billing Information updates Successfully.");

			
			}catch (APIException e) {
				WebServiceLoggerUtil.logError("QuotePolicyBillingAttributeServiceImpl", "updateBillingAttribute", "Exception occurred while updating Billing information:"+e.getLocalizedMessage(), new Object[] { e.getErrorMessage() }, e);
				throw e;
			}catch (Exception e) {
				WebServiceLoggerUtil.logError("QuotePolicyBillingAttributeServiceImpl", "updateBillingAttribute", "Exception occurred while updating Billing information:", new Object[] { e.getLocalizedMessage() }, e);
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));
				String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
			}finally{
				try {
					DBUtil.close(rs, ps);
				} catch (SQLException e) {
					WebServiceLoggerUtil.logInfo("QuotePolicyUWRulesServiceImpl", "getUWRulesList", e.getLocalizedMessage(), new Object[] { e.getCause() });
				}
				simpleTimer.stop();
				String timeString="Execution time for updateBillingAttribute for "+entityReference+" by "+user.getUserId()+" is "+simpleTimer.getDurationAsString();
				WebServiceLoggerUtil.logInfo("QuotePolicyUWRulesServiceImpl", "getUWRulesList", timeString, new Object[] { timeString });
			}
		
		return billingResponse;
	}
	
	private List<Message> getErrorMessageList(List<String> strMessages)	{
		if(strMessages == null)	{
			return null;
		}
		List<Message> errorMessageList = new ArrayList<Message>(strMessages.size());
		for(String aMsg : strMessages)	{
			Message message = new Message();
			message.setMoreinfo(aMsg);
			errorMessageList.add(message);
		}
		return errorMessageList;
	}
	
	private String verifyAndGetPaymentPlanID(Connection conn,String payPlan) throws SQLException{
		String payPlanId=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String queryForPayPlanVerification="SELECT VALID_PAY_OPTION_ID payPlanID FROM VALID_PAY_OPTIONS WHERE upper(DESCR)=upper(?) and rownum<2";
		try {
			ps=conn.prepareStatement(queryForPayPlanVerification);
			ps.setString(1, payPlan);

			rs=ps.executeQuery();
			while(rs.next()){
				payPlanId=rs.getString("payPlanID");
			}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			WebServiceLoggerUtil.logError("QuotePolicyBillingAttributeServiceImpl", "verifyIFPaymentPlanExists", "Failed:", new Object[] { e.getMessage() }, e);
			throw e;
		}finally{
			try{
				DBUtil.close(rs, ps);
			}catch(Exception e){
				WebServiceLoggerUtil.logInfo("QuotePolicyBillingAttributeServiceImpl", "verifyIFPaymentPlanExists", e.getLocalizedMessage(), new Object[] { e.getMessage() });	
			}
		}

		return payPlanId;

	}
	
	private String verifyAndGetBillType(Connection conn,String billTypeRequest) throws SQLException{
		String billType=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String queryForBillTypeVerification="select distinct Bill_Type  from IEL_MIC_BILL_TYPES WHERE upper(BILL_TYPE)=upper(?) and rownum<2 ";
		try {
			ps=conn.prepareStatement(queryForBillTypeVerification);
			ps.setString(1, billTypeRequest);

			rs=ps.executeQuery();
			while(rs.next()){
				billType=rs.getString("Bill_Type");
			}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			WebServiceLoggerUtil.logError("QuotePolicyBillingAttributeServiceImpl", "verifyAndGetBillType", "Failed:", new Object[] { e.getMessage() }, e);
			throw e;
		}finally{
			try{
				DBUtil.close(rs, ps);
			}catch(Exception e){
				WebServiceLoggerUtil.logInfo("QuotePolicyBillingAttributeServiceImpl", "verifyAndGetBillType", e.getLocalizedMessage(), new Object[] { e.getMessage() });	
			}
		}

		return billType;

	}
	
	protected String verifyAndGetBillTypeFlag(Connection conn,String billTypeRequest) throws SQLException{
		String billTypecode=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String queryForBillTypeCodeVerification="select distinct Bill_Type_Code  from IEL_MIC_BILL_TYPES WHERE upper(BILL_TYPE)=upper(?) and rownum<2 ";
		try {
			ps=conn.prepareStatement(queryForBillTypeCodeVerification);
			ps.setString(1, billTypeRequest);

			rs=ps.executeQuery();
			while(rs.next()){
				billTypecode=rs.getString("Bill_Type_Code");
			}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			WebServiceLoggerUtil.logError("QuotePolicyBillingAttributeServiceImpl", "verifyAndGetBillTypeFlag", "Failed:", new Object[] { e.getMessage() }, e);
			throw e;
		}finally{
			try{
				DBUtil.close(rs, ps);
			}catch(Exception e){
				WebServiceLoggerUtil.logInfo("QuotePolicyBillingAttributeServiceImpl", "verifyAndGetBillTypeFlag", e.getLocalizedMessage(), new Object[] { e.getMessage() });	
			}
		}

		return billTypecode;

	}
	
	
	protected String verifyAndGetBillingCollectionMethodID(Connection conn,String collectionMethod) throws SQLException{
		String collectionMethodId=null;
		
		PreparedStatement ps=null;
		ResultSet rs=null;
		String queryForPayPlanVerification="select IEL_LINK_ID collectionMethodId from IEL_COLLECTOR_METHOD where UPPER(collector_method) =UPPER(?) and customer_code =  UPPER(?) AND rownum<2";
		try {
			ps=conn.prepareStatement(queryForPayPlanVerification);
			ps.setString(1, collectionMethod);
			ps.setString(2, getCustomerCodeFromUser(user));
			rs=ps.executeQuery();
			while(rs.next()){
				collectionMethodId=rs.getString("collectionMethodId");
			}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			WebServiceLoggerUtil.logError("QuotePolicyBillingAttributeServiceImpl", "getBillingCollectionMethodId", "Failed:", new Object[] { e.getMessage() }, e);
			throw e;
		}finally{
			try{
				DBUtil.close(rs, ps);
			}catch(Exception e){
				WebServiceLoggerUtil.logInfo("QuotePolicyBillingAttributeServiceImpl", "getBillingCollectionMethodId", e.getLocalizedMessage(), new Object[] { e.getMessage() });	
			}
		}
		return collectionMethodId;
		
	}
	
	protected boolean verifyAccountNumberInput(Connection conn,String accountNumber) throws SQLException{
		String payPlanId=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		boolean validAccountNumber=false;
		// String queryForFetchingValidAccountNumber="SELECT decode(count(YAA_ACC_NO),0,'N','Y') validAccountNumber FROM vw_mis_insureds a,BIL_BILLING_ACCOUNT b WHERE 1=1 AND entity_reference = ?"+
		//		  " AND (a.id = YAA_INSURED_ID OR a.MASTER_RECORD_GID = YAA_INSURED_ID) AND YAA_ACC_NO=?";
				  
		  String queryForFetchingValidAccountNumber="SELECT decode(count(YAA_ACC_NO),0,'N','Y') validAccountNumber FROM vw_mis_insureds a,BIL_BILLING_ACCOUNT b WHERE 1=1 AND entity_reference = ?"+
				  " AND YAA_ACC_NO=? and( (FK_COLUMN_NAME = 'POLICY_INSURED' and B.YAA_CUSTOMER_CODE = a.MASTER_CUSTOMER_GID) " + 
				  "        OR (a.id = YAA_INSURED_ID or a.MASTER_RECORD_GID = YAA_INSURED_ID) ) ";
		try {
			ps=conn.prepareStatement(queryForFetchingValidAccountNumber);
			ps.setString(1, entityReference);
			ps.setString(2, accountNumber);

			rs=ps.executeQuery();
			
			while(rs.next()){
				validAccountNumber="Y".equalsIgnoreCase(rs.getString("validAccountNumber"))?true:false;
			}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			WebServiceLoggerUtil.logError("QuotePolicyBillingAttributeServiceImpl", "verifyAccountNumberInput", "Failed:", new Object[] { e.getMessage() }, e);
			throw e;
		}finally{
			try{
				DBUtil.close(rs, ps);
			}catch(Exception e){
				WebServiceLoggerUtil.logInfo("QuotePolicyBillingAttributeServiceImpl", "verifyAccountNumberInput", e.getLocalizedMessage(), new Object[] { e.getMessage() });	
			}
		}

		return validAccountNumber;

	}
	
	protected QuotePolicyBillingAttribute getListOfBillingInformation(Connection conn,long sourceSystemRequestNo) throws Exception{

		QuotePolicyBillingAttribute billingAttribute=new QuotePolicyBillingAttribute();
		List<BillingInstallment> installmentList=new ArrayList<BillingInstallment>();
		billingAttribute.setInstallments(installmentList);

		PreparedStatement ps=null;
		ResultSet rs=null;
		PreparedStatement psInstallment=null;
		ResultSet rsInstallment=null;
		PreparedStatement psbillingTypeFlag=null;
		ResultSet rsbillingTypeFlag=null;

		try{
			ps=conn.prepareStatement(queryForFetchingPaymentPlanInfo);
			ps.setString(1, getCustomerCodeFromUser(user));
			ps.setString(2, getCustomerCodeFromUser(user));
			ps.setString(3, entityReference);
			ps.setString(4, entityReference);

			rs=ps.executeQuery();

			billingAttribute.setSourceSystemUserId(user.getUserId());
			billingAttribute.setSourceSystemCode(SOURCE_SYSTEM_CODE);
			billingAttribute.setSourceSystemRequestNo(sourceSystemRequestNo);

			while(rs.next()){

				billingAttribute.setPayPlanName(rs.getString("planName"));
				billingAttribute.setPayer(rs.getString("payer"));
				billingAttribute.setPaymentMethod(rs.getString("paymentMethod"));
				billingAttribute.setBillingEffectiveDate(rs.getString("billingEffectiveDate"));
				billingAttribute.setAccount(rs.getString("accountNumber"));
				billingAttribute.setBillType(rs.getString("billType"));
				billingAttribute.setBillTypeFlag(rs.getString("MPF_BILL_TYPE"));

				psInstallment=conn.prepareStatement(queryForFecthingInstallments);
				psInstallment.setString(1, entityReference);

				rsInstallment=psInstallment.executeQuery();

				while(rsInstallment.next()){
					BillingInstallment installment=new BillingInstallment();
					installment.setDueDate(rsInstallment.getString("dueDate"));
					installment.setInstallmentId(rsInstallment.getString("installmentId"));
					installment.setInstallmentCharge(rsInstallment.getDouble("installmentCharge"));
					installment.setPremiumDue(rsInstallment.getDouble("premiumDue"));
					installment.setTaxesFeesSurcharge(rsInstallment.getDouble("taxesFeesSurcharge"));
					installment.setTotalAmount(rsInstallment.getDouble("totalAmount"));

					installmentList.add(installment);
				}
			}
			//Logic for displaying bill type field
//			if(displayBillTypeValue==null){
//				psbillingTypeFlag=conn.prepareStatement(queryForFetchingValueOfBillType);
//				rsbillingTypeFlag=psbillingTypeFlag.executeQuery();
//				while (rsbillingTypeFlag.next()) {
//					displayBillTypeValue = rsbillingTypeFlag.getString("displayBillType");
//
//				}
//			}
//			if("N".equalsIgnoreCase(displayBillTypeValue)){
//				billingAttribute.setBillType(null);
//			}
		}catch (Exception e) {
			WebServiceLoggerUtil.logError("QuotePolicyBillingAttributeServiceImpl", "getListOfBillingInformation", "Exception occurred while fetching Billing attributes:"+e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw e;
		}finally{
			try{
				DBUtil.close(rsbillingTypeFlag, psbillingTypeFlag);
			}catch(Exception e){
				//do nothing
			}

			try{
				DBUtil.close(rsInstallment, psInstallment);
			}catch(Exception e){
				//do nothing
			}

			try{	
				DBUtil.close(rs, ps);
			}catch(Exception e){
				//do nothing
			}
	}
	
	return billingAttribute;
}
	

	
	protected String getCustomerCodeFromUser(User user){ 
		final CustomerConfigUtil ccu = CustomerConfigUtil.getInstance();
		String domain = user.getDomain();
		return ccu.getCustomerCode(domain);
	}
	
	protected ArrayList<String> verifyValidPayer(Connection conn,String entityreference, String Billtype, String payer, String account_Number) throws SQLException{
		
		PreparedStatement ps=null;
		ResultSet rs=null;
		String vaid_payer = "false";
		ArrayList<String> PayerDetails = new ArrayList<String>();
	  	String payorType = "";
    	String payorID = "";
    	String payername="";
    	String payerIdDetails="";
		System.out.println(entityreference+"came in validpayer "+Billtype+ "and payer id is "+payer);
	    CallableStatement cs = null;
		
	    if (Billtype.equalsIgnoreCase("A") || Billtype.equalsIgnoreCase("W")) {
	    	System.out.println("came in agent/ wholsale bill");
			String queryForPayPlanVerification="SELECT SUBSTR(SPR_PRODUCER_NAME, 1, 60) SPR_PRODUCER_NAME , SPR_PRODUCER_ID " + 
					"FROM SHL_PRODUCERS " + 
					"WHERE	SPR_PRODUCER_CODE IN (SELECT MPO_AGENT_ID FROM MIS_POLICIES	WHERE MPO_POLICY_REFERENCE = ? )";
			try {
				ps=conn.prepareStatement(queryForPayPlanVerification);
				ps.setString(1, entityreference);
				rs=ps.executeQuery();
				while(rs.next()){
					payername = rs.getString("SPR_PRODUCER_NAME");
					payorID = rs.getString("SPR_PRODUCER_ID");
				}
				
				
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				WebServiceLoggerUtil.logError("QuotePolicyBillingAttributeServiceImpl", "verifyValidPayer", "Failed:", new Object[] { e.getMessage() }, e);
				throw e;
			}finally{
				if(payername.equalsIgnoreCase(payer)) {
					vaid_payer = "true";
				}else {
					vaid_payer = "false";
				}
				payorType = "Agent";
				payerIdDetails = payorType+ "_"+payorID;				
				PayerDetails.add(vaid_payer);
				PayerDetails.add(payorType);
				PayerDetails.add(payorID);
				PayerDetails.add(payername);
				PayerDetails.add(payerIdDetails);
				try{
					DBUtil.close(null, ps);
				}catch(Exception e){
					WebServiceLoggerUtil.logInfo("QuotePolicyBillingAttributeServiceImpl", "verifyValidPayer", e.getLocalizedMessage(), new Object[] { e.getMessage() });	
				}
			}
			
		}else if (Billtype.equalsIgnoreCase("I")){
			System.out.println("came in Account bill"+ account_Number);				
			
			// Fetch Bill Type from IEL_MIC_BILL_TYPES table if it is not present in params map.
			if (account_Number != null ) {
				PreparedStatement stmt = null;
				rs = null;
				
				try {
					conn = ConnectionPool.getConnection(user);
					stmt = conn.prepareStatement("select YAA_INSURED_ID, YAA_BUSINESS_NAME, YAA_PAYER_TYPE  from BIL_BILLING_ACCOUNT where YAA_ACC_NO = ?");
					stmt.setString(1, account_Number);
					rs = stmt.executeQuery();
					if(rs.next()) {
						
						System.out.println("InsuredID  --- > "+rs.getString("YAA_INSURED_ID")+" Businessname "+rs.getString("YAA_BUSINESS_NAME")+" payertpe "+rs.getString("YAA_PAYER_TYPE"));
						if(rs.getString("YAA_BUSINESS_NAME").equalsIgnoreCase(payer)) {
							payername = rs.getString("YAA_BUSINESS_NAME");
							payorID = rs.getString("YAA_INSURED_ID");		
							payorType = rs.getString("YAA_PAYER_TYPE");		
							vaid_payer = "true";
						}else {
							vaid_payer = "false";
						}
						
					}
					
					payerIdDetails= "Account_"+payorID;
					if(payorType==null) {
						payorType= "Account";
					}
									
				} catch(Exception ex) {
	            	WebServiceLoggerUtil.logError("QuotePolicyBillingAttributeServiceImpl", "verifyValidPayer account billtype", "Failed:", new Object[] { ex.getMessage() }, ex);

				} finally {
					PayerDetails.add(vaid_payer);
					PayerDetails.add(payorType);
					PayerDetails.add(payorID);
					PayerDetails.add(payername.trim());
					PayerDetails.add(payerIdDetails);
					
					try {
						// DBUtil.close(rs, stmt, conn);
					} catch(Exception ex) {}
				}
									
			}
			
			
			
		}else {
			rs = null;
			System.out.println("came in Direct");
			  try {        	

		        	cs = conn.prepareCall("{? = call k_policy_financial_management.f_get_mni_payer(?)}");
		        	cs.registerOutParameter(1, OracleTypes.CURSOR);
		        	cs.setString(2, entityreference);
		        	cs.execute();
		        	rs = (ResultSet) cs.getObject(1);
		        	while (rs.next()) {
		        		System.out.println("Each ecord ----> "+rs.getString("ID") + " name---> "+ rs.getString("FULLNAME"));
		        		
		        		 if(rs.getString("FULLNAME") != null) {
		        			 	//updated to avoid incorrect splitting when '_' in the payer details 
		        	        	String[] payorDetails = rs.getString("FULLNAME").split("-",2);            
		        	        	payorType = payorDetails[0];
		        	        	if(payorDetails.length >1) {
		        	        		payername = payorDetails[1];
		        	        	}
		        	        }
	        			WebServiceLoggerUtil.logInfo("QuotePolicyBillingAttributeServiceImpl", "verifyValidPayer:for Direct Bill", "Payer Obtained from DB:" + "payername:" + payername.trim()+ ", payorType:" + payorType + ", payer from API parameter: "+payer, new Object[] {entityreference});
	        			
	        			if (payer.equalsIgnoreCase(payername.trim())){
		        			
		        			  if(rs.getString("ID") != null) {
		        				//updated to avoid incorrect splitting when '-' in the payer details 
			        	        	String[] payorDetails = rs.getString("ID").split("_",2);            
			        	        	payorType = payorDetails[0];
			        	        	if(payorDetails.length >1) {
			        	        		payorID = payorDetails[1];
			        	        	}
			        	        	payerIdDetails = rs.getString("ID");
			        	        }
		        			  
		        			WebServiceLoggerUtil.logInfo("QuotePolicyBillingAttributeServiceImpl", "verifyValidPayer:for Direct Bill", "Matched Payer Obtained from DB:" + "payername:" + payername.trim()+ ", payorID:"+payorID+", payorType:"+payorType + ", payer from API parameter: "+payer, new Object[] {entityreference});
		        			
		        			vaid_payer = "true";
		        			 break;
		        		}
		        	}
		        		        	
		           // conn.commit();

		        } catch (Exception ex) {
					WebServiceLoggerUtil.logError("QuotePolicyBillingAttributeServiceImpl", "verifyValidPayer", "Failed:", new Object[] { ex.getMessage() }, ex);
					
		            try {
		                conn.rollback();
		            } catch (Exception e) {
		            	WebServiceLoggerUtil.logError("QuotePolicyBillingAttributeServiceImpl", "verifyValidPayer", "Failed:", new Object[] { e.getMessage() }, e);
						throw e;
		            }
		            throw ex;
		        } finally {
		        	PayerDetails.add(vaid_payer);
					PayerDetails.add(payorType);
					PayerDetails.add(payorID);
					PayerDetails.add(payername.trim());
					PayerDetails.add(payerIdDetails);
		            try {
		                DBUtil.close(rs, cs);
		            } catch (Throwable error) {
		            }
		        }		
			
		}
		
		return PayerDetails;
	}
	
	
	private void insertDefaultsForBilling(String entityReference)  
	{
        
        boolean defaultExistForBilling = isDefaultExistForBilling(entityReference);
        if(!defaultExistForBilling)
        {
        	insertDefaultForBilling(entityReference);
        }
		
	}
	
	private boolean isDefaultExistForBilling(String entityReference)
	{
		boolean defaultExistForBilling = false;
		
		PreparedStatement ps=null;
		ResultSet rs=null;
		Connection conn = null;
		int recordCount = 0;
		
		try {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,this.getClass().getName(), "isDefaultExistForBilling",ServletConfigUtil.COMPONENT_PORTAL,
					new Object[] { entityReference},"verifying if Defaults Exist For Billing",null,LogMinderDOMUtil.VALUE_MIC);
		
			String queryForDefaultExistForBilling = "SELECT COUNT(*) AS RECORD_COUNT FROM MIS_POLICY_FINANCIALS WHERE MPF_POLICY_REFERENCE = ?  ";
			
			conn = ConnectionPool.getConnection(user);
			ps=conn.prepareStatement(queryForDefaultExistForBilling);
			ps.setString(1, entityReference);
			rs=ps.executeQuery();
			while(rs.next()){
				recordCount = rs.getInt("RECORD_COUNT");
			}

	        if(recordCount>0)
	        {
	        	defaultExistForBilling = true;
	        }
		
		}
		catch(Exception ex) {
			WebServiceLoggerUtil.logError("QuotePolicyBillingAttributeServiceImpl.isdefaultExistForBilling", "check for default Exist For Billing falied", "Failed:", new Object[] { entityReference,ex.getMessage() }, ex);
		}
		finally {
	
			try {
				DBUtil.close(rs, ps, conn);
			} catch(Exception ex) {
				ex.printStackTrace();
			}
		}
		return defaultExistForBilling;
	}

	private void insertDefaultForBilling(String entityReference)
	{
		boolean defaultExistForBilling = false;
		
        String customerCode = CustomerConfigUtil.getInstance().getCustomerCode(user.getDomain());
        String calculateCommission = CustomerConfigUtil.getInstance().getCustomerProperty(user.getDomain(),
                                         ServletConfigUtil.COMPONENT_PORTAL,
                                         HTTPConstants.PROPERTY_CALCULATE_COMMISSION);
        User user = User.getUser(request);
		
        CallableStatement cs=null;
        PreparedStatement ps=null;
		ResultSet rs=null;
		Connection conn = null;
		String billType = null;
		String payPlan = null;
		String payPlanDescr = null;
		String billCollectionPlan = null;
		String billCollectionPlanDescr = null;
		
		try {

			LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,this.getClass().getName(), "insertDefaultForBilling",ServletConfigUtil.COMPONENT_PORTAL,
					new Object[] { entityReference},"Inserting Default For Billing",null,LogMinderDOMUtil.VALUE_MIC);
		
			conn = ConnectionPool.getConnection(user);

			
			String defaultBillType = "select BILL_TYPE_CODE from IEL_MIC_BILL_TYPES where PRODUCT_CODE = (SELECT product_code from vw_mis_quote_policies where entity_reference = ?) AND rownum = 1";
			ps = conn.prepareStatement(defaultBillType);
			ps.setString(1, entityReference);
			rs=ps.executeQuery();
			while(rs.next()){
				billType = rs.getString("BILL_TYPE_CODE");
			}
			
			cs = conn.prepareCall("{ call k_policy_financial_management.p_get_selected_pay_plan(?, ?, ?, ?, ?, ?, ?, ?, ?, ?) }");
            cs.registerOutParameter(6, Types.INTEGER);
            cs.registerOutParameter(7, Types.VARCHAR);
            cs.registerOutParameter(8, Types.INTEGER);
            cs.registerOutParameter(9, Types.VARCHAR);
            cs.registerOutParameter(10, Types.VARCHAR);
            cs.setString(1, customerCode);
            cs.setString(2, entityReference);
            cs.setString(3, calculateCommission);
            cs.setString(4, billType);
            cs.setString(5, user.getFullName());
            cs.execute();
            String errorMessaage = cs.getString(10);
            if (errorMessaage != null) {
                throw new Exception(errorMessaage);
            }
            
            payPlan = cs.getString(6);
            payPlanDescr = cs.getString(7);
        
            if (billCollectionPlan == null || billCollectionPlan.trim().equals("")) {
            	billCollectionPlan = cs.getString(8);
            }
            if (billCollectionPlanDescr == null || billCollectionPlanDescr.trim().equals("")) {
            	billCollectionPlanDescr = cs.getString(9);
            }

			LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO,this.getClass().getName(), "insertDefaultForBilling",ServletConfigUtil.COMPONENT_PORTAL,
					new Object[] { entityReference},"Inserting Default For Billing pay Plan=" + payPlan 
									+ ",pay Plan Descr="+payPlanDescr 
									+ ",bill Collection Plan="+billCollectionPlan
									+ ",bill Collection Plan Descr="+billCollectionPlanDescr
									,null,LogMinderDOMUtil.VALUE_MIC);
            
            
		}
		catch(Exception ex) {
			WebServiceLoggerUtil.logError("QuotePolicyBillingAttributeServiceImpl.insertDefaultForBilling", "insert for default For Billing failed", "Failed:", new Object[] { entityReference,ex.getMessage() }, ex);
			
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			String errMsg = "Not able to set defaults for billing before updating Billing info";
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,ex);	
		}
		finally {
	
			try {
				DBUtil.close(rs,ps);
				DBUtil.close(null,cs,conn);
			} catch(Exception ex) {
				ex.printStackTrace();
			}
		}
		
	}
	
	
	
	
}
