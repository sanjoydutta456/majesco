package com.coverall.mic.rest.policy.api.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.coverall.mic.rest.policy.api.service.model.BillingInstallment;
import com.coverall.mic.rest.policy.api.service.model.BillingInstallmentV2;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyBillingAttribute;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.util.DBUtil;

public class QuotePolicyBillingAttributeServiceImplV2 extends QuotePolicyBillingAttributeServiceImpl {

	public QuotePolicyBillingAttributeServiceImplV2(String entityReference, String entityType, HttpServletRequest request) {
		super(entityReference, entityType, request);
		// TODO Auto-generated constructor stub
	}

	protected QuotePolicyBillingAttribute getListOfBillingInformation(Connection conn, long sourceSystemRequestNo) throws Exception {

		QuotePolicyBillingAttribute billingAttribute = new QuotePolicyBillingAttribute();
		List<BillingInstallment> installmentList = new ArrayList<BillingInstallment>();
		billingAttribute.setInstallments(installmentList);

		PreparedStatement ps = null;
		ResultSet rs = null;
		PreparedStatement psInstallment = null;
		ResultSet rsInstallment = null;
		PreparedStatement psbillingTypeFlag = null;
		ResultSet rsbillingTypeFlag = null;

		try {
			ps = conn.prepareStatement(queryForFetchingPaymentPlanInfo);
			ps.setString(1, getCustomerCodeFromUser(user));
			ps.setString(2, getCustomerCodeFromUser(user));
			ps.setString(3, entityReference);
			ps.setString(4, entityReference);

			rs = ps.executeQuery();

			billingAttribute.setSourceSystemUserId(user.getUserId());
			billingAttribute.setSourceSystemCode(SOURCE_SYSTEM_CODE);
			billingAttribute.setSourceSystemRequestNo(sourceSystemRequestNo);

			while (rs.next()) {

				billingAttribute.setPayPlanName(rs.getString("planName"));
				billingAttribute.setPayer(rs.getString("payer"));
				billingAttribute.setPaymentMethod(rs.getString("paymentMethod"));
				billingAttribute.setBillingEffectiveDate(rs.getString("billingEffectiveDate"));
				billingAttribute.setAccount(rs.getString("accountNumber"));
				billingAttribute.setBillType(rs.getString("billType"));
				billingAttribute.setBillTypeFlag(rs.getString("MPF_BILL_TYPE"));

				psInstallment = conn.prepareStatement(queryForFecthingInstallments);
				psInstallment.setString(1, entityReference);

				rsInstallment = psInstallment.executeQuery();

				while (rsInstallment.next()) {
					String installmentId = rsInstallment.getString("installmentId");
					BillingInstallmentV2 installment = new BillingInstallmentV2();
					installment.setDueDate(rsInstallment.getString("dueDate"));
					installment.setSendDate(rsInstallment.getString("sendDate"));
					installment.setInstallmentId(installmentId);
					installment.setInstallmentCharge(rsInstallment.getDouble("installmentCharge"));
					installment.setPremiumDue(rsInstallment.getDouble("premiumDue"));
					installment.setTaxesFeesSurcharge(rsInstallment.getDouble("taxesFeesSurcharge"));
					installment.setTotalAmount(rsInstallment.getDouble("totalAmount"));
					if("0".equalsIgnoreCase(installmentId)){
						installment.setDisplayInstallmentId("D");
					}else{
						installment.setDisplayInstallmentId(installmentId);
					}
					installmentList.add(installment);
				}
			}
			// Logic for displaying bill type field
			// if(displayBillTypeValue==null){
			// psbillingTypeFlag=conn.prepareStatement(queryForFetchingValueOfBillType);
			// rsbillingTypeFlag=psbillingTypeFlag.executeQuery();
			// while (rsbillingTypeFlag.next()) {
			// displayBillTypeValue =
			// rsbillingTypeFlag.getString("displayBillType");
			//
			// }
			// }
			// if("N".equalsIgnoreCase(displayBillTypeValue)){
			// billingAttribute.setBillType(null);
			// }
		} catch (Exception e) {
			WebServiceLoggerUtil.logError("QuotePolicyBillingAttributeServiceImpl", "getListOfBillingInformation",
					"Exception occurred while fetching Billing attributes:" + e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw e;
		} finally {
			try {
				DBUtil.close(rsbillingTypeFlag, psbillingTypeFlag);
			} catch (Exception e) {
				// do nothing
			}

			try {
				DBUtil.close(rsInstallment, psInstallment);
			} catch (Exception e) {
				// do nothing
			}

			try {
				DBUtil.close(rs, ps);
			} catch (Exception e) {
				// do nothing
			}
		}

		return billingAttribute;
	}

}
