package com.coverall.mic.rest.policy.api.service.impl;

import java.util.Collections;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.type.CollectionType;

import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.QuotePolicyChangeSummaryService;
import com.coverall.mic.rest.policy.api.service.QuotePolicyExtractImportService;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;

import javax.servlet.http.HttpServletRequest;

import com.coverall.mt.http.User;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.pctv2.server.rs.service.microservices.ExtractTransactionRequest;
import com.coverall.pctv2.server.rs.service.microservices.ImportTransactionRequest;
import com.coverall.pctv2.server.service.ChangeSummaryProcessor;
import com.coverall.pctv2.server.service.ExtractTransactionProcessor;
import com.coverall.pctv2.server.service.ImportTransactionProcessor;

public class QuotePolicyChangeSummaryServiceImpl implements QuotePolicyChangeSummaryService{

	
	private User user;
	private HttpServletRequest request;
	private String entityReferenceNumber;
	private String entityType;
	private String policyAdditionalDetails;
	private String dontBook;
	private String allowTransaction;

	

	public QuotePolicyChangeSummaryServiceImpl(HttpServletRequest request,String entityReferenceNumber,String entityType){
		super();
		this.request=request;
		this.user=User.getUser(request);
		this.entityReferenceNumber = entityReferenceNumber;
		this.entityType = entityType;
		
	}
	
	
	@Override
	public Object getQuotePolicyChangeSummary() throws Exception {
		
        ExtractTransactionRequest extractTransactionRequest = new ExtractTransactionRequest();
		extractTransactionRequest.setEntityType(entityType);
		extractTransactionRequest.setEntityReference(entityReferenceNumber);
		
		Object obj = null;
		try{
			ChangeSummaryProcessor extractor = new ChangeSummaryProcessor(extractTransactionRequest, user); 
			//isDigitalFirstMode = request.getParameter(IGNORE_AUTO_INSTANCE_CREATION);
			obj = extractor.changeSummary();
			
		}catch (APIException e) {
			WebServiceLoggerUtil.logError("QuotePolicyChangeSummaryServiceImpl", "getQuotePolicyChangeSummary", "Failed:"+e.getErrorMessage(), new Object[] { null }, e);
			throw e;
		} catch (Exception e) {
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(e.getMessage()));
			String httpStatusCode = "";
			WebServiceLoggerUtil.logError("QuotePolicyChangeSummaryServiceImpl", "getQuotePolicyChangeSummary", "Failed:", new Object[] { e.getMessage() }, e);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		}
		
		
		return obj;
	}

			
}

