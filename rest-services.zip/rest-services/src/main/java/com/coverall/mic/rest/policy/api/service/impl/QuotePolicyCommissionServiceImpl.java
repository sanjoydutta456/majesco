package com.coverall.mic.rest.policy.api.service.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.type.CollectionType;

import com.coverall.exceptions.ServiceException;
import com.coverall.mt.util.APIAuditTrailLog;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.factory.impl.PolicyAPIFactoryServiceImpl;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.QuotePolicyCommissionService;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.ConfirmationMessage;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyCommission;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyCommissionOverride;
import com.coverall.mic.rest.policy.api.service.model.SourceSystemInformationBean;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mic.rest.policy.api.service.util.WorkflowUtil;
import com.coverall.mt.http.User;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.util.DBUtil;

public class QuotePolicyCommissionServiceImpl implements QuotePolicyCommissionService{

	public String entityReference;
	public String entityType;
	public HttpServletRequest request;
	public User user;
	public boolean isCommissionOverride=false;

	public String queryForFetchingCommission="SELECT commissionId, commissionPlanType,producerName,commissionPlanName,commissionPlanAmount,calculatedCommissionAmount,overrideCommission,netCommissionAmount,isPercent FROM (SELECT NVL(MPM_IS_COMM_PLAN_PERCENT,'N') isPercent,MPM_ID commissionId,"+
			"NVL(MPM_SUB_POLICY_REFERENCE, -1) AUDIT_ID,INITCAP(TO_CHAR(MAU_REPORTING_PERIOD, 'MON, YYYY')) REPORTING_PERIOD,"+
			"MPM_TYPE commissionPlanType,DECODE (MPM_PRODUCER_CODE, NULL, 'N/A',(SELECT SPR_PRODUCER_NAME FROM SHL_PRODUCERS"+ 
			" WHERE SPR_PRODUCER_CODE = MPM_PRODUCER_CODE))  producerName,DECODE(MPM_TYPE, 'Commission', '2' || MPM_PRODUCER_CODE, '1' || MPM_PRODUCER_CODE) SORTTING_COLUMN,"+
			"MPM_COMM_PLAN_NAME commissionPlanName,MPM_COMM_PLAN_DESC,MPM_IS_COMM_PLAN_PERCENT,DECODE(MIC_ADMIN.K_SECURITY_UTILITIES.F_GET_USERNAME(NVL(MPM_USER_MODIFIED, MPM_USER_CREATED)), 'batchuser', 'System',"+
			"MIC_ADMIN.K_SECURITY_UTILITIES.F_GET_USERNAME(NVL(MPM_USER_MODIFIED, MPM_USER_CREATED))) USER_MODIFIED,TO_CHAR(NVL(MPM_DATE_MODIFIED, MPM_DATE_CREATED), 'MM/DD/YYYY HH:MI') DATE_MODIFIED,"+
			"TO_CHAR(NVL(MPM_DATE_MODIFIED, MPM_DATE_CREATED), 'yyyy/mm/dd') DATE_MODIFIED_SORT,DECODE(MPM_IS_COMM_PLAN_PERCENT, 'Y', MPM_COMM_PLAN_COMM || '%', MPM_COMM_PLAN_COMM) commissionPlanAmount,"+
			"NVL(MPM_COMMISSION, 0) calculatedCommissionAmount,DECODE(MPM_COMM_PLAN_ADJUSTMENT, NULL, ' ', (MPM_COMM_PLAN_COMM + MPM_COMM_PLAN_ADJUSTMENT)) overrideCommission,"+
			"DECODE(MPM_IS_COMM_PLAN_PERCENT, 'Y', MPM_COMM_PLAN_COMM + MPM_COMM_PLAN_ADJUSTMENT || '%',MPM_COMM_PLAN_COMM + MPM_COMM_PLAN_ADJUSTMENT) FORMATTED_OVERRIDDEN_COMM,"+
			"DECODE(MPM_IS_COMM_PLAN_PERCENT, 'Y', NVL(MPM_COMM_PLAN_COMM + MPM_COMM_PLAN_ADJUSTMENT,MPM_COMM_PLAN_COMM) || '%',                NVL(MPM_COMM_PLAN_COMM + MPM_COMM_PLAN_ADJUSTMENT,MPM_COMM_PLAN_COMM)) FORMATTED_NET_PERCENTAGE,"+
			"NVL(MPM_NET_COMMISSION, 0) netCommissionAmount,MPM_ADJUSTED_COMMISSION ADJUSTMENT_AMOUNT,(CASE WHEN (NVL(MPM_ADJUSTED_COMMISSION,0)  < 0 ) THEN '-$' || ( -1 * MPM_ADJUSTED_COMMISSION) ELSE '$' || MPM_ADJUSTED_COMMISSION END )ADJUSTMENT_AMOUNT_LABEL,"+
			"(SELECT mpo_commissionable_premium FROM mis_policies WHERE mpo_policy_reference = MPM_POLICY_REFERENCE ) SUBJECT_TO_COMMISSION"+
			" FROM MIS_POLICY_COMMS_FEES,MIS_AUDITS WHERE MPM_POLICY_REFERENCE = ? AND MPM_SUB_POLICY_REFERENCE = MAU_ID(+))";

	public String queryForCommissionManagementTaskId="SELECT WAC_ID activityId FROM wfl_activities WHERE wac_task_id=(SELECT wta_id FROM WFL_TASKS WHERE WTA_NAME='"+APIConstant.COMMISSIONMANAGEMENT_TASK+"')"+
			" AND WAC_WORKFLOW_TASK_ID IN (SELECT wwt_id FROM WFL_WORKFLOW_TASKS WHERE WWT_WORKFLOW_ID IN (SELECT wwo_id FROM WFL_WORKFLOWS"+
			" WHERE wwo_NAME IN ('POLICY WORKFLOW','QUOTE WORKFLOW')) AND wwt_task_id=("+
			" SELECT wta_id FROM WFL_TASKS WHERE WTA_NAME='"+APIConstant.COMMISSIONMANAGEMENT_TASK+"' ))"+
			" AND WAC_ENTITY_REFERENCE=?";

	public QuotePolicyCommissionServiceImpl(String entityReference, String entityType,HttpServletRequest request) {
		super();
		this.entityReference = entityReference;
		this.entityType = entityType;
		this.request=request;
		user=user.getUser(request);
	}


	@Override
	public List<QuotePolicyCommission> getCommissionsList() throws APIException {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		List<QuotePolicyCommission> commissionList=new ArrayList<QuotePolicyCommission>();
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		String sourceSystemUserId=user.getUserId();
		long sourceSystemRequestNo=System.currentTimeMillis();
		try{
			if(!WorkflowUtil.checkIfUserHasTheRequiredPermission(requestContext.getUser(), APIConstant.VIEW_COMMISSION_REPORT_PERMISSION)) {
				String errMsg = user.getUserId()+" doesn't have permission to view commissions.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("QuotePolicyCommissionServiceImpl", "getCommissionsList", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}
			conn = requestContext.getConnection();
			if(!WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)){
				String errMsg = entityType + " " + entityReference + " was not found. Please check input parameters.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("QuotePolicyCommissionServiceImpl", "getCommissionsList", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
			
			if(!WorkflowUtil.isWorkflowStageReached(conn, entityType, APIConstant.COMMISSIONMANAGEMENT_TASK,entityReference)){
				String errMsg = "Commission management stage is not yet reached for the entity "+entityReference+". Please check the status.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("QuotePolicyCommissionServiceImpl", "getCommissionsList", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
			commissionList=getListOfCommissionsForQuotePolicy(conn,sourceSystemUserId,sourceSystemRequestNo,entityReference);

		}catch (APIException e) {
			throw e;
		}catch (Exception e) {
			WebServiceLoggerUtil.logError("QuotePolicyCommissioServiceImpl", "getCommissionsList", "Exception occurred while executing commission fecthing query:", new Object[] { queryForFetchingCommission }, e);
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		}

		return commissionList;
	}


	@Override
	public Object processCommissionCalculation() throws Exception {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		ConfirmationMessage processCommissionResponse=new ConfirmationMessage();
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		CallableStatement callStmt=null;
		
		if(!isCommissionOverride){
			String sourceSystemCode=null;
			String sourceSystemUserId=null;
			long sourceSystemRequestNo=0;

			try{
				ObjectMapper mapper=new ObjectMapper();
				String inputJson=APIOperationUtil.fetchRequestBody(request);
				SourceSystemInformationBean sourceSystem=mapper.readValue(inputJson, SourceSystemInformationBean.class);
				sourceSystemCode=sourceSystem.getSourceSystemCode();
				sourceSystemUserId=sourceSystem.getSourceSystemUserId();
				sourceSystemRequestNo=sourceSystem.getSourceSystemRequestNo();
			}catch(Exception exp){
				//do nothing as this is not a mandatory part of request but needed for audit logging
			}

			//Auditing logic
			APIAuditTrailLog auditTrailLog=requestContext.getAuditTrailLog();
			APIOperationUtil.populateAPIAuditLog(auditTrailLog, sourceSystemCode, sourceSystemUserId, sourceSystemRequestNo, RESOURCE_TYPE, PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
			//Adding specifics
			APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, entityReference, null, "Process Commission Calculation.");
		}
		
		try{
			conn = requestContext.getConnection();
		
		if(!WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)){
			String errMsg = entityType + " " + entityReference + " was not found. Please check input parameters.";
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
			WebServiceLoggerUtil.logInfo("QuotePolicyCommissionServiceImpl", "processCommissionCalculation", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}

		if(!WorkflowUtil.isWorkflowStageReached(conn, entityType, APIConstant.COMMISSIONMANAGEMENT_TASK,entityReference)){
			String errMsg = "Commission management stage is not yet reached for the entity "+entityReference+". Please check the status.";
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			WebServiceLoggerUtil.logInfo("QuotePolicyCommissionServiceImpl", "processCommissionCalculation", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}

		if(!WorkflowUtil.checkIfUWRuleAndCommissionManagementWorkflowIsApplicable(user,conn, entityReference, entityType)){
			String errMsg = "Commission Calculation can not be performed for "+entityReference;
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			WebServiceLoggerUtil.logInfo("QuotePolicyCommissionServiceImpl", "processCommissionCalculation", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}

		
			ps=conn.prepareStatement(queryForCommissionManagementTaskId);
			ps.setString(1, entityReference);
			rs=ps.executeQuery();
			long activityId=0;
			while(rs.next()){
				activityId=Long.parseLong(rs.getString("activityId"));
				break;	
			}

			//Setting commission management activity as blocked
			callStmt = conn.prepareCall("{ ? = call K_WORKFLOW_ACTIVITY_MANAGEMENT.f_set_blocked(?, ?, ?, ?)}");
			callStmt.registerOutParameter(1, Types.INTEGER);
			callStmt.setLong(2, activityId);
			callStmt.setString(3, "Ready for Commission Management");
			callStmt.setString(4, "Y");
			callStmt.registerOutParameter(5, Types.VARCHAR);
			callStmt.execute();
			long errorCode=callStmt.getInt(1);
			String errorDescription=callStmt.getString(5);

			conn.commit();
			callStmt.close();
			callStmt=null;

			if (errorCode!= 0) {
				throw new ServiceException(errorDescription, null);
			}

			//Completing commission management activity
			callStmt = conn.prepareCall("{? = call K_WORKFLOW_ACTIVITY_MANAGEMENT.f_set_complete(?, ?, ?, ?, ?, ?)}");
			callStmt.registerOutParameter(1, Types.INTEGER);
			callStmt.setString(2, activityId+"");
			callStmt.setString(3, "Y");
			callStmt.setString(4, user.getFullName());
			callStmt.setString(5, null);
			callStmt.setString(6, "Y");
			callStmt.registerOutParameter(7, Types.VARCHAR);
			callStmt.execute();
			errorCode=callStmt.getLong(1);
			errorDescription=callStmt.getString(7);

			conn.commit();
			callStmt.close();
			callStmt=null;

			if (errorCode != 0) {
				throw new com.coverall.exceptions.ServiceException(errorDescription,null);
			}

			processCommissionResponse.setCode("SUCCESS");
			processCommissionResponse.setDescription("Commission Calculation re-triggered for the "+entityType+" : "+entityReference);

		}catch (APIException e) {
			WebServiceLoggerUtil.logError("QuotePolicyCommissioServiceImpl", "processCommissionCalculation", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw e;
		}catch (Exception e) {
			WebServiceLoggerUtil.logError("QuotePolicyCommissioServiceImpl", "processCommissionCalculation", "Exception occurred while triggering commission re-processing:", new Object[] { "K_WORKFLOW_ACTIVITY_MANAGEMENT.f_set_blocked",
			"K_WORKFLOW_ACTIVITY_MANAGEMENT.f_set_complete" }, e);
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		}finally{
			try {
				DBUtil.close(rs, ps, null);
			} catch (SQLException e) {
				WebServiceLoggerUtil.logInfo("QuotePolicyCommissionServiceImpl", "processCommissionCalculation", e.getLocalizedMessage(), new Object[] { e.getMessage() });
			}
		}

		return processCommissionResponse;
	}


	@Override
	public Object modifyCommissions() throws Exception {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		ConfirmationMessage overrideResponse=new ConfirmationMessage();
		//Fetching JSON request as a MAP
		ObjectMapper mapper = null;
		String inputJson = null;
		List<QuotePolicyCommissionOverride> listOfCommissionOverrides=null;
		Connection conn = requestContext.getConnection();
		CallableStatement callStmt=null;
		isCommissionOverride=true;
		//requestContext.setAuditTrailLog(null);

		try{
			mapper=new ObjectMapper();
			inputJson=APIOperationUtil.fetchRequestBody(request);
			CollectionType listType = mapper.getTypeFactory().constructCollectionType(ArrayList.class, QuotePolicyCommissionOverride.class);
			listOfCommissionOverrides=mapper.readValue(inputJson, listType);

		}catch(Exception exp){
			String errMsg = "Invalid JSON. Please provide proper numeric value for commissionId, overrideCommission(without any sign like %,$)";
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,exp);
		}

		List<QuotePolicyCommission> listOfExistingCommissionsForEntity=getListOfCommissionsForQuotePolicy(conn,requestContext.getUserName(),System.currentTimeMillis(),entityReference);
		
		for(QuotePolicyCommissionOverride overriddenCommission:listOfCommissionOverrides){
			boolean foundCommission=false;
			for(QuotePolicyCommission commissionInSystem:listOfExistingCommissionsForEntity){
				if(overriddenCommission.getCommissionId()==commissionInSystem.getCommissionId()){
					foundCommission=true;
					if(overriddenCommission.getOverrideCommission()<0){
						String errMsg = "Value of the overrideCommission cannot be less than 0.";
						List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
						String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
						throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
					}
				}
			}
			if(!foundCommission){
				String errMsg = "No commission with ID:"+overriddenCommission.getCommissionId()+" is found for "+entityType+":"+entityReference;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
		}

		try{

			if(!WorkflowUtil.checkIfUserHasTheRequiredPermission(requestContext.getUser(), APIConstant.OVERRIDE_COMMISSION_PERMISSION)) {
				String errMsg = user.getUserId()+" doesn't have permission to override commissions.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}

			if(!WorkflowUtil.checkIfUWRuleAndCommissionManagementWorkflowIsApplicable(user, conn,entityReference, entityType)){
				String errMsg = "Commission can not be for overridden for "+entityReference;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}

			ArrayList<String> commissionsNotOverridden=new ArrayList<String>();
			ArrayList<String> commissionsOverridden=new ArrayList<String>();

			for(QuotePolicyCommissionOverride overriddenCommission:listOfCommissionOverrides){
				try{
					callStmt = conn.prepareCall("{? = call K_COMMISSION_MANAGEMENT.f_override_commission(?, ?, ?, ?, ?)}");
					callStmt.registerOutParameter(1, Types.INTEGER);
					callStmt.setString(2, overriddenCommission.getCommissionId()+"");
					callStmt.setString(3, overriddenCommission.getOverrideCommission()+"");
					callStmt.setString(4, user.getFullDisplayName());
					callStmt.setString(5, "Y");
					callStmt.registerOutParameter(6, Types.VARCHAR);
					callStmt.execute();

					if (callStmt.getLong(1) != 0) {
						commissionsNotOverridden.add(overriddenCommission.getCommissionId()+"[Reason:"+callStmt.getString(6)+"]");
					}else{
						commissionsOverridden.add(overriddenCommission.getCommissionId()+"");
					}
				}catch(Exception exp){
					commissionsNotOverridden.add(overriddenCommission.getCommissionId()+"");
				}finally{
					conn.commit();
					DBUtil.close(null, callStmt, null);	
				}
			}

			if(commissionsOverridden!=null && commissionsOverridden.size()>0){
				overrideResponse.setCode("SUCCESS");
				String descriptionString="Commissions sucessfully overriden: "+StringUtils.join(commissionsOverridden, ',');
				if(commissionsNotOverridden!=null && commissionsNotOverridden.size()>0){
					overrideResponse.setCode("PARTIAL SUCCESS");
					descriptionString+="There is some error while overridding commissions:"+StringUtils.join(commissionsNotOverridden, ',');
				}
				overrideResponse.setDescription(descriptionString);
			}else{
				String errMsg = "Error overriding commissions: ";
				if(commissionsNotOverridden!=null && commissionsNotOverridden.size()>0){
					errMsg+=StringUtils.join(commissionsNotOverridden, ',');
				}
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
			
			processCommissionCalculation();
		} catch (APIException e) {
			WebServiceLoggerUtil.logError("QuotePolicyCommissioServiceImpl", "modifyCommissions", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw e;
		} catch (Exception exc) {
			WebServiceLoggerUtil.logError("QuotePolicyCommissioServiceImpl", "processCommissionCalculation", "Exception occurred while overridding commission", new Object[] { "K_COMMISSION_MANAGEMENT.f_override_commission" }, exc);
			String errMsg = null;
			List <Message> errorMessageList = null;
			String httpStatusCode = null;
			if(exc instanceof APIException){
				errMsg = ((APIException) exc).getErrorMessage();
				errorMessageList = ((APIException) exc).getErrorMessageList();
				httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			}else{
				errMsg = "Error overriding commission " + exc.getLocalizedMessage();
				errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			}
			
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);

		}

		return overrideResponse;
	}
	
	public List<QuotePolicyCommission> getListOfCommissionsForQuotePolicy(Connection conn,String sourceSystemUserId,long sourceSystemRequestNo,String entityReference) throws APIException{
		List<QuotePolicyCommission> commissionList=new ArrayList<QuotePolicyCommission>();
		PreparedStatement ps=null;
		ResultSet rs=null;
		try{
			ps=conn.prepareStatement(queryForFetchingCommission);
			ps.setString(1, entityReference);
			rs=ps.executeQuery();
			while(rs.next()){
				QuotePolicyCommission commission=new QuotePolicyCommission();
				//Mandatory Columns
				commission.setSourceSystemCode(SOURCE_SYSTEM_CODE);
				commission.setSourceSystemRequestNo(sourceSystemRequestNo);
				commission.setSourceSystemUserId(sourceSystemUserId);

				commission.setCommissionId(Integer.parseInt(rs.getString("commissionId")));
				commission.setProducerName(rs.getString("producerName"));
				commission.setCommissionPlanName(rs.getString("commissionPlanName"));
				commission.setCommissionPlanType(rs.getString("commissionPlanType"));
				commission.setCommissionPlanAmount(rs.getString("commissionPlanAmount"));
				commission.setNetCommissionAmount(rs.getString("netCommissionAmount").trim().equalsIgnoreCase("")?0:Double.parseDouble(rs.getString("netCommissionAmount")));
				commission.setCalculatedCommissionAmount(rs.getString("calculatedCommissionAmount").trim().equalsIgnoreCase("")?0:Double.parseDouble(rs.getString("calculatedCommissionAmount")));
				commission.setOverrideCommission(rs.getString("overrideCommission").trim().equalsIgnoreCase("")?0:Double.parseDouble(rs.getString("overrideCommission")));
				commission.setIsPercent(rs.getString("isPercent"));

				commissionList.add(commission);
			}
		}catch(Exception exp){
			WebServiceLoggerUtil.logError("QuotePolicyCommissioServiceImpl", "getListOfCommissionsForQuotePolicy", "Exception occurred while fetching commission for "+entityReference, new Object[] {} , exp);
			String errMsg = "Error fetching commission " + exp.getLocalizedMessage();
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);

		}finally{
			try {
				DBUtil.close(rs, ps, null);
			} catch (SQLException e) {
				WebServiceLoggerUtil.logInfo("QuotePolicyCommissionServiceImpl", "getListOfCommissionsForQuotePolicy", e.getLocalizedMessage(), new Object[] { e.getMessage() });
			}
		}
		return commissionList;
	}

	public List<Message> getErrorMessageList(List<String> strMessages)	{
		if(strMessages == null)	{
			return null;
		}
		List<Message> errorMessageList = new ArrayList<Message>(strMessages.size());
		for(String aMsg : strMessages)	{
			Message message = new Message();
			message.setMoreinfo(aMsg);
			errorMessageList.add(message);
		}
		return errorMessageList;
	}
}

