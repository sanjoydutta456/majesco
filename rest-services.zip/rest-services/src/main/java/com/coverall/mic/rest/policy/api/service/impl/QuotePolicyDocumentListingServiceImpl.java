package com.coverall.mic.rest.policy.api.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.QuotePolicyDocumentListingService;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyDocument;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mic.rest.policy.api.service.util.WorkflowUtil;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.util.DBUtil;

public class QuotePolicyDocumentListingServiceImpl implements QuotePolicyDocumentListingService {

	public String entityReference;
	public String entityType;
	public HttpServletRequest request;

	public static final String queryForFetchingDocumentListing="SELECT mdo_document_id documentId,MDO_DOCUMENT_NAME documentName, MDO_DOCUMENT_EDITION_DATE documentEditionDate,MDO_DOCUMENT_DESCRIPTION documentDescription,"
			+"(SELECT pdt_id FROM VW_PS_DOCUMENT_TEMPLATE WHERE pdt_date_deleted IS NULL AND upper(pdt_name)=upper(MDO_DOCUMENT_NAME) AND rownum=1) templateId,"
			+ "MDO_RANK rank, MDO_MANUAL_ATTACH manualAttach, MDO_USER_DELETE_OVERRIDE deleteOverride,MDO_ADOPTED_STATES adoptionStates,"
			+ "to_char(MDO_DATE_CREATED,'YYYY-MM-DD') dateCreated, to_char(MDO_DATE_MODIFIED,'YYYY-MM-DD') dateModified FROM MIS_DOCUMENTS"
			+" WHERE MDO_POLICY_REFERENCE=? AND UPPER(mdo_entity_type)=UPPER(?) ORDER bY MDO_RANK";


	public QuotePolicyDocumentListingServiceImpl(HttpServletRequest request,String entityType,String entityReference) {
		super();
		this.entityReference = entityReference;
		this.entityType = entityType;
		this.request=request;
	}

	@Override
	public Object getListOfAttachedDocuments() throws Exception {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		List<QuotePolicyDocument> listOfDocuments=new ArrayList<QuotePolicyDocument>();
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;

		try{
			conn=requestContext.getConnection();

			if(!WorkflowUtil.isWorkflowStageReached(conn, entityType, APIConstant.DOCUMENTS_TASK,entityReference)){
				String errMsg = "Document Generation stage is yet not reached for the entity "+entityReference+". Please check the status.";
				List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("QuotePolicyDocumentListingServiceImpl", "getListOfAttachedDocuments", errMsg, new Object[] {  errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}

			ps=conn.prepareStatement(queryForFetchingDocumentListing);
			ps.setString(1, entityReference);
			
			boolean isBinder = WorkflowUtil.checkIfBinder(conn, entityReference);
			if(isBinder){
				ps.setString(2, "BINDER");
			}else{
				ps.setString(2, entityType);
			}

			rs=ps.executeQuery();

			while(rs.next()){
				QuotePolicyDocument newDocument=new QuotePolicyDocument();

				newDocument.setTemplateId(rs.getString("templateId"));
				newDocument.setDocumentId(rs.getString("documentId"));
				newDocument.setDocumentName(rs.getString("documentName"));
				newDocument.setDocumentEditionDate(rs.getString("documentEditionDate"));
				newDocument.setDocumentDescription(rs.getString("documentDescription"));
				newDocument.setRank(rs.getString("rank"));
				newDocument.setManualAttach(rs.getString("manualAttach"));
				newDocument.setDeleteOverride(rs.getString("deleteOverride"));
				newDocument.setAdoptionStates(rs.getString("adoptionStates"));
				newDocument.setDateCreated(rs.getString("dateCreated"));
				newDocument.setDateModified(rs.getString("dateModified"));

				listOfDocuments.add(newDocument);
			}
		}catch(APIException e){
			throw e;
		}catch (Exception e) {
			String errMsg = e.getLocalizedMessage();
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError("QuotePolicyDocumentListingServiceImpl", "getListOfAttachedDocuments", "Exception occurred while fetching list of document:"+e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}finally{
			try{	
				DBUtil.close(rs, ps);
			}catch(Exception e){
				//do nothing
			}
		}
		return listOfDocuments;
	}
}
