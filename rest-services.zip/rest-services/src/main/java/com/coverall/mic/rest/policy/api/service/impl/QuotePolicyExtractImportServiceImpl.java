package com.coverall.mic.rest.policy.api.service.impl;

import java.util.Collections;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.type.CollectionType;

import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.QuotePolicyExtractImportService;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import javax.servlet.http.HttpServletRequest;
import com.coverall.mt.http.User;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.pctv2.server.rs.service.microservices.ExtractTransactionRequest;
import com.coverall.pctv2.server.rs.service.microservices.ImportTransactionRequest;
import com.coverall.pctv2.server.service.ExtractTransactionProcessor;
import com.coverall.pctv2.server.service.ImportTransactionProcessor;
import com.coverall.mic.rest.policy.api.service.IAPIContext;

public class QuotePolicyExtractImportServiceImpl implements QuotePolicyExtractImportService{

	
	private User user;
	private HttpServletRequest request;
	private String entityReferenceNumber;
	private String policyAdditionalDetails;
	private String dontBook;
	private String allowTransaction;

	

	public QuotePolicyExtractImportServiceImpl(HttpServletRequest request,String entityReferenceNumber,String policyAdditionalDetails){
		super();
		this.request=request;
		this.user=User.getUser(request);
		this.entityReferenceNumber = entityReferenceNumber;
		this.policyAdditionalDetails=policyAdditionalDetails;
		
	}
	
	public QuotePolicyExtractImportServiceImpl(HttpServletRequest request,String entityReferenceNumber,String dontBook,String allowTransaction){
		super();
		this.request=request;
		this.user=User.getUser(request);
		this.entityReferenceNumber = entityReferenceNumber;
		this.dontBook=dontBook;
		this.allowTransaction=allowTransaction;
	}
	
	@Override
	public Object getQuotePolicyExtractData() throws Exception {
		String entType = entityReferenceNumber.substring(0, 1);
		String isDigitalFirstMode = null;
        if (entType.equalsIgnoreCase("P")) {
        	entType = "POLICY";	        	
        } else {
        	entType = "QUOTE";
        }
        ExtractTransactionRequest extractTransactionRequest = new ExtractTransactionRequest();
		extractTransactionRequest.setEntityType(entType);
		extractTransactionRequest.setEntityReference(entityReferenceNumber);
		extractTransactionRequest.setPolicyAdditionalDetails(policyAdditionalDetails);
		
		Object obj = null;
		try{
			ExtractTransactionProcessor extractor = new ExtractTransactionProcessor(extractTransactionRequest, user); 
			//isDigitalFirstMode = request.getParameter(IGNORE_AUTO_INSTANCE_CREATION);
			obj = extractor.extractTransaction(isDigitalFirstMode,null);
			
		}catch (APIException e) {
			WebServiceLoggerUtil.logError("QuotePolicyExtractImportServiceImpl", "getQuotePolicyExtractData", "Failed:"+e.getErrorMessage(), new Object[] { null }, e);
			throw e;
		} catch (Exception e) {
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(e.getMessage()));
			String httpStatusCode = "";
			WebServiceLoggerUtil.logError("QuotePolicyExtractImportServiceImpl", "getQuotePolicyExtractData", "Failed:", new Object[] { e.getMessage() }, e);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		}
		
		
		return obj;
	}

	@Override
	public Object getQuotePolicyImportData() throws APIException {
		String entType = entityReferenceNumber.substring(0, 1);
		String isDigitalFirstMode = null;
        if (entType.equalsIgnoreCase("P")) {
        	entType = "POLICY";	        	
        } else {
        	entType = "QUOTE";
        }
		ImportTransactionRequest importTransactionRequest = new ImportTransactionRequest();
		importTransactionRequest.setEntityType(entType);
		importTransactionRequest.setEntityReference(entityReferenceNumber);
		importTransactionRequest.setAllowTransaction(allowTransaction);
		importTransactionRequest.setDontBook(dontBook);
		
		ImportTransactionProcessor extractor = new ImportTransactionProcessor(importTransactionRequest, user); 
		Object obj = null;
		try{
			ObjectMapper mapper=new ObjectMapper();
			String inputJson=APIOperationUtil.fetchRequestBody(request);
			//isDigitalFirstMode = request.getParameter(IGNORE_AUTO_INSTANCE_CREATION);
			obj = extractor.importTransaction(isDigitalFirstMode,inputJson);
			
		}catch (APIException e) {
			WebServiceLoggerUtil.logError("QuotePolicyExtractImportServiceImpl", "getQuotePolicyImportData", "Failed:"+e.getErrorMessage(), new Object[] { null }, e);
			throw e;
		} catch (Exception e) {
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(e.getMessage()));
			String httpStatusCode = "";
			WebServiceLoggerUtil.logError("QuotePolicyExtractImportServiceImpl", "getQuotePolicyImportData", "Failed:", new Object[] { e.getMessage() }, e);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		}
				
		// Writing the Jason into response
		//String json = new Gson().toJson(obj);
		
		return obj;
	}


		
}

