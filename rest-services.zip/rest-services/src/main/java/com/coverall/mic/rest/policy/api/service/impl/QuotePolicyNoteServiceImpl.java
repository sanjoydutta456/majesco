package com.coverall.mic.rest.policy.api.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import org.apache.commons.io.IOUtils;
import org.codehaus.jackson.map.ObjectMapper;

import com.coverall.exceptions.ELException;
import com.coverall.exceptions.ExceptionImpl;
import com.coverall.mt.util.APIAuditTrailLog;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.factory.impl.PolicyAPIFactoryServiceImpl;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.QuotePolicyNoteService;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.ConfirmationMessage;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyNote;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyNoteHistory;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyNoteRequest;
import com.coverall.mic.rest.policy.api.service.model.SourceSystemInformationBean;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mic.rest.policy.api.service.util.WorkflowUtil;
import com.coverall.mt.fm.FolderObject;
import com.coverall.mt.http.User;
import com.coverall.mt.security.AdminX;
import com.coverall.mt.security.Principal;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.portal.dao.FolderObjectsNotesAssn;
import com.coverall.portal.dao.Notes;
import com.coverall.util.DBUtil;


public class QuotePolicyNoteServiceImpl implements QuotePolicyNoteService{

	private String entityReference;
	private String entityType;
	private HttpServletRequest request;
	private User user;

	public static final String TEMP = "temp";
	public static final String TEMPLATE_DOWNLOAD = "templateDownload";
	public static final String CLASS_NAME = "QuotePolicyNoteServiceImpl";
	public static final String NOT_FOUND_MESSAGE = " was not found. Please check input parameters.";
	public static final String INTERNAL_ERROR_MESSAGE = "Internal Server Error: Please check Server/Database logs for details.";
	public static final String FAILED = "Failed:";
	
	
	public QuotePolicyNoteServiceImpl(String entityReference, String entityType,HttpServletRequest request) {
		super();
		this.entityReference = entityReference;
		this.entityType = entityType;
		this.request=request;

	}

	@Override
	public List<QuotePolicyNote> getQuotePolicyAllNotesList()
			throws Exception {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		user = User.getUser(request);
		Connection conn = null;
		String functionName = "getQuotePolicyAllNotesList";
		List<QuotePolicyNote> notesList=new ArrayList<QuotePolicyNote>();
		try{
			conn=requestContext.getConnection();
			if(WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)){
				String folderObjectId=getFolderObjectIdFromEntityReference(conn,entityReference);
				notesList=getNotesDataForEntity(conn, folderObjectId,null);

			}else{
				String errMsg = entityType + " " + entityReference + NOT_FOUND_MESSAGE;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo(CLASS_NAME, "getQuotePolicyAllNotesList", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
		}catch (APIException e) {
			WebServiceLoggerUtil.logError(CLASS_NAME, functionName, FAILED + e.getErrorMessage(), new Object[] { null }, e);
			throw e;
		} catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(INTERNAL_ERROR_MESSAGE));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError(CLASS_NAME, functionName, FAILED, new Object[] { e.getMessage() }, e);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		}
		return notesList;
	}


	@Override
	public List<QuotePolicyNote> getQuotePolicyNote(
			String noteId) throws Exception {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		user = User.getUser(request);
		Connection conn = null;
		List<QuotePolicyNote> notesList=new ArrayList<QuotePolicyNote>();
		try{
			conn=requestContext.getConnection();
			if(WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)){
				String folderObjectId=getFolderObjectIdFromEntityReference(conn,entityReference);
				notesList=getNotesDataForEntity(conn, folderObjectId,noteId);

			}else{
				String errMsg = entityType + " " + entityReference + NOT_FOUND_MESSAGE;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
		}catch (APIException e) {
			WebServiceLoggerUtil.logError(CLASS_NAME, "getQuotePolicyNote", FAILED + e.getErrorMessage(), new Object[] { null }, e);
			throw e;
		} catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(INTERNAL_ERROR_MESSAGE));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError(CLASS_NAME, "getQuotePolicyNote", FAILED , new Object[] { e.getMessage() }, e);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		}
		return notesList;
	}


	@Override
	public Object deleteQuotePolicyNote(
			String noteId) throws APIException {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		ConfirmationMessage deleteObject=new ConfirmationMessage();
		user = User.getUser(request);
		Connection conn = null;	
		
		String sourceSystemCode=null;
		String sourceSystemUserId=null;
		long sourceSystemRequestNo=0;
		try{
			ObjectMapper mapper=new ObjectMapper();
			String inputJson=APIOperationUtil.fetchRequestBody(request);
			SourceSystemInformationBean sourceSystem=mapper.readValue(inputJson, SourceSystemInformationBean.class);
			sourceSystemCode=sourceSystem.getSourceSystemCode();
			sourceSystemUserId=sourceSystem.getSourceSystemUserId();
			sourceSystemRequestNo=sourceSystem.getSourceSystemRequestNo();
		}catch(Exception exp){
				//do nothing as this is not a mandatory part of request but needed for audit logging
		}		
			//Auditing logic
		APIAuditTrailLog auditTrailLog=requestContext.getAuditTrailLog();
		APIOperationUtil.populateAPIAuditLog(auditTrailLog, sourceSystemCode, sourceSystemUserId, sourceSystemRequestNo, RESOURCE_TYPE, PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
			//Adding specifics

		try{
			conn=requestContext.getConnection();
			if(checkSecurityFeatureInNoteOperations(conn)){
				if(!WorkflowUtil.checkIfUserHasTheRequiredPermission(requestContext.getUser(), APIConstant.DELETE_NOTE_PERMISSION)) {
					String errMsg = user.getUserId()+" doesn't have permission to delete a note.";
					List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
					String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
					WebServiceLoggerUtil.logInfo(CLASS_NAME, "deleteQuotePolicyNote", errMsg, new Object[] { errMsg });
					throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
				}
			}

			if(WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)){
				if(noteId==null || noteId.trim().equalsIgnoreCase("")){
					String errMsg = noteId + NOT_FOUND_MESSAGE;
					List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
					String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
					WebServiceLoggerUtil.logInfo(CLASS_NAME, "deleteQuotePolicyNote", errMsg, new Object[] { errMsg });
					throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
				}

				String strfolderObjectId=getFolderObjectIdFromEntityReference(conn,entityReference);
		        
				long noteIdLong = 0;
				boolean isValidateNoteId = true;
		        try {
		        	noteIdLong = Long.parseLong(noteId);
		        	isValidateNoteId = validateNoteId(conn, strfolderObjectId, noteIdLong);
		        } catch (Exception ex) {
					String errMsg = noteId + NOT_FOUND_MESSAGE;
					List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
					String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
					WebServiceLoggerUtil.logInfo(CLASS_NAME, "deleteQuotePolicyNote", errMsg, new Object[] { errMsg });
					throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
		        }
		        
				if(strfolderObjectId != null && !strfolderObjectId.trim().equalsIgnoreCase("") && isValidateNoteId) {
			        long folderObjectId = 0;
			        try {
			            folderObjectId = Long.parseLong(strfolderObjectId);
			        } catch (Exception ex) {
			            throw new Exception("Invalid folderObjectId: " +
			            		folderObjectId);
			        }

			        FolderObjectsNotesAssn fnAssn = new FolderObjectsNotesAssn();
			        fnAssn.init(user, folderObjectId, noteIdLong);
			        fnAssn.delete(user);

			        Notes notes = new Notes();
			        notes.init(user, noteIdLong);
			        notes.delete(user);

					deleteObject.setCode("200");
					deleteObject.setDescription("Note with id " + noteId +" is deleted.");
				}else{
					deleteObject.setCode("400");
					deleteObject.setDescription("There is no such note with id "+noteId+" for "+entityReference);	
				}
			} else{
				String errMsg = entityType + " " + entityReference + NOT_FOUND_MESSAGE;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo(CLASS_NAME, "deleteQuotePolicyNote", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
			APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, entityReference, noteId, "Deleted Note");
		}catch (APIException e) {
			WebServiceLoggerUtil.logError(CLASS_NAME, "deleteQuotePolicyNote", FAILED +e.getErrorMessage(), new Object[] { null }, e);
			throw e;
		} catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(INTERNAL_ERROR_MESSAGE));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError(CLASS_NAME, "deleteQuotePolicyNote", FAILED , new Object[] { e.getMessage() }, e);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		}
		return deleteObject;
	}

	@Override
	public Object addQuotePolicyNote()
			throws Exception {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		user = User.getUser(request);
		Connection conn = null;
		ConfirmationMessage confirmationMessage=null;

		try{
			conn=requestContext.getConnection();

			if(checkSecurityFeatureInNoteOperations(conn)){
				if(!WorkflowUtil.checkIfUserHasTheRequiredPermission(requestContext.getUser(), APIConstant.CREATE_NOTE_PERMISSION)) {
					String errMsg = user.getUserId()+" doesn't have permission to add a note.";
					List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
					String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
					WebServiceLoggerUtil.logInfo(CLASS_NAME, "addQuotePolicyNote", errMsg, new Object[] { errMsg });
					throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
				}
			}

			Set<String> listOfNoteAdded=new HashSet<String>();
			if(WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)){
				String folderObjectId=getFolderObjectIdFromEntityReference(conn,entityReference);
				APIAuditTrailLog auditTrailLog=null;

				ObjectMapper mapper=new ObjectMapper();
				String inputJson=APIOperationUtil.fetchRequestBody(request);
				
				QuotePolicyNoteRequest noteInput=mapper.readValue(inputJson, QuotePolicyNoteRequest.class);
				 //Auditing logic
				auditTrailLog=requestContext.getAuditTrailLog();
				APIOperationUtil.populateAPIAuditLog(auditTrailLog, noteInput.getSourceSystemCode(), noteInput.getSourceSystemUserId(), noteInput.getSourceSystemRequestNo(), RESOURCE_TYPE, PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
				
				validateAddNoteInputs(noteInput);

				String noteType=noteInput.getType();
					
				long noteTypeId =  getNoteTypeId(conn, noteType);
				if(noteTypeId == 0){
					String errorMessage="Invalid Note Type. Please provide a valid note type.";
					List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errorMessage));
					String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
					WebServiceLoggerUtil.logInfo(CLASS_NAME, "addQuotePolicyNote", errorMessage, new Object[] { errorMessage });
					throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
				}

				long noteId = saveNoteObjectData(user, noteInput, noteTypeId, folderObjectId, null);

				APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, entityReference, String.valueOf(noteId), "Note Added");
				confirmationMessage=new ConfirmationMessage();
				confirmationMessage.setCode("Success");
				confirmationMessage.setDescription("Note added with Id "+noteId);				
			}else{
				String errMsg = entityType + " " + entityReference + NOT_FOUND_MESSAGE;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo(CLASS_NAME, "addQuotePolicyNote", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
		}catch (APIException e) {
			WebServiceLoggerUtil.logError(CLASS_NAME, "addQuotePolicyNote", e.getLocalizedMessage(), new Object[] { e.getErrorMessage() }, null);
			throw e;
		} catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(INTERNAL_ERROR_MESSAGE));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError(CLASS_NAME, "addQuotePolicyNote", FAILED , new Object[] { e.getMessage() }, e);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		}
		return confirmationMessage;
	}

	@Override
	public Object updateQuotePolicyNote(
			String noteId) throws Exception {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		user = User.getUser(request);
		Connection conn = null;
		QuotePolicyNote updatedNote = null;
		ConfirmationMessage confirmationMessage = null;

		try{
			conn=requestContext.getConnection();

			if(checkSecurityFeatureInNoteOperations(conn)){
				if(!WorkflowUtil.checkIfUserHasTheRequiredPermission(requestContext.getUser(), APIConstant.REPLY_TO_NOTE_PERMISSION)) {
					String errMsg = user.getUserId()+" doesn't have permission to update the note.";
					List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
					String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
					WebServiceLoggerUtil.logInfo(CLASS_NAME, "updateQuotePolicyNote", errMsg, new Object[] { errMsg });
					throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
				}
			}

			if(WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)){
				String folderObjectId=getFolderObjectIdFromEntityReference(conn,entityReference);
				APIAuditTrailLog auditTrailLog=null;
				QuotePolicyNoteRequest noteInput=null;
				try{
					ObjectMapper mapper=new ObjectMapper();
					String inputJson=APIOperationUtil.fetchRequestBody(request);
					noteInput=mapper.readValue(inputJson, QuotePolicyNoteRequest.class);
				}catch(Exception exp){
					String errMsg = "Invalid JSON. Please provide a valid single note object for updation.";
					List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
					String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
					throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,exp);
				}
					//Auditing logic
				auditTrailLog=requestContext.getAuditTrailLog();
				APIOperationUtil.populateAPIAuditLog(auditTrailLog, noteInput.getSourceSystemCode(), noteInput.getSourceSystemUserId(), noteInput.getSourceSystemRequestNo(), RESOURCE_TYPE, PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
				
				long noteIdLong = 0;
				boolean isValidateNoteId = true;
		        try {
		        	if(noteId == null || noteId.trim().equalsIgnoreCase("")) {
		        		isValidateNoteId = false;
					}
		        	if(isValidateNoteId) {
		        		noteIdLong = Long.parseLong(noteId);
		        		isValidateNoteId = validateNoteId(conn, folderObjectId, noteIdLong);
		        	}
		        	
		        } catch (Exception ex) {
					String errMsg = noteId + NOT_FOUND_MESSAGE;
					List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
					String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
					WebServiceLoggerUtil.logInfo(CLASS_NAME, "deleteQuotePolicyNote", errMsg, new Object[] { errMsg });
					throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
		        }
				 
				if(!isValidateNoteId) {
					String errMsg = "Note id "+ noteId +" is invalid. Please provide valid note id";
					List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
					String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
					WebServiceLoggerUtil.logInfo(CLASS_NAME, "updateQuotePolicyNote", errMsg, new Object[] { errMsg });
					throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
				}
				
				QuotePolicyNote note = getNotesDataForEntity(conn, folderObjectId, String.valueOf(noteId)).get(0);
				
				if(note == null) {
					String errMsg = "Note id "+ noteId +" is invalid.  Please provide valid note id";
					List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
					String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
					WebServiceLoggerUtil.logInfo(CLASS_NAME, "updateQuotePolicyNote", errMsg, new Object[] { errMsg });
					throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
				}
				
				validateUpdateNoteInputs(noteInput, note);
				noteInput.setTitle(note.getTitle());
				String noteType = note.getType();
				String dueOn = noteInput.getDueOn();
				if(dueOn == null  && (noteInput.getFollowUp() == null || !"N".equalsIgnoreCase(noteInput.getFollowUp()))) {
					noteInput.setDueOn(note.getDueOn());
					noteInput.setFollowUp("Y");
				}
				if(dueOn != null  && (noteInput.getFollowUp() == null || !"N".equalsIgnoreCase(noteInput.getFollowUp()))) {
					noteInput.setFollowUp("Y");
				}
				if(note.getComplete() != null && "Yes".equalsIgnoreCase(note.getComplete())) {
					noteInput.setComplete("Y");
				}
				long noteTypeId =  getNoteTypeId(conn, noteType);
				saveNoteObjectData(user, noteInput, noteTypeId, folderObjectId, noteId);

				APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, entityReference, noteId, "Note Updated");
				confirmationMessage=new ConfirmationMessage();
				confirmationMessage.setCode("200");
				confirmationMessage.setDescription("Note with id "+ noteId +" is updated.");

				
			}else{
				String errMsg = entityType + " " + entityReference + NOT_FOUND_MESSAGE;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo(CLASS_NAME, "updateQuotePolicyNote", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
		}catch (APIException e) {
			WebServiceLoggerUtil.logError(CLASS_NAME, "updateQuotePolicyNote", e.getLocalizedMessage(), new Object[] { e.getErrorMessage() }, null);
			throw e;
		} catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(INTERNAL_ERROR_MESSAGE));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError(CLASS_NAME, "updateQuotePolicyNote", FAILED, new Object[] { e.getMessage() }, e);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		}				
		return confirmationMessage;
	}

	public List<Message> getErrorMessageList(List<String> strMessages)	{
		if(strMessages == null)	{
			return null;
		}
		List<Message> errorMessageList = new ArrayList<Message>(strMessages.size());
		for(String aMsg : strMessages)	{
			Message message = new Message();
			message.setMoreinfo(aMsg);
			errorMessageList.add(message);
		}
		return errorMessageList;
	}

	public String getFolderObjectIdFromEntityReference(Connection conn,String entityReference) throws SQLException{

		PreparedStatement ps=null;
		ResultSet rs=null;
		String objectId="";
		String queryForFolderObjectId="SELECT FOB_FOLDER_OBJECT_ID FROM FOM_FOLDER_OBJECTS"+
				" WHERE FOB_FOLDER_ID=(SELECT FEF_FOLDER_ID FROM FOM_ENTITY_FOLDERS"+
				" WHERE FEF_ENTITY_REFERENCE=? AND FEF_ENTITY_TYPE=?) AND FOB_OBJECT_ID=("+
				" SELECT FBO_OBJECT_ID FROM FOM_BASIC_OBJECTS WHERE FBO_OBJECT_NAME='Notes')";
		try {
			//Converting entity reference to new Business entity reference
			entityReference=FolderObject.getNewBusinessPolicyReferenceForAPI(conn,entityReference,User.getUser(request));
			
			ps=conn.prepareStatement(queryForFolderObjectId);
			ps.setString(1, entityReference);
			ps.setString(2, entityType);

			rs=ps.executeQuery();
			while(rs.next()){
				objectId=rs.getString("FOB_FOLDER_OBJECT_ID");
			}
		}catch (SQLException e) {
			WebServiceLoggerUtil.logError(CLASS_NAME, "getFolderObjectIdFromEntityReference", FAILED, new Object[] { e.getMessage() }, e);
			throw e;
		}finally{
			try{
				DBUtil.close(rs, ps);
			}catch(Exception e){
				WebServiceLoggerUtil.logInfo(CLASS_NAME, "getFolderObjectIdFromEntityReference", e.getLocalizedMessage(), new Object[] { e.getMessage() });	
			}
		}

		return objectId;

	}

	public List<QuotePolicyNote> getNotesDataForEntity(Connection conn,String folderObjectId, String notesId) throws Exception{
		PreparedStatement ps=null;
		ResultSet rs=null;
		PreparedStatement ps1=null;
		ResultSet rs1=null;

		List<QuotePolicyNote> notesData=new ArrayList<QuotePolicyNote>();
		long sourceSystemRequestNo=System.currentTimeMillis();

		String queryForNotesData="SELECT " + 
				"                MNO_NOTES_ID NOTEID, " + 
				"                MNO_TITLE TITLE, " + 
				"                MNT_TYPE TYPE, " + 
				"                MNO_TEXT TEXT, " + 
				"                TO_CHAR(cast(MNO_DATE_CREATED as timestamp) at time zone 'UTC', 'YYYY-MM-DD\"T\"HH24:MI:SS\"Z\"') DATE_CREATED," + 
				"                TO_CHAR(cast(MNO_DATE_MODIFIED as timestamp) at time zone 'UTC', 'YYYY-MM-DD\"T\"HH24:MI:SS\"Z\"') DATE_MODIFIED," + 
				"                TO_CHAR(cast(DECODE(MNO_DATE_MODIFIED, NULL, MNO_DATE_CREATED, MNO_DATE_MODIFIED) as timestamp) at time zone 'UTC', 'YYYY-MM-DD\"T\"HH24:MI:SS\"Z\"')" + 
				"                    DATE_LAST_MODIFIED," + 
				"                MNO_USER_CREATED USER_CREATED, " + 
				"                MNO_USER_MODIFIED USER_MODIFIED, " + 
				"                DECODE(MNO_USER_MODIFIED, NULL, MNO_USER_CREATED, MNO_USER_MODIFIED) USER_LAST_MODIFIED," + 
				"                MNO_COMPLETED_BY USER_COMPLETED," + 
				"                TO_CHAR(cast(MNO_DUE_DATE as timestamp) at time zone 'UTC', 'YYYY-MM-DD\"T\"HH24:MI:SS\"Z\"') DUE_DATE," + 
				"                TO_CHAR(cast(MNO_COMPLETION_DATE as timestamp) at time zone 'UTC', 'YYYY-MM-DD\"T\"HH24:MI:SS\"Z\"') DATE_COMPLETED," + 
				"                DECODE(MNO_DUE_DATE, NULL, 'N/A', DECODE(MNO_COMPLETION_DATE, NULL, 'No', 'Yes')) COMPLETE               " + 
				"                FROM MIS_NOTES, MIS_NOTE_TYPES, MIS_FOLDER_OBJECTS_NOTES_ASSN" + 
				"                WHERE MNT_TYPE_ID = MNO_TYPE_ID " + 
				"                AND MFN_NOTES_ID = MNO_NOTES_ID" + 
				"                AND MFN_FOLDER_OBJECT_ID = ?";

		if(notesId !=null && !notesId.equalsIgnoreCase("")){
			queryForNotesData+=" AND MIS_FOLDER_OBJECTS_NOTES_ASSN.MFN_NOTES_ID = ?";
		} else {
			queryForNotesData+=" ORDER BY NOTEID ASC";
		}

		try {
			ps=conn.prepareStatement(queryForNotesData);
			ps.setString(1, folderObjectId);
			if(notesId !=null && !notesId.equalsIgnoreCase("")){
				ps.setString(2, notesId);
			}

			rs=ps.executeQuery();
			while(rs.next()){
				QuotePolicyNote note=new QuotePolicyNote();
				note.setSourceSystemUserId(user.getUserId());
				note.setSourceSystemCode(SOURCE_SYSTEM_CODE);
				note.setSourceSystemRequestNo(sourceSystemRequestNo);
				
				note.setId(rs.getString("NOTEID"));
				note.setTitle(rs.getString("TITLE"));
				note.setType(rs.getString("TYPE"));
				note.setLastMemo(rs.getString("TEXT"));
				note.setLastModifiedBy(getUserName(rs.getString("USER_LAST_MODIFIED")));
				note.setLastModifiedOn(rs.getString("DATE_LAST_MODIFIED"));
				note.setDueOn(rs.getString("DUE_DATE"));
				note.setComplete(rs.getString("COMPLETE"));
				note.setCompletedBy(getUserName(rs.getString("USER_COMPLETED")));
				note.setCompletionOn(rs.getString("DATE_COMPLETED"));
				
				String queryForNoteHistory = "SELECT MNH_TEXT MEMO, MNH_USER_CREATED USER_CREATED, TO_CHAR(cast(MNH_DATE_CREATED as timestamp) at time zone 'UTC', 'YYYY-MM-DD\"T\"HH24:MI:SS\"Z\"') DATE_CREATED " + 
						           			 " FROM MIS_NOTES_HISTORY " + 
						           			 " WHERE MNH_NOTES_ID = ? ORDER BY DATE_CREATED DESC";
				ps1=conn.prepareStatement(queryForNoteHistory);
				ps1.setString(1, note.getId());
				rs1=ps1.executeQuery();
				List<QuotePolicyNoteHistory> noteHistory = null;
				while(rs1.next()){
					if(noteHistory == null) {
						noteHistory = new ArrayList<QuotePolicyNoteHistory>();
					}
					QuotePolicyNoteHistory history=new QuotePolicyNoteHistory();
					history.setPreviousMemo(rs1.getString("MEMO"));
					history.setUserCreated(rs1.getString("USER_CREATED"));
					history.setDateCreated(rs1.getString("DATE_CREATED"));
					noteHistory.add(history);
				}
				note.setHistory(noteHistory);
				notesData.add(note);
			}
		}catch (Exception e) {
			WebServiceLoggerUtil.logError(CLASS_NAME, "getNotesDataForEntity", FAILED, new Object[] { e.getMessage() }, e);
			throw e;
		}finally{
			try{
				DBUtil.close(rs, ps);
				DBUtil.close(rs1, ps1);
			}catch(Exception e){
				WebServiceLoggerUtil.logInfo(CLASS_NAME, "getNotesDataForEntity", e.getLocalizedMessage(), new Object[] { e.getMessage() });	
			}
		}
		return notesData;
	}

	public void validateAddNoteInputs(QuotePolicyNoteRequest noteInput) throws Exception{
		boolean gotException=false;
		String errorMessage="";
		String title = noteInput.getTitle();
		String type = noteInput.getType();
		String followUp = noteInput.getFollowUp();
		String dueOn = noteInput.getDueOn();

		List <String> errorMessages = validateCommonNoteInputs(noteInput);

		if(!errorMessages.isEmpty()) {
			gotException = true;
		}
		
		if (title == null || title.trim().equalsIgnoreCase("")) {
			errorMessage = "Note title cannot be empty. Please provide a valid title.";
			errorMessages.add(errorMessage);
			gotException = true;
		}
		if (type == null || type.trim().equalsIgnoreCase("")) {
			errorMessage = "Note type is not provided. Please provide a valid type.";
			errorMessages.add(errorMessage);
			gotException = true;
		}
		if (title != null && title.length() > 255) {
			errorMessage = "Note title cannot be more than 255 characters.";
			errorMessages.add(errorMessage);
			gotException = true;
		}
		if (dueOn != null && !"Y".equalsIgnoreCase(followUp)) {
			errorMessage = "Due On date can not be set as there is no follow up.";
			errorMessages.add(errorMessage);
			gotException = true;
		}
		String complete = noteInput.getComplete();
		if (complete != null && "Y".equalsIgnoreCase(complete)) {
			errorMessage = "Cannot mark complete.";
			errorMessages.add(errorMessage);
			gotException = true;
		}
		
		if(gotException){

			List <Message> errorMessageList = getErrorMessageList(errorMessages);
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			WebServiceLoggerUtil.logInfo(CLASS_NAME, "validateAddNoteInputs", errorMessage, new Object[] { errorMessage });
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}

	}
	
	public void validateUpdateNoteInputs(QuotePolicyNoteRequest noteInput, QuotePolicyNote note) throws Exception{
		boolean gotException=false;
		String errorMessage="";
		String title = noteInput.getTitle();
		String type = noteInput.getType();
		String followUp = noteInput.getFollowUp();
		String dueOn = noteInput.getDueOn();

		List <String> errorMessages = validateCommonNoteInputs(noteInput);

		if(!errorMessages.isEmpty()) {
			gotException = true;
		}
		if (title != null) {
			errorMessage = "Note title is non updatable.";
			errorMessages.add(errorMessage);
			
		}
		if (type != null) {
			errorMessage = "Note type is non updatable";
			errorMessages.add(errorMessage);
			gotException = true;
		}
		if (followUp != null && "Yes".equalsIgnoreCase(note.getComplete())) {
			errorMessage = "Note is completed so cannot change follow up value.";
			errorMessages.add(errorMessage);
			gotException = true;
		}
		if (dueOn != null && "Yes".equalsIgnoreCase(note.getComplete())) {
			errorMessage = "Note is completed so cannot change due on date.";
			errorMessages.add(errorMessage);
			gotException = true;
		}
		if (dueOn != null && (note.getDueOn() == null && !"Y".equalsIgnoreCase(followUp))) {
			errorMessage = "Due On date can not be set as there is no follow up required on this note.";
			errorMessages.add(errorMessage);
			gotException = true;
		}
		if (dueOn != null && "N".equalsIgnoreCase(followUp)) {
			errorMessage = "Due On date can not be set as there is no follow up required on this note.";
			errorMessages.add(errorMessage);
			gotException = true;
		}
		String complete = noteInput.getComplete();
		if (complete != null && "Y".equalsIgnoreCase(complete) && note.getDueOn() == null) {
			errorMessage = "Can not mark complete as there is no follow up required on this note.";
			errorMessages.add(errorMessage);
			gotException = true;
		}
		if (complete != null && "Y".equalsIgnoreCase(complete) && "Yes".equalsIgnoreCase(note.getComplete())) {
			errorMessage = "Note is already completed.";
			errorMessages.add(errorMessage);
			gotException = true;
		}
		if (complete != null && !"Y".equalsIgnoreCase(complete)) {
			errorMessage = "Complete value is incorrect. Please provide correct complete value.";
			errorMessages.add(errorMessage);
			gotException = true;
		}
		
		
		if(gotException){
			List <Message> errorMessageList = getErrorMessageList(errorMessages);
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			WebServiceLoggerUtil.logInfo(CLASS_NAME, "validateUpdateNoteInputs", errorMessage, new Object[] { errorMessage });
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}

	}
	
	public List <String> validateCommonNoteInputs(QuotePolicyNoteRequest noteInput) {
		String errorMessage="";
		String text = noteInput.getMemo();
		String followUp = noteInput.getFollowUp();
		String dueOn = noteInput.getDueOn();
		Boolean isDueOn = false;
        SimpleDateFormat dateFormat1 = new SimpleDateFormat("MM/dd/yyyy HH:mm");
        SimpleDateFormat dateFormat2 = new SimpleDateFormat("MM/dd/yyyy");

		List <String> errorMessages = new ArrayList<String>();
		
		if (text == null || text.trim().equalsIgnoreCase("")) {
			errorMessage = "Note memo is not provided. Please provide a memo.";
			errorMessages.add(errorMessage);
		}
		
		if (followUp != null && !("Y".equalsIgnoreCase(followUp) || "N".equalsIgnoreCase(followUp))) {
			errorMessage = "Follow up value is incorrect. Please provide correct follow up value.";
			errorMessages.add(errorMessage);
		}

		if (followUp != null && "Y".equalsIgnoreCase(followUp)) {
			isDueOn = true;
			if (dueOn == null || dueOn.trim().equalsIgnoreCase("")) {
				errorMessage = "Due on date is not provided. Please provide a valid due date.";
				errorMessages.add(errorMessage);
				isDueOn = false;
			}

			if (isDueOn && !dueOn.trim().equals("")) {
				Timestamp dueDate = null;
				try {
					dueDate = new java.sql.Timestamp((dateFormat1.parse(dueOn)).getTime());
				} catch (Exception ex1) {
					try {
						dueDate = new java.sql.Timestamp((dateFormat2.parse(dueOn)).getTime());
					} catch (Exception ex2) {
						errorMessage = "Invalid due date: " + dueOn + ".";
						errorMessages.add(errorMessage);
					}
				}
			}
		}
		
		if(text != null && text.length()>4000){
			errorMessage="Note memo cannot be more than 4000 characters.";
			errorMessages.add(errorMessage);
		}
		
		return errorMessages;

	}

	public boolean checkSecurityFeatureInNoteOperations(Connection conn){
		String securityCheckEnabled=APIOperationUtil.getProductGlobalOptionValue(conn, APIConstant.NOTES_SECURITY_CHECK_GLOBAL_OPTION, true, entityReference);
		return "Y".equalsIgnoreCase(securityCheckEnabled)?true:false;

	}
	
	public String getUserName(String user) throws ELException {
    	String userName = null;
    	try{
    		String principalName = user; 
    		String realmName = null;
    		AdminX adminX = new AdminX();
    		//check userId contains '@' character, if contains the split it and get the principalName and realm name.
    		if(user != null && user.contains("@")){
    			String[] userIdWithDomain = user.split("@");
    			principalName = userIdWithDomain[0];
    		}else{
    			return user;
    		}

    		if(user.contains("@")){
        		String[] userIdWithDomain = user.split("@");
        		realmName = userIdWithDomain[1];
        	}

    		Principal userProfile = adminX.getUser(realmName, principalName);
    		
    		userName = userProfile.getName();
    	}catch(Exception exc){
    		throw new ELException("Error getting userProfile.", exc);
    	}
    	return userName;
    }
	

	public String getCustomerCodeFromUser(User user){ 
		final CustomerConfigUtil ccu = CustomerConfigUtil.getInstance();
		String domain = user.getDomain();
		return ccu.getCustomerCode(domain);
	}

	protected long saveNoteObjectData(User user, QuotePolicyNoteRequest noteRequest, long typeId, String strFolderObjectId, String strNoteId) throws Exception {

		long folderObjectId = 0;

		try {
			folderObjectId = Long.parseLong(strFolderObjectId);
		} catch (Exception ex) {
			throw new Exception("Invalid folderObjectId: " + strFolderObjectId);
		}

		long noteId = 0;

		if (strNoteId != null) {
			noteId = Long.parseLong(strNoteId);
		}

		String title = noteRequest.getTitle();

		String strDueDate = noteRequest.getDueOn();
		SimpleDateFormat dateFormat1 = new SimpleDateFormat("MM/dd/yyyy HH:mm");
		SimpleDateFormat dateFormat2 = new SimpleDateFormat("MM/dd/yyyy");

		String noteText = noteRequest.getMemo();
		String reminder = noteRequest.getFollowUp();
		String complete = noteRequest.getComplete();

		Timestamp dueDate = null;

		if ((strDueDate != null) && !strDueDate.trim().equals("")) {
			try {
				dueDate = new java.sql.Timestamp((dateFormat1.parse(strDueDate)).getTime());
			} catch (Exception ex1) {
				try {
					dueDate = new java.sql.Timestamp((dateFormat2.parse(strDueDate)).getTime());
				} catch (Exception ex2) {
					throw new ExceptionImpl(ExceptionImpl.NON_FATAL, "Invalid due date: " + strDueDate, null);
				}
			}
		}

		Notes notes = new Notes();
		notes.setTitle(title);
		notes.setTypeId(typeId);
		notes.setText(noteText);
		notes.setDueDate(dueDate);
		
        if (reminder != null && "Y".equalsIgnoreCase(reminder)) {
            if (complete != null && "Y".equalsIgnoreCase(complete)) {
                notes.setCompletionDate(new java.sql.Timestamp(
                        System.currentTimeMillis()));
                notes.setCompletedBy(user.getFullName());
            } else {
                notes.setCompletionDate(null);
                notes.setCompletedBy("");
            }
        } else {
            notes.setDueDate(null);
            notes.setCompletionDate(null);
            notes.setCompletedBy("");
        }

        if ((strNoteId != null) && !strNoteId.equals("")) {
            notes.setNotesId(noteId);
            notes.update(user);
        } else {
            noteId = notes.insert(user);

            FolderObjectsNotesAssn fnAssn = new FolderObjectsNotesAssn();
            fnAssn.setFolderObjectId(folderObjectId);
            fnAssn.setNotesId(noteId);
            fnAssn.insert(user);
        }
        
        return noteId;
	}
	
	public int getNoteTypeId(Connection conn,String noteType) throws SQLException{

		PreparedStatement ps=null;
		ResultSet rs=null;
		int typeId = 0;
		String queryForNoteType="SELECT MNT_TYPE_ID FROM MIS_NOTE_TYPES WHERE MNT_TYPE = ?";
		try {
			ps=conn.prepareStatement(queryForNoteType);
			ps.setString(1, noteType);

			rs=ps.executeQuery();
			while(rs.next()){
				typeId=rs.getInt("MNT_TYPE_ID");
			}
		}catch (SQLException e) {
			WebServiceLoggerUtil.logError(CLASS_NAME, "getNoteTypeId", FAILED, new Object[] { e.getMessage() }, e);
			throw e;
		}finally{
			try{
				DBUtil.close(rs, ps);
			}catch(Exception e){
				WebServiceLoggerUtil.logInfo(CLASS_NAME, "getNoteTypeId", e.getLocalizedMessage(), new Object[] { e.getMessage() });	
			}
		}

		return typeId;

	}
	
	public boolean validateNoteId(Connection conn,String strfolderObjectId,long noteIdLong) throws SQLException{

		PreparedStatement ps=null;
		ResultSet rs=null;
		String validNoteId = "N";
		boolean valid = false;
		String queryForNoteId="SELECT DECODE(COUNT(1),0,'N','Y') VALID_NOTE_ID FROM MIS_FOLDER_OBJECTS_NOTES_ASSN WHERE MFN_FOLDER_OBJECT_ID = ? AND MFN_NOTES_ID = ?";
		try {
			ps=conn.prepareStatement(queryForNoteId);
			ps.setString(1, strfolderObjectId);
			ps.setLong(2, noteIdLong);
			rs=ps.executeQuery();
			while(rs.next()){
				validNoteId=rs.getString("VALID_NOTE_ID");
				if(validNoteId != null && "Y".equalsIgnoreCase(validNoteId)) {
					valid = true;
				} 
			}
		}catch (SQLException e) {
			WebServiceLoggerUtil.logError(CLASS_NAME, "validateNoteId", FAILED, new Object[] { e.getMessage() }, e);
			throw e;
		}finally{
			try{
				DBUtil.close(rs, ps);
			}catch(Exception e){
				WebServiceLoggerUtil.logInfo(CLASS_NAME, "validateNoteId", e.getLocalizedMessage(), new Object[] { e.getMessage() });	
			}
		}
		return valid;
	}

}

