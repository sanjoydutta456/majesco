package com.coverall.mic.rest.policy.api.service.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import org.apache.commons.lang.StringUtils;

import oracle.jdbc.OracleTypes;

import com.coverall.mic.rest.document.mgmt.model.DocumentPackage;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.QuotePolicyPaymentPlanInformation;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyPaymentPlan;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mic.rest.policy.api.service.util.WorkflowUtil;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.util.DBUtil;
import com.coverall.mt.http.User;

public class QuotePolicyPaymentPlanInformationImpl implements QuotePolicyPaymentPlanInformation {
	
	private HttpServletRequest request;
	private String entityType;
	private String entityReference;
	private User user;
	
	private String paymentPlanInformationQuery="SELECT pp.payment_plan_id payPlanId,pp.payment_plan_code payPlanCode,pp.descr payPlanDescription,"+
											   "pp.NUM_OF_INSTALLMENT numberOfInstallment, pp.deposit_amt depositAmount,pp.min_premium minPremium,"+
											   "NVL((SELECT NVL(DUE_DAYS_FOR_NB ,0) FROM INSTALLMENT_PERCENTAGES WHERE PAYMENT_PLAN_ID =pp.PAYMENT_PLAN_ID AND INSTALLMENT_ID=1 AND rownum=1),0) installmentIntervalDays,"+
											   "pp.deposit_pct depositPercentage,NVL(pp.rounding,'N') rounding,pp.EFF_DT effectiveDate, pp.EXP_DT expirationDate, NVL(pp.USR_MDFD,pp.USR_CRTD) userModified,"+
											   "NVL(pp.DT_MDFD,pp.DT_CRTD) modifiedDate FROM payment_plans pp,VALID_PAY_OPTIONS vpo WHERE vpo.PAYMENT_PLAN_ID_1=PAYMENT_PLAN_ID"+
											   " AND vpo.VALID_PAY_OPTION_ID IN (";			 
	
	public QuotePolicyPaymentPlanInformationImpl(HttpServletRequest request,String entityType,String entityReference) {
		super();
		this.entityReference = entityReference;
		this.entityType = entityType;
		this.request=request;
		this.user=user.getUser(request);
	}
	
	@Override
	public Object getApplicablePaymentPlans() throws Exception {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		Connection conn=null;
		ResultSet rs=null;
		CallableStatement callStmt=null;
		ResultSet rsPaymentPlan=null;
		PreparedStatement stmtPaymentPlan=null;
		ArrayList<QuotePolicyPaymentPlan> payPlanInformation=new ArrayList<QuotePolicyPaymentPlan>();
		long sourceSystemRequestNo=System.currentTimeMillis();
		try{
			conn=requestContext.getConnection();
			if(!WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)){
				String errMsg = entityType + " " + entityReference + " was not found. Please check input parameters.";
				List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("QuotePolicyPaymentPlanInformationImpl", "getApplicablePaymentPlans", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}

			//Call all applicable payment plans
			callStmt = conn.prepareCall("{ ? = call k_policy_financial_management.f_get_available_pay_plans(?,?,?)}");
			callStmt.registerOutParameter(1, OracleTypes.CURSOR);
			callStmt.setString(2, entityType);
			callStmt.setString(3, entityReference);
			callStmt.setString(4, user.getFullName());
			callStmt.execute();

			rs = (ResultSet) callStmt.getObject(1);
			List<String> listOfValidPaymentPlan=new ArrayList<String>();
			while (rs.next()) {
					String optionId = rs.getString("MIN(PAY_OPTION_ID)");
					listOfValidPaymentPlan.add(optionId);
			}
			String validOptionIdList=StringUtils.join(listOfValidPaymentPlan, ',');
			paymentPlanInformationQuery+=validOptionIdList+")";
			stmtPaymentPlan=conn.prepareStatement(paymentPlanInformationQuery);
			rsPaymentPlan=stmtPaymentPlan.executeQuery();
			
			while(rsPaymentPlan.next()){
				QuotePolicyPaymentPlan payPlan=new QuotePolicyPaymentPlan();
				payPlan.setDepositAmount(rsPaymentPlan.getString("depositAmount"));
				payPlan.setDepositPercentage(rsPaymentPlan.getString("depositPercentage"));
				payPlan.setEffectiveDate(rsPaymentPlan.getString("effectiveDate"));
				payPlan.setExpirationDate(rsPaymentPlan.getString("expirationDate"));
				payPlan.setInstallmentIntervalDays(rsPaymentPlan.getString("installmentIntervalDays"));
				payPlan.setMinPremium(rsPaymentPlan.getString("minPremium"));
				payPlan.setModifiedDate(rsPaymentPlan.getString("modifiedDate"));
				payPlan.setNumberOfInstallment(rsPaymentPlan.getString("numberOfInstallment"));
				payPlan.setPayPlanCode(rsPaymentPlan.getString("payPlanCode"));
				payPlan.setPayPlanDescription(rsPaymentPlan.getString("payPlanDescription"));
				payPlan.setPayPlanId(rsPaymentPlan.getInt("payPlanId"));
				payPlan.setRounding(rsPaymentPlan.getString("rounding"));
				payPlan.setSourceSystemCode(SOURCE_SYSTEM_CODE);
				payPlan.setSourceSystemUserId(user.getUserId());
				payPlan.setSourceSystemRequestNo(sourceSystemRequestNo);
				payPlanInformation.add(payPlan);
			}
		}catch(Exception e){
			WebServiceLoggerUtil.logError("QuotePolicyPaymentPlanInformationImpl", "getApplicablePaymentPlans", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw e;
		}finally{
			try{
				DBUtil.close(rs, callStmt);
			}catch(Exception e){
				WebServiceLoggerUtil.logError("QuotePolicyPaymentPlanInformationImpl", "getApplicablePaymentPlans", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			}
			try{
				DBUtil.close(rsPaymentPlan, stmtPaymentPlan);
			}catch(Exception e){
				WebServiceLoggerUtil.logError("QuotePolicyPaymentPlanInformationImpl", "getApplicablePaymentPlans", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			}
		}
		return payPlanInformation;

	}

}
