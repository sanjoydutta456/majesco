package com.coverall.mic.rest.policy.api.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import com.coverall.el.Expression;
import com.coverall.el.FunctionResolver;
import com.coverall.el.VariableResolver;
import com.coverall.el.function.DefaultFunctionResolver;
import com.coverall.exceptions.ELException;
import com.coverall.exceptions.ELParseException;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.QuotePolicySearchService;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyPagination;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicySearch;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicySearchResult;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mt.el.variable.VariableResolverImpl;
import com.coverall.mt.http.User;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.mt.xml.DOMUtil;
import com.coverall.util.DBUtil;
import com.coverall.util.GeneralUtil;


public class QuotePolicySearchServiceImpl implements QuotePolicySearchService{
	//private static LinkedHashMap<String, QuotePolicySearch> cachedResults=new LinkedHashMap<String, QuotePolicySearch>();
	public final String VERSION_END_POINT="/version";
	public final String LIST_END_POINT="/list";
	//private static int cacheSize=100;
	public String policyNo;
	public String product;
	public String exactMatch;
	public int pageSize;
	public int pageNumber;
	//private String correlationid;
	public String effectiveStartDateRange;
	public String effectiveEndDateRange;
	public String company;
	public String agencyNumber;
	public String agencyName;
	public String marketManager;
	public String insured;
	public String underwriter;
	public String status;
	public HttpServletRequest request;

	public User user;

	public final String dlsStringQuotePolicy="${var:user('DLSFILTER', ' AND ', '{operator=OPERATOR,state=STATE,underwriter=UNDERWRITER_CODE, producer=AGENT_CODE,insured=INSURED_NAME, policyref=ENTITY_REFERENCE,company=COMPANY_CODE,branch=PRODUCT_CODE,subproducer=SUB_AGENT_ID,programcode=PROGRAM_CODE}')}";
	public String quotePolicySearchQuery="SELECT * FROM (SELECT qp.entity_reference entityReference,qp.entity_type entityType,qp.display_policy_number policyNumber,TO_CHAR(qp.effective_date,'YYYY-MM-DD') effectiveDate,TO_CHAR(qp.effective_date,'YYYYMMDD') effective_date_sort,"+
								  "TO_CHAR(qp.expiration_date,'YYYY-MM-DD') expirationDate,NVL(ins.BUSINESS_NAME, ins.SURNAME || ' '|| ins.FIRST_NAME) insuredName,ins_address.line_1 ||','|| ins_address.city ||','|| ins_address.state_code ||','|| ins_address.zip_code insuredAddress,"+
								  "ins.doing_business_as insuredDBA,ins.fein insuredFEIN,(select ins_contact.phone_1 from vw_mis_contacts ins_contact where ins_contact.entity_reference = qp.entity_reference AND ins_contact.entity_type	 = qp.entity_type"+
								  " AND ins_contact.insured_contact  = ins.gid) insuredPhone ,(select ins_contact.e_mail from vw_mis_contacts ins_contact where ins_contact.entity_reference = qp.entity_reference AND ins_contact.entity_type	 = qp.entity_type"+
								  " AND ins_contact.insured_contact  = ins.gid) insuredEmail,ins.INSURED_TYPE insuredType,prd.name agencyName,prd.PRODUCER_CODE agencyNumber,prd.market_manager marketManager,"+
								  " qp.market_segment_code marketSegment, qp.product_name product,qp.full_term_premium fullTermPrem,TRIM(TO_CHAR(NVL(written_premium,0) + NVL(total_fterm_surcharge,0) + NVL(total_fterm_taxes,0) + NVL(total_fterm_fee,0), '999,999,999,990.00')) totalWrittenPrem,"+
								  " prd_address.line_1 ||','||prd_address.city ||','||prd_address.state_code ||','||prd_address.zip_code agencyAddress,prd_contact.phone_1 agencyPhone,qp.company_name companyName,"+
								  //Not known value
								  " '' currentDue,"+
								  " decode (qp.underwriter_code, null, 'NA', (Select sun_underwriter_name from shl_underwriters und where und.sun_underwriter_code = qp.underwriter_code) ) underwriter,"+
								  " decode (qp.underwriter_code, null, 'NA', (Select sun_telephone from shl_underwriters und where und.sun_underwriter_code = qp.underwriter_code) ) underwriterPhone,"+
								  " K_Workflow_Activity_Management.f_get_status_wrapper(qp.entity_type, qp.entity_reference) status,"+
								  //DLS FILTER THINGS
								  "qp.PROGRAM_CODE PROGRAM_CODE,qp.ENTITY_REFERENCE ENTITY_REFERENCE,qp.COMPANY_CODE COMPANY_CODE,qp.product_code PRODUCT_CODE,qp.underwriter_code underwriter_code,"+
					              "(SELECT MPO_OPERATOR_CODE FROM mis_policies where mpo_policy_reference=qp.entity_reference) operator,(SELECT mpo_policy_state FROM mis_policies where mpo_policy_reference=qp.entity_reference) state,"+
					              "(SELECT MPO_AGENT_ID FROM mis_policies where mpo_policy_reference=qp.entity_reference) AGENT_CODE,(SELECT mpo_insured_name FROM mis_policies where mpo_policy_reference=qp.entity_reference) INSURED_NAME,"+
					              "(SELECT MPO_SUB_AGENT_ID FROM mis_policies where mpo_policy_reference=qp.entity_reference) SUB_AGENT_ID"+ 
								  " FROM ev_mis_quote_policies qp,vw_mis_insureds ins,vw_mis_addresses ins_address,"+
								  " vw_mis_producers prd,vw_mis_addresses prd_address,vw_mis_contacts prd_contact WHERE prd.entity_reference=qp.entity_reference AND prd.entity_type= qp.entity_type AND ins.entity_reference= qp.entity_reference"+
								  " AND ins.entity_type=qp.entity_type AND ins.fk_column_name = 'POLICY_INSURED' AND prd_address.entity_reference = qp.entity_reference AND prd_address.entity_type=qp.entity_type	AND prd_address.producer_address = prd.gid"+
								  " AND ins_address.entity_reference = qp.entity_reference AND ins_address.entity_type=qp.entity_type AND ins_address.insured_address=ins.gid AND prd_contact.entity_reference (+)= qp.entity_reference"+
								  " AND prd_contact.entity_type (+)= qp.entity_type AND prd_contact.producer_contact (+)= prd.gid)";

	public QuotePolicySearchServiceImpl(HttpServletRequest request,String exactMatch,String policyNo, String product, String entityType, int pageSize, int pageNumber,
			String correlationid, String effectiveStartDateRange,
			String effectiveEndDateRange, String company, String agencyNumber,
			String agencyName, String marketManager, String insured,
			String underwriter, String status) {
		super();
		this.request=request;
		this.exactMatch=exactMatch;
		this.policyNo=policyNo;
		this.product=product;
		this.pageNumber=pageNumber;
		this.pageSize=pageSize;
		//this.correlationid=correlationid;
		this.effectiveStartDateRange=effectiveStartDateRange;
		this.effectiveEndDateRange=effectiveEndDateRange;
		this.company=company;
		this.agencyNumber=agencyNumber;
		this.agencyName=agencyName;
		this.marketManager=marketManager;
		this.insured=insured;
		this.underwriter=underwriter;
		this.status=status;
		if(pageSize==0){
			this.pageSize=10;
		}
		if(pageNumber==0){
			this.pageNumber=1;
		}

		user = User.getUser(request);
	}

	@Override
	public QuotePolicySearch getQuotePolicySearchResult() throws APIException {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		QuotePolicySearch resultPayload=new QuotePolicySearch();
		ArrayList<QuotePolicySearchResult> allResults=new ArrayList<QuotePolicySearchResult>();
		QuotePolicyPagination pagination=new QuotePolicyPagination();
		
		//This url is used for producing pagination links
		String url = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getRequestURI()+"?"+request.getQueryString();

		Connection conn = null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		
		try{
			if(!validateInputParameters()){
				String errMsg =  "Either effectiveStartDateRange is missing or exactMatch(Y|N), effectiveStartDateRange(yyyy-mm-dd), effectiveEndDateRange(yyyy-mm-dd) are not in correct format. Please check these input parameters.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("QuotePolicySearchServiceImpl", "getQuotePolicySearchResult", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}

			conn=requestContext.getConnection();
			
			Map<String, Object> mapSQL = createSQLQueryOnBasisOfParameters(true);
			
			String queryWithConditions = String.valueOf(mapSQL.get("QUERY"));
			List<String> variableList = (List<String>) mapSQL.get("VARIABLE");
			
			pagination=APIOperationUtil.populatePaginationInformation(url, conn, queryWithConditions, pageNumber, pageSize, variableList);
			
			variableList.add(pagination.getEndIndex());
			variableList.add(pagination.getStartIndex());
			
			String finalExecutableQuery="SELECT  *  FROM (SELECT ROWNUM rnum, z.* FROM ("+queryWithConditions+") z WHERE ROWNUM<=?) WHERE rnum>=?";
			ps=conn.prepareStatement(finalExecutableQuery);
			
			GeneralUtil.bindVariablesToStatement(variableList, ps, 0);
			
			rs=ps.executeQuery();
			//int count=0;
			while(rs.next()){
				QuotePolicySearchResult result=new QuotePolicySearchResult();

				result.setEntityReference(rs.getString("entityReference"));
				result.setPolicyNumber(rs.getString("policyNumber"));
				result.setAgencyAddress(rs.getString("agencyAddress"));
				result.setAgencyName(rs.getString("agencyName"));
				result.setAgencyNumber(rs.getString("agencyNumber"));
				result.setCurrentDue(convertStringToDouble(rs.getString("currentDue")));
				result.setEffectiveDate(rs.getString("effectiveDate"));
				result.setEntityType(rs.getString("entityType"));
				result.setExpirationDate(rs.getString("expirationDate"));
				result.setFullTermPrem(convertStringToDouble(rs.getString("fullTermPrem")));
				result.setInsuredAddress(rs.getString("insuredAddress"));
				result.setAgencyPhone(rs.getString("agencyPhone"));
				result.setInsuredDBA(rs.getString("insuredDBA"));
				result.setInsuredEmail(rs.getString("insuredEmail"));
				result.setInsuredFEIN(rs.getString("insuredFEIN"));
				result.setInsuredName(rs.getString("insuredName"));
				result.setInsuredPhone(rs.getString("insuredPhone"));
				result.setInsuredType(rs.getString("insuredType"));
				result.setMarketManager(rs.getString("marketManager"));
				result.setMarketSegment(rs.getString("marketSegment"));
				result.setPolicyNumber(rs.getString("policyNumber"));
				result.setProduct(rs.getString("product"));
				result.setStatus(rs.getString("status"));
				result.setTotalWrittenPrem(convertStringToDouble(rs.getString("totalWrittenPrem")));
				result.setUnderwriter(rs.getString("underwriter"));
				result.setUnderwriterPhone(rs.getString("underwriterPhone"));
				//count++;

				allResults.add(result);
			}

			resultPayload.setSearchResults(allResults);
			resultPayload.setPagination(pagination);
			resultPayload.setAllResults(allResults);
		}catch (APIException e) {
			throw e;
		}catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError("QuotePolicySearchServiceImpl", "getQuotePolicySearchResult", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		}finally{
			try {
				DBUtil.close(rs, ps);
			} catch (SQLException e) {
				WebServiceLoggerUtil.logInfo("QuotePolicySearchServiceImpl", "getQuotePolicySearchResult", e.getLocalizedMessage(), new Object[] { e.getMessage() });
			}
		 }
		
		return resultPayload;
	}

	private List<Message> getErrorMessageList(List<String> strMessages)	{
		if(strMessages == null)	{
			return null;
		}
		List<Message> errorMessageList = new ArrayList<Message>(strMessages.size());
		for(String aMsg : strMessages)	{
			Message message = new Message();
			message.setMoreinfo(aMsg);
			errorMessageList.add(message);
		}
		return errorMessageList;
	}

	private boolean validateInputParameters(){
		boolean valid=true;

		if(exactMatch!=null){
			if(!(exactMatch.equalsIgnoreCase("Y") || exactMatch.equalsIgnoreCase("N"))){
				valid=false;
			}
		}else{
			exactMatch="N";
		}

		if(effectiveStartDateRange!=null){
			if(!effectiveStartDateRange.matches("^([0-9][0-9])?[0-9][0-9]-(0[0-9]||1[0-2])-([0-2][0-9]||3[0-1])$")){
				valid=false;
			}
		}else{
			valid=false;
		}

		if(effectiveEndDateRange!=null){
			if(!effectiveEndDateRange.matches("^([0-9][0-9])?[0-9][0-9]-(0[0-9]||1[0-2])-([0-2][0-9]||3[0-1])$")){
				valid=false;
			}
		}

		return valid;
	}


	public String createSQLQueryOnBasisOfParameters(){
		StringBuilder queryConditions=new StringBuilder(" WHERE 1=1");

		if(exactMatch!=null && exactMatch.equalsIgnoreCase("Y")){
			if(this.policyNo!=null && !this.policyNo.equalsIgnoreCase("")){
				queryConditions.append(" AND UPPER(policyNumber)=UPPER('"+this.policyNo+"')");
			}
			queryConditions.append(" AND to_date(effectiveDate,'yyyy-mm-dd')>=to_date('"+this.effectiveStartDateRange+"','yyyy-mm-dd')");

			if(this.effectiveEndDateRange!=null){
				queryConditions.append(" AND to_date(effectiveDate,'yyyy-mm-dd')<=to_date('"+this.effectiveEndDateRange+"','yyyy-mm-dd')");
			}
			
			if(this.product!=null && !this.product.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(product)=upper('"+this.product+"')");
			}

			if(this.agencyNumber!=null && !this.agencyNumber.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(agencyNumber)=upper('"+this.agencyNumber+"')");
			}

			if(this.agencyName!=null && !this.agencyName.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(agencyName)=upper('"+this.agencyName+"')");
			}
			if(this.marketManager!=null && !this.marketManager.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(marketManager)=upper('"+this.marketManager+"')");
			}
			if(this.insured!=null && !this.insured.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(insuredName)=upper('"+this.insured+"')");
			}
			if(this.underwriter!=null && !this.underwriter.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(underwriter)=upper('"+this.underwriter+"')");
			}
			if(this.company!=null && !this.company.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(companyName)=upper('"+this.company+"')");
			}
			if(this.status!=null && !this.status.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(status)=upper('"+this.status+"')");
			}
		}else{

			if(this.policyNo!=null && !this.policyNo.equalsIgnoreCase("")){
				queryConditions.append(" AND UPPER(policyNumber) LIKE (UPPER('%"+this.policyNo+"%'))");
			}
			queryConditions.append(" AND to_date(effectiveDate,'yyyy-mm-dd')>=to_date('"+this.effectiveStartDateRange+"','yyyy-mm-dd')");

			if(this.effectiveEndDateRange!=null){
				queryConditions.append(" AND to_date(effectiveDate,'yyyy-mm-dd')<=to_date('"+this.effectiveEndDateRange+"','yyyy-mm-dd')");
			}
			
			if(this.product!=null && !this.product.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(product) LIKE (upper('%"+this.product+"%'))");
			}

			if(this.agencyNumber!=null && !this.agencyNumber.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(agencyNumber) LIKE (upper('%"+this.agencyNumber+"%'))");
			}

			if(this.agencyName!=null && !this.agencyName.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(agencyName) LIKE (upper('%"+this.agencyName+"%'))");
			}
			if(this.marketManager!=null && !this.marketManager.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(marketManager) LIKE (upper('%"+this.marketManager+"%'))");
			}
			if(this.insured!=null && !this.insured.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(insuredName) LIKE (upper('%"+this.insured+"%'))");
			}
			if(this.underwriter!=null && !this.underwriter.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(underwriter) LIKE (upper('%"+this.underwriter+"%'))");
			}
			if(this.company!=null && !this.company.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(companyName) LIKE (upper('%"+this.company+"%'))");
			}
			if(this.status!=null && !this.status.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(status) LIKE (upper('%"+this.status+"%'))");
			}
		}

		queryConditions.append(resolveDLSExpression(dlsStringQuotePolicy));
		
		queryConditions.append(" ORDER BY effective_date_sort asc");

		return quotePolicySearchQuery+" "+queryConditions.toString();
	}
	
	public Map<String, Object> createSQLQueryOnBasisOfParameters(boolean bindVariableStatus){
		Map<String, Object> mapSQL = new HashMap<String, Object>();
		List<String> variableList = new ArrayList<String>();
		
		StringBuilder queryConditions=new StringBuilder(" WHERE 1=1");

		if(exactMatch!=null && exactMatch.equalsIgnoreCase("Y")){
			if(this.policyNo!=null && !this.policyNo.equalsIgnoreCase("")){
				queryConditions.append(" AND UPPER(policyNumber)=UPPER(?)");
				variableList.add(this.policyNo);
			}
			queryConditions.append(" AND to_date(effectiveDate,'yyyy-mm-dd')>=to_date(?,'yyyy-mm-dd')");
			variableList.add(this.effectiveStartDateRange);

			if(this.effectiveEndDateRange!=null){
				queryConditions.append(" AND to_date(effectiveDate,'yyyy-mm-dd')<=to_date(?,'yyyy-mm-dd')");
				variableList.add(this.effectiveEndDateRange);
			}
			
			if(this.product!=null && !this.product.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(product)=upper(?)");
				variableList.add(this.product);
			}

			if(this.agencyNumber!=null && !this.agencyNumber.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(agencyNumber)=upper(?)");
				variableList.add(this.agencyNumber);
			}

			if(this.agencyName!=null && !this.agencyName.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(agencyName)=upper(?)");
				variableList.add(this.agencyName);
			}
			if(this.marketManager!=null && !this.marketManager.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(marketManager)=upper(?)");
				variableList.add(this.marketManager);
			}
			if(this.insured!=null && !this.insured.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(insuredName)=upper(?)");
				variableList.add(this.insured);
			}
			if(this.underwriter!=null && !this.underwriter.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(underwriter)=upper(?)");
				variableList.add(this.underwriter);
			}
			if(this.company!=null && !this.company.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(companyName)=upper(?)");
				variableList.add(this.company);
			}
			if(this.status!=null && !this.status.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(status)=upper(?)");
				variableList.add(this.status);
			}
		}else{

			if(this.policyNo!=null && !this.policyNo.equalsIgnoreCase("")){
				queryConditions.append(" AND UPPER(policyNumber) LIKE (UPPER(?))");
				variableList.add("%" + this.policyNo + "%");
			}
			queryConditions.append(" AND to_date(effectiveDate,'yyyy-mm-dd')>=to_date(?,'yyyy-mm-dd')");
			variableList.add(this.effectiveStartDateRange);

			if(this.effectiveEndDateRange!=null){
				queryConditions.append(" AND to_date(effectiveDate,'yyyy-mm-dd')<=to_date(?,'yyyy-mm-dd')");
				variableList.add(this.effectiveEndDateRange);
			}
			
			if(this.product!=null && !this.product.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(product) LIKE (upper(?))");
				variableList.add("%" + this.product + "%");
			}

			if(this.agencyNumber!=null && !this.agencyNumber.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(agencyNumber) LIKE (upper(?))");
				variableList.add("%" + this.agencyNumber + "%");
			}

			if(this.agencyName!=null && !this.agencyName.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(agencyName) LIKE (upper(?))");
				variableList.add("%" + this.agencyName + "%");
			}
			if(this.marketManager!=null && !this.marketManager.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(marketManager) LIKE (upper(?))");
				variableList.add("%" + this.marketManager + "%");
			}
			if(this.insured!=null && !this.insured.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(insuredName) LIKE (upper(?))");
				variableList.add("%" + this.insured + "%");
			}
			if(this.underwriter!=null && !this.underwriter.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(underwriter) LIKE (upper(?))");
				variableList.add("%" + this.underwriter + "%");
			}
			if(this.company!=null && !this.company.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(companyName) LIKE (upper(?))");
				variableList.add("%" + this.company + "%");
			}
			if(this.status!=null && !this.status.equalsIgnoreCase("")){
				queryConditions.append(" AND upper(status) LIKE (upper(?))");
				variableList.add("%" + this.status + "%");
			}
		}

		queryConditions.append(resolveDLSExpression(dlsStringQuotePolicy));
		
		queryConditions.append(" ORDER BY effective_date_sort asc");
		
		mapSQL.put("QUERY", (quotePolicySearchQuery+" "+queryConditions.toString()));
		mapSQL.put("VARIABLE", variableList);

		return mapSQL;
	}

	public String resolveDLSExpression(String dlsExpressionString){
		String resolvedExpression=""; 
		HashMap variableMap = new HashMap();
		variableMap.put(VariableResolverImpl.USER_PARAMETER, user);
		variableMap.put(VariableResolverImpl.SESSION_PARAMETER, user);

		try {
			VariableResolver varResolver = new VariableResolverImpl(variableMap);
			FunctionResolver funcResolver = new DefaultFunctionResolver();

			HashMap expressionMap = new HashMap();


			Expression exp=null;

			exp = new Expression(
					dlsExpressionString,
					null,
					null,
					varResolver,
					funcResolver,
					DOMUtil.GET_MAPDIRECTION,
					expressionMap,
					true);
			resolvedExpression=exp.getValue();
		} catch (ELParseException e) {
			WebServiceLoggerUtil.logError("QuotePolicySearchServiceImpl", "resolveDLSExpression", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
		} catch (ELException e) {
			WebServiceLoggerUtil.logError("QuotePolicySearchServiceImpl", "resolveDLSExpression", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
		}

		return resolvedExpression;
	}
	
	private double convertStringToDouble(String stringValue){
		double doubleValue=0;
		if(stringValue!=null && !"".equalsIgnoreCase(stringValue)){
			stringValue=stringValue.trim();
			try{
			 doubleValue=Double.parseDouble(stringValue);
			}catch(NumberFormatException exp){
				doubleValue=0;
			}
		}
		return doubleValue;
	}
	
}

