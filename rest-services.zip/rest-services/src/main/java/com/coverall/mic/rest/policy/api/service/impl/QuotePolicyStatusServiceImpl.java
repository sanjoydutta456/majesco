/**
 * 
 */
package com.coverall.mic.rest.policy.api.service.impl;

import java.sql.Connection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.ws.rs.core.Response;

import org.apache.commons.lang.time.DateFormatUtils;

import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.QuotePolicyStatusService;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyStatus;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.WorkflowUtil;


/**
 * @author Kaushik87149
 *
 */
public class QuotePolicyStatusServiceImpl implements QuotePolicyStatusService {
	private String entityReference;
	private String entityType;
	DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
	
	
	public QuotePolicyStatusServiceImpl(String entityReference, String entityType) {
		super();
		this.entityReference = entityReference;
		this.entityType = entityType;
	}

	@Override
	public QuotePolicyStatus getQuotePolicyStatus() throws APIException {
		QuotePolicyStatus quotePolicyStatus = new QuotePolicyStatus();
		quotePolicyStatus.setEntityType(entityType);
		quotePolicyStatus.setEntityReference(entityReference);

		String status = null;
		Connection conn = null;
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		
		try	{
			conn = requestContext.getConnection();
			
			if (!WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)) {
				String errMsg = entityType + " " + entityReference + " was not found. Please check input parameters.";
				
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
			
			status = WorkflowUtil.getCurrentPolicyStatus(entityReference, entityType, conn);
			quotePolicyStatus.setStatus(status); 
			quotePolicyStatus.setStatusTimestamp(df.format(System.currentTimeMillis()));
		} catch (APIException e) {
			throw e;
		} catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));
			
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		}
		
		return quotePolicyStatus;
	}
	
	
	private List<Message> getErrorMessageList(List<String> strMessages)	{
		if(strMessages == null)	{
			return null;
		}
		List<Message> errorMessageList = new ArrayList<Message>(strMessages.size());
		for(String aMsg : strMessages)	{
			Message message = new Message();
			message.setMoreinfo(aMsg);
			errorMessageList.add(message);
		}
		return errorMessageList;
	}
}
