package com.coverall.mic.rest.policy.api.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.QuotePolicySurchargeService;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicySurcharge;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.WorkflowUtil;
import com.coverall.mt.http.User;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.util.DBUtil;

public class QuotePolicySurchargeServiceImpl implements QuotePolicySurchargeService{

	public String entityReference;
	public String entityType;
	public HttpServletRequest request;
	public User user;

	String queryForGettingSurchargeInfo="SELECT id id,GID gid,lob lobCode, NVL((SELECT PLB_DESCRIPTION FROM PS_LINES_OF_BUSINESS,DS_RESOURCE where DSR_GID = PLB_ID and dsr_lob_code =LOB and rownum<2),LOB) lobDescription,"+
			"stat_code StatCode, ANNUAL_STATEMENT_LINE annualStatementLine, DATE_DELETED dateDeleted, DEL_ENTITY_TYPE delEntityType, DEL_ENTITY_REFERENCE delEntityReference,"+
			"STATE_CODE stateCode,(SELECT state_name FROM IEL_MIC_STATE_CODES WHERE state_code=STATE_CODE AND rownum<2) stateName,CITY_CODE cityCode, CITY_NAME cityName,name name, des description,type type,"+
			"annual_fee annualFee, transaction_fee transactionFee,deposit_fee depositFee, premium_basis premiumBasis, surcharge_amount surchargeAmount,"+
			"full_term_fee fullTermFee,total_fee totalFee, trans_fee_not_sub_to_audit feeNotSubToAudit,WAIVE_INDICATOR waiveIndicator,waived_fee waivedFee,"+
			"waived_tax waivedTax,waived_col_fee waivedColFee, policy_waived_surcharge policyWaivedSurcharge, prior_surcharge_adjustment priorSurchargeAdjustment,"+
			"is_amount_in_percent isAmountInPercent, HANDLING_METHOD handlingMethod, UNIT_COVERAGE unitCoverage, UNIT_NUMBER unitNumber, UNIT_ID unitId,"+
			"ENTITY_STATUS entityStatus,PRODUCT_CODE productCode,NAME_UK nameUk,OPTION_NO optionNo,IS_OPTION_SELECTED isOptionSelected,"+
			"FK_COLUMN_NAME refName,FK_COLUMN_VALUE refValue,MOD_ENTITY_TYPE modEntityType,MOD_ENTITY_REFERENCE modEntityReference,ADD_ENTITY_REFERENCE addEntityReference,"+
			"ADD_ENTITY_TYPE addEntityType,DATE_CREATED dateCreated,DATE_MODIFIED dateModified,USER_CREATED userCreated,USER_MODIFIED userModified,AUDIT_FLAG auditFlag"+
			" FROM AT_MIS_SURCHARGES where entity_reference=? order BY lobCode";

	public QuotePolicySurchargeServiceImpl(String entityReference, String entityType,HttpServletRequest request) {
		super();
		this.entityReference = entityReference;
		this.entityType = entityType;
		this.request=request;
		user = User.getUser(request);

	}

	@Override
	public Object getQuotePolicySurchargenResult() throws Exception {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		List<QuotePolicySurcharge> surchargeList=new ArrayList<QuotePolicySurcharge>();
		Connection conn = null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		try {
			conn=requestContext.getConnection();
			if(WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)){
				ps=conn.prepareStatement(queryForGettingSurchargeInfo);
				ps.setString(1, entityReference);
				rs=ps.executeQuery();

				while(rs.next()){
					QuotePolicySurcharge surcharge=new QuotePolicySurcharge();
					surcharge.setId(getColumnValue(rs,"id"));
					surcharge.setGid(getColumnValue(rs,"gid"));
					surcharge.setName(getColumnValue(rs,"name"));
					surcharge.setDescription(getColumnValue(rs,"description"));
					surcharge.setLobCode(getColumnValue(rs,"lobCode"));
					surcharge.setLobDescription(getColumnValue(rs,"lobDescription"));
					surcharge.setProductCode(getColumnValue(rs,"productCode"));
					surcharge.setStateCode(getColumnValue(rs,"stateCode"));
					surcharge.setStateName(getColumnValue(rs,"stateName"));
					surcharge.setCityCode(getColumnValue(rs,"cityCode"));
					surcharge.setCityName(getColumnValue(rs,"cityName"));
					surcharge.setIsAmountInPercent(getColumnValue(rs,"isAmountInPercent"));
					surcharge.setAnnualFee(getColumnValue(rs,"annualFee"));
					surcharge.setDepositFee(getColumnValue(rs,"depositFee"));
					surcharge.setFeeNotSubjectToAudit(getColumnValue(rs,"feeNotSubToAudit"));
					surcharge.setFullTermFee(getColumnValue(rs,"fullTermFee"));
					surcharge.setHandlingMethod(getColumnValue(rs,"handlingMethod"));
					surcharge.setPolicyWaivedSurcharge(getColumnValue(rs,"policyWaivedSurcharge"));
					surcharge.setPremiumBasis(getColumnValue(rs,"premiumBasis"));
					surcharge.setPriorSurchargeAdjustment(getColumnValue(rs,"priorSurchargeAdjustment"));
					surcharge.setSurchargeAmount(getColumnValue(rs,"surchargeAmount"));
					surcharge.setTotalFee(getColumnValue(rs,"totalFee"));
					surcharge.setTransactionFee(getColumnValue(rs,"transactionFee"));
					surcharge.setType(getColumnValue(rs,"type"));
					surcharge.setUnitCoverage(getColumnValue(rs,"unitCoverage"));
					surcharge.setUnitId(getColumnValue(rs,"unitId"));
					surcharge.setUnitNumber(getColumnValue(rs,"unitNumber"));
					surcharge.setWaivedColFees(getColumnValue(rs,"waivedColFee"));
					surcharge.setWaivedFee(getColumnValue(rs,"waivedFee"));
					surcharge.setWaiveIndicator(getColumnValue(rs,"waiveIndicator"));
					surcharge.setWaivedTax(getColumnValue(rs,"waivedTax"));
					surcharge.setUserCreated(getColumnValue(rs,"userCreated"));
					surcharge.setUserModified(getColumnValue(rs,"userModified"));
					surcharge.setDateCreated(getColumnValue(rs,"dateCreated"));
					surcharge.setDateModified(getColumnValue(rs,"dateModified"));
					surcharge.setEntityStatus(getColumnValue(rs,"entityStatus"));
					surcharge.setNameUk(getColumnValue(rs,"nameUk"));
					surcharge.setOptionNo(getColumnValue(rs,"optionNo"));
					surcharge.setIsOptionSelected(getColumnValue(rs,"isOptionSelected"));
					surcharge.setRefName(getColumnValue(rs,"refName"));
					surcharge.setRefValue(getColumnValue(rs,"refValue"));
					surcharge.setAddEntityReference(getColumnValue(rs,"addEntityReference"));
					surcharge.setAddEntityType(getColumnValue(rs,"addEntityType"));
					surcharge.setModEntityReference(getColumnValue(rs,"modEntityReference"));
					surcharge.setModEntityType(getColumnValue(rs,"modEntityType"));
					surcharge.setAuditFlag(getColumnValue(rs,"auditFlag"));  
					surcharge.setAnnualStatementLine(getColumnValue(rs,"annualStatementLine"));
					surcharge.setStatCode(getColumnValue(rs,"StatCode"));
					surcharge.setDateDeleted(getColumnValue(rs,"dateDeleted"));
					surcharge.setDelEntityType(getColumnValue(rs,"delEntityType"));
					surcharge.setDelEntityReference(getColumnValue(rs,"delEntityReference"));

					surchargeList.add(surcharge);
				}
			}else{
				String errMsg = entityType + " " + entityReference + " was not found. Please check input parameters.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("QuotePolicySurchargeServiceImpl", "getQuotePolicySurchargenResult", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
		}catch (APIException e) {
			WebServiceLoggerUtil.logError("QuotePolicySurchargeServiceImpl", "getQuotePolicySurchargenResult", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw e;
		}catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError("QuotePolicySurchargeServiceImpl", "getQuotePolicyTransactionResult", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		}finally{
			try {
				DBUtil.close(rs, ps);
			} catch (SQLException e) {
				WebServiceLoggerUtil.logInfo("QuotePolicySurchargeServiceImpl", "getQuotePolicySurchargenResult", e.getLocalizedMessage(), new Object[] { e.getMessage() });
			}
		}
		return surchargeList;
	}

	private List<Message> getErrorMessageList(List<String> strMessages)	{
		if(strMessages == null)	{
			return null;
		}
		List<Message> errorMessageList = new ArrayList<Message>(strMessages.size());
		for(String aMsg : strMessages)	{
			Message message = new Message();
			message.setMoreinfo(aMsg);
			errorMessageList.add(message);
		}
		return errorMessageList;
	}

	private String getColumnValue(ResultSet rs, String columnName) throws Exception{
		ResultSetMetaData rsmd = null;
		String columnValue = null;
		try{

			rsmd = rs.getMetaData();
			for (int j = 1; j <= rsmd.getColumnCount(); j++) {
				if (columnName.equalsIgnoreCase(rsmd.getColumnName(j))){
					/* Get the column value */
					columnValue = getColumnValueAtIndex(rs, j);
					break;
				}
			}
		}catch(Exception e){
			throw new Exception("Error in obtaining the value for column: " + columnName);
		}
		return columnValue;
	}

	private String getColumnValueAtIndex(ResultSet rs, int columnIndex) throws Exception{
		ResultSetMetaData rsmd = null;
		String columnValue = null;
		String columnName = null;
		try{
			rsmd = rs.getMetaData();
			if (("varchar2").equalsIgnoreCase(rsmd.getColumnTypeName(columnIndex)) ||
					("char").equalsIgnoreCase(rsmd.getColumnTypeName(columnIndex))) {
				columnValue = rs.getString(columnIndex);
			}else if (("number").equalsIgnoreCase(rsmd.getColumnTypeName(columnIndex))) {
				 DecimalFormat formatter = new DecimalFormat("#.##########");
				 double d = rs.getDouble(columnIndex);
				 columnValue = "" + formatter.format(d);
				 if(rs.wasNull()){
					 columnValue=null;
				 }
			}else if (("date").equalsIgnoreCase(rsmd.getColumnTypeName(columnIndex))) {
				java.sql.Timestamp timeStampValue = rs.getTimestamp(columnIndex);
				if (timeStampValue != null) {
					SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
					columnValue = dateFormat.format(timeStampValue);
				}
			}else if (("clob").equalsIgnoreCase(rsmd.getColumnTypeName(columnIndex))) {
				columnValue = DBUtil.readClob(rs.getClob(columnIndex));
			}
			columnName = rsmd.getColumnName(columnIndex);
		}catch(Exception e){
			throw new Exception("Error in obtaining the value for column: " + columnName, e);
		}
		return columnValue;
	}
}

