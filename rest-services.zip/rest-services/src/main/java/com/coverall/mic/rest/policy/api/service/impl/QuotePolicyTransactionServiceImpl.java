package com.coverall.mic.rest.policy.api.service.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import org.apache.commons.lang.time.DateFormatUtils;

import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.QuotePolicyTransactionService;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyTransactions;
import com.coverall.mic.rest.policy.api.service.model.Transaction;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.WorkflowUtil;
import com.coverall.mt.http.User;
import com.coverall.mt.nexgensecurity.NsRestClientUtil;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.mt.security.securityclient.AuthorizationService;
import com.coverall.security.model.NsRole;
import com.coverall.util.DBUtil;
import com.coverall.mt.policytrans.TransactionService;
import com.coverall.mt.policytrans.PolicyTransactionDetailsVO;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;

public class QuotePolicyTransactionServiceImpl implements QuotePolicyTransactionService{
	
	public String entityReference;
	public String entityType;
	public HttpServletRequest request;
	public User user;
	
	public QuotePolicyTransactionServiceImpl(String entityReference, String entityType,HttpServletRequest request) {
		super();
		this.entityReference = entityReference;
		this.entityType = entityType;
		this.request=request;
		user = User.getUser(request);
		
	}

	@Override
	public QuotePolicyTransactions getQuotePolicyTransactionResult() throws Exception {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		QuotePolicyTransactions transaction=new QuotePolicyTransactions();
		transaction.setEntityType(entityType);
		transaction.setEntityReference(entityReference);
		transaction.setTransactionTimestamp(DateFormatUtils.ISO_DATETIME_TIME_ZONE_FORMAT.format(System.currentTimeMillis()));
		
		Connection conn = null;
		CallableStatement callStmt=null;
		try {
			conn=requestContext.getConnection();
			if(WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)){
				//Extracting user specific info
				user = User.getUser(request);
				String userName=user.getUserId();
				String domain=user.getDomain();
				String rolesString="";

				//Fetching roles list for the user
				AuthorizationService authorizationService = NsRestClientUtil.getAuthorizationServiceInstance(user.getDomain());
				Set<NsRole> roles = authorizationService.getAssignedRolesForUser(user.getFullName()); //get user roles assigned to loggedin user
				for(NsRole role:roles){
					rolesString+="'"+role.getName()+"',";
				}
				rolesString=rolesString.substring(0,rolesString.length()-1);

				TransactionService transactionService=new TransactionService();
				List<PolicyTransactionDetailsVO> filteredTransactionList=transactionService.getAvailableTransactions(entityType,entityReference,user,"N",rolesString, null);
				transaction.setTransactions(convertTransactionListFromUIToAPIFormat(filteredTransactionList));
			}else{
				String errMsg = entityType + " " + entityReference + " was not found. Please check input parameters.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("QuotePolicyTransactionServiceImpl", "getQuotePolicyTransactionResult", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
		}catch (APIException e) {
			WebServiceLoggerUtil.logError("QuotePolicyTransactionServiceImpl", "getQuotePolicyTransactionResult", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw e;
		}catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError("QuotePolicyTransactionServiceImpl", "getQuotePolicyTransactionResult", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		}finally{
			try {
				DBUtil.close(null, callStmt, conn);
			} catch (SQLException e) {
				WebServiceLoggerUtil.logInfo("QuotePolicyTransactionServiceImpl", "getQuotePolicyTransactionResult", e.getLocalizedMessage(), new Object[] { e.getMessage() });
			}
		}
		return transaction;
	}

//	public ArrayList<Transaction> getListOfTransactionSepcifics(String transactionResponse){
//		ArrayList<Transaction> transactions=new ArrayList<Transaction>();
//
//		for(String transactionStrings:transactionResponse.split("~")){
//			Transaction transactionBean=new Transaction();
//			Map<String,String> propertyMap=new HashMap<String, String>();
//			transactionBean.setTransactionProperty(propertyMap);
//			String transactionName=transactionStrings.split("\\?")[0];
//			transactionBean.setTransactionName(transactionName);
//			//Getting all transaction specifics
//			String transactionSpecifics[]=(transactionStrings.split("\\?")[1]).split("\\|");
//			for(String transactionSet:transactionSpecifics){
//				String propertySpecifics[]=transactionSet.split("=");
//				propertyMap.put(propertySpecifics[0],propertySpecifics[1]);
//			}
//			transactions.add(transactionBean);
//		}
//		return transactions;
//	}
	
	private List<Message> getErrorMessageList(List<String> strMessages)	{
		if(strMessages == null)	{
			return null;
		}
		List<Message> errorMessageList = new ArrayList<Message>(strMessages.size());
		for(String aMsg : strMessages)	{
			Message message = new Message();
			message.setMoreinfo(aMsg);
			errorMessageList.add(message);
		}
		return errorMessageList;
	}
	
	private ArrayList<Transaction> convertTransactionListFromUIToAPIFormat(List<PolicyTransactionDetailsVO> filteredTransactionList){
		ArrayList<Transaction> apiTransactionList=new ArrayList<Transaction>();
		
		for(PolicyTransactionDetailsVO policyTransaction:filteredTransactionList) {
			Transaction transaction=new Transaction();
			transaction.setTransactionName(policyTransaction.getDisplayName());
			
			Map<String,String> propertyMap=new HashMap<String, String>();
			propertyMap.putAll(policyTransaction.getParams());
			propertyMap.put("acknowledgementMessageType",policyTransaction.getAcknowledgementMessageType());
			propertyMap.put("acknowledgementMessage",policyTransaction.getAcknowledgementMessage());
			propertyMap.put("transactionAction",policyTransaction.getTransactionAction());
			transaction.setTransactionProperty(propertyMap);
			
			apiTransactionList.add(transaction);
		}
		return apiTransactionList;
	}
	
}

