package com.coverall.mic.rest.policy.api.service.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import org.apache.commons.io.IOUtils;
import org.codehaus.jackson.map.ObjectMapper;

import com.coverall.exceptions.ServiceException;
import com.coverall.mt.util.APIAuditTrailLog;
import com.coverall.mt.util.APIAuditTrailLogSpecifics;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.factory.impl.PolicyAPIFactoryServiceImpl;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.QuotePolicyUWRulesService;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.ConfirmationMessage;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyUWRule;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyUWRuleAction;
import com.coverall.mic.rest.policy.api.service.model.SourceSystemInformationBean;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mic.rest.policy.api.service.util.WorkflowUtil;
import com.coverall.mt.http.User;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.portal.dao.RulesetActionTransactionsDAO;
import com.coverall.util.DBUtil;

public class QuotePolicyUWRulesServiceImpl implements QuotePolicyUWRulesService{

	public String entityReference;
	public String entityType;
	public HttpServletRequest request;
	public User user;
	public final String UNDERWRITER_DESC="Underwriter Approval Required";
	public final String UNDERWRITER_APPROVAL="Underwriter Approval";
	public final String UNDERWRITER_REJECTION="Underwriter Rejection";


	public String queryForUWRules="SELECT uwRuleTitle, uwRuleResult, uwRuleDescreption,actionId FROM (SELECT 'RULE' ROW_TYPE,RRU_RULE_TITLE uwRuleTitle,"+ 
			"DECODE(RRL_RULE_RESULT, '0', 'Success', 'Failure') uwRuleResult,NVL(RRL_RULE_RESULT_DESC,'NA') uwRuleDescreption,"+ 
			"TO_CHAR(cast(NVL(RRL_DATE_MODIFIED, RRL_DATE_CREATED) as timestamp) at time zone 'UTC', 'YYYY-MM-DD\"T\"HH24:MI:SS\"Z\"') LAST_MODIFIED_ON,TO_CHAR(NVL(RRL_DATE_MODIFIED, RRL_DATE_CREATED), 'YYYYMMDDHH24:MI') LAST_MODIFIED_ON_SORT,"+
			" 'System' LAST_MODIFIED_BY,NULL actionId,0 HAS_MORE_INFO FROM RUL_RULESET_RULE_EXECUTION, RUL_RULESET_RULES,RUL_RULES"+
			" WHERE RRL_RULESET_EXECUTION_ID IN (SELECT MAX(RRE_RULESET_EXECUTION_ID) FROM RUL_RULESET_EXECUTION WHERE RRE_ENTITY_TYPE = UPPER(?)"+
			" AND RRE_ENTITY_REFERENCE = UPPER(?)) AND RRR_RULESET_RULE_ID = RRL_RULESET_RULE_ID AND RRU_RULE_ID = RRR_RULE_ID"+
			" UNION "+
			"SELECT 'ACTION' ROW_TYPE,RAC_ACTION_TITLE uwRuleTitle,DECODE(RRI_ACTION_STATUS, 'NOT_STARTED', 'Action Required', 'Action Completed') uwRuleResult,"+
			"NVL(RRI_ACTION_STATUS_DESC,'NA') uwRuleDescreption, TO_CHAR(cast(NVL(RRI_DATE_MODIFIED, RRI_DATE_CREATED) as timestamp) at time zone 'UTC', 'YYYY-MM-DD\"T\"HH24:MI:SS\"Z\"') LAST_MODIFIED_ON,"+
			"TO_CHAR(NVL(RRI_DATE_MODIFIED, RRI_DATE_CREATED), 'YYYYMMDDHH24:MI') LAST_MODIFIED_ON_SORT,DECODE(RRI_USER_MODIFIED, 'batchuser', 'System',"+ 
			"RRI_USER_MODIFIED) LAST_MODIFIED_BY,RRI_ACTION_EXECUTION_ID actionId,(SELECT COUNT(*) FROM RUL_RULESET_ACT_EXE_DETAILS WHERE RRX_ACTION_EXECUTION_ID = RRI_ACTION_EXECUTION_ID)"+
			" HAS_MORE_INFO FROM RUL_RULESET_ACTION_EXECUTION,RUL_RULESET_ACT_EXE_DETAILS,RUL_RULESET_ACTIONS,RUL_ACTIONS"+
			" WHERE RRI_RULESET_EXECUTION_ID IN (SELECT MAX(RRE_RULESET_EXECUTION_ID) FROM RUL_RULESET_EXECUTION WHERE RRE_ENTITY_TYPE = UPPER(?)"+
			" AND RRE_ENTITY_REFERENCE = UPPER(?)) AND RRI_ACTION_EXECUTION_ID = RRX_ACTION_EXECUTION_ID(+)"+
			" AND RRA_RULESET_ACTION_ID = RRI_RULESET_ACTION_ID AND RAC_ACTION_ID = RRA_ACTION_ID)";

	public String queryForUWRuleNotes="SELECT RRX_ACTION_NOTE remark FROM RUL_RULESET_ACT_EXE_DETAILS WHERE RRX_ACTION_EXECUTION_ID =?";


	public String queryForUWRuleTaskId="SELECT WAC_ID activityId FROM wfl_activities WHERE wac_task_id=(SELECT wta_id FROM WFL_TASKS WHERE WTA_NAME='"+APIConstant.UNDERWRITINGRULES_TASK+"')"+
			" AND WAC_WORKFLOW_TASK_ID IN (SELECT wwt_id FROM WFL_WORKFLOW_TASKS WHERE WWT_WORKFLOW_ID IN (SELECT wwo_id FROM WFL_WORKFLOWS"+
			" WHERE wwo_NAME IN ('POLICY WORKFLOW','QUOTE WORKFLOW')) AND wwt_task_id=("+
			" SELECT wta_id FROM WFL_TASKS WHERE WTA_NAME='"+APIConstant.UNDERWRITINGRULES_TASK+"' ))"+
			" AND WAC_ENTITY_REFERENCE=?";

	public String queryForUWInputRequired="SELECT decode(count(*),0,'N','Y') inputRequired FROM WFL_ACTIVITIES WHERE WAC_STAGE='BLOCK'"+
			" AND wac_percent=0 AND UPPER(WAC_STAGE_DESC)=UPPER('"+UNDERWRITER_DESC+"') AND wac_id=("+queryForUWRuleTaskId+")";

	public String queryForFetchingUWActionId="SELECT rri_ruleset_action_id,rac_action_id,rac_action_type,rac_action_title FROM rul_ruleset_action_execution,"+
			"rul_ruleset_actions,rul_actions WHERE rri_ruleset_execution_id = (SELECT MAX(RRE_RULESET_EXECUTION_ID)"+
			" FROM RUL_RULESET_EXECUTION WHERE UPPER(RRE_ENTITY_TYPE) = UPPER(?) AND RRE_ENTITY_REFERENCE = ?)"+
			" AND rri_ruleset_action_id = rra_ruleset_action_id AND rac_action_id = rra_action_id AND rac_action_title = 'Underwriter Approval'";

	public QuotePolicyUWRulesServiceImpl(String entityReference, String entityType,HttpServletRequest request) {
		super();
		this.entityReference = entityReference;
		this.entityType = entityType;
		this.request=request;
		user=user.getUser(request);
	}

	@Override
	public Object getUWRulesList() throws Exception {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		List<QuotePolicyUWRule> uwRuleList=new ArrayList<QuotePolicyUWRule>();
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		long sourceSystemRequestNo=System.currentTimeMillis();
		try{
			conn=requestContext.getConnection();
			
			if(!WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)){
				String errMsg = entityType + " " + entityReference + " was not found. Please check input parameters.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("QuotePolicyUWRulesServiceImpl", "getUWRulesList", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}

			if(!WorkflowUtil.isWorkflowStageReached(conn, entityType, APIConstant.UNDERWRITINGRULES_TASK,entityReference)){
				String errMsg = "Underwriter Rule execution stage is yet not reached for the entity "+entityReference+". Please check the status.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("QuotePolicyUWRulesServiceImpl", "getUWRulesList", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}

			ps=conn.prepareStatement(queryForUWRules);
			ps.setString(1, entityType);
			ps.setString(2, entityReference);
			ps.setString(3, entityType);
			ps.setString(4, entityReference);
			rs=ps.executeQuery();
			while(rs.next()){
				QuotePolicyUWRule uwRule=new QuotePolicyUWRule();
				//Populating common columns
				uwRule.setSourceSystemCode(SOURCE_SYSTEM_CODE);
				uwRule.setSourceSystemRequestNo(sourceSystemRequestNo);
				uwRule.setSourceSystemUserId(user.getUserId());

				uwRule.setUwRuleTitle(rs.getString("uwRuleTitle"));
				uwRule.setUwRuleResult(rs.getString("uwRuleResult"));
				uwRule.setUwRuleDescreption(rs.getString("uwRuleDescreption"));
				long actionId=rs.getLong("actionId");

				//Populating notes
				Map<String,String> notesMap=new HashMap<String,String>();
				int noteCount=0;
				PreparedStatement psNotes=conn.prepareStatement(queryForUWRuleNotes);
				psNotes.setLong(1, actionId);
				ResultSet rsNotes=psNotes.executeQuery();
				while(rsNotes.next()){
					noteCount++;
					String note=rsNotes.getString("remark");
					notesMap.put(noteCount+"", note);
					uwRule.setUwRuleRemarks(notesMap);
				}

				uwRuleList.add(uwRule);
			}

		}catch (APIException e) {
			WebServiceLoggerUtil.logError("QuotePolicyUWRulesServiceImpl", "getUWRulesList", "Exception occurred while fetching UW Rules:"+e.getLocalizedMessage(), new Object[] { e.getErrorMessage() }, e);
			throw e;
		}catch (Exception e) {
			WebServiceLoggerUtil.logError("QuotePolicyUWRulesServiceImpl", "getUWRulesList", "Exception occurred while fetching UW Rules query:", new Object[] { queryForUWRules }, e);
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		}finally{
			try {
				DBUtil.close(rs, ps);
			} catch (SQLException e) {
				WebServiceLoggerUtil.logInfo("QuotePolicyUWRulesServiceImpl", "getUWRulesList", e.getLocalizedMessage(), new Object[] { e.getCause() });
			}
		}

		return uwRuleList;
	}



	@Override
	public Object processUWRules() throws Exception {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		ConfirmationMessage processUWRuleResponse=new ConfirmationMessage();
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		CallableStatement callStmt=null;
		
		String sourceSystemCode=null;
		String sourceSystemUserId=null;
		long sourceSystemRequestNo=0;
		try{
			ObjectMapper mapper=new ObjectMapper();
			String inputJson=APIOperationUtil.fetchRequestBody(request);
			SourceSystemInformationBean sourceSystem=mapper.readValue(inputJson, SourceSystemInformationBean.class);
			sourceSystemCode=sourceSystem.getSourceSystemCode();
			sourceSystemUserId=sourceSystem.getSourceSystemUserId();
			sourceSystemRequestNo=sourceSystem.getSourceSystemRequestNo();
		}catch(Exception exp){
			//do nothing as this is not a mandatory part of request but needed for audit logging
		}		
		//Auditing logic
		APIAuditTrailLog auditTrailLog=requestContext.getAuditTrailLog();
		APIOperationUtil.populateAPIAuditLog(auditTrailLog, sourceSystemCode, sourceSystemUserId, sourceSystemRequestNo, RESOURCE_TYPE, PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
		//Adding specifics
		APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, entityReference, null, "Execute Underwriter Rules");
		
		conn=requestContext.getConnection();

		if(!WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)){
			String errMsg = entityType + " " + entityReference + " was not found. Please check input parameters.";
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
			WebServiceLoggerUtil.logInfo("QuotePolicyUWRulesServiceImpl", "processUWRules", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}

		if(!WorkflowUtil.isWorkflowStageReached(conn, entityType, APIConstant.UNDERWRITINGRULES_TASK,entityReference)){
			String errMsg = "Underwriter Rule execution stage is yet not reached for the entity "+entityReference+". Please check the status.";
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			WebServiceLoggerUtil.logInfo("QuotePolicyUWRulesServiceImpl", "processUWRules", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}

		if(!WorkflowUtil.checkIfUWRuleAndCommissionManagementWorkflowIsApplicable(user,conn, entityReference, entityType)){
			String errMsg = "Underwriter Rules can not be executed for "+entityReference;
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			WebServiceLoggerUtil.logInfo("QuotePolicyUWRulesServiceImpl", "processUWRules", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}

		try{
			conn=requestContext.getConnection();
			ps=conn.prepareStatement(queryForUWRuleTaskId);
			ps.setString(1, entityReference);
			rs=ps.executeQuery();
			long activityId=0;
			while(rs.next()){
				activityId=Long.parseLong(rs.getString("activityId"));
				break;	
			}

			WorkflowUtil.setBlocked(conn, activityId, UNDERWRITER_DESC);
			callStmt = conn.prepareCall("{ ? = call K_RULES_MANAGEMENT.f_execute_ruleset(?,?,?,?,?,?,?) }");
			callStmt.registerOutParameter(1, Types.BIGINT);
			callStmt.setString(2, entityType);
			callStmt.setString(3, entityReference);
			callStmt.setString(4, user.getFullName());
			callStmt.registerOutParameter(5, Types.BIGINT);
			callStmt.registerOutParameter(6, Types.VARCHAR);
			callStmt.registerOutParameter(7, Types.VARCHAR);
			callStmt.registerOutParameter(8, Types.VARCHAR);
			callStmt.execute();

			int errorCode=callStmt.getInt(1);
			String isBlockingAction = callStmt.getString(6);
			String statusDescription= callStmt.getString(7);

			if (errorCode != 0) {
				String errorMessage = callStmt.getString(8);
				throw new ServiceException("Error: " + errorMessage, null);
			} else {
				if (null != isBlockingAction && 
						isBlockingAction.equalsIgnoreCase("N")) {
					processUWRuleResponse.setCode("SUCCESS");
					processUWRuleResponse.setDescription("Underwriter rules executed for "+entityType+" : "+entityReference);
				} else {
					processUWRuleResponse.setCode("Action Needed");
					processUWRuleResponse.setDescription("Underwriter rules execution blocked for "+entityType+" : "+entityReference+" Status-"+statusDescription);
				}

			}

			conn.commit();
			callStmt.close();
			callStmt=null;

		}catch (APIException e) {
			WebServiceLoggerUtil.logError("QuotePolicyUWRulesServiceImpl", "processUWRules", "Exception occurred while triggering uw rule re-processing:"+e.getLocalizedMessage(), new Object[] { e.getErrorMessage() }, e);
			throw e;
		}catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError("QuotePolicyUWRulesServiceImpl", "processUWRules", "Exception occurred while triggering uw rule re-processing:"+e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		}finally{
			try {
				DBUtil.close(rs, ps);
			} catch (Exception e) {
				WebServiceLoggerUtil.logInfo("QuotePolicyUWRulesServiceImpl", "processUWRules", e.getLocalizedMessage(), new Object[] { e.getCause() });
			}

		}

		return processUWRuleResponse;
	}


	@Override
	public Object approveUWRules() throws Exception {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		ConfirmationMessage response=new ConfirmationMessage();
		Connection conn=null;
		CallableStatement callableStatement = null;

		ObjectMapper mapper=null;

		try {
			//Getting action Id
			conn = requestContext.getConnection();
			
			//Getting notes from request
			String note="";
			mapper=new ObjectMapper();
			String inputJson=APIOperationUtil.fetchRequestBody(request);
			QuotePolicyUWRuleAction uwRuleAction=mapper.readValue(inputJson, QuotePolicyUWRuleAction.class);
			note=uwRuleAction.getRemarks();
			
			//Auditing logic
			APIAuditTrailLog auditTrailLog=requestContext.getAuditTrailLog();
			APIOperationUtil.populateAPIAuditLog(auditTrailLog, uwRuleAction.getSourceSystemCode(), uwRuleAction.getSourceSystemUserId(), uwRuleAction.getSourceSystemRequestNo(), RESOURCE_TYPE, PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
			//Adding specifics
			APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, entityReference, null, "Remark:"+note);

			if(!WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)){
				String errMsg = entityType + " " + entityReference + " was not found. Please check input parameters.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("QuotePolicyUWRulesServiceImpl", "approveUWRules", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
			
			if(!WorkflowUtil.checkIfUserHasTheRequiredPermission(requestContext.getUser(), APIConstant.UNDERWRITER_RULESET_PERMISSION)) {
				String errMsg = user.getUserId()+" doesn't have permission to approve underwriter rules.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("QuotePolicyUWRulesServiceImpl", "approveUWRules", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}

			if(!verifyIfUWInputRequired(conn,entityReference)){
				String errMsg = "Underwriter input is not required for "+entityReference+". Please verify status of transaction";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("QuotePolicyUWRulesServiceImpl", "rejectUWRules", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}

			long rulesetActionId=getRuleActionIdForTransation(conn);

			//Making a call for approving uw rules
			RulesetActionTransactionsDAO transactionsDAO = new RulesetActionTransactionsDAO();
			transactionsDAO.setTransactionType(UNDERWRITER_APPROVAL);
			transactionsDAO.setNote(note);
			transactionsDAO.setEntityReference(entityReference);
			transactionsDAO.setEntityType(entityType);
			transactionsDAO.setRulesetActionId(rulesetActionId);
			try{
				transactionsDAO.saveTransaction(user);
			}catch(Exception e){
				WebServiceLoggerUtil.logError("QuotePolicyUWRulesServiceImpl", "approveUWRules", "Exception occurred while approving uw rule using saveTransaction under RulesetActionTransactionsDAO: "+e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
				throw e;
			}
			response.setCode("SUCCESS");
			response.setDescription("Underwriter rules approved for "+entityType+" : "+entityReference);
		} catch (Exception ex) {
			WebServiceLoggerUtil.logError("QuotePolicyUWRulesServiceImpl", "approveUWRules", "Exception occurred while approving uw rule: "+ex.getLocalizedMessage(), new Object[] { ex.getMessage() }, ex);
			throw ex;
		} finally {
			try{
				DBUtil.close(null, callableStatement);
			}catch(Exception exp){
				WebServiceLoggerUtil.logInfo("QuotePolicyUWRulesServiceImpl", "approveUWRules", exp.getLocalizedMessage(), new Object[] { exp.getMessage() });
			}

		}
		return response;
	}

	@Override
	public Object rejectUWRules() throws Exception {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		ConfirmationMessage response=new ConfirmationMessage();
		Connection conn=null;
		CallableStatement callableStatement = null;

		ObjectMapper mapper=null;

		try {

			conn = requestContext.getConnection();
			
			//Getting notes from request
			String note="";
			mapper=new ObjectMapper();
			String inputJson=APIOperationUtil.fetchRequestBody(request);
			QuotePolicyUWRuleAction uwRuleAction=mapper.readValue(inputJson, QuotePolicyUWRuleAction.class);
			note=uwRuleAction.getRemarks();
			
			//Auditing logic
			APIAuditTrailLog auditTrailLog=requestContext.getAuditTrailLog();
			APIOperationUtil.populateAPIAuditLog(auditTrailLog, uwRuleAction.getSourceSystemCode(), uwRuleAction.getSourceSystemUserId(), uwRuleAction.getSourceSystemRequestNo(), RESOURCE_TYPE, PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
			//Adding specifics
			APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, entityReference, null, "Remark:"+note);

			if(!WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)){
				String errMsg = entityType + " " + entityReference + " was not found. Please check input parameters.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("QuotePolicyUWRulesServiceImpl", "rejectUWRules", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
			
			if(!WorkflowUtil.checkIfUserHasTheRequiredPermission(requestContext.getUser(), APIConstant.UNDERWRITER_RULESET_PERMISSION)) {
				String errMsg = user.getUserId()+" doesn't have permission to reject underwriter rules.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("QuotePolicyUWRulesServiceImpl", "rejectUWRules", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}

			if(!verifyIfUWInputRequired(conn,entityReference)){
				String errMsg = "Underwriter input is not required for "+entityReference+". Please verify status of transaction";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("QuotePolicyUWRulesServiceImpl", "rejectUWRules", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}

			long rulesetActionId=getRuleActionIdForTransation(conn);

			//Making a call for rejecting uw rules
			RulesetActionTransactionsDAO transactionsDAO = new RulesetActionTransactionsDAO();
			transactionsDAO.setTransactionType(UNDERWRITER_REJECTION);
			transactionsDAO.setNote(note);
			transactionsDAO.setEntityReference(entityReference);
			transactionsDAO.setEntityType(entityType);
			transactionsDAO.setRulesetActionId(rulesetActionId);
			try{
				transactionsDAO.saveTransaction(user);
			}catch(Exception e){
				WebServiceLoggerUtil.logError("QuotePolicyUWRulesServiceImpl", "rejectUWRules", "Exception occurred while rejecting uw rule using saveTransaction under RulesetActionTransactionsDAO: "+e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
				throw e;
			}
			response.setCode("SUCCESS");
			response.setDescription("Underwriter rules rejected for "+entityType+" : "+entityReference);
		} catch (Exception ex) {
			WebServiceLoggerUtil.logError("QuotePolicyUWRulesServiceImpl", "rejectUWRules", "Exception occurred while rejecting uw rule: "+ex.getLocalizedMessage(), new Object[] { ex.getMessage() }, ex);
			throw ex;
		} finally {
			try{
				DBUtil.close(null, callableStatement);
			}catch(Exception exp){
				WebServiceLoggerUtil.logInfo("QuotePolicyUWRulesServiceImpl", "rejectUWRules", exp.getLocalizedMessage(), new Object[] { exp.getMessage() });
			}

		}
		return response;

	}


	private long getRuleActionIdForTransation(Connection conn) throws Exception{
		long rulesetActionId=0;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			pstmt=conn.prepareStatement(queryForFetchingUWActionId);
			pstmt.setString(1, entityType);
			pstmt.setString(2, entityReference);
			rs=pstmt.executeQuery();
			while(rs.next()){
				rulesetActionId=rs.getLong("rri_ruleset_action_id");
				break;
			}
		}catch(Exception exp){
			throw exp;
		}finally{
			try{
				DBUtil.close(rs, pstmt);
			}catch(Exception exp){
				WebServiceLoggerUtil.logInfo("QuotePolicyUWRulesServiceImpl", "getRuleActionIdForTransation", exp.getLocalizedMessage(), new Object[] { exp.getMessage() });
			}
		}
		return rulesetActionId;

	}

	private List<Message> getErrorMessageList(List<String> strMessages)	{
		if(strMessages == null)	{
			return null;
		}
		List<Message> errorMessageList = new ArrayList<Message>(strMessages.size());
		for(String aMsg : strMessages)	{
			Message message = new Message();
			message.setMoreinfo(aMsg);
			errorMessageList.add(message);
		}
		return errorMessageList;
	}

	private boolean verifyIfUWInputRequired(Connection conn, String entityReference) throws Exception{
		PreparedStatement psInput=null;
		ResultSet rsInput=null;
		String inputRequired="N";

		try{
			psInput=conn.prepareStatement(queryForUWInputRequired);
			psInput.setString(1, entityReference);
			rsInput=psInput.executeQuery();

			while(rsInput.next()){
				inputRequired=rsInput.getString("inputRequired");
				break;	
			}

			if(inputRequired.equalsIgnoreCase("Y")){
				return true;
			}else{
				return false;
			}

		}catch(Exception exp){
			WebServiceLoggerUtil.logError("QuotePolicyUWRulesServiceImpl", "verifyIfUWInputRequired", "Exception occurred while verifying if uw input required: "+exp.getLocalizedMessage(), new Object[] { exp.getMessage() }, exp);
			throw exp;
		}finally{
			try{
				DBUtil.close(rsInput, psInput);
			}catch(Exception e){
				WebServiceLoggerUtil.logInfo("QuotePolicyUWRulesServiceImpl", "verifyIfUWInputRequired", e.getLocalizedMessage(), new Object[] { e.getMessage() });	
			}
		}
	}


}

