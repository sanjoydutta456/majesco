package com.coverall.mic.rest.policy.api.service.impl;

import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.ScaledownService;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.ScaledownBean;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.util.MachineInfoUtil;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.pct.server.util.PCTGenUtils;
import com.coverall.pctv2.server.service.PCTListener;


public class ScaledownServiceImpl implements ScaledownService{
	
	HttpServletRequest request;
	String timeout;
	
	ScaledownServiceImpl(HttpServletRequest request, String timeout){
		this.request=request;
		this.timeout=timeout;
	}

	@Override
	public ScaledownBean initiateScaledown() throws Exception {
		if(!MachineInfoUtil.isContainerMode()) {
			String errMsg = "Scaledown operation only works in container mode. This machine is not running in container mode.";
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.NOT_ACCEPTABLE.getStatusCode());
			PCTGenUtils.systemOutWithThreadInfo("PolicyAPIServiceImpl,initiateInstanceScaledown: "+errMsg);
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, this.getClass().getName(), "initiateScaledown", ServletConfigUtil.COMPONENT_FRAMEWORK,
				      new Object[] {MachineInfoUtil.getMachineHostName()},
				      "Scaledown - "+errMsg, null,LogMinderDOMUtil.VALUE_ADMIN);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}
		ScaledownBean responseBean=null;
		if(!PCTListener.isScaledownInitiated()) {
			responseBean=new ScaledownBean();
			String ipAddress=APIOperationUtil.getClientIPAddress(request);
			String message="Scaledown initiated at "+new Date()+" from IP:"+ipAddress;
			responseBean.setMessage("Scaledown initiated");
			responseBean.setTriggerTime(""+new Date());
			responseBean.setTriggeredBy(ipAddress);
			responseBean.setTimeout(timeout);
			PCTGenUtils.systemOutWithThreadInfo("PolicyAPIServiceImpl,initiateInstanceScaledown: URL executed: "+request.getRequestURI()+"?"+request.getQueryString());
			PCTGenUtils.systemOutWithThreadInfo("PolicyAPIServiceImpl,initiateInstanceScaledown: "+responseBean);
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, this.getClass().getName(), "initiateScaledown", ServletConfigUtil.COMPONENT_FRAMEWORK,
				      new Object[] {MachineInfoUtil.getMachineHostName(), "URL=", request.getRequestURI()+"?"+request.getQueryString(), "responseBean", responseBean},
				      "Scaledown - URL executed", null,LogMinderDOMUtil.VALUE_ADMIN);
			PCTListener.initiateScaledown(message,timeout);
		}else {
			String errMsg = "Scaledown operation was already initiated, can't retrigger scaledown";
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.NOT_ACCEPTABLE.getStatusCode());
			PCTGenUtils.systemOutWithThreadInfo("PolicyAPIServiceImpl,initiateInstanceScaledown: "+errMsg);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}
		return responseBean;
	}
	
}

