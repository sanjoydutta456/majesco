/**
 * 
 */
package com.coverall.mic.rest.policy.api.service.losscontrol;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

/**
 * @author Achint11877
 *
 */
@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
@Produces({ MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA, MediaType.APPLICATION_OCTET_STREAM,
		"application/pdf" })
public interface ILossControlService
{
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.MULTIPART_FORM_DATA })
	@POST
	@Path("inspectionstatusupdate")
	public Object inspectionStatusUpdate(@Context HttpServletRequest request, @QueryParam("status") String status)
			throws Exception;

	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.MULTIPART_FORM_DATA })
	@POST
	@Path("recommendationresponse")
	public Object recommendationResponse(@Context HttpServletRequest request) throws Exception;

	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.MULTIPART_FORM_DATA })
	@POST
	@Path("inspectiontypechange")
	public Object inspectionTypeChange(@Context HttpServletRequest request) throws Exception;

	@GET
	@Path("ping")
	public String ping();

}
