/**
 * 
 */
package com.coverall.mic.rest.policy.api.service.losscontrol.impl;

import java.sql.Connection;
import java.util.Collections;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.losscontrol.ILossControlService;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.UnifiedSearchErrors;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.impl.AbstractUnifiedEntitySearch;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.majesco.losscontrol.core.exceptions.LC360Exception;
import com.majesco.losscontrol.inspectionstatusupdate.model.InspectionStatus;
import com.majesco.losscontrol.inspectiontypechange.model.InspectionTypeChangeRequest;
import com.majesco.losscontrol.recommendation.model.Recommendation;
import com.majesco.losscontrol.services.InspectionStatusUpdateService;
import com.majesco.losscontrol.services.InspectionTypeChangeService;
import com.majesco.losscontrol.services.RecommendationResponseService;

/**
 * @author Achint11877
 *
 */
public class LossControlServiceImpl implements ILossControlService
{

	@Override
	public Object inspectionStatusUpdate(HttpServletRequest request, String status) throws Exception
	{
		try
		{
			String jsonInspectionStatus = APIOperationUtil.fetchRequestBody(request);
			if (jsonInspectionStatus != null && !jsonInspectionStatus.isEmpty())
			{
				WebServiceLoggerUtil.logInfo(getClass().getName(), "inspectionStatusUpdate",
						"Request: " + jsonInspectionStatus, null);
				ObjectMapper om = new ObjectMapper();
				InspectionStatus inspectionStatus = om.readValue(jsonInspectionStatus, InspectionStatus.class);
				if (inspectionStatus.testString == null || inspectionStatus.testString.isEmpty())
				{
					inspectionStatus.status = status;

					Connection connection = APIRequestContext.getApiRequestContext().getConnection();

					InspectionStatusUpdateService inspectionStatusUpdateService = new InspectionStatusUpdateService();
					inspectionStatusUpdateService.inspectionStatusUpdate(inspectionStatus, connection);
				}
				else
				{
					WebServiceLoggerUtil.logInfo("inspectionStatusUpdate", "ping - LC360 inspectionstatusupdate",
							new Object[] { jsonInspectionStatus });
				}
			}
		} catch (LC360Exception e)
		{
			throw e;
		} catch (Exception e)
		{
			WebServiceLoggerUtil.logError("LossControlServiceImpl", "inspectionStatusUpdate", e.getLocalizedMessage(),
					new Object[] { request }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
					APIConstant.FAILED,
					AbstractUnifiedEntitySearch.getErrorMessageList(
							Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),
					e);
		}
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object recommendationResponse(HttpServletRequest request) throws Exception
	{
		try
		{
			String jsonRecommendationResponse = APIOperationUtil.fetchRequestBody(request);
			if (jsonRecommendationResponse != null && !jsonRecommendationResponse.isEmpty())
			{
				WebServiceLoggerUtil.logInfo(getClass().getName(), "recommendationResponse",
						"Request: " + jsonRecommendationResponse, null);
				ObjectMapper om = new ObjectMapper();
				Recommendation recommendation = om.readValue(jsonRecommendationResponse, Recommendation.class);
				if (recommendation.testString == null || recommendation.testString.isEmpty())
				{
					Connection connection = APIRequestContext.getApiRequestContext().getConnection();

					RecommendationResponseService recommendationService = new RecommendationResponseService();
					recommendationService.recommendationUpdate(recommendation, connection);
				}
				else
				{
					WebServiceLoggerUtil.logInfo("recommendationResponse", "ping - LC360 recommendationresponse",
							new Object[] { jsonRecommendationResponse });
				}
			}
		} catch (LC360Exception e)
		{
			throw e;
		} catch (Exception e)
		{
			WebServiceLoggerUtil.logError("LossControlServiceImpl", "recommendationResponse", e.getLocalizedMessage(),
					new Object[] { request }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
					APIConstant.FAILED,
					AbstractUnifiedEntitySearch.getErrorMessageList(
							Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),
					e);
		}
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String ping()
	{
		return "This is Loss Control Service";
	}

	@Override
	public Object inspectionTypeChange(HttpServletRequest request) throws Exception
	{
		try
		{
			String jsonInspectionTypeChangeRequest = APIOperationUtil.fetchRequestBody(request);
			if (jsonInspectionTypeChangeRequest != null && !jsonInspectionTypeChangeRequest.isEmpty())
			{
				WebServiceLoggerUtil.logInfo(getClass().getName(), "inspectionTypeChange",
						"Request: " + jsonInspectionTypeChangeRequest, null);
				ObjectMapper om = new ObjectMapper();
				InspectionTypeChangeRequest inspectionTypeChange = om.readValue(jsonInspectionTypeChangeRequest,
						InspectionTypeChangeRequest.class);
				if (inspectionTypeChange.testString == null || inspectionTypeChange.testString.isEmpty())
				{
					Connection connection = APIRequestContext.getApiRequestContext().getConnection();

					InspectionTypeChangeService recommendationService = new InspectionTypeChangeService();
					recommendationService.inspectionTypeChange(inspectionTypeChange, connection);
				}
				else
				{
					WebServiceLoggerUtil.logInfo("inspectionTypeChange", "ping - LC360 inspectiontypechange",
							new Object[] { jsonInspectionTypeChangeRequest });
				}
			}
		} catch (LC360Exception e)
		{
			throw e;
		} catch (Exception e)
		{
			WebServiceLoggerUtil.logError("LossControlServiceImpl", "inspectionTypeChange", e.getLocalizedMessage(),
					new Object[] { request }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
					APIConstant.FAILED,
					AbstractUnifiedEntitySearch.getErrorMessageList(
							Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),
					e);
		}
		return null;
	}
}
