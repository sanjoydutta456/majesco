package com.coverall.mic.rest.policy.api.service.model;

public class BillingInstallment {
	
	String installmentId;
	String dueDate;
	double premiumDue;
	double taxesFeesSurcharge;
	double installmentCharge;
	double totalAmount;
	
	public String getInstallmentId() {
		return installmentId;
	}
	public void setInstallmentId(String installmentId) {
		this.installmentId = installmentId;
	}
	public String getDueDate() {
		return dueDate;
	}
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	public double getPremiumDue() {
		return premiumDue;
	}
	public void setPremiumDue(double premiumDue) {
		this.premiumDue = premiumDue;
	}
	public double getTaxesFeesSurcharge() {
		return taxesFeesSurcharge;
	}
	public void setTaxesFeesSurcharge(double taxesFeesSurcharge) {
		this.taxesFeesSurcharge = taxesFeesSurcharge;
	}
	public double getInstallmentCharge() {
		return installmentCharge;
	}
	public void setInstallmentCharge(double installmentCharge) {
		this.installmentCharge = installmentCharge;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	
	
	
	
	
}
