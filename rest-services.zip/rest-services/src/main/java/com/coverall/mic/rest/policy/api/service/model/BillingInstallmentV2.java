package com.coverall.mic.rest.policy.api.service.model;

public class BillingInstallmentV2 extends BillingInstallment {
	
	String installmentId;
	String dueDate;
	String sendDate;
	double premiumDue;
	double taxesFeesSurcharge;
	double installmentCharge;
	double totalAmount;
	String displayInstallmentId;
	
	public String getDisplayInstallmentId() {
		return displayInstallmentId;
	}
	public void setDisplayInstallmentId(String displayInstallmentId) {
		this.displayInstallmentId = displayInstallmentId;
	}
	public String getInstallmentId() {
		return installmentId;
	}
	public void setInstallmentId(String installmentId) {
		this.installmentId = installmentId;
	}
	public String getDueDate() {
		return dueDate;
	}
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	public String getSendDate() {
		return sendDate;
	}
	public void setSendDate(String sendDate) {
		this.sendDate = sendDate;
	}
	public double getPremiumDue() {
		return premiumDue;
	}
	public void setPremiumDue(double premiumDue) {
		this.premiumDue = premiumDue;
	}
	public double getTaxesFeesSurcharge() {
		return taxesFeesSurcharge;
	}
	public void setTaxesFeesSurcharge(double taxesFeesSurcharge) {
		this.taxesFeesSurcharge = taxesFeesSurcharge;
	}
	public double getInstallmentCharge() {
		return installmentCharge;
	}
	public void setInstallmentCharge(double installmentCharge) {
		this.installmentCharge = installmentCharge;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	
	
	
	
	
}
