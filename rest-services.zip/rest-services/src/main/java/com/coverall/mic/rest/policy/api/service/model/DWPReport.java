package com.coverall.mic.rest.policy.api.service.model;

import java.util.List;

public class DWPReport {
	
	private String product;
	private String productLine;
	private int noOfMonths;
	private String fromYearMonth;
	private String toYearMonth;
	private String totalDwpValue;
    private String asOfDate;
    private String sourceSystemRequestNo;
    private  List<DWPReportData>listData;
	
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getProductLine() {
		return productLine;
	}
	public void setProductLine(String productLine) {
		this.productLine = productLine;
	}
	public int getNoOfMonths() {
		return noOfMonths;
	}
	public void setNoOfMonths(int noOfMonths) {
		this.noOfMonths = noOfMonths;
	}
	public String getFromYearMonth() {
		return fromYearMonth;
	}
	public void setFromYearMonth(String fromYearMonth) {
		this.fromYearMonth = fromYearMonth;
	}
	public String getToYearMonth() {
		return toYearMonth;
	}
	public void setToYearMonth(String toYearMonth) {
		this.toYearMonth = toYearMonth;
	}
	public String getTotalDwpValue() {
		return totalDwpValue;
	}
	public void setTotalDwpValue(String totalDwpValue) {
		this.totalDwpValue = totalDwpValue;
	}
	public String getAsOfDate() {
		return asOfDate;
	}
	public void setAsOfDate(String asOfDate) {
		this.asOfDate = asOfDate;
	}
	public String getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}
	public void setSourceSystemRequestNo(String sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}
	public List<DWPReportData> getListData() {
		return listData;
	}
	public void setListData(List<DWPReportData> listData) {
		this.listData = listData;
	}
	@Override
	public String toString() {
		return "DWPReport [product=" + product + ", productLine=" + productLine + ", noOfMonths=" + noOfMonths + ", fromYearMonth=" + fromYearMonth + ", toYearMonth=" + toYearMonth + ", totalDwpValue=" + totalDwpValue + ", asOfDate=" + asOfDate + ", sourceSystemRequestNo="
				+ sourceSystemRequestNo + ", listData=" + listData + "]";
	}
}
