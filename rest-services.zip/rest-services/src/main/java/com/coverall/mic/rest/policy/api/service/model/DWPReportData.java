package com.coverall.mic.rest.policy.api.service.model;

public class DWPReportData {
	
	private String transactionMonth;
	private double dwpValue;
	
	
	public String getTransactionMonth() {
		return transactionMonth;
	}
	public void setTransactionMonth(String transactionMonth) {
		this.transactionMonth = transactionMonth;
	}
	public double getDwpValue() {
		return dwpValue;
	}
	public void setDwpValue(double dwpValue) {
		this.dwpValue = dwpValue;
	}
	@Override
	public String toString() {
		return "DWPReportData [transactionMonth=" + transactionMonth + ", dwpValue=" + dwpValue + "]";
	}
	
	

}
