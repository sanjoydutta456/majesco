package com.coverall.mic.rest.policy.api.service.model;

public class DocumentTemplateInfo {
	
	private long id;
	private long templateId;
	private String templateName;
	private String documentId;
	private String description;
	private String mimeType;
	private String isForm;
	private String isStatic;
	private String isMicDocument;
	private String editionDate;
	private String stateCode;
	private String revision;
	private String isManuscipt;
	private String isInterline;
	private String requiresAdoption;
	private String wordFormat;
	private String isMultiAttach;
	private String isManualUpload;
	private String lobCode;
	private String productCode;
	private String customerCode;
	private String validateVariable;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getTemplateName() {
		return templateName;
	}
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}
	public String getDocumentId() {
		return documentId;
	}
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getMimeType() {
		return mimeType;
	}
	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}
	public String getIsForm() {
		return isForm;
	}
	public void setIsForm(String isForm) {
		this.isForm = isForm;
	}
	public String getIsStatic() {
		return isStatic;
	}
	public void setIsStatic(String isStatic) {
		this.isStatic = isStatic;
	}
	public String getIsMicDocument() {
		return isMicDocument;
	}
	public void setIsMicDocument(String isMicDocument) {
		this.isMicDocument = isMicDocument;
	}
	public String getEditionDate() {
		return editionDate;
	}
	public void setEditionDate(String editionDate) {
		this.editionDate = editionDate;
	}
	public String getStateCode() {
		return stateCode;
	}
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	public String getRevision() {
		return revision;
	}
	public void setRevision(String revision) {
		this.revision = revision;
	}
	public String getIsManuscipt() {
		return isManuscipt;
	}
	public void setIsManuscipt(String isManuscipt) {
		this.isManuscipt = isManuscipt;
	}
	public String getIsInterline() {
		return isInterline;
	}
	public void setIsInterline(String isInterline) {
		this.isInterline = isInterline;
	}
	public String getRequiresAdoption() {
		return requiresAdoption;
	}
	public void setRequiresAdoption(String requiresAdoption) {
		this.requiresAdoption = requiresAdoption;
	}
	public String getWordFormat() {
		return wordFormat;
	}
	public void setWordFormat(String wordFormat) {
		this.wordFormat = wordFormat;
	}
	public String getIsMultiAttach() {
		return isMultiAttach;
	}
	public void setIsMultiAttach(String isMultiAttach) {
		this.isMultiAttach = isMultiAttach;
	}
	public String getIsManualUpload() {
		return isManualUpload;
	}
	public void setIsManualUpload(String isManualUpload) {
		this.isManualUpload = isManualUpload;
	}
	public String getLobCode() {
		return lobCode;
	}
	public void setLobCode(String lobCode) {
		this.lobCode = lobCode;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	public String getValidateVariable() {
		return validateVariable;
	}
	public void setValidateVariable(String validateVariable) {
		this.validateVariable = validateVariable;
	}
	public long getTemplateId() {
		return templateId;
	}
	public void setTemplateId(long templateId) {
		this.templateId = templateId;
	}
	@Override
	public String toString() {
		return "DocumentTemplate [id=" + id + ", templateName=" + templateName + ", documentId=" + documentId
				+ ", description=" + description + ", mimeType=" + mimeType + ", isForm=" + isForm + ", isStatic="
				+ isStatic + ", isMicDocument=" + isMicDocument + ", editionDate=" + editionDate + ", stateCode="
				+ stateCode + ", revision=" + revision + ", isManuscipt=" + isManuscipt + ", isInterline=" + isInterline
				+ ", requiresAdoption=" + requiresAdoption + ", wordFormat=" + wordFormat + ", isMultiAttach="
				+ isMultiAttach + ", isManualUpload=" + isManualUpload + ", lobCode=" + lobCode + ", productCode="
				+ productCode + ", customerCode=" + customerCode + ", validateVariable=" + validateVariable + "]";
	}
}
