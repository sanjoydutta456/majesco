package com.coverall.mic.rest.policy.api.service.model;

public class InforcePremium {
	
	private String product;
    private String asOfDate;
    private String sourceSystemRequestNo;
    private double inForcePremium;
    private int inForcePolicyCount;
    
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getAsOfDate() {
		return asOfDate;
	}
	public void setAsOfDate(String asOfDate) {
		this.asOfDate = asOfDate;
	}
	public String getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}
	public void setSourceSystemRequestNo(String sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}
	public double getInForcePremium() {
		return inForcePremium;
	}
	public void setInForcePremium(double inForcePremium) {
		this.inForcePremium = inForcePremium;
	}
	public int getInForcePolicyCount() {
		return inForcePolicyCount;
	}
	public void setInForcePolicyCount(int inForcePolicyCount) {
		this.inForcePolicyCount = inForcePolicyCount;
	}
	@Override
	public String toString() {
		return "InforcePremium [product=" + product + ", asOfDate=" + asOfDate + ", sourceSystemRequestNo="
				+ sourceSystemRequestNo + ", inForcePremium=" + inForcePremium + ", inForcePolicyCount="
				+ inForcePolicyCount + "]";
	}
}
