package com.coverall.mic.rest.policy.api.service.model;

public class QuotePolicyAttachmentDelete {
	
	String code;
	String description;
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	@Override
	public String toString() {
		return "QuotePolicyAttachmentDelete [code=" + code + ", description="
				+ description + "]";
	}
	
}
