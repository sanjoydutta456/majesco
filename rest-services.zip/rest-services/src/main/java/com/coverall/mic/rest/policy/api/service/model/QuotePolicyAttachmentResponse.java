package com.coverall.mic.rest.policy.api.service.model;

public class QuotePolicyAttachmentResponse {
	
	String sourceSystemUserId;
	String sourceSystemCode;
	long sourceSystemRequestNo;
	String fileId;
	String filename;
	String fileDescription;
	String fileType;
	String fileAddedBy;
	String fileSize;
	String lastUpdated;
	String status;
	String file;
	
	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}
	public void setSourceSystemUserId(String sourceSystemUserId) {
		this.sourceSystemUserId = sourceSystemUserId;
	}
	public String getSourceSystemCode() {
		return sourceSystemCode;
	}
	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}
	public long getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}
	public void setSourceSystemRequestNo(long sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public String getFileDescription() {
		return fileDescription;
	}
	public void setFileDescription(String fileDescription) {
		this.fileDescription = fileDescription;
	}
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	public String getFileAddedBy() {
		return fileAddedBy;
	}
	public void setFileAddedBy(String fileAddedBy) {
		this.fileAddedBy = fileAddedBy;
	}
	public String getFileSize() {
		return fileSize;
	}
	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}
	public String getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(String lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getFile() {
		return file;
	}
	public void setFile(String file) {
		this.file = file;
	}
	@Override
	public String toString() {
		return "QuotePolicyAttachment [sourceSystemUserId="
				+ sourceSystemUserId + ", sourceSystemCode=" + sourceSystemCode
				+ ", sourceSystemRequestNo=" + sourceSystemRequestNo
				+ ", fileId=" + fileId + ", filename=" + filename
				+ ", fileType=" + fileType + ", fileAddedBy=" + fileAddedBy
				+ ", fileSize=" + fileSize + ", lastUpdated=" + lastUpdated
				+ ", status=" + status + ", file=" + file + "]";
	}

}
