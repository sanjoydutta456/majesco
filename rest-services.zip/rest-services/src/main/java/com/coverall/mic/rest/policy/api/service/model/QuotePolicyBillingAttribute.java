package com.coverall.mic.rest.policy.api.service.model;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class QuotePolicyBillingAttribute {

	String sourceSystemUserId;
	String sourceSystemCode;
	long sourceSystemRequestNo;
	String payPlanName;
	String payer;
	String paymentMethod;
	String billingEffectiveDate;
	String account;
	String billType;
	@JsonIgnore
	String billTypeFlag;
		
	List<BillingInstallment> installments;
	
	
	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}
	public void setSourceSystemUserId(String sourceSystemUserId) {
		this.sourceSystemUserId = sourceSystemUserId;
	}
	public String getSourceSystemCode() {
		return sourceSystemCode;
	}
	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}
	public long getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}
	public void setSourceSystemRequestNo(long sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}
	public String getPayPlanName() {
		return payPlanName;
	}
	public void setPayPlanName(String payPlanName) {
		this.payPlanName = payPlanName;
	}
	public String getBillingEffectiveDate() {
		return billingEffectiveDate;
	}
	public void setBillingEffectiveDate(String billingEffectiveDate) {
		this.billingEffectiveDate = billingEffectiveDate;
	}
	public String getPayer() {
		return payer;
	}
	public void setPayer(String payer) {
		this.payer = payer;
	}
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public List<BillingInstallment> getInstallments() {
		return installments;
	}
	public void setInstallments(List<BillingInstallment> installments) {
		this.installments = installments;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getBillType() {
		return billType;
	}
	public void setBillType(String billType) {
		this.billType = billType;
	}
	
	@JsonIgnore
	public String getBillTypeFlag() {
		return billTypeFlag;
	}
	public void setBillTypeFlag(String billTypeFlag) {
		this.billTypeFlag = billTypeFlag;
	}
	
	
}
