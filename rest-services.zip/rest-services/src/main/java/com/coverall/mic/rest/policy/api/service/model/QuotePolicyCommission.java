package com.coverall.mic.rest.policy.api.service.model;

import org.codehaus.jackson.annotate.JsonIgnore;

public class QuotePolicyCommission {

	String sourceSystemUserId;
	String sourceSystemCode;
	long sourceSystemRequestNo;
	int commissionId;
	String producerName;
	String commissionPlanName;
	String commissionPlanType;
	String commissionPlanAmount;
	double overrideCommission;
	double calculatedCommissionAmount;
	double netCommissionAmount;
	@JsonIgnore
	String isPercent;

	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}
	public void setSourceSystemUserId(String sourceSystemUserId) {
		this.sourceSystemUserId = sourceSystemUserId;
	}
	public String getSourceSystemCode() {
		return sourceSystemCode;
	}
	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}
	public long getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}
	public void setSourceSystemRequestNo(long sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}
	public int getCommissionId() {
		return commissionId;
	}
	public void setCommissionId(int commissionId) {
		this.commissionId = commissionId;
	}
	public String getProducerName() {
		return producerName;
	}
	public void setProducerName(String producerName) {
		this.producerName = producerName;
	}
	public String getCommissionPlanName() {
		return commissionPlanName;
	}
	public void setCommissionPlanName(String commissionPlanName) {
		this.commissionPlanName = commissionPlanName;
	}
	public String getCommissionPlanType() {
		return commissionPlanType;
	}
	public void setCommissionPlanType(String commissionPlanType) {
		this.commissionPlanType = commissionPlanType;
	}
	public String getCommissionPlanAmount() {
		return commissionPlanAmount;
	}
	public void setCommissionPlanAmount(String commissionPlanAmount) {
		this.commissionPlanAmount = commissionPlanAmount;
	}
	public double getOverrideCommission() {
		return overrideCommission;
	}
	public void setOverrideCommission(double overrideCommission) {
		this.overrideCommission = overrideCommission;
	}
	public double getCalculatedCommissionAmount() {
		return calculatedCommissionAmount;
	}
	public void setCalculatedCommissionAmount(double calculatedCommissionAmount) {
		this.calculatedCommissionAmount = calculatedCommissionAmount;
	}
	public double getNetCommissionAmount() {
		return netCommissionAmount;
	}
	public void setNetCommissionAmount(double netCommissionAmount) {
		this.netCommissionAmount = netCommissionAmount;
	}
	@JsonIgnore
	public String getIsPercent() {
		return isPercent;
	}
	public void setIsPercent(String isPercent) {
		this.isPercent = isPercent;
	}
	
}
