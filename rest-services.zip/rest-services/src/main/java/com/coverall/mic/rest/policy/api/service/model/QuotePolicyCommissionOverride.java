package com.coverall.mic.rest.policy.api.service.model;

public class QuotePolicyCommissionOverride {
	String sourceSystemUserId;
	String sourceSystemCode;
	long sourceSystemRequestNo;
	int commissionId;
	double overrideCommission;

	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}
	public void setSourceSystemUserId(String sourceSystemUserId) {
		this.sourceSystemUserId = sourceSystemUserId;
	}
	public String getSourceSystemCode() {
		return sourceSystemCode;
	}
	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}
	public long getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}
	public void setSourceSystemRequestNo(long sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}
	public int getCommissionId() {
		return commissionId;
	}
	public void setCommissionId(int commissionId) {
		this.commissionId = commissionId;
	}
	public double getOverrideCommission() {
		return overrideCommission;
	}
	public void setOverrideCommission(double overrideCommission) {
		this.overrideCommission = overrideCommission;
	}




}
