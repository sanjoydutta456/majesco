package com.coverall.mic.rest.policy.api.service.model;

public class QuotePolicyDocument {
	
	public String templateId;
	public String documentId;
	public String documentName;
	public String documentEditionDate;
	public String documentDescription;
	public String rank;
	public String manualAttach;
	public String deleteOverride;
	public String adoptionStates;
	public String dateCreated;
	public String dateModified;
	
	public String getTemplateId() {
		return templateId;
	}
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}
	public String getDocumentId() {
		return documentId;
	}
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	public String getDocumentEditionDate() {
		return documentEditionDate;
	}
	public void setDocumentEditionDate(String documentEditionDate) {
		this.documentEditionDate = documentEditionDate;
	}
	public String getDocumentDescription() {
		return documentDescription;
	}
	public void setDocumentDescription(String documentDescription) {
		this.documentDescription = documentDescription;
	}
	public String getRank() {
		return rank;
	}
	public void setRank(String rank) {
		this.rank = rank;
	}
	public String getManualAttach() {
		return manualAttach;
	}
	public void setManualAttach(String manualAttach) {
		this.manualAttach = manualAttach;
	}
	public String getDeleteOverride() {
		return deleteOverride;
	}
	public void setDeleteOverride(String deleteOverride) {
		this.deleteOverride = deleteOverride;
	}
	public String getAdoptionStates() {
		return adoptionStates;
	}
	public void setAdoptionStates(String adoptionStates) {
		this.adoptionStates = adoptionStates;
	}
	public String getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(String dateCreated) {
		this.dateCreated = dateCreated;
	}
	public String getDateModified() {
		return dateModified;
	}
	public void setDateModified(String dateModified) {
		this.dateModified = dateModified;
	}
}
