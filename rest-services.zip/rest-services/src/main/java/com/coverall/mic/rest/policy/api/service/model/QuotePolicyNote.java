package com.coverall.mic.rest.policy.api.service.model;

import java.util.List;

public class QuotePolicyNote {
	
	String sourceSystemUserId;
	String sourceSystemCode;
	long sourceSystemRequestNo;
	String id;
	String title;
	String type;
	String lastModifiedBy;
	String lastModifiedOn;
	String dueOn;
	String complete;
	String completedBy;
	String completionOn;
	String lastMemo;
	List<QuotePolicyNoteHistory> history;

	
	
	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}

	public void setSourceSystemUserId(String sourceSystemUserId) {
		this.sourceSystemUserId = sourceSystemUserId;
	}

	public String getSourceSystemCode() {
		return sourceSystemCode;
	}

	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}

	public long getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}

	public void setSourceSystemRequestNo(long sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public String getLastModifiedOn() {
		return lastModifiedOn;
	}

	public void setLastModifiedOn(String lastModifiedOn) {
		this.lastModifiedOn = lastModifiedOn;
	}

	public String getDueOn() {
		return dueOn;
	}

	public void setDueOn(String dueOn) {
		this.dueOn = dueOn;
	}

	public String getComplete() {
		return complete;
	}

	public void setComplete(String complete) {
		this.complete = complete;
	}

	public String getCompletedBy() {
		return completedBy;
	}

	public void setCompletedBy(String completedBy) {
		this.completedBy = completedBy;
	}

	public String getCompletionOn() {
		return completionOn;
	}

	public void setCompletionOn(String completionOn) {
		this.completionOn = completionOn;
	}

	public String getLastMemo() {
		return lastMemo;
	}

	public void setLastMemo(String lastMemo) {
		this.lastMemo = lastMemo;
	}

	public List<QuotePolicyNoteHistory> getHistory() {
		return history;
	}

	public void setHistory(List<QuotePolicyNoteHistory> history) {
		this.history = history;
	}

	@Override
	public String toString() {
		return "QuotePolicyNote ["
				+ "sourceSystemUserId=" + sourceSystemUserId 
				+ ", sourceSystemCode=" + sourceSystemCode
				+ ", sourceSystemRequestNo=" + sourceSystemRequestNo
				+ ", id=" + id 
				+ ", title=" + title
				+ ", type=" + type 
				+ ", lastModifiedBy=" + lastModifiedBy
				+ ", lastModifiedOn=" + lastModifiedOn
				+ ", dueOn=" + dueOn 
				+ ", complete=" + complete
				+ ", completedBy=" + completedBy 
				+ ", completionOn=" + completionOn 
				+ ", lastMemo=" + lastMemo
				+ "]";
	}

}
