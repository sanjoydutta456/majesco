package com.coverall.mic.rest.policy.api.service.model;

public class QuotePolicyNoteHistory {
	
	String previousMemo;
	String userCreated;
	String dateCreated;
	
	public String getPreviousMemo() {
		return previousMemo;
	}

	public void setPreviousMemo(String previousMemo) {
		this.previousMemo = previousMemo;
	}

	public String getUserCreated() {
		return userCreated;
	}

	public void setUserCreated(String userCreated) {
		this.userCreated = userCreated;
	}

	public String getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(String dateCreated) {
		this.dateCreated = dateCreated;
	}

	@Override
	public String toString() {
		return "QuotePolicyNoteHistory ["
				+ " previousMemo=" + previousMemo 
				+ ", userCreated=" + userCreated
				+ ", dateCreated=" + dateCreated + "]";
	}

}
