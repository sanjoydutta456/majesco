package com.coverall.mic.rest.policy.api.service.model;

import java.util.ArrayList;

public class QuotePolicyPagination {
	
	String correlationid;	
	String pageSize;
	String totalRecords;
	String pageNumber;
	String lastPageNumber;
	String startIndex;
	String endIndex;
	
	ArrayList<QuotePolicyPaginationLinks> links;

	public String getCorrelationid() {
		return correlationid;
	}

	public void setCorrelationid(String correlationid) {
		this.correlationid = correlationid;
	}

	public String getPageSize() {
		return pageSize;
	}

	public void setPageSize(String pageSize) {
		this.pageSize = pageSize;
	}

	public String getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(String totalRecords) {
		this.totalRecords = totalRecords;
	}

	public String getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(String pageNumber) {
		this.pageNumber = pageNumber;
	}

	public String getLastPageNumber() {
		return lastPageNumber;
	}

	public void setLastPageNumber(String lastPageNumber) {
		this.lastPageNumber = lastPageNumber;
	}

	public String getStartIndex() {
		return startIndex;
	}

	public void setStartIndex(String startIndex) {
		this.startIndex = startIndex;
	}

	public String getEndIndex() {
		return endIndex;
	}

	public void setEndIndex(String endIndex) {
		this.endIndex = endIndex;
	}

	public ArrayList<QuotePolicyPaginationLinks> getLinks() {
		return links;
	}

	public void setLinks(ArrayList<QuotePolicyPaginationLinks> links) {
		this.links = links;
	}

	@Override
	public String toString() {
		return "QuotePolicyPagination [correlationid=" + correlationid
				+ ", pageSize=" + pageSize + ", totalRecords=" + totalRecords
				+ ", pageNumber=" + pageNumber + ", lastPageNumber="
				+ lastPageNumber + ", startIndex=" + startIndex + ", endIndex="
				+ endIndex + ", links=" + links + "]";
	}
}
