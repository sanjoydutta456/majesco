package com.coverall.mic.rest.policy.api.service.model;

public class QuotePolicyPaginationLinks {
	
	String next;
	String prev;
	String first;
	String last;
	
	public String getNext() {
		return next;
	}
	public void setNext(String next) {
		this.next = next;
	}
	public String getPrev() {
		return prev;
	}
	public void setPrev(String prev) {
		this.prev = prev;
	}
	public String getFirst() {
		return first;
	}
	public void setFirst(String first) {
		this.first = first;
	}
	public String getLast() {
		return last;
	}
	public void setLast(String last) {
		this.last = last;
	}
	@Override
	public String toString() {
		return "QuotePolicyPaginationLinks [next=" + next + ", prev=" + prev
				+ ", first=" + first + ", last=" + last + "]";
	}
	
}
