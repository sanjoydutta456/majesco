package com.coverall.mic.rest.policy.api.service.model;

public class QuotePolicyPaymentPlan {
	
	private String sourceSystemUserId;
    private String sourceSystemCode;
    private long sourceSystemRequestNo;
    private int payPlanId;
    private String payPlanCode;
    private String payPlanDescription;
    private String numberOfInstallment; 
    private String installmentIntervalDays;
    private String depositAmount;
    private String depositPercentage;
    private String minPremium;
    private String rounding;
    private String effectiveDate;
    private String expirationDate;
    private String userModified;    
    private String modifiedDate;
    
	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}
	public void setSourceSystemUserId(String sourceSystemUserId) {
		this.sourceSystemUserId = sourceSystemUserId;
	}
	public String getSourceSystemCode() {
		return sourceSystemCode;
	}
	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}
	public long getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}
	public void setSourceSystemRequestNo(long sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}
	public int getPayPlanId() {
		return payPlanId;
	}
	public void setPayPlanId(int payPlanId) {
		this.payPlanId = payPlanId;
	}
	public String getPayPlanCode() {
		return payPlanCode;
	}
	public void setPayPlanCode(String payPlanCode) {
		this.payPlanCode = payPlanCode;
	}
	public String getPayPlanDescription() {
		return payPlanDescription;
	}
	public void setPayPlanDescription(String payPlanDescription) {
		this.payPlanDescription = payPlanDescription;
	}
	public String getNumberOfInstallment() {
		return numberOfInstallment;
	}
	public void setNumberOfInstallment(String numberOfInstallment) {
		this.numberOfInstallment = numberOfInstallment;
	}
	public String getInstallmentIntervalDays() {
		return installmentIntervalDays;
	}
	public void setInstallmentIntervalDays(String installmentIntervalDays) {
		this.installmentIntervalDays = installmentIntervalDays;
	}
	public String getDepositAmount() {
		return depositAmount;
	}
	public void setDepositAmount(String depositAmount) {
		this.depositAmount = depositAmount;
	}
	public String getDepositPercentage() {
		return depositPercentage;
	}
	public void setDepositPercentage(String depositPercentage) {
		this.depositPercentage = depositPercentage;
	}
	public String getMinPremium() {
		return minPremium;
	}
	public void setMinPremium(String minPremium) {
		this.minPremium = minPremium;
	}
	public String getRounding() {
		return rounding;
	}
	public void setRounding(String rounding) {
		this.rounding = rounding;
	}
	public String getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}
	public String getUserModified() {
		return userModified;
	}
	public void setUserModified(String userModified) {
		this.userModified = userModified;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
}
