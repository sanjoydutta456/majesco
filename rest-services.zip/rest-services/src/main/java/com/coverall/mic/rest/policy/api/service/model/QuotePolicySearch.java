package com.coverall.mic.rest.policy.api.service.model;

import java.util.ArrayList;

import org.codehaus.jackson.annotate.JsonIgnore;

public class QuotePolicySearch {
	
	ArrayList<QuotePolicySearchResult> searchResults;
	QuotePolicyPagination pagination;
	
	@JsonIgnore
	ArrayList<QuotePolicySearchResult> allResults;
	
	public ArrayList<QuotePolicySearchResult> getSearchResults() {
		return searchResults;
	}
	public void setSearchResults(ArrayList<QuotePolicySearchResult> searchResults) {
		this.searchResults = searchResults;
	}
	public QuotePolicyPagination getPagination() {
		return pagination;
	}
	public void setPagination(QuotePolicyPagination pagination) {
		this.pagination = pagination;
	}
	
	@JsonIgnore
	public ArrayList<QuotePolicySearchResult> getAllResults() {
		return allResults;
	}
	public void setAllResults(ArrayList<QuotePolicySearchResult> allResults) {
		this.allResults = allResults;
	}
	
	@Override
	public String toString() {
		return "QuotePolicySearch [searchResults=" + searchResults
				+ ", pagination=" + pagination + ", allResults=" + allResults
				+ "]";
	}

}
