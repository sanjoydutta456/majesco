package com.coverall.mic.rest.policy.api.service.model;

public class QuotePolicySearchResult {
	
	String entityReference;
	String policyNumber;
	String effectiveDate;
	String expirationDate;
	String insuredName;
	String insuredAddress;
	String insuredDBA;
	String insuredFEIN;
	String insuredPhone;
	String insuredEmail;
	String agencyName;
	String agencyNumber;
	String agencyAddress;
	String agencyPhone;
	String underwriter;
	String underwriterPhone;
	String marketSegment;
	String marketManager;
	String product;
	double totalWrittenPrem;
	double fullTermPrem;
	String entityType;
	String insuredType;
	String status;
	double currentDue;
	
	public String getEntityReference() {
		return entityReference;
	}
	public void setEntityReference(String entityReference) {
		this.entityReference = entityReference;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}
	public String getInsuredName() {
		return insuredName;
	}
	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}
	public String getInsuredAddress() {
		return insuredAddress;
	}
	public void setInsuredAddress(String insuredAddress) {
		this.insuredAddress = insuredAddress;
	}
	public String getInsuredDBA() {
		return insuredDBA;
	}
	public void setInsuredDBA(String insuredDBA) {
		this.insuredDBA = insuredDBA;
	}
	public String getInsuredFEIN() {
		return insuredFEIN;
	}
	public void setInsuredFEIN(String insuredFEIN) {
		this.insuredFEIN = insuredFEIN;
	}
	public String getInsuredPhone() {
		return insuredPhone;
	}
	public void setInsuredPhone(String insuredPhone) {
		this.insuredPhone = insuredPhone;
	}
	public String getInsuredEmail() {
		return insuredEmail;
	}
	public void setInsuredEmail(String insuredEmail) {
		this.insuredEmail = insuredEmail;
	}
	public String getAgencyName() {
		return agencyName;
	}
	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}
	public String getAgencyNumber() {
		return agencyNumber;
	}
	public void setAgencyNumber(String agencyNumber) {
		this.agencyNumber = agencyNumber;
	}
	public String getAgencyAddress() {
		return agencyAddress;
	}
	public void setAgencyAddress(String agencyAddress) {
		this.agencyAddress = agencyAddress;
	}
	public String getAgencyPhone() {
		return agencyPhone;
	}
	public void setAgencyPhone(String agencyPhone) {
		this.agencyPhone = agencyPhone;
	}
	public String getUnderwriter() {
		return underwriter;
	}
	public void setUnderwriter(String underwriter) {
		this.underwriter = underwriter;
	}
	public String getUnderwriterPhone() {
		return underwriterPhone;
	}
	public void setUnderwriterPhone(String underwriterPhone) {
		this.underwriterPhone = underwriterPhone;
	}
	public String getMarketSegment() {
		return marketSegment;
	}
	public void setMarketSegment(String marketSegment) {
		this.marketSegment = marketSegment;
	}
	public String getMarketManager() {
		return marketManager;
	}
	public void setMarketManager(String marketManager) {
		this.marketManager = marketManager;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getEntityType() {
		return entityType;
	}
	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}
	public String getInsuredType() {
		return insuredType;
	}
	public void setInsuredType(String insuredType) {
		this.insuredType = insuredType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public double getTotalWrittenPrem() {
		return totalWrittenPrem;
	}
	public void setTotalWrittenPrem(double totalWrittenPrem) {
		this.totalWrittenPrem = totalWrittenPrem;
	}
	public double getFullTermPrem() {
		return fullTermPrem;
	}
	public void setFullTermPrem(double fullTermPrem) {
		this.fullTermPrem = fullTermPrem;
	}
	public double getCurrentDue() {
		return currentDue;
	}
	public void setCurrentDue(double currentDue) {
		this.currentDue = currentDue;
	}
	@Override
	public String toString() {
		return "QuotePolicySearchResult [entityReference=" + entityReference
				+ ", policyNumber=" + policyNumber + ", effectiveDate="
				+ effectiveDate + ", expirationDate=" + expirationDate
				+ ", insuredName=" + insuredName + ", insuredAddress="
				+ insuredAddress + ", insuredDBA=" + insuredDBA
				+ ", insuredFEIN=" + insuredFEIN + ", insuredPhone="
				+ insuredPhone + ", insuredEmail=" + insuredEmail
				+ ", agencyName=" + agencyName + ", agencyNumber="
				+ agencyNumber + ", agencyAddress=" + agencyAddress
				+ ", agencyPhone=" + agencyPhone + ", underwriter="
				+ underwriter + ", underwriterPhone=" + underwriterPhone
				+ ", marketSegment=" + marketSegment + ", marketManager="
				+ marketManager + ", product=" + product
				+ ", totalWrittenPrem=" + totalWrittenPrem + ", fullTermPrem="
				+ fullTermPrem + ", entityType=" + entityType
				+ ", insuredType=" + insuredType + ", status=" + status
				+ ", currentDue=" + currentDue + "]";
	}
}
