package com.coverall.mic.rest.policy.api.service.model;

public class QuotePolicyStatus {

	String status;
	String entityType;
	String entityReference;
	String statusTimestamp;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getEntityType() {
		return entityType;
	}
	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}
	public String getEntityReference() {
		return entityReference;
	}
	public void setEntityReference(String entityReference) {
		this.entityReference = entityReference;
	}
	public String getStatusTimestamp() {
		return statusTimestamp;
	}
	public void setStatusTimestamp(String statusTimestamp) {
		this.statusTimestamp = statusTimestamp;
	}
	@Override
	public String toString() {
		return "QuotePolicyStatus [" + (status != null ? "status=" + status + ", " : "")
				+ (entityType != null ? "entityType=" + entityType + ", " : "")
				+ (entityReference != null ? "entityReference=" + entityReference + ", " : "")
				+ (statusTimestamp != null ? "statusTimestamp=" + statusTimestamp : "") + "]";
	}
	
	
}
