package com.coverall.mic.rest.policy.api.service.model;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL) 
public class QuotePolicySurcharge {
	
	String id;
	String gid;
	String lobCode;    
	String lobDescription; 
	String stateCode;    
	String stateName;   
	String cityCode;   
	String cityName;  
	String name;  
	String description; 
	String type;    
	String annualFee;         
	String transactionFee;         
	String depositFee;         
	String premiumBasis;         
	String surchargeAmount;         
	String fullTermFee;         
	String totalFee;
	String feeNotSubjectToAudit;
	String waiveIndicator;         
	String waivedFee;
	String waivedTax;         
	String waivedColFees;  
	String policyWaivedSurcharge;         
	String priorSurchargeAdjustment;         
	String isAmountInPercent;         
	String handlingMethod;      
	String unitCoverage;    
	String unitNumber;  
	String unitId;
	String entityStatus;
    String productCode;
    String nameUk;
    String optionNo;
    String isOptionSelected;
    String refName;
    String refValue;
    String modEntityType;
    String modEntityReference;
    String addEntityReference;
    String addEntityType;
    String dateCreated;
    String dateModified;
    String userCreated;
    String userModified;
    String auditFlag;
    String statCode;
    String annualStatementLine;
    String dateDeleted;
    String delEntityReference;
    String delEntityType;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getGid() {
		return gid;
	}
	public void setGid(String gid) {
		this.gid = gid;
	}
	public String getLobCode() {
		return lobCode;
	}
	public void setLobCode(String lobCode) {
		this.lobCode = lobCode;
	}
	public String getLobDescription() {
		return lobDescription;
	}
	public void setLobDescription(String lobDescription) {
		this.lobDescription = lobDescription;
	}
	public String getStateCode() {
		return stateCode;
	}
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public String getCityCode() {
		return cityCode;
	}
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getAnnualFee() {
		return annualFee;
	}
	public void setAnnualFee(String annualFee) {
		this.annualFee = annualFee;
	}
	public String getTransactionFee() {
		return transactionFee;
	}
	public void setTransactionFee(String transactionFee) {
		this.transactionFee = transactionFee;
	}
	public String getDepositFee() {
		return depositFee;
	}
	public void setDepositFee(String depositFee) {
		this.depositFee = depositFee;
	}
	public String getPremiumBasis() {
		return premiumBasis;
	}
	public void setPremiumBasis(String premiumBasis) {
		this.premiumBasis = premiumBasis;
	}
	public String getSurchargeAmount() {
		return surchargeAmount;
	}
	public void setSurchargeAmount(String surchargeAmount) {
		this.surchargeAmount = surchargeAmount;
	}
	public String getFullTermFee() {
		return fullTermFee;
	}
	public void setFullTermFee(String fullTermFee) {
		this.fullTermFee = fullTermFee;
	}
	public String getTotalFee() {
		return totalFee;
	}
	public void setTotalFee(String totalFee) {
		this.totalFee = totalFee;
	}
	public String getFeeNotSubjectToAudit() {
		return feeNotSubjectToAudit;
	}
	public void setFeeNotSubjectToAudit(String feeNotSubjectToAudit) {
		this.feeNotSubjectToAudit = feeNotSubjectToAudit;
	}
	public String getWaiveIndicator() {
		return waiveIndicator;
	}
	public void setWaiveIndicator(String waiveIndicator) {
		this.waiveIndicator = waiveIndicator;
	}
	public String getWaivedFee() {
		return waivedFee;
	}
	public void setWaivedFee(String waivedFee) {
		this.waivedFee = waivedFee;
	}
	public String getWaivedTax() {
		return waivedTax;
	}
	public void setWaivedTax(String waivedTax) {
		this.waivedTax = waivedTax;
	}
	public String getWaivedColFees() {
		return waivedColFees;
	}
	public void setWaivedColFees(String waivedColFees) {
		this.waivedColFees = waivedColFees;
	}
	public String getPolicyWaivedSurcharge() {
		return policyWaivedSurcharge;
	}
	public void setPolicyWaivedSurcharge(String policyWaivedSurcharge) {
		this.policyWaivedSurcharge = policyWaivedSurcharge;
	}
	public String getPriorSurchargeAdjustment() {
		return priorSurchargeAdjustment;
	}
	public void setPriorSurchargeAdjustment(String priorSurchargeAdjustment) {
		this.priorSurchargeAdjustment = priorSurchargeAdjustment;
	}
	public String getIsAmountInPercent() {
		return isAmountInPercent;
	}
	public void setIsAmountInPercent(String isAmountInPercent) {
		this.isAmountInPercent = isAmountInPercent;
	}
	public String getHandlingMethod() {
		return handlingMethod;
	}
	public void setHandlingMethod(String handlingMethod) {
		this.handlingMethod = handlingMethod;
	}
	public String getUnitCoverage() {
		return unitCoverage;
	}
	public void setUnitCoverage(String unitCoverage) {
		this.unitCoverage = unitCoverage;
	}
	public String getUnitNumber() {
		return unitNumber;
	}
	public void setUnitNumber(String unitNumber) {
		this.unitNumber = unitNumber;
	}
	public String getUnitId() {
		return unitId;
	}
	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}
	public String getEntityStatus() {
		return entityStatus;
	}
	public void setEntityStatus(String entityStatus) {
		this.entityStatus = entityStatus;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getNameUk() {
		return nameUk;
	}
	public void setNameUk(String nameUk) {
		this.nameUk = nameUk;
	}
	public String getOptionNo() {
		return optionNo;
	}
	public void setOptionNo(String optionNo) {
		this.optionNo = optionNo;
	}
	public String getIsOptionSelected() {
		return isOptionSelected;
	}
	public void setIsOptionSelected(String isOptionSelected) {
		this.isOptionSelected = isOptionSelected;
	}
	public String getRefName() {
		return refName;
	}
	public void setRefName(String refName) {
		this.refName = refName;
	}
	public String getRefValue() {
		return refValue;
	}
	public void setRefValue(String refValue) {
		this.refValue = refValue;
	}
	public String getModEntityType() {
		return modEntityType;
	}
	public void setModEntityType(String modEntityType) {
		this.modEntityType = modEntityType;
	}
	public String getModEntityReference() {
		return modEntityReference;
	}
	public void setModEntityReference(String modEntityReference) {
		this.modEntityReference = modEntityReference;
	}
	public String getAddEntityReference() {
		return addEntityReference;
	}
	public void setAddEntityReference(String addEntityReference) {
		this.addEntityReference = addEntityReference;
	}
	public String getAddEntityType() {
		return addEntityType;
	}
	public void setAddEntityType(String addEntityType) {
		this.addEntityType = addEntityType;
	}
	public String getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(String dateCreated) {
		this.dateCreated = dateCreated;
	}
	public String getDateModified() {
		return dateModified;
	}
	public void setDateModified(String dateModified) {
		this.dateModified = dateModified;
	}
	public String getUserCreated() {
		return userCreated;
	}
	public void setUserCreated(String userCreated) {
		this.userCreated = userCreated;
	}
	public String getUserModified() {
		return userModified;
	}
	public void setUserModified(String userModified) {
		this.userModified = userModified;
	}
	public String getAuditFlag() {
		return auditFlag;
	}
	public void setAuditFlag(String auditFlag) {
		this.auditFlag = auditFlag;
	}
	public String getStatCode() {
		return statCode;
	}
	public void setStatCode(String statCode) {
		this.statCode = statCode;
	}
	public String getAnnualStatementLine() {
		return annualStatementLine;
	}
	public void setAnnualStatementLine(String annualStatementLine) {
		this.annualStatementLine = annualStatementLine;
	}
	public String getDateDeleted() {
		return dateDeleted;
	}
	public void setDateDeleted(String dateDeleted) {
		this.dateDeleted = dateDeleted;
	}
	public String getDelEntityReference() {
		return delEntityReference;
	}
	public void setDelEntityReference(String delEntityReference) {
		this.delEntityReference = delEntityReference;
	}
	public String getDelEntityType() {
		return delEntityType;
	}
	public void setDelEntityType(String delEntityType) {
		this.delEntityType = delEntityType;
	}
	@Override
	public String toString() {
		return "QuotePolicySurcharge [id=" + id + ", gid=" + gid + ", lobCode="
				+ lobCode + ", lobDescription=" + lobDescription
				+ ", stateCode=" + stateCode + ", stateName=" + stateName
				+ ", cityCode=" + cityCode + ", cityName=" + cityName
				+ ", name=" + name + ", description=" + description + ", type="
				+ type + ", annualFee=" + annualFee + ", transactionFee="
				+ transactionFee + ", depositFee=" + depositFee
				+ ", premiumBasis=" + premiumBasis + ", surchargeAmount="
				+ surchargeAmount + ", fullTermFee=" + fullTermFee
				+ ", totalFee=" + totalFee + ", feeNotSubjectToAudit="
				+ feeNotSubjectToAudit + ", waiveIndicator=" + waiveIndicator
				+ ", waivedFee=" + waivedFee + ", waivedTax=" + waivedTax
				+ ", waivedColFees=" + waivedColFees
				+ ", policyWaivedSurcharge=" + policyWaivedSurcharge
				+ ", priorSurchargeAdjustment=" + priorSurchargeAdjustment
				+ ", isAmountInPercent=" + isAmountInPercent
				+ ", handlingMethod=" + handlingMethod + ", unitCoverage="
				+ unitCoverage + ", unitNumber=" + unitNumber + ", unitId="
				+ unitId + ", entityStatus=" + entityStatus + ", productCode="
				+ productCode + ", nameUk=" + nameUk + ", optionNo=" + optionNo
				+ ", isOptionSelected=" + isOptionSelected + ", refName="
				+ refName + ", refValue=" + refValue + ", modEntityType="
				+ modEntityType + ", modEntityReference=" + modEntityReference
				+ ", addEntityReference=" + addEntityReference
				+ ", addEntityType=" + addEntityType + ", dateCreated="
				+ dateCreated + ", dateModified=" + dateModified
				+ ", userCreated=" + userCreated + ", userModified="
				+ userModified + ", auditFlag=" + auditFlag + ", statCode="
				+ statCode + ", annualStatementLine=" + annualStatementLine
				+ ", dateDeleted=" + dateDeleted + ", delEntityReference="
				+ delEntityReference + ", delEntityType=" + delEntityType + "]";
	}
}
