package com.coverall.mic.rest.policy.api.service.model;

import java.util.ArrayList;

public class QuotePolicyTransactions {
	
	String entityType;
	String entityReference;
	String transactionTimestamp;
	
	ArrayList<Transaction> transactions;

	public String getEntityType() {
		return entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	public String getEntityReference() {
		return entityReference;
	}

	public void setEntityReference(String entityReferemce) {
		this.entityReference = entityReferemce;
	}
	
	public String getTransactionTimestamp() {
		return transactionTimestamp;
	}

	public void setTransactionTimestamp(String transactionTimestamp) {
		this.transactionTimestamp = transactionTimestamp;
	}

	public ArrayList<Transaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(ArrayList<Transaction> transactions) {
		this.transactions = transactions;
	}

	@Override
	public String toString() {
		return "QuotePolicyTransactions [entityType=" + entityType
				+ ", entityReference=" + entityReference
				+ ", transactionTimestamp=" + transactionTimestamp
				+ ", transactions=" + transactions + "]";
	}
	
}
