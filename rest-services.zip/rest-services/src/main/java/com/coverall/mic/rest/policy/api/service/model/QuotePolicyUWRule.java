package com.coverall.mic.rest.policy.api.service.model;

import java.util.Map;

public class QuotePolicyUWRule {
	
	String sourceSystemUserId;
	String sourceSystemCode;
	long sourceSystemRequestNo;
	String uwRuleTitle;
	String uwRuleDescreption;
	String uwRuleResult;
	Map<String,String> uwRuleRemarks;
	
	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}
	public void setSourceSystemUserId(String sourceSystemUserId) {
		this.sourceSystemUserId = sourceSystemUserId;
	}
	public String getSourceSystemCode() {
		return sourceSystemCode;
	}
	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}
	public long getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}
	public void setSourceSystemRequestNo(long sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}
	public String getUwRuleTitle() {
		return uwRuleTitle;
	}
	public void setUwRuleTitle(String uwRuleTitle) {
		this.uwRuleTitle = uwRuleTitle;
	}
	public String getUwRuleDescreption() {
		return uwRuleDescreption;
	}
	public void setUwRuleDescreption(String uwRuleDescreption) {
		this.uwRuleDescreption = uwRuleDescreption;
	}
	public String getUwRuleResult() {
		return uwRuleResult;
	}
	public void setUwRuleResult(String uwRuleResult) {
		this.uwRuleResult = uwRuleResult;
	}
	public Map<String, String> getUwRuleRemarks() {
		return uwRuleRemarks;
	}
	public void setUwRuleRemarks(Map<String, String> uwRuleRemarks) {
		this.uwRuleRemarks = uwRuleRemarks;
	}

}
