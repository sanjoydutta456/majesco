package com.coverall.mic.rest.policy.api.service.model;

public class QuotePolicyUWRuleAction {
	
	String sourceSystemUserId;
	String sourceSystemCode;
	long sourceSystemRequestNo;
	String remarks;
	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}
	public void setSourceSystemUserId(String sourceSystemUserId) {
		this.sourceSystemUserId = sourceSystemUserId;
	}
	public String getSourceSystemCode() {
		return sourceSystemCode;
	}
	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}
	public long getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}
	public void setSourceSystemRequestNo(long sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	
}
