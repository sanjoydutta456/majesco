package com.coverall.mic.rest.policy.api.service.model;

import java.util.Date;

public class ScaledownBean {
	
	private String message;
	private String triggeredByUser;
	private String triggeredBy;
	private String triggerTime;
	private String timeout;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getTriggeredByUser() {
		return triggeredByUser;
	}
	public void setTriggeredByUser(String triggeredByUser) {
		this.triggeredByUser = triggeredByUser;
	}
	public String getTriggeredBy() {
		return triggeredBy;
	}
	public void setTriggeredBy(String triggeredBy) {
		this.triggeredBy = triggeredBy;
	}
	public String getTriggerTime() {
		return triggerTime;
	}
	public void setTriggerTime(String triggerTime) {
		this.triggerTime = triggerTime;
	}
	public String getTimeout() {
		return timeout;
	}
	public void setTimeout(String timeout) {
		this.timeout = timeout;
	}
	@Override
	public String toString() {
		return "ScaledownBean [message=" + message + ", triggeredByUser=" + triggeredByUser + ", triggeredBy="
				+ triggeredBy + ", triggerTime=" + triggerTime + ", timeout=" + timeout + "]";
	}
	
}
