package com.coverall.mic.rest.policy.api.service.model;

import java.util.Map;

public class Transaction {
	String transactionName;
	Map<String,String> transactionProperty;

	public String getTransactionName() {
		return transactionName;
	}

	public void setTransactionName(String transactionName) {
		this.transactionName = transactionName;
	}

	public Map<String, String> getTransactionProperty() {
		return transactionProperty;
	}

	public void setTransactionProperty(Map<String, String> transactionProperty) {
		this.transactionProperty = transactionProperty;
	}

	@Override
	public String toString() {
		return "TransactionBean [transactionName=" + transactionName
				+ ", transactionProperty=" + transactionProperty + "]";
	}
	
}
