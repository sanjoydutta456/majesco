package com.coverall.mic.rest.policy.api.service.model.common;

public class Items {
	protected String systemerrcode;
	protected String developer;
	protected String user;
	
	
	public String getSystemerrcode() {
		return systemerrcode;
	}
	public void setSystemerrcode(String systemerrcode) {
		this.systemerrcode = systemerrcode;
	}
	public String getDeveloper() {
		return developer;
	}
	public void setDeveloper(String developer) {
		this.developer = developer;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	
	
 
}
