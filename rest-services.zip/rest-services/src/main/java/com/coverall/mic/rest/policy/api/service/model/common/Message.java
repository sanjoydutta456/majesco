package com.coverall.mic.rest.policy.api.service.model.common;

import java.util.Map;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@JsonIgnoreProperties({ "additionalInformation" })
public class Message {
	
protected Items item;
protected String moreinfo;

protected String systemerrcode;
protected String developer;
protected String user;
protected Map<String,String> additionalInformation;

public String getMoreinfo() {
	return moreinfo;
}

public void setMoreinfo(String moreinfo) { 
	this.moreinfo = moreinfo;
}

public Items getItem() {
	return item;
}

public void setItem(Items item) {
	this.item = item;
	
}

public String getSystemerrcode() {
	return systemerrcode;
}

public void setSystemerrcode(String systemerrcode) {
	this.systemerrcode = systemerrcode;
}

public String getDeveloper() {
	return developer;
}

public void setDeveloper(String developer) {
	this.developer = developer;
}

public String getUser() {
	return user;
}

public void setUser(String user) {
	this.user = user;
}

public Map<String, String> getAdditionalInformation() {
	return additionalInformation;
}

public void setAdditionalInformation(Map<String, String> additionalInformation) {
	this.additionalInformation = additionalInformation;
}

}
