package com.coverall.mic.rest.policy.api.service.model.common;

public class MessageItems extends Message{
	protected String systemerrcode;
	protected String user;
	
	
	public String getSystemerrcode() {
		return systemerrcode;
	}
	public void setSystemerrcode(String systemerrcode) {
		this.systemerrcode = systemerrcode;
	}
	
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	
	
 
}
