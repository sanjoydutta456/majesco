package com.coverall.mic.rest.policy.api.service.oose;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.UnifiedSearchRequest;


@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON , MediaType.MULTIPART_FORM_DATA })
@Produces({ MediaType.APPLICATION_JSON , MediaType.MULTIPART_FORM_DATA})
public interface OOSEService {

	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@GET
	@Path("oose-status")
	public Object getOOSEStatus();
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@POST
	@Path("book-all-revisions")
	public Object bookAllRevisions();
	
	@GET
	@Path("ping")
	public String ping();

	
}
