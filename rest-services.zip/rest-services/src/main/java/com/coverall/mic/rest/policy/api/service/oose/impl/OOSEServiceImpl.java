package com.coverall.mic.rest.policy.api.service.oose.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import com.coverall.exceptions.ExceptionImpl;
import com.coverall.exceptions.JDBCException;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.oose.OOSEService;
import com.coverall.mic.rest.policy.api.service.oose.model.OOSEBookingServiceResponse;
import com.coverall.mic.rest.policy.api.service.oose.model.OOSEServiceErrors;
import com.coverall.mic.rest.policy.api.service.oose.model.OOSEStatusServiceResponse;
import com.coverall.mt.http.User;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.pctv2.client.common.PCTConstants;
import com.coverall.pctv2.client.exceptions.PCTException;
import com.coverall.pctv2.client.util.PCTUtil;
import com.coverall.pctv2.server.cache.ProductCache;
import com.coverall.pctv2.server.model.vo.WflWorkloadJobs;
import com.coverall.pctv2.server.model.vo.WflWorkloads;
import com.coverall.pctv2.server.rh.RHWorkLoadStatus;
import com.coverall.pctv2.server.service.IPCTRequestContext;
import com.coverall.pctv2.server.service.PCTRequestContext;
import com.coverall.util.DBUtil;

public class OOSEServiceImpl implements OOSEService{
	
	private HttpServletRequest request;
	private String entityType;
	private String entityReference;
	private User user;
	private static final String TRANS_EFFECTIVE_DATE = "TRANS_EFFECTIVE_DATE";
	private static final String TRANSACTION = "TRANSACTION";
	private static final String STATUS = "STATUS";
	private static final String DESCRIPTION = "DESCRIPTION";
	private static final String REVISION = "REVISION";	
	private static final String STATUS_FAILED = "FAILED";	
	private static final String STATUS_SUCCESS = "SUCCESSFUL";	
	 
	public OOSEServiceImpl(HttpServletRequest request, String entityType, String policyId) {
		super();
		this.entityReference = policyId;
		this.entityType = entityType;
		this.request=request;
		this.user=User.getUser(request);
	}

	@Override
	public OOSEStatusServiceResponse getOOSEStatus() {
		OOSEStatusServiceResponse response = new OOSEStatusServiceResponse();
		String httpStatusCode = null;
		List<Message> errMsg = null;
		try {
			validateInput(entityReference);
			initContext(request, entityReference, "POLICY");
			getOOSEActualStatus(response);
			
		} catch (APIException e) {
			throw e;
		} catch(Exception e) {
			httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			errMsg = getErrorMessageList(Collections.singletonList(OOSEServiceErrors.errors.INTERNAL_SERVER.getErrorMessage()));
			WebServiceLoggerUtil.logError("OOSEServiceResponse", "getOOSEStatus", e.getLocalizedMessage(), new Object[] { entityReference }, e);
			throw new APIException(httpStatusCode, APIConstant.FAILED, errMsg, e);
		} finally {
			try {
				PCTRequestContext.getContext().release();
			} catch (PCTException e) {
				httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
				errMsg = getErrorMessageList(
						Collections.singletonList(OOSEServiceErrors.errors.INTERNAL_SERVER.getErrorMessage()));
				WebServiceLoggerUtil.logError("OOSEServiceResponse", "getOOSEStatus", e.getLocalizedMessage(),
						new Object[] { entityReference }, e);
				throw new APIException(httpStatusCode, APIConstant.FAILED, errMsg, e);
			}
		}
		return response;
	}
	
	public void getOOSEActualStatus(OOSEStatusServiceResponse response)  throws Exception {		
		RHWorkLoadStatus rhWorkLoadStatus = new RHWorkLoadStatus();
		List<WflWorkloads> workLoads = new ArrayList<WflWorkloads>();
		List<WflWorkloadJobs> workLoadJobs = new ArrayList<WflWorkloadJobs>();
		List<Map<String, String>> ooseStatus = new ArrayList<Map<String, String>>();
		IPCTRequestContext context = PCTRequestContext.getContext();
	    String isOOSEAcrossPolicyTerm = "N";	
	    String isSingleReverseEndorse = "N";	
		ResultSet rs = null;
		try {
			
			rhWorkLoadStatus.getWorkloadData(workLoads, workLoadJobs);
			
			if (workLoads.size() == 1 && workLoadJobs.size() == 1) {
				WflWorkloadJobs workLoadJob = workLoadJobs.get(0);
				rs = rhWorkLoadStatus.populateWorkLoadItemsDataResultSet(workLoadJob);

		        int lastRevisionNumber = 0;
		        int lastCustomRevisionNumber = 0;
		        
		        ProductCache productCache = (ProductCache)ProductCache.getProductCache();
				isOOSEAcrossPolicyTerm = getProductOptionValue(PCTRequestContext.getContext().getEntityReference(), "OOSE_ACROSS_POLICY"); 
	        	isSingleReverseEndorse = getProductOptionValue(PCTRequestContext.getContext().getEntityReference(), "REV_END_SNGL_ROLBCK");

	            DecimalFormat df = new DecimalFormat("000");
	            
	            String revisionLabel;
                if(productCache.getCounterConfig().hideInternalRevisionsForOOSE()){
                    revisionLabel = "newRevision";
                }else{
                	revisionLabel = "revision";    
                }
	            
				while (rs.next()) {
					LinkedHashMap<String, String> ooseRevisionStatus = new LinkedHashMap<String, String>();

	                int revisionNumber = rs.getInt(REVISION);
	                if (revisionNumber == -1) {
	                    revisionNumber = lastRevisionNumber + 1;
	                }
	                
	                int customRevisionNumber = rs.getInt("CUSTOM_REVISION");
	                if(customRevisionNumber == -1){
	                    customRevisionNumber = lastCustomRevisionNumber + 1;
	                }
					
	                
					if (productCache.getCounterConfig().hideInternalRevisionsForOOSE()) {
		                 String customRevisionStr = df.format(customRevisionNumber);
		                   ooseRevisionStatus.put(revisionLabel, customRevisionStr);
		             } else {
		                 // Changes made for PSR#58682.
		                 if("Y".equalsIgnoreCase(isOOSEAcrossPolicyTerm) && 
		                     "Y".equalsIgnoreCase(isSingleReverseEndorse)) {
		                   String customRevisionStr = df.format(customRevisionNumber);
		                   ooseRevisionStatus.put(revisionLabel, customRevisionStr);
		                 } else {	// End of changes made for PSR#58682.
		                 String revisionStr = df.format(revisionNumber);
		                 ooseRevisionStatus.put(revisionLabel, revisionStr);
		                 } // Changes made for PSR#58682. Closing else block.
		             }
	                lastRevisionNumber = revisionNumber;
	                lastCustomRevisionNumber = customRevisionNumber;
	                
	                String transEffectiveDate = rs.getString(TRANS_EFFECTIVE_DATE);
	                ooseRevisionStatus.put("transactionEffectiveDate", transEffectiveDate);
	                

	                String transDisplayName = rs.getString(TRANSACTION);
	                ooseRevisionStatus.put("transaction", transDisplayName);
	                

	                String description = rs.getString(DESCRIPTION);
	                ooseRevisionStatus.put("description", description);
	                

	                String status = rs.getString(STATUS);
	                String statusDetail = rs.getString("STATUS_DETAIL");
	                
	                String statusDetailLabel = statusDetail;
                    if (null == statusDetailLabel) {
                        statusDetailLabel = PCTUtil.sentenceCase(status, " ");
                    }

	                ooseRevisionStatus.put("status", statusDetailLabel);
	                
	                if ("READY FOR BOOKING".equals(status) || "CANCELLED".equals(status)) {
	                	response.setBookingEnabled("Y");
	                }
	                
					ooseStatus.add(ooseRevisionStatus);
				}
			} else {
				String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
				List<Message> errMsg = getErrorMessageList(Collections.singletonList(OOSEServiceErrors.errors.INTERNAL_SERVER.getErrorMessage()));
				WebServiceLoggerUtil.logError("OOSEServiceResponse", "getOOSEActualStatus", "Wrong number of workLoad and workLoadJob received: {workLoads: " + workLoads.size()
                + ", workLoadJobs: " + workLoadJobs.size() + "}", new Object[] { context.getEntityReference() }, null);
				throw new APIException(httpStatusCode, APIConstant.FAILED, errMsg, null);
			}
				
		} catch (Exception ex) {
				throw ex;
			} finally {
				try {
					DBUtil.close(rs, null);
				} catch (SQLException ex) {
			
			}
			
		}
		if(response.getBookingEnabled() == null) {
			response.setBookingEnabled("N");
		}
		response.setOoseStatus(ooseStatus);
	}
	
	private static String getProductOptionValue(String entityReference, 
    		String featureCode) throws Exception {
			Connection conn = null;
			PreparedStatement st = null;
			ResultSet result = null;
			String ipiFeatureSelected = "N";
			
			String productOptionQuery = "SELECT DECODE(ipi_feature_selected, 'Y', 'Y', 'N') IPI_FEATURE_SELECTED "
										+ "FROM mis_product_options_assn "  
										+ "WHERE ipi_feature_code = ? "
										+ "AND ipi_product_code = " 
										+ "(SELECT product_code FROM ev_mis_quote_policies WHERE entity_reference = ? )";
			
			try {
				conn = PCTRequestContext.getContext().getConnection();
				st =
				conn.prepareStatement(productOptionQuery);
				st.setString(1, featureCode);
				st.setString(2, entityReference);
				
				result = st.executeQuery();
				
				if (result != null) {
					while(result.next()) {
						ipiFeatureSelected = result.getString("IPI_FEATURE_SELECTED");
					}
				} else {
					ipiFeatureSelected = "N";
				}
				
			} catch(Exception e) {
				ipiFeatureSelected = "N";
			} finally {
			try {
				DBUtil.close(result, st); 
				} catch (Throwable error) {
				if (error instanceof JDBCException) {
					throw (JDBCException)error;
				} else {
					throw new JDBCException(ExceptionImpl.FATAL,
				            "Error closing connection when getting the product option for OOSE Across Policy Terms " +
				            entityReference + ".", error);
					}
				}
			}
			return ipiFeatureSelected;	
    }


	
	public void initContext(HttpServletRequest request, String entityReference, String entityType) throws Exception {
		IPCTRequestContext context = PCTRequestContext.getContext(user);
		context.setEntityReference(entityReference);
		context.setEntityType(entityType);
		String productCode = entityReference.substring(3, 5);
		String httpStatusCode = null;
		List<Message> errMsg = null;
		
		if(productCode == null) {
			httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			errMsg = getErrorMessageList(Collections.singletonList(OOSEServiceErrors.errors.ENTITY_REFERENCE_ERROR.getErrorMessage()));
			throw new APIException(httpStatusCode, APIConstant.FAILED,errMsg, null);
		} else {
			context.setParameterValue("PRODUCT_CODE", productCode);
		}
	}
	
	public static List<Message> getErrorMessageList(List<String> strMessages)	{
		if(strMessages == null)	{
			return null;
		}
		List<Message> errorMessageList = new ArrayList<Message>(strMessages.size());
		for(String aMsg : strMessages)	{
			Message message = new Message();
			message.setMoreinfo(aMsg);
			errorMessageList.add(message);
		}
		return errorMessageList;
	}
	
	@Override
	public String ping() {
		return null;
	}

	@Override
	public OOSEBookingServiceResponse bookAllRevisions(){
		OOSEBookingServiceResponse response = new OOSEBookingServiceResponse();
		String httpStatusCode = null;
		List<Message> errMsg = null;
        RHWorkLoadStatus rhWorkLoadStatus = new RHWorkLoadStatus();
		HashMap<String, String> params = new HashMap<String, String>();
	    params.put(PCTConstants.ENTITY_TYPE, entityType);
	    params.put(PCTConstants.ENTITY_REFERENCE, entityReference);
	    String buttonAction = RHWorkLoadStatus.BUTTON_BOOK;
		List<WflWorkloads> workLoads = new ArrayList<WflWorkloads>();
		List<WflWorkloadJobs> workLoadJobs = new ArrayList<WflWorkloadJobs>();
		boolean isBookingEnabled = false;
		try {
			validateInput(entityReference);
			initContext(request, entityReference, "POLICY");

			rhWorkLoadStatus.getWorkloadData(workLoads, workLoadJobs);

			if (workLoads.size() == 1 && workLoadJobs.size() == 1) {
				WflWorkloadJobs workLoadJob = workLoadJobs.get(0);
				WflWorkloads workload = workLoads.get(0);
				if(!"Y".equals(String.valueOf(workload.getFwoSequential()))) {
					response.setBookingStatus(STATUS_FAILED);
					response.setBookingMessage("Book all revision not applicable.");
					return response;
				} else {

					ResultSet rs = null;
					try {
						rs = rhWorkLoadStatus.populateWorkLoadItemsDataResultSet(workLoadJob);
						while (rs.next()) {
							String status = rs.getString(STATUS);
							String statusDetail = rs.getString("STATUS_DETAIL");

							String statusDetailLabel = statusDetail;
							if (null == statusDetailLabel) {
								statusDetailLabel = PCTUtil.sentenceCase(status, " ");
							}

							if ("READY FOR BOOKING".equals(status) || "CANCELLED".equals(status)) {
								isBookingEnabled = true;
							}
						}
					} finally {
						try {
							DBUtil.close(rs, null);
						} catch (SQLException ex) {

						}
					}
					
					if (!isBookingEnabled) {
						response.setBookingStatus(STATUS_FAILED);
						response.setBookingMessage("OOSE is not ready for booking.");
						return response;
					}
					
				}
			} else {
				httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
				errMsg = getErrorMessageList(
						Collections.singletonList(OOSEServiceErrors.errors.INTERNAL_SERVER.getErrorMessage()));
				WebServiceLoggerUtil.logError("OOSEServiceResponse", "bookAllRevisions",
						"Wrong number of workLoad and workLoadJob received: {workLoads: " + workLoads.size()
								+ ", workLoadJobs: " + workLoadJobs.size() + "}",
						new Object[] { entityReference }, null);
				throw new APIException(httpStatusCode, APIConstant.FAILED, errMsg, null);

			}
			performBookAllRevisions(params, user, response, buttonAction);
		} catch (APIException e) {
			throw e;
		} catch (Exception e) {
			httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			errMsg = getErrorMessageList(
					Collections.singletonList(OOSEServiceErrors.errors.INTERNAL_SERVER.getErrorMessage()));
			WebServiceLoggerUtil.logError("OOSEServiceResponse", "bookAllRevisions", e.getLocalizedMessage(),
					new Object[] { entityReference }, e);
			throw new APIException(httpStatusCode, APIConstant.FAILED, errMsg, e);
		} finally {
			try {
				PCTRequestContext.getContext().release();
			} catch (PCTException e) {
				httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
				errMsg = getErrorMessageList(
						Collections.singletonList(OOSEServiceErrors.errors.INTERNAL_SERVER.getErrorMessage()));
				WebServiceLoggerUtil.logError("OOSEServiceResponse", "bookAllRevisions", e.getLocalizedMessage(),
						new Object[] { entityReference }, e);
				throw new APIException(httpStatusCode, APIConstant.FAILED, errMsg, e);
			}
		}
		return response;
	}
	
	public OOSEBookingServiceResponse performBookAllRevisions(HashMap<String, String> params, User user, OOSEBookingServiceResponse response, String buttonAction) throws Exception {
        String entityType = params.get(PCTConstants.ENTITY_TYPE);
        String entityReference = params.get(PCTConstants.ENTITY_REFERENCE);
        RHWorkLoadStatus rhWorkLoadStatus = new RHWorkLoadStatus();
		int returnValue;
             
		rhWorkLoadStatus.completeItemForBooking(entityReference);
		
		returnValue = rhWorkLoadStatus.bookAll(entityReference, buttonAction, params);
		if (returnValue != 0) {
			rhWorkLoadStatus.setBookingErrorStatus(entityReference);
			response.setBookingStatus(STATUS_FAILED);
			response.setBookingMessage("Error in booking, please check logs and oose status for further details.");
			return response;
		}
		response.setBookingStatus(STATUS_SUCCESS);
		response.setBookingMessage("Booking Completed.");
		      
		rhWorkLoadStatus.updateStatus(entityReference, entityType);
     
		return response;
 }
	
	private void validateInput(String entityReference) {
		String httpStatusCode = null;
		List<Message> errMsg = null;
		if(entityReference == null) {
			httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			errMsg = getErrorMessageList(Collections.singletonList(OOSEServiceErrors.errors.ENTITY_REFERENCE_ERROR.getErrorMessage()));
			throw new APIException(httpStatusCode, APIConstant.FAILED,errMsg, null);
		}
	}

}
