package com.coverall.mic.rest.policy.api.service.oose.model;

public class OOSEBookingServiceResponse {
	private String bookingStatus;
	private String bookingMessage;

	public String getBookingStatus() {
		return bookingStatus;
	}

	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	public String getBookingMessage() {
		return bookingMessage;
	}

	public void setBookingMessage(String bookingMessage) {
		this.bookingMessage = bookingMessage;
	}
}
