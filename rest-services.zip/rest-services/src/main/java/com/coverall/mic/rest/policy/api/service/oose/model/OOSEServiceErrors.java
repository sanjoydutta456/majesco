package com.coverall.mic.rest.policy.api.service.oose.model;

public interface OOSEServiceErrors {

	String ERROR_START_MSG = "ERROR";
	String ERROR_START_DELIM = " : ";
	String ERROR_DELIM = "-";
	public enum errors {
		INTERNAL_SERVER("Internal Server Error please check logs for more details","ERR-COM-0001"),
		ENTITY_REFERENCE_ERROR("Invalid entity Reference", "ERR-COM-0002");
		
		private final String errorMessage;
		public String getErrorMessage() {
			return errorMessage;
		}
		public String getErrorCode() {
			return errorCode;
		}
		private final String errorCode;
		
		private errors(final String errorMessage, final String errorCode) {
			this.errorMessage = errorMessage;
			this.errorCode = errorCode;
		}
		@Override
		public String toString() {
			return ERROR_START_MSG +ERROR_START_DELIM + errorCode+ERROR_DELIM+errorMessage;
		}
		public boolean equals(String errorCode) {
			return this.errorCode.equalsIgnoreCase(errorCode);
		}
		
	}
	
}
