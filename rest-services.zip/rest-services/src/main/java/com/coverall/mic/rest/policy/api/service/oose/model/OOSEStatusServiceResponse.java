package com.coverall.mic.rest.policy.api.service.oose.model;

import java.util.List;
import java.util.Map;

public class OOSEStatusServiceResponse {
	private List<Map<String,String>> ooseStatus;
	private String bookingEnabled;

	public List<Map<String, String>> getOoseStatus() {
		return ooseStatus;
	}
	public void setOoseStatus(List<Map<String, String>> ooseStatus) {
		this.ooseStatus = ooseStatus;
	}
	public String getBookingEnabled() {
		return bookingEnabled;
	}
	public void setBookingEnabled(String bookingEnabled) {
		this.bookingEnabled = bookingEnabled;
	}
}
