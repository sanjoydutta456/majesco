package com.coverall.mic.rest.policy.api.service.processors;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface IAPIProcessor {
	 public static enum PROCESSOR_TRIGGER_POINT {
	        PRE ,POST
	 }
	 
	 public Object process(HttpServletRequest request,Object response,Map<Object,Object> params) throws Exception;
	 
	 public boolean shouldProcess(HttpServletRequest request,Object responses,Map<Object,Object> params) throws Exception;

}
