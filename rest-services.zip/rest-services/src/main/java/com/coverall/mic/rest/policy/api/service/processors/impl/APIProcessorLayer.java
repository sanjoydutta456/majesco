package com.coverall.mic.rest.policy.api.service.processors.impl;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.httpclient.HttpStatus;

import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.processors.IAPIProcessor;
import com.coverall.mic.rest.policy.api.service.processors.model.APIProcessor;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mt.webservices.WebServiceLoggerUtil;

public class APIProcessorLayer {
	
	public Object preProcessAPIRequest(HttpServletRequest request,Map<Object,Object> processorParams) throws Exception{
		Object returnObj=request;
		String methodName="preProcessAPIRequest";
		String className="APIProcessorLayer";
		String requestType=request.getMethod();
		try {
            List<APIProcessor> processorsToBeExecuted = APIOperationUtil.getAPIProcessorList(requestType, APIConstant.API_OPERATION_SERVICE_CATEGORY, IAPIProcessor.PROCESSOR_TRIGGER_POINT.PRE);
            if(processorsToBeExecuted != null && processorsToBeExecuted.size()>0) {
            	returnObj = executeProcessors(request,null,processorsToBeExecuted,IAPIProcessor.PROCESSOR_TRIGGER_POINT.PRE,processorParams);
            }
        }catch(APIException exp) {
        	WebServiceLoggerUtil.logError(className, methodName, "Failed for :"+request.getRequestURI(), new Object[] {exp.getLocalizedMessage()},exp);
        	throw exp;
        }catch(Throwable e) {
        	APIException exp=new APIException();
            exp.setErrorCode(HttpStatus.SC_INTERNAL_SERVER_ERROR+"");
            exp.setErrorMessage("Failed");
            Message msg=new Message();
            msg.setDeveloper(e.getStackTrace().toString());
            msg.setSystemerrcode(APIConstant.SYSTEM_RESPONSE_CODE.STOP.toString());
            msg.setUser(e.getLocalizedMessage());
            exp.setErrorMessageList(new ArrayList<Message>(Arrays.asList(msg)));
            exp.setMoreInfo(request.getRequestURI());
            WebServiceLoggerUtil.logError(className, methodName, "Failed for :"+request.getRequestURI(), new Object[] {e.getLocalizedMessage()},e);
            throw exp;
        }
        
        return returnObj;
	}
	
	public Object postProcessAPIRequest(HttpServletRequest request,Object response,Map<Object,Object> processorParams) {
		Object returnObj=response;
		String methodName="postProcessAPIRequest";
		String className="APIProcessorLayer";
		String requestType=request.getMethod();
		try {
            List<APIProcessor> processorsToBeExecuted = APIOperationUtil.getAPIProcessorList(requestType, APIConstant.API_OPERATION_SERVICE_CATEGORY, IAPIProcessor.PROCESSOR_TRIGGER_POINT.POST);
            if(processorsToBeExecuted != null && processorsToBeExecuted.size()>0) {
            	returnObj = executeProcessors(request,response,processorsToBeExecuted,IAPIProcessor.PROCESSOR_TRIGGER_POINT.POST,processorParams);
            }
        }catch(APIException exp) {
        	WebServiceLoggerUtil.logError(className, methodName, "Failed for :"+request.getRequestURI(), new Object[] {exp.getLocalizedMessage()},exp);
        	throw exp;
        }catch(Throwable e) {
        	APIException exp=new APIException();
            exp.setErrorCode(HttpStatus.SC_INTERNAL_SERVER_ERROR+"");
            exp.setErrorMessage("Failed");
            Message msg=new Message();
            msg.setDeveloper(e.getStackTrace().toString());
            msg.setSystemerrcode(APIConstant.SYSTEM_RESPONSE_CODE.STOP.toString());
            msg.setUser(e.getLocalizedMessage());
            exp.setErrorMessageList(new ArrayList<Message>(Arrays.asList(msg)));
            exp.setMoreInfo(request.getRequestURI());
            WebServiceLoggerUtil.logError(className, methodName, "Failed for :"+request.getRequestURI(), new Object[] {e.getLocalizedMessage()},e);
            throw exp;
        }
        
        return returnObj;
	}
	
    private Object executeProcessors(HttpServletRequest request,Object response,List<APIProcessor> processorsToBeExecuted,IAPIProcessor.PROCESSOR_TRIGGER_POINT prePost,Map<Object,Object> processorParams) throws Throwable {
    	Object returnObj=null;
        String mName = "executeProcessors";
        String classNameLog="APIProcessorLayer";
        
        for (Iterator<APIProcessor> iterator = processorsToBeExecuted.iterator(); iterator.hasNext();) {
        	long tStart=System.currentTimeMillis();
        	APIProcessor apiProcessor = iterator.next();
            
            String className = apiProcessor.getClassName();
            Class myClass = Class.forName(className);
            Object obj = myClass.newInstance();
            if(! (obj instanceof IAPIProcessor) ) {
            	WebServiceLoggerUtil.logError(classNameLog, mName, "Processor "+prePost.toString()+":"+apiProcessor.getClassName()+" is not insance of IAPIProcessor", new Object[] {"Can execute only the processors of type IAPIProcessor"},null);
                throw new Exception("Can execute only the processors of type IAPIProcessor");
            } else {
                Class[] methodParams = new Class[]{HttpServletRequest.class,Object.class,Map.class};
                Method method = myClass.getMethod("process", methodParams);
                try {
                	returnObj =  method.invoke(obj, new Object[] { request,response,processorParams });
                }catch(APIException exp) {
                	throw exp;
                }catch (InvocationTargetException e) {
                	WebServiceLoggerUtil.logError(classNameLog, mName, "Exception while executing: "+prePost.toString()+":"+apiProcessor.getClassName(), new Object[] {e.getLocalizedMessage()},e);
                    throw e.getTargetException();
                }
                iterator.remove();
            }
            long tEnd=System.currentTimeMillis();
            WebServiceLoggerUtil.logInfo(classNameLog, mName, "Time taken by "+prePost.toString()+":"+apiProcessor.getClassName()+" is "+(tEnd-tStart)+" ms", new Object[] {prePost.toString(),tEnd-tStart});
        }
        return returnObj;
    }

}
