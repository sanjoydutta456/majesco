package com.coverall.mic.rest.policy.api.service.processors.validations.post;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.processors.IAPIProcessor;
import com.coverall.mic.rest.workflow.service.ErrorMessage;

public class ExceptionHandlerForQuotePolicyServices implements IAPIProcessor{

	@Override
	public Object process(HttpServletRequest request, Object response, Map<Object, Object> params) throws Exception {
		if(shouldProcess(request, response, params)) {
			if(response instanceof APIException) {
				APIException exp=(APIException)response;
				for(Message message:exp.getErrorMessageList()) {
					updateMessageObject(message);
				}
				exp.setMoreInfo(request.getRequestURL().toString());
				throw exp;
			}
		}
		return response;
	}

	@Override
	public boolean shouldProcess(HttpServletRequest request, Object responses, Map<Object, Object> params)
			throws Exception {
		if(params!=null && "Y".equalsIgnoreCase(params.get(APIConstant.QUOTE_POLICY_SERVICE_IDENTIFIER).toString()) && !"Y".equalsIgnoreCase(params.get("PROCESSED_SUCCESSFULLY").toString())) {
			String quotePolicyServiceIdentifier=params.get(APIConstant.QUOTE_POLICY_SERVICE_IDENTIFIER)!=null?params.get(APIConstant.QUOTE_POLICY_SERVICE_IDENTIFIER).toString():null;
			String processedSuccessfully=params.get("PROCESSED_SUCCESSFULLY")!=null?params.get("PROCESSED_SUCCESSFULLY").toString():"N";
			if("Y".equalsIgnoreCase(quotePolicyServiceIdentifier) && !"Y".equalsIgnoreCase(processedSuccessfully)) {
			 return true;
			}
		}
		return false;
	}
	
	public void updateMessageObject(Message message) {
		String jsonPath="";
		String messageText="";
		if(message.getAdditionalInformation()!=null) {
			String expressionType=message.getAdditionalInformation().get("EXPRESSION_TYPE");
			String errorType=message.getAdditionalInformation().get("ERROR_TYPE");
			String isBlocker=message.getAdditionalInformation().get("IS_BLOCKER");
			messageText=message.getAdditionalInformation().get(APIConstant.MESSAGE);
			jsonPath=message.getAdditionalInformation().get(APIConstant.JSON_PATH);
			
			if("Y".equalsIgnoreCase(isBlocker)) {
				message.setSystemerrcode(APIConstant.SYSTEM_RESPONSE_CODE.BLOCKER.toString());
			}else if("N".equalsIgnoreCase(isBlocker)) {
				if("WARN".equalsIgnoreCase(errorType)) {
				  message.setSystemerrcode(APIConstant.SYSTEM_RESPONSE_CODE.ALERT.toString());
				}else {
					message.setSystemerrcode(APIConstant.SYSTEM_RESPONSE_CODE.ERROR.toString());
				}
			}else {
				message.setSystemerrcode(APIConstant.SYSTEM_RESPONSE_CODE.STOP.toString());
			}
			if(messageText!=null && messageText.contains("-DNQ:")) {
				int msgStartIndex=messageText.indexOf("-DNQ:");
				String questionName=messageText.substring(0,messageText.indexOf("-DNQ:"));
				String modifiedMessage=messageText.substring(messageText.indexOf("-DNQ:")+1);
				messageText=modifiedMessage;
				jsonPath+="["+questionName+"]";
				message.setSystemerrcode(APIConstant.SYSTEM_RESPONSE_CODE.UNDERWRITING.toString());
				message.setMoreinfo(jsonPath+":, "+messageText);
			}
		}else {
			message.setSystemerrcode(APIConstant.SYSTEM_RESPONSE_CODE.STOP.toString());
			try {
				String msgArr[]=message.getMoreinfo().split(":");
				jsonPath=msgArr[0];
				messageText=msgArr[1];
			}catch(Exception exp) {
				jsonPath=message.getMoreinfo();
				messageText=message.getMoreinfo();
			}
		}
		message.setDeveloper(jsonPath);
		message.setUser(messageText);
		message.setItem(null);
	}
}
