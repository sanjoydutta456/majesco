package com.coverall.mic.rest.policy.api.service.processors.validations.pre;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.httpclient.HttpStatus;
import org.codehaus.jackson.map.deser.std.ThrowableDeserializer;
import org.mockito.internal.stubbing.answers.ThrowsException;

import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.processors.IAPIProcessor;
import com.coverall.mic.rest.policy.api.service.util.WorkflowUtil;

public class EntityReferenceValidator implements IAPIProcessor {

	@Override
	public Object process(HttpServletRequest request, Object response,Map<Object,Object> params)
			throws Exception{
		if(shouldProcess(request, response, params)) {
		String entityType=params.get("ENTITY_TYPE").toString();
		String entityReference=params.get("ENTITY_REFERENCE").toString();
		try {
			if(!WorkflowUtil.checkIfPolicyExists(APIRequestContext.getApiRequestContext().getConnection(), entityReference, entityType)) {
				APIException exp=new APIException();
				exp.setErrorCode(HttpStatus.SC_BAD_REQUEST+"");
				exp.setErrorMessage("Invalid Entity Reference");
				Message msg=new Message();
				msg.setDeveloper("Verfiy existence of provided entityReference");
				msg.setSystemerrcode(APIConstant.SYSTEM_RESPONSE_CODE.ERROR.toString());
				msg.setUser(entityReference+" doesn't exist");
				exp.setErrorMessageList(new ArrayList<Message>(Arrays.asList(msg)));
				exp.setMoreInfo(request.getRequestURI());
				throw exp;
			}
		}catch(Throwable e) {
			APIException exp=new APIException();
			exp.setErrorCode(HttpStatus.SC_INTERNAL_SERVER_ERROR+"");
			exp.setErrorMessage("Failed while executing EntityReferenceValidator");
			Message msg=new Message();
			msg.setDeveloper(e.getStackTrace().toString());
			msg.setSystemerrcode(APIConstant.SYSTEM_RESPONSE_CODE.STOP.toString());
			msg.setUser("Failed while validating "+entityReference);
			exp.setErrorMessageList(new ArrayList<Message>(Arrays.asList(msg)));
			exp.setMoreInfo(request.getRequestURI());
			throw exp;
		 }
		}
		return request;
	}

	@Override
	public boolean shouldProcess(HttpServletRequest request, Object responses,Map<Object,Object> params) throws Exception {
		if(params!=null && params.get("ENTITY_TYPE")!=null && params.get("ENTITY_REFERENCE")!=null) {
			return true;
		}else {
			return false;
		}
	}

}
