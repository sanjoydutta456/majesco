package com.coverall.mic.rest.policy.api.service.quotepolicy;

public interface QuotePolicyErrors {
	String ERROR_START_MSG = "ERROR";
	String ERROR_START_DELIM = " : ";
	String ERROR_DELIM = "-";
	public enum errors {
		INTERNAL_SERVER("Internal Server Error please check logs for more details","ERR-COM-0001"),
		VALID_SORT_BY("Error Msg", "ERR-COM-0002"),
		INVALID_ENTITY_ID("Invalid search entity Id", "ERR-COM-0003"),
		VALIDATE_ERROR("Internal Server Error while Rating the policy, please check logs for more details","ERR-COM-0004"),
		ADD_ERROR("Internal Server Error while adding the requested object, please verify the request","ERR-COM-0005"),
		SUSPEND_ERROR("Internal Server Error while suspending the policy","ERR-COM-0006"),
		UPDATE_ERROR("Internal Server Error while updating the requested object, please verify the request","ERR-COM-0008"),
		COMPLETE_ERROR("Internal Server Error while completing the policy","ERR-COM-0007"),
		DELETE_ERROR("Internal Server Error while deleting the requested object, please verify the request","ERR-COM-0009"),
		INVALID_UPDATE_ERROR("Invalid create request, cannot update/delete in create request","ERR-COM-0010"),
		INVALID_REQUEST_ERROR("Invalid create request, requested JSON path is not supported","ERR-COM-0011");
		
		
		
		private final String errorMessage;
		public String getErrorMessage() {
			return errorMessage;
		}
		public String getErrorCode() {
			return errorCode;
		}
		private final String errorCode;
		
		private errors(final String errorMessage, final String errorCode) {
			this.errorMessage = errorMessage;
			this.errorCode = errorCode;
		}
		@Override
		public String toString() {
			return ERROR_START_MSG +ERROR_START_DELIM + errorCode+ERROR_DELIM+errorMessage;
		}
		public boolean equals(String errorCode) {
			return this.errorCode.equalsIgnoreCase(errorCode);
		}
		
	}
}
