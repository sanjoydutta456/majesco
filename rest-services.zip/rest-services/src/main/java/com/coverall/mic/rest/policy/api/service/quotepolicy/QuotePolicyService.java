package com.coverall.mic.rest.policy.api.service.quotepolicy;

import javax.ws.rs.Consumes;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.servlet.http.HttpServletRequest;

@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
@Produces({ MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA, MediaType.APPLICATION_OCTET_STREAM, "application/pdf" })
public interface QuotePolicyService {

	/*
	 * *******************************************************************************
     *  DO NOT CHANGE THE SIGNATURE OF EXISTING METHODS FROM THIS INTERFACE
     *  THE IMPLEMNETATION (QuotePolicyServiceImpl) IS USED BY CUSTOM POLICY CODE   
     *  AS PART OF THE ATEGRITY CUSTOM API
     * *******************************************************************************
     */
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA, MediaType.TEXT_PLAIN, MediaType.TEXT_HTML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.MULTIPART_FORM_DATA })
	@POST
	@Path("/")
	public Object create(@Context HttpServletRequest request, String json) throws Exception;

	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA, MediaType.TEXT_PLAIN, MediaType.TEXT_HTML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.MULTIPART_FORM_DATA })
	@PUT
	@Path("{policyId}")
	public Object update(@Context HttpServletRequest request, @PathParam("policyId") String policyId,  String json) throws Exception;

	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA, MediaType.TEXT_PLAIN, MediaType.TEXT_HTML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.MULTIPART_FORM_DATA })
	@GET
	@Path("{policyId}")
	public Object get(@Context HttpServletRequest request, @PathParam("policyId") String policyId) throws Exception;

	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA, MediaType.TEXT_PLAIN, MediaType.TEXT_HTML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.MULTIPART_FORM_DATA })
	@POST
	@Path("{policyId}/endorse")
	public Object endorse(@Context HttpServletRequest request,@PathParam("policyId") String policyId, String json) throws Exception;

	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA, MediaType.TEXT_PLAIN, MediaType.TEXT_HTML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.MULTIPART_FORM_DATA })
	@POST
	@Path("{quoteId}/revise")
	public Object revise(@Context HttpServletRequest request,@PathParam("quoteId") String policyId, String json) throws Exception;

	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA, MediaType.TEXT_PLAIN, MediaType.TEXT_HTML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.MULTIPART_FORM_DATA })
	@POST
	@Path("{policyId}/interimAudit")
	public Object interimAudit(@Context HttpServletRequest request,@PathParam("policyId") String policyId, String json) throws Exception;

	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA, MediaType.TEXT_PLAIN, MediaType.TEXT_HTML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.MULTIPART_FORM_DATA })
	@POST
	@Path("{policyId}/finalAudit")
	public Object finalAudit(@Context HttpServletRequest request,@PathParam("policyId") String policyId, String json) throws Exception;
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA, MediaType.TEXT_PLAIN, MediaType.TEXT_HTML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.MULTIPART_FORM_DATA })
	@POST
	@Path("{policyId}/quoteForEndorsement")
	public Object quoteForEndorsement(@Context HttpServletRequest request,@PathParam("policyId") String policyId, String json) throws Exception;

	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA, MediaType.TEXT_PLAIN, MediaType.TEXT_HTML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.MULTIPART_FORM_DATA })
	@POST
	@Path("{policyId}/cancel")
	public Object cancel(@Context HttpServletRequest request,@PathParam("policyId") String policyId, String json) throws Exception;


	
	
	@GET
	@Path("ping")
	public String ping();

}
