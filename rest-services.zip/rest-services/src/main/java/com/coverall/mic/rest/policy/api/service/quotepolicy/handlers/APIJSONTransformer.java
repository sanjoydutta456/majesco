package com.coverall.mic.rest.policy.api.service.quotepolicy.handlers;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;





import com.coverall.mic.rest.policy.api.service.quotepolicy.model.APIMicroserviceCallBean;
import com.coverall.pctv2.server.cache.IPCTAPIMappingCache;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public abstract class APIJSONTransformer implements IAPIJsonTransformer {
	public static final String XPATH_DELIMITER = "/";
	public static final String UK_DELIMITER = "$$";
	public static final String SS_ID = "id";
	public static final String SS_SOURCE_SYSTEM_ID = "sourceSystemId";
	public static final String IS_DELETE_PARAM = "isDelete";
	public static final String SS_ID_RESPONSE = "sourceSystemId";
	public static final String TRANS_CONFIG = "transactionConfig";
	public static final String SYS_ATTRIBUTES = "SystemAttributes";
	public static final String PREMIUM_ATTRIBUTES = "PremiumAttributes";
	public static final String ROOT_PCT_CONTEXT_PATH = "QuotePolicy";

	protected Map<String, Integer> objectCountMap = new HashMap<String, Integer>();
	protected Map<String, String> transactionConfig = new HashMap<String, String>();
	IPCTAPIMappingCache apiMappingCache;

	
	protected List<Map<String, Map<String, String>>> parsedJsonObjects = new ArrayList<Map<String, Map<String, String>>>();

	protected List<APIMicroserviceCallBean> parsedMicroServiceBeans = new ArrayList<APIMicroserviceCallBean>();
	protected List<String> multiOccuringXpaths = new ArrayList<String>();
	
	public static Set<String> IGNORE_FIELDS_FOR_REQUEST = new HashSet<String>(
			Arrays.asList(new String[] { "RATINGFORMULA", "FKCOLUMNNAME" , "FKCOLUMNVALUE", "ENTITYREFERENCE",
					"TRANSACTIONACTION", "TRANSACTIONCODE", "TOTALANNUALCOLFEE","TOTALANNUALFEE","TOTALANNUALSURCHARGE","TOTALANNUALTAX","TOTALFTERMCOLFEE",
					"TOTALFTERMFEE","TOTALFTERMSURCHARGE","WAIVEDPREMIUM","WAIVEPREMIUM","ANNUALPREMIUM","COMMISSIONABLEPREMIUM",
					"FULLTERMPREMIUM","TRANSACTIONPREMIUM","TRANSPREMNOTSUBTOAUD","WRITTENPREMIUM","AUDITFLAG"}));

	
	public Map<String, Object> parseJson(String jsonString) throws Exception {
		Gson gson = new Gson();

		try {
			Type type = new TypeToken<Map<String, Object>>() {
			}.getType();
			Map<String, Object> myMap = gson.fromJson(jsonString, type);
			return myMap;

		} catch (Exception w) {
			throw w;
		}

	}

	protected void parseJSONObject(Map<String, Object> jsonMap, Map<String, Map<String, String>> objectLevelMap, String mapKey, String parentKey) {
		if (objectLevelMap == null) {
			return;
		}
		parsedJsonObjects.add(objectLevelMap);
		Map<String, String> objectValueMap = null;
		String jsonXpath = mapKey;
		if (!TRANS_CONFIG.equalsIgnoreCase(mapKey) && parentKey != null && !TRANS_CONFIG.equalsIgnoreCase(parentKey)) {
			jsonXpath = parentKey + XPATH_DELIMITER + mapKey;
		}

		if (objectLevelMap.get(mapKey) != null) {
			objectValueMap = objectLevelMap.get(jsonXpath);
		} else {
			objectValueMap = new LinkedHashMap<String, String>();
			objectLevelMap.put(jsonXpath, objectValueMap);
		}
		for (String key : jsonMap.keySet()) {
			// System.out.println("Key For The Map : " + key);
			Object valueObject = jsonMap.get(key);
			if (valueObject != null && valueObject instanceof Map) {
				Map<String, Object> valueMap = (Map<String, Object>) valueObject;
				Map<String, Map<String, String>> objectLevelChildMap = new HashMap<String, Map<String, String>>();
				parseJSONObject(valueMap, objectLevelChildMap, key, jsonXpath);
			} else if (valueObject != null && valueObject instanceof List) {
				List listObj = (List) valueObject;
				for (Object obj : listObj) {
					if (obj != null && obj instanceof Map) {
						Map<String, Object> valueMap = (Map<String, Object>) obj;
						Map<String, Map<String, String>> objectLevelChildMap = new HashMap<String, Map<String, String>>();
						parseJSONObject(valueMap, objectLevelChildMap, key, jsonXpath);
					} else if (obj != null && obj instanceof String) {
						objectValueMap.put(key, (String) obj);
					}
				}

			} else if (valueObject != null && valueObject instanceof String) {
				objectValueMap.put(key, (String) valueObject);
			}
		}
	}

	protected void parseJSONObject(Map<String, Object> jsonMap, JSONObjectStructureBean parentMSBean, String mapKey, String parentKey) {
		if (parentMSBean == null) {
			return;
		}
		String jsonXpath = mapKey;
		Set<String> mergeAttributes = getMergeAttributes();
		if (!TRANS_CONFIG.equalsIgnoreCase(mapKey) && parentKey != null && !TRANS_CONFIG.equalsIgnoreCase(parentKey)
				&& (mergeAttributes == null || (mapKey != null && !mergeAttributes.contains(mapKey.toUpperCase())))) {
			jsonXpath = parentKey + XPATH_DELIMITER + mapKey;
		}

		if (!TRANS_CONFIG.equalsIgnoreCase(jsonXpath) && (mergeAttributes == null || (mapKey != null && !mergeAttributes.contains(mapKey.toUpperCase())))) {
			parentMSBean.setApiJsonPath(jsonXpath);
			parentMSBean.setJsonXpath(mapKey);
			if(parentMSBean.isMultiOccuringObjectInRequest()){
				multiOccuringXpaths.add(jsonXpath);
			}

		}
		Set<String> iginoreAttributes = getIgnoreAttributes();
		JSONObjectStructureBean childBean = parentMSBean;
		for (String key : jsonMap.keySet()) {
			if (key != null && iginoreAttributes != null && iginoreAttributes.contains(key.toUpperCase())) {
				continue;
			}
			Object valueObject = jsonMap.get(key);
			if (valueObject != null && valueObject instanceof Map) {
				Map<String, Object> valueMap = (Map<String, Object>) valueObject;
				JSONObjectStructureBean currentChild = childBean;
				if (!TRANS_CONFIG.equalsIgnoreCase(jsonXpath) && (mergeAttributes == null || !mergeAttributes.contains(key.toUpperCase()))) {
					currentChild = new JSONObjectStructureBean();
					currentChild.setParentJSONBean(parentMSBean);
					parentMSBean.getChildObjectServiceCalls().add(currentChild);
				}
				parseJSONObject(valueMap, currentChild, key, jsonXpath);
			} else if (valueObject != null && valueObject instanceof List) {
				List listObj = (List) valueObject;
				for (Object obj : listObj) {
					if (obj != null && obj instanceof Map) {
						Map<String, Object> valueMap = (Map<String, Object>) obj;
						JSONObjectStructureBean currentChild = childBean;
						if (!TRANS_CONFIG.equalsIgnoreCase(jsonXpath)) {
							currentChild = new JSONObjectStructureBean();
							currentChild.setParentJSONBean(parentMSBean);
							currentChild.setMultiOccuringObjectInRequest(true);
							parentMSBean.getChildObjectServiceCalls().add(currentChild);
						}
						parseJSONObject(valueMap, currentChild, key, jsonXpath);
					} else if (obj != null && obj instanceof String) {
						childBean.getPostData().put(key, (String) obj);
					}
				}

			} else if (valueObject != null && valueObject instanceof String) {
				if (TRANS_CONFIG.equalsIgnoreCase(jsonXpath)) {
					transactionConfig.put(key, (String) valueObject);
				} else {
					childBean.getPostData().put(key, (String) valueObject);
				}
			}
		}
	}

	protected String getParentXpath(String xpath) {
		if (xpath != null && !xpath.isEmpty()) {
			xpath = formatXpath(xpath);
			if (xpath != null && xpath.contains(XPATH_DELIMITER)) {
				xpath = xpath.substring(0, xpath.lastIndexOf(XPATH_DELIMITER));
				return xpath;
			}
		}
		return null;
	}

	protected String formatXpath(String xpath) {
		if (xpath != null && !xpath.isEmpty()) {
			xpath = xpath.trim();
			if (XPATH_DELIMITER.equalsIgnoreCase(xpath)) {
				return xpath;
			}
			if (xpath.startsWith(XPATH_DELIMITER)) {
				xpath = xpath.substring(1);
			}
			if (xpath.endsWith(XPATH_DELIMITER)) {
				xpath = xpath.substring(0, (xpath.length() - 1));
			}
			if (xpath != null && (xpath.startsWith(XPATH_DELIMITER) || xpath.endsWith(XPATH_DELIMITER))) {
				xpath = formatXpath(xpath);
			}
		}
		return xpath;
	}

	protected String getUniqueKeyForAPIBean(String apiJsonPath) {
		String uniqueKey = apiJsonPath;
		if (objectCountMap.containsKey(apiJsonPath)) {
			int apiCount = objectCountMap.get(apiJsonPath);
			++apiCount;
			uniqueKey += UK_DELIMITER + 1;
			objectCountMap.put(apiJsonPath, apiCount);

		} else {
			uniqueKey += UK_DELIMITER + 1;
			objectCountMap.put(apiJsonPath, 1);
		}
		return uniqueKey;
	}

	protected Set<String> getIgnoreAttributes() {

		return null;
	}

	protected Set<String> getMergeAttributes() {

		return null;
	}
	
	public Map<String, String> getTransactionConfig() {
		return transactionConfig;
	}

	@Override
	public APIMicroserviceCallBean getRootAPIMicroserviceCallBean() {
		return null;
	}
	public List<String> getMultiOccuringXpaths() {
		return multiOccuringXpaths;
	}
	
	public void setMultiOccuringXpaths(List<String> multiOccuringXpaths) {
		this.multiOccuringXpaths = multiOccuringXpaths;
	}


}
