package com.coverall.mic.rest.policy.api.service.quotepolicy.handlers;
import com.coverall.mic.rest.policy.api.service.quotepolicy.model.APIMicroserviceCallBean;
import com.coverall.pctv2.server.cache.IPCTAPIMappingCache;
import com.coverall.pctv2.server.cache.ProductCache;
import com.google.gson.Gson;
import com.google.gson.JsonParser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class APIRequestTransformer extends APIJSONTransformer {

	private Map<String, APIMicroserviceCallBean> microServiceRequests = new LinkedHashMap<String, APIMicroserviceCallBean>();
	private APIMicroserviceCallBean rootAPIMicroserviceCallBean;

	private APIRequestTransformer(IPCTAPIMappingCache apiMappingCache) {
		this.apiMappingCache = apiMappingCache;
	}
	
	public static APIJSONTransformer getRequestTransformer(IPCTAPIMappingCache apiMappingCache){
		APIJSONTransformer reqestTransformer = new APIRequestTransformer(apiMappingCache);
		return reqestTransformer;
	}
	

	public void parseJsonStructure(String requestJson) throws Exception {
		JsonParser parser = new JsonParser();
		Gson gson = new Gson();
		try {
			Map<String, Object> parsedJsonMap = parseJson(requestJson);
			JSONObjectStructureBean rootJsonObject = new JSONObjectStructureBean();
			parseJSONObject(parsedJsonMap, rootJsonObject, TRANS_CONFIG, null);
			prepareMicroserviceRequest(rootJsonObject, null);
			//System.out.println(transactionConfig);
			//System.out.println(rootAPIMicroserviceCallBean);
			
		} catch (Exception w) {
			throw w;
		}

	}
	
	private void prepareMicroserviceRequest(JSONObjectStructureBean jsonObject , APIMicroserviceCallBean parentObjectMS) {
		if (jsonObject != null ) {
			Map<String,String> postData =   jsonObject.getPostData();
			String apiJsonPath = jsonObject.getApiJsonPath();
			APIMicroserviceCallBean currentObjectMSBean = null;
			String pctJsonPathAtObject = apiMappingCache.getXpathMappingForAPI(apiJsonPath);
			currentObjectMSBean = new APIMicroserviceCallBean(apiJsonPath,pctJsonPathAtObject);
			if(parentObjectMS != null){
				parentObjectMS.getChildObjectServiceCalls().add(currentObjectMSBean);
				currentObjectMSBean.setParentMSCallbean(parentObjectMS);
			}
			if(postData != null && !postData.isEmpty()){
				
				for(String attributeName : postData.keySet()){
					String attributeValue = postData.get(attributeName);
					String pctAttributeName = apiMappingCache.getAttributeMappingForAPI(apiJsonPath, attributeName);
					String pctJsonPath = apiMappingCache.getXpathMappingForAPI(apiJsonPath, attributeName);
					String pctxpath = apiMappingCache.getPCTXpath(pctJsonPath);
					if(rootAPIMicroserviceCallBean == null){
						rootAPIMicroserviceCallBean = currentObjectMSBean;
					}
					if(currentObjectMSBean.getApiJsonPath()  == null){
						currentObjectMSBean.setApiJsonPath(apiJsonPath);
					}
					if(currentObjectMSBean.getPctJsonPath()  == null){
						currentObjectMSBean.setPctJsonPath(pctJsonPath);
					}
					if(currentObjectMSBean.getPctXpath()  == null){
						currentObjectMSBean.setPctXpath(pctxpath);
					}
					currentObjectMSBean.setMultiOccuringObjectInRequest(jsonObject.isMultiOccuringObjectInRequest());
					if (SS_ID.equalsIgnoreCase(attributeName)) {
						currentObjectMSBean.setSourceSystemId(attributeValue);
					}else if (SS_SOURCE_SYSTEM_ID.equalsIgnoreCase(attributeName)) {
						currentObjectMSBean.setOverrideSourceSystemId(attributeValue);
					}else if(IS_DELETE_PARAM.equalsIgnoreCase(attributeName)){
						currentObjectMSBean.setIsDelete(attributeValue);
					}else if (IGNORE_FIELDS_FOR_REQUEST.contains(attributeName.toUpperCase())){
						// Ignoring the system fields
						continue;
					}
					else {
						currentObjectMSBean.getPostData().put(pctAttributeName, attributeValue);
					}
				}
			}else{
				String pctJsonPath = apiMappingCache.getXpathMappingForAPI(apiJsonPath, null);
				String pctxpath = apiMappingCache.getPCTXpath(pctJsonPath);
				if(currentObjectMSBean.getPctJsonPath()  == null){
					currentObjectMSBean.setPctJsonPath(pctJsonPath);
				}
				if(currentObjectMSBean.getPctXpath()  == null){
					currentObjectMSBean.setPctXpath(pctxpath);
				}
			}
			List<JSONObjectStructureBean>  childJSONObjects  = jsonObject.getChildObjectServiceCalls();
			if (childJSONObjects != null) {
				for (JSONObjectStructureBean childJsonObject : childJSONObjects) {
					prepareMicroserviceRequest(childJsonObject, currentObjectMSBean);
				}
			}
		}
	}
	
	protected String getParentXpath(String xpath) {
		if (xpath != null && !xpath.isEmpty()) {
			xpath = formatXpath(xpath);
			if (xpath != null && xpath.contains(XPATH_DELIMITER)) {
				xpath = xpath.substring(0, xpath.lastIndexOf(XPATH_DELIMITER));
				return xpath;
			}
		}
		return null;
	}

	public Map<String, APIMicroserviceCallBean> getMicroServiceRequests() {
		return microServiceRequests;
	}

	public void setMicroServiceRequests(Map<String, APIMicroserviceCallBean> microServiceRequests) {
		this.microServiceRequests = microServiceRequests;
	}

	public List<Map<String, Map<String, String>>> getParsedJsonObjects() {
		return parsedJsonObjects;
	}

	public void setParsedJsonObjects(List<Map<String, Map<String, String>>> parsedJsonObjects) {
		this.parsedJsonObjects = parsedJsonObjects;
	}
	
	public APIMicroserviceCallBean getRootAPIMicroserviceCallBean() {
		return rootAPIMicroserviceCallBean;
	}

	public void setRootAPIMicroserviceCallBean(APIMicroserviceCallBean rootAPIMicroserviceCallBean) {
		this.rootAPIMicroserviceCallBean = rootAPIMicroserviceCallBean;
	}
	
	/*
	public static void main(String[] args) throws Exception {
		APIRequestTransformer transformer = new APIRequestTransformer();
		transformer.parseJsonRequest("D:\\Policy_dev\\CreateQuoteAPI\\request1.json");
	} */

}
