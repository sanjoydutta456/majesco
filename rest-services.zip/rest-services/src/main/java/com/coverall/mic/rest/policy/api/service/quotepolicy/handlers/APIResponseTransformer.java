package com.coverall.mic.rest.policy.api.service.quotepolicy.handlers;



import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.pctv2.server.cache.IPCTAPIMappingCache;
import com.google.gson.Gson;
import com.google.gson.JsonParser;

public class APIResponseTransformer extends APIJSONTransformer {

	Map<Object, Object> apiResponse = new HashMap<Object, Object>();
	Map<String, Object> individualObjectResponse = new HashMap<String, Object>();
	private static Set<String> IGNORE_ATTRIBUTES = new HashSet<String>(
			Arrays.asList(new String[] { "SYSTEMATTRIBUTES" }));
	private static Set<String> MERGE_ATTRIBUTES = new HashSet<String>(
			Arrays.asList(new String[] { "PREMIUMATTRIBUTES" }));
	
	private static Set<String> IGNORE_FIELDS_FOR_RESPONSE = new HashSet<String>(
			Arrays.asList(new String[] { "RATINGFORMULA", "FKCOLUMNNAME" , "FKCOLUMNVALUE", "ID"}));

	private APIResponseTransformer(IPCTAPIMappingCache apiMappingCache) {
		this.apiMappingCache = apiMappingCache;
	}
	
	public static APIResponseTransformer getResponseTransformer(IPCTAPIMappingCache apiMappingCache){
		APIResponseTransformer responseTransformer = new APIResponseTransformer(apiMappingCache);
		return responseTransformer;
	}

	public void parseJsonStructure(String jsonPath) throws Exception {
		JsonParser parser = new JsonParser();
		try {
			Map<String, Object> parsedJsonMap = parseJson(jsonPath);
			JSONObjectStructureBean rootJsonObject = new JSONObjectStructureBean();
			Map<String, Map<String, String>> objectLevelMap = new HashMap<String, Map<String, String>>();
			Map<String, Object> apiResponse =  parseJSONANdPrepareRespone(parsedJsonMap,  TRANS_CONFIG, null,null);
		} catch (Exception w) {
			throw w;
		}

	}
	
	public Map<String, Object> parseJsonStructure(Map<String, Object> parsedJsonMap) throws Exception {
		try {
			Map<String, Object> responseMap =  parseJSONANdPrepareRespone(parsedJsonMap,  TRANS_CONFIG, null,null);
			return responseMap;
		} catch (Exception w) {
			throw w;
		}

	}
	
	protected Map<String, Object>  parseJSONANdPrepareRespone(Map<String, Object> jsonMap,  String mapKey, String parentKey, Map<String, Object> parentJsonMap) {
		
		Map<String, Object>  attrValueMap = parentJsonMap;
		String jsonXpath = mapKey;
		Set<String> mergeAttributes = getMergeAttributes();
		if (!TRANS_CONFIG.equalsIgnoreCase(mapKey) && parentKey != null && !TRANS_CONFIG.equalsIgnoreCase(parentKey) 
				&& (mergeAttributes == null || (  mapKey!= null && !mergeAttributes.contains(mapKey.toUpperCase())))) {
			jsonXpath = parentKey + XPATH_DELIMITER + mapKey;
		}
	
		if (!TRANS_CONFIG.equalsIgnoreCase(jsonXpath) && ( mergeAttributes == null || ( mapKey!= null && !mergeAttributes.contains(mapKey.toUpperCase())))) {
			if(parentJsonMap == null){
				parentJsonMap = new LinkedHashMap<String, Object>();
				attrValueMap = new LinkedHashMap<String, Object>();
				String objectLevelAPIJsonPath = apiMappingCache.getAPIMappingForPctXpath(jsonXpath);
				parentJsonMap.put(objectLevelAPIJsonPath, attrValueMap);
			}
		}
		
		
		Set<String> iginoreAttributes = getIgnoreAttributes();
		Map<String, Object>  responseChildMap = parentJsonMap;
		for (String key : jsonMap.keySet()) {
			if(key != null && iginoreAttributes != null && iginoreAttributes.contains(key.toUpperCase())){
				continue;
			}
			Object valueObject = jsonMap.get(key);
			if (valueObject != null && valueObject instanceof Map) {
				Map<String, Object> valueMap = (Map<String, Object>) valueObject;
				if (!TRANS_CONFIG.equalsIgnoreCase(jsonXpath) && ( mergeAttributes == null || !mergeAttributes.contains(key.toUpperCase()))) {
					responseChildMap = new LinkedHashMap<String, Object>();
					String childJsonXpath = parentKey + XPATH_DELIMITER + key;
					String objectLevelAPIJsonPath = apiMappingCache.getAPIMappingForPctXpath(childJsonXpath);
					attrValueMap.put(objectLevelAPIJsonPath, responseChildMap);
					parseJSONANdPrepareRespone(valueMap,  key, jsonXpath, responseChildMap);
				}else{
					if (parentJsonMap == null) {
						parentJsonMap = parseJSONANdPrepareRespone(valueMap,  key, jsonXpath, attrValueMap);
					} else {
						parseJSONANdPrepareRespone(valueMap,  key, jsonXpath, attrValueMap);
					}
				}
			} else if (valueObject != null && valueObject instanceof List) {
				List listObj = (List) valueObject;
				List responseJsonList  = new ArrayList<Map<String, Object>>();
				String childJsonXpath = jsonXpath + XPATH_DELIMITER + key;
				boolean isSinglyOccuringObject = false;
				if(apiMappingCache.getPctSinglyOccuringJSONPaths()!= null ){
					isSinglyOccuringObject = apiMappingCache.getPctSinglyOccuringJSONPaths().contains(childJsonXpath);
				}
				String objectLevelAPIJsonPath = apiMappingCache.getAPIMappingForPctXpath(childJsonXpath);
				if(!isSinglyOccuringObject){
					attrValueMap.put(objectLevelAPIJsonPath, responseJsonList);
				}else if(!listObj.isEmpty() && listObj.size() > 1  ){
					WebServiceLoggerUtil.logError("APIResponseTransformer", "parseJSONANdPrepareRespone"," Error : Found multiple instances for singly occuring object :"+childJsonXpath
							,new Object[] { listObj }, null);
				}
				for (Object obj : listObj) {
					if (obj != null && obj instanceof Map) {
						Map<String, Object> valueMap = (Map<String, Object>) obj;
						if (!TRANS_CONFIG.equalsIgnoreCase(jsonXpath)) {
							responseChildMap = new LinkedHashMap<String, Object>();
							if(isSinglyOccuringObject){
								attrValueMap.put(objectLevelAPIJsonPath, responseChildMap);
							}
							responseJsonList.add(responseChildMap);
							parseJSONANdPrepareRespone(valueMap,  key, jsonXpath, responseChildMap);
						}else{
							parseJSONANdPrepareRespone(valueMap, key, jsonXpath, attrValueMap);
						}
					} else if (obj != null && obj instanceof String) {
						if(key != null && !IGNORE_FIELDS_FOR_RESPONSE.contains(key.toUpperCase()) && !SS_ID_RESPONSE.equalsIgnoreCase(key)){
							String apiAttributeName = apiMappingCache.getAPIAttributeMappingForPctName(jsonXpath, key);
							attrValueMap.put(apiAttributeName, (String) valueObject);
						}else if (key != null && SS_ID_RESPONSE.equalsIgnoreCase(key)){
							attrValueMap.put(SS_ID, (String) valueObject);
						}
					}
				}

			} else if (valueObject != null && valueObject instanceof String) {
				if (TRANS_CONFIG.equalsIgnoreCase(jsonXpath)) {
					transactionConfig.put(key, (String) valueObject);
				} else {
					
					if(key != null && !IGNORE_FIELDS_FOR_RESPONSE.contains(key.toUpperCase()) && !SS_ID_RESPONSE.equalsIgnoreCase(key)){
						String apiAttributeName = apiMappingCache.getAPIAttributeMappingForPctName(jsonXpath, key);
						attrValueMap.put(apiAttributeName, (String) valueObject);
					}else if (key != null && SS_ID_RESPONSE.equalsIgnoreCase(key)){
						attrValueMap.put(SS_ID, (String) valueObject);
					}
				}
			}
		}
		return parentJsonMap;
	}
	
	
	protected Set<String>  getIgnoreAttributes(){
		return IGNORE_ATTRIBUTES;
	}
	
	protected Set<String>  getMergeAttributes(){
		return MERGE_ATTRIBUTES;
	}

	
}
