package com.coverall.mic.rest.policy.api.service.quotepolicy.handlers;

import java.util.List;
import java.util.Map;

import com.coverall.mic.rest.policy.api.service.quotepolicy.model.APIMicroserviceCallBean;


public interface IAPIJsonTransformer {
	
	public Map<String, String> getTransactionConfig();
	
	
	public APIMicroserviceCallBean getRootAPIMicroserviceCallBean();
	
	
	public void parseJsonStructure(String requestJson) throws Exception;
	
	
	public List<String> getMultiOccuringXpaths();
	
	public void setMultiOccuringXpaths(List<String> multiOccuringXpaths);

}
