package com.coverall.mic.rest.policy.api.service.quotepolicy.handlers;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JSONObjectStructureBean {
	String apiJsonPath;
	String jsonXpath;

	boolean isMultiOccuringObjectInRequest;
	Map<String, String> postData = new HashMap<String, String>();
	List<JSONObjectStructureBean> childObjectServiceCalls = new ArrayList<JSONObjectStructureBean>();
	JSONObjectStructureBean parentJSONBean;

	public String getJsonXpath() {
		return jsonXpath;
	}

	public void setJsonXpath(String jsonXpath) {

		this.jsonXpath = jsonXpath;

	}

	public String getApiJsonPath() {
		return apiJsonPath;
	}

	public void setApiJsonPath(String apiJsonPath) {
		this.apiJsonPath = apiJsonPath;
	}

	public boolean isMultiOccuringObjectInRequest() {
		return isMultiOccuringObjectInRequest;
	}

	public void setMultiOccuringObjectInRequest(boolean isMultiOccuringObjectInRequest) {
		this.isMultiOccuringObjectInRequest = isMultiOccuringObjectInRequest;
	}

	public Map<String, String> getPostData() {
		return postData;
	}

	public void setPostData(Map<String, String> postData) {
		this.postData = postData;
	}

	public List<JSONObjectStructureBean> getChildObjectServiceCalls() {
		return childObjectServiceCalls;
	}

	public void setChildObjectServiceCalls(List<JSONObjectStructureBean> childObjectServiceCalls) {
		this.childObjectServiceCalls = childObjectServiceCalls;
	}

	public JSONObjectStructureBean getParentJSONBean() {
		return parentJSONBean;
	}

	public void setParentJSONBean(JSONObjectStructureBean jSONObjectStructureBean) {
		parentJSONBean = jSONObjectStructureBean;
	}

	@Override
	public String toString() {
		return "JSONObjectStructureBean [apiJsonPath=" + apiJsonPath + ", isMultiOccuringObjectInRequest=" + isMultiOccuringObjectInRequest + ", postData="
				+ postData + ", childObjectServiceCalls=" + childObjectServiceCalls + "]";
	}

}
