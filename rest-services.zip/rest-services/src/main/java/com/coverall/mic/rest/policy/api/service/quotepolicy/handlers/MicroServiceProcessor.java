package com.coverall.mic.rest.policy.api.service.quotepolicy.handlers;

import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.Random;
import java.lang.Exception;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.ws.rs.core.Response;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.quotepolicy.QuotePolicyErrors;
import com.coverall.mic.rest.policy.api.service.quotepolicy.model.APIMicroserviceCallBean;
import com.coverall.mic.rest.policy.api.service.quotepolicy.model.MicroserviceProcessorResponse;
import com.coverall.mic.rest.policy.api.service.quotepolicy.mt.QuotePolicyAPIExecutorInput;
import com.coverall.mic.rest.policy.api.service.quotepolicy.mt.QuotePolicyAPIExecutorTask;
import com.coverall.mic.rest.policy.api.service.quotepolicy.mt.QuotePolicyExecutorOutput;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.pct.server.logging.PCTLogUtil;
import com.coverall.pct.server.util.PCTGenUtils;
import com.coverall.pctv2.client.exceptions.ProductServiceException;
import com.coverall.pctv2.client.model.IPCTCFP;
import com.coverall.pctv2.server.cache.ProductCache;
import com.coverall.pctv2.server.mt.PCTApiForkJoinPoolMgr;
import com.coverall.pctv2.server.rh.PCTForkJoinExecutionOutput;
import com.coverall.pctv2.server.rs.service.microservices.ErrorMessage;
import com.coverall.pctv2.server.rs.service.microservices.ExtractTransactionRequest;
import com.coverall.pctv2.server.rs.service.microservices.MicroServiceDBUtil;
import com.coverall.pctv2.server.rs.service.microservices.MicroServiceFormat;
import com.coverall.pctv2.server.rs.service.microservices.MicroServiceServlet;
import com.coverall.pctv2.server.rs.service.microservices.rh.MicroServicesExecutorTask;
import com.coverall.pctv2.server.service.AbstractMicroserviceHandler;
import com.coverall.pctv2.server.service.ExtractTransactionProcessor;
import com.coverall.pctv2.server.service.PCTEntityTransaction;
import com.coverall.pctv2.server.service.PCTMicroservicesTransaction;
import com.coverall.pctv2.server.service.PCTMicroservicesTransaction.RequestMethodType;
import com.coverall.pctv2.server.service.PCTRequestContext;
import com.coverall.pctv2.server.service.PCTRetryRequestException;
import com.coverall.pctv2.server.service.IPCTRequestContext.EntityViewMode;
import com.coverall.pctv2.server.yaml.generation.OpenAPISpecGenerator;
import com.coverall.util.DBUtil;
import com.coverall.mt.http.User;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.google.gson.Gson;


public class MicroServiceProcessor {

	String isOose;
	String productCode;
	String entityType;
	String transactionName;
	boolean rateTransaction;
	String transactionId;
	String clientId;
	boolean completeTransaction;
	boolean completeWithoutRateTrans =  false;
	boolean returnCompleteResponse;
	boolean isUpdateRequest;
	String responseEntityType;
	boolean isQuickQuoteMode;
	boolean isOverrideSourceSystemId;
	boolean multiThreadedExecution;
	String errorMessagePlaceHolderType = "GID";
	boolean validateOnly = false;
	public static final String ENTITY_REFERENCE = "ENTITY_REFERENCE";
	public static final String REST_METHOD = "REST_METHOD";
	public static final String STARTNEW_POST = "STARTNEW_POST";
	public static final String RATE = "RATE";
	public static final String SUSPEND = "SUSPEND";
    public static final String COMPLETE = "COMPLETE";
    public static final String COMPLETE_WITHOUT_RATE = "COMPLETEWITHOUTRATE";
    public static final String ADD = "ADD";
    public static final String UPDATE = "UPDATE";
    public static final String DELETE = "DELETE";
	public static final String SS_ID = "sourceSystemID";
	public static final String SS_ID_PREFIX = "API";
	public static final String SS_ID_DELIM = "_";
	public static final String END_POIMT_DELIM = "/";
	public static final String START_TRANS_END_POINT= "startNewTransaction";
	public static final String VALIDATE_TRANS_END_POINT= "validateTransaction";
	public static final String SUSPEND_TRANS_END_POINT= "suspendTransaction";
	public static final String COMPLETE_TRANS_END_POINT= "completeTransaction";
	public static final String COMPLETE_WITHOUT_RATE_END_POINT= "declineTransaction";
	public static final String NEXT_GEN = "NextGeneration";
	public static final String EXIT_GRACEFULLY = "ExitGracefully";
	public static final String CALL_BEFORE_EXIT = "CallBeforeExit";
	public static final String NO_PROMPT_RATE = "NoPromptRate";
	public static final String RE_EXECUTE_AFTER_ACK =  "RE_EXECUTE_AFTER_ACKNOWLEDGE";
	public static final String VALIDATIONS =  "VALIDATIONS";
	public static final String DATE_FORMAT = "yyyy-MM-dd";
	public static final String sourceSystemID = "sourceSystemID";
	public static final String enableValidationOption ="MICR_ENBL_VALIDATION";
	Map<String,List<String>> ssIdMap = new  HashMap<String,List<String>> ();
	
	Map<String, String> transactionParams = new HashMap<String, String>();
	User user;
	Map<String,List<ErrorMessage>> erroMessagesMap = new HashMap<String,List<ErrorMessage>>() ;
	MicroserviceProcessorResponse msResponse = new MicroserviceProcessorResponse();
	APIResponseTransformer responseTransformer;
	Map<String,ArrayList<String>> byRefPCTJsontoAttributeMap = new HashMap<String,ArrayList<String>>() ;
	Map<String, String> referenceIdtoSSIdMap = new HashMap<String, String>();
	String enableValidations;

	ArrayList<QuotePolicyAPIExecutorTask> submittedTasks = new ArrayList<QuotePolicyAPIExecutorTask>();


	/**
	 * 
	 * @param productCode
	 * @param entityType
	 * @param transactionName
	 * @param rateTransaction
	 * @param completeTransaction
	 */
	public MicroServiceProcessor(String productCode, String entityType, String transactionName, boolean rateTransaction, boolean completeTransaction, boolean returnCompleteResponse, boolean isUpdateRequest) {
		this.productCode = productCode;
		this.entityType = entityType;
		this.transactionName = transactionName;
		this.rateTransaction = rateTransaction;
		this.completeTransaction = completeTransaction;
		this.returnCompleteResponse = returnCompleteResponse;
		this.isUpdateRequest = isUpdateRequest;
		user = APIRequestContext.getApiRequestContext().getMtUser();
	}
	
	/**
	 * 
	 * @param productCode
	 * @param entityType
	 * @param transactionName
	 * @param rateTransaction
	 * @param completeTransaction
	 */
	public MicroServiceProcessor(String productCode, String entityType, String transactionName, String transactionId , boolean completeWithoutRateTrans, boolean returnCompleteResponse, boolean isUpdateRequest) {
		this.productCode = productCode;
		this.entityType = entityType;
		this.transactionName = transactionName;
		this.completeWithoutRateTrans = completeWithoutRateTrans;
		if(completeWithoutRateTrans) {
			this.validateOnly=true;
			this.rateTransaction = true;
		}
		this.returnCompleteResponse = returnCompleteResponse;
		this.isUpdateRequest = isUpdateRequest;
		this.transactionId = transactionId;
		user = APIRequestContext.getApiRequestContext().getMtUser();
	}
	
	
	/**
	 * 
	 * @param productCode
	 * @param entityType
	 * @param transactionName
	 * @param rateTransaction
	 * @param completeTransaction
	 */
	public MicroServiceProcessor(String productCode, String entityType, String transactionName, String transactionId , boolean rateTransaction, boolean completeTransaction, boolean returnCompleteResponse, boolean isUpdateRequest) {
		this.productCode = productCode;
		this.entityType = entityType;
		this.transactionName = transactionName;
		this.rateTransaction = rateTransaction;
		this.completeTransaction = completeTransaction;
		this.returnCompleteResponse = returnCompleteResponse;
		this.isUpdateRequest = isUpdateRequest;
		this.transactionId = transactionId;
		user = APIRequestContext.getApiRequestContext().getMtUser();
	}

	/*
	 * This method receives the hierarchy of the micro-service calls which are
	 * required. These calls are parsed from the request JSON
	 */
	public MicroserviceProcessorResponse process(APIMicroserviceCallBean rootMSCallBean) throws Exception {
		
		String newTransactionId="";
		String newResponseEntityType="";
		List<Map<String, String>> ooseRevisions = null;
		MicroServiceFormat response = processMSStartNewTransaction(rootMSCallBean);
		resetContextParams();
		if(response == null){
			msResponse.setStatus(MicroserviceProcessorResponse.STATUS.FAILURE);
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			msResponse.setErrorCode(httpStatusCode);
			msResponse.setErroMessagesMap(erroMessagesMap);
			return msResponse;
		}
		if(isMultiThreadedExecution()){
			processMSBeanMultithreaded(rootMSCallBean);
		}else{
			processMSBean(rootMSCallBean);
		}
		boolean processSuspend = true;
		resetContextParams();
		if(rateTransaction){
			MicroServiceFormat validateResponse = null;
            try{  
            	validateResponse  = processValidateCall(rootMSCallBean);
            }catch(PCTRetryRequestException error){
				// Retry the validate request
            	//validateResponse  = processValidateCall(rootMSCallBean);
            	try{  
                	validateResponse  = processValidateCall(rootMSCallBean);
                }catch(PCTRetryRequestException retryError){
    				// Retry the validate request for oose across
                	validateResponse  = processValidateCall(rootMSCallBean);
    			}
			}
                        				
            
            newTransactionId = validateResponse.getTransactionID();
			newResponseEntityType = validateResponse.getEntityType();
			String newClientId = response.getClientID();
			

			if(  !"".equalsIgnoreCase(newTransactionId) && transactionId != null && !transactionId.equalsIgnoreCase(newTransactionId) && isOoseTransaction(newTransactionId, newResponseEntityType)){
				PCTRequestContext.getContext().getConnection().commit();
				msResponse.setStatus(MicroserviceProcessorResponse.STATUS.SUCCESSFULL);
				String httpStatusCode = String.valueOf(Response.Status.OK.getStatusCode());
				msResponse.setErrorCode(httpStatusCode);
				
				String entityType=newTransactionId.startsWith("Q")?"QUOTE":"POLICY";
				Object ooseResponse=(new JSONParser()).parse("{\"EntityReference\":\""+newTransactionId+"\",\"EntityType\":\""+entityType+"\",\"IsOOSE\":\""+"Y"+"\"}");
				msResponse.setResponseJson(ooseResponse);
				return msResponse; 
			}

	            
			if(validateResponse != null && validateResponse.getErrors() != null && !validateResponse.getErrors().isEmpty() ){
				// As there are validation errors, do not complete
				completeTransaction = false;
				addFinalErrorMessages(validateResponse.getErrors());
			}else if(validateResponse != null){
				clearValidationErrorMessages();
			}
		}
		if(completeTransaction){
			MicroServiceFormat completeResponse  = null;
			try{
				completeResponse =  processCompleteCall(rootMSCallBean);
			}catch(PCTRetryRequestException error){
				// Retry the complete request
				completeResponse  = processCompleteCall(rootMSCallBean);
			}
			
			if( ( null != completeResponse && null != completeResponse.getOoseRevisions()) && (null != isOose && "Y".equalsIgnoreCase(isOose))){
				ooseRevisions = completeResponse.getOoseRevisions();				
			}
			
			if(completeResponse != null && completeResponse.getErrors() != null && !completeResponse.getErrors().isEmpty() ){
				addFinalErrorMessages(completeResponse.getErrors());
			}else if(completeResponse != null){
				processSuspend = false;
				clearValidationErrorMessages();
			}
		}
		if(completeWithoutRateTrans){
			MicroServiceFormat completeResponse  = null;
			try{
				completeResponse =  processCompleteWithoutRateCall(rootMSCallBean);
			}catch(PCTRetryRequestException error){
				// Retry the complete request
				completeResponse  = processCompleteWithoutRateCall(rootMSCallBean);
			}
			
			
			if(completeResponse != null && completeResponse.getErrors() != null && !completeResponse.getErrors().isEmpty() ){
				addFinalErrorMessages(completeResponse.getErrors());
			}else if(completeResponse != null){
				processSuspend = false;
				clearValidationErrorMessages();
			}
		}
		if (processSuspend) {
			try {
				processSuspendCall(rootMSCallBean);
			} catch (PCTRetryRequestException error) {
				// Retry the suspend request
				processSuspendCall(rootMSCallBean);
			}
		}
		PCTRequestContext.getContext().getConnection().commit();
		
		
		if(returnCompleteResponse){
			Object responseJson = processExtractCall();
			
			if(null != isOose && "Y".equalsIgnoreCase(isOose) && null != ooseRevisions){
				JSONObject jsonInnerObject = new JSONObject();
				jsonInnerObject.putAll((Map<String,String>)responseJson);
				jsonInnerObject.put("OOSE revisions",ooseRevisions);
				
				responseJson = jsonInnerObject;
			}
			msResponse.setResponseJson(responseJson);
		}
		if(erroMessagesMap != null &&  erroMessagesMap.isEmpty()){
			msResponse.setStatus(MicroserviceProcessorResponse.STATUS.SUCCESSFULL);
			String httpStatusCode = String.valueOf(Response.Status.OK.getStatusCode());
			msResponse.setErrorCode(httpStatusCode);
		}else{
			msResponse.setStatus(MicroserviceProcessorResponse.STATUS.FAILURE);
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			msResponse.setErrorCode(httpStatusCode);
			msResponse.setErroMessagesMap(erroMessagesMap);
		}
		return msResponse;
	}
	
public MicroserviceProcessorResponse processToUpdateSSID(APIMicroserviceCallBean rootMSCallBean, String transactionId) throws Exception {

	String rootObjectGid = null;
	PreparedStatement Stmt = null;
	String rootObjDBTableName = null;
	String rootObjSSId = null;
	String rootObjOverRdSSId = null;
	Connection conn= null;
	PreparedStatement preStmt = null;
	ResultSet rs = null;
	
	try {
		conn = APIRequestContext.getApiRequestContext().getConnection();
		Stmt = conn.prepareStatement(" select gid from vw_mis_quote_policies where entity_reference = ? AND entity_type = ? ");
		 
		Stmt.setString(1, transactionId);
		Stmt.setString(2, entityType);
			 
		rs = Stmt.executeQuery();
		
		while(rs.next()) {
			rootObjectGid = rs.getString(1);
			}
	} catch (Exception ex) {
		erroMessagesMap.put(rootMSCallBean.getApiJsonPath(), getMSErrorMessageList(Collections.singletonList(QuotePolicyErrors.errors.INVALID_REQUEST_ERROR.getErrorMessage()+":" + rootMSCallBean.getApiJsonPath())));
	}finally  {
        try  {
            DBUtil.close(rs, Stmt);    
        } catch (Exception ex)  {
            //suppress
        } 
    }
	processMSBeanForSSID(rootMSCallBean, rootObjectGid);
	
	Map<String,String> dbTableCPMap=ProductCache.getProductCache().getDBTableByObjectContextPath();
	if(rootMSCallBean.getPctJsonPath() != null) {
		rootObjDBTableName= dbTableCPMap.get("/"+rootMSCallBean.getPctJsonPath());
	}
	rootObjSSId = rootMSCallBean.getSourceSystemId();
	rootObjOverRdSSId = rootMSCallBean.getOverrideSourceSystemId();
	
	if(null != rootObjSSId && null != rootObjOverRdSSId && null != rootObjectGid && null != rootObjDBTableName) {
		try {
			preStmt = conn.prepareStatement("UPDATE PCT_INSTANCE_INDEX SET PII_SOURCE_SYSTEM_ID = ? WHERE PII_SOURCE_SYSTEM_ID = ? AND PII_ROOT_OBJECT_GID = ? "
        			+ " AND PII_DB_TABLE_NAME = ? ");
			preStmt.setString(1,rootObjOverRdSSId);
			preStmt.setString(2,rootObjSSId);
			preStmt.setString(3,rootObjectGid);
			preStmt.setString(4,rootObjDBTableName);
			preStmt.executeUpdate();
			conn.commit();
    	} catch (Exception e) {
    		erroMessagesMap.put(rootMSCallBean.getApiJsonPath(), getMSErrorMessageList(Collections.singletonList(QuotePolicyErrors.errors.INVALID_REQUEST_ERROR.getErrorMessage()+":" + rootMSCallBean.getApiJsonPath())));
		}finally  {
	        try  {
	            DBUtil.close(null, preStmt);    
	        } catch (Exception ex)  {
	            //suppress
	        } 
	    }
	}
	
		if(returnCompleteResponse){
			Object responseJson = processExtractCall();
			msResponse.setResponseJson(responseJson);
		}
		if(erroMessagesMap != null &&  erroMessagesMap.isEmpty()){
			msResponse.setStatus(MicroserviceProcessorResponse.STATUS.SUCCESSFULL);
			String httpStatusCode = String.valueOf(Response.Status.OK.getStatusCode());
			msResponse.setErrorCode(httpStatusCode);
		}else{
			msResponse.setStatus(MicroserviceProcessorResponse.STATUS.FAILURE);
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			msResponse.setErrorCode(httpStatusCode);
			msResponse.setErroMessagesMap(erroMessagesMap);
		}
		return msResponse;
	}
	
	private void processMSBeanForSSID(APIMicroserviceCallBean msCallBean, String rootObjectGid) throws Exception {
		
		String sourceSystemId = null;
		String overrideSsId = null;
		Connection conn= null;
		PreparedStatement stmt = null;
		String objectDBTableName= null;
		if(msCallBean == null){
			return;
		}
		List<APIMicroserviceCallBean> childMsBeans = msCallBean.getChildObjectServiceCalls();
		if (childMsBeans != null && !childMsBeans.isEmpty()) {
			for (APIMicroserviceCallBean childMsBean : childMsBeans) {
				if (childMsBean.getPctXpath() != null) {
					sourceSystemId = childMsBean.getSourceSystemId();
					overrideSsId = childMsBean.getOverrideSourceSystemId();
					Map<String,String> dbTableCPMap=ProductCache.getProductCache().getDBTableByObjectContextPath();
					if(childMsBean.getPctJsonPath() != null) {
						objectDBTableName= dbTableCPMap.get("/"+childMsBean.getPctJsonPath());
					}
					
					if(null != sourceSystemId && null != overrideSsId && null != rootObjectGid && null != objectDBTableName) {
						try {
							conn = APIRequestContext.getApiRequestContext().getConnection();
				        	stmt = conn.prepareStatement("UPDATE PCT_INSTANCE_INDEX SET PII_SOURCE_SYSTEM_ID = ? WHERE PII_SOURCE_SYSTEM_ID = ? AND PII_ROOT_OBJECT_GID = ? "
				        			+ " AND PII_DB_TABLE_NAME = ? ");
				        	stmt.setString(1,overrideSsId);
				        	stmt.setString(2,sourceSystemId);
				        	stmt.setString(3,rootObjectGid);
				        	stmt.setString(4,objectDBTableName);
				        	stmt.executeUpdate();
				    	} catch (Exception e) {
				    		erroMessagesMap.put(childMsBean.getApiJsonPath(), getMSErrorMessageList(Collections.singletonList(QuotePolicyErrors.errors.INVALID_REQUEST_ERROR.getErrorMessage()+":" + childMsBean.getApiJsonPath())));
						}finally  {
					        try  {
					            DBUtil.close(null, stmt);    
					        } catch (Exception ex)  {
					            //suppress
					        } 
					    }
					}
					processMSBeanForSSID(childMsBean, rootObjectGid);
				}else{
					erroMessagesMap.put(childMsBean.getApiJsonPath(), getMSErrorMessageList(Collections.singletonList(QuotePolicyErrors.errors.INVALID_REQUEST_ERROR.getErrorMessage()+":" + childMsBean.getApiJsonPath())));
				}
			}
		}
	}	

	public  MicroserviceProcessorResponse initiateMSTransaction()throws Exception {
		MicroServiceFormat response = processMSStartNewTransaction();
		resetContextParams();
		if(response == null){
			msResponse.setStatus(MicroserviceProcessorResponse.STATUS.FAILURE);
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			msResponse.setErrorCode(httpStatusCode);
			msResponse.setErroMessagesMap(erroMessagesMap);
			return msResponse;
		}
		resetContextParams();
		boolean processSuspend = true;
		if(rateTransaction){
			MicroServiceFormat validateResponse = null;
            try{  
            	validateResponse  = processValidateCall(null);
            }catch(PCTRetryRequestException error){
				// Retry the validate request
            	validateResponse  = processValidateCall(null);
			}
			if(validateResponse != null && validateResponse.getErrors() != null && !validateResponse.getErrors().isEmpty() ){
				// As there are validation errors, do not complete
				completeTransaction = false;
				addFinalErrorMessages(validateResponse.getErrors());
			}else if(validateResponse != null){
				clearValidationErrorMessages();
			}
		}
		if(completeTransaction){
			MicroServiceFormat completeResponse  = null;
			try{
				completeResponse =  processCompleteCall(null);
			}catch(PCTRetryRequestException error){
				// Retry the complete request
				completeResponse  = processCompleteCall(null);
			}
			
			if(completeResponse != null && completeResponse.getErrors() != null && !completeResponse.getErrors().isEmpty() ){
				addFinalErrorMessages(completeResponse.getErrors());
			}else if(completeResponse != null){
				processSuspend = false;
				clearValidationErrorMessages();
			}
		}
		if (processSuspend) {
			try {
				processSuspendCall(null);
			} catch (PCTRetryRequestException error) {
				// Retry the suspend request
				processSuspendCall(null);
			}
		}
		
		if(returnCompleteResponse){
			Object responseJson = processExtractCall();
			msResponse.setResponseJson(responseJson);
		}
		if(erroMessagesMap != null &&  erroMessagesMap.isEmpty()){
			msResponse.setStatus(MicroserviceProcessorResponse.STATUS.SUCCESSFULL);
			String httpStatusCode = String.valueOf(Response.Status.OK.getStatusCode());
			msResponse.setErrorCode(httpStatusCode);
		}else{
			msResponse.setStatus(MicroserviceProcessorResponse.STATUS.FAILURE);
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			msResponse.setErrorCode(httpStatusCode);
			msResponse.setErroMessagesMap(erroMessagesMap);
		}
		return msResponse;
	}
	
	/*
	 * This method receives the hierarchy of the micro-service calls which are
	 * required. These calls are parsed from the request JSON
	 */
	public MicroserviceProcessorResponse processGet() throws Exception {

		Object responseJson = processExtractCall();
		msResponse.setResponseJson(responseJson);
		msResponse.setStatus(MicroserviceProcessorResponse.STATUS.SUCCESSFULL);
		String httpStatusCode = String.valueOf(Response.Status.OK.getStatusCode());
		msResponse.setErrorCode(httpStatusCode);

		return msResponse;
	}
	
	private void addFinalErrorMessages(List<ErrorMessage> finalErrorMessages) {
		if (finalErrorMessages == null || finalErrorMessages.isEmpty()) {
			return;
		}
		Map<String,List<ErrorMessage>> updatedErroMessagesMap = new HashMap<String,List<ErrorMessage>>() ;
		for(String key : erroMessagesMap.keySet()){
			List<ErrorMessage>  errorMessages = erroMessagesMap.get(key);	
			List<ErrorMessage>  filteredErrorMessage = new ArrayList<ErrorMessage>();
			for (ErrorMessage errrMsg : errorMessages) {
				if(errrMsg.getJasonPath() ==  null){
					filteredErrorMessage.add(errrMsg);
				}
			}
			updatedErroMessagesMap.put(key, filteredErrorMessage);
		}
		updatedErroMessagesMap.put(VALIDATIONS, finalErrorMessages);
		erroMessagesMap = updatedErroMessagesMap;
	}
	
	
	private void clearValidationErrorMessages() {
		Map<String,List<ErrorMessage>> updatedErroMessagesMap = new HashMap<String,List<ErrorMessage>>() ;
		for(String key : erroMessagesMap.keySet()){
			List<ErrorMessage>  errorMessages = erroMessagesMap.get(key);	
			List<ErrorMessage>  filteredErrorMessage = new ArrayList<ErrorMessage>();
			for (ErrorMessage errrMsg : errorMessages) {
				if(errrMsg.getJasonPath() ==  null){
					filteredErrorMessage.add(errrMsg);
				}
			}
			if(!filteredErrorMessage.isEmpty()){
				updatedErroMessagesMap.put(key, filteredErrorMessage);
			}
		}
		erroMessagesMap = updatedErroMessagesMap;
	}
	
	
	private void processMSBean(APIMicroserviceCallBean msCallBean) throws Exception {
		if(msCallBean == null){
			return;
		}
		List<APIMicroserviceCallBean> childMsBeans = msCallBean.getChildObjectServiceCalls();
		if (childMsBeans != null && !childMsBeans.isEmpty()) {
			for (APIMicroserviceCallBean childMsBean : childMsBeans) {
				if (childMsBean.getPctXpath() != null) {
					if (childMsBean.getSourceSystemId() == null) {
						try{
							Object response = processMSAddCall(childMsBean);
						}catch(PCTRetryRequestException error){
							// Retry the ADD request
							Object response = processMSAddCall(childMsBean);
						}
					} else {
						if (isUpdateRequest) {
							if ("Y".equalsIgnoreCase(childMsBean.getIsDelete())) {
								Object response = processMSDeleteCall(childMsBean);
							} else {
								Object response = processMSUpdateCall(childMsBean);
							}
						}else{
							erroMessagesMap.put(childMsBean.getApiJsonPath(), getMSErrorMessageList(Collections.singletonList(QuotePolicyErrors.errors.INVALID_UPDATE_ERROR.getErrorMessage() +":" + childMsBean.getApiJsonPath())));	
						}
					}
					resetContextParams();
					processMSBean(childMsBean);
				}else{
					erroMessagesMap.put(childMsBean.getApiJsonPath(), getMSErrorMessageList(Collections.singletonList(QuotePolicyErrors.errors.INVALID_REQUEST_ERROR.getErrorMessage()+":" + childMsBean.getApiJsonPath())));
				}
			}
		}
	}

	private MicroServiceFormat processMSStartNewTransaction(APIMicroserviceCallBean rootMSBean) throws Exception {
		MicroServiceFormat response = null;
		try {
			if(rootMSBean == null){
				return processMSStartNewTransaction();
			}
			HashMap<String, String> params = populateCommonParams();
			params.put(REST_METHOD, STARTNEW_POST);
			params.put(IPCTCFP.REQUEST_ACTION, IPCTCFP.RequestMethod.INIT_TRANSACTION.toString());
			transactionParams = MicroServiceDBUtil.getTransactionParams(transactionName);
			params.putAll(transactionParams);
			MicroServiceFormat msRequestFormat = getMSRequest(PCTMicroservicesTransaction.RequestMethodType.STARTNEW_POST, rootMSBean);
			Map<String, List<Map<String, String>>> instanceToBeMapped = new HashMap<String, List<Map<String, String>>>();
			List<Map<String, String>> instanceList = new ArrayList<Map<String, String>>();
			Map<String, String> withOverrideSSId = new HashMap<String, String>();
			withOverrideSSId = rootMSBean.getPostData();
			if(null != rootMSBean.getOverrideSourceSystemId() && !rootMSBean.getOverrideSourceSystemId().isEmpty()) {
				withOverrideSSId.put(SS_ID,rootMSBean.getOverrideSourceSystemId());
			}
			rootMSBean.setPostData(withOverrideSSId);
			instanceList.add(rootMSBean.getPostData());// changes 
			if(rootMSBean.getPctXpath() == null || rootMSBean.getPctXpath().isEmpty()){
				erroMessagesMap.put(rootMSBean.getApiJsonPath(), getMSErrorMessageList(Collections.singletonList(QuotePolicyErrors.errors.INVALID_REQUEST_ERROR.getErrorMessage()+":" + rootMSBean.getApiJsonPath())));
				return  response;
			}
			instanceToBeMapped.put(rootMSBean.getPctXpath(), instanceList);
			PCTMicroservicesTransaction micsroserviceTrans = new PCTMicroservicesTransaction(user, params, user.getUserId() + "@" + user.getDomain(), 0);
			response = micsroserviceTrans.processRequest(msRequestFormat, instanceToBeMapped, STARTNEW_POST, PCTRequestContext.getContext());
			transactionId = response.getTransactionID();
			responseEntityType = response.getEntityType();
			clientId = response.getClientID();
			List<ErrorMessage> erroMessages = response.getErrors();
			if(erroMessages != null && !erroMessages.isEmpty()){
			erroMessagesMap.put(msRequestFormat.getRestEndPoint(), erroMessages);
			}
			PCTRequestContext.getContext().getConnection().commit();
			List<Map<String, Object>> responseObjectValues = response.getObjectFieldValuesList();
			if(responseObjectValues != null && !responseObjectValues.isEmpty()){
				String rootSSID = (String)responseObjectValues.get(0).get(SS_ID);
				if(null == rootSSID || rootSSID.isEmpty()){
					rootSSID = (String)responseObjectValues.get(0).get("GID");
				}
				rootMSBean.setSourceSystemId(rootSSID);
				rootMSBean.setEndPointURL(END_POIMT_DELIM+rootMSBean.getPctXpath()+END_POIMT_DELIM+rootSSID);
			}
			return response;
		} catch (ProductServiceException e) {
			throw new Exception(e);
		} catch (Exception e) {
			throw e;
		}
	}

	
	private MicroServiceFormat processMSStartNewTransaction() throws Exception {
		MicroServiceFormat response = null;
		try {
			HashMap<String, String> params = populateCommonParams();
			params.put(REST_METHOD, STARTNEW_POST);
			params.put(IPCTCFP.REQUEST_ACTION, IPCTCFP.RequestMethod.INIT_TRANSACTION.toString());
			transactionParams = MicroServiceDBUtil.getTransactionParams(transactionName);
			params.putAll(transactionParams);
			MicroServiceFormat msRequestFormat = getMSRequest(PCTMicroservicesTransaction.RequestMethodType.STARTNEW_POST, null);
			Map<String, List<Map<String, String>>> instanceToBeMapped = new HashMap<String, List<Map<String, String>>>();
			List<Map<String, String>> instanceList = new ArrayList<Map<String, String>>();
			PCTMicroservicesTransaction micsroserviceTrans = new PCTMicroservicesTransaction(user, params, user.getUserId() + "@" + user.getDomain(), 0);
			response = micsroserviceTrans.processRequest(msRequestFormat, instanceToBeMapped, RequestMethodType.STARTNEW.toString(), PCTRequestContext.getContext());
			transactionId = response.getTransactionID();
			clientId = response.getClientID();
			responseEntityType = response.getEntityType();
			List<ErrorMessage> erroMessages = response.getErrors();
			if(erroMessages != null && !erroMessages.isEmpty()){
			erroMessagesMap.put(msRequestFormat.getRestEndPoint(), erroMessages);
			}
			PCTRequestContext.getContext().getConnection().commit();
			return response;
		} catch (ProductServiceException e) {
			throw new Exception(e);
		} catch (Exception e) {
			throw e;
		}
	}
	
	
	private Object processMSAddCall(APIMicroserviceCallBean addMSBeans) throws Exception {
		HashMap<String, String> params = populateCommonParams();
		params.put(IPCTCFP.REQUEST_ACTION, IPCTCFP.RequestMethod.GET_PAGE.toString());
		params.put(REST_METHOD, ADD);
		MicroServiceFormat msRequestFormat = getMSRequest(PCTMicroservicesTransaction.RequestMethodType.ADD, addMSBeans);
		Map<String, List<Map<String, String>>> instanceToBeMapped = new HashMap<String, List<Map<String, String>>>();
		List<Map<String, String>> instanceList = new ArrayList<Map<String, String>>();
		updateByRefReferenceInfo(addMSBeans);
		instanceList.add(addMSBeans.getPostData());
		if(addMSBeans.getPctXpath() == null || addMSBeans.getPctXpath().isEmpty()){
			erroMessagesMap.put(addMSBeans.getApiJsonPath(), getMSErrorMessageList(Collections.singletonList(QuotePolicyErrors.errors.INVALID_REQUEST_ERROR.getErrorMessage()+":" + addMSBeans.getApiJsonPath())));
			return  null;
		}
		instanceToBeMapped.put(addMSBeans.getPctXpath(), instanceList);
		PCTMicroservicesTransaction micsroserviceTrans = new PCTMicroservicesTransaction(user, params, user.getUserId() + "@" + user.getDomain(), 0);
		MicroServiceFormat response = null;
		try {
			 if(multiThreadedExecution){
				 Map<String, Map<String, String>> instanceToBeMappedMT = new HashMap<String, Map<String, String>>();
				 instanceToBeMappedMT.put(addMSBeans.getPctXpath(), addMSBeans.getPostData());
				 response = micsroserviceTrans.processMultiThreadedAPIRequest(msRequestFormat, instanceToBeMappedMT, 
						 PCTMicroservicesTransaction.RequestMethodType.ADD.toString(), PCTRequestContext.getContext());
			 }else{
				 response = micsroserviceTrans.processRequest(msRequestFormat, instanceToBeMapped,
					PCTMicroservicesTransaction.RequestMethodType.ADD.toString(), PCTRequestContext.getContext());
			 }
			 
			List<ErrorMessage> erroMessages = response.getErrors();
			if(response != null && response.getObjectFieldValuesList() != null){
				storeByRefReferenceIdSSIDMapping(response, addMSBeans);
			}
			if (erroMessages != null && !erroMessages.isEmpty()) {
				erroMessagesMap.put(msRequestFormat.getRestEndPoint(), erroMessages);
			}
		} catch (Exception e) {
			WebServiceLoggerUtil.logError("MicroServiceProcessor", "processMSAddCall", new Object[] { addMSBeans }, e);
			erroMessagesMap.put(msRequestFormat.getRestEndPoint(),getMSErrorMessageList(Collections.singletonList(QuotePolicyErrors.errors.ADD_ERROR.getErrorMessage()+":" + addMSBeans.getApiJsonPath())));
		}
		return response;
	}

	private MicroServiceFormat processValidateCall(APIMicroserviceCallBean rootMSBean) {
		MicroServiceFormat response = null;
		try {
			HashMap<String, String> params = populateCommonParams();
			params.put(REST_METHOD, RATE);
			params.put(IPCTCFP.REQUEST_ACTION, IPCTCFP.RequestMethod.RATE.toString());
			params.put(RE_EXECUTE_AFTER_ACK, "Y");
			params.put(PCTRequestContext.UPLOAD_PROCESSING_MODE, "N");
			MicroServiceFormat msRequestFormat = getMSRequest(PCTMicroservicesTransaction.RequestMethodType.RATE, rootMSBean);
			PCTMicroservicesTransaction micsroserviceTrans = new PCTMicroservicesTransaction(user, params, user.getUserId() + "@" + user.getDomain(), 0);
			response = micsroserviceTrans.processRequest(msRequestFormat, null, RATE, PCTRequestContext.getContext());
		} catch (Exception e) {
			WebServiceLoggerUtil.logError("MicroServiceProcessor", "processValidateCall", new Object[] { rootMSBean }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,
					getErrorMessageList(Collections.singletonList(QuotePolicyErrors.errors.VALIDATE_ERROR.getErrorMessage())), e, transactionId);
		}

		return response;
	}
	
	

	private MicroServiceFormat processSuspendCall(APIMicroserviceCallBean rootMSBean) {

		MicroServiceFormat response = null;
		MicroServiceFormat msRequestFormat = null;
		try {
			HashMap<String, String> params = populateCommonParams();
			params.put(SUSPEND.toLowerCase(), "Y");
			params.put(REST_METHOD, SUSPEND);
			params.put(EXIT_GRACEFULLY, "Y");
			params.put(IPCTCFP.REQUEST_ACTION, IPCTCFP.RequestMethod.FINALIZE_TRANSACTION.toString());
			msRequestFormat = getMSRequest(PCTMicroservicesTransaction.RequestMethodType.SUSPEND, rootMSBean);
			PCTMicroservicesTransaction micsroserviceTrans = new PCTMicroservicesTransaction(user, params, user.getUserId() + "@" + user.getDomain(), 0);
			response = micsroserviceTrans.processRequest(msRequestFormat, null, SUSPEND, PCTRequestContext.getContext());
			List<ErrorMessage> erroMessages = response.getErrors();
			if (erroMessages != null && !erroMessages.isEmpty()) {
				erroMessagesMap.put(msRequestFormat.getRestEndPoint(), erroMessages);
			}
		} catch (Exception e) {
			WebServiceLoggerUtil.logError("MicroServiceProcessor", "processSuspendCall", new Object[] { rootMSBean }, e);
			if(msRequestFormat != null){
				erroMessagesMap.put(msRequestFormat.getRestEndPoint(),getMSErrorMessageList(Collections.singletonList(QuotePolicyErrors.errors.SUSPEND_ERROR.getErrorMessage())));
			}
		}
		return response;
	}

	private MicroServiceFormat processCompleteCall(APIMicroserviceCallBean rootMSBean) {

		MicroServiceFormat response = null;
		MicroServiceFormat msRequestFormat = null;
		try {
			HashMap<String, String> params = populateCommonParams();
			
			params.put(NEXT_GEN, "Y");
			params.put(EXIT_GRACEFULLY, "Y");
			params.put(CALL_BEFORE_EXIT, "Y");
			params.put(NO_PROMPT_RATE, "Y");
			params.put(REST_METHOD, COMPLETE);
			params.put(RE_EXECUTE_AFTER_ACK, "Y");
			params.put(PCTRequestContext.UPLOAD_PROCESSING_MODE, "N");
			params.put(IPCTCFP.REQUEST_ACTION, IPCTCFP.RequestMethod.FINALIZE_TRANSACTION.toString());
			msRequestFormat = getMSRequest(PCTMicroservicesTransaction.RequestMethodType.COMPLETE, rootMSBean);
			PCTMicroservicesTransaction micsroserviceTrans = new PCTMicroservicesTransaction(user, params, user.getUserId() + "@" + user.getDomain(), 0);
			response = micsroserviceTrans.processRequest(msRequestFormat, null, COMPLETE, PCTRequestContext.getContext());
		} catch (Exception e) {
			WebServiceLoggerUtil.logError("MicroServiceProcessor", "processCompleteCall", new Object[] { rootMSBean }, e);
			if(msRequestFormat != null){
				erroMessagesMap.put(msRequestFormat.getRestEndPoint(),getMSErrorMessageList(Collections.singletonList(QuotePolicyErrors.errors.COMPLETE_ERROR.getErrorMessage())));
			}
		}
		return response;
	}
	
	private MicroServiceFormat processCompleteWithoutRateCall(APIMicroserviceCallBean rootMSBean) {

		MicroServiceFormat response = null;
		MicroServiceFormat msRequestFormat = null;
		try {
			HashMap<String, String> params = populateCommonParams();
		
			params.put(REST_METHOD, COMPLETE_WITHOUT_RATE);
			params.put(PCTRequestContext.UPLOAD_PROCESSING_MODE, "N");
			params.put(IPCTCFP.REQUEST_ACTION, IPCTCFP.RequestMethod.FINALIZE_TRANSACTION.toString());
			msRequestFormat = getMSRequest(PCTMicroservicesTransaction.RequestMethodType.COMPLETEWITHOUTRATE, rootMSBean);
			PCTMicroservicesTransaction micsroserviceTrans = new PCTMicroservicesTransaction(user, params, user.getUserId() + "@" + user.getDomain(), 0);
			response = micsroserviceTrans.processRequest(msRequestFormat, null, COMPLETE_WITHOUT_RATE, PCTRequestContext.getContext());
		} catch (Exception e) {
			WebServiceLoggerUtil.logError("MicroServiceProcessor", "processCompleteWithoutRateCall", new Object[] { rootMSBean }, e);
			if(msRequestFormat != null){
				erroMessagesMap.put(msRequestFormat.getRestEndPoint(),getMSErrorMessageList(Collections.singletonList(QuotePolicyErrors.errors.COMPLETE_ERROR.getErrorMessage())));
			}
		}
		return response;
	}
	
	private Object processMSUpdateCall(APIMicroserviceCallBean addMSBeans) throws Exception {
		if(addMSBeans.getPostData() == null || addMSBeans.getPostData().isEmpty()){
			// Nothing to update here
			MicroServiceFormat msRequestFormat = getMSRequest(PCTMicroservicesTransaction.RequestMethodType.UPDATE, addMSBeans);
			return null;
		}
		
		HashMap<String, String> params = populateCommonParams();
		params.put(IPCTCFP.REQUEST_ACTION, IPCTCFP.RequestMethod.GET_PAGE.toString());
		params.put(REST_METHOD, UPDATE);
		MicroServiceFormat msRequestFormat = getMSRequest(PCTMicroservicesTransaction.RequestMethodType.UPDATE, addMSBeans);
		Map<String, List<Map<String, String>>> instanceToBeMapped = new HashMap<String, List<Map<String, String>>>();
		List<Map<String, String>> instanceList = new ArrayList<Map<String, String>>();
		updateByRefReferenceInfo(addMSBeans);
		
		instanceList.add(addMSBeans.getPostData());
		if(addMSBeans.getPctXpath() == null || addMSBeans.getPctXpath().isEmpty()){
			erroMessagesMap.put(addMSBeans.getApiJsonPath(), getMSErrorMessageList(Collections.singletonList(QuotePolicyErrors.errors.INVALID_REQUEST_ERROR.getErrorMessage())));
			return  null;
		}
		instanceToBeMapped.put(addMSBeans.getPctXpath(), instanceList);
		PCTMicroservicesTransaction micsroserviceTrans = new PCTMicroservicesTransaction(user, params, user.getUserId() + "@" + user.getDomain(), 0);
		MicroServiceFormat response = null;
		try {
			
			if(multiThreadedExecution){
				 Map<String, Map<String, String>> instanceToBeMappedMT = new HashMap<String, Map<String, String>>();
				 instanceToBeMappedMT.put(addMSBeans.getPctXpath(), addMSBeans.getPostData());
				 response = micsroserviceTrans.processMultiThreadedAPIRequest(msRequestFormat, instanceToBeMappedMT, 
						 PCTMicroservicesTransaction.RequestMethodType.UPDATE.toString(), PCTRequestContext.getContext());
			 }else{
				 response = micsroserviceTrans.processRequest(msRequestFormat, instanceToBeMapped,
					PCTMicroservicesTransaction.RequestMethodType.UPDATE.toString(), PCTRequestContext.getContext());
			 }
			if (response != null && response.getObjectFieldValuesList() != null) {
				storeByRefReferenceIdSSIDMapping(response, addMSBeans);
			}
			List<ErrorMessage> erroMessages = response.getErrors();
			if (erroMessages != null && !erroMessages.isEmpty()) {
				erroMessagesMap.put(msRequestFormat.getRestEndPoint(), erroMessages);
			}
		} catch (Exception e) {
			WebServiceLoggerUtil.logError("MicroServiceProcessor", "processMSUpdateCall", new Object[] { addMSBeans }, e);
			erroMessagesMap.put(msRequestFormat.getRestEndPoint(),getMSErrorMessageList(Collections.singletonList(QuotePolicyErrors.errors.UPDATE_ERROR.getErrorMessage())));
		}
		return response;
	}
	
	
	private Object processMSDeleteCall(APIMicroserviceCallBean addMSBeans) throws Exception {
		HashMap<String, String> params = populateCommonParams();
		params.put(IPCTCFP.REQUEST_ACTION, IPCTCFP.RequestMethod.GET_PAGE.toString());
		params.put(REST_METHOD, DELETE);
		MicroServiceFormat msRequestFormat = getMSRequest(PCTMicroservicesTransaction.RequestMethodType.DELETE, addMSBeans);
		Map<String, List<Map<String, String>>> instanceToBeMapped = new HashMap<String, List<Map<String, String>>>();
		List<Map<String, String>> instanceList = new ArrayList<Map<String, String>>();
		PCTMicroservicesTransaction micsroserviceTrans = new PCTMicroservicesTransaction(user, params, user.getUserId() + "@" + user.getDomain(), 0);
		MicroServiceFormat response = null;
		try {
			 response = micsroserviceTrans.processRequest(msRequestFormat, instanceToBeMapped,
					PCTMicroservicesTransaction.RequestMethodType.DELETE.toString(), PCTRequestContext.getContext());
			List<ErrorMessage> erroMessages = response.getErrors();
			if (erroMessages != null && !erroMessages.isEmpty()) {
				erroMessagesMap.put(msRequestFormat.getRestEndPoint(), erroMessages);
			}
		} catch (Exception e) {
			WebServiceLoggerUtil.logError("MicroServiceProcessor", "processMSDeleteCall", new Object[] { addMSBeans }, e);
			erroMessagesMap.put(msRequestFormat.getRestEndPoint(),getMSErrorMessageList(Collections.singletonList(QuotePolicyErrors.errors.DELETE_ERROR.getErrorMessage())));
		}
		return response;
	}
	
	private Object processExtractCall() throws Exception{
		String responseJson = null;
		ExtractTransactionRequest extractTransactionRequest = new ExtractTransactionRequest();
		extractTransactionRequest.setEntityType(entityType);
		if(responseEntityType != null && !responseEntityType.isEmpty() ){
			extractTransactionRequest.setEntityType(responseEntityType);
		}
		extractTransactionRequest.setEntityReference(transactionId);
		ExtractTransactionProcessor extractor = new ExtractTransactionProcessor(extractTransactionRequest, user, DATE_FORMAT); 
		Map<String, Object> responseObj = (Map<String, Object>)extractor.extractTransaction(null,null);
		Object response = responseObj;
		if(responseTransformer != null){
			response = responseTransformer.parseJsonStructure(responseObj);
		}
		return response;
	}

	private MicroServiceFormat getMSRequest(PCTMicroservicesTransaction.RequestMethodType requestType, APIMicroserviceCallBean msCallBean) {
		MicroServiceFormat requestData = new MicroServiceFormat();
		requestData.setEntityType(entityType);
		requestData.setProductName(productCode);
		requestData.setUseOptimizedFlow(true);
		if (PCTMicroservicesTransaction.RequestMethodType.STARTNEW_POST.equals(requestType)) {
			requestData.setRestEndPoint(START_TRANS_END_POINT);
		} else {
			if (PCTMicroservicesTransaction.RequestMethodType.RATE.equals(requestType)) {
				requestData.setRestEndPoint(VALIDATE_TRANS_END_POINT);
			}else if(PCTMicroservicesTransaction.RequestMethodType.SUSPEND.equals(requestType)) {
				requestData.setRestEndPoint(SUSPEND_TRANS_END_POINT);
			}else if(PCTMicroservicesTransaction.RequestMethodType.COMPLETE.equals(requestType)) {
				requestData.setRestEndPoint(COMPLETE_TRANS_END_POINT);
			}else if(PCTMicroservicesTransaction.RequestMethodType.COMPLETEWITHOUTRATE.equals(requestType)) {
				requestData.setRestEndPoint(COMPLETE_WITHOUT_RATE_END_POINT);
			}else{
				String restEndPoint = msCallBean.getParentMSCallbean().getEndPointURL()+ END_POIMT_DELIM +msCallBean.getPctXpath();
				restEndPoint = restEndPoint+END_POIMT_DELIM;
				if(msCallBean.getSourceSystemId() != null){
					restEndPoint = restEndPoint+msCallBean.getSourceSystemId();
				}else{
					if(msCallBean.getOverrideSourceSystemId() != null) {
						restEndPoint = restEndPoint+msCallBean.getOverrideSourceSystemId();
					}else {
						String SSID = generateSSID(msCallBean.getPctJsonPath());
						restEndPoint = restEndPoint+SSID;
						msCallBean.setSourceSystemId(SSID);
					}
				}
				requestData.setRestEndPoint(restEndPoint);
				msCallBean.setEndPointURL(restEndPoint);
			}
			requestData.setClientID(clientId);
			requestData.setTransactionID(transactionId);
		}
		return requestData;
	}

	private HashMap<String, String> populateCommonParams() {
		HashMap<String, String> params = new HashMap<String, String>();
		params.put(ENTITY_REFERENCE, "-1");
		if (transactionId != null) {
			params.put(ENTITY_REFERENCE, transactionId);
		}
		
		if(enableValidations==null) {
			try {
			enableValidations="Y";
			params.put(MicroServiceServlet.ENABLE_VALIDATION,enableValidations);
			}catch(Exception exp) {
				//do nothing
			}
		}
		if(multiThreadedExecution) {
			params.put(MicroServiceServlet.MULTI_THREADING_ALLOW, "Y");
		}
		if(errorMessagePlaceHolderType != null) {
			params.put(MicroServiceServlet.ERROR_MSG_PLACE_HOLDER_TYPE, errorMessagePlaceHolderType);
		}
		if(validateOnly){
			params.put(PCTMicroservicesTransaction.VALIDATE_ONLY, "Y");
		}
		params.put(PCTRequestContext.ENTITY_TYPE, entityType);
		params.put(PCTRequestContext.PRODUCT_CODE, productCode);
		params.put(PCTRequestContext.IS_MICRO_SERVICES, "true");
		params.put(PCTRequestContext.UPLOAD_PROCESSING_MODE, "Y");		
		params.put(PCTEntityTransaction.ACKNOWLEDGE_ALERT, "Y");
		params.put(MicroServiceServlet.IGNORE_AUTO_INSTANCE_CREATION, "Y");
		params.put(AbstractMicroserviceHandler.API_DATE_FORMAT, DATE_FORMAT);
		params.put(AbstractMicroserviceHandler.API_REQUEST, "true");
		if ("QUOTE".equalsIgnoreCase(entityType)) {
			if (isQuickQuoteMode) {
				params.put("viewMode", EntityViewMode.QUICK.toString());
				PCTRequestContext.getContext().setEntityViewMode(EntityViewMode.QUICK);
			} else {
				params.put("viewMode", EntityViewMode.FULL.toString());
				PCTRequestContext.getContext().setEntityViewMode(EntityViewMode.FULL);
			}
		}

		return params;
	}

	private String generateSSID(String pctContextPath) {
		Random rand = new Random();
		int randomNumber = rand.nextInt(10000);
		if(randomNumber == 0){
			randomNumber = randomNumber+1;
		}
		String ssId = "API" + "_" + randomNumber;
		if(ssIdMap != null && ssIdMap.containsKey(pctContextPath) ){
			List<String> allocatedSSIDs =   ssIdMap.get(pctContextPath);
			if(allocatedSSIDs != null && allocatedSSIDs.contains(ssId)){
				ssId = generateSSID(pctContextPath);
			}
		}
		return ssId;
	}
	
	public static List<Message> getErrorMessageList(List<String> strMessages)	{
		if(strMessages == null)	{
			return null;
		}
		List<Message> errorMessageList = new ArrayList<Message>(strMessages.size());
		for(String aMsg : strMessages)	{
			Message message = new Message();
			message.setMoreinfo(aMsg);
			errorMessageList.add(message);
		}
		return errorMessageList;
	}
	
	
	public static List<ErrorMessage> getMSErrorMessageList(List<String> strMessages)	{
		if(strMessages == null)	{
			return null;
		}
		List<ErrorMessage> errorMessageList = new ArrayList<ErrorMessage>(strMessages.size());
		for(String aMsg : strMessages)	{
			ErrorMessage message = new ErrorMessage();
			message.setMessage(aMsg);
			errorMessageList.add(message);
		}
		return errorMessageList;
	}
	
	
	
	public void setResponseTransformer(APIResponseTransformer responseTransformer) {
		this.responseTransformer = responseTransformer;
	}
	
	public boolean isQuickQuoteMode() {
		return isQuickQuoteMode;
	}
	public void setQuickQuoteMode(boolean isQuickQuoteMode) {
		this.isQuickQuoteMode = isQuickQuoteMode;
	}
	
	public boolean isOverrideSourceSystemId() {
		return isOverrideSourceSystemId;
	}

	public void setOverrideSourceSystemId(boolean isOverrideSourceSystemId) {
		this.isOverrideSourceSystemId = isOverrideSourceSystemId;
	}

	public Map<String, ArrayList<String>> getByRefPCTJsontoAttributeMap() {
		return byRefPCTJsontoAttributeMap;
	}

	public void setByRefPCTJsontoAttributeMap(Map<String, ArrayList<String>> byRefPCTJsontoAttributeMap) {
		this.byRefPCTJsontoAttributeMap = byRefPCTJsontoAttributeMap;
	}
	
	private void updateByRefReferenceInfo(APIMicroserviceCallBean msCallBean) {
		String pctJsonPath = msCallBean.getPctJsonPath();
		if (byRefPCTJsontoAttributeMap != null && pctJsonPath != null && byRefPCTJsontoAttributeMap.containsKey(pctJsonPath)) {
			List<String> byRefAttributeList = byRefPCTJsontoAttributeMap.get(pctJsonPath);
			if (byRefAttributeList != null && msCallBean != null && msCallBean.getPostData() != null && msCallBean.getPostData().size() > 0) {
				for (String attributeName : msCallBean.getPostData().keySet()) {
					String attributeValue =  msCallBean.getPostData().get(attributeName);
					if (checkIfByRefAttribute(byRefAttributeList, attributeName)  && referenceIdtoSSIdMap.containsKey(attributeValue)) {
						String byRefSSId = referenceIdtoSSIdMap.get(attributeValue);
						msCallBean.getPostData().put(attributeName, byRefSSId);
					}
				}
			}
		}
	}
	
	private void storeByRefReferenceIdSSIDMapping(MicroServiceFormat response, APIMicroserviceCallBean msCallBean) {
		if (msCallBean.getPostData() != null && !msCallBean.getPostData().isEmpty()) {
			String referenceId = getReferenceIdIfPresent(msCallBean.getPostData());
			if (referenceId != null && response != null && response.getObjectFieldValuesList() != null) {
				Map<String, Object> responseMap = response.getObjectFieldValuesList().get(0);
				if (responseMap != null && responseMap.containsKey(sourceSystemID)) {
					String ssid = (String) responseMap.get(sourceSystemID);
					if (ssid != null) {
						referenceIdtoSSIdMap.put(referenceId, ssid);
					}
				}
			}
		}
	}
	
	
	private String getSSID(MicroServiceFormat response) {
			if (response != null && response.getObjectFieldValuesList() != null) {
				Map<String, Object> responseMap = response.getObjectFieldValuesList().get(0);
				if (responseMap != null && responseMap.containsKey(sourceSystemID)) {
					String ssid = (String) responseMap.get(sourceSystemID);
					return ssid;
				}
			}
			return null;
	}
	
	private boolean checkIfByRefAttribute(List<String> byRefAttributeList , String attributeName ){
		for(String byRefAttributeName : byRefAttributeList){
			if(byRefAttributeName != null && byRefAttributeName.equalsIgnoreCase(attributeName)){
				return true;
			}
		}
		return false;
	}
	

	private String getReferenceIdIfPresent( Map<String, String> postdata ){
		for(String attributeName : postdata.keySet()){
			if(attributeName != null && attributeName.equalsIgnoreCase(OpenAPISpecGenerator.REFERENCE_ID)){
				String referenceId = postdata.get(attributeName);
				return referenceId;
			}
		}
		return null;
	}
	
	//Reset the SSID otherwise all the autogenerated objects will have same SSID which was set before
	private void resetContextParams(){
		if(PCTRequestContext.getContext() != null){
			PCTRequestContext.getContext().setParameterValue("SOURCE_SYSTEM_ID",null );
		}
	}
	
	public boolean isMultiThreadedExecution() {
		return multiThreadedExecution;
	}


	public void setMultiThreadedExecution(boolean multiThreadedExecution) {
		this.multiThreadedExecution = multiThreadedExecution;
	}
	
		
	public String getErrorMessagePlaceHolderType() {
		return errorMessagePlaceHolderType;
	}


	public void setErrorMessagePlaceHolderType(String errorMessagePlaceHolderType) {
		this.errorMessagePlaceHolderType = errorMessagePlaceHolderType;
	}


	private void processMSBeanMultithreaded(APIMicroserviceCallBean msCallBean) throws Exception {
		if(msCallBean == null || msCallBean.isProcessedOnce()){
			return;
		}
		List<APIMicroserviceCallBean> childMsBeans = msCallBean.getChildObjectServiceCalls();
		
		Map<String,ArrayList<APIMicroserviceCallBean>> parallelAddMsCalls = new LinkedHashMap<String, ArrayList<APIMicroserviceCallBean>>();
		Map<String,ArrayList<APIMicroserviceCallBean>> parallelUpdateMsCalls = new LinkedHashMap<String, ArrayList<APIMicroserviceCallBean>>();
		
		ArrayList<APIMicroserviceCallBean> parallelAddMsBeans = null;
		ArrayList<APIMicroserviceCallBean> parallelUpdateMsBeans =  null;
		
		
		/*
		 * Filter the multiple request for same objects which can be processed in parallel	 
		 */
		if (childMsBeans != null && !childMsBeans.isEmpty()) {
			for (APIMicroserviceCallBean childMsBean : childMsBeans) {
				String pctXpath = childMsBean.getPctXpath();
				if (pctXpath != null) {
					if (childMsBean.getSourceSystemId() == null) {
						if (parallelAddMsCalls.containsKey(pctXpath)) {
							parallelAddMsBeans = parallelAddMsCalls.get(pctXpath);
							parallelAddMsBeans.add(childMsBean);
						} else {
							parallelAddMsBeans = new ArrayList<APIMicroserviceCallBean>();
							parallelAddMsBeans.add(childMsBean);
							parallelAddMsCalls.put(pctXpath, parallelAddMsBeans);
						}

					} else {
						if (isUpdateRequest) {
							if (!"Y".equalsIgnoreCase(childMsBean.getIsDelete())) {
								if (parallelUpdateMsCalls.containsKey(pctXpath)) {
									parallelUpdateMsBeans = parallelAddMsCalls.get(pctXpath);
									parallelUpdateMsBeans.add(childMsBean);
								} else {
									parallelUpdateMsBeans = new ArrayList<APIMicroserviceCallBean>();
									parallelUpdateMsBeans.add(childMsBean);
									parallelUpdateMsCalls.put(pctXpath, parallelUpdateMsBeans);
								}
							}
						}
					}
				}
			}
		}
		
		// Process the beans in same hierarchy, if there are multiple instance of same object then process them in parallel 
		if (childMsBeans != null && !childMsBeans.isEmpty()) {
			for (APIMicroserviceCallBean childMsBean : childMsBeans) {
				if (childMsBean.getPctXpath() != null && !childMsBean.isProcessedOnce()) {
					String pctXpathForBean = childMsBean.getPctXpath();
					if (childMsBean.getSourceSystemId() == null) {
						if (parallelAddMsCalls.containsKey(pctXpathForBean) && parallelAddMsCalls.get(pctXpathForBean) != null
								&& parallelAddMsCalls.get(pctXpathForBean).size() > 1
								) {
							/// More than one instance detected, process them in parallel
							ArrayList<APIMicroserviceCallBean> addRequestsToBeProcesedInParalell =parallelAddMsCalls.get(pctXpathForBean);
							prepareAndExecuteRequestsInMT(addRequestsToBeProcesedInParalell, ADD);
							for(APIMicroserviceCallBean processedBeans : addRequestsToBeProcesedInParalell){
								processedBeans.setProcessedOnce(true);
							}
						} else {
							try {
								Object response = processMSAddCall(childMsBean);
							} catch (PCTRetryRequestException error) {
								// Retry the ADD request
								Object response = processMSAddCall(childMsBean);
							}
						}
					} else {
						if (isUpdateRequest) {
							if ("Y".equalsIgnoreCase(childMsBean.getIsDelete())) {
								Object response = processMSDeleteCall(childMsBean);
							} else {
								if (parallelUpdateMsCalls.containsKey(pctXpathForBean) && parallelUpdateMsCalls.get(pctXpathForBean) != null
										&& parallelUpdateMsCalls.get(pctXpathForBean).size() > 1) {
									/// More than one instance detected, process them in parallel
									ArrayList<APIMicroserviceCallBean> updateRequestsToBeProcesedInParalell =parallelUpdateMsCalls.get(pctXpathForBean);
									
								}else{
									Object response = processMSUpdateCall(childMsBean);
								}
							}
						}else{
							erroMessagesMap.put(childMsBean.getApiJsonPath(), getMSErrorMessageList(Collections.singletonList(QuotePolicyErrors.errors.INVALID_UPDATE_ERROR.getErrorMessage() +":" + childMsBean.getApiJsonPath())));	
						}
					}
					resetContextParams();
					processMSBeanMultithreaded(childMsBean);
				}else{
					if(childMsBean.getPctXpath() == null){
					erroMessagesMap.put(childMsBean.getApiJsonPath(), getMSErrorMessageList(Collections.singletonList(QuotePolicyErrors.errors.INVALID_REQUEST_ERROR.getErrorMessage()+":" + childMsBean.getApiJsonPath())));
					}
				}
			}
		}
	}
	
	
	
	private Object prepareAndExecuteRequestsInMT(ArrayList<APIMicroserviceCallBean> msBeans, String methodType) throws Exception {
		/*
		if (ADD.equalsIgnoreCase(methodType)) {
			// Process blank Addition sequentially & update in parallel
			for (APIMicroserviceCallBean msBean : msBeans) {
				APIMicroserviceCallBean addMsBean = msBean.deepClone();
				// Remove postdata as we need just the blank instance
				addMsBean.setPostData(new HashMap<String, String>());
				String ssid = null;
				try {
					Object response = processMSAddCall(addMsBean);
					ssid = getSSID((MicroServiceFormat)response);
				} catch (PCTRetryRequestException error) {
					// Retry the ADD request
					Object response = processMSAddCall(addMsBean);
					ssid = getSSID((MicroServiceFormat)response);
				}
				if(ssid != null){
					msBean.setSourceSystemId(ssid);
				}
			}
		}*/

		for (APIMicroserviceCallBean msBean : msBeans) {
			List<QuotePolicyAPIExecutorInput> apiExecutorInputList = generateInputForMultiThreadedTask(msBean, methodType);
			//generateBlankInstancesForParallelProcessing( apiExecutorInputList);
			submitTask(apiExecutorInputList);
		}
		prepareOutput();
		resetContextParams();
		return null;
	}
		
	
	private List<QuotePolicyAPIExecutorInput> generateInputForMultiThreadedTask(APIMicroserviceCallBean msBeans, String methodType) {

		List<QuotePolicyAPIExecutorInput> apiExecutorInputList = new ArrayList<QuotePolicyAPIExecutorInput>();
		QuotePolicyAPIExecutorInput executorInput = null;
		HashMap<String, String> params = populateCommonParams();
		params.put(IPCTCFP.REQUEST_ACTION, IPCTCFP.RequestMethod.GET_PAGE.toString());
		
		if (ADD.equalsIgnoreCase(methodType)) {
			params.put(REST_METHOD, ADD);
			MicroServiceFormat msRequestFormat = getMSRequest(PCTMicroservicesTransaction.RequestMethodType.ADD, msBeans);
			Map<String, Map<String, String>> instanceToBeMapped = new HashMap<String, Map<String, String>>();
			updateByRefReferenceInfo(msBeans);
			if (msBeans.getPctXpath() == null || msBeans.getPctXpath().isEmpty()) {
				erroMessagesMap.put(
						msBeans.getApiJsonPath(),
						getMSErrorMessageList(Collections.singletonList(QuotePolicyErrors.errors.INVALID_REQUEST_ERROR.getErrorMessage() + ":"
								+ msBeans.getApiJsonPath())));
				return null;
			}
			instanceToBeMapped.put(msBeans.getPctXpath(), msBeans.getPostData());
			executorInput = new QuotePolicyAPIExecutorInput(msRequestFormat, instanceToBeMapped, PCTMicroservicesTransaction.RequestMethodType.ADD.toString(), params, msBeans);
			apiExecutorInputList.add(executorInput);
		}else if (UPDATE.equalsIgnoreCase(methodType)) {
			params.put(REST_METHOD, UPDATE);
			MicroServiceFormat msRequestFormat = getMSRequest(PCTMicroservicesTransaction.RequestMethodType.UPDATE, msBeans);
			Map<String, Map<String, String>> instanceToBeMapped = new HashMap<String, Map<String, String>>();
			updateByRefReferenceInfo(msBeans);
			if (msBeans.getPctXpath() == null || msBeans.getPctXpath().isEmpty()) {
				erroMessagesMap.put(
						msBeans.getApiJsonPath(),
						getMSErrorMessageList(Collections.singletonList(QuotePolicyErrors.errors.INVALID_REQUEST_ERROR.getErrorMessage() + ":"
								+ msBeans.getApiJsonPath())));
				return null;
			}
			instanceToBeMapped.put(msBeans.getPctXpath(), msBeans.getPostData());
			executorInput = new QuotePolicyAPIExecutorInput(msRequestFormat, instanceToBeMapped, PCTMicroservicesTransaction.RequestMethodType.UPDATE.toString(), params, msBeans);
			apiExecutorInputList.add(executorInput);
		}else if (DELETE.equalsIgnoreCase(methodType)) {
			params.put(REST_METHOD, DELETE);
			MicroServiceFormat msRequestFormat = getMSRequest(PCTMicroservicesTransaction.RequestMethodType.DELETE, msBeans);
			Map<String, Map<String, String>> instanceToBeMapped = new HashMap<String, Map<String, String>>();
			executorInput = new QuotePolicyAPIExecutorInput(msRequestFormat, instanceToBeMapped, PCTMicroservicesTransaction.RequestMethodType.DELETE.toString(), params, msBeans);
			apiExecutorInputList.add(executorInput);
			// No need to process child as parent is getting deleted
			return apiExecutorInputList;
		}

		if (msBeans.getChildObjectServiceCalls() != null && !msBeans.getChildObjectServiceCalls().isEmpty()) {
			List<APIMicroserviceCallBean> childMsBeans = msBeans.getChildObjectServiceCalls();
			for (APIMicroserviceCallBean childMsBean : childMsBeans) {
				List<QuotePolicyAPIExecutorInput> childInputList = null;
				String pctXpath = childMsBean.getPctXpath();
				if (pctXpath != null) {
					if (childMsBean.getSourceSystemId() == null) {
					  childInputList = generateInputForMultiThreadedTask(childMsBean, ADD);
						
					} else {
						if ("Y".equalsIgnoreCase(childMsBean.getIsDelete())) {
							// Delete
							childInputList = generateInputForMultiThreadedTask(childMsBean, DELETE);
						} else {
							childInputList = generateInputForMultiThreadedTask(childMsBean, UPDATE);
						}
					}
					if(childInputList != null){
						apiExecutorInputList.addAll(childInputList);
					}
				}
			}

		}
		return apiExecutorInputList;
	}
	
	
	private void submitTask(List<QuotePolicyAPIExecutorInput> apiExecutorInputList){
		QuotePolicyAPIExecutorTask task = new QuotePolicyAPIExecutorTask(PCTRequestContext.getContext(), user, apiExecutorInputList, this);
		PCTApiForkJoinPoolMgr.getInstance().executeTask(task);
		submittedTasks.add(task);
	}
	
	
	
	private void prepareOutput() {
		List<QuotePolicyExecutorOutput> output = null;
		try{
		for (QuotePolicyAPIExecutorTask submittedTask : submittedTasks) {
			try {
				Boolean result = submittedTask.get(); // blocking call
				output = submittedTask.getResponse();
				
				for(QuotePolicyExecutorOutput response : output){
					MicroServiceFormat msResponse = response.getResponse();
					QuotePolicyAPIExecutorInput input =  response.getInput();
					List<ErrorMessage> erroMessages = msResponse.getErrors();
					if (response != null && msResponse.getObjectFieldValuesList() != null) {
						storeByRefReferenceIdSSIDMapping(msResponse, input.getMsBean());
					}
					if (erroMessages != null && !erroMessages.isEmpty()) {
						erroMessagesMap.put(msResponse.getRestEndPoint(), erroMessages);
					}
				}
				
			} catch (Exception e) { // java.util.concurrent.ExecutionException
				String errMsgTemp = PCTGenUtils.getErrorMessage(e);
				PCTLogUtil.logErrorIntoContextLogger(getClass(), "prepareOutput", new Object[] {}, e, errMsgTemp);
				erroMessagesMap.put("Error : ",getMSErrorMessageList(Collections.singletonList(errMsgTemp)));
			}
		}
		} finally{
			submittedTasks.clear();
		}
		
	}
	
	public synchronized void  generateBlankInstancesForParallelProcessing( QuotePolicyAPIExecutorInput apiExecutorInput)
			throws Exception {
		List<QuotePolicyAPIExecutorInput> apiExecutorInputList = new ArrayList<QuotePolicyAPIExecutorInput>();
		apiExecutorInputList.add(apiExecutorInput);
		generateBlankInstancesForParallelProcessing(apiExecutorInputList);
		resetContextParams();
	}
	
	public synchronized void  processDeleteForParallelProcessing( QuotePolicyAPIExecutorInput apiExecutorInput) throws Exception{
		// Delete will happen sequentially 
		APIMicroserviceCallBean msBean = apiExecutorInput.getMsBean();
		MicroServiceFormat request = apiExecutorInput.getRequest();
		APIMicroserviceCallBean addMsBean = msBean.deepClone();
		processMSDeleteCall(addMsBean);
		resetContextParams();
	}
	
	
	
	private void generateBlankInstancesForParallelProcessing( List<QuotePolicyAPIExecutorInput> apiExecutorInputList)
			throws Exception {
		for (QuotePolicyAPIExecutorInput input : apiExecutorInputList) {

			APIMicroserviceCallBean msBean = input.getMsBean();
			MicroServiceFormat request = input.getRequest();
			APIMicroserviceCallBean addMsBean = msBean.deepClone();
			// Remove postdata as we need just the blank instance
			addMsBean.setPostData(new HashMap<String, String>());
			String ssid = null;
			Object response = null ;
			try {
				response = processMSAddCall(addMsBean);
				ssid = getSSID((MicroServiceFormat) response);
			} catch (PCTRetryRequestException error) {
				// Retry the ADD request
				response = processMSAddCall(addMsBean);
				ssid = getSSID((MicroServiceFormat) response);
			}
			if (ssid != null) {
				MicroServiceFormat responseObj = (MicroServiceFormat)response;
				msBean.setSourceSystemId(ssid);
				msBean.setEndPointURL(addMsBean.getEndPointURL());
				request.setRestEndPoint(addMsBean.getEndPointURL());
			}
		}
	}
	
	public String getIsOose() {
		return isOose;
	}


	public void setIsOose(String isOose) {
		this.isOose = isOose;
	}
	
	private boolean isOoseTransaction(String transactionId, String entityTyp) throws Exception {
		int count = 0;
		PreparedStatement Stmt = null;
		Connection conn= null;
		PreparedStatement preStmt = null;
		ResultSet rs = null;
		boolean isOoseTransaction = false;
		try {
			conn = APIRequestContext.getApiRequestContext().getConnection();
			Stmt = conn.prepareStatement(" select count(1) from VW_MIS_QUOTE_POLICIES where entity_reference= ? AND entity_type = ? AND oos_number is not null AND oos_total is not null ");
			 
			Stmt.setString(1, transactionId);
			Stmt.setString(2, entityTyp);
				 
			rs = Stmt.executeQuery();
			
			while(rs.next()) {
				count = rs.getInt(1);
				
				if(count > 0){
					isOoseTransaction = true;
				}
				}
		} catch (Exception ex) {
			isOoseTransaction = false;
		}finally  {
	        try  {
	            DBUtil.close(rs, Stmt);    
	        } catch (Exception ex)  {
	            //suppress
	        } 
	    }
		
		return isOoseTransaction;
	}


}
