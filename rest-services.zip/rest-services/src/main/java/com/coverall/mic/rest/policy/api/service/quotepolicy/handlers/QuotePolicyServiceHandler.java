package com.coverall.mic.rest.policy.api.service.quotepolicy.handlers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import org.json.simple.parser.JSONParser;
import org.json.simple.JSONObject;

import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.common.Items;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.quotepolicy.model.APIMicroserviceCallBean;
import com.coverall.mic.rest.policy.api.service.quotepolicy.model.MicroserviceProcessorResponse;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.pct.server.context.IPCTRequestContext;
import com.coverall.pctv2.client.exceptions.ProductServiceException;
import com.coverall.pctv2.client.model.IPCTObjectBundle;
import com.coverall.pctv2.server.cache.APIMappingCache;
import com.coverall.pctv2.server.cache.IPCTAPIMappingCache;
import com.coverall.pctv2.server.cache.IPCTProductCache;
import com.coverall.pctv2.server.cache.ProductCache;
import com.coverall.pctv2.server.rs.service.microservices.ErrorMessage;
import com.coverall.pctv2.server.rs.service.microservices.MicroServiceException;
import com.coverall.pctv2.server.rs.service.microservices.MicroServiceFormat;
import com.coverall.pctv2.server.service.PCTRequestContext;
import com.coverall.pctv2.server.service.PCTRetryRequestException;
import com.coverall.util.DBUtil;

public class QuotePolicyServiceHandler {

	private String productCode;
	private String entityType;
	private IPCTRequestContext pctContext;
	private IAPIContext apiContext;
	public static final String RATE = "rate";
	public static final String SUSPEND = "draft";
	public static final String RETURN_COMPLETE_RESPONSE = "fullModel";
	public static final String QUICK_QUOTE = "quickQuote";
	public static final String OVERRIDE_SS_ID = "updateSSID";
	public static final String PARALLEL_PROCESS = "parallelProcessing";
	public static final String ERROR_MSG_PLACE_HOLDER_TYPE = "errorMessagePlaceHolderType";
	public static String REDO_POLICY_TRANS = "RedoPolicy";
	public static String REDO_QUOTE_TRANS = "RedoQuote";


//--------------------------------------------------------------------------------------------------------------------------------------	
	// Enum for transactions and their respective Redo Transaction names
	public enum  TRANSACTION_NAMES {
		 ENODRSE_POLICY("EndorsePolicy",  "RedoPolicyEndorsement"),
		 CREATE_QUOTE("CreateQuote",  "RedoQuote"),
		 REVISE_QUOTE("ReviseQuote",  "RedoQuote"),
		 CREATE_POLICY("CreatePolicy",  "RedoPolicy"),
		 CONVERT_BINDER("ConvertToBinder",  "RedoPolicy"),
		 RENEW_POLICY("RenewPolicy",  "RedoPolicy"),
		 CONVERT_QUOTE("ConvertQuote",  "RedoPolicy"),
		 INTERIM_AUDIT("InterimAudit",  "RedoInterimAudit"),
		 FINAL_AUDIT("FinalAudit",  "RedoFinalAudit"),
		 QUOTE_FOR_ENDORSEMENT("QuoteForEndorsement",  "RedoQuoteForEndorsement"),
		 CONVERT_QUOTE_FOR_ENDORSEMENT("ConvertQuoteForEndorsement",  "RedoPolicyEndorsement"),
		 CANCEL_POLICY("Cancellation",  "RedoCancellation"),
		 DECLINE_QUOTE("Decline","RedoQuote"),
		 OPEN_QUOTE("OpenQuote",  "RedoQuote");
		 
		 
		 private final String transactionName;
		 private final String redoTransName;
		 private TRANSACTION_NAMES(String transactionName, String redoTransName) {
		        this.transactionName = transactionName;
		        
		        this.redoTransName = redoTransName;
		 }
		 public String getTransactionName(){
			 return transactionName;
		 }
		 public String getRedoTransactionName(){
			 return redoTransName;
		 }
	}

//--------------------------------------------------------------------------------------------------------------------------------------	
	
	public QuotePolicyServiceHandler(String productCode, String entityType, IPCTRequestContext pctContext, IAPIContext apiContext) {
		this.productCode = productCode;
		this.entityType = entityType;
		this.pctContext = pctContext;
		this.apiContext = apiContext;
	}

//--------------------------------------------------------------------------------------------------------------------------------------
    /**
     * Methods to create a Quote/Policy
     * @param requestJson
     * @return
     * @throws Exception
     */
	public Object process(String requestJson) throws Exception {
		// Build Context
		Object response = null;
		String transactionId = null;
		try {
			IPCTProductCache pc = ProductCache.getProductCache();
			IPCTAPIMappingCache apiMappingCache = pc.getAPIMappingCache();
			if(apiMappingCache != null){
				APIMappingCache mappingCache = (APIMappingCache)apiMappingCache;
				if(mappingCache.getApiToPctFieldMapping() == null || mappingCache.getApiToPctFieldMapping().isEmpty()){
					List<Message> errorMessageList = new ArrayList<Message>();
					Message message = new Message();
					message.setMoreinfo("Internal Server Error : This could be because the ProductCache for the product is not generated or the  Micro Services are not enabled for the product");
					errorMessageList.add(message);
					throw new APIException(""+Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), APIConstant.FAILED, errorMessageList, new Throwable());
				}
			}
			IAPIJsonTransformer requestTransformer = APIRequestTransformer.getRequestTransformer(apiMappingCache);
			APIResponseTransformer responseTransformer =   APIResponseTransformer.getResponseTransformer(apiMappingCache);
			requestTransformer.parseJsonStructure(requestJson);
			APIMicroserviceCallBean microServiceBean = requestTransformer.getRootAPIMicroserviceCallBean();
			Map<String, String> transactionConfig = requestTransformer.getTransactionConfig();
			boolean canRate = transactionConfig.containsKey(RATE) ? "Y".equalsIgnoreCase(transactionConfig.get(RATE)) : false;
			boolean completeTransaction = transactionConfig.containsKey(SUSPEND) ? "N".equalsIgnoreCase(transactionConfig.get(SUSPEND)) : true;
			boolean quickQuote = transactionConfig.containsKey(QUICK_QUOTE) ? "Y".equalsIgnoreCase(transactionConfig.get(QUICK_QUOTE)) : false;
			boolean processMultiThreaded = transactionConfig.containsKey(PARALLEL_PROCESS) ? "Y".equalsIgnoreCase(transactionConfig.get(PARALLEL_PROCESS)) : false;
			String errorMessagePlaceHolderType = "GID";
			if(transactionConfig.containsKey(ERROR_MSG_PLACE_HOLDER_TYPE)) {
				errorMessagePlaceHolderType=transactionConfig.get(ERROR_MSG_PLACE_HOLDER_TYPE);
			}
			boolean returnCompleteResponse = transactionConfig.containsKey(RETURN_COMPLETE_RESPONSE) ? "Y".equalsIgnoreCase(transactionConfig
					.get(RETURN_COMPLETE_RESPONSE)) : false;
			String transactionName = entityType == "QUOTE" ? TRANSACTION_NAMES.CREATE_QUOTE.getTransactionName() : TRANSACTION_NAMES.CREATE_POLICY.getTransactionName();
			MicroServiceProcessor msProcessor = new MicroServiceProcessor(productCode, entityType, transactionName, canRate, completeTransaction,
					returnCompleteResponse, false);
			msProcessor.setQuickQuoteMode(quickQuote);
			msProcessor.setMultiThreadedExecution(processMultiThreaded);
			msProcessor.setResponseTransformer(responseTransformer);
			msProcessor.setByRefPCTJsontoAttributeMap(apiMappingCache.getPctJsonPathToByRefFieldsMapping());
			msProcessor.setErrorMessagePlaceHolderType(errorMessagePlaceHolderType);
			MicroserviceProcessorResponse msResponse = msProcessor.process(microServiceBean);
			if(PCTRequestContext.getContext() != null){
				transactionId = PCTRequestContext.getContext().getEntityReference();
			}
			response = prepareResponse(msResponse, transactionId);

		}catch (MicroServiceException e) {
			String errMsg = e.getMessage();
			WebServiceLoggerUtil.logInfo("QuotePolicyAllLinesServiceImpl", "processConvert", errMsg, new Object[] { errMsg });
			List<Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logInfo("QuotePolicyAllLinesServiceImpl", "converQuoteToBinder", errMsg, new Object[] { errMsg });
			if(PCTRequestContext.getContext() != null){
				transactionId = PCTRequestContext.getContext().getEntityReference();
			}
			throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, e, transactionId);
		} catch (APIException e) {
			throw e;
		} catch (Exception e) {
			String errMsg = "Error while intiating the transaction";
			WebServiceLoggerUtil.logError("QuotePolicyAllLinesServiceImpl", "process", errMsg, new Object[] { errMsg }, e);
			List<Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			if(PCTRequestContext.getContext() != null){
				transactionId = PCTRequestContext.getContext().getEntityReference();
			}
			throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, e, transactionId);
		}

		return response;
	}
	
	/**
	 * Methods to update a policy
	 * @param requestJson
	 * @param transactionId
	 * @return
	 * @throws Exception
	 */
	public Object processUpdate(String requestJson, String transactionId) throws Exception {
		// Build Context
		Object response = null;
		try {
			IPCTProductCache pc = ProductCache.getProductCache();
			IPCTAPIMappingCache apiMappingCache = pc.getAPIMappingCache();
			IAPIJsonTransformer requestTransformer = APIRequestTransformer.getRequestTransformer(apiMappingCache);
			APIResponseTransformer responseTransformer =   APIResponseTransformer.getResponseTransformer(apiMappingCache);
			requestTransformer.parseJsonStructure(requestJson);
			APIMicroserviceCallBean microServiceBean = requestTransformer.getRootAPIMicroserviceCallBean();
			Map<String, String> transactionConfig = requestTransformer.getTransactionConfig();
			boolean canRate = transactionConfig.containsKey(RATE) ? "Y".equalsIgnoreCase(transactionConfig.get(RATE)) : false;
			boolean completeTransaction = transactionConfig.containsKey(SUSPEND) ? "N".equalsIgnoreCase(transactionConfig.get(SUSPEND)) : true;
			boolean quickQuote = transactionConfig.containsKey(QUICK_QUOTE) ? "Y".equalsIgnoreCase(transactionConfig.get(QUICK_QUOTE)) : false;
			boolean overrideSsId = transactionConfig.containsKey(OVERRIDE_SS_ID) ? "Y".equalsIgnoreCase(transactionConfig.get(OVERRIDE_SS_ID)) : false;
			String errorMessagePlaceHolderType = "GID";
			if(transactionConfig.containsKey(ERROR_MSG_PLACE_HOLDER_TYPE)) {
				errorMessagePlaceHolderType=transactionConfig.get(ERROR_MSG_PLACE_HOLDER_TYPE);
			}
			boolean returnCompleteResponse = transactionConfig.containsKey(RETURN_COMPLETE_RESPONSE) ? "Y".equalsIgnoreCase(transactionConfig
					.get(RETURN_COMPLETE_RESPONSE)) : false;
			String transactionName = entityType == "QUOTE" ? REDO_QUOTE_TRANS : REDO_POLICY_TRANS;
			String newTransactionName = getRedoTransactionName(transactionId, APIRequestContext.getApiRequestContext().getConnection());
			
			JSONObject jsonObject = (JSONObject) new JSONParser().parse(requestJson);
			String isOose = null;
			try {
				isOose = jsonObject.get("isOose") != null ? jsonObject.get("isOose").toString() : null;
			} catch (Exception exp) {
				// do nothing as this is specifically for logging purpose
			}
			
			MicroServiceProcessor msProcessor = new MicroServiceProcessor(productCode, entityType, newTransactionName,transactionId, canRate, completeTransaction,
					returnCompleteResponse, true);
			msProcessor.setQuickQuoteMode(quickQuote);
			msProcessor.setOverrideSourceSystemId(overrideSsId);
			msProcessor.setResponseTransformer(responseTransformer);
			msProcessor.setByRefPCTJsontoAttributeMap(apiMappingCache.getPctJsonPathToByRefFieldsMapping());
			msProcessor.setErrorMessagePlaceHolderType(errorMessagePlaceHolderType);
			msProcessor.setIsOose(isOose);
			MicroserviceProcessorResponse msResponse = null;
			if(overrideSsId) {
				msResponse = msProcessor.processToUpdateSSID(microServiceBean, transactionId);
			}else {
				msResponse = msProcessor.process(microServiceBean);
			}
			response = prepareResponse(msResponse, transactionId);
			
		} catch (MicroServiceException e) {
			String errMsg = e.getMessage();
			WebServiceLoggerUtil.logInfo("QuotePolicyAllLinesServiceImpl", "processConvert", errMsg, new Object[] { errMsg });
			List<Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logInfo("QuotePolicyAllLinesServiceImpl", "converQuoteToBinder", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, e);
		} catch (APIException e) {
			throw e;
		} catch (Exception e) {
			String errMsg = "Error while intiating the transaction";
			WebServiceLoggerUtil.logError("QuotePolicyAllLinesServiceImpl", "processUpdate", errMsg, new Object[] { errMsg }, e);
			List<Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, e);
		}
		return response;
	}
	
	/**
	 * Method to get the policy in JSON format
	 * @param transactionId
	 * @return
	 * @throws Exception
	 */
	public Object processGet(String transactionId) throws Exception {
		// Build Context
		Object response = null;
		try {
			IPCTProductCache pc = ProductCache.getProductCache();
			IPCTAPIMappingCache apiMappingCache = pc.getAPIMappingCache();
			APIResponseTransformer responseTransformer =   APIResponseTransformer.getResponseTransformer(apiMappingCache);
			MicroServiceProcessor msProcessor = new MicroServiceProcessor(productCode, entityType, null,transactionId, false, false,true, false);
			msProcessor.setResponseTransformer(responseTransformer);
			MicroserviceProcessorResponse msResponse = msProcessor.processGet();
			response = prepareResponse(msResponse, transactionId);
			
		} catch (MicroServiceException e) {
			String errMsg = e.getMessage();
			WebServiceLoggerUtil.logInfo("QuotePolicyAllLinesServiceImpl", "processConvert", errMsg, new Object[] { errMsg });
			List<Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logInfo("QuotePolicyAllLinesServiceImpl", "converQuoteToBinder", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, e);
		} catch (APIException e) {
			throw e;
		} catch (Exception e) {
			String errMsg = "Error while intiating the transaction";
			WebServiceLoggerUtil.logError("QuotePolicyAllLinesServiceImpl", "processGet", errMsg, new Object[] { errMsg }, e);
			List<Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, e);
		}
		return response;
	}

	/**
	 * Method to perform convertToQuote & convertToBinder transaction
	 * @param transactionId
	 * @param convertToBinder
	 * @param rate
	 * @param fullModel
	 * @return
	 * @throws APIException
	 */
	public Object processConvert(String transactionId, boolean convertToBinder , boolean rate, boolean fullModel, String errorMessagePlaceHolderType ) throws APIException {
		Object response = null;
		String transactionName = null;
		if (convertToBinder) {
			transactionName = TRANSACTION_NAMES.CONVERT_BINDER.getTransactionName();
		} else {
			transactionName = TRANSACTION_NAMES.CONVERT_QUOTE.getTransactionName();
		}
		MicroServiceProcessor msProcessor = new MicroServiceProcessor(productCode, entityType, transactionName, transactionId, rate, rate, fullModel, false);
		msProcessor.setErrorMessagePlaceHolderType(errorMessagePlaceHolderType);
		try {
			IPCTProductCache pc = ProductCache.getProductCache();
			IPCTAPIMappingCache apiMappingCache = pc.getAPIMappingCache();
			APIResponseTransformer responseTransformer =   APIResponseTransformer.getResponseTransformer(apiMappingCache);
			msProcessor.setResponseTransformer(responseTransformer);
			MicroserviceProcessorResponse msResponse = msProcessor.initiateMSTransaction();
			if (MicroserviceProcessorResponse.STATUS.FAILURE.equals(msResponse.getStatus())) {
				List<Message> errorMessageList = new ArrayList<Message>();

				Map<String, List<ErrorMessage>> errorMap = msResponse.getErroMessagesMap();
				for (String key : errorMap.keySet()) {
					List<ErrorMessage> errorMessages = errorMap.get(key);
					for (ErrorMessage erm : errorMessages) {
						Message message = new Message();
						if (erm.getJasonPath() != null) {
							message.setMoreinfo(erm.getJasonPath() + ":" + erm.getMessage());
						} else {
							message.setMoreinfo(erm.getMessage());
						}
						errorMessageList.add(message);
					}
				}
				throw new APIException(msResponse.getErrorCode(), APIConstant.FAILED, errorMessageList, new Throwable(), transactionId);
			} else {
				if (msResponse.getResponseJson() != null) {
					response = msResponse.getResponseJson();
				} else {
					Map<String,String> responseMap = new HashMap<String,String>();
					responseMap.put("policyNo", PCTRequestContext.getContext().getEntityReference());
					response = responseMap;
				}
			}
		} catch (MicroServiceException e) {
			String errMsg = e.getMessage();
			WebServiceLoggerUtil.logInfo("QuotePolicyAllLinesServiceImpl", "processConvert", errMsg, new Object[] { errMsg });
			List<Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logInfo("QuotePolicyAllLinesServiceImpl", "converQuoteToBinder", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, errMsg, errorMessageList, e);
		} catch (APIException e) {
			throw e;
		} catch (Exception e) {
			String errMsg = "Error while intiating the transaction";
			WebServiceLoggerUtil.logError("QuotePolicyAllLinesServiceImpl", "processConvert", errMsg, new Object[] { errMsg }, e);
			List<Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, e);
		}
		return response;
	}
	
	
	/**
	 * Method to perform ReviseQuote 
	 * @param transactionId
	 * @param convertToBinder
	 * @param rate
	 * @param fullModel
	 * @return
	 * @throws APIException
	 */
	public Object processRevise(String requestJson, String policyId) throws APIException {
		Object response = null;
		String transactionName = null;
		transactionName = TRANSACTION_NAMES.REVISE_QUOTE.getTransactionName();
		try {
			IPCTProductCache pc = ProductCache.getProductCache();
			IPCTAPIMappingCache apiMappingCache = pc.getAPIMappingCache();
			if(apiMappingCache != null){
				APIMappingCache mappingCache = (APIMappingCache)apiMappingCache;
				if(mappingCache.getApiToPctFieldMapping() == null || mappingCache.getApiToPctFieldMapping().isEmpty()){
					List<Message> errorMessageList = new ArrayList<Message>();
					Message message = new Message();
					message.setMoreinfo("Internal Server Error : This could be because the ProductCache for the product is not generated or the  Micro Services are not enabled for the product");
					errorMessageList.add(message);
					throw new APIException(""+Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), APIConstant.FAILED, errorMessageList, new Throwable());
				}
			}
			IAPIJsonTransformer requestTransformer = APIRequestTransformer.getRequestTransformer(apiMappingCache);
			APIResponseTransformer responseTransformer =   APIResponseTransformer.getResponseTransformer(apiMappingCache);
			requestTransformer.parseJsonStructure(requestJson);
			APIMicroserviceCallBean microServiceBean = requestTransformer.getRootAPIMicroserviceCallBean();
			Map<String, String> transactionConfig = requestTransformer.getTransactionConfig();
			boolean canRate = transactionConfig.containsKey(RATE) ? "Y".equalsIgnoreCase(transactionConfig.get(RATE)) : false;
			boolean completeTransaction = transactionConfig.containsKey(SUSPEND) ? "N".equalsIgnoreCase(transactionConfig.get(SUSPEND)) : true;
			boolean quickQuote = transactionConfig.containsKey(QUICK_QUOTE) ? "Y".equalsIgnoreCase(transactionConfig.get(QUICK_QUOTE)) : false;
			boolean returnCompleteResponse = transactionConfig.containsKey(RETURN_COMPLETE_RESPONSE) ? "Y".equalsIgnoreCase(transactionConfig
					.get(RETURN_COMPLETE_RESPONSE)) : false;
			String errorMessagePlaceHolderType = "GID";
			if(transactionConfig.containsKey(ERROR_MSG_PLACE_HOLDER_TYPE)) {
				errorMessagePlaceHolderType=transactionConfig.get(ERROR_MSG_PLACE_HOLDER_TYPE);
			}
			MicroServiceProcessor msProcessor = new MicroServiceProcessor(productCode, entityType, transactionName,policyId, canRate, completeTransaction,
					returnCompleteResponse, true);
			msProcessor.setResponseTransformer(responseTransformer);
			msProcessor.setByRefPCTJsontoAttributeMap(apiMappingCache.getPctJsonPathToByRefFieldsMapping());
			msProcessor.setQuickQuoteMode(quickQuote);
			msProcessor.setErrorMessagePlaceHolderType(errorMessagePlaceHolderType);
			MicroserviceProcessorResponse msResponse = msProcessor.process(microServiceBean);
			String transactionId = null;
			if(PCTRequestContext.getContext() != null){
				transactionId = PCTRequestContext.getContext().getEntityReference();
			}
			response = prepareResponse(msResponse, transactionId);
		} catch (MicroServiceException e) {
			String errMsg = e.getMessage();
			WebServiceLoggerUtil.logInfo("QuotePolicyAllLinesServiceImpl", "revise", errMsg, new Object[] { errMsg });
			List<Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logInfo("QuotePolicyAllLinesServiceImpl", "revise", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, e);
		} catch (APIException e) {
			throw e;
		} catch (Exception e) {
		    String errMsg = "Error while intiating the transaction";
			WebServiceLoggerUtil.logError("QuotePolicyAllLinesServiceImpl", "revise", errMsg, new Object[] { errMsg },e);
			List<Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, e);
		}
		return response;
	}
	
	/**
	 * Method to perform the endorsement transaction
	 * @param requestJson
	 * @param policyId
	 * @return
	 * @throws Exception
	 */
	public Object processEndorse(String requestJson, String policyId) throws Exception{
		Object response = null;
		try {
			IPCTProductCache pc = ProductCache.getProductCache();
			IPCTAPIMappingCache apiMappingCache = pc.getAPIMappingCache();
			if(apiMappingCache != null){
				APIMappingCache mappingCache = (APIMappingCache)apiMappingCache;
				if(mappingCache.getApiToPctFieldMapping() == null || mappingCache.getApiToPctFieldMapping().isEmpty()){
					List<Message> errorMessageList = new ArrayList<Message>();
					Message message = new Message();
					message.setMoreinfo("Internal Server Error : This could be because the ProductCache for the product is not generated or the  Micro Services are not enabled for the product");
					errorMessageList.add(message);
					throw new APIException(""+Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), APIConstant.FAILED, errorMessageList, new Throwable());
				}
			}
			IAPIJsonTransformer requestTransformer = APIRequestTransformer.getRequestTransformer(apiMappingCache);
			APIResponseTransformer responseTransformer =   APIResponseTransformer.getResponseTransformer(apiMappingCache);
			requestTransformer.parseJsonStructure(requestJson);
			APIMicroserviceCallBean microServiceBean = requestTransformer.getRootAPIMicroserviceCallBean();
			Map<String, String> transactionConfig = requestTransformer.getTransactionConfig();
			boolean canRate = transactionConfig.containsKey(RATE) ? "Y".equalsIgnoreCase(transactionConfig.get(RATE)) : false;
			boolean completeTransaction = transactionConfig.containsKey(SUSPEND) ? "N".equalsIgnoreCase(transactionConfig.get(SUSPEND)) : true;
			boolean returnCompleteResponse = transactionConfig.containsKey(RETURN_COMPLETE_RESPONSE) ? "Y".equalsIgnoreCase(transactionConfig
					.get(RETURN_COMPLETE_RESPONSE)) : false;
			String errorMessagePlaceHolderType = "GID";
			if(transactionConfig.containsKey(ERROR_MSG_PLACE_HOLDER_TYPE)) {
				errorMessagePlaceHolderType=transactionConfig.get(ERROR_MSG_PLACE_HOLDER_TYPE);
			}
			String transactionName =  TRANSACTION_NAMES.ENODRSE_POLICY.getTransactionName();
			MicroServiceProcessor msProcessor = new MicroServiceProcessor(productCode, entityType, transactionName,policyId, canRate, completeTransaction,
					returnCompleteResponse, true);
			msProcessor.setByRefPCTJsontoAttributeMap(apiMappingCache.getPctJsonPathToByRefFieldsMapping());
			msProcessor.setResponseTransformer(responseTransformer);
			msProcessor.setErrorMessagePlaceHolderType(errorMessagePlaceHolderType);
			MicroserviceProcessorResponse msResponse = msProcessor.process(microServiceBean);
			
			
			String transactionId = null;
			if(PCTRequestContext.getContext() != null){
				transactionId = PCTRequestContext.getContext().getEntityReference();
			}
			response = prepareResponse(msResponse, transactionId);
		} catch (MicroServiceException e) {
			String errMsg = e.getMessage();
			WebServiceLoggerUtil.logInfo("QuotePolicyAllLinesServiceImpl", "processConvert", errMsg, new Object[] { errMsg });
			List<Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logInfo("QuotePolicyAllLinesServiceImpl", "converQuoteToBinder", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, e);
		} catch (APIException e) {
			throw e;
		} catch (Exception e) {
		    String errMsg = "Error while intiating the transaction";
			WebServiceLoggerUtil.logError("QuotePolicyAllLinesServiceImpl", "processEndorse", errMsg, new Object[] { errMsg },e);
			List<Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, e);
		}
		return response;
	}	
	
	/**
	 * Method to perform the interim audit transaction
	 * @param requestJson
	 * @param policyId
	 * @return
	 * @throws Exception
	 */
	public Object processInterimAudit(String requestJson, String policyId) throws Exception{
		Object response = null;
		try {
			IPCTProductCache pc = ProductCache.getProductCache();
			IPCTAPIMappingCache apiMappingCache = pc.getAPIMappingCache();
			if(apiMappingCache != null){
				APIMappingCache mappingCache = (APIMappingCache)apiMappingCache;
				if(mappingCache.getApiToPctFieldMapping() == null || mappingCache.getApiToPctFieldMapping().isEmpty()){
					List<Message> errorMessageList = new ArrayList<Message>();
					Message message = new Message();
					message.setMoreinfo("Internal Server Error : This could be because the ProductCache for the product is not generated or the  Micro Services are not enabled for the product");
					errorMessageList.add(message);
					throw new APIException(""+Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), APIConstant.FAILED, errorMessageList, new Throwable());
				}
			}
			IAPIJsonTransformer requestTransformer = APIRequestTransformer.getRequestTransformer(apiMappingCache);
			APIResponseTransformer responseTransformer =   APIResponseTransformer.getResponseTransformer(apiMappingCache);
			requestTransformer.parseJsonStructure(requestJson);
			APIMicroserviceCallBean microServiceBean = requestTransformer.getRootAPIMicroserviceCallBean();
			Map<String, String> transactionConfig = requestTransformer.getTransactionConfig();
			boolean canRate = transactionConfig.containsKey(RATE) ? "Y".equalsIgnoreCase(transactionConfig.get(RATE)) : false;
			boolean completeTransaction = transactionConfig.containsKey(SUSPEND) ? "N".equalsIgnoreCase(transactionConfig.get(SUSPEND)) : true;
			boolean returnCompleteResponse = transactionConfig.containsKey(RETURN_COMPLETE_RESPONSE) ? "Y".equalsIgnoreCase(transactionConfig
					.get(RETURN_COMPLETE_RESPONSE)) : false;
			String errorMessagePlaceHolderType = "GID";
			if(transactionConfig.containsKey(ERROR_MSG_PLACE_HOLDER_TYPE)) {
				errorMessagePlaceHolderType=transactionConfig.get(ERROR_MSG_PLACE_HOLDER_TYPE);
			}
			String transactionName =  TRANSACTION_NAMES.INTERIM_AUDIT.getTransactionName();
			MicroServiceProcessor msProcessor = new MicroServiceProcessor(productCode, entityType, transactionName,policyId, canRate, completeTransaction,
					returnCompleteResponse, true);
			msProcessor.setByRefPCTJsontoAttributeMap(apiMappingCache.getPctJsonPathToByRefFieldsMapping());
			msProcessor.setResponseTransformer(responseTransformer);
			msProcessor.setErrorMessagePlaceHolderType(errorMessagePlaceHolderType);
			MicroserviceProcessorResponse msResponse = msProcessor.process(microServiceBean);
			String transactionId = null;
			if(PCTRequestContext.getContext() != null){
				transactionId = PCTRequestContext.getContext().getEntityReference();
			}
			response = prepareResponse(msResponse, transactionId);
		} catch (MicroServiceException e) {
			String errMsg = e.getMessage();
			WebServiceLoggerUtil.logInfo("QuotePolicyAllLinesServiceImpl", "processConvert", errMsg, new Object[] { errMsg });
			List<Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logInfo("QuotePolicyAllLinesServiceImpl", "converQuoteToBinder", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, e);
		} catch (APIException e) {
			throw e;
		} catch (Exception e) {
		    String errMsg = "Error while intiating the transaction";
			WebServiceLoggerUtil.logError("QuotePolicyAllLinesServiceImpl", "processEndorse", errMsg, new Object[] { errMsg },e);
			List<Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, e);
		}
		return response;
	}	
	/**
	 * Method to perform the final audit transaction
	 * @param requestJson
	 * @param policyId
	 * @return
	 * @throws Exception
	 */
	public Object processFinalAudit(String requestJson, String policyId) throws Exception{
		Object response = null;
		try {
			IPCTProductCache pc = ProductCache.getProductCache();
			IPCTAPIMappingCache apiMappingCache = pc.getAPIMappingCache();
			if(apiMappingCache != null){
				APIMappingCache mappingCache = (APIMappingCache)apiMappingCache;
				if(mappingCache.getApiToPctFieldMapping() == null || mappingCache.getApiToPctFieldMapping().isEmpty()){
					List<Message> errorMessageList = new ArrayList<Message>();
					Message message = new Message();
					message.setMoreinfo("Internal Server Error : This could be because the ProductCache for the product is not generated or the  Micro Services are not enabled for the product");
					errorMessageList.add(message);
					throw new APIException(""+Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), APIConstant.FAILED, errorMessageList, new Throwable());
				}
			}
			IAPIJsonTransformer requestTransformer = APIRequestTransformer.getRequestTransformer(apiMappingCache);
			APIResponseTransformer responseTransformer =   APIResponseTransformer.getResponseTransformer(apiMappingCache);
			requestTransformer.parseJsonStructure(requestJson);
			APIMicroserviceCallBean microServiceBean = requestTransformer.getRootAPIMicroserviceCallBean();
			Map<String, String> transactionConfig = requestTransformer.getTransactionConfig();
			boolean canRate = transactionConfig.containsKey(RATE) ? "Y".equalsIgnoreCase(transactionConfig.get(RATE)) : false;
			boolean completeTransaction = transactionConfig.containsKey(SUSPEND) ? "N".equalsIgnoreCase(transactionConfig.get(SUSPEND)) : true;
			boolean returnCompleteResponse = transactionConfig.containsKey(RETURN_COMPLETE_RESPONSE) ? "Y".equalsIgnoreCase(transactionConfig
					.get(RETURN_COMPLETE_RESPONSE)) : false;
			String errorMessagePlaceHolderType = "GID";
			if(transactionConfig.containsKey(ERROR_MSG_PLACE_HOLDER_TYPE)) {
				errorMessagePlaceHolderType=transactionConfig.get(ERROR_MSG_PLACE_HOLDER_TYPE);
			}
			String transactionName =  TRANSACTION_NAMES.FINAL_AUDIT.getTransactionName();
			MicroServiceProcessor msProcessor = new MicroServiceProcessor(productCode, entityType, transactionName,policyId, canRate, completeTransaction,
					returnCompleteResponse, true);
			msProcessor.setByRefPCTJsontoAttributeMap(apiMappingCache.getPctJsonPathToByRefFieldsMapping());
			msProcessor.setResponseTransformer(responseTransformer);
			msProcessor.setErrorMessagePlaceHolderType(errorMessagePlaceHolderType);
			MicroserviceProcessorResponse msResponse = msProcessor.process(microServiceBean);
			String transactionId = null;
			if(PCTRequestContext.getContext() != null){
				transactionId = PCTRequestContext.getContext().getEntityReference();
			}
			response = prepareResponse(msResponse, transactionId);
		} catch (MicroServiceException e) {
			String errMsg = e.getMessage();
			WebServiceLoggerUtil.logInfo("QuotePolicyAllLinesServiceImpl", "processConvert", errMsg, new Object[] { errMsg });
			List<Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logInfo("QuotePolicyAllLinesServiceImpl", "converQuoteToBinder", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, e);
		} catch (APIException e) {
			throw e;
		} catch (Exception e) {
		    String errMsg = "Error while intiating the transaction";
			WebServiceLoggerUtil.logError("QuotePolicyAllLinesServiceImpl", "processEndorse", errMsg, new Object[] { errMsg },e);
			List<Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, e);
		}
		return response;
	}
	
	/**
	 * The is generic method to prepare response for all the api's where response is common
	 * @param msResponse
	 * @param transactionId
	 * @return
	 */
	private Object prepareResponse( MicroserviceProcessorResponse msResponse, String transactionId){
		Object response = null;
		if (MicroserviceProcessorResponse.STATUS.FAILURE.equals(msResponse.getStatus())) {
			List<Message> errorMessageList = new ArrayList<Message>();

			Map<String, List<ErrorMessage>> errorMap = msResponse.getErroMessagesMap();
			for (String key : errorMap.keySet()) {
				List<ErrorMessage> errorMessages = errorMap.get(key);
				for (ErrorMessage erm : errorMessages) {
					Message message = new Message();
					Map<String,String> additionalMap=erm.getAdditionalInformation()!=null?erm.getAdditionalInformation():new HashMap<String, String>();
					additionalMap.put(APIConstant.JSON_PATH,erm.getJasonPath());
					additionalMap.put(APIConstant.MESSAGE_TYPE,erm.getMessageType());
					message.setAdditionalInformation(additionalMap);
					if (erm.getJasonPath() != null) {
						message.setMoreinfo(erm.getJasonPath() + ":" + erm.getMessage());
					} else {
						message.setMoreinfo(erm.getMessage());
					}
					errorMessageList.add(message);
				}
			}
			throw new APIException(msResponse.getErrorCode(), APIConstant.FAILED, errorMessageList, new Throwable(), transactionId);
		} else {
			if (msResponse.getResponseJson() != null) {
				response = msResponse.getResponseJson();
			} else {
				try {
					String entityType=transactionId.startsWith("Q")?"QUOTE":"POLICY";
					response=(new JSONParser()).parse("{\"quotePolicy\":{\"EntityReference\":\""+transactionId+"\",\"EntityType\":\""+entityType+"\"}}");
				}catch(Exception exp) {
					Message message = new Message();
					Items item = new Items();
					item.setSystemerrcode("Successful");
					message.setItem(item);
					if(transactionId != null && transactionId.startsWith("Q")){
						message.setMoreinfo("Successfully processed the request. Quote number:"+transactionId);
					}else{
						message.setMoreinfo("Successfully processed the request. Policy number:"+transactionId);
					}
					response = message;
				}
			}
		}
		return response;
	}
	
	/**
	 * This method will return the transaction name for performing the redo operation.
	 * Will be used by update policy request to identify the correct transaction which needs to be performed
	 * * 
	 * @param transactionId
	 * @param conn
	 * @return
	 */
	private String getRedoTransactionName(String transactionId, Connection conn){
		String redoTransactionName= null;
		String transactionName = null;
		PreparedStatement psTrnsactionName = null;
		ResultSet rsTransName = null;
		String transactionNameQuery = " SELECT str_transaction_name  FROM shl_transaction_params , shl_transactions "
				+ " WHERE stp_transaction_id = str_transaction_id " + " AND stp_param_name = 'action' " + " AND STP_PARAM_VALUE IN ( "
				+ " SELECT TRANSACTION_ACTION FROM vw_mis_quote_policies WHERE entity_reference = ?  ) "
				+ " AND str_use = 'Y' " + " AND rownum = 1 ";
		try {
			psTrnsactionName = conn.prepareStatement(transactionNameQuery);
			psTrnsactionName.setString(1,transactionId);
			rsTransName = psTrnsactionName.executeQuery();
			if(rsTransName.next()){
				transactionName = rsTransName.getString("str_transaction_name");
			}
		} catch (Exception e) {
			WebServiceLoggerUtil.logInfo("QuotePolicyServiceHandler", "getRedoTransactionName", e.getLocalizedMessage(), new Object[] { transactionId });
		} finally {
			try {
				DBUtil.close(rsTransName, psTrnsactionName);
			} catch (Exception exp) {
				WebServiceLoggerUtil.logInfo("QuotePolicyServiceHandler", "getRedoTransactionName", exp.getLocalizedMessage(),
						new Object[] { "Error while closing preparedstatement and resultset" });
			}

		}
		if(transactionName != null){
			redoTransactionName = transactionName;
			TRANSACTION_NAMES [] transactions = TRANSACTION_NAMES.values();
			for(TRANSACTION_NAMES trans : transactions){
				if(transactionName.equalsIgnoreCase(trans.getTransactionName())){
					redoTransactionName = trans.getRedoTransactionName();
					break;
				}
			}
		}else{
			WebServiceLoggerUtil.logError("getRedoTransactionName", " Transaction name not found ", new Object[] { transactionId, transactionNameQuery }, new Exception());
		}
		return redoTransactionName;
	}
	
	/**
	 * Method to perform the QuoteForEndorsement transaction
	 * @param requestJson
	 * @param policyId
	 * @return
	 * @throws Exception
	 */
	public Object processQuoteForEndorsement(String requestJson, String policyId) throws Exception{
		Object response = null;
		try {
			IPCTProductCache pc = ProductCache.getProductCache();
			IPCTAPIMappingCache apiMappingCache = pc.getAPIMappingCache();
			if(apiMappingCache != null){
				APIMappingCache mappingCache = (APIMappingCache)apiMappingCache;
				if(mappingCache.getApiToPctFieldMapping() == null || mappingCache.getApiToPctFieldMapping().isEmpty()){
					List<Message> errorMessageList = new ArrayList<Message>();
					Message message = new Message();
					message.setMoreinfo("Internal Server Error : This could be because the ProductCache for the product is not generated or the  Micro Services are not enabled for the product");
					errorMessageList.add(message);
					throw new APIException(""+Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), APIConstant.FAILED, errorMessageList, new Throwable());
				}
			}
			IAPIJsonTransformer requestTransformer = APIRequestTransformer.getRequestTransformer(apiMappingCache);
			APIResponseTransformer responseTransformer =   APIResponseTransformer.getResponseTransformer(apiMappingCache);
			requestTransformer.parseJsonStructure(requestJson);
			APIMicroserviceCallBean microServiceBean = requestTransformer.getRootAPIMicroserviceCallBean();
			Map<String, String> transactionConfig = requestTransformer.getTransactionConfig();
			boolean canRate = transactionConfig.containsKey(RATE) ? "Y".equalsIgnoreCase(transactionConfig.get(RATE)) : false;
			boolean completeTransaction = transactionConfig.containsKey(SUSPEND) ? "N".equalsIgnoreCase(transactionConfig.get(SUSPEND)) : true;
			boolean returnCompleteResponse = transactionConfig.containsKey(RETURN_COMPLETE_RESPONSE) ? "Y".equalsIgnoreCase(transactionConfig
					.get(RETURN_COMPLETE_RESPONSE)) : false;
			String transactionName =  TRANSACTION_NAMES.QUOTE_FOR_ENDORSEMENT.getTransactionName();
			MicroServiceProcessor msProcessor = new MicroServiceProcessor(productCode, entityType, transactionName,policyId, canRate, completeTransaction,
					returnCompleteResponse, true);
			msProcessor.setByRefPCTJsontoAttributeMap(apiMappingCache.getPctJsonPathToByRefFieldsMapping());
			msProcessor.setResponseTransformer(responseTransformer);
			MicroserviceProcessorResponse msResponse = msProcessor.process(microServiceBean);
			String transactionId = null;
			if(PCTRequestContext.getContext() != null){
				transactionId = PCTRequestContext.getContext().getEntityReference();
			}
			response = prepareResponse(msResponse, transactionId);
		} catch (MicroServiceException e) {
			String errMsg = e.getMessage();
			WebServiceLoggerUtil.logInfo("QuotePolicyServiceHandler ", "processConvert", errMsg, new Object[] { errMsg });
			List<Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logInfo("QuotePolicyServiceHandler ", "converQuoteToBinder", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, e);
		} catch (APIException e) {
			throw e;
		} catch (Exception e) {
		    String errMsg = "Error while intiating the transaction";
			WebServiceLoggerUtil.logError("QuotePolicyServiceHandler ", "processEndorse", errMsg, new Object[] { errMsg },e);
			List<Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, e);
		}
		return response;
	}
	
	/**
	 * Method to perform convertToQuote, convertToBinder and convert Quote for Endorsement transaction
	 * @param transactionId
	 * @param convertToBinder
	 * @param rate
	 * @param fullModel
	 * @return
	 * @throws APIException
	 */
	public Object processConvertEndorsement(String transactionId, String transactionName , boolean rate, boolean fullModel) throws APIException {
		Object response = null;
		WebServiceLoggerUtil.logError("QuotePolicyServiceHandler ", "processConvertEndorsement ", " transactionName "+transactionName, new Object[] { transactionId,transactionName }, null);
		
				
		MicroServiceProcessor msProcessor = new MicroServiceProcessor(productCode, entityType, transactionName, transactionId, rate, rate, fullModel, false);
		try {
			
			IPCTProductCache pc = ProductCache.getProductCache();
			IPCTAPIMappingCache apiMappingCache = pc.getAPIMappingCache();
			APIResponseTransformer responseTransformer =   APIResponseTransformer.getResponseTransformer(apiMappingCache);
			msProcessor.setResponseTransformer(responseTransformer);
			MicroserviceProcessorResponse msResponse = msProcessor.initiateMSTransaction();
			if (MicroserviceProcessorResponse.STATUS.FAILURE.equals(msResponse.getStatus())) {
				List<Message> errorMessageList = new ArrayList<Message>();

				Map<String, List<ErrorMessage>> errorMap = msResponse.getErroMessagesMap();
				for (String key : errorMap.keySet()) {
					List<ErrorMessage> errorMessages = errorMap.get(key);
					for (ErrorMessage erm : errorMessages) {
						Message message = new Message();
						if (erm.getJasonPath() != null) {
							message.setMoreinfo(erm.getJasonPath() + ":" + erm.getMessage());
						} else {
							message.setMoreinfo(erm.getMessage());
						}
						errorMessageList.add(message);
					}
				}
				throw new APIException(msResponse.getErrorCode(), APIConstant.FAILED, errorMessageList, new Throwable(), transactionId);
			} else {
				if (msResponse.getResponseJson() != null) {
					response = msResponse.getResponseJson();
				} else {
					Map<String,String> responseMap = new HashMap<String,String>();
					responseMap.put("policyNo", PCTRequestContext.getContext().getEntityReference());
					response = responseMap;
				}
			}
		} catch (MicroServiceException e) {
			String errMsg = e.getMessage();
			WebServiceLoggerUtil.logError("QuotePolicyServiceHandler ", "processConvertEndorsement", errMsg, new Object[] { errMsg },e);
			List<Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError("QuotePolicyServiceHandler", "processConvertEndorsement", errMsg, new Object[] { errMsg },e);
			throw new APIException(httpStatusCode, errMsg, errorMessageList, e);
		} catch (APIException e) {
			WebServiceLoggerUtil.logError("QuotePolicyServiceHandler", "processConvertEndorsement", "", new Object[] {  },e);
			throw e;
		} catch (Exception e) {
			String errMsg = "Error while intiating the transaction";
			WebServiceLoggerUtil.logError("QuotePolicyServiceHandler ", "processConvertEndorsement ", errMsg, new Object[] { errMsg }, e);
			List<Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, e);
		}
		return response;
	}
	
	
	/**
	 * Method to perform the QuoteForEndorsement transaction
	 * @param requestJson
	 * @param policyId
	 * @return
	 * @throws Exception
	 */
	public Object processCancel(String requestJson, String policyId) throws Exception{
		Object response = null;
		WebServiceLoggerUtil.logError("QuotePolicyServiceHandler ", "processCancel ", " requestJson "+requestJson, new Object[] { "policyId "+policyId }, null);
		try {
			IPCTProductCache pc = ProductCache.getProductCache();
			IPCTAPIMappingCache apiMappingCache = pc.getAPIMappingCache();
			if(apiMappingCache != null){
				APIMappingCache mappingCache = (APIMappingCache)apiMappingCache;
				if(mappingCache.getApiToPctFieldMapping() == null || mappingCache.getApiToPctFieldMapping().isEmpty()){
					List<Message> errorMessageList = new ArrayList<Message>();
					Message message = new Message();
					message.setMoreinfo("Internal Server Error : This could be because the ProductCache for the product is not generated or the  Micro Services are not enabled for the product");
					errorMessageList.add(message);
					throw new APIException(""+Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), APIConstant.FAILED, errorMessageList, new Throwable());
				}
			}
			IAPIJsonTransformer requestTransformer = APIRequestTransformer.getRequestTransformer(apiMappingCache);
			APIResponseTransformer responseTransformer =   APIResponseTransformer.getResponseTransformer(apiMappingCache);
			requestTransformer.parseJsonStructure(requestJson);
			APIMicroserviceCallBean microServiceBean = requestTransformer.getRootAPIMicroserviceCallBean();
			Map<String, String> transactionConfig = requestTransformer.getTransactionConfig();
			boolean canRate = transactionConfig.containsKey(RATE) ? "Y".equalsIgnoreCase(transactionConfig.get(RATE)) : false;
			boolean completeTransaction = transactionConfig.containsKey(SUSPEND) ? "N".equalsIgnoreCase(transactionConfig.get(SUSPEND)) : true;
			boolean returnCompleteResponse = transactionConfig.containsKey(RETURN_COMPLETE_RESPONSE) ? "Y".equalsIgnoreCase(transactionConfig
					.get(RETURN_COMPLETE_RESPONSE)) : false;
			String transactionName =  TRANSACTION_NAMES.CANCEL_POLICY.getTransactionName();
			MicroServiceProcessor msProcessor = new MicroServiceProcessor(productCode, entityType, transactionName,policyId, canRate, completeTransaction,
					returnCompleteResponse, true);
			msProcessor.setByRefPCTJsontoAttributeMap(apiMappingCache.getPctJsonPathToByRefFieldsMapping());
			msProcessor.setResponseTransformer(responseTransformer);
			MicroserviceProcessorResponse msResponse = msProcessor.process(microServiceBean);
			String transactionId = null;
			if(PCTRequestContext.getContext() != null){
				transactionId = PCTRequestContext.getContext().getEntityReference();
			}
			response = prepareResponse(msResponse, transactionId);
		} catch (MicroServiceException e) {
			String errMsg = e.getMessage();
			WebServiceLoggerUtil.logError("QuotePolicyServiceHandler ", "processCancel", errMsg, new Object[] { errMsg },e);
			List<Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError("QuotePolicyAllLinesServiceImpl", "processCancel", errMsg, new Object[] { errMsg },e);
			throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, e);
		} catch (APIException e) {
			WebServiceLoggerUtil.logError("QuotePolicyAllLinesServiceImpl", "processCancel", "", new Object[] { },e);
			throw e;
		} catch (Exception e) {
		    String errMsg = "Error while intiating the transaction";
			WebServiceLoggerUtil.logError("QuotePolicyServiceHandler ", "processCancel", errMsg, new Object[] { errMsg },e);
			List<Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, e);
		}
		return response;
	}
	
	/**
	 * Method to perform delcineQuote transaction
	 * @param transactionId
	 * @param json 
	 * @return
	 * @throws APIException
	 */
	public Object processDecline(String policyId, String requestJson ) throws APIException {
		Object response = null;
		try {
			IPCTProductCache pc = ProductCache.getProductCache();
			IPCTAPIMappingCache apiMappingCache = pc.getAPIMappingCache();
			if(apiMappingCache != null){
				APIMappingCache mappingCache = (APIMappingCache)apiMappingCache;
				if(mappingCache.getApiToPctFieldMapping() == null || mappingCache.getApiToPctFieldMapping().isEmpty()){
					List<Message> errorMessageList = new ArrayList<Message>();
					Message message = new Message();
					message.setMoreinfo("Internal Server Error : This could be because the ProductCache for the product is not generated or the  Micro Services are not enabled for the product");
					errorMessageList.add(message);
					throw new APIException(""+Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), APIConstant.FAILED, errorMessageList, new Throwable());
				}
			}
			IAPIJsonTransformer requestTransformer = APIRequestTransformer.getRequestTransformer(apiMappingCache);
			APIResponseTransformer responseTransformer =   APIResponseTransformer.getResponseTransformer(apiMappingCache);
			requestTransformer.parseJsonStructure(requestJson);
			APIMicroserviceCallBean microServiceBean = requestTransformer.getRootAPIMicroserviceCallBean();
			Map<String, String> transactionConfig = requestTransformer.getTransactionConfig();
			boolean declineTransaction = true;
			boolean returnCompleteResponse = transactionConfig.containsKey(RETURN_COMPLETE_RESPONSE) ? "Y".equalsIgnoreCase(transactionConfig
					.get(RETURN_COMPLETE_RESPONSE)) : false;
			String errorMessagePlaceHolderType = "GID";
			if(transactionConfig.containsKey(ERROR_MSG_PLACE_HOLDER_TYPE)) {
				errorMessagePlaceHolderType=transactionConfig.get(ERROR_MSG_PLACE_HOLDER_TYPE);
			}
			String transactionName =  TRANSACTION_NAMES.DECLINE_QUOTE.getTransactionName();
			MicroServiceProcessor msProcessor = new MicroServiceProcessor(productCode, entityType, transactionName,policyId, declineTransaction,
					returnCompleteResponse, true);
			msProcessor.setByRefPCTJsontoAttributeMap(apiMappingCache.getPctJsonPathToByRefFieldsMapping());
			msProcessor.setResponseTransformer(responseTransformer);
			msProcessor.setErrorMessagePlaceHolderType(errorMessagePlaceHolderType);
			MicroserviceProcessorResponse msResponse = msProcessor.process(microServiceBean);
			String transactionId = null;
			if(PCTRequestContext.getContext() != null){
				transactionId = PCTRequestContext.getContext().getEntityReference();
			}
			response = prepareResponse(msResponse, transactionId);
		} catch (MicroServiceException e) {
			String errMsg = e.getMessage();
			WebServiceLoggerUtil.logInfo("QuotePolicyAllLinesServiceImpl", "processDecline", errMsg, new Object[] { errMsg });
			List<Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logInfo("QuotePolicyAllLinesServiceImpl", "processDecline", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, e);
		} catch (APIException e) {
			throw e;
		} catch (Exception e) {
		    String errMsg = "Error while intiating the transaction";
			WebServiceLoggerUtil.logError("QuotePolicyAllLinesServiceImpl", "processDecline", errMsg, new Object[] { errMsg },e);
			List<Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, e);
		}
		return response;
	}
	
	/**
	 * Method to perform OpenQuote transaction
	 * @param transactionId
	 * @param processOpenQuote
	 * @param rate
	 * @param fullModel
	 * @return
	 * @throws APIException
	 */
	public Object processOpenQuote(String transactionId, boolean completeTransaction , boolean rate, boolean fullModel, String errorMessagePlaceHolderType ) throws APIException {
		Object response = null;
		MicroServiceProcessor msProcessor = new MicroServiceProcessor(productCode, entityType, TRANSACTION_NAMES.OPEN_QUOTE.getTransactionName(), transactionId, rate, completeTransaction, fullModel, false);
		msProcessor.setErrorMessagePlaceHolderType(errorMessagePlaceHolderType);
		try {
			IPCTProductCache pc = ProductCache.getProductCache();
			IPCTAPIMappingCache apiMappingCache = pc.getAPIMappingCache();
			APIResponseTransformer responseTransformer =   APIResponseTransformer.getResponseTransformer(apiMappingCache);
			msProcessor.setResponseTransformer(responseTransformer);
			MicroserviceProcessorResponse msResponse = msProcessor.initiateMSTransaction();
			if (MicroserviceProcessorResponse.STATUS.FAILURE.equals(msResponse.getStatus())) {
				List<Message> errorMessageList = new ArrayList<Message>();

				Map<String, List<ErrorMessage>> errorMap = msResponse.getErroMessagesMap();
				for (String key : errorMap.keySet()) {
					List<ErrorMessage> errorMessages = errorMap.get(key);
					for (ErrorMessage erm : errorMessages) {
						Message message = new Message();
						if (erm.getJasonPath() != null) {
							message.setMoreinfo(erm.getJasonPath() + ":" + erm.getMessage());
						} else {
							message.setMoreinfo(erm.getMessage());
						}
						errorMessageList.add(message);
					}
				}
				throw new APIException(msResponse.getErrorCode(), APIConstant.FAILED, errorMessageList, new Throwable(), transactionId);
			} else {
				if (msResponse.getResponseJson() != null) {
					response = msResponse.getResponseJson();
				} else {
					Map<String,String> responseMap = new HashMap<String,String>();
					responseMap.put("policyNo", PCTRequestContext.getContext().getEntityReference());
					response = responseMap;
				}
			}
		} catch (MicroServiceException e) {
			String errMsg = e.getMessage();
			WebServiceLoggerUtil.logInfo("QuotePolicyAllLinesServiceImpl", "processOpenQuote", errMsg, new Object[] { errMsg });
			List<Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logInfo("QuotePolicyAllLinesServiceImpl", "processOpenQuote", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, errMsg, errorMessageList, e);
		} catch (APIException e) {
			throw e;
		} catch (Exception e) {
			String errMsg = "Error while intiating the transaction";
			WebServiceLoggerUtil.logError("QuotePolicyAllLinesServiceImpl", "processOpenQuote", errMsg, new Object[] { errMsg }, e);
			List<Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, e);
		}
		return response;
	}

}
