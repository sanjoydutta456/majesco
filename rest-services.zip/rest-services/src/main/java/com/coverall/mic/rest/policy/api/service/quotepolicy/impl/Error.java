package com.coverall.mic.rest.policy.api.service.quotepolicy.impl;

import java.util.List;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import com.coverall.mic.rest.policy.api.service.model.common.Message;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class Error {

	private String statuscode;
	private String status;
	private List <Message> message ;
	private String id;
	private String moreinfo;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getStatuscode() {
		return statuscode;
	}
	public void setStatuscode(String statuscode) {
		this.statuscode = statuscode;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public List<Message> getMessage() {
		return message;
	}
	public void setMessage(List<Message> message) {
		this.message = message;
	}
	public String getMoreinfo() {
		return moreinfo;
	}
	public void setMoreinfo(String moreinfo) {
		this.moreinfo = moreinfo;
	} 
	
	 
	
	
}
