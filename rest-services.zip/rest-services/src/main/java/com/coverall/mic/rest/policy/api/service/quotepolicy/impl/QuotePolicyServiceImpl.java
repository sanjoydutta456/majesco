package com.coverall.mic.rest.policy.api.service.quotepolicy.impl;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.coverall.mt.util.APIAuditTrailLog;
import com.coverall.mic.rest.policy.api.factory.impl.PolicyAPIFactoryServiceImpl;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.quotepolicy.QuotePolicyErrors;
import com.coverall.mic.rest.policy.api.service.quotepolicy.QuotePolicyService;
import com.coverall.mic.rest.policy.api.service.quotepolicy.handlers.QuotePolicyServiceHandler;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.pct.server.context.IPCTRequestContext;
import com.coverall.pctv2.server.service.PCTRequestContext;
import com.coverall.pctv2.server.service.PCTRetryRequestException;
import com.coverall.mt.webservices.WebServiceLoggerUtil;



public class QuotePolicyServiceImpl implements QuotePolicyService {
	String productCode ;
	String entityType;
	Map<Object,Object> prePostProcessorParams=new HashMap<Object,Object>();
	
	public QuotePolicyServiceImpl(String productCode, String entityType) {
		this.productCode = productCode;
		this.entityType = entityType;
		prePostProcessorParams.put(APIConstant.QUOTE_POLICY_SERVICE_IDENTIFIER,"Y");
		prePostProcessorParams.put("PROCESSED_SUCCESSFULLY", "N");
	}
	
	@Override
	public Object create(HttpServletRequest request, String json) throws Exception {
		Object response=null;
		APIOperationUtil.callRequestPreProcessor(request, prePostProcessorParams);
		try {
			if(json==null || "".equalsIgnoreCase(json)) {
			 json=APIOperationUtil.fetchRequestBody(request);
			}
			IAPIContext apiContext = APIRequestContext.getApiRequestContext();
			IPCTRequestContext pctContext = PCTRequestContext.getContext(request, null);
			pctContext.setParameterValue(PCTRequestContext.PRODUCT_CODE, productCode);
			pctContext.setParameterValue(PCTRequestContext.ENTITY_TYPE, entityType);
			
			//Auditing logic
			APIAuditTrailLog auditTrailLog=apiContext.getAuditTrailLog();
			JSONObject jsonObject = (JSONObject) new JSONParser().parse(json);
			String sourceSystemUserId = null;
			String sourceSystemCode = null;
			long sourceSystemRequestNo = 0;
			try{
				sourceSystemUserId = jsonObject.get("sourceSystemUserId")!=null?jsonObject.get("sourceSystemUserId").toString():null;
				sourceSystemCode = jsonObject.get("sourceSystemCode")!=null?jsonObject.get("sourceSystemCode").toString():null;
				sourceSystemRequestNo = jsonObject.get("sourceSystemRequestNo")!=null?Long.parseLong(jsonObject.get("sourceSystemRequestNo").toString()):0;
			}catch(Exception exp){
				//do nothing as this is specifically for logging purpose
			}
			APIOperationUtil.populateAPIAuditLog(auditTrailLog, sourceSystemCode, sourceSystemUserId, sourceSystemRequestNo, entityType+"-"+productCode, PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
						
			QuotePolicyServiceHandler serviceHandler = new QuotePolicyServiceHandler(productCode, entityType, pctContext, apiContext);
			response = serviceHandler.process(json);
			APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, PCTRequestContext.getContext().getEntityReference(), null, "Create new "+productCode+" "+entityType);
			prePostProcessorParams.put("PROCESSED_SUCCESSFULLY","Y");
			APIOperationUtil.callRequestPostProcessor(request, response, prePostProcessorParams);
		}catch(Exception exp) {
			APIOperationUtil.callRequestPostProcessor(request, exp, prePostProcessorParams);
			throw exp;
		}finally {
			if(PCTRequestContext.getContext() != null){
				// Releasing PCT request context, API context will be auto released
				PCTRequestContext.getContext().release();
			}
		}
		return response;
	}

	@Override
	public Object update(HttpServletRequest request, String policyId, String json) throws Exception {
		Object response=null;
		APIOperationUtil.callRequestPreProcessor(request, prePostProcessorParams);
		try {
			if(json==null || "".equalsIgnoreCase(json)) {
				 json=APIOperationUtil.fetchRequestBody(request);
			}
			IAPIContext apiContext = APIRequestContext.getApiRequestContext();
			IPCTRequestContext pctContext = PCTRequestContext.getContext(request, null);
			pctContext.setParameterValue(PCTRequestContext.PRODUCT_CODE, productCode);
			pctContext.setParameterValue(PCTRequestContext.ENTITY_TYPE, entityType);
			QuotePolicyServiceHandler serviceHandler = new QuotePolicyServiceHandler(productCode, entityType, pctContext, apiContext);
			
			//Auditing logic
			APIAuditTrailLog auditTrailLog=apiContext.getAuditTrailLog();
			JSONObject jsonObject = (JSONObject) new JSONParser().parse(json);
			String sourceSystemUserId = null;
			String sourceSystemCode = null;
			long sourceSystemRequestNo = 0;
			try{
				sourceSystemUserId = jsonObject.get("sourceSystemUserId")!=null?jsonObject.get("sourceSystemUserId").toString():null;
				sourceSystemCode = jsonObject.get("sourceSystemCode")!=null?jsonObject.get("sourceSystemCode").toString():null;
				sourceSystemRequestNo = jsonObject.get("sourceSystemRequestNo")!=null?Long.parseLong(jsonObject.get("sourceSystemRequestNo").toString()):0;
			}catch(Exception exp){
				//do nothing as this is specifically for logging purpose
			}
			APIOperationUtil.populateAPIAuditLog(auditTrailLog, sourceSystemCode, sourceSystemUserId, sourceSystemRequestNo, entityType+"-"+productCode, PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
			
			response = serviceHandler.processUpdate(json, policyId);
			APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, policyId, null, "Updated "+productCode+" "+entityType);
			prePostProcessorParams.put("PROCESSED_SUCCESSFULLY","Y");
			APIOperationUtil.callRequestPostProcessor(request, response, prePostProcessorParams);
			
			if(response != null && response instanceof JSONObject){
				JSONObject jsonObject1 = (JSONObject) response;
				String entityRef = null;
				String isOOse = null;
				try {
					entityRef = jsonObject1.get("EntityReference") != null ? jsonObject1.get("EntityReference").toString() : null;
					isOOse = jsonObject1.get("IsOOSE") != null ? jsonObject1.get("IsOOSE").toString() : null;
				} catch (Exception exp) {
					// do nothing as this is specifically for logging purpose
				}
				
				if(null != isOOse && "Y".equalsIgnoreCase(isOOse)){
					if(json != null && !json.isEmpty()){
						JSONObject jsonObj = (JSONObject) new JSONParser().parse(json);
						jsonObj.put("isOose", "Y");
						response = update(request, entityRef, jsonObj.toString());
					}
					
				}
			}
			
		} catch(Exception exp) {
			APIOperationUtil.callRequestPostProcessor(request, exp, prePostProcessorParams);
			throw exp;
		} finally {
			if(PCTRequestContext.getContext() != null){
				//Releasing PCT request context, API context will be auto released
				PCTRequestContext.getContext().release();
			}
			
		}
		return response;
	}

	@Override
	public Object get(HttpServletRequest request, String policyId) throws Exception {
		Object response=null;
		APIOperationUtil.callRequestPreProcessor(request, prePostProcessorParams);
		try {
			IAPIContext apiContext = APIRequestContext.getApiRequestContext();
			IPCTRequestContext pctContext = PCTRequestContext.getContext(request, null);
			pctContext.setParameterValue(PCTRequestContext.PRODUCT_CODE, productCode);
			pctContext.setParameterValue(PCTRequestContext.ENTITY_TYPE, entityType);
			QuotePolicyServiceHandler serviceHandler = new QuotePolicyServiceHandler(productCode, entityType, pctContext, apiContext);
			response = serviceHandler.processGet(policyId);
			prePostProcessorParams.put("PROCESSED_SUCCESSFULLY","Y");
			APIOperationUtil.callRequestPostProcessor(request, response, prePostProcessorParams);
		} catch(Exception exp) {
			APIOperationUtil.callRequestPostProcessor(request, exp, prePostProcessorParams);
			throw exp;
		} finally {
			if(PCTRequestContext.getContext() != null){
				//Releasing PCT request context, API context will be auto released
				PCTRequestContext.getContext().release();
			}
		}
		return response;
	}
	
	public Object processConvert(HttpServletRequest request, String transactionId, boolean convertToBinder, boolean rate, boolean fullModel, String errorMessagePlaceHolderType) throws Exception {
		Object response = null;
		APIOperationUtil.callRequestPreProcessor(request, prePostProcessorParams);
		try {
			IAPIContext apiContext = APIRequestContext.getApiRequestContext();
			IPCTRequestContext pctContext = PCTRequestContext.getContext(request, null);
			pctContext.setParameterValue(PCTRequestContext.PRODUCT_CODE, productCode);
			pctContext.setParameterValue(PCTRequestContext.ENTITY_TYPE, entityType);
			QuotePolicyServiceHandler serviceHandler = new QuotePolicyServiceHandler(productCode, entityType, pctContext, apiContext);
			response = serviceHandler.processConvert(transactionId, convertToBinder, rate, fullModel, errorMessagePlaceHolderType);
			prePostProcessorParams.put("PROCESSED_SUCCESSFULLY","Y");
			APIOperationUtil.callRequestPostProcessor(request, response, prePostProcessorParams);
		} catch(Exception exp) {
			APIOperationUtil.callRequestPostProcessor(request, exp, prePostProcessorParams);
			throw exp;
		} finally {
			if(PCTRequestContext.getContext() != null){
				//Releasing PCT request context, API context will be auto released
				PCTRequestContext.getContext().release();
			}
		}
		return response;
	}
	

	@Override
	public Object revise(HttpServletRequest request,String policyId, String json) throws Exception {
		Object response= null;
		APIOperationUtil.callRequestPreProcessor(request, prePostProcessorParams);
		try {
			if(json==null || "".equalsIgnoreCase(json)) {
				 json=APIOperationUtil.fetchRequestBody(request);
			}
			IAPIContext apiContext = APIRequestContext.getApiRequestContext();
			IPCTRequestContext pctContext = PCTRequestContext.getContext(request, null);
			pctContext.setParameterValue(PCTRequestContext.PRODUCT_CODE, productCode);
			pctContext.setParameterValue(PCTRequestContext.ENTITY_TYPE, entityType);
			
			//Auditing logic
			APIAuditTrailLog auditTrailLog = apiContext.getAuditTrailLog();
			if(json != null && !json.isEmpty()){
				JSONObject jsonObject = (JSONObject) new JSONParser().parse(json);
				String sourceSystemUserId = null;
				String sourceSystemCode = null;
				long sourceSystemRequestNo = 0;
				try {
					sourceSystemUserId = jsonObject.get("sourceSystemUserId") != null ? jsonObject.get("sourceSystemUserId").toString() : null;
					sourceSystemCode = jsonObject.get("sourceSystemCode") != null ? jsonObject.get("sourceSystemCode").toString() : null;
					sourceSystemRequestNo = jsonObject.get("sourceSystemRequestNo") != null ? Long
							.parseLong(jsonObject.get("sourceSystemRequestNo").toString()) : 0;
				} catch (Exception exp) {
					// do nothing as this is specifically for logging purpose
				}
				APIOperationUtil.populateAPIAuditLog(auditTrailLog, sourceSystemCode, sourceSystemUserId, sourceSystemRequestNo,
						entityType + "-" + productCode, PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
			}						
			QuotePolicyServiceHandler serviceHandler = new QuotePolicyServiceHandler(productCode, entityType, pctContext, apiContext);
			response = serviceHandler.processRevise(json, policyId);
			APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, PCTRequestContext.getContext().getEntityReference(), null, "Endorse  "+productCode+" "+entityType + policyId);
			prePostProcessorParams.put("PROCESSED_SUCCESSFULLY","Y");
			APIOperationUtil.callRequestPostProcessor(request, response, prePostProcessorParams);
		} catch(Exception exp) {
			APIOperationUtil.callRequestPostProcessor(request, exp, prePostProcessorParams);
			throw exp;
		} finally {
			if(PCTRequestContext.getContext() != null){
				// Releasing PCT request context, API context will be auto released
				PCTRequestContext.getContext().release();
			}
		}
		return response;
	}
	
	
	
	@Override
	public Object endorse(HttpServletRequest request,String policyId, String json) throws Exception {
		Object response=null;
		APIOperationUtil.callRequestPreProcessor(request, prePostProcessorParams);
		try {
			if(json==null || "".equalsIgnoreCase(json)) {
				 json=APIOperationUtil.fetchRequestBody(request);
			}
			IAPIContext apiContext = APIRequestContext.getApiRequestContext();
			IPCTRequestContext pctContext = PCTRequestContext.getContext(request, null);
			pctContext.setParameterValue(PCTRequestContext.PRODUCT_CODE, productCode);
			pctContext.setParameterValue(PCTRequestContext.ENTITY_TYPE, entityType);
			
			//Auditing logic
			APIAuditTrailLog auditTrailLog = apiContext.getAuditTrailLog();
			if(json != null && !json.isEmpty()){
				JSONObject jsonObject = (JSONObject) new JSONParser().parse(json);
				String sourceSystemUserId = null;
				String sourceSystemCode = null;
				long sourceSystemRequestNo = 0;
				try {
					sourceSystemUserId = jsonObject.get("sourceSystemUserId") != null ? jsonObject.get("sourceSystemUserId").toString() : null;
					sourceSystemCode = jsonObject.get("sourceSystemCode") != null ? jsonObject.get("sourceSystemCode").toString() : null;
					sourceSystemRequestNo = jsonObject.get("sourceSystemRequestNo") != null ? Long
							.parseLong(jsonObject.get("sourceSystemRequestNo").toString()) : 0;
				} catch (Exception exp) {
					// do nothing as this is specifically for logging purpose
				}
				APIOperationUtil.populateAPIAuditLog(auditTrailLog, sourceSystemCode, sourceSystemUserId, sourceSystemRequestNo,
						entityType + "-" + productCode, PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
			}						
			QuotePolicyServiceHandler serviceHandler = new QuotePolicyServiceHandler(productCode, entityType, pctContext, apiContext);
			response = serviceHandler.processEndorse(json, policyId);
		
			
	            
			APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, PCTRequestContext.getContext().getEntityReference(), null, "Endorse  "+productCode+" "+entityType + policyId);
			prePostProcessorParams.put("PROCESSED_SUCCESSFULLY","Y");
			APIOperationUtil.callRequestPostProcessor(request, response, prePostProcessorParams);
			
			if(response != null && response instanceof JSONObject){
				JSONObject jsonObject = (JSONObject) response;
				String entityRef = null;
				String isOOse = null;
				long sourceSystemRequestNo = 0;
				try {
					entityRef = jsonObject.get("EntityReference") != null ? jsonObject.get("EntityReference").toString() : null;
					isOOse = jsonObject.get("IsOOSE") != null ? jsonObject.get("IsOOSE").toString() : null;
				} catch (Exception exp) {
					// do nothing as this is specifically for logging purpose
				}
				
				if(null != isOOse && "Y".equalsIgnoreCase(isOOse)){
					if(json != null && !json.isEmpty()){
						JSONObject jsonObj = (JSONObject) new JSONParser().parse(json);
						jsonObj.put("isOose", "Y");
						response = update(request, entityRef, jsonObj.toString());
					}
					
				}
			}
						
			
		} catch(Exception exp) {
			APIOperationUtil.callRequestPostProcessor(request, exp, prePostProcessorParams);			
			
			throw exp;
		} finally {
			if(PCTRequestContext.getContext() != null){
				// Releasing PCT request context, API context will be auto released
				PCTRequestContext.getContext().release();
			}
		}
		return response;
	}
	
	@Override
	public Object interimAudit(HttpServletRequest request,String policyId, String json) throws Exception {
		Object response=null;
		APIOperationUtil.callRequestPreProcessor(request, prePostProcessorParams);
		try {
			if(json==null || "".equalsIgnoreCase(json)) {
				 json=APIOperationUtil.fetchRequestBody(request);
			}
			IAPIContext apiContext = APIRequestContext.getApiRequestContext();
			IPCTRequestContext pctContext = PCTRequestContext.getContext(request, null);
			pctContext.setParameterValue(PCTRequestContext.PRODUCT_CODE, productCode);
			pctContext.setParameterValue(PCTRequestContext.ENTITY_TYPE, entityType);
			
			//Auditing logic
			APIAuditTrailLog auditTrailLog = apiContext.getAuditTrailLog();
			if(json != null && !json.isEmpty()){
				JSONObject jsonObject = (JSONObject) new JSONParser().parse(json);
				String sourceSystemUserId = null;
				String sourceSystemCode = null;
				long sourceSystemRequestNo = 0;
				try {
					sourceSystemUserId = jsonObject.get("sourceSystemUserId") != null ? jsonObject.get("sourceSystemUserId").toString() : null;
					sourceSystemCode = jsonObject.get("sourceSystemCode") != null ? jsonObject.get("sourceSystemCode").toString() : null;
					sourceSystemRequestNo = jsonObject.get("sourceSystemRequestNo") != null ? Long
							.parseLong(jsonObject.get("sourceSystemRequestNo").toString()) : 0;
				} catch (Exception exp) {
					// do nothing as this is specifically for logging purpose
				}
				APIOperationUtil.populateAPIAuditLog(auditTrailLog, sourceSystemCode, sourceSystemUserId, sourceSystemRequestNo,
						entityType + "-" + productCode, PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
			}						
			QuotePolicyServiceHandler serviceHandler = new QuotePolicyServiceHandler(productCode, entityType, pctContext, apiContext);
			response = serviceHandler.processInterimAudit(json, policyId);
			APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, PCTRequestContext.getContext().getEntityReference(), null, "Endorse  "+productCode+" "+entityType + policyId);
			prePostProcessorParams.put("PROCESSED_SUCCESSFULLY","Y");
			APIOperationUtil.callRequestPostProcessor(request, response, prePostProcessorParams);
		} catch(Exception exp) {
			APIOperationUtil.callRequestPostProcessor(request, exp, prePostProcessorParams);
			throw exp;
		} finally {
			if(PCTRequestContext.getContext() != null){
				// Releasing PCT request context, API context will be auto released
				PCTRequestContext.getContext().release();
			}
		}
		return response;
	}
	
	@Override
	public Object finalAudit(HttpServletRequest request,String policyId, String json) throws Exception {
		Object response=null;
		APIOperationUtil.callRequestPreProcessor(request, prePostProcessorParams);
		try {
			if(json==null || "".equalsIgnoreCase(json)) {
				 json=APIOperationUtil.fetchRequestBody(request);
			}
			IAPIContext apiContext = APIRequestContext.getApiRequestContext();
			IPCTRequestContext pctContext = PCTRequestContext.getContext(request, null);
			pctContext.setParameterValue(PCTRequestContext.PRODUCT_CODE, productCode);
			pctContext.setParameterValue(PCTRequestContext.ENTITY_TYPE, entityType);
			
			//Auditing logic
			APIAuditTrailLog auditTrailLog = apiContext.getAuditTrailLog();
			if(json != null && !json.isEmpty()){
				JSONObject jsonObject = (JSONObject) new JSONParser().parse(json);
				String sourceSystemUserId = null;
				String sourceSystemCode = null;
				long sourceSystemRequestNo = 0;
				try {
					sourceSystemUserId = jsonObject.get("sourceSystemUserId") != null ? jsonObject.get("sourceSystemUserId").toString() : null;
					sourceSystemCode = jsonObject.get("sourceSystemCode") != null ? jsonObject.get("sourceSystemCode").toString() : null;
					sourceSystemRequestNo = jsonObject.get("sourceSystemRequestNo") != null ? Long
							.parseLong(jsonObject.get("sourceSystemRequestNo").toString()) : 0;
				} catch (Exception exp) {
					// do nothing as this is specifically for logging purpose
				}
				APIOperationUtil.populateAPIAuditLog(auditTrailLog, sourceSystemCode, sourceSystemUserId, sourceSystemRequestNo,
						entityType + "-" + productCode, PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
			}						
			QuotePolicyServiceHandler serviceHandler = new QuotePolicyServiceHandler(productCode, entityType, pctContext, apiContext);
			response = serviceHandler.processFinalAudit(json, policyId);
			APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, PCTRequestContext.getContext().getEntityReference(), null, "Endorse  "+productCode+" "+entityType + policyId);
			prePostProcessorParams.put("PROCESSED_SUCCESSFULLY","Y");
			APIOperationUtil.callRequestPostProcessor(request, response, prePostProcessorParams);
		} catch(Exception exp) {
			APIOperationUtil.callRequestPostProcessor(request, exp, prePostProcessorParams);
			throw exp;
		} finally {
			if(PCTRequestContext.getContext() != null){
				// Releasing PCT request context, API context will be auto released
				PCTRequestContext.getContext().release();
			}
		}
		return response;
	}
	
	@Override
	public Object quoteForEndorsement(HttpServletRequest request,String policyId, String json) throws Exception {
		Object response=null;
		if(json==null || "".equalsIgnoreCase(json)) {
			 json=APIOperationUtil.fetchRequestBody(request);
		}
		WebServiceLoggerUtil.logInfo("quoteForEndorsement test", " Request :", new Object[] {  json,"policyId: " +policyId});
		APIOperationUtil.callRequestPreProcessor(request, prePostProcessorParams);
		try {
			IAPIContext apiContext = APIRequestContext.getApiRequestContext();
			IPCTRequestContext pctContext = PCTRequestContext.getContext(request, null);
			pctContext.setParameterValue(PCTRequestContext.PRODUCT_CODE, productCode);
			pctContext.setParameterValue(PCTRequestContext.ENTITY_TYPE, entityType);
			
			//Auditing logic
			APIAuditTrailLog auditTrailLog = apiContext.getAuditTrailLog();
			if(json != null && !json.isEmpty()){
				JSONObject jsonObject = (JSONObject) new JSONParser().parse(json);
				String sourceSystemUserId = null;
				String sourceSystemCode = null;
				long sourceSystemRequestNo = 0;
				try {
					sourceSystemUserId = jsonObject.get("sourceSystemUserId") != null ? jsonObject.get("sourceSystemUserId").toString() : null;
					sourceSystemCode = jsonObject.get("sourceSystemCode") != null ? jsonObject.get("sourceSystemCode").toString() : null;
					sourceSystemRequestNo = jsonObject.get("sourceSystemRequestNo") != null ? Long
							.parseLong(jsonObject.get("sourceSystemRequestNo").toString()) : 0;
				} catch (Exception exp) {
					// do nothing as this is specifically for logging purpose
				}
				APIOperationUtil.populateAPIAuditLog(auditTrailLog, sourceSystemCode, sourceSystemUserId, sourceSystemRequestNo,
						entityType + "-" + productCode, PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
			}						
			QuotePolicyServiceHandler serviceHandler = new QuotePolicyServiceHandler(productCode, entityType, pctContext, apiContext);
			response = serviceHandler.processQuoteForEndorsement(json, policyId);
			APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, PCTRequestContext.getContext().getEntityReference(), null, "QuoteForEndorsement  "+productCode+" "+entityType + policyId);
			prePostProcessorParams.put("PROCESSED_SUCCESSFULLY","Y");
			APIOperationUtil.callRequestPostProcessor(request, response, prePostProcessorParams);
		} catch(Exception exp) {
			APIOperationUtil.callRequestPostProcessor(request, exp, prePostProcessorParams);
			throw exp;
		} finally {
			if(PCTRequestContext.getContext() != null){
				// Releasing PCT request context, API context will be auto released
				PCTRequestContext.getContext().release();
			}
		}
		return response;
	}
	
	@Override
	public String ping() {
		// TODO Auto-generated method stub
		return "This is QuotePolicyService";
	}
	
	public Object processConvertEndorsement(HttpServletRequest request, String transactionId, String convertToBinder, boolean rate, boolean fullModel) throws Exception {
		Object response = null;
		WebServiceLoggerUtil.logInfo("QuotePolicyServiceImpl", "processConvertNew","convertToBinder : "+ convertToBinder, new Object[] { "transactionId : "+transactionId , request});
		
		
		APIOperationUtil.callRequestPreProcessor(request, prePostProcessorParams);
		try {
			IAPIContext apiContext = APIRequestContext.getApiRequestContext();
			IPCTRequestContext pctContext = PCTRequestContext.getContext(request, null);
			pctContext.setParameterValue(PCTRequestContext.PRODUCT_CODE, productCode);
			pctContext.setParameterValue(PCTRequestContext.ENTITY_TYPE, entityType);
			QuotePolicyServiceHandler serviceHandler = new QuotePolicyServiceHandler(productCode, entityType, pctContext, apiContext);
			response = serviceHandler.processConvertEndorsement(transactionId, "ConvertQuoteForEndorsement", rate, fullModel);
			prePostProcessorParams.put("PROCESSED_SUCCESSFULLY","Y");
			APIOperationUtil.callRequestPostProcessor(request, response, prePostProcessorParams);
		} catch(Exception exp) {
			APIOperationUtil.callRequestPostProcessor(request, exp, prePostProcessorParams);
			throw exp;
		} finally {
			if(PCTRequestContext.getContext() != null){
				//Releasing PCT request context, API context will be auto released
				PCTRequestContext.getContext().release();
			}
		}
		return response;
	}
	
	@Override
	public Object cancel(HttpServletRequest request,String policyId, String json) throws Exception {
		Object response=null;
		if(json==null || "".equalsIgnoreCase(json)) {
			 json=APIOperationUtil.fetchRequestBody(request);
		}
		WebServiceLoggerUtil.logInfo("cancel test", " Request :", new Object[] {  json,"policyId: " +policyId});
		APIOperationUtil.callRequestPreProcessor(request, prePostProcessorParams);
		try {
			IAPIContext apiContext = APIRequestContext.getApiRequestContext();
			IPCTRequestContext pctContext = PCTRequestContext.getContext(request, null);
			pctContext.setParameterValue(PCTRequestContext.PRODUCT_CODE, productCode);
			pctContext.setParameterValue(PCTRequestContext.ENTITY_TYPE, entityType);
			
			//Auditing logic
			APIAuditTrailLog auditTrailLog = apiContext.getAuditTrailLog();
			if(json != null && !json.isEmpty()){
				JSONObject jsonObject = (JSONObject) new JSONParser().parse(json);
				String sourceSystemUserId = null;
				String sourceSystemCode = null;
				long sourceSystemRequestNo = 0;
				try {
					sourceSystemUserId = jsonObject.get("sourceSystemUserId") != null ? jsonObject.get("sourceSystemUserId").toString() : null;
					sourceSystemCode = jsonObject.get("sourceSystemCode") != null ? jsonObject.get("sourceSystemCode").toString() : null;
					sourceSystemRequestNo = jsonObject.get("sourceSystemRequestNo") != null ? Long
							.parseLong(jsonObject.get("sourceSystemRequestNo").toString()) : 0;
				} catch (Exception exp) {
					// do nothing as this is specifically for logging purpose
				}
				APIOperationUtil.populateAPIAuditLog(auditTrailLog, sourceSystemCode, sourceSystemUserId, sourceSystemRequestNo,
						entityType + "-" + productCode, PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
			}						
			QuotePolicyServiceHandler serviceHandler = new QuotePolicyServiceHandler(productCode, entityType, pctContext, apiContext);
			response = serviceHandler.processCancel(json, policyId);
			APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, PCTRequestContext.getContext().getEntityReference(), null, "QuoteForEndorsement  "+productCode+" "+entityType + policyId);
			prePostProcessorParams.put("PROCESSED_SUCCESSFULLY","Y");
			APIOperationUtil.callRequestPostProcessor(request, response, prePostProcessorParams);
			
			if(response != null && response instanceof JSONObject){
				JSONObject jsonObject1 = (JSONObject) response;
				String entityRef = null;
				String isOOse = null;
				try {
					entityRef = jsonObject1.get("EntityReference") != null ? jsonObject1.get("EntityReference").toString() : null;
					isOOse = jsonObject1.get("IsOOSE") != null ? jsonObject1.get("IsOOSE").toString() : null;
				} catch (Exception exp) {
					// do nothing as this is specifically for logging purpose
				}
				
				if(null != isOOse && "Y".equalsIgnoreCase(isOOse)){
					if(json != null && !json.isEmpty()){
						JSONObject jsonObj = (JSONObject) new JSONParser().parse(json);
						jsonObj.put("isOose", "Y");
						response = update(request, entityRef, jsonObj.toString());
					}
					
				}
			}
			
		} catch(Exception exp) {
			APIOperationUtil.callRequestPostProcessor(request, exp, prePostProcessorParams);
			throw exp;
		} finally {
			if(PCTRequestContext.getContext() != null){
				// Releasing PCT request context, API context will be auto released
				PCTRequestContext.getContext().release();
			}
		}
		return response;
	}
	
	public Object processDecline(HttpServletRequest request, String transactionId, String json) throws Exception {
		Object response = null;
		APIOperationUtil.callRequestPreProcessor(request, prePostProcessorParams);
		try {
			IAPIContext apiContext = APIRequestContext.getApiRequestContext();
			IPCTRequestContext pctContext = PCTRequestContext.getContext(request, null);
			pctContext.setParameterValue(PCTRequestContext.PRODUCT_CODE, productCode);
			pctContext.setParameterValue(PCTRequestContext.ENTITY_TYPE, entityType);
			QuotePolicyServiceHandler serviceHandler = new QuotePolicyServiceHandler(productCode, entityType, pctContext, apiContext);
			response = serviceHandler.processDecline(transactionId, json);
			prePostProcessorParams.put("PROCESSED_SUCCESSFULLY","Y");
			APIOperationUtil.callRequestPostProcessor(request, response, prePostProcessorParams);
		} catch(Exception exp) {
			APIOperationUtil.callRequestPostProcessor(request, exp, prePostProcessorParams);
			throw exp;
		} finally {
			if(PCTRequestContext.getContext() != null){
				//Releasing PCT request context, API context will be auto released
				PCTRequestContext.getContext().release();
			}
		}
		return response;
	}
	
	public Object processOpenQuote(HttpServletRequest request, String transactionId, boolean completeTransaction, boolean rate, boolean fullModel, String errorMessagePlaceHolderType) throws Exception {
		Object response = null;
		APIOperationUtil.callRequestPreProcessor(request, prePostProcessorParams);
		try {
			IAPIContext apiContext = APIRequestContext.getApiRequestContext();
			IPCTRequestContext pctContext = PCTRequestContext.getContext(request, null);
			pctContext.setParameterValue(PCTRequestContext.PRODUCT_CODE, productCode);
			pctContext.setParameterValue(PCTRequestContext.ENTITY_TYPE, entityType);
			QuotePolicyServiceHandler serviceHandler = new QuotePolicyServiceHandler(productCode, entityType, pctContext, apiContext);
			response = serviceHandler.processOpenQuote(transactionId, completeTransaction , rate, fullModel, errorMessagePlaceHolderType);
			prePostProcessorParams.put("PROCESSED_SUCCESSFULLY","Y");
			APIOperationUtil.callRequestPostProcessor(request, response, prePostProcessorParams);
		} catch(Exception exp) {
			APIOperationUtil.callRequestPostProcessor(request, exp, prePostProcessorParams);
			throw exp;
		} finally {
			if(PCTRequestContext.getContext() != null){
				//Releasing PCT request context, API context will be auto released
				PCTRequestContext.getContext().release();
			}
		}
		return response;
	}
	

}
