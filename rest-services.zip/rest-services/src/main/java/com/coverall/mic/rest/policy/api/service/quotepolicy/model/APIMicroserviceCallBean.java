package com.coverall.mic.rest.policy.api.service.quotepolicy.model;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class APIMicroserviceCallBean {

	String apiJsonPath;
	String pctJsonPath;
	String sourceSystemId;
	String pctXpath;
    boolean isMultiOccuringObjectInRequest;
	Map<String, String> postData = new HashMap<String, String>();
	String endPointURL;
	List<APIMicroserviceCallBean> childObjectServiceCalls = new ArrayList<APIMicroserviceCallBean>();
	APIMicroserviceCallBean parentMSCallbean;
    String uniqueKey ;
    String isDelete; 
    String msRestEndPoint;
    String overrideSourceSystemId;
    boolean processedOnce;
	

	


	public APIMicroserviceCallBean() {

	}

	public APIMicroserviceCallBean(String apiJsonPath, String pctJsonPath) {
		this.apiJsonPath = apiJsonPath;
		this.pctJsonPath = pctJsonPath;
	}
	
	public boolean isMultiOccuringObjectInRequest() {
		return isMultiOccuringObjectInRequest;
	}

	public void setMultiOccuringObjectInRequest(boolean isMultiOccuringObjectInRequest) {
		this.isMultiOccuringObjectInRequest = isMultiOccuringObjectInRequest;
	}


	public String getApiJsonPath() {
		return apiJsonPath;
	}

	public void setApiJsonPath(String apiJsonPath) {
		this.apiJsonPath = apiJsonPath;
	}

	public String getPctJsonPath() {
		return pctJsonPath;
	}

	public void setPctJsonPath(String pctJsonPath) {
		this.pctJsonPath = pctJsonPath;
	}

	public String getSourceSystemId() {
		return sourceSystemId;
	}

	public void setSourceSystemId(String sourceSystemId) {
		this.sourceSystemId = sourceSystemId;
	}

	public String getOverrideSourceSystemId() {
		return overrideSourceSystemId;
	}

	public void setOverrideSourceSystemId(String overrideSourceSystemId) {
		this.overrideSourceSystemId = overrideSourceSystemId;
	}

	public Map<String, String> getPostData() {
		return postData;
	}

	public void setPostData(Map<String, String> postData) {
		this.postData = postData;
	}

	public String getEndPointURL() {
		return endPointURL;
	}

	public void setEndPointURL(String endPointURL) {
		this.endPointURL = endPointURL;
	}

	public List<APIMicroserviceCallBean> getChildObjectServiceCalls() {
		return childObjectServiceCalls;
	}

	public void setChildObjectServiceCalls(List<APIMicroserviceCallBean> childObjectServiceCalls) {
		this.childObjectServiceCalls = childObjectServiceCalls;
	}


	public APIMicroserviceCallBean getParentMSCallbean() {
		return parentMSCallbean;
	}

	public void setParentMSCallbean(APIMicroserviceCallBean parentMSCallbean) {
		this.parentMSCallbean = parentMSCallbean;
	}
	
	public String getPctXpath() {
		return pctXpath;
	}

	public void setPctXpath(String pctXpath) {
		this.pctXpath = pctXpath;
	}
	
	public String getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(String isDelete) {
		this.isDelete = isDelete;
	}
	public String getMsRestEndPoint() {
		return msRestEndPoint;
	}

	public void setMsRestEndPoint(String msRestEndPoint) {
		this.msRestEndPoint = msRestEndPoint;
	}

	
	@Override
	public String toString() {
		return "APIMicroserviceCallBean [apiJsonPath=" + apiJsonPath + ", pctJsonPath=" + pctJsonPath + ", sourceSystemId=" + sourceSystemId + ", postData="
				+ postData + ", uniqueKey=" + uniqueKey+", processedOnce="+processedOnce +", endPointURL=" + endPointURL +", pctXpath="+pctXpath+ ", isMultiOccuringObjectInRequest="+isMultiOccuringObjectInRequest+ ", childObjectServiceCalls=" + childObjectServiceCalls + "]";
	}
	
	public String getUniqueKey() {
		return uniqueKey;
	}

	public void setUniqueKey(String uniqueKey) {
		this.uniqueKey = uniqueKey;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((uniqueKey == null) ? 0 : uniqueKey.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		APIMicroserviceCallBean other = (APIMicroserviceCallBean) obj;
		if (this.uniqueKey == null) {
				return false;
		} else if (this.uniqueKey.equals(other.uniqueKey)){
			return true;
		}
		return false;
	}
	

	public boolean isProcessedOnce() {
		return processedOnce;
	}

	public void setProcessedOnce(boolean processedOnce) {
		this.processedOnce = processedOnce;
	}
    
	public APIMicroserviceCallBean deepClone(){
		APIMicroserviceCallBean clonedCopy = new  APIMicroserviceCallBean();
		clonedCopy.setApiJsonPath(this.apiJsonPath);
		clonedCopy.setPctJsonPath(this.pctJsonPath);
		clonedCopy.setSourceSystemId(this.sourceSystemId);
		clonedCopy.setPctXpath(this.pctXpath);
		clonedCopy.setMultiOccuringObjectInRequest(this.isMultiOccuringObjectInRequest);
		clonedCopy.setPostData(this.postData);
		clonedCopy.setEndPointURL(this.endPointURL);
		clonedCopy.setChildObjectServiceCalls(this.childObjectServiceCalls);
		clonedCopy.setParentMSCallbean(this.parentMSCallbean);
		clonedCopy.setUniqueKey(this.uniqueKey) ;
		clonedCopy.setIsDelete(isDelete); 
		clonedCopy.setMsRestEndPoint(this.msRestEndPoint);
		clonedCopy.setOverrideSourceSystemId(this.overrideSourceSystemId);
		clonedCopy.setProcessedOnce(processedOnce);
		return clonedCopy;
	}
	
}
