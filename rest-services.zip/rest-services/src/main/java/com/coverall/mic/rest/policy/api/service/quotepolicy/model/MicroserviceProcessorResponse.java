package com.coverall.mic.rest.policy.api.service.quotepolicy.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.coverall.pctv2.server.rs.service.microservices.ErrorMessage;

public class MicroserviceProcessorResponse {

	
	public static enum STATUS {SUCCESSFULL, FAILURE}; 
	private String errorCode;
	private Map<String,List<ErrorMessage>> erroMessagesMap = new HashMap<String,List<ErrorMessage>>() ;
	private Object responseJson;
	private STATUS status; 
	
	public STATUS getStatus() {
		return status;
	}
	public void setStatus(STATUS status) {
		this.status = status;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public Map<String, List<ErrorMessage>> getErroMessagesMap() {
		return erroMessagesMap;
	}
	public void setErroMessagesMap(Map<String, List<ErrorMessage>> erroMessagesMap) {
		this.erroMessagesMap = erroMessagesMap;
	}
	public Object getResponseJson() {
		return responseJson;
	}
	public void setResponseJson(Object responseJson) {
		this.responseJson = responseJson;
	}
	
	
}
