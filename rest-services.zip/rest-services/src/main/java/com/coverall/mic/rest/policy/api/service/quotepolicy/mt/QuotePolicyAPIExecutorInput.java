package com.coverall.mic.rest.policy.api.service.quotepolicy.mt;

import java.util.HashMap;
import java.util.Map;

import com.coverall.mic.rest.policy.api.service.quotepolicy.model.APIMicroserviceCallBean;
import com.coverall.pctv2.server.rs.service.microservices.MicroServiceFormat;

public class QuotePolicyAPIExecutorInput {

	private MicroServiceFormat request;
	private Map<String, Map<String, String>> instancesToBeMapped;
	private String methodType;
	private HashMap<String, String> params;
	private APIMicroserviceCallBean msBean;
	
	
	public QuotePolicyAPIExecutorInput(){
		
	}
	
	public QuotePolicyAPIExecutorInput(MicroServiceFormat request, Map<String, Map<String, String>> instancesToBeMapped, String methodType, HashMap<String, String> params, APIMicroserviceCallBean msBean) {
		this.request = request;
		this.instancesToBeMapped = instancesToBeMapped;
		this.methodType = methodType;
		this.params = params;
		this.msBean = msBean;
	}
	
	
	
	public APIMicroserviceCallBean getMsBean() {
		return msBean;
	}

	public void setMsBean(APIMicroserviceCallBean msBean) {
		this.msBean = msBean;
	}

	public HashMap<String, String> getParams() {
		return params;
	}

	public void setParams(HashMap<String, String> params) {
		this.params = params;
	}

	public MicroServiceFormat getRequest() {
		return request;
	}
	public void setRequest(MicroServiceFormat request) {
		this.request = request;
	}
	public Map<String, Map<String, String>> getInstancesToBeMapped() {
		return instancesToBeMapped;
	}
	public void setInstancesToBeMapped(Map<String, Map<String, String>> instancesToBeMapped) {
		this.instancesToBeMapped = instancesToBeMapped;
	}
	public String getMethodType() {
		return methodType;
	}
	public void setMethodType(String methodType) {
		this.methodType = methodType;
	}
	
	
}

