package com.coverall.mic.rest.policy.api.service.quotepolicy.mt;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.rowset.spi.SyncResolver;

import jsr166y.RecursiveTask;

import com.coverall.gwt.common.client.TimingSession;
import com.coverall.mic.rest.policy.api.service.quotepolicy.handlers.MicroServiceProcessor;
import com.coverall.mt.http.User;
import com.coverall.mt.pl.concurrency.PerfLoggingThreadedServicesManagerML;
import com.coverall.mt.pl.step.IStepLogger.LogLevel;
import com.coverall.mt.pl.step.IStepLogger.LogScope;
import com.coverall.mt.pl.step.IStepLogger.LogSubScope;
import com.coverall.mt.pl.step.impl.StepLogUtil;
import com.coverall.pct.server.logging.PCTLogUtil;
import com.coverall.pct.server.util.PCTGenUtils;
import com.coverall.pctv2.client.exceptions.PCTException;
import com.coverall.pctv2.server.exceptions.PCTRuntimeException;
import com.coverall.pctv2.server.rs.service.microservices.MicroServiceFormat;
import com.coverall.pctv2.server.service.IPCTRequestContext;
import com.coverall.pctv2.server.service.PCTMicroservicesTransaction;
import com.coverall.pctv2.server.service.PCTRequestContext;

public class QuotePolicyAPIExecutorTask extends RecursiveTask<Boolean> {

	private User user;
	private List<QuotePolicyExecutorOutput> responses = new ArrayList<QuotePolicyExecutorOutput>();
	private List<QuotePolicyAPIExecutorInput> msCalls;
	private transient IPCTRequestContext context;
	private transient IPCTRequestContext parentContext;
	private PerfLoggingThreadedServicesManagerML pltm;
	private MicroServiceProcessor processor;

	public QuotePolicyAPIExecutorTask(IPCTRequestContext parentContext, User user,
			List<QuotePolicyAPIExecutorInput> msCalls, MicroServiceProcessor processor) {
		this.parentContext = parentContext;
		this.user = user;
		this.msCalls = msCalls;
		this.processor = processor;

	}

	@Override
	protected Boolean compute() {
		try {
			
			try {
				// Commit the existing connection as child threads will have different connections
				parentContext.getConnection().commit();
			} catch (SQLException | PCTException e) {
				PCTLogUtil.logErrorIntoContextLogger(getClass(), "compute", new Object[] {}, e, "Error commiting the parent connection");
			}
			
			
			prepareContext();
			TimingSession ts = PCTRequestContext.getContext().getTimingSession(); // timing
																					// session
																					// has
																					// already
																					// been
																					// setup
																					// by
																					// now
			try {
				// ts.startClientTiming("QueryExecutorTask.computeActual");
				// ts.startNetworkTiming("QueryExecutorTask.computeActual", "");
				// ts.startServerTiming("QueryExecutorTask.computeActual - Before Process");
				//if (pltm != null) {
				//	pltm.addService(ts);
				//}
				executeService();
			} finally {
				// ts.stopServerTiming("QueryExecutorTask.computeActual - End Process");
				// ts.stopNetworkTiming("QueryExecutorTask.computeActual");
				// ts.stopClientTiming("QueryExecutorTask.computeActual");
			}
		} finally {
			releaseContext();
		}
		return true;
	}

	private void prepareContextandInitiateTS(){
		prepareContext();
		TimingSession ts = PCTRequestContext.getContext().getTimingSession();
		if (pltm != null) {
				pltm.addService(ts);
		}
		
	}
	
	private void prepareContext() {
		try {
			PCTRequestContext.initContextForMicroserviceMT(parentContext, "" + Math.random(), true);
			;
		} catch (Exception e) {
			PCTLogUtil.logErrorIntoContextLogger(getClass(), "prepareContext", new Object[] {}, e, "Error while preparing context");
			throw new PCTRuntimeException("Error [" + e.getMessage() + "] while preparing context", e);
		}

		context = PCTRequestContext.getContext();
	}

	private void releaseContext() {
		if (context != null) {
			try {
				PCTRequestContext.releaseContextForRatingMT(parentContext);
			} catch (PCTException e) {
				// since the attempt has been made to release the context, log
				// on file system
				PCTGenUtils.systemErrWithThreadInfo("Error releasing context", e);
				throw new PCTRuntimeException("Error releasing context", e);
			}
		}
	}

	protected void executeService() {

		if (msCalls != null) {
			for (QuotePolicyAPIExecutorInput microServiceCall : msCalls) {
				try {
					//prepareContextandInitiateTS();
					String methodType = microServiceCall.getMethodType();
					if(MicroServiceProcessor.ADD.equalsIgnoreCase(microServiceCall.getMethodType())){
						processor.generateBlankInstancesForParallelProcessing(microServiceCall);
						// Commit the blank instance
						context.getConnection().commit();
						methodType = MicroServiceProcessor.UPDATE;
					}else if (MicroServiceProcessor.DELETE.equalsIgnoreCase(microServiceCall.getMethodType())){
						synchronized (processor) {
							processor.processDeleteForParallelProcessing(microServiceCall);
							context.getConnection().commit();
							return;	
						}
					}
					
					PCTMicroservicesTransaction  microserviceTransaction = new PCTMicroservicesTransaction(user, microServiceCall.getParams(), user.getUserId() + "@" + user.getDomain(), 0);
					MicroServiceFormat response = microserviceTransaction.processMultiThreadedAPIRequest(microServiceCall.getRequest(), microServiceCall.getInstancesToBeMapped(),
							methodType, parentContext);
					QuotePolicyExecutorOutput output = new QuotePolicyExecutorOutput(response, microServiceCall);
					responses.add(output);
					context.getConnection().commit();
				} catch (Exception e) {
					PCTLogUtil.logErrorIntoContextLogger(getClass(), "executeService()", new Object[] { microServiceCall.getInstancesToBeMapped(),
							microServiceCall.getRequest() }, e, "Exception while executing service ");
					throw new PCTRuntimeException("Error executing services "+ microServiceCall.getMsBean().getMsRestEndPoint(), e);
				}finally{
					//releaseContext();
				}
			}
		}

	}

	public List<QuotePolicyExecutorOutput> getResponse() {
		return responses;
	}

	public void setResponse(List<QuotePolicyExecutorOutput> responses) {
		this.responses = responses;
	}

}
