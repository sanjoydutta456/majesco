package com.coverall.mic.rest.policy.api.service.quotepolicy.mt;

import com.coverall.pctv2.server.rs.service.microservices.MicroServiceFormat;

public class QuotePolicyExecutorOutput {

	MicroServiceFormat response;
	QuotePolicyAPIExecutorInput input;

	public QuotePolicyExecutorOutput(MicroServiceFormat response, QuotePolicyAPIExecutorInput input) {
		this.response = response;
		this.input = input;
	}

	public MicroServiceFormat getResponse() {
		return response;
	}

	public void setResponse(MicroServiceFormat response) {
		this.response = response;
	}

	public QuotePolicyAPIExecutorInput getInput() {
		return input;
	}

	public void setInput(QuotePolicyAPIExecutorInput input) {
		this.input = input;
	}

}
