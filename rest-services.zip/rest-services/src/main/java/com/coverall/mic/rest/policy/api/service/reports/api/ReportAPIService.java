/**
 * 
 */
package com.coverall.mic.rest.policy.api.service.reports.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.coverall.mic.rest.policy.api.exception.APIException;

/**
 * @author aayush87156
 *
 */
public interface ReportAPIService {
	
	String RESOURCE_TYPE="Report";

	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({ 
		MediaType.APPLICATION_JSON})
	@POST
	Object getReportData() throws APIException;
}
