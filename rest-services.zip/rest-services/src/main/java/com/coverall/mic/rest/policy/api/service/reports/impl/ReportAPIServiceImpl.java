package com.coverall.mic.rest.policy.api.service.reports.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.core.Response;

import org.apache.cxf.helpers.IOUtils;
import org.apache.http.HttpRequest;
import org.codehaus.jackson.map.ObjectMapper;
import org.eclipse.jetty.util.ConcurrentHashSet;
import org.w3c.dom.Document;

import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.forms.model.Forms;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyPagination;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyPaginationLinks;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.reports.api.ReportAPIService;
import com.coverall.mic.rest.policy.api.service.reports.model.ReportRequestDetails;
import com.coverall.mic.rest.policy.api.service.reports.model.ReportResponseDetails;
import com.coverall.mic.rest.policy.api.service.reports.model.RequestFilter;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.pctv2.server.yaml.generation.reports.ReportAPIUtil;
import com.coverall.pctv2.server.yaml.generation.reports.ReportAPIYAMLGenerator;
import com.coverall.pctv2.server.yaml.generation.reports.model.ReportBean;
import com.coverall.pctv2.server.yaml.generation.reports.model.ReportBeanColumnSpecifics;
import com.coverall.pctv2.server.yaml.generation.reports.model.ReportToProcess;
import com.coverall.portal.data.ListDataObject;
import com.coverall.mt.http.HTTPConstants;
import com.coverall.mt.http.User;
import com.coverall.mt.lists.IDataList;
import com.coverall.mt.soa.ListService;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.ReportDOMUtil;
import com.sun.xml.xsom.impl.scd.Iterators.Array;


public class ReportAPIServiceImpl implements ReportAPIService {
	private String apiEndPoint;
	private User user;
	private HttpServletRequest request;
	private int pageNumber;
	private int pageSize;
	private String countOnly;


	private String uniqueIdentifier;


	public ReportAPIServiceImpl(String apiEndPoint, HttpServletRequest request,int pageNumber,int pageSize,String countOnly){
		super();
		this.apiEndPoint = apiEndPoint;
		this.request=request;
		this.user=User.getUser(request);
		this.countOnly=countOnly;
		//Generating ID for the report
		this.uniqueIdentifier=ReportAPIUtil.getReportUniqueIdentifier(user, apiEndPoint);
		this.pageNumber=pageNumber;
		this.pageSize=pageSize;
	}

	@Override
	public Object getReportData() throws APIException {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		ReportRequestDetails requestDetails=null;
		ReportResponseDetails responseDetail=null;
		
		final CustomerConfigUtil ccu = CustomerConfigUtil.getInstance();
		String customerCodeString=ccu.getCustomerCode(user.getDomain());
		
		ConcurrentHashMap<String, Boolean> reportgenerationStatus=ReportAPIYAMLGenerator.reportAPIYAMLStatus;
		if(reportgenerationStatus!=null){
			boolean cacheCompleted=false;
			if(reportgenerationStatus.containsKey(customerCodeString.toUpperCase())){
				if(reportgenerationStatus.get(customerCodeString.toUpperCase())){
					cacheCompleted=true;
				}
			}	
			if(!cacheCompleted) {	
				String errMsg = "Report API Cache generatation is not yet completed for "+customerCodeString+". Please try after some time.";
				List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.FORBIDDEN.getStatusCode());
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
		}
	
		try {
			ObjectMapper mapper=new ObjectMapper();
			String inputJson=APIOperationUtil.fetchRequestBody(request);
			requestDetails=mapper.readValue(inputJson, ReportRequestDetails.class);
		}catch(Exception exp){
			String errMsg = "Invalid JSON. Please provide a proper input JSON as per request specification.";
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,exp);
		}

		ConcurrentHashSet<ReportToProcess> reportsToProcess=ReportAPIYAMLGenerator.generatedCachedReports.get(uniqueIdentifier);
		if(reportsToProcess==null || reportsToProcess.size()==0){
			try{
				reportsToProcess=ReportAPIUtil.populateReportToProcessObject(requestContext.getConnection(),user,apiEndPoint);
			}catch(Exception exp){
				String errMsg = exp.getMessage();
				List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,exp);
			}
			if(!reportsToProcess.isEmpty()){
				ReportAPIYAMLGenerator.generatedCachedReports.put(uniqueIdentifier, reportsToProcess);
			}
		}
		if(reportsToProcess.size()==0){
			String errMsg = "There is no report configured for endpoint: "+apiEndPoint+"";
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}else{
			responseDetail=new ReportResponseDetails();
			ArrayList<Map<String,Object>> dataList=new ArrayList<Map<String,Object>>();
			responseDetail.setReportData(dataList);

			for(ReportToProcess report:reportsToProcess){
				try{
					initializeRequestParametersFromInputRequest(report, requestDetails);
					ReportBean reportBean=report.getReportBean();
					
					IDataList dl=ReportAPIUtil.getListDataForAPI(user, report.getRequestParams(),report.getComponent(),reportBean.getReportDocument());
					if (!"Y".equalsIgnoreCase(countOnly)) {
						for (int i = 0; i < dl.getRowCount(); i++) {
							HashMap<String, Object> row = new HashMap<String, Object>();
							for (int j = 0; j < dl.getColumns().size(); j++) {
								ReportBeanColumnSpecifics columnSpecific = reportBean.getDbColumnSpecificMap().get(dl.getColumns().get(j).toString());
								if (columnSpecific.getColumnHeader() != null && !columnSpecific.isHiddenForApi()) {
									Object formattedValue = ReportAPIUtil.formatAndOrganizeDataAsPerReport(dl.getValue(i, j), columnSpecific);
									row.put(columnSpecific.getApiColumnHeader(), formattedValue != null ? formattedValue.toString().trim() : formattedValue);
								}
							}
							dataList.add(row);
						}
					} else {
						int reportCount = responseDetail.getReportCount();
						responseDetail.setReportCount((dl.getRowCount()+ reportCount));
					}
				}catch(APIException exp){
					throw exp;
				}catch(Exception exp){
					String errMsg = "Failed while fetching data for the report associated with : "+apiEndPoint+"";
					List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
					String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
					throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,exp);

				}
			}
			if (!"Y".equalsIgnoreCase(countOnly)) {
				responseDetail.setReportCount(dataList.size());
			}
			responseDetail.setSortColumn(requestDetails.getSortColumn());
			responseDetail.setSortOrder(responseDetail.getSortOrder().valueOf(requestDetails.getSortOrder().toString()));
			responseDetail.setEffectiveEndDateRange(requestDetails.getEffectiveEndDateRange());
			responseDetail.setEffectiveStartDateRange(requestDetails.getEffectiveStartDateRange());
			
			if("Y".equalsIgnoreCase(countOnly)){
				responseDetail.setReportData(null);
				responseDetail.setPagination(null);
				return responseDetail;
			}

		}
		
		//logic for applying pagination
		if(pageNumber>0 && pageSize>0){
			populatePaginationObject(responseDetail, pageNumber, pageSize);
		}
		return responseDetail;
	}

	private void initializeRequestParametersFromInputRequest(ReportToProcess report,ReportRequestDetails requestDetail) throws APIException{
		HashMap<String,String> inputParameters=new HashMap<String, String>();
		try{
			String formattedEffectiveStartDateString=ReportAPIUtil.convertDateToSpecifiedFormat(requestDetail.getEffectiveStartDateRange(), ReportAPIUtil.UTC_DATE_FORMAT,ReportAPIUtil.REPORT_SPECIFIC_DATE_FORMAT);
			String formattedEffectiveEndDateString=ReportAPIUtil.convertDateToSpecifiedFormat(requestDetail.getEffectiveEndDateRange(), ReportAPIUtil.UTC_DATE_FORMAT,ReportAPIUtil.REPORT_SPECIFIC_DATE_FORMAT);
			inputParameters.put("effectiveDateStart", formattedEffectiveStartDateString);
			inputParameters.put("effectiveDateEnd", formattedEffectiveEndDateString);
		}catch(Exception exp){
			String errMsg = exp.getMessage();
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,exp);
		}

		if(requestDetail.getSortColumn()!=null){
			for(String dbColumnName:report.getReportBean().getDbColumnSpecificMap().keySet()){
				ReportBeanColumnSpecifics columnSpecific=report.getReportBean().getDbColumnSpecificMap().get(dbColumnName);
				if(requestDetail.getSortColumn().equalsIgnoreCase(columnSpecific.getApiColumnHeader())){
					inputParameters.put(HTTPConstants.REQUEST_SORT_BY, columnSpecific.getId());
					break;
				}
			}
		}
		inputParameters.put(HTTPConstants.REQUEST_SORT_ORDER,requestDetail.getSortOrder().toString());

		if(requestDetail.getAdditionalFilters()!=null){
			for(RequestFilter filter:requestDetail.getAdditionalFilters()){
				if("DATE".equalsIgnoreCase(filter.getFilterFormat().toString())){
					try{	
						String formattedDate=ReportAPIUtil.convertDateToSpecifiedFormat(filter.getFilterValue(), ReportAPIUtil.UTC_DATE_FORMAT,ReportAPIUtil.REPORT_SPECIFIC_DATE_FORMAT);	
						inputParameters.put(filter.getFilterColumn(),formattedDate);
					}catch(Exception exp){
						String errMsg = exp.getMessage();
						List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
						String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
						throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,exp);
					}
				}else{
					inputParameters.put(filter.getFilterColumn(),filter.getFilterValue());
				}
			}
		}
		
		inputParameters.put(HTTPConstants.REQUEST_EXPORTING, ReportDOMUtil.VALUE_YES);
		inputParameters.put(HTTPConstants.REQUEST_REPORT_XML,report.getReportXML());
		inputParameters.put(HTTPConstants.REPORT_API_CALL,ReportDOMUtil.VALUE_YES);

		if("Y".equalsIgnoreCase(countOnly) && report.getRequestParams() != null){
			inputParameters.put(HTTPConstants.SKIP_EXECUTION, "true");
			inputParameters.put(HTTPConstants.COUNT_EXECUTION, "true");
		}
		report.setRequestParams(inputParameters);
	}

	private void populatePaginationObject(ReportResponseDetails responseDetail,int pageNumber, int pageSize){
		String url = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getRequestURI()+"?"+request.getQueryString();
		QuotePolicyPagination pagination=new QuotePolicyPagination();
		int totalCount=responseDetail.getReportData().size();
		int lastPageNumber=0;
		int startIndex=0;
		int endIndex=0;
		if(totalCount!=0){
			startIndex=(pageNumber==1?0:((pageNumber-1)*pageSize));
			endIndex=(startIndex+pageSize)-1;	
			lastPageNumber=(int) Math.ceil((totalCount*1.0/pageSize));

			if(startIndex>totalCount && endIndex>totalCount){
				endIndex=0;
				startIndex=0;
			}

			if(startIndex>totalCount){
				startIndex=0;
			}

			if(endIndex>=totalCount){
				endIndex=totalCount-1;
			}
			pagination.setTotalRecords(totalCount+"");
			pagination.setStartIndex(startIndex+"");
			pagination.setEndIndex(endIndex+"");
			pagination.setPageSize(pageSize+"");
			pagination.setLastPageNumber(lastPageNumber+"");
			pagination.setPageNumber(pageNumber+"");

			ArrayList<QuotePolicyPaginationLinks> links=new ArrayList<QuotePolicyPaginationLinks>();
			links.add(APIOperationUtil.populateLinksForPaginationResult(url, totalCount, pageSize, pageNumber));
			pagination.setLinks(links);
			
			responseDetail.setPagination(pagination);
			
			//Filter results as per the pagination information
			ArrayList<Map<String, Object>> paginatedList=new ArrayList<Map<String,Object>>();
			for(int i=startIndex;i<=endIndex;i++){
				paginatedList.add(responseDetail.getReportData().get(i));
			}
			responseDetail.setReportData(paginatedList);
			
		}
		
		
		
	}
}
