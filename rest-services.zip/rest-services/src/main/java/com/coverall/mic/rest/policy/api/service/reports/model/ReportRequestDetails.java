package com.coverall.mic.rest.policy.api.service.reports.model;

import java.util.List;

public class ReportRequestDetails {
	
	private String sortColumn;
	
	public enum SortOrderValues{
		ASC, DESC
	}
	
	private SortOrderValues sortOrder=SortOrderValues.ASC;
	private String effectiveStartDateRange;
	private String effectiveEndDateRange;
	private String sourceSystemUserId;
	private String sourceSystemCode;
	private long sourceSystemRequestNo;
	private List<RequestFilter> additionalFilters;
	
	public String getSortColumn() {
		return sortColumn;
	}
	public void setSortColumn(String sortColumn) {
		this.sortColumn = sortColumn;
	}
	public SortOrderValues getSortOrder() {
		return sortOrder;
	}
	public void setSortOrder(SortOrderValues sortOrder) {
		this.sortOrder = sortOrder;
	}
	public String getEffectiveStartDateRange() {
		return effectiveStartDateRange;
	}
	public void setEffectiveStartDateRange(String effectiveStartDateRange) {
		this.effectiveStartDateRange = effectiveStartDateRange;
	}
	public String getEffectiveEndDateRange() {
		return effectiveEndDateRange;
	}
	public void setEffectiveEndDateRange(String effectiveEndDateRange) {
		this.effectiveEndDateRange = effectiveEndDateRange;
	}
	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}
	public void setSourceSystemUserId(String sourceSystemUserId) {
		this.sourceSystemUserId = sourceSystemUserId;
	}
	public String getSourceSystemCode() {
		return sourceSystemCode;
	}
	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}
	public long getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}
	public void setSourceSystemRequestNo(long sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}
	public List<RequestFilter> getAdditionalFilters() {
		return additionalFilters;
	}
	public void setAdditionalFilters(List<RequestFilter> additionalFilters) {
		this.additionalFilters = additionalFilters;
	}
}
