package com.coverall.mic.rest.policy.api.service.reports.model;

import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.coverall.mic.rest.policy.api.service.model.QuotePolicyPagination;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class ReportResponseDetails {
	
	private int reportCount;
	public enum SortOrderValues{
		ASC, DESC
	}
	
	private SortOrderValues sortOrder;
	private String sortColumn;
	private String effectiveStartDateRange;
	private String effectiveEndDateRange;
	private List<Map<String,Object>> reportData;
	private QuotePolicyPagination pagination;
	public int getReportCount() {
		return reportCount;
	}
	public void setReportCount(int reportCount) {
		this.reportCount = reportCount;
	}
	public SortOrderValues getSortOrder() {
		return sortOrder;
	}
	public void setSortOrder(SortOrderValues sortOrder) {
		this.sortOrder = sortOrder;
	}
	public String getSortColumn() {
		return sortColumn;
	}
	public void setSortColumn(String sortColumn) {
		this.sortColumn = sortColumn;
	}
	public String getEffectiveStartDateRange() {
		return effectiveStartDateRange;
	}
	public void setEffectiveStartDateRange(String effectiveStartDateRange) {
		this.effectiveStartDateRange = effectiveStartDateRange;
	}
	public String getEffectiveEndDateRange() {
		return effectiveEndDateRange;
	}
	public void setEffectiveEndDateRange(String effectiveEndDateRange) {
		this.effectiveEndDateRange = effectiveEndDateRange;
	}
	public List<Map<String, Object>> getReportData() {
		return reportData;
	}
	public void setReportData(List<Map<String, Object>> reportData) {
		this.reportData = reportData;
	}
	public QuotePolicyPagination getPagination() {
		return pagination;
	}
	public void setPagination(QuotePolicyPagination pagination) {
		this.pagination = pagination;
	}
}
