package com.coverall.mic.rest.policy.api.service.reports.model;

public class RequestFilter {
	
	private String filterColumn;
	private String filterValue;
	
	
	public enum  FilterFormatValues {
		 STRING, NUMBER, DATE 
	}
	
	private FilterFormatValues filterFormat=FilterFormatValues.STRING;
	
	public String getFilterColumn() {
		return filterColumn;
	}
	public void setFilterColumn(String filterColumn) {
		this.filterColumn = filterColumn;
	}
	public String getFilterValue() {
		return filterValue;
	}
	public void setFilterValue(String filterValue) {
		this.filterValue = filterValue;
	}
	public FilterFormatValues getFilterFormat() {
		return filterFormat;
	}
	public void setFilterFormat(FilterFormatValues filterFormat) {
		this.filterFormat = filterFormat;
	}

}
