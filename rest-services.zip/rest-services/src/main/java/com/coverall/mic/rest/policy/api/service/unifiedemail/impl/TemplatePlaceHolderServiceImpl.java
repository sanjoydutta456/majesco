package com.coverall.mic.rest.policy.api.service.unifiedemail.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Collections;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import javax.ws.rs.core.Response;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.model.common.Message;

import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.unifiedemail.TemplatePlaceHolderService;
import com.coverall.mt.http.User;
import com.coverall.mt.security.Principal;
import com.coverall.mt.security.AdminX;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.portal.dao.EmailTemplateXDAO;
import com.coverall.util.DBUtil;

public class TemplatePlaceHolderServiceImpl implements TemplatePlaceHolderService {
	
	private HttpServletRequest request;
	private String reference;
	private String referenceType;
	private String templateName;
	private String templateNameId;
	private String sourceSystemUserId;
	public TemplatePlaceHolderServiceImpl(HttpServletRequest request,String reference, String referenceType,String templateName,String sourceSystemUserId) {
		super();
		this.request=request;
		this.reference = reference;
		this.referenceType=referenceType;
		this.templateName=templateName;
		this.sourceSystemUserId=sourceSystemUserId;
	}
	@Override
	public Object getTemplatePlaceholders() throws Exception
	{
		User user = APIRequestContext.getApiRequestContext().getMtUser();
		
		try
		{
			if(templateName.isEmpty()  || templateName.equals("") )
			{
				String errMsg = "Template name is required";
				inValidInput(errMsg);
			}
			
			if(sourceSystemUserId.isEmpty()  || sourceSystemUserId.equals("") )
			{
				String errMsg = "Source System UserId is required";
				inValidInput(errMsg);
			}
			else
			{
				user = APIRequestContext.getApiRequestContext().getSourceSystemUser(sourceSystemUserId);
				if(user.getPrincipal()==null)
				{
					AdminX adminX = new AdminX();
					int index     = sourceSystemUserId.indexOf('@');
					String userId = sourceSystemUserId.substring(0, index);
					String domain = sourceSystemUserId.substring(index + 1);
					Principal principal = adminX.getUser(domain, userId);
					user.setEmailId(principal.getEmail());
				}
				else
				{
					 user.setEmailId(user.getPrincipal().getEmail());
				}
               
			}
			
			if(referenceType.isEmpty()  || referenceType.equals(""))
			{
				String errMsg = "Entity reference type is required";
				inValidInput(errMsg);
			}
			
			if(reference.isEmpty()  || reference.equals(""))
			{
				String errMsg = "Policy entity reference is required";
				inValidInput(errMsg);
			}
			
			HashMap<String,String> emailTemplatesData =  getApplicableTemplates(templateName);
		
			
			if(emailTemplatesData != null ){
	  
			 for(String templateId : emailTemplatesData.keySet()){
	          templateNameId = templateId;
			  break;
		   }
	 }
		 if(templateNameId == null) {
			 String tempalteErrMsg=templateName+" template is not found in policy";
			 resourceNotFound(tempalteErrMsg);
		 }
		 
		 if((referenceType.equalsIgnoreCase("QUOTE")||referenceType.equalsIgnoreCase("POLICY")) && !checkIfPolicyExists(reference))
		 {
			 String policyErrMsg=reference+" policy entity reference does not exist";
			 resourceNotFound(policyErrMsg);
		 }
		 
		 	JSONObject jsonObject = new JSONObject();
		
	      if (templateNameId != null && !reference.isEmpty())
		 {
	    	  HashMap params = new HashMap();
	    	  params.put("WEA_ENTITY_REFERENCE",reference); 
	    	  params.put("entityReference",reference);
	    	  params.put("WEA_ENTITY_TYPE", referenceType);
	    	  params.put("entityType", referenceType);
	    	  EmailTemplateXDAO emailTemplateXDAO = new EmailTemplateXDAO();
	    	  emailTemplateXDAO.initialise(user, templateNameId);
			 try
			 {
				 Map<String,String> unifiedEmailTemplatesData=emailTemplateXDAO.prepareUnifiedEmailPlaceHolder(params, templateNameId); 
			 if(unifiedEmailTemplatesData !=null)
			 {
				 StringBuilder logInfo = new StringBuilder();
				 JSONArray array = new JSONArray();
				 jsonObject.put("parties",array);
				 JSONArray placeHolderArray = new JSONArray();
				 Iterator<Entry<String, String>> it = unifiedEmailTemplatesData.entrySet().iterator();
				 while (it.hasNext()) {
					 Map.Entry<String, String> pair = (Map.Entry<String, String>) it.next();
					 logInfo.append(pair.getKey()+": "+pair.getValue());
					 WebServiceLoggerUtil.logInfo("TemplatePlaceHolderServiceImpl", "getTemplatePlaceholders", logInfo.toString(), new Object[] { logInfo });
					 
					 JSONObject jsonInnerObject = new JSONObject();
					 if(pair.getValue()!= null)
					 {
						 jsonInnerObject.put("value", pair.getValue());
						 jsonInnerObject.put("key", pair.getKey());
						 placeHolderArray.add(jsonInnerObject);
					 }
			 
				 }
				 
				 if(placeHolderArray.size()>0) {
		 			jsonObject.put("placeholders",placeHolderArray);
				 }
				 else
				 {
					 List errorMessageList = new ArrayList<Message>();
			    	 errorMessageList.add("SQL query not defined for template "+templateName);
			    	 String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
			    	 throw new APIException(httpStatusCode,APIConstant.FAILED,errorMessageList
									,new Throwable());
					 
				 }

		 		}
			 } catch(SQLException e)
			 {
				 List errorMessageList = new ArrayList<Message>();
		    	 errorMessageList.add("There is an issue executing the placehoder sql query in policy");
		    	 String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
		    	 throw new APIException(httpStatusCode,APIConstant.FAILED,errorMessageList
								,new Throwable());
			 }
		 }
	      return jsonObject;
	      
	     
		}catch(APIException e)
	     {
			 throw e;
	     }
	     catch(Exception e)
		{
	    	List errorMessageList = new ArrayList<Message>();
	    	errorMessageList.add(e.getMessage());
			throw new APIException(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()), APIConstant.FAILED, errorMessageList,
						new Throwable());
		}
	}
	
	private void inValidInput(String errMsg) {
		List errorMessageList = new ArrayList<Message>();
		errorMessageList.add(errMsg);
		String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
		throw new APIException(httpStatusCode,APIConstant.FAILED,errorMessageList
				,new Throwable());
		
	}
	
	private void resourceNotFound(String errMsg) {
		List errorMessageList = new ArrayList<Message>();
		errorMessageList.add(errMsg);
		String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
		throw new APIException(httpStatusCode,APIConstant.FAILED,errorMessageList
				,new Throwable());
		
	}
	
	public HashMap<String, String> getApplicableTemplates(String templateName)
			throws Exception {
				
		HashMap<String, String> map = new HashMap<String, String>(); 
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		Connection con = null;
		String id = null;
		String name = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		try {
				con=requestContext.getConnection();
				
				String sql = "SELECT mep_id id,mep_name name FROM MIS_EMAIL_TEMPLATES  WHERE upper(MEP_NAME)=?";
				st = con.prepareStatement(sql.toString());
				st.setString(1, templateName.toUpperCase());
				rs = st.executeQuery();
				
				while (rs.next()) {
				id = rs.getString("id");
				name = rs.getString("name");
				if (null != reference  && null != id) {
					if (name.equalsIgnoreCase(templateName)) {
						map.put(id, name);
					}
				}
				}
				
		}
				
				catch (Exception e) {
					throw new Exception("Unexpected error when getting placeholders detail:");
		}finally {
			try {
                DBUtil.close(rs, st, null);                
			} catch (SQLException e) {
				
				//Suppress
			}
		}
		
			return map; 	
	}
	
	public static boolean checkIfPolicyExists( String entityReference ) throws Exception {
		boolean isValidRequest = false;
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		//change table ev_mis_quote_policies
		String sqlQuery = "select decode(count(gid),0,'false','true') isValidRequest from ev_mis_quote_policies  where entity_reference =?";
				
		
		try {
			conn=requestContext.getConnection();
			stmt = conn.prepareStatement(sqlQuery.toString()); 
			stmt.setString(1, entityReference);
			rs = stmt.executeQuery();

			while (rs.next()) {
				isValidRequest =   new Boolean( rs.getString(APIConstant.IS_VALID_REQUEST)).booleanValue();
				
			}


		} catch (SQLException e) {
			 //supress
		} finally {
			

			try {
				DBUtil.close(rs, stmt, null);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return isValidRequest;


	}
	
	
}
