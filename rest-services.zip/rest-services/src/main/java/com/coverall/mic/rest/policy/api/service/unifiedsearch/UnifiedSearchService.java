package com.coverall.mic.rest.policy.api.service.unifiedsearch;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.UnifiedSearchRequest;


@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON , MediaType.MULTIPART_FORM_DATA })
@Produces({ MediaType.APPLICATION_JSON , MediaType.MULTIPART_FORM_DATA, MediaType.APPLICATION_OCTET_STREAM,"application/pdf"})
public interface UnifiedSearchService {

	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@POST
	@Path("search")
	public Object search(@Context HttpServletRequest request) throws Exception;
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@POST
	@Path("getSearchCount")
	public Object getSearchCount(@Context HttpServletRequest request) throws Exception;
	
	@GET
	@Path("ping")
	public String ping();
	
}
