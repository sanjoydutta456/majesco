package com.coverall.mic.rest.policy.api.service.unifiedsearch.impl;


import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.ws.rs.core.Response;

import com.coverall.el.FunctionResolver;
import com.coverall.el.InlineExpression;
import com.coverall.el.QueryWithBindVariables;
import com.coverall.el.VariableResolver;
import com.coverall.el.function.DefaultFunctionResolver;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.UnifiedSearchErrors;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.IEntityResponseData;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.UnifiedCountSearchResponse;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.UnifiedSearchRequest;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.UnifiedSearchResponse;
import com.coverall.mt.dao.QueriesCache;
import com.coverall.mt.el.variable.VariableResolverImpl;
import com.coverall.mt.http.HTTPConstants;
import com.coverall.mt.http.MICSession;
import com.coverall.mt.http.User;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.DOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;
import com.coverall.util.GeneralUtil;
import com.coverall.util.validators.SQLInjectionValidator;

public abstract class AbstractUnifiedEntitySearch implements UnifiedEntitySearch {

	static final String RNUM = "rnum";
	static final String PARAM_USER = "user";
	static final String SEARCH_TYPE = "searchType";
	static final String DISPLAY_MODE = "displayMode";
	static final String SEARCH_VALUE = "searchValue";
	static final String SEARCH_VALUE_ESC = "searchValueEsc";
	static final String WRAPPER_COUNT_QUERY_START = "SELECT COUNT(1) ROW_COUNT FROM ( " ;
	static final String WRAPPER_QUERY_END = ") " ;
	static final String WRAPPER_QUERY_START = "SELECT z.*, ROWNUM "+RNUM+"  FROM ( ";
	static final String WRAPPER_QUERY_WO_RNUM_START = "SELECT *  FROM ( ";
	static final String WRAPPER_QUERY_WO_RNUM_WHERE = ")  WHERE 1 = 1  ";
	static final String WRAPPER_QUERY_WHERE = ") z WHERE 1 = 1 " ;
	static final String WRAPPER_QUERY_AND = " AND ";
	static final String WRAPPER_QUERY_DESC = " DESC ";
	static final String WRAPPER_QUERY_EQUALS = " = ";
	static final String WRAPPER_QUERY_LIKE = " LIKE ";
	static final String WRAPPER_QUERY_PERCENT = "%";
	static final String WRAPPER_QUERY_ORDER_BY = " ORDER BY ";
	static final String DESCENDING = "DESCENDING";
	static final String DESC = "DESC";
	static final String ROWNUM = " ROWNUM ";
	static final String GREATER_THAN = " > ";
	static final String LESS_THAN = " < ";
	static final String LESS_THAN_EQUALS = " <= ";
	static final String GREATER_THAN_EQUALS = " >= ";
	static final String SINGLE_QUOTE = "'";
	
	static final String ENTITY = "ENTITY";
	static final String LINKS_QUERY_ID = "unifiedSearchLinks";
	static final String LINK ="LINK";
	static final String TYPE ="TYPE";
	static final String NAME = "NAME";
	static final String ACTION = "actions";
	static final String NAVIGATIONS = "navigations";
	static final String HOST_PLACEHODLER = "$HOST$";
	static final String ATTR_NAME = "attributeName";
	static final String NAVIGATION_LINK = "navigationLink";
	static final String ACTION_NAME = "actionName";
	static final String ACTION_LINK = "actionLink";
	
	static final String KEY = "key";
	static final String VALUE = "value";
	
	public static ConcurrentHashMap<String,ArrayList<HashMap<String,String>>> commonEntityProperties = new ConcurrentHashMap<String, ArrayList<HashMap<String,String>>>();
	
	public enum searchEntity {
		POLICY,
		INSURED,
		AGENCY,
		CUSTOMER,
		SUBMISSION,
		ACCOUNT
	}
	
	public enum searchQueryType {
		SEARCH,
		COUNT
	}
	
	 public static final Set<String> ESCAPE_CHARS = new HashSet<String>(
				Arrays.asList(new String[] { "&", "=","?","{",
						"}","(",")","-",";","~","|","$","!",">","*","%","_"}));
		
	//&=?{}\()[]-;~|$!>*%_
	public enum searchType {
		CONTAINS("contains"), STARTS_WITH("startsWith");
		private final String searchType;
		private searchType(final String searchType) {
			this.searchType = searchType;
		}
		@Override
		public String toString() {
			return searchType;
		}
		public boolean equals(String tagType) {
			return this.searchType.equalsIgnoreCase(tagType);
		}
	}
	private static String hostURL ;
	
	
	public static String getHostURL() {
		return hostURL;
	}

	public static void setHostURL(String hostURL) {
		AbstractUnifiedEntitySearch.hostURL = hostURL;
	}

	/**
	 * implemented by subclass, should return the query name from queries.xml 
	 * @return
	 */
	public abstract String getQueryName();
	
	protected UnifiedSearchResponse createBasicResponse(UnifiedSearchRequest searchRequest){
		UnifiedSearchResponse basicResponse = new UnifiedSearchResponse();
		basicResponse.setSearchEntityId(searchRequest.getSearchEntityId());
		basicResponse.setSearchType(searchRequest.getSearchType());
		basicResponse.setSearchText(searchRequest.getSearchText());
		basicResponse.setSourceSystemUserId(searchRequest.getSourceSystemUserId());
		basicResponse.setEndIndex(searchRequest.getEndIndex());
		basicResponse.setStartIndex(searchRequest.getStartIndex());
		basicResponse.setSortColumn(searchRequest.getSortColumn());
		basicResponse.setSortOrder(searchRequest.getSortOrder());
		basicResponse.setFilters(searchRequest.getFilters());
		basicResponse.setDisplayMode(searchRequest.getDisplayMode());
		return basicResponse;
	}
	
	protected void  loadCommonEntityProperties(UnifiedSearchRequest searchRequest) {
		//commonEntityProperties.clear();
		if(!commonEntityProperties.isEmpty()){
			// The properties are already loaded
			return ;
		}
		synchronized (commonEntityProperties) {
			if (commonEntityProperties.isEmpty()) {
				QueryWithBindVariables queryWithBindVariables = resolveQueryExpression(searchRequest, LINKS_QUERY_ID);
				ArrayList<HashMap<String, String>> dataRecords = executeQuery(queryWithBindVariables);
				for (HashMap<String, String> row : dataRecords) {
					if (row != null) {
						String entityId = row.get(ENTITY);
						ArrayList<HashMap<String, String>> loadedData = commonEntityProperties.get(entityId);
						if (loadedData == null) {
							ArrayList<HashMap<String, String>> initialRow = new ArrayList<HashMap<String, String>>();
							initialRow.add(row);
							commonEntityProperties.put(entityId, initialRow);
						} else {
							loadedData.add(row);
						}
					}
				}
			}
		}
	}
	
	
	protected UnifiedCountSearchResponse createBasicCountResponse(UnifiedSearchRequest searchRequest){
		UnifiedCountSearchResponse basicResponse = new UnifiedCountSearchResponse();
		basicResponse.setSearchEntityId(searchRequest.getSearchEntityId());
		basicResponse.setSearchType(searchRequest.getSearchType());
		basicResponse.setSearchText(searchRequest.getSearchText());
		basicResponse.setSourceSystemUserId(searchRequest.getSourceSystemUserId());
		basicResponse.setFilters(searchRequest.getFilters());
		return basicResponse;
	}
	
	public static void validateRequest(UnifiedSearchRequest searchRequest){
		
		if(searchRequest.getSearchType().equals(null) || searchRequest.getSearchType().isEmpty()) {
			List <Message> errorMessageList =  new ArrayList<Message>();
			Message message = new Message();
			message.setMoreinfo(APIConstant.MANDATORY_REQUEST_PARAM_SEARCH_TYPE);
			errorMessageList.add(message);
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			throw new APIException(httpStatusCode,APIConstant.FAILED,errorMessageList,new Throwable());
		}
		if(!(searchRequest.getSearchType().equalsIgnoreCase(searchType.STARTS_WITH.toString()) || searchRequest.getSearchType().equalsIgnoreCase(searchType.CONTAINS.toString()))){
			List <Message> errorMessageList =  new ArrayList<Message>();
			Message message = new Message();
			message.setMoreinfo(APIConstant.MANDATORY_REQUEST_ALLOWED_SEARCH_TYPE);
			errorMessageList.add(message);
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			throw new APIException(httpStatusCode,APIConstant.FAILED,errorMessageList,new Throwable());
		}
		if(searchRequest.getSearchText().equals(null) || searchRequest.getSearchText().isEmpty()) {
			List <Message> errorMessageList =  new ArrayList<Message>();
			Message message = new Message();
			message.setMoreinfo(APIConstant.MANDATORY_REQUEST_PARAM_SEARCH_VALUE);
			errorMessageList.add(message);
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,new Throwable());
		}
		if(searchRequest.getSearchText().length() < APIConstant.MANDATORY_REQUEST_ALLOWED_SEARCH_LENGTH) {
			List <Message> errorMessageList =  new ArrayList<Message>();
			Message message = new Message();
			message.setMoreinfo(APIConstant.MANDATORY_REQUEST_PARAM_SEARCH_LENGTH);
			errorMessageList.add(message);
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,new Throwable());
		}
		if (searchRequest.getSearchText().length() > APIConstant.MANDATORY_REQUEST_ALLOWED_MAX_SEARCH_LENGTH) {
			List<Message> errorMessageList = new ArrayList<Message>();
			Message message = new Message();
			message.setMoreinfo(APIConstant.MANDATORY_REQUEST_PARAM_MAX_SEARCH_LENGTH);
			errorMessageList.add(message);
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, new Throwable());
		}
		if(searchRequest.getSearchEntityId() == null || "null".equalsIgnoreCase(searchRequest.getSearchEntityId()) || searchRequest.getSearchEntityId().isEmpty()) {
			List <Message> errorMessageList =  new ArrayList<Message>();
			Message message = new Message();
			message.setMoreinfo(APIConstant.MANDATORY_REQUEST_PARAM_SEARCH_ENTITY);
			errorMessageList.add(message);
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			throw new APIException(httpStatusCode,APIConstant.FAILED,errorMessageList,new Throwable());
		}
		if (  searchRequest.getStartIndex() != null  && searchRequest.getEndIndex() != null 
				&& ( searchRequest.getStartIndex() <= 0 || searchRequest.getEndIndex() <= 0 )) {
			List<Message> errorMessageList = new ArrayList<Message>();
			Message message = new Message();
			message.setMoreinfo(APIConstant.MANDATORY_REQUEST_PARAM_INDEX_VALUE);
			errorMessageList.add(message);
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, new Throwable());
		}
		
	}
	
	public static UnifiedEntitySearch getSearchImpl(UnifiedSearchRequest searchRequest) {
		UnifiedEntitySearch searchImpl = null;
		validateRequest(searchRequest);
		if(searchEntity.POLICY.toString().equalsIgnoreCase(searchRequest.getSearchEntityId())){
			searchImpl =  new PolicyEntitySearch();
		}else if (searchEntity.AGENCY.toString().equalsIgnoreCase(searchRequest.getSearchEntityId())){
			searchImpl =  new AgencyEntitySearch();
		}else if(searchEntity.INSURED.toString().equalsIgnoreCase(searchRequest.getSearchEntityId())){
			searchImpl =  new InsuredEntitySearch();
		}else if(searchEntity.CUSTOMER.toString().equalsIgnoreCase(searchRequest.getSearchEntityId())){
			searchImpl =  new CustomerEntitySearch();
		}else if(searchEntity.SUBMISSION.toString().equalsIgnoreCase(searchRequest.getSearchEntityId())){
			searchImpl =  new SubmissionEntitySearch();
		}else if(searchEntity.ACCOUNT.toString().equalsIgnoreCase(searchRequest.getSearchEntityId())){
			searchImpl =  new BillingAccountEntitySearch();
		}else{
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			String errMsg = UnifiedSearchErrors.errors.INVALID_ENTITY_ID.getErrorMessage();
			WebServiceLoggerUtil.logInfo("AbstractUnifiedEntitySearch", "getSearchImpl", errMsg, new Object[] { errMsg });
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}
		
		return searchImpl;
	}
	
	
	/**
	 * @param searchRequest
	 * @param queryType
	 * @return
	 */
	protected ArrayList<HashMap<String, String>> searchRecords(UnifiedSearchRequest searchRequest,searchQueryType queryType) {
		QueryWithBindVariables queryWithBindVariables = new QueryWithBindVariables();
		loadCommonEntityProperties(searchRequest);
		ArrayList<HashMap<String, String>> dataList = new ArrayList<HashMap<String, String>>();
		String query = null;
		if(searchQueryType.SEARCH.equals(queryType)){
			queryWithBindVariables = generateQueryWithFilters(searchRequest);
		}else if (searchQueryType.COUNT.equals(queryType)){
			queryWithBindVariables = generateQueryWithCount(searchRequest);
		}
		dataList = executeQuery(queryWithBindVariables);
		return dataList;
	}
	
	private ArrayList<HashMap<String, String>> executeQuery(QueryWithBindVariables queryWithBindVariables){
		String query = queryWithBindVariables.getQuery();
		List<String> bindVariableList = queryWithBindVariables.getBindVariablesValues();
		
		ArrayList<HashMap<String, String>> dataList = new ArrayList<HashMap<String, String>>();
		Connection conn = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		HashMap<String, String> row = null;
		try {
			conn = APIRequestContext.getApiRequestContext().getConnection();
			statement = conn.prepareStatement(query);
			
			if (!((null == bindVariableList) || (bindVariableList.isEmpty()) || ((bindVariableList.size()) == 0))) {
				GeneralUtil.bindVariablesToStatement(bindVariableList, statement, 0);
			}
			
			WebServiceLoggerUtil.logInfo("AbstractUnifiedEntitySearch", "executeQuery", query, new Object[] { query, bindVariableList });
			
			rs = statement.executeQuery();
			if (rs != null) {
				ResultSetMetaData rsmd = rs.getMetaData();
				while (rs.next()) {
					row = new HashMap<String, String>();
					int columnCount = rsmd.getColumnCount();
					for (int i = 1; i <= columnCount; i++) {
						String columnName = rsmd.getColumnName(i);
						row.put(columnName.toUpperCase(), rs.getString(columnName));
					}
					dataList.add(row);
				}
			}
		} 
        catch(SQLException e)
        {
                
                  if (e.getErrorCode() == 29902)
                  {
                		WebServiceLoggerUtil.logError("AbstractUnifiedEntitySearch", "executeQuery","Too many records found", new Object[] { query, bindVariableList, conn }, e);
                		throw new APIException("Too many records found. Please change the filter criteria", APIConstant.FAILED,getErrorMessageList(Collections.singletonList("Too many records found. Please change the filter criteria")),e);
	            	 
                  }else{
                	  
                	  WebServiceLoggerUtil.logError("AbstractUnifiedEntitySearch", "executeQuery", e.getLocalizedMessage(), new Object[] { query, bindVariableList, conn }, e);
          			  throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);

                  }
                  //System.out.println("SQL Exception -> Error Code -> " + se.getErrorCode()) ;
        }

		catch (Exception e) {
			WebServiceLoggerUtil.logError("AbstractUnifiedEntitySearch", "executeQuery", e.getLocalizedMessage(), new Object[] { query, bindVariableList, conn }, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);

		}
		finally {
			try {
                DBUtil.close(rs, statement, null);                
			} catch (SQLException e) {
				WebServiceLoggerUtil.logError("AbstractUnifiedEntitySearch", "executeQuery", e.getLocalizedMessage(), new Object[] { query, bindVariableList, conn }, e);
				throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);
			}
		}
		return dataList;
	}
	
	protected QueryWithBindVariables generateQueryWithCount(UnifiedSearchRequest searchRequest){
		QueryWithBindVariables queryWithBindVariables = new QueryWithBindVariables();
		String query = "";
		if ( searchRequest.getFilters() != null && !searchRequest.getFilters().isEmpty()) {
			queryWithBindVariables = generateQueryWithFilters(searchRequest);
		} else {
			queryWithBindVariables = resolveQueryExpression(searchRequest, null);
		}
		StringBuffer  wrapperCountQuery = new StringBuffer();
		wrapperCountQuery.append(WRAPPER_COUNT_QUERY_START);
		wrapperCountQuery.append(queryWithBindVariables.getQuery());
		wrapperCountQuery.append(WRAPPER_QUERY_END);
		
		queryWithBindVariables.setQuery(wrapperCountQuery.toString());
		
		return queryWithBindVariables;
	}
	
	protected QueryWithBindVariables generateQueryWithFilters(UnifiedSearchRequest searchRequest){
		QueryWithBindVariables queryWithBindVariables = resolveQueryExpression(searchRequest, null);
		
		try {
			String query = queryWithBindVariables.getQuery();
			List<String> bindVariableList = queryWithBindVariables.getBindVariablesValues();
			
			if (null == bindVariableList) {
				bindVariableList = new ArrayList<String>();
			}
			
			String sortOrder  = searchRequest.getSortOrder();
			String sortColumn = searchRequest.getSortColumn();
			Long startIndex = searchRequest.getStartIndex(); 
			Long endIndex = searchRequest.getEndIndex();
			ArrayList<HashMap> additionalFiltersList = searchRequest.getFilters();
			
			StringBuffer  wrapperQuery = new StringBuffer();
			StringBuffer  rownumWrapperQuery = new StringBuffer(); 
			StringBuffer  rownumEndIndexWrapperQuery = null; 
			
			wrapperQuery.append(WRAPPER_QUERY_WO_RNUM_START);
			wrapperQuery.append(query);
			wrapperQuery.append(WRAPPER_QUERY_WO_RNUM_WHERE);
			if (additionalFiltersList != null && !additionalFiltersList.isEmpty()) {
				for (HashMap additionalFilters : additionalFiltersList) {
					if (additionalFilters != null && !additionalFilters.isEmpty()) {
						String key = null;
						String value = null;
						if (additionalFilters.containsKey(KEY)) {
							key = additionalFilters.get(KEY).toString();
						} else if (key == null && additionalFilters.containsKey(KEY.toUpperCase())) {
							key = additionalFilters.get(KEY.toUpperCase()).toString();
						}
						if (additionalFilters.containsKey(VALUE)) {
							value = additionalFilters.get(VALUE).toString();
						} else if (key == null && additionalFilters.containsKey(VALUE.toUpperCase())) {
							value = additionalFilters.get(VALUE.toUpperCase()).toString();
						}
						
						if(key != null && value != null){
							validateAdvancedFilter(key);
						}

						if (key != null && value != null && !canSkipTheFilter(key)) {
							SQLInjectionValidator.validateColumnName(key);
							bindVariableList.add(WRAPPER_QUERY_PERCENT + value + WRAPPER_QUERY_PERCENT);
							
							wrapperQuery.append(WRAPPER_QUERY_AND);
							wrapperQuery.append(key);
							wrapperQuery.append(WRAPPER_QUERY_LIKE);
							wrapperQuery.append("?");						
						}
					}
				}
			}
			if(sortColumn != null){
				SQLInjectionValidator.validateColumnName(sortColumn);
				validateSortByColumn(sortColumn);
				wrapperQuery.append(WRAPPER_QUERY_ORDER_BY);
				wrapperQuery.append(sortColumn);
				if(DESCENDING.equalsIgnoreCase(sortOrder) || DESC.equalsIgnoreCase(sortOrder)){
					wrapperQuery.append(WRAPPER_QUERY_DESC);
				}
			}
			if(startIndex != null || endIndex != null ){
				if(endIndex != null){
					rownumEndIndexWrapperQuery = new StringBuffer();
					rownumEndIndexWrapperQuery.append(WRAPPER_QUERY_START);
					rownumEndIndexWrapperQuery.append(wrapperQuery);
					rownumEndIndexWrapperQuery.append(WRAPPER_QUERY_WHERE);
					rownumEndIndexWrapperQuery.append(WRAPPER_QUERY_AND);
					rownumEndIndexWrapperQuery.append(ROWNUM);
					rownumEndIndexWrapperQuery.append(LESS_THAN_EQUALS);
					rownumEndIndexWrapperQuery.append("?");
					wrapperQuery = rownumEndIndexWrapperQuery;
					
					bindVariableList.add(String.valueOf(endIndex));
				}else if(startIndex != null){
					rownumEndIndexWrapperQuery = new StringBuffer();
					rownumEndIndexWrapperQuery.append(WRAPPER_QUERY_START);
					rownumEndIndexWrapperQuery.append(wrapperQuery);
					rownumEndIndexWrapperQuery.append(WRAPPER_QUERY_WHERE);
					wrapperQuery = rownumEndIndexWrapperQuery;
				}
				
				if(startIndex != null){
					rownumWrapperQuery.append(WRAPPER_QUERY_WO_RNUM_START);
					rownumWrapperQuery.append(wrapperQuery);
					rownumWrapperQuery.append(WRAPPER_QUERY_WO_RNUM_WHERE);
					rownumWrapperQuery.append(WRAPPER_QUERY_AND);
					rownumWrapperQuery.append(RNUM);
					rownumWrapperQuery.append(GREATER_THAN_EQUALS);
					rownumWrapperQuery.append("?");
					
					bindVariableList.add(String.valueOf(startIndex));
					
					return (new QueryWithBindVariables((rownumWrapperQuery.toString()), true, bindVariableList, null));
				}
			}
			
			WebServiceLoggerUtil.logInfo("generateQueryWithFilters", " Query Generated After Filter", new Object[] { wrapperQuery.toString(), searchRequest});
			
			return (new QueryWithBindVariables((wrapperQuery.toString()), true, bindVariableList, null));
		} catch (Exception e) {
			String errorMessage = "Abstract Unified Entity Search query with Filters creation failed. Error while validating Filters: ";
			
			if (null != (e.getLocalizedMessage())) {
				if ((e.getLocalizedMessage()).contains("It should only contain alphabets, numbers, or one of the following special characters")) {
					errorMessage = errorMessage + "Invalid Input value found";
				}
			}
			
			WebServiceLoggerUtil.logError("AbstractUnifiedEntitySearch", "generateQueryWithFilters", errorMessage, new Object[] {}, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);
		}
	}
	

	public QueryWithBindVariables resolveQueryExpression(UnifiedSearchRequest searchRequest, String queryId) {
		User user = APIRequestContext.getApiRequestContext().getMtUser();
		if(queryId == null){
		   queryId = getQueryName();
		}
		String sqlQuery = null;
		HashMap variableMap = new HashMap();
		try {
			/*DAOManager daoManager = DAOManager.getInstance(ServletConfigUtil.COMPONENT_PORTAL);
			Query query = daoManager.getQuery(ServletConfigUtil.COMPONENT_PORTAL, user, queryId);
			if(query == null){
				Exception apiException  = new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,null,null);
				WebServiceLoggerUtil.logError("AbstractUnifiedEntitySearch", "resolveQueryExpression", "Query not found in queries.xml file" , new Object[] {queryId},apiException);
				throw new APIException();
			}
			sqlQuery = query.toString();*/
			String customerCode = CustomerConfigUtil.getInstance().getCustomerCode(user.getDomain());
			sqlQuery = QueriesCache.getUnifiedSearchQueries(customerCode + "_" + queryId);
			if(sqlQuery == null || sqlQuery.length() == 0 ){
				Exception apiException  = new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,null,null);
				WebServiceLoggerUtil.logError("AbstractUnifiedEntitySearch", "resolveQueryExpression", "Query not found in queries.xml file" , new Object[] {queryId},apiException);
				throw new APIException();
			}
			Random randomizer = new Random();
			MICSession session = new MICSession(randomizer.nextInt() + "", null);
			if(searchRequest.getSourceSystemUserId() != null){
			  User simulatedUser = getSimulatedUser(searchRequest.getSourceSystemUserId());
			  if(simulatedUser != null){
				  user = simulatedUser;  
			  }else{
				  WebServiceLoggerUtil.logError("AbstractUnifiedEntitySearch", "resolveQueryExpression","simulatedUser is null, using the autheticated user", new Object[] {}, new Exception());
			  }
			}
			WebServiceLoggerUtil.logInfo("AbstractUnifiedEntitySearch","resolveQueryExpression", "User gettng used for DLS filter", new Object[] {user});
			// Provide Additional Filters in parameters
			
			HashMap params = new HashMap();
			params.put(PARAM_USER, user);
			params.put("domain", user.getDomain());
			params.put("userName", user.getUserId());
			params.put(ServletConfigUtil.COMPONENT, "portal");
			if (searchType.CONTAINS.toString().equalsIgnoreCase(searchRequest.getSearchType())) {
				params.put(SEARCH_TYPE, searchType.CONTAINS.toString());
			} else {
				params.put(SEARCH_TYPE, searchType.STARTS_WITH.toString());
			}
			String searchText  = searchRequest.getSearchText();
			String searchTextEsc = searchText;
            // Escape for Text Index
			if(searchText!= null && searchEntity.POLICY.toString().equalsIgnoreCase(searchRequest.getSearchEntityId()))
			{
				for(String escapeChar : ESCAPE_CHARS){
					searchTextEsc = searchTextEsc.replace(escapeChar, "\\"+escapeChar);
				}
				
				
			}
			params.put(SEARCH_VALUE, searchText);
			params.put(SEARCH_VALUE_ESC, searchTextEsc);
			if(searchRequest.getDisplayMode() != null){
				params.put(DISPLAY_MODE, searchRequest.getDisplayMode());
			}
			// Provide Additional Filters in parameters
			ArrayList<HashMap> additionalFiltersList = searchRequest.getFilters();
			if (additionalFiltersList != null && !additionalFiltersList.isEmpty()) {
				for (HashMap additionalFilters : additionalFiltersList) {
					if (additionalFilters != null && !additionalFilters.isEmpty()) {
						String key = null;
						String value = null;
						if (additionalFilters.containsKey(KEY)) {
							key = additionalFilters.get(KEY).toString();
						} else if (key == null && additionalFilters.containsKey(KEY.toUpperCase())) {
							key = additionalFilters.get(KEY.toUpperCase()).toString();
						}
						if (additionalFilters.containsKey(VALUE)) {
							value = additionalFilters.get(VALUE).toString();
						} else if (key == null && additionalFilters.containsKey(VALUE.toUpperCase())) {
							value = additionalFilters.get(VALUE.toUpperCase()).toString();
						}
						if(key != null && value != null){
							params.put(key, value);
						}
					}
				}
			}
			
			
			variableMap.put(VariableResolverImpl.REQUESTPARAMS_PARAMETER, params);
			session.setAttribute(HTTPConstants.SESSION_USER, user);
			variableMap.put(VariableResolverImpl.SESSION_PARAMETER, session);
			VariableResolver varResolver = new VariableResolverImpl(variableMap);
			FunctionResolver funcResolver = new DefaultFunctionResolver();
			
			try {
				varResolver.setDynamicBind(true);
				
				InlineExpression expression = new InlineExpression(sqlQuery, varResolver, funcResolver);
				
				return (expression.getQueryWithBindVariables());
			} catch (Exception e) {
				e.printStackTrace();
				
				WebServiceLoggerUtil.logError("AbstractUnifiedEntitySearch", "resolveQueryExpression", e.getLocalizedMessage(), new Object[] {queryId , sqlQuery , variableMap}, e);
				throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);
			} finally {
				varResolver.setDynamicBind(false);
			}
		}  catch (Exception e) {
			WebServiceLoggerUtil.logError("AbstractUnifiedEntitySearch", "resolveQueryExpression", e.getLocalizedMessage(), new Object[] {queryId , sqlQuery , variableMap}, e);
			throw new APIException(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()), APIConstant.FAILED,getErrorMessageList(Collections.singletonList(UnifiedSearchErrors.errors.INTERNAL_SERVER.getErrorMessage())),e);
		}
	}
	
	public static List<Message> getErrorMessageList(List<String> strMessages)	{
		if(strMessages == null)	{
			return null;
		}
		List<Message> errorMessageList = new ArrayList<Message>(strMessages.size());
		for(String aMsg : strMessages)	{
			Message message = new Message();
			message.setMoreinfo(aMsg);
			errorMessageList.add(message);
		}
		return errorMessageList;
	}
	
	/**
	 * Create User object for the requested user ID
	 * This can only be done by batchuser, hence creating batchuser object first
	 * @param userId
	 * @return
	 */
	private User getSimulatedUser(String userId){
		User user = null;
		try {
			if(userId != null && userId.indexOf('@') == -1 ){
				userId = userId + "@" + APIRequestContext.getApiRequestContext().getMtUser().getDomain();
			}
			User batchUser = new User(DOMUtil.BATCH_USER + "@" + APIRequestContext.getApiRequestContext().getMtUser().getDomain(),
                    DOMUtil.BATCH_PASSWORD);
            Method mGetSimulatedUser = User.class.getDeclaredMethod("getSimulatedUser", String.class);
            mGetSimulatedUser.setAccessible(true);
            user = (User) mGetSimulatedUser.invoke(batchUser, userId);
        } catch (Exception e) {
        	WebServiceLoggerUtil.logError("AbstractUnifiedEntitySearch", "getSimulatedUser", e.getLocalizedMessage(), new Object[] {userId}, e);
            
        }
		return user;
	}
	
	protected void addNavigationAndAction(IEntityResponseData entityResponseData, UnifiedSearchRequest searchRequest, Map<String, String> dataRow) {
		addNavigationAndAction(entityResponseData, searchRequest, dataRow, false);
	}
	
	
	protected void addNavigationAndAction(IEntityResponseData entityResponseData, UnifiedSearchRequest searchRequest, Map<String, String> dataRow, boolean skipActions) {
		loadCommonEntityProperties(searchRequest);
		ArrayList<HashMap<String, String>> entityProperties = commonEntityProperties.get(searchRequest.getSearchEntityId().toUpperCase());
		ArrayList<HashMap> navigationList = new ArrayList<HashMap>();
		ArrayList<HashMap> actionList = new ArrayList<HashMap>();
		if (entityProperties != null) {
			for (HashMap<String, String> entityMap : entityProperties) {
				boolean addLink = true;
				HashMap<String, String> linkMap = new HashMap<String, String>();
				String link = entityMap.get(LINK);
				// Replace HOST
				if (hostURL != null) {
					link = link.replace(HOST_PLACEHODLER, hostURL);
				}
				// Replace placeholder in the link
				for (String key : dataRow.keySet()) {
					String placeHolder = "$" + key + "$";
					if (link != null && link.indexOf(placeHolder) != -1) {
						if(dataRow.get(key) == null){
							// Do not add link
							addLink = false;
						}else{
						  link = link.replace(placeHolder, dataRow.get(key));
						}
					}
				}

				if(!addLink){
					continue;
				}
				String name = entityMap.get(NAME);
				
				if (ACTION.equalsIgnoreCase(entityMap.get(TYPE))  && !skipActions) {
					linkMap.put(ACTION_NAME, name);
					linkMap.put(ACTION_LINK, link);
					ArrayList<HashMap> exitsingActionList = entityResponseData.getActions();
					if (exitsingActionList != null) {
						exitsingActionList.add(linkMap);
					} else {
						actionList.add(linkMap);
						entityResponseData.setActions(actionList);
					}
				} else if (NAVIGATIONS.equalsIgnoreCase(entityMap.get(TYPE))) {
					linkMap.put(ATTR_NAME, name);
					linkMap.put(NAVIGATION_LINK, link);
					ArrayList<HashMap> exitsingNavigationList = entityResponseData.getNavigations();
					if (exitsingNavigationList != null) {
						exitsingNavigationList.add(linkMap);
					} else {
						navigationList.add(linkMap);
						entityResponseData.setNavigations(navigationList);
					}
				}
			}
		}

	}
	
	protected boolean canSkipTheFilter(String filterColumn){
		return false;
	}
	
	protected void validateAdvancedFilter(String key){
		// Do Nothing
	}
	
	protected void validateSortByColumn(String sortBy){
		//Do Nothing
	}
	
}
