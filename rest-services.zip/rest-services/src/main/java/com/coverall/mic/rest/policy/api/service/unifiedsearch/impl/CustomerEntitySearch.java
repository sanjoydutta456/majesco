package com.coverall.mic.rest.policy.api.service.unifiedsearch.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.core.Response;

import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.CustomerResponseData;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.UnifiedCountSearchResponse;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.UnifiedSearchRequest;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.UnifiedSearchResponse;

public class CustomerEntitySearch extends AbstractUnifiedEntitySearch{

	final static String queryId = "CustomerUnifiedSearch"; 
	
	 public static final Set<String> SORT_BY_COLUMN = new HashSet<String>(
				Arrays.asList(new String[] { "CUSTOMERNUMBER","CUSTOMERNAME","ADDRESS","MODIFIEDON","MODIFIEDBY"}));
	 
	@Override
	public UnifiedSearchResponse searchEntity(UnifiedSearchRequest request) {

		UnifiedSearchResponse unifiedResponse = createBasicResponse(request);
		CustomerResponseData customerData = null;
		ArrayList<Object> customerDatas = new ArrayList<Object>();
		ArrayList<HashMap<String, String>> searchRecords = searchRecords(request, searchQueryType.SEARCH);
		for (Map<String, String> row : searchRecords) {
			customerData = new CustomerResponseData();
			customerData.setCustomerNumber(row.get("CUSTOMERNUMBER"));
			customerData.setCustomerName(row.get("CUSTOMERNAME"));
			customerData.setCity(row.get("CITY"));
			customerData.setState(row.get("STATE"));
			customerData.setCountry(row.get("COUNTRY"));
			customerData.setZipCode(row.get("ZIPCODE"));
			customerData.setCustomerAddress(row.get("ADDRESS"));
			customerData.setModfiedOn(row.get("MODIFIEDON"));
			customerData.setModifiedBy(row.get("MODIFIEDBY"));
			addNavigationAndAction(customerData, request, row);
			customerDatas.add(customerData);
		}
		unifiedResponse.setData(customerDatas);

		return unifiedResponse;
	}

	@Override
	public UnifiedCountSearchResponse getEntityCount(UnifiedSearchRequest request) {

		UnifiedCountSearchResponse countResponse = new UnifiedCountSearchResponse();

		countResponse = createBasicCountResponse(request);
		ArrayList<HashMap<String, String>> searchRecords = searchRecords(request, searchQueryType.COUNT);
		HashMap<String, String> countResult = searchRecords.get(0);
		String rowCount = countResult.get("ROW_COUNT");
		if (rowCount != null) {
			countResponse.setTotalRecords(Long.parseLong(rowCount));
		}
		return countResponse;
	}

	@Override
	public String getQueryName() {
		return queryId;
	}
	
	protected void validateSortByColumn(String sortBy){
		if(sortBy != null ){
			if(!SORT_BY_COLUMN.contains(sortBy.toUpperCase())){
				String errMsg = "Invalid value for SortBy, the request value is not supported for SortBy";
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				throw new APIException(httpStatusCode,APIConstant.FAILED,getErrorMessageList(Collections.singletonList(errMsg))
						,new Throwable());
			}
		}
	}

}
