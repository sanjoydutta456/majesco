package com.coverall.mic.rest.policy.api.service.unifiedsearch.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.core.Response;

import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.InsuredResponseData;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.UnifiedCountSearchResponse;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.UnifiedSearchRequest;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.UnifiedSearchResponse;

public class InsuredEntitySearch extends AbstractUnifiedEntitySearch {

	final static String queryId = "InsuredUnifiedSearch"; 
	
	public static final Set<String> SORT_BY_COLUMN = new HashSet<String>(
				Arrays.asList(new String[] { "INSUREDNAME","ADDRESS","MODIFIEDON","MODIFIEDBY"}));
	 
	@Override
	public UnifiedSearchResponse searchEntity(UnifiedSearchRequest request) {

		UnifiedSearchResponse unifiedResponse = createBasicResponse(request);
		InsuredResponseData insuredData = null;
		ArrayList<Object> agencyDatas = new ArrayList<Object>();
		ArrayList<HashMap<String, String>> searchRecords = searchRecords(request, searchQueryType.SEARCH);
		for (Map<String, String> row : searchRecords) {
			insuredData = new InsuredResponseData();
			insuredData.setInsuredName(row.get("INSUREDNAME"));
			insuredData.setCity(row.get("CITY"));
			insuredData.setState(row.get("STATE"));
			insuredData.setCountry(row.get("COUNTRY"));
			insuredData.setZipcode(row.get("ZIPCODE"));
			insuredData.setInsuredAddress(row.get("ADDRESS"));
			insuredData.setModifiedOn(row.get("MODIFIEDON"));
			insuredData.setModifiedBy(row.get("MODIFIEDBY"));
			addNavigationAndAction(insuredData, request, row);
			agencyDatas.add(insuredData);
		}
		unifiedResponse.setData(agencyDatas);

		return unifiedResponse;
	}

	@Override
	public UnifiedCountSearchResponse getEntityCount(UnifiedSearchRequest request) {

		UnifiedCountSearchResponse countResponse = new UnifiedCountSearchResponse();

		countResponse = createBasicCountResponse(request);
		ArrayList<HashMap<String, String>> searchRecords = searchRecords(request, searchQueryType.COUNT);
		HashMap<String, String> countResult = searchRecords.get(0);
		String rowCount = countResult.get("ROW_COUNT");
		if (rowCount != null) {
			countResponse.setTotalRecords(Long.parseLong(rowCount));
		}
		return countResponse;
	}

	@Override
	public String getQueryName() {
		return queryId;
	}
	
	protected void validateSortByColumn(String sortBy){
		if(sortBy != null ){
			if(!SORT_BY_COLUMN.contains(sortBy.toUpperCase())){
				String errMsg = "Invalid value for SortBy, the request value is not supported for SortBy";
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				throw new APIException(httpStatusCode,APIConstant.FAILED,getErrorMessageList(Collections.singletonList(errMsg))
						,new Throwable());
			}
		}
	}

}
