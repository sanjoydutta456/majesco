package com.coverall.mic.rest.policy.api.service.unifiedsearch.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.core.Response;

import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.PolicyResponseData;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.UnifiedCountSearchResponse;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.UnifiedSearchRequest;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.UnifiedSearchResponse;

public class PolicyEntitySearch extends AbstractUnifiedEntitySearch {
	final static String queryId = "policyUnifiedSearch";
    final static String POLICYEFFDT = "POLICYEFFDT";
	
    public static final Set<String> ADV_FILTER_COLUMNS = new HashSet<String>(
			Arrays.asList(new String[] { "POLICYEFFDT", "ZIPCODE"}));
    
    public static final Set<String> SORT_BY_COLUMN = new HashSet<String>(
			Arrays.asList(new String[] { "AGENCY", "INSUREDNM","INSUREDNAME",
					"POLICYEFFDT","POLICYNUMBER","POLSTATUS","PRODUCT","WRITTENPREMIUM","QUOTEPOLICYINDICATOR","ADDRESS","MODIFIEDON","MODIFIEDBY"}));
	

	@Override
	public String getQueryName() {
		return queryId;
	}

	@Override
	public UnifiedSearchResponse searchEntity(UnifiedSearchRequest request) {
		UnifiedSearchResponse response = createBasicResponse(request);
		PolicyResponseData policyData = null;
		ArrayList<HashMap<String, String>> searchRecords = searchRecords(request, searchQueryType.SEARCH);
		for (Map<String, String> row : searchRecords) {
			policyData = new PolicyResponseData();
			policyData.setAddress(row.get("ADDRESS"));
			policyData.setAgency(row.get("AGENCY"));
			policyData.setInsuredName(row.get("INSUREDNM"));
			policyData.setModifiedOn(row.get("MODIFIEDON"));
            policyData.setModifiedBy(row.get("MODIFIEDBY"));
			policyData.setPolicyEffDt(row.get("POLICYEFFDT"));
			policyData.setPolicyNumber(row.get("POLICYNUMBER"));
			policyData.setPolStatus(row.get("POLSTATUS"));
			policyData.setWrittenPremium(row.get("WRITTENPREMIUM"));
			policyData.setProduct(row.get("PRODUCT"));
			policyData.setQuotePolicyIndicator(row.get("ENTITY_TYPE"));
			policyData.setSourceSystem(row.get("SOURCESYSTEM"));
			policyData.setCustomerName(row.get("CUSTOMERNAME"));
			policyData.setCustomerId(row.get("CUSTOMERID"));
			response.getData().add(policyData);
			// Add action & navigations
			boolean skipAction = false;
			if("QUOTE".equalsIgnoreCase(row.get("ENTITY_TYPE"))){
				//Skip Adding Action for Quotes as we dont sync them with billing and claims
				skipAction = true;
			}
			addNavigationAndAction(policyData, request, row,skipAction);
		}
		
		return response;
	}

	@Override
	public UnifiedCountSearchResponse getEntityCount(UnifiedSearchRequest request) {
		UnifiedCountSearchResponse response = createBasicCountResponse(request);
		ArrayList<HashMap<String, String>> searchRecords = searchRecords(request, searchQueryType.COUNT);
		HashMap<String, String> countResult = searchRecords.get(0);
		String rowCount = countResult.get("ROW_COUNT");
		if (rowCount != null) {
			response.setTotalRecords(Long.parseLong(rowCount));
		}
		// ROW_COUNT
		return response;
	}
	
	@Override
	protected boolean canSkipTheFilter(String filterColumn) {
		/*
		 * Skip the filter for PolicyEffDt field as it is getting handled in the queries.xml
		 */
		if(POLICYEFFDT.equalsIgnoreCase(filterColumn)){
			return true;
		}
		return super.canSkipTheFilter(filterColumn);
	}
	
	
	protected void validateAdvancedFilter(String key){
		if(key != null ){
			if(!ADV_FILTER_COLUMNS.contains(key.toUpperCase())){
				String errMsg = "Invalid filter value, supported filters are :"+ADV_FILTER_COLUMNS.toString().toLowerCase();
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				throw new APIException(httpStatusCode,APIConstant.FAILED,getErrorMessageList(Collections.singletonList(errMsg))
						,new Throwable());
			}
		}
	}
	
	protected void validateSortByColumn(String sortBy){
		if(sortBy != null ){
			if(!SORT_BY_COLUMN.contains(sortBy.toUpperCase())){
				String errMsg = "Invalid value for SortBy, the request value is not supported for SortBy";
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				throw new APIException(httpStatusCode,APIConstant.FAILED,getErrorMessageList(Collections.singletonList(errMsg))
						,new Throwable());
			}
		}
	}

}
