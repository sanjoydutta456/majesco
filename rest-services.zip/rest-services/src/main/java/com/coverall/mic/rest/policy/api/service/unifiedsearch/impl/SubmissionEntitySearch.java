package com.coverall.mic.rest.policy.api.service.unifiedsearch.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.core.Response;

import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.SubmissionResponseData;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.UnifiedCountSearchResponse;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.UnifiedSearchRequest;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.UnifiedSearchResponse;

public class SubmissionEntitySearch extends AbstractUnifiedEntitySearch{


	final static String queryId = "SubmissionUnifiedSearch"; 
	
	public static final Set<String> SORT_BY_COLUMN = new HashSet<String>(
			Arrays.asList(new String[] { "SUBMISSIONNUMBER","CUSTOMERNAME","AGENTNAME","PRODUCT","EFFECTIVEDATE","MODIFIEDON","MODIFIEDBY"}));
	
	@Override
	public UnifiedSearchResponse searchEntity(UnifiedSearchRequest request) {

		UnifiedSearchResponse unifiedResponse = createBasicResponse(request);
		SubmissionResponseData submissionData = null;
		ArrayList<Object> submissionDatas = new ArrayList<Object>();
		ArrayList<HashMap<String, String>> searchRecords = searchRecords(request, searchQueryType.SEARCH);
		for (Map<String, String> row : searchRecords) {
			submissionData = new SubmissionResponseData();
			submissionData.setSubmissionNumber(row.get("SUBMISSIONNUMBER"));
			submissionData.setCustomerName(row.get("CUSTOMERNAME"));
			submissionData.setAgentName(row.get("AGENTNAME"));
			submissionData.setProduct(row.get("PRODUCT"));
			submissionData.setEffectiveDate(row.get("EFFECTIVEDATE"));
			submissionData.setModifiedOn(row.get("MODIFIEDON"));
			submissionData.setModifiedBy(row.get("MODIFIEDBY"));
			addNavigationAndAction(submissionData, request, row);
			submissionDatas.add(submissionData);
		}
		unifiedResponse.setData(submissionDatas);

		return unifiedResponse;
	}

	@Override
	public UnifiedCountSearchResponse getEntityCount(UnifiedSearchRequest request) {

		UnifiedCountSearchResponse countResponse = new UnifiedCountSearchResponse();

		countResponse = createBasicCountResponse(request);
		ArrayList<HashMap<String, String>> searchRecords = searchRecords(request, searchQueryType.COUNT);
		HashMap<String, String> countResult = searchRecords.get(0);
		String rowCount = countResult.get("ROW_COUNT");
		if (rowCount != null) {
			countResponse.setTotalRecords(Long.parseLong(rowCount));
		}
		return countResponse;
	}

	@Override
	public String getQueryName() {
		return queryId;
	}

	protected void validateSortByColumn(String sortBy){
		if(sortBy != null ){
			if(!SORT_BY_COLUMN.contains(sortBy.toUpperCase())){
				String errMsg = "Invalid value for SortBy, the request value is not supported for SortBy";
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				throw new APIException(httpStatusCode,APIConstant.FAILED,getErrorMessageList(Collections.singletonList(errMsg))
						,new Throwable());
			}
		}
	}

}
