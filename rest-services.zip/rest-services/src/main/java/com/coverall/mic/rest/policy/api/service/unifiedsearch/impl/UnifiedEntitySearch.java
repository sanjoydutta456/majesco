package com.coverall.mic.rest.policy.api.service.unifiedsearch.impl;


import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.UnifiedCountSearchResponse;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.UnifiedSearchRequest;
import com.coverall.mic.rest.policy.api.service.unifiedsearch.model.UnifiedSearchResponse;

public interface UnifiedEntitySearch {
	
	
	public UnifiedSearchResponse  searchEntity(UnifiedSearchRequest request);
	
	
	public UnifiedCountSearchResponse getEntityCount(UnifiedSearchRequest request); 
	
	
	

}
