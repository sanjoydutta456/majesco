package com.coverall.mic.rest.policy.api.service.unifiedsearch.model;

import java.util.ArrayList;
import java.util.HashMap;

public class AgencyResponseData implements IEntityResponseData{
	
	public String agencyNumber;
	public String agencyName;
	public String city;
	public String state;
	public String zipcode;
	public String country;
	public String agencyAddress;
	

	ArrayList<HashMap> actions = new ArrayList<HashMap>();
	ArrayList<HashMap> navigations = new ArrayList<HashMap>();
	
	public String getAgencyAddress() {
		return agencyAddress;
	}
	public void setAgencyAddress(String agencyAddress) {
		this.agencyAddress = agencyAddress;
	}
	
	public ArrayList<HashMap> getActions() {	
		return actions;
	}
	public void setActions(ArrayList<HashMap> actions) {
		this.actions = actions;
	}
	public ArrayList<HashMap> getNavigations() {
		return navigations;
	}
	public void setNavigations(ArrayList<HashMap> navigations) {
		this.navigations = navigations;
	}
	public String getAgencyNumber() {
		return agencyNumber;
	}
	public void setAgencyNumber(String agencyNumber) {
		this.agencyNumber = agencyNumber;
	}
	
	public String getAgencyName() {
		return agencyName;
	}
	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
	@Override
	public String toString() {
		return "AgencyResponseData [agencyNumber=" + agencyNumber + ", agencyName=" + agencyName + ", city=" + city + ", country="
				+ country + ", zipcode=" + zipcode + ", state=" + state + ", actions=" + actions + ", navigations=" + navigations + "]";
	}
}
