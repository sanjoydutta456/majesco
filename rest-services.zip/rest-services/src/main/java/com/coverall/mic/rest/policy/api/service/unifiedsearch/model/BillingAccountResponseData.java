package com.coverall.mic.rest.policy.api.service.unifiedsearch.model;

import java.util.ArrayList;
import java.util.HashMap;

public class BillingAccountResponseData implements IEntityResponseData{

	public String accountNumber;
	public String accountName;
	public String city;
	public String state;
	public String zipCode;
	public String country;
	public String accountAddress;
	

	ArrayList<HashMap> actions = new ArrayList<HashMap>();
	ArrayList<HashMap> navigations = new ArrayList<HashMap>();
	
	@Override
	public ArrayList<HashMap> getActions() {
		return actions;
	}
	@Override
	public void setActions(ArrayList<HashMap> actions) {
		this.actions = actions;
	}

	@Override
	public ArrayList<HashMap> getNavigations() {
		return navigations;
	}
	@Override
	public void setNavigations(ArrayList<HashMap> navigations) {
		this.navigations = navigations;
	}
	
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipcode) {
		this.zipCode = zipcode;
	}
	
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getAccountAddress() {
		return accountAddress;
	}
	public void setAccountAddress(String accountAddress) {
		this.accountAddress = accountAddress;
	}
	@Override
	public String toString() {
		return "BillingAccountResponseData [accountNumber=" + accountNumber + ", accountName=" + accountName + ", city=" + city + ", country="
				+ country + ", zipcode=" + zipCode + ", state=" + state + ", actions=" + actions + ", navigations=" + navigations + "]";
	}

}
