package com.coverall.mic.rest.policy.api.service.unifiedsearch.model;

import java.util.ArrayList;
import java.util.HashMap;

public class CustomerResponseData implements IEntityResponseData{

	public String customerNumber;
	public String customerName;
	public String city;
	public String state;
	public String zipCode;
	public String country;
	public String modifiedOn;
	public String modifiedBy;
	public String customerAddress;
	

	
	ArrayList<HashMap> actions = new ArrayList<HashMap>();
	ArrayList<HashMap> navigations = new ArrayList<HashMap>();
	
	@Override
	public ArrayList<HashMap> getActions() {
		return actions;
	}
	@Override
	public void setActions(ArrayList<HashMap> actions) {
		this.actions = actions;
	}

	@Override
	public ArrayList<HashMap> getNavigations() {
		return navigations;
	}
	@Override
	public void setNavigations(ArrayList<HashMap> navigations) {
		this.navigations = navigations;
	}
	
	public String getCustomerNumber() {
		return customerNumber;
	}
	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipcode) {
		this.zipCode = zipcode;
	}
	
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getModfiedOn() {
		return modifiedOn;
	}
	public void setModfiedOn(String modfiedOn) {
		this.modifiedOn = modfiedOn;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modfiedBy) {
		this.modifiedBy = modfiedBy;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}


	@Override
	public String toString() {
		return "CustomerResponseData [customerNumber=" + customerNumber + ", customerName=" + customerName + ", city=" + city + ", country="
				+ country + ", zipcode=" + zipCode + ", state=" + state + ", actions=" + actions + ", navigations=" + navigations + "]";
	}
	
}
