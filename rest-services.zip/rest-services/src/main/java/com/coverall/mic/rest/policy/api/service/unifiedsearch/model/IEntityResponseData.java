package com.coverall.mic.rest.policy.api.service.unifiedsearch.model;

import java.util.ArrayList;
import java.util.HashMap;

public interface IEntityResponseData {

	
	public ArrayList<HashMap> getActions();
	
	public ArrayList<HashMap> getNavigations();
	
	public void setActions(ArrayList<HashMap> actions) ;
	
	public void setNavigations(ArrayList<HashMap> navigations);
	
}
