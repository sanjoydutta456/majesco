package com.coverall.mic.rest.policy.api.service.unifiedsearch.model;

import java.util.ArrayList;
import java.util.HashMap;

public class InsuredResponseData implements IEntityResponseData{

	public String insuredName;
	public String city;
	public String state;
	public String zipcode;
	public String country;
	public String modifiedOn;
	public String modifiedBy;
	public String insuredAddress;
	
	

	ArrayList<HashMap> actions = new ArrayList<HashMap>();
	ArrayList<HashMap> navigations = new ArrayList<HashMap>();

	public ArrayList<HashMap> getActions() {
		return actions;
	}
	public void setActions(ArrayList<HashMap> actions) {
		this.actions = actions;
	}
	
	public ArrayList<HashMap> getNavigations() {
		return navigations;
	}
	public void setNavigations(ArrayList<HashMap> navigations) {
		this.navigations = navigations;
	}
	
	public String getInsuredName() {
		return insuredName;
	}
	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(String modfiedOn) {
		this.modifiedOn = modfiedOn;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modfiedBy) {
		this.modifiedBy = modfiedBy;
	}
	public String getInsuredAddress() {
		return insuredAddress;
	}
	public void setInsuredAddress(String insuredAddress) {
		this.insuredAddress = insuredAddress;
	}
	
	@Override
	public String toString() {
		return "InsuredResponseData [insuredName=" + insuredName + ", city=" + city + ", country="
				+ country + ", zipcode=" + zipcode + ", state=" + state + ", actions=" + actions + ", navigations=" + navigations + "]";
	}
	
}
