package com.coverall.mic.rest.policy.api.service.unifiedsearch.model;

import java.util.ArrayList;
import java.util.HashMap;

public class SubmissionResponseData implements IEntityResponseData{

	public String submissionNumber;
	public String effectiveDate;
	public String product;
	public String agentName;
	public String customerName;
	public String modifiedOn;
	public String modifiedBy;
	ArrayList<HashMap> actions = new ArrayList<HashMap>();
	ArrayList<HashMap> navigations = new ArrayList<HashMap>();
	
	@Override
	public ArrayList<HashMap> getActions() {
		return actions;
	}
	@Override
	public void setActions(ArrayList<HashMap> actions) {
		this.actions = actions;
	}

	@Override
	public ArrayList<HashMap> getNavigations() {
		return navigations;
	}
	@Override
	public void setNavigations(ArrayList<HashMap> navigations) {
		this.navigations = navigations;
	}
	
	public String getSubmissionNumber() {
		return submissionNumber;
	}
	public void setSubmissionNumber(String submissionNumber) {
		this.submissionNumber = submissionNumber;
	}
	public String getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(String modfiedOn) {
		this.modifiedOn = modfiedOn;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modfiedBy) {
		this.modifiedBy = modfiedBy;
	}
	
	@Override
	public String toString() {
		return "SubmissionResponseData [submissionNumber=" + submissionNumber + ", customerName=" + customerName + ", effectiveDate=" + effectiveDate + ", product="
				+ product + ", agentName=" + agentName +"]";
	}
}
