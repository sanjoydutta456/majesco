package com.coverall.mic.rest.policy.api.service.unifiedsearch.model;

import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.bind.annotation.XmlRootElement;

@SuppressWarnings("serial")
@XmlRootElement(name="UnifiedCountSearchResponse")
public class UnifiedCountSearchResponse implements java.io.Serializable {

	String sourceSystemUserId;
	String searchEntityId;
	String searchType;
	String searchText;
	Long totalRecords;
	ArrayList<HashMap> filters;
	ArrayList<HashMap> searchedColumns = new ArrayList<HashMap>();
	

	public ArrayList<HashMap> getSearchedColumns() {
		return searchedColumns;
	}

	public void setSearchedColumns(ArrayList<HashMap> searchedColumns) {
		this.searchedColumns = searchedColumns;
	}

	public ArrayList<HashMap> getFilters() {
		return filters;
	}

	public void setFilters(ArrayList<HashMap> filters) {
		this.filters = filters;
	}

	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}

	public void setSourceSystemUserId(String userID) {
		this.sourceSystemUserId = userID;
	}

	public String getSearchEntityId() {
		return searchEntityId;
	}

	public void setSearchEntityId(String searchEntityID) {
		this.searchEntityId = searchEntityID;
	}

	public String getSearchType() {
		return searchType;
	}

	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}

	public String getSearchText() {
		return searchText;
	}

	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}

	public Long getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(Long totalRecords) {
		this.totalRecords = totalRecords;
	}

	@Override
	public String toString() {
		return "UnifiedCountSearchResponse [sourceSystemUserId=" + sourceSystemUserId + ", searchEntityId=" + searchEntityId + ", searchType=" + searchType
				+ ", searchText=" + searchText +", totalRecords=" + totalRecords + ", filters=" + filters + "]";
	}
	
	
}
