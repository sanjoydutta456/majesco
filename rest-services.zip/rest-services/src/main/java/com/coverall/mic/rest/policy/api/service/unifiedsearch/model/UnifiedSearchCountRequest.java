package com.coverall.mic.rest.policy.api.service.unifiedsearch.model;

@SuppressWarnings("serial")
public class UnifiedSearchCountRequest  {

}
