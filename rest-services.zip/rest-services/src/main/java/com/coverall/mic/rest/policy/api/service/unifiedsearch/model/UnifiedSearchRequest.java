package com.coverall.mic.rest.policy.api.service.unifiedsearch.model;

import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.bind.annotation.XmlRootElement;

import com.google.gson.Gson;

@SuppressWarnings("serial")
@XmlRootElement(name="UnifiedSearchRequest")
public class UnifiedSearchRequest  implements java.io.Serializable  {
	
	public UnifiedSearchRequest(){
		
	}

	public UnifiedSearchRequest(String json) {
		super(); 
		Gson gson = new Gson();
		UnifiedSearchRequest request = gson.fromJson(json, UnifiedSearchRequest.class);
		this.sourceSystemUserId = request.sourceSystemUserId;
		this.searchEntityId = request.searchEntityId;
		this.searchType = request.searchType;
		this.searchText = request.searchText;
		this.startIndex = request.startIndex;
		this.endIndex = request.endIndex;
		this.sortColumn = request.sortColumn;
		this.sortOrder = request.sortOrder;
		this.filters = request.filters;
		this.displayMode = request.displayMode;
	}
	
	

	/**
	 * User id is required for data segmentation
	 */
	String sourceSystemUserId;
	/**
	 * Entity to be searched - POLICY, CLAIMS, INSURED etc.
	 */
	String searchEntityId;
	/**
	 * STARTSWITH or CONTAINS
	 */
	String searchType;
	/**
	 * Text to be searched
	 */
	String searchText;
	/**
	 * Pagination - Start Record #
	 */
	Long startIndex;
	/**
	 * Pagination - End Record #
	 */
	Long endIndex;
	/**
	 * Sorting on column
	 */
	String sortColumn;
	/**
	 * DESCENDING / ASCENDING
	 */
	String sortOrder;
	/**
	 * Array of filters (Secondard search)
	 */
	ArrayList<HashMap> filters;
	/**
	 * POPUP / PAGE
	 */
	String displayMode;
	
	
	
	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}
	public void setSourceSystemUserId(String userID) {
		this.sourceSystemUserId = userID;
	}
	public String getSearchEntityId() {
		return searchEntityId;
	}
	public void setSearchEntityId(String searchEntityID) {
		this.searchEntityId = searchEntityID;
	}
	public String getSearchType() {
		return searchType;
	}
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}
	public String getSearchText() {
		return searchText;
	}
	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}
	public Long getStartIndex() {
		return startIndex;
	}
	public void setStartIndex(Long startIndex) {
		this.startIndex = startIndex;
	}
	public Long getEndIndex() {
		return endIndex;
	}
	public void setEndIndex(Long endIndex) {
		this.endIndex = endIndex;
	}
	public String getSortColumn() {
		return sortColumn;
	}
	public void setSortColumn(String sortCol) {
		this.sortColumn = sortCol;
	}
	public String getSortOrder() {
		return sortOrder;
	}
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}
	public ArrayList<HashMap> getFilters() {
		return filters;
	}
	public void setFilters(ArrayList<HashMap> filters) {
		this.filters = filters;
	}
	public String getDisplayMode() {
		return displayMode;
	}
	public void setDisplayMode(String displaymode) {
		this.displayMode = displaymode;
	}
	
	
	@Override
	public String toString() {
		return "UnifiedSearchRequest [sourceSystemUserId=" + sourceSystemUserId + ", searchEntityId=" + searchEntityId + ", searchType=" + searchType
				+ ", searchText=" + searchText + ", startIndex=" + startIndex + ", endIndex=" + endIndex + ", sortCol=" + sortColumn + ", sortOrder=" + sortOrder
				+ ", filters=" + filters + ", displaymode=" + displayMode + "]";
	}

}
