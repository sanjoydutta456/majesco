package com.coverall.mic.rest.policy.api.service.unifiedsearch.model;

import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.bind.annotation.XmlRootElement;

@SuppressWarnings("serial")
@XmlRootElement(name="UnifiedSearchResponse")
public class UnifiedSearchResponse  implements java.io.Serializable{
	
	String sourceSystemUserId;
	String searchEntityId;
	String searchType;
	String searchText;
	Long startIndex;
	Long endIndex;
	String sortColumn;
	String sortOrder;
	String displayMode;
	

	ArrayList<Object> data = new ArrayList<Object>();
	ArrayList<HashMap> filters;
	ArrayList<HashMap> searchedColumns;
	
	
	public ArrayList<HashMap> getFilters() {
		return filters;
	}
	public void setFilters(ArrayList<HashMap> filters) {
		this.filters = filters;
	}
	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}
	public void setSourceSystemUserId(String userID) {
		this.sourceSystemUserId = userID;
	}
	public String getSearchEntityId() {
		return searchEntityId;
	}
	public void setSearchEntityId(String searchEntityID) {
		this.searchEntityId = searchEntityID;
	}
	public String getSearchType() {
		return searchType;
	}
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}
	public String getSearchText() {
		return searchText;
	}
	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}
	public Long getStartIndex() {
		return startIndex;
	}
	public void setStartIndex(Long startIndex) {
		this.startIndex = startIndex;
	}
	public Long getEndIndex() {
		return endIndex;
	}
	public void setEndIndex(Long endIndex) {
		this.endIndex = endIndex;
	}
	public String getSortColumn() {
		return sortColumn;
	}
	public void setSortColumn(String sortCol) {
		this.sortColumn = sortCol;
	}
	public String getSortOrder() {
		return sortOrder;
	}
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}
	public ArrayList<Object> getData() {
		return data;
	}
	public String getDisplayMode() {
		return displayMode;
	}
	public void setDisplayMode(String displayMode) {
		this.displayMode = displayMode;
	}
	
	public void setData(ArrayList<Object> data) {
		this.data = data;
	}
	
	@Override
	public String toString() {
		return "UnifiedSearchResponse [sourceSystemUserId=" + sourceSystemUserId + ", searchEntityId=" + searchEntityId + ", searchType=" + searchType
				+ ", searchText=" + searchText + ", startIndex=" + startIndex + ", endIndex=" + endIndex + ", sortColumn=" + sortColumn + ", sortOrder=" + sortOrder
				+ ", displayMode=" + displayMode + ", data=" + data + ", filters=" + filters + "]";
	}
	
}
