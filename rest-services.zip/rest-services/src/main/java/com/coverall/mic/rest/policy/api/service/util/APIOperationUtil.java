package com.coverall.mic.rest.policy.api.service.util;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import com.coverall.el.Expression;
import com.coverall.el.FunctionResolver;
import com.coverall.el.VariableResolver;
import com.coverall.el.function.DefaultFunctionResolver;
import com.coverall.exceptions.ELException;
import com.coverall.exceptions.ELParseException;
import com.coverall.mt.util.APILoggerUtil;
import com.coverall.mt.util.APIAuditTrailLog;
import com.coverall.mt.util.APIAuditTrailLogSpecifics;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.factory.impl.PolicyAPIFactoryServiceImpl;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyPagination;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyPaginationLinks;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.el.variable.VariableResolverImpl;
import com.coverall.mt.http.User;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.DOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.pctv2.server.model.vo.PctMicroserviceProcessors;
import com.coverall.pctv2.server.yaml.generation.OpenAPISpecGenerator;
import com.coverall.util.DBUtil;
import com.coverall.util.GeneralUtil;
import com.coverall.mic.rest.policy.api.service.processors.IAPIProcessor;
import com.coverall.mic.rest.policy.api.service.processors.impl.APIProcessorLayer;
import com.coverall.mic.rest.policy.api.service.processors.model.APIProcessor;
import org.apache.commons.io.IOUtils;

public class APIOperationUtil {
	
	private static String queryForDLSValidation="SELECT qp.PROGRAM_CODE PROGRAM_CODE,qp.ENTITY_REFERENCE ENTITY_REFERENCE,qp.COMPANY_CODE COMPANY_CODE,qp.product_code PRODUCT_CODE,qp.underwriter_code underwriter_code,"+
										 "(SELECT MPO_OPERATOR_CODE FROM mis_policies where mpo_policy_reference=qp.entity_reference) operator,(SELECT mpo_policy_state FROM mis_policies where mpo_policy_reference=qp.entity_reference) state,"+
										 "(SELECT MPO_AGENT_ID FROM mis_policies where mpo_policy_reference=qp.entity_reference) AGENT_CODE,(SELECT mpo_insured_name FROM mis_policies where mpo_policy_reference=qp.entity_reference) INSURED_NAME,"+
										 "(SELECT MPO_SUB_AGENT_ID FROM mis_policies where mpo_policy_reference=qp.entity_reference) SUB_AGENT_ID FROM EV_MIS_QUOTE_POLICIES qp WHERE qp.ENTITY_REFERENCE=? AND UPPER(qp.ENTITY_TYPE)=UPPER(?)";
	
	private static String queryForFetchingGlobalProductOptionValue="SELECT NVL(IPI_FEATURE_SELECTED, IPI_FEATURE_DEFAULT) featureValue"+
																   " FROM mis_product_options_assn WHERE ipi_feature_code =?";
	
	private static final String TEMP = "temp";
	private static final String TEMPLATE_DOWNLOAD = "templateDownload";
	
	private static String queryForInsertingAuditLog="INSERT INTO MIS_API_AUDIT_TRAIL_LOG (maatl_id,maatl_source_system_user_Id,"+
													"maatl_source_system_code,maatl_source_system_requestNo,maatl_operation_type,maatl_resource,"+
													"maatl_version,maatl_URL,maatl_user,maatl_request_date,maatl_response_date,maatl_status_code,maatl_status_message)"+
													" VALUES(api_audit_trail_sequence.nextVAL,?,?,?,?,?,?,?,?,?,?,?,?)";
	
	private static String queryForInsertingAuditLogSpecifics="INSERT INTO MIS_API_AUDIT_SPECIFICS (maas_request_id,maas_entity_type,"+
															 "maas_entity_reference,maas_resource_id,maas_specifics) VALUES(?,?,?,?,?)";
	
	private static Map<String,Map<String,Map<String, Map<IAPIProcessor.PROCESSOR_TRIGGER_POINT,List<APIProcessor>>>>> customerApiProcessorMap=new HashMap<String,Map<String,Map<String, Map<IAPIProcessor.PROCESSOR_TRIGGER_POINT,List<APIProcessor>>>>>();
	
	public static boolean checkIfUserHasAccessToTransaction(User user, Connection conn, String entityReference, String entityType) throws APIException{
		PreparedStatement psExistence=null;
		ResultSet rsExistence=null;
		
		PreparedStatement psDLSValidation=null;
		ResultSet rsDLSValidation=null;
		
		try{
			String queryForVerifyingExistance="SELECT count(*) transactionExist FROM ("+queryForDLSValidation+")";
			
			psExistence=conn.prepareStatement(queryForVerifyingExistance);
			psExistence.setString(1, entityReference);
			psExistence.setString(2, entityType);
			
			rsExistence=psExistence.executeQuery();
			
			boolean transactionExists=false;
			while(rsExistence.next()){
				transactionExists=rsExistence.getInt("transactionExist")==0?false:true;
			}
			
			if(transactionExists){
			String finalQueryWithDLSInputs="SELECT * FROM ("+queryForDLSValidation+") WHERE 1=1 "+resolveDLSExpression(user,APIConstant.DLS_EXPRESSION_STRING_QUOTE_POLICY);
			
			psDLSValidation=conn.prepareStatement(finalQueryWithDLSInputs);
			psDLSValidation.setString(1, entityReference);
			psDLSValidation.setString(2, entityType);
			
			rsDLSValidation=psDLSValidation.executeQuery();
			while(rsDLSValidation.next()){
				return true;
			}
			 return false;
			}else{
				String errMsg ="There is no such transaction in existence: "+entityReference;
				List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("APIOperationUtil", "checkIfUserHasAccessToTransaction", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.ENTITY_NOT_IN_EXISTENCE,errorMessageList,null);
			}
		}catch(APIException exp){
			throw exp;
		}catch(Exception e){
			String errMsg ="Error while validating DLS for the "+entityReference;
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logInfo("APIOperationUtil", "checkIfUserHasAccessToTransaction", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}finally{
			try{
				DBUtil.close(rsExistence, psExistence);
			}catch(Exception e){
				WebServiceLoggerUtil.logError("APIOperationUtil", "checkIfUserHasAccessToTransaction", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			}
			try{
				DBUtil.close(rsDLSValidation, psDLSValidation);
			}catch(Exception e){
				WebServiceLoggerUtil.logError("APIOperationUtil", "checkIfUserHasAccessToTransaction", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			}
		}
	}
	
	public static String resolveDLSExpression(User user, String dlsExpressionString){
		
		String resolvedExpression=""; 
		HashMap variableMap = new HashMap();
		variableMap.put(VariableResolverImpl.USER_PARAMETER, user);
		variableMap.put(VariableResolverImpl.SESSION_PARAMETER, user);

		try {
			VariableResolver varResolver = new VariableResolverImpl(variableMap);
			FunctionResolver funcResolver = new DefaultFunctionResolver();

			HashMap expressionMap = new HashMap();


			Expression exp=null;

			exp = new Expression(
					dlsExpressionString,
					null,
					null,
					varResolver,
					funcResolver,
					DOMUtil.GET_MAPDIRECTION,
					expressionMap,
					true);
			resolvedExpression=exp.getValue();
		} catch (ELParseException e) {
			WebServiceLoggerUtil.logError("APIOperationUtil", "resolveDLSExpression", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
		} catch (ELException e) {
			WebServiceLoggerUtil.logError("APIOperationUtil", "resolveDLSExpression", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
		}

		return resolvedExpression;
	}
	
	
//	public static boolean checkIfUserHasAccessToSpecificFolderUnderTransaction(User user, Connection conn, String entityType,String entityReference, String folderObjectName ,boolean cloneable) throws APIException{
//		boolean hasAccess=false;
//		try{
//			FolderObject folderObject=FolderObject.getFolderObjectAccessibilityForAPI(conn, entityType, entityReference, user, cloneable, folderObjectName);
//			hasAccess=!folderObject.isHidden();
//		}catch(Exception exp){
//			String errMsg ="Error while getting folder accessiblity information for :"+entityReference;
//			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
//			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
//			WebServiceLoggerUtil.logInfo("APIOperationUtil", "checkIfUserHasAccessToSpecificFolderUnderTransaction", errMsg, new Object[] { errMsg });
//			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
//		}
//		return hasAccess;
//	}
	
	public static QuotePolicyPagination populatePaginationInformation(String url, Connection conn, String queryString, int pageNumber, int pageSize) throws APIException{
		return (populatePaginationInformation(url, conn, queryString, pageNumber, pageSize, null));
	}

	public static QuotePolicyPagination populatePaginationInformation(String url, Connection conn, String queryString, int pageNumber, int pageSize, List<String> variableList) throws APIException{
		
		if(pageSize>150){
			WebServiceLoggerUtil.logError("APIOperationUtil", "populatePaginationInformation", "pageSize cannot be greater than 150", new Object[] { },null);
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList("pageSize cannot be greater than 150"));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}else if(pageSize<=0 || pageNumber<=0){
			WebServiceLoggerUtil.logError("APIOperationUtil", "populatePaginationInformation", "pageNumber and pageSize should be greater than 0.", new Object[] { },null);
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList("pageNumber and pageSize should be greater than 0."));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}
		QuotePolicyPagination pagination=new QuotePolicyPagination();

		PreparedStatement psGetCount=null;
		ResultSet rsGetCount=null;

		int startIndex=0;
		int endIndex=0;
		int totalCount=0;
		int lastPageNumber=0;
		
		String queryForGettingCount="SELECT count(*) as rowCount FROM ("+queryString+")";

		//Getting total count
		try{
			psGetCount=conn.prepareStatement(queryForGettingCount);
			
			if (null != variableList) {
				GeneralUtil.bindVariablesToStatement(variableList, psGetCount, 0);
			}
			
			rsGetCount=psGetCount.executeQuery();
			rsGetCount.next();
			totalCount=rsGetCount.getInt("rowCount");
			if(totalCount!=0){
				startIndex=(pageNumber==1?1:((pageNumber-1)*pageSize)+1);
				endIndex=(startIndex+pageSize)-1;	
				lastPageNumber=(int) Math.ceil((totalCount*1.0/pageSize));
				
				if(startIndex>totalCount && endIndex>totalCount){
					endIndex=0;
					startIndex=0;
				}
				
				if(startIndex>totalCount){
					startIndex=0;
				}
				
				if(endIndex>totalCount){
					endIndex=totalCount;
				}
				
			pagination.setTotalRecords(totalCount+"");
			 pagination.setStartIndex(startIndex+"");
			 pagination.setEndIndex(endIndex+"");
			 pagination.setPageSize(pageSize+"");
			 pagination.setLastPageNumber(lastPageNumber+"");
			 pagination.setPageNumber(pageNumber+"");
			 
			
			 ArrayList<QuotePolicyPaginationLinks> links=new ArrayList<QuotePolicyPaginationLinks>();
			 links.add(populateLinksForPaginationResult(url, totalCount, pageSize, pageNumber));
			 pagination.setLinks(links);
			}
		}catch(Exception exp){
			WebServiceLoggerUtil.logError("APIOperationUtil", "populatePaginationInformation", "Exception occurred while fetching count using: ", new Object[] { queryForGettingCount }, exp);
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(exp.getMessage()));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,exp);

		}finally{
			try{
				DBUtil.close(rsGetCount, psGetCount);
			}catch(Exception e){

			}
		}

		return pagination;
	}
	
	public static QuotePolicyPaginationLinks populateLinksForPaginationResult(String url,int totalCount,int pageSize, int pageNumber){
		int firstPageNumber=0;
		int lastPageNumber=0;
		int previousPageNumber=0;
		int nextPageNumber=0;

		if(totalCount!=0){
			firstPageNumber=1;
			lastPageNumber=(int) Math.ceil((totalCount*1.0/pageSize));
			
			if(pageNumber>firstPageNumber){
				previousPageNumber=pageNumber-1;
			}else if(pageNumber==firstPageNumber){
				previousPageNumber=pageNumber;
			}
			if(pageNumber<lastPageNumber){
				nextPageNumber=pageNumber+1;
			}else if(pageNumber==lastPageNumber){
				nextPageNumber=pageNumber;
			}
			
			if(pageNumber>lastPageNumber){
				previousPageNumber=0;
				nextPageNumber=0;
			}

		}
		
		String baseurl=url;
		Pattern pageNumberPattern=Pattern.compile("pageNumber=[0-9]+[&]*",Pattern.DOTALL);
		Matcher pageNumberMatcher=pageNumberPattern.matcher(url);
		baseurl=pageNumberMatcher.replaceAll("");
		
		if(!baseurl.contains("pageSize")){
			baseurl+="&pageSize="+pageSize;
		}
		
		baseurl=baseurl+"&pageNumber=";
		baseurl=baseurl.replaceAll("&&", "&");
		baseurl=baseurl.replaceAll("\\?&", "?");
		
		QuotePolicyPaginationLinks paginationlink=new QuotePolicyPaginationLinks();

		if(firstPageNumber!=0){
			paginationlink.setFirst(baseurl+firstPageNumber);
		}else{
			paginationlink.setFirst("");	
		}

		if(lastPageNumber!=0){
			paginationlink.setLast(baseurl+lastPageNumber);	
		}else{
			paginationlink.setLast("");
		}

		if(nextPageNumber!=0){
			paginationlink.setNext(baseurl+nextPageNumber);
		}else{
			paginationlink.setNext("");	
		}

		if(previousPageNumber!=0){
			paginationlink.setPrev(baseurl+previousPageNumber);
		}else{
			paginationlink.setPrev("");	
		}

		return paginationlink;

	}
	
	public static boolean validatePhoneNumber(String phoneNo) {
		//validate phone numbers of format "1234567890"
		if (phoneNo.matches("\\d{10}")) return true;
		//validating phone number with -, . or spaces
		else if(phoneNo.matches("\\d{3}[-\\.\\s]\\d{3}[-\\.\\s]\\d{4}")) return true;
		//validating phone number with extension length from 3 to 5
		else if(phoneNo.matches("\\d{3}-\\d{3}-\\d{4}\\s(x|(ext))\\d{3,5}")) return true;
		//validating phone number where area code is in braces ()
		else if(phoneNo.matches("\\(\\d{3}\\)-\\d{3}-\\d{4}")) return true;
		//return false if nothing matches the input
		else return false;
	}
	
	public static void validateVersion(String providedVersion) throws APIException{
		boolean versionFound=false;
		for(String version:APIVersionTracker.SUPPORTED_VERSION){
			if(version.equals(providedVersion)){
				versionFound=true;
				break;
			}
		}
		if(!versionFound){
			String errMsg = "Version "+providedVersion+" doesn't exist. Please correct the version in URL.";
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
			WebServiceLoggerUtil.logError("APIOperationUtil", "validateVersion", "Version not in existence", new Object[] { "Version not in existence" }, null);
			throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
		}
	}
	
	public static void verifyIfUserHasAccessToTransaction(User user,String quoteId, String entityType) throws APIException{
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		if(!APIOperationUtil.checkIfUserHasAccessToTransaction(user, requestContext.getConnection(),quoteId,entityType)){
			String errMsg = requestContext.getUser().getUserId()+" doesn't have access to the "+quoteId;
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			WebServiceLoggerUtil.logInfo("APIOperationUtil", "verifyIfUserHasAccessToTransaction", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
		}
	}
	
//	public static void verifyIfUserHasAccessToTheFolderUnderTransaction(User user,String entityType,String quoteId, String folderObjectName, boolean cloneable) throws APIException{
//		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
//		if(!APIOperationUtil.checkIfUserHasAccessToSpecificFolderUnderTransaction(user, requestContext.getConnection(),entityType,quoteId,folderObjectName,cloneable)){
//			String errMsg = requestContext.getUser().getUserId()+" doesn't have access to the "+folderObjectName+" tab or the folder not yet created under "+quoteId+". Please verify the permission and current status of transaction.";
//			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
//			String httpStatusCode = String.valueOf(Response.Status.NOT_ACCEPTABLE.getStatusCode());
//			WebServiceLoggerUtil.logInfo("APIOperationUtil", "verifyIfUserHasAccessToTheFolderUnderTransaction", errMsg, new Object[] { errMsg });
//			throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
//		}
//	}
	
	public static String getProductGlobalOptionValue(Connection conn, String featureCode, boolean isGlobalOption, String entityReference){
		PreparedStatement psProductOption=null;
		ResultSet rsProductOption=null;
		
		try{
			String finalQueryForProductOption=queryForFetchingGlobalProductOptionValue;
			
			if(isGlobalOption){
				finalQueryForProductOption+=" AND IPI_PRODUCT_CODE IS NULL";
			}else{
				finalQueryForProductOption+=" AND IPI_PRODUCT_CODE=(select mpo_policy_symbol from mis_policies where mpo_policy_reference= ?)";
			}
			
			psProductOption=conn.prepareStatement(finalQueryForProductOption);
			psProductOption.setString(1, featureCode);
			if(!isGlobalOption){
				psProductOption.setString(2, entityReference);
			}
			rsProductOption=psProductOption.executeQuery();
			String featureValue=null;
			while(rsProductOption.next()){
				featureValue=rsProductOption.getString(1);
			}
			
			if(featureValue!=null){
				return featureValue;
			}else{
				String errMsg ="There is no product option with code "+featureCode+" configured in system.";
				List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
				WebServiceLoggerUtil.logInfo("APIOperationUtil", "getProductGlobalOptionValue", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
		}catch(APIException exp){
			throw exp;
		}catch(Exception e){
			String errMsg ="Error while fetching product option value.";
			List <Message> errorMessageList = APIOperationUtil.getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logInfo("APIOperationUtil", "getProductGlobalOptionValue", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}finally{
			try{
				DBUtil.close(rsProductOption, psProductOption);
			}catch(Exception e){
				WebServiceLoggerUtil.logError("APIOperationUtil", "getProductGlobalOptionValue", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			}
		}
		
	}
	
	public static String getTemporaryFolderLocationForUser(User user){
		Random randomizer = new Random();
		String micRiHome =
				System.getProperty(DOMUtil.MIC_SYSTEM_HOME) + File.separator +
				ServletConfigUtil.COMPONENT_RI + File.separator +
				CustomerConfigUtil.getInstance().getCustomerCode(user.getDomain());

		File tempDirectory =
				new File(micRiHome + File.separator + TEMP + File.separator +
						TEMPLATE_DOWNLOAD + File.separator +
						randomizer.nextLong());
		tempDirectory.mkdirs();
		return tempDirectory.getAbsolutePath();
	}
	
	public static void deleteAnyFolder(String temporaryFolderLocation){
		if(temporaryFolderLocation!=null && !"".equalsIgnoreCase(temporaryFolderLocation)){
			File temporaryFolder=new File(temporaryFolderLocation);
			if(temporaryFolder.exists()){
				if (temporaryFolder.isDirectory()) {
					for (File subFile : temporaryFolder.listFiles()) {
						subFile.delete();
					}
				}
				temporaryFolder.delete();
			}
		}
	}
	
	public static List<Message> getErrorMessageList(List<String> strMessages)	{
		if(strMessages == null)	{
			return null;
		}
		List<Message> errorMessageList = new ArrayList<Message>(strMessages.size());
		for(String aMsg : strMessages)	{
			Message message = new Message();
			message.setMoreinfo(aMsg);
			errorMessageList.add(message);
		}
		return errorMessageList;
	}
	
//	public static void createAuditTrailForTransaction(final com.coverall.mt.http.User user,final APIAuditTrailLog auditTrail){
//		Thread auditLogging=new Thread(new Runnable() {
//			@Override
//			public void run() {
//				Connection conn=null;
//				PreparedStatement psAuditTrail=null;
//				ResultSet rsAuditTrail=null;
//				PreparedStatement psAuditSpecifics=null;
//				try{
//					if(auditTrail!=null){
//						long requestId=0;
//						String generatedColumns[] = { "maatl_id" };
//						conn=ConnectionPool.getConnection(user);
//
//						psAuditTrail = conn.prepareStatement(queryForInsertingAuditLog, generatedColumns);
//						psAuditTrail.setString(1, auditTrail.getSourceSystemUserId());
//						psAuditTrail.setString(2, auditTrail.getSourceSystemCode());
//						psAuditTrail.setLong(3, auditTrail.getSourceSystemRequestNo());
//						psAuditTrail.setString(4, auditTrail.getOperationType());
//						psAuditTrail.setString(5, auditTrail.getResource());
//						psAuditTrail.setString(6, auditTrail.getVersion());
//						psAuditTrail.setString(7, auditTrail.getURL());
//						psAuditTrail.setString(8, auditTrail.getUser());
//						psAuditTrail.setTimestamp(9, auditTrail.getRequestDate());
//						psAuditTrail.setTimestamp(10, auditTrail.getResponseDate());
//						psAuditTrail.setInt(11, auditTrail.getStatusCode());
//						psAuditTrail.setString(12, auditTrail.getStatusMessage());
//						
//						psAuditTrail.execute();
//						
//						rsAuditTrail = psAuditTrail.getGeneratedKeys();
//
//						if (rsAuditTrail.next()) {
//							requestId = rsAuditTrail.getLong(1);
//						}
//
//						if(requestId!=0){
//							if(auditTrail.getAuditSpecifics()!=null && !auditTrail.getAuditSpecifics().isEmpty()){
//
//								for(APIAuditSpecifics auditSpecifics:auditTrail.getAuditSpecifics()){
//									try{
//										psAuditSpecifics=conn.prepareStatement(queryForInsertingAuditLogSpecifics);
//										psAuditSpecifics.setLong(1, requestId);
//										psAuditSpecifics.setString(2, auditSpecifics.getEntityType());
//										psAuditSpecifics.setString(3, auditSpecifics.getEntityReference());
//										psAuditSpecifics.setString(4, auditSpecifics.getResourceId());
//										psAuditSpecifics.setString(5, auditSpecifics.getSpecifics());
//										int i=psAuditSpecifics.executeUpdate();
//										if(i!=1){
//											throw new Exception();
//										}
//									}catch(Exception exp){
//										WebServiceLoggerUtil.logInfo("APIOperationUtil", "createAuditTrailForTransaction", exp.getLocalizedMessage(), new Object[] { auditSpecifics });
//									}finally{
//										DBUtil.close(null,psAuditSpecifics);
//									}
//								}
//							}
//						}else{
//							throw new Exception();
//						}
//					}
//				} catch (Exception e) {
//					WebServiceLoggerUtil.logInfo("APIOperationUtil", "createAuditTrailForTransaction", e.getLocalizedMessage(), new Object[] { auditTrail });
//				}finally{
//					try{
//						DBUtil.close(rsAuditTrail,psAuditTrail);
//					}catch(Exception exp){
//						WebServiceLoggerUtil.logInfo("APIOperationUtil", "createAuditTrailForTransaction", exp.getLocalizedMessage(), new Object[] { "Error while closing preparedstatement and resultset" });	
//					}finally{
//						try{
//							DBUtil.close(conn);
//						}catch(Exception exp){
//							WebServiceLoggerUtil.logInfo("APIOperationUtil", "createAuditTrailForTransaction", exp.getLocalizedMessage(), new Object[] { "Error while closing connection" });
//						}
//					}
//				} 
//			}
//		});
//
//		auditLogging.start();
//	}
	
//	public static String createInsertQueryFromTheAuditTrailBean(Connection conn,String tableName, LinkedHashMap<String, Object> dataRow){
//		StringBuilder query=null;
//		PreparedStatement psAuditTrail=null;
//		ResultSet rsAuditTrail=null;
//		if(tableName!=null && !"".equalsIgnoreCase(tableName) && !dataRow.isEmpty()){
//			
//			query=new StringBuilder();
//			query.append("INSERT INTO "+tableName+" ("+StringUtils.join(dataRow.keySet(), ',')+") values (");
//			String dataArray[]=new String[dataRow.size()];
//			Arrays.fill(dataArray, "?");
//			query.append(")");
//			
//			try {
//				psAuditTrail=conn.prepareStatement(query.toString());
//				
//				for(int i=0;i<dataRow.size();i++){
//					if(dataRow.get(i) instanceof String){
//						psAuditTrail.setString(i, (String)dataRow.get(i));
//					}else if(dataRow.get(i) instanceof Integer){
//						psAuditTrail.setInt(i, (Integer)dataRow.get(i));
//					}else if(dataRow.get(i) instanceof Long){
//						psAuditTrail.setLong(i, (Long)dataRow.get(i));
//					}else if(dataRow.get(i) instanceof Double){
//						psAuditTrail.setDouble(i, (Double)dataRow.get(i));
//					}else if(dataRow.get(i) instanceof Double){
//						psAuditTrail.setInt(i, (Integer)dataRow.get(i));
//					}else if(dataRow.get(i) instanceof Integer){
//						psAuditTrail.setInt(i, (Integer)dataRow.get(i));
//					}else if(dataRow.get(i) instanceof Date){
//						psAuditTrail.setDate(i,new java.sql.Date(((Date)dataRow.get(i)).getTime()));
//					}else if(dataRow.get(i) instanceof java.sql.Date){
//						psAuditTrail.setDate(i,(java.sql.Date)dataRow.get(i));
//					}
//					
//				}
//			} catch (SQLException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			
//			
//			
//			
//		}
//		
//		return query.toString();
//	}
	
	public static void populateAPIAuditLog(APIAuditTrailLog auditTrailLog,String sourceSystemId, String sourceSystemUserId, long sourceSystemRequestNo, String resourceType, String version){

		if(auditTrailLog != null ){
			auditTrailLog.setSourceSystemCode(sourceSystemId);
			auditTrailLog.setSourceSystemUserId(sourceSystemUserId);
			auditTrailLog.setSourceSystemRequestNo(sourceSystemRequestNo);
			auditTrailLog.setResourceType(resourceType);
		}
	}

	public static void populateAPISpecific(APIAuditTrailLog auditTrailLog,String entityType, String entityReference, String requestIdentifier, String additionalInfo){

		if(auditTrailLog != null){
			APIAuditTrailLogSpecifics auditSpecific=auditTrailLog.getLogSpecifics();

			auditSpecific.setEntityType(entityType);
			auditSpecific.setEntityReference(entityReference);
			auditSpecific.setRequestIdentifier(requestIdentifier!=null?requestIdentifier:additionalInfo);

		}

	}
	
	public static String getProductCode(String quotePolicyId, Connection conn) {
		String productCode = null;
		PreparedStatement psProductCode = null;
		ResultSet rsProductCode = null;
        String productCodeQuery = " SELECT product_code FROM vw_mis_quote_policies WHERE entity_reference =  ?";
		try {
			psProductCode = conn.prepareStatement(productCodeQuery);
			psProductCode.setString(1,quotePolicyId);
			rsProductCode = psProductCode.executeQuery();
			if(rsProductCode.next()){
				productCode = rsProductCode.getString("product_code");
			}
		} catch (Exception e) {
			WebServiceLoggerUtil.logInfo("APIOperationUtil", "getProductCode", e.getLocalizedMessage(), new Object[] { quotePolicyId });
		} finally {
			try {
				DBUtil.close(rsProductCode, psProductCode);
			} catch (Exception exp) {
				WebServiceLoggerUtil.logInfo("APIOperationUtil", "getProductCode", exp.getLocalizedMessage(),
						new Object[] { "Error while closing preparedstatement and resultset" });
			}

		}
		return productCode;
	}
	
	public static Map<String,String> getProductURLDetails(Connection conn) {
		PreparedStatement ps = null;
		ResultSet rs = null;
		String productName = null;
		String productCode = null;
		Map<String,String> productDetailsMap = new HashMap<String,String>();
		try {
			String sql = " SELECT * FROM ps_products, ds_resource WHERE "
					+ " dsr_gid = ppd_id AND DSR_DATE_DELETED IS NULL AND NVL(PPD_IS_INSURANCE_PRODUCT,'Y') <> 'N'  ";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()){
				productName = rs.getString("PPD_NAME");
				productCode = rs.getString("dsr_product_code");
				String productURI = null;
				/* 
				 * Hard-coding the product code, will be replaced once we a dedicated URI column in PS_PRODUCTS  
				 */
				if("WK".equalsIgnoreCase(productCode)){
					productURI = "workers-compensation";
				}else{
					productURI = OpenAPISpecGenerator.getProductURI(productName);
				}
				if(productURI != null){
					productDetailsMap.put("policy-"+productURI, productCode);
					productDetailsMap.put("quote-"+productURI, productCode);
				}
				
			}
			return productDetailsMap;
		} catch (Exception e) {

		} finally {
			if (conn != null) {
				try {
					DBUtil.close(rs, ps, conn);
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return null;
	}
	
	public static boolean isNullOrEmptyString(String value) {
		if(value==null || "".equalsIgnoreCase(value)) {
			return true;
		}
		return false;
	}
	
	public static void callRequestPreProcessor(HttpServletRequest request, Map<Object,Object> params) throws Exception{
		APIProcessorLayer layer=new APIProcessorLayer();
		layer.preProcessAPIRequest(request, params);
	}
	
	public static void callRequestPostProcessor(HttpServletRequest request,Object response, Map<Object,Object> params) throws Exception{
		APIProcessorLayer layer=new APIProcessorLayer();
		layer.postProcessAPIRequest(request, response ,params);
	}
	
	public static String getCustomerCodeFromContext(APIRequestContext context) {
		return CustomerConfigUtil.getInstance().getCustomerCode(context.getUserDomain()).toUpperCase();
	}
	
	public static List<APIProcessor> getAPIProcessorList(String requestType, String serviceCategory, IAPIProcessor.PROCESSOR_TRIGGER_POINT triggerPoint) {
		List<APIProcessor> processors=new ArrayList<APIProcessor>();
		String customerCode = getCustomerCodeFromContext(APIRequestContext.getApiRequestContext());
		if(customerApiProcessorMap.get(customerCode)==null) {
			loadAndCacheAPIProcessorData(APIRequestContext.getApiRequestContext().getConnection(), customerCode);
		}
		if(customerApiProcessorMap.get(customerCode).get(serviceCategory)!=null) {
			if(customerApiProcessorMap.get(customerCode).get(serviceCategory).get(requestType)!=null) {
				processors=customerApiProcessorMap.get(customerCode).get(serviceCategory).get(requestType).get(triggerPoint);
			}
			if(customerApiProcessorMap.get(customerCode).get(serviceCategory).get(APIConstant.API_PROCESSOR_ALL_REQUEST_TYPE).get(triggerPoint)!=null) {
			 processors.addAll(customerApiProcessorMap.get(customerCode).get(serviceCategory).get(APIConstant.API_PROCESSOR_ALL_REQUEST_TYPE).get(triggerPoint));
			}
		}
		WebServiceLoggerUtil.logInfo("APIOperationUtil", "getAPIProcessorList", (processors!=null?processors.size():0)+" fetched for "+customerCode+" for "+requestType, new Object[] { customerCode,serviceCategory,requestType,triggerPoint});
		return processors;
	}

	public static void loadAndCacheAPIProcessorData(Connection conn, String customerCode) {
		String productCode = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		List<APIProcessor> listOfProcessors=new ArrayList<APIProcessor>();
		String queryForLoadingApiProcessor = "SELECT pmpz_id,pmpz_request_type,pmpz_triggering_point,pmpz_class_name, PMPZ_SEQUENCE,PMPZ_SERVICE_CATEGORY,PMPZ_IS_ACTIVE\r\n" + 
				"FROM PCT_MICROSERVICE_PROCESSORS\r\n" + 
				"WHERE PMPZ_IS_ACTIVE='Y'\r\n" + 
				"AND PMPZ_SERVICE_CATEGORY<>'microservices'\r\n" + 
				"ORDER BY PMPZ_REQUEST_TYPE,PMPZ_TRIGGERING_POINT, pmpz_sequence";

		try {
			psmt = conn.prepareStatement(queryForLoadingApiProcessor);
			rs = psmt.executeQuery();
			while(rs.next()){
				APIProcessor processor=new APIProcessor();
				processor.setId(rs.getBigDecimal("pmpz_id"));
				processor.setServiceCategory(rs.getString("PMPZ_SERVICE_CATEGORY"));
				processor.setRequestType(rs.getString("pmpz_request_type"));
				processor.setProcessorType(rs.getString("pmpz_triggering_point"));
				processor.setSequence(rs.getBigDecimal("PMPZ_SEQUENCE"));
				processor.setClassName(rs.getString("pmpz_class_name"));
				processor.setIsActive(rs.getString("PMPZ_IS_ACTIVE"));
				processor.setTriggeringPoint(rs.getString("pmpz_triggering_point"));

				listOfProcessors.add(processor);
			}
		} catch (Exception e) {
			WebServiceLoggerUtil.logInfo("APIOperationUtil", "loadAndCacheAPIProcessorData", e.getLocalizedMessage(), new Object[] { customerCode });
		} finally {
			try {
				DBUtil.close(rs, psmt);
			} catch (Exception exp) {
				WebServiceLoggerUtil.logInfo("APIOperationUtil", "loadAndCacheAPIProcessorData", exp.getLocalizedMessage(),
						new Object[] { "Error while closing preparedstatement and resultset" });
			}

		}
		Map<String,Map<String, Map<IAPIProcessor.PROCESSOR_TRIGGER_POINT,List<APIProcessor>>>> categoryProcessorMap=new HashMap<String,Map<String, Map<IAPIProcessor.PROCESSOR_TRIGGER_POINT,List<APIProcessor>>>>();
		customerApiProcessorMap.put(customerCode,categoryProcessorMap);

		for(APIProcessor processor:listOfProcessors) {
			Map<String, Map<IAPIProcessor.PROCESSOR_TRIGGER_POINT,List<APIProcessor>>>serviceProcessorMap=categoryProcessorMap.get(processor.getServiceCategory());
			if(serviceProcessorMap==null) {
				serviceProcessorMap=new HashMap<String, Map<IAPIProcessor.PROCESSOR_TRIGGER_POINT,List<APIProcessor>>>();
				categoryProcessorMap.put(processor.getServiceCategory(), serviceProcessorMap);
			}
			if(serviceProcessorMap.containsKey(processor.getRequestType())){
				Map<IAPIProcessor.PROCESSOR_TRIGGER_POINT,List<APIProcessor>> existingProcessorMap=serviceProcessorMap.getOrDefault(processor.getRequestType(),new HashMap<IAPIProcessor.PROCESSOR_TRIGGER_POINT, List<APIProcessor>>());
				String triggerPoint = processor.getTriggeringPoint();

				if (IAPIProcessor.PROCESSOR_TRIGGER_POINT.PRE.toString()
						.equalsIgnoreCase(triggerPoint)) {
					List<APIProcessor> existingList=existingProcessorMap.getOrDefault(IAPIProcessor.PROCESSOR_TRIGGER_POINT.PRE, new ArrayList<APIProcessor>());
					existingList.add(processor);
					existingProcessorMap.put(IAPIProcessor.PROCESSOR_TRIGGER_POINT.PRE,existingList);
				} else if (IAPIProcessor.PROCESSOR_TRIGGER_POINT.POST
						.toString().equalsIgnoreCase(triggerPoint)) {
					List<APIProcessor> existingList=existingProcessorMap.getOrDefault(IAPIProcessor.PROCESSOR_TRIGGER_POINT.POST,new ArrayList<APIProcessor>());
					existingList.add(processor);
					existingProcessorMap.put(IAPIProcessor.PROCESSOR_TRIGGER_POINT.POST,existingList);
				}
			}else {
				List<APIProcessor> newList=new ArrayList<APIProcessor>();
				newList.add(processor);
				Map<IAPIProcessor.PROCESSOR_TRIGGER_POINT,List<APIProcessor>> newMap=new HashMap<IAPIProcessor.PROCESSOR_TRIGGER_POINT, List<APIProcessor>>();
				String triggerPoint = processor.getTriggeringPoint();
				if (IAPIProcessor.PROCESSOR_TRIGGER_POINT.PRE.toString()
						.equalsIgnoreCase(triggerPoint)) {
					newMap.put(IAPIProcessor.PROCESSOR_TRIGGER_POINT.PRE,newList);
				} else if (IAPIProcessor.PROCESSOR_TRIGGER_POINT.POST
						.toString().equalsIgnoreCase(triggerPoint)) {
					newMap.put(IAPIProcessor.PROCESSOR_TRIGGER_POINT.POST,newList);
				}
				serviceProcessorMap.put(processor.getRequestType(),newMap);
			}
		}
	}
	
	public static String getClientIPAddress(HttpServletRequest request) {
		String xForwardedForHeader = request.getHeader("X-Forwarded-For");
	    if (xForwardedForHeader == null) {
	        return request.getRemoteAddr();
	    } else {
	        return new StringTokenizer(xForwardedForHeader, ",").nextToken().trim();
	    }
	}
	
	public static String fetchRequestBody(HttpServletRequest request) {
		String inputJson=null;
		try {
			inputJson=IOUtils.toString(request.getInputStream(), "UTF-8");
		}catch(Exception exp) {
			//do nothing
		}
		if(inputJson==null || "".equalsIgnoreCase(inputJson)) {
			inputJson=(String)request.getAttribute(IAPIContext.INPUT_JSON);
		}
		return inputJson;
	}
}
