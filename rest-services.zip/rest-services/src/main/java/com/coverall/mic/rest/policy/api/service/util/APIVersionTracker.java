package com.coverall.mic.rest.policy.api.service.util;

public interface APIVersionTracker {
	
	public static final String[] SUPPORTED_VERSION={"1","2","3"};

}
