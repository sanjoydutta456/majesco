package com.coverall.mic.rest.policy.api.service.util;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import com.coverall.exceptions.ExceptionImpl;
import com.coverall.exceptions.JDBCException;
import com.coverall.exceptions.SecurityException;
import com.coverall.exceptions.ServiceException;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mt.http.User;
import com.coverall.mt.security.AdminX;
import com.coverall.mt.security.Principal;
import com.coverall.mt.services.WorkFlowService;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.pctv2.server.rs.client.WorkflowEventNotifier;
import com.coverall.pctv2.server.util.BookOverrideEntity;
import com.coverall.mt.nexgensecurity.NsRestClientUtil;
import com.coverall.mt.security.securityclient.AuthorizationService;
import com.coverall.security.model.NsRole;
//import com.coverall.mt.webservices.WebServiceLoggerUtil;
//import com.coverall.mt.db.ConnectionPool;
//import com.coverall.mt.http.HTTPConstants;

import com.coverall.util.DBUtil;

public class WorkflowUtil {
	private static String className="WorkflowUtil";
	

	public static String getCurrentPolicyStatus(String policyReference,String entityType,
			Connection conn ) throws JDBCException {
		String status = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		try {

			 st = conn.prepareStatement("select K_Workflow_Activity_Management.f_get_status(?, ? ) status from dual " );
			 st.setString(1, entityType);
			 st.setString(2, policyReference);

			 rs = st.executeQuery();

			if(rs != null && rs.next()){
				status = rs.getString("status");
			}
		}catch (Throwable error) {
			
			 if (error instanceof JDBCException) {
	           throw (JDBCException)error;
	       } else {
	           throw new JDBCException(ExceptionImpl.FATAL, "Unexpected error occured while getting  getCurrentPolicyStatus.", error); 
	       }
		}finally {
			   try {
	             DBUtil.close(rs,st,null); 
	         } catch (Throwable error) {
	             if (error instanceof JDBCException) {
	                 throw (JDBCException)error;
	             } else {
	                 throw new JDBCException(ExceptionImpl.FATAL, "Error closing statement getting getCurrentPolicyStatus.", error);
	             }
	         }
			
		}
		return status;
	}

	
	public static Map<String, String> getCurrentWorkflowStatus(Connection conn, String entityType, String entityReference,
	            String taskName) throws Exception {
	        Map<String, String> statusMap = new HashMap<String, String>();
	       
	        CallableStatement callStmt = null;
	        if (taskName != null) {
	            try {
	                callStmt = conn.prepareCall("{? = call K_WORKFLOW_ACTIVITY_MANAGEMENT.f_get_status(?, ?, ?, ?,? )}");
	                callStmt.registerOutParameter(1, Types.INTEGER);
	                callStmt.registerOutParameter(5, Types.VARCHAR);
	                callStmt.registerOutParameter(6, Types.VARCHAR);
	                callStmt.setString(2, entityType);
	                callStmt.setString(3, entityReference);
	                callStmt.setString(4, taskName);
	                callStmt.execute();
	                if (callStmt.getLong(1) != 0) {
	                    throw new com.coverall.exceptions.ServiceException(
	                            com.coverall.exceptions.ServiceException.FATAL,
	                            callStmt.getString(6),
	                            null);
	                }
	             
	                statusMap.put(APIConstant.TASK_STATUS, callStmt.getString(5));
	            } catch (Exception ex) {
	                LogMinder.getLogMinder().log(
	                        LogEntry.SEVERITY_FATAL,
	                        WorkflowEventNotifier.class.getName(),
	                        new Exception().getStackTrace()[0].toString(),
	                        ServletConfigUtil.COMPONENT_FRAMEWORK,
	                        new Object[] {},
	                        "Error occured when try to get the event status for the task " + taskName,
	                        ex,
	                        LogMinderDOMUtil.VALUE_MIC);
	            } finally {
	                DBUtil.close(null, callStmt,null);
	            }
	        }
	        return statusMap;
	    }
	
	  

	  public static void setInProgress(Connection conn, long activityId, int percent) {
	        CallableStatement st = null;

	        try {
	            st = conn.prepareCall("{ ? = call K_WORKFLOW_ACTIVITY_MANAGEMENT.f_set_progress(?, ?, ?, ?)}");
	            st.registerOutParameter(1, Types.INTEGER);
	            st.setLong(2, activityId);
	            st.setInt(3, percent);
	            st.setString(4, "Y");
	            st.registerOutParameter(5, Types.VARCHAR);
	            st.execute();
	            if (st.getInt(1) != 0) {
	                throw new ServiceException(st.getString(5), null);
	            }
	        } catch (Throwable error) {
	            LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
	                                         WorkFlowService.class.getName(),
	                                         new Exception().getStackTrace()[0].toString(),
	                                         ServletConfigUtil.COMPONENT_FRAMEWORK,
	                                         new Object[] { "Activity id =" +
	                                                        activityId,
	                                                        "percent = " +
	                                                        percent },
	                                         "Error setting progress percent",
	                                         error, LogMinderDOMUtil.VALUE_MIC);
	        } finally {
	            try {
	                DBUtil.close(null, st, null);
	            } catch (Throwable error) {
	            }
	        }
	    }
	  
	  

	  public  static void setBlocked(Connection conn, long activityId, String stageDesc) {
          CallableStatement st = null;

          try {
              st =
              conn.prepareCall("{ ? = call K_WORKFLOW_ACTIVITY_MANAGEMENT.f_set_blocked(?, ?, ?, ?)}"); 
              st.registerOutParameter(1, Types.INTEGER);
              st.setLong(2, activityId);
              st.setString(3, stageDesc);
              st.setString(4, "Y");
              st.registerOutParameter(5, Types.VARCHAR);
              st.execute();
              if (st.getInt(1) != 0) {
                  throw new ServiceException(st.getString(5), null);
              }
          } catch (Throwable error) {
              LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                                           WorkflowUtil.class.getName(),
                                           new Exception().getStackTrace()[0].toString(),
                                           ServletConfigUtil.COMPONENT_FRAMEWORK,
                                           new Object[] { "Activity id =" +
                                                          activityId },
                                           "Error marking transaction as blocked",
                                           error,
                                           LogMinderDOMUtil.VALUE_MIC);
          } finally {
              try {
                  DBUtil.close(null, st, null);
              } catch (Throwable error) {
              }
          }
  }
	  
	  

	  public static long  getActivityID(Connection conn,String entityType, String entityReference, String taskName) {
          CallableStatement st = null;
 
  	      long activityId = -1; 

          try {
              st =
              conn.prepareCall("{ ? = call K_WORKFLOW_ACTIVITY_MANAGEMENT.f_get_activity_id(?, ?, ?, ?, ?)}");
              st.registerOutParameter(1, Types.INTEGER);
              st.setString(2, entityType);
              st.setString(3, entityReference);
              st.setString(4, taskName);
              st.registerOutParameter(5, Types.BIGINT);
              st.registerOutParameter(6, Types.VARCHAR);
              st.execute();
              
              
              if (st.getInt(1) != 0) {
            	  
                  throw new ServiceException(st.getString(6), null);
              }
              
              activityId = st.getLong(5);
                            
          } catch (Throwable error) {
              LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                                           BookOverrideEntity.class.getName(),
                                           new Exception().getStackTrace()[0].toString(),
                                           ServletConfigUtil.COMPONENT_FRAMEWORK,
                                           new Object[] { "taskName =" +
                                        		   taskName },
                                           "Error marking transaction as blocked",
                                           error,
                                           LogMinderDOMUtil.VALUE_MIC);
          } finally {
              try {
                  DBUtil.close(null, st, null);
              } catch (Throwable error) {
              }
          }
		return activityId;
  }
	  
	  
		public static String getStageDesc(Connection conn,  String entityReference , long activityId) throws Exception {
			String stageDesc = null;

			PreparedStatement stmt = null;
			ResultSet rs = null;
			String sqlQuery = " SELECT wac_stage_desc FROM wfl_activities WHERE wac_entity_reference = ? AND wac_id = ? ";
			
			try {
				stmt = conn.prepareStatement(sqlQuery); 
				stmt.setString(1, entityReference);
				stmt.setLong(2, activityId);
				rs = stmt.executeQuery();

				while (rs.next()) {
	                   
					stageDesc = rs.getString("wac_stage_desc"); 
					
				}


			} catch (SQLException e) {
				 LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                         BookOverrideEntity.class.getName(),
                         new Exception().getStackTrace()[0].toString(),
                         ServletConfigUtil.COMPONENT_FRAMEWORK,
                         new Object[] { "taskName =" +
                      		   "Booking" },
                         "Error in getStageDesc",
                         e,
                         LogMinderDOMUtil.VALUE_MIC);			
				 e.printStackTrace();
			} finally {
				

				try {
	                  DBUtil.close(null, stmt, null);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			return stageDesc;


		}
    
		
		
		
		public static boolean getEntityType(Connection conn,  String entityReference ) throws Exception {
			boolean isPolicyEntity = false;

			PreparedStatement stmt = null;
			ResultSet rs = null;
			String sqlQuery = " SELECT decode(count(gid),0,'false','true') isPolicyEntity FROM vw_mis_quote_policies \r\n" + 
					" WHERE entity_reference =  ? \r\n" + 
					" AND policy_quote_indicator = 'P'" +
				    " AND entity_type = 'POLICY' ";
			
			try {
				stmt = conn.prepareStatement(sqlQuery); 
				stmt.setString(1, entityReference);
				rs = stmt.executeQuery();

				while (rs.next()) {
					isPolicyEntity =   new Boolean( rs.getString(APIConstant.IS_POLICY_ENTITY)).booleanValue();
					
				}


			} catch (SQLException e) {
				 LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                         BookOverrideEntity.class.getName(),
                         new Exception().getStackTrace()[0].toString(),
                         ServletConfigUtil.COMPONENT_FRAMEWORK,
                         new Object[] { "taskName =" +
                      		   "Booking" },
                         "Error in getStageDesc",
                         e,
                         LogMinderDOMUtil.VALUE_MIC);			
				 e.printStackTrace();
			} finally {
				

				try {
	                  DBUtil.close(null, stmt, null);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			return isPolicyEntity;


		}
		
		
		
		
		public static boolean isWorkflowStageReached (Connection conn,  String entityType, String workflowTask , String entityReference ) throws Exception {
			boolean isWorkflowStageReached = false;
			
			PreparedStatement stmt = null;
			ResultSet rs = null;
			String sqlQuery = " SELECT decode(count(wac_id),0,'FALSE','TRUE') isWorkflowStageReached FROM wfl_activities WHERE wac_entity_reference = ?\r\n" + 
					"AND wac_task_id IN (\r\n" + 
					"SELECT wwt_task_id FROM wfl_workflow_tasks WHERE wwt_workflow_id = (\r\n" + 
					"select wwo_id from WFL_WORKFLOWS where WWO_ENTITY_TYPE =  ?\r\n" + 
					"\r\n" + 
					") AND wwt_task_name = ?  )" ;
			
			try {
				stmt = conn.prepareStatement(sqlQuery); 
				stmt.setString(1, entityReference);
				stmt.setString(2, entityType);  
				stmt.setString(3, workflowTask);

				rs = stmt.executeQuery();

				while (rs.next()) {
					isWorkflowStageReached =   new Boolean( rs.getString(APIConstant.IS_WORKFLOW_STAGE_REACHED)).booleanValue();
					
				}


			} catch (SQLException e) {
				 LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                         BookOverrideEntity.class.getName(),
                         new Exception().getStackTrace()[0].toString(),
                         ServletConfigUtil.COMPONENT_FRAMEWORK,
                         new Object[] { "taskName =" +
                      		   "Booking" },
                         "Error in getStageDesc",
                         e,
                         LogMinderDOMUtil.VALUE_MIC);			
				 e.printStackTrace();
			} finally {
				

				try {
	                  DBUtil.close(null, stmt, null);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			return isWorkflowStageReached;


		}
		
		
		
		
		public static boolean checkIfFormPresent(Connection conn,  String entityReference, String formId, String occurance) throws Exception {
			boolean isFormExists = false;

			PreparedStatement stmt = null;
			ResultSet rs = null;
			/* Changes not done for same name document as query is based on PDT_ID */
			String sqlQuery = "SELECT count(*) isFormDataExists FROM mis_forms where mis_forms.MFO_POLICY_REFERENCE = ? AND mfo_form_number= (SELECT pdt_name FROM ps_document_template"+ 
							  " WHERE pdt_id=? AND NVL(pdt_date_deleted,to_date(' 1000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) = to_date(' 1000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))"+
							  " AND NVL(MFO_OCCURRENCE,0)=?";
			
			try {
				stmt = conn.prepareStatement(sqlQuery); 
				stmt.setString(1, entityReference);
				stmt.setString(2, formId);
				stmt.setString(3, occurance);
				
				rs = stmt.executeQuery();

				while (rs.next()) {
					isFormExists =   rs.getInt(APIConstant.IS_ENTITY_FORM_EXISTS)==0?false:true;
				}
			} catch (Exception e) {
				 LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                         BookOverrideEntity.class.getName(),
                         new Exception().getStackTrace()[0].toString(),
                         ServletConfigUtil.COMPONENT_FRAMEWORK,
                         new Object[] { "taskName =" +
                      		   "Booking" },
                         "Error in getStageDesc",
                         e,
                         LogMinderDOMUtil.VALUE_MIC);			
				 e.printStackTrace();
			} finally {
				

				try {
	                  DBUtil.close(null, stmt, null);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			return isFormExists;


		}
		
		
		public static boolean checkIfFormVariableIsAvailable(Connection conn,  String entityReference , int formID , String varDesc, String varOccurence) throws Exception {
			boolean isFormVarDataValid = false;

			PreparedStatement stmt = null;
			ResultSet rs = null;
			/* Changes not done for same name document as query is based on PDT_ID */
			String sqlQuery = " SELECT DECODE(COUNT(mfv_id),0,'false','true') isFormVarDataValid \r\n" + 
					"FROM MIS_FORM_VARS\r\n" + 
					"WHERE mfv_policy_reference =  ? \r\n" + 
					"AND mfv_form_number        =\r\n" + 
					"  (SELECT pdt_name\r\n" + 
					"  FROM ps_document_template\r\n" + 
					"  WHERE pdt_id                                                                        = ? \r\n" + 
					"  AND NVL(pdt_date_deleted,to_date(' 1000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) = to_date(' 1000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')\r\n" + 
					"  )\r\n" + 
					" AND mfv_var_desc = ?"+
					" AND NVL(MFV_OCCURRENCE,0)= ?";
			
			try {
				stmt = conn.prepareStatement(sqlQuery); 
				stmt.setString(1, entityReference);
				stmt.setInt(2, formID);
				stmt.setString(3, varDesc);
				stmt.setString(4, varOccurence);


				rs = stmt.executeQuery();

				while (rs.next()) {
					isFormVarDataValid =   new Boolean( rs.getString(APIConstant.IS_FORM_VAR_DATA_VALID)).booleanValue();
					
				}


			} catch (SQLException e) {
				 LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                         BookOverrideEntity.class.getName(),
                         new Exception().getStackTrace()[0].toString(),
                         ServletConfigUtil.COMPONENT_FRAMEWORK,
                         new Object[] { "taskName =" +
                      		   "Booking" },
                         "Error in getStageDesc",
                         e,
                         LogMinderDOMUtil.VALUE_MIC);			
				 e.printStackTrace();
			} finally {
				

				try {
	                  DBUtil.close(null, stmt, null);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			return isFormVarDataValid;


		}
		
		public static boolean checkIfFormVariableIsAvailableV3(Connection conn,  String entityReference , int formID , String varDesc, String varOccurence) throws Exception {
			boolean isFormVarDataValid = false;

			PreparedStatement stmt = null;
			ResultSet rs = null;
			/* Changes not done for same name document as query is based on PDT_ID */
			String sqlQuery = " SELECT DECODE(COUNT(mfv_id),0,'false','true') isFormVarDataValid \r\n" + 
					"FROM MIS_FORM_VARS\r\n" + 
					"WHERE mfv_policy_reference =  ? \r\n" + 
					"AND mfv_form_number        =\r\n" + 
					"  (SELECT pdt_name\r\n" + 
					"  FROM ps_document_template\r\n" + 
					"  WHERE pdt_id                                                                        = ? \r\n" + 
					"  AND NVL(pdt_date_deleted,to_date(' 1000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) = to_date(' 1000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')\r\n" + 
					"  )\r\n" + 
					" AND mfv_var_name = ?"+
					" AND NVL(MFV_OCCURRENCE,0)= ?";
			
			try {
				stmt = conn.prepareStatement(sqlQuery); 
				stmt.setString(1, entityReference);
				stmt.setInt(2, formID);
				stmt.setString(3, varDesc);
				stmt.setString(4, varOccurence);


				rs = stmt.executeQuery();

				while (rs.next()) {
					isFormVarDataValid =   new Boolean( rs.getString(APIConstant.IS_FORM_VAR_DATA_VALID)).booleanValue();
					
				}


			} catch (SQLException e) {
				 LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                         BookOverrideEntity.class.getName(),
                         new Exception().getStackTrace()[0].toString(),
                         ServletConfigUtil.COMPONENT_FRAMEWORK,
                         new Object[] { "taskName =" +
                      		   "Booking" },
                         "Error in getStageDesc",
                         e,
                         LogMinderDOMUtil.VALUE_MIC);			
				 e.printStackTrace();
			} finally {
				

				try {
	                  DBUtil.close(null, stmt, null);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			return isFormVarDataValid;


		}
		
		

		public static boolean checkIfPolicyBooked(Connection conn,  String entityReference ) throws Exception {
			boolean isPolicyBooked = false;

			PreparedStatement stmt = null;
			ResultSet rs = null;
			String sqlQuery = " SELECT decode(count(gid),0,'false','true') isPolicyBooked FROM vw_mis_quote_policies,mis_policies\r\n" + 
					"WHERE vw_mis_quote_policies.entity_reference = mis_policies.mpo_policy_reference\r\n" + 
					"AND mis_policies.mpo_book_flag = 'Y'\r\n" + 
					"AND vw_mis_quote_policies.entity_reference = ?\r\n" + 
					"AND booking_status = 'COMPLETE'  ";
			
			try {
				stmt = conn.prepareStatement(sqlQuery); 
				stmt.setString(1, entityReference);
				rs = stmt.executeQuery();

				while (rs.next()) {
					isPolicyBooked =   new Boolean( rs.getString(APIConstant.IS_POLICY_BOOKED)).booleanValue();
					
				}


			} catch (SQLException e) {
				 LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                         BookOverrideEntity.class.getName(),
                         new Exception().getStackTrace()[0].toString(),
                         ServletConfigUtil.COMPONENT_FRAMEWORK,
                         new Object[] { "taskName =" +
                      		   "Booking" },
                         "Error in getStageDesc",
                         e,
                         LogMinderDOMUtil.VALUE_MIC);			
				 e.printStackTrace();
			} finally {
				

				try {
	                  DBUtil.close(null, stmt, null);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			return isPolicyBooked;
		}
		
		
        public static void setComplete(long activityId, Connection conn, String userId) {
            CallableStatement st = null;
            try {
                st = conn.prepareCall("{ ? = call K_WORKFLOW_ACTIVITY_MANAGEMENT.f_set_complete(?, ?, ?, ?, ?)}");
                st.registerOutParameter(1, Types.INTEGER);
                st.registerOutParameter(6, Types.INTEGER);
                st.setLong(2, activityId);
                st.setString(3, "Y");
                st.setString(4, null);
                st.setString(5, "Y");  
                st.execute();
                if (st.getInt(1) != 0) {
                    throw new ServiceException(st.getString(6), null);
                }
                conn.commit();
            } catch (Throwable error) {
            	if(conn != null)
            	{
            		try {
                 	   conn.rollback();
                 	}catch(Exception e){
                 	    	
                 	}
            	}
                LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                                             WorkFlowService.class.getName(),
                                             new Exception().getStackTrace()[0].toString(),
                                             ServletConfigUtil.COMPONENT_FRAMEWORK,
                                             new Object[] { "Activity id=" + activityId, "instanceId="  },
                                             "Error marking transaction as complete",
                                             error,
                                             LogMinderDOMUtil.VALUE_MIC);
            } finally {
                try {
                    DBUtil.close(null, st, null);
                } catch (Throwable error) {
                }
            }
        }
        
        
        
        public static boolean hasFormModifyPermission(String domainName, String userId) throws Exception {
 	       AdminX adminX = null;
 	       boolean hasFormModifyPermission = false;

 	       try {
 	           adminX = new AdminX();

                /* Check Auto Issue permission */
 	          hasFormModifyPermission =  adminX.hasPermission(domainName, userId, AdminX.USER_PRINCIPAL, adminX.getPermission("Modify Forms"));

 	       } catch (Exception se) {
 	           throw se;
 	       }   
 	       return hasFormModifyPermission;
 	}
 	
        
        
    	public static boolean checkIfBinder(Connection conn,  String entityReference ) throws Exception {
			boolean isBinder = false;

			PreparedStatement stmt = null;
			ResultSet rs = null;
			String sqlQuery = "  select decode(count(gid),0,'false','true') isBinder from vw_mis_quote_policies \r\n " + 
					" where binder_flag = 'Y'  \r\n " + 
					" and entity_type = 'POLICY' \r\n " + 
					" and ENTITY_REFERENCE = ?  ";
			
			try {
				stmt = conn.prepareStatement(sqlQuery); 
				stmt.setString(1, entityReference);
				rs = stmt.executeQuery();

				while (rs.next()) {
					isBinder =   new Boolean( rs.getString(APIConstant.IS_BINDER)).booleanValue();
					
				}


			} catch (SQLException e) {
				 LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                         BookOverrideEntity.class.getName(),
                         new Exception().getStackTrace()[0].toString(),
                         ServletConfigUtil.COMPONENT_FRAMEWORK,
                         new Object[] { "taskName =" +
                      		   "Booking" },
                         "Error in getStageDesc",
                         e,
                         LogMinderDOMUtil.VALUE_MIC);			
				 e.printStackTrace();
			} finally {
				

				try {
	                  DBUtil.close(null, stmt, null);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			return isBinder;


		}
    	
    	
    	
    	
    	
    	public static boolean checkIfPolicyExists(Connection conn,  String entityReference , String entityType ) throws Exception {
			boolean isValidRequest = false;

			PreparedStatement stmt = null;
			ResultSet rs = null;
			String sqlQuery = " select decode(count(gid),0,'false','true') isValidRequest from vw_mis_quote_policies \r\n" + 
					" where entity_type =  ?  \r\n" + 
					" and entity_reference = ? ";
			
			try {
				stmt = conn.prepareStatement(sqlQuery); 
				stmt.setString(1, entityType);
				stmt.setString(2, entityReference);

				rs = stmt.executeQuery();

				while (rs.next()) {
					isValidRequest =   new Boolean( rs.getString(APIConstant.IS_VALID_REQUEST)).booleanValue();
					
				}


			} catch (SQLException e) {
				 LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                         BookOverrideEntity.class.getName(),
                         new Exception().getStackTrace()[0].toString(),
                         ServletConfigUtil.COMPONENT_FRAMEWORK,
                         new Object[] { "taskName =" +
                      		   "Booking" },
                         "Error in getStageDesc",
                         e,
                         LogMinderDOMUtil.VALUE_MIC);			
				 e.printStackTrace();
			} finally {
				

				try {
	                  DBUtil.close(null, stmt, null);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			return isValidRequest;


		}
		
    	
    	public static boolean checkIfUWRuleAndCommissionManagementWorkflowIsApplicable(User user,Connection conn,String entityReference , String entityType ) throws Exception {
    		CallableStatement st = null;
    		boolean isApplicable=false;
    		try {
                st = conn.prepareCall("{ ? = call k_workflow_activity_helper.f_get_modify_commission_task(?,?,?,?,?)}");
                st.registerOutParameter(1, Types.INTEGER);
                st.registerOutParameter(5, Types.VARCHAR);
                st.registerOutParameter(6, Types.VARCHAR);
                st.setString(2, entityType);
                st.setString(3, entityReference);
                st.setString(4, user.getFullName());
                st.execute();
                long errorCode=st.getInt(1);
                String errorDescription=st.getString(6);
                if (errorCode!=0) {
                    throw new ServiceException(errorDescription, null);
                }else{
                	if(st.getString(5).equalsIgnoreCase("Y"))
                		isApplicable=true;
                }
                st.close();
                st=null;
            } catch (Throwable error) {
            	if(conn != null)
            	{
            		try {
                 	   conn.rollback();
                 	}catch(Exception e){
                 	    	
                 	}
            	}
                LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                                             WorkFlowService.class.getName(),
                                             new Exception().getStackTrace()[0].toString(),
                                             ServletConfigUtil.COMPONENT_FRAMEWORK,
                                             new Object[] { "Entity reference=" + entityReference, "instanceId="  },
                                             "Error marking transaction as complete",
                                             error,
                                             LogMinderDOMUtil.VALUE_MIC);
            } finally {
                try {
                    DBUtil.close(null, st, null);
                } catch (Throwable error) {
                }
            }	
    	 return isApplicable;
    	}
    	
    	
    	public static boolean checkIfBillingWorkflowIsApplicable(User user,Connection conn,String entityReference , String entityType ) throws Exception {
    		CallableStatement st = null;
    		boolean isApplicable=false;
    		try {
                st = conn.prepareCall("{ ? = call k_workflow_activity_helper.f_get_modify_billing(?,?,?,?,?)}");
                st.registerOutParameter(1, Types.INTEGER);
                st.registerOutParameter(5, Types.VARCHAR);
                st.registerOutParameter(6, Types.VARCHAR);
                st.setString(2, entityType);
                st.setString(3, entityReference);
                st.setString(4, user.getFullName());
                st.execute();
                long errorCode=st.getInt(1);
                String errorDescription=st.getString(6);
                if (errorCode!=0) {
                    throw new ServiceException(errorDescription, null);
                }else{
                	if(st.getString(5).equalsIgnoreCase("Y"))
                		isApplicable=true;
                }
                st.close();
                st=null;
            } catch (Throwable error) {
            	if(conn != null)
            	{
            		try {
                 	   conn.rollback();
                 	}catch(Exception e){
                 	    	
                 	}
            	}
                LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                                             WorkFlowService.class.getName(),
                                             new Exception().getStackTrace()[0].toString(),
                                             ServletConfigUtil.COMPONENT_FRAMEWORK,
                                             new Object[] { "Entity reference=" + entityReference, "instanceId="  },
                                             "Error marking transaction as complete",
                                             error,
                                             LogMinderDOMUtil.VALUE_MIC);
            } finally {
                try {
                    DBUtil.close(null, st, null);
                } catch (Throwable error) {
                }
            }	
    	 return isApplicable;
    	}
    	
    	public static long getActivityIdForTheTask(Connection conn, String taskName, String entityReference, String entityType) throws SQLException{
    		
    		PreparedStatement ps=null;
    		ResultSet rs=null;
    		long activityId=0;
    		String queryForFecthingActivityId="SELECT wac_id activityId FROM WFL_ACTIVITIES WHERE WAC_ENTITY_REFERENCE=? AND WAC_TASK_ID=(SELECT WTA_ID FROM WFL_TASKS WHERE WTA_NAME=?) AND WAC_ENTITY_TYPE=?";
    		try {
    			ps=conn.prepareStatement(queryForFecthingActivityId);
    			ps.setString(1, entityReference);
    			ps.setString(2, taskName);
    			ps.setString(3,entityType);
    			rs=ps.executeQuery();
    			while(rs.next()){
    				activityId=rs.getLong("activityId");
    			}
    		}catch (SQLException e) {
    			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                        WorkFlowService.class.getName(),
                        new Exception().getStackTrace()[0].toString(),
                        ServletConfigUtil.COMPONENT_FRAMEWORK,
                        new Object[] { "Entity reference=" + entityReference, "instanceId="  },
                        "Error marking transaction as complete",
                        e,
                        LogMinderDOMUtil.VALUE_MIC);
    			throw e;
    		}finally{
    			try{
    				DBUtil.close(rs, ps);
    			}catch(Exception e){
    					
    			}
    		}
    		return activityId;
    		
    	}
    	
    	public static boolean checkIfFormCanBeModifiedForTheEntity(String userName,Connection conn, String entityType, String entityReference){
    		boolean canBeModified=false;
    		CallableStatement stPrimaryCheck=null;
    		CallableStatement st = null;
    		try {
    			stPrimaryCheck = conn.prepareCall("{ ? = call k_workflow_activity_helper.f_get_modify_form_task(?,?,?,?,?)}");
    			stPrimaryCheck.registerOutParameter(1, Types.INTEGER);
    			stPrimaryCheck.registerOutParameter(5, Types.VARCHAR);
    			stPrimaryCheck.registerOutParameter(6, Types.VARCHAR);
    			stPrimaryCheck.setString(2, entityType);
    			stPrimaryCheck.setString(3, entityReference);
    			stPrimaryCheck.setString(4, userName);
    			stPrimaryCheck.execute();
                long errorCode=stPrimaryCheck.getInt(1);
                String errorDescription=stPrimaryCheck.getString(6);
                if (errorCode!=0) {
                    throw new ServiceException(errorDescription, null);
                }else{
                	if(stPrimaryCheck.getString(5).equalsIgnoreCase("Y"))
                		canBeModified=true;
                }
                stPrimaryCheck.close();
            } catch (Throwable error) {
            	if(conn != null)
            	{
            		try {
                 	   conn.rollback();
                 	}catch(Exception e){
                 	    	
                 	}
            	}
                LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                                             WorkFlowService.class.getName(),
                                             new Exception().getStackTrace()[0].toString(),
                                             ServletConfigUtil.COMPONENT_FRAMEWORK,
                                             new Object[] { "Entity reference=" + entityReference, "instanceId="  },
                                             "Error marking transaction as complete",
                                             error,
                                             LogMinderDOMUtil.VALUE_MIC);
            } finally {
                try {
                    DBUtil.close(null, stPrimaryCheck);
                } catch (Throwable error) {
                }
            }	
    		if(canBeModified){
    		try {
    			st = conn.prepareCall("{ ? = call K_Transaction_Management.f_is_qfe(?,?)}");
    			st.registerOutParameter(1, Types.INTEGER);
    			st.setString(2, entityType);
    			st.setString(3, entityReference);
    			st.execute();
    			int flag=st.getInt(1);
    			if (flag==0) {
    				canBeModified=false;
    			}
    			st.close();
    			st=null;
    		} catch (Throwable error) {
    			if(conn != null)
    			{
    				try {
    					conn.rollback();
    				}catch(Exception e){

    				}
    			}
    			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
    					WorkFlowService.class.getName(),
    					new Exception().getStackTrace()[0].toString(),
    					ServletConfigUtil.COMPONENT_FRAMEWORK,
    					new Object[] { "Entity reference=" + entityReference, "instanceId="  },
    					"Error while determining if form can be modified or not",
    					error,
    					LogMinderDOMUtil.VALUE_MIC);
    		} finally {
    			try {
    				DBUtil.close(null, st, null);
    			} catch (Throwable error) {
    			}
    		}
    		}
    		return canBeModified;

    	}
    	
    	public static boolean checkIfUserHasTheRequiredPermission(com.coverall.security.authentication.User user, String permissionName) throws Exception{
    		AdminX adminX = null;
    		boolean hasPermission = false;
    		boolean isAdmin=false;

    		try {
    			adminX = new AdminX();
    			/**  Check the administrators role to user      */
    			ArrayList roles;
    			try {
    				roles = new AdminX().listUserRoles(user.getDomain(), user.getUserId().substring(0, user.getUserId().indexOf("@")), false);
    				Iterator it = roles.iterator();
    				while (it.hasNext()) {
    					String toCompare = ((Principal)it.next()).getName();
    					if (toCompare.equalsIgnoreCase(APIConstant.ADMINISTRATOR_ROLE)) {
    						isAdmin = true;
    						break;
    					}
    				}
    			} catch (SecurityException e) {
    				e.printStackTrace();
    			}
    			if(!isAdmin){
    				hasPermission =  adminX.hasPermission(user.getDomain(), user.getUserId().substring(0, user.getUserId().indexOf("@")), AdminX.USER_PRINCIPAL, adminX.getPermission(permissionName));
    			}else{
    				hasPermission=true;
    			}

    		} catch (Exception se) {
    			throw se;
    		}   
    		return hasPermission;
    	}
    	
      	public static boolean checkIfPolicyIsReadyForBooking(Connection conn, String entityReference , String entityType ) throws Exception {
    		CallableStatement checkStmt = null;
    		boolean isApplicable=false;
    		try {
    			checkStmt = conn.prepareCall("{ ? = call k_transaction_management.f_is_policy_ready_for_booking(?, ?)}");
    			checkStmt.registerOutParameter(1, Types.VARCHAR);
    			checkStmt.setString(2, entityType);
    			checkStmt.setString(3, entityReference);
    			checkStmt.execute();
    			
    			String isReadyForBooking = checkStmt.getString(1);

    			if ("Y".equalsIgnoreCase(isReadyForBooking)) {
    				isApplicable=true;
    			}

            } catch (Throwable error) {
            	LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                                             WorkFlowService.class.getName(),
                                             new Exception().getStackTrace()[0].toString(),
                                             ServletConfigUtil.COMPONENT_FRAMEWORK,
                                             new Object[] { "Entity reference=" + entityReference, "instanceId="  },
                                             "Error checking if policy is ready for booking",
                                             error,
                                             LogMinderDOMUtil.VALUE_MIC);
            } finally {
                try {
                    DBUtil.close(null, checkStmt, null);
                } catch (Throwable error) {
                }
            }	
    	 return isApplicable;
    	}
      	
      	public static boolean checkIfLatestRevision(Connection conn,  String entityReference , String entityType ) throws Exception {
      		String orgEntityReference=entityReference.substring(0,entityReference.length()-3);
      		long currentRevision=Long.parseLong(entityReference.substring(entityReference.length()-3));
      		orgEntityReference+="000";
      		
			boolean isLatestRevision = false;

			PreparedStatement stmt = null;
			ResultSet rs = null;
			String sqlQuery = "SELECT max(revision_number) latestRevision\r\n" + 
					"FROM ev_mis_quote_policies\r\n" + 
					"WHERE org_entity_reference=UPPER(?)\r\n" + 
					"AND entity_type=UPPER(?)";
			
			try {
				stmt = conn.prepareStatement(sqlQuery); 
				stmt.setString(1, orgEntityReference);
				stmt.setString(2, entityType);
				
				rs = stmt.executeQuery();

				while (rs.next()) {
					long latestRevision=rs.getLong("latestRevision");
					if(currentRevision==latestRevision) {
						isLatestRevision=true;
					}
					
				}
			} catch (SQLException e) {
				 LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
						 className,
                         new Exception().getStackTrace()[0].toString(),
                         ServletConfigUtil.COMPONENT_FRAMEWORK,
                         new Object[] { "checkIfLatestRevision" },
                         "Error in checkIfLatestRevision",
                         e,
                         LogMinderDOMUtil.VALUE_MIC);			
				 e.printStackTrace();
			} finally {
				

				try {
	                  DBUtil.close(rs, stmt, null);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			return isLatestRevision;


		}
      	
      	public static boolean checkIfTransactionIsAllowedOnQuotePolicy(Connection conn,  User user,String entityReference , String entityType, String transactionName ) throws Exception {
      		CallableStatement callStmt=null;
      		try {
      			//Extracting user specific info
      			String userName=user.getUserId();
      			String domain=user.getDomain();
      			String rolesString="";

      			//Fetching roles list for the user
      			AuthorizationService authorizationService = NsRestClientUtil.getAuthorizationServiceInstance(user.getDomain());
      			Set<NsRole> roles = authorizationService.getAssignedRolesForUser(user.getFullName()); //get user roles assigned to loggedin user
      			for(NsRole role:roles){
      				rolesString+="''"+role.getName()+"'',";
      			}
      			rolesString=rolesString.substring(0,rolesString.length()-1);

      			//Firing Database Query for getting all transactions

      			callStmt = conn.prepareCall("{?= call K_TRANSACTION_MANAGEMENT.F_GET_AVAILABLE_TRANSACTIONS(?,?,?,?,?,?,?,?)}");
      			callStmt.registerOutParameter(1, Types.INTEGER);
      			callStmt.setString(2, entityType);
      			callStmt.setString(3, entityReference);
      			callStmt.setString(4, domain);
      			callStmt.setString(5, userName);
      			callStmt.registerOutParameter(6, Types.VARCHAR);
      			callStmt.registerOutParameter(7, Types.VARCHAR);
      			callStmt.setString(8, "N");
      			callStmt.setString(9, rolesString);

      			callStmt.executeUpdate();
      			String transactions = callStmt.getString(6);
      			if(transactions!=null && !transactions.trim().equalsIgnoreCase("")){
      				ArrayList<String> transactionList=getListOfTransactionAction(transactions);
      				if(transactionList.contains(transactionName.toLowerCase())) {
      					return true;
      				}
      			}

      		}catch (Exception e) {
      			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
						 className,
                        e.getMessage(),
                        ServletConfigUtil.COMPONENT_FRAMEWORK,
                        new Object[] { "checkIfTransactionIsAllowedOnQuotePolicy" },
                        "Error in checkIfTransactionIsAllowedOnQuotePolicy",
                        e,
                        LogMinderDOMUtil.VALUE_MIC);	
      		}finally{
      			try {
      				DBUtil.close(null, callStmt, null);
      			} catch (SQLException e) {
      				// do nothing
      			}
      		}
      		return false;

      	}

      	private static ArrayList<String> getListOfTransactionAction(String transactionResponse){
      		ArrayList<String> transactions=new ArrayList<String>();

      		for(String transactionStrings:transactionResponse.split("~")){
      			String transactionName=transactionStrings.split("\\?")[0];
      			transactions.add(transactionName.toLowerCase());
      		}
      		return transactions;
      	}
      	
      	public static boolean checkIfEntityIsConverted(Connection conn, String entityType, String entityReference ) throws Exception {
      		//Checks if policy is booked
      		//If quote is converted to policy
      		CallableStatement st = null;
      		boolean isConverted=false;
      		try {
      			st = conn.prepareCall("{ ? = call K_Transaction_Management.f_is_converted(?,?)}");
      			st.registerOutParameter(1, Types.VARCHAR);
      			st.setString(2, entityType.toUpperCase());
      			st.setString(3, entityReference);
      			st.execute();
      			String convertedEntity=st.getString(1);
      			isConverted="Y".equalsIgnoreCase(convertedEntity);

      		} catch (Throwable error) {
      			if(conn != null){
      				try {
      					conn.rollback();
      				}catch(Exception e){

      				}
      			}
      			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
      					WorkFlowService.class.getName(),
      					new Exception().getStackTrace()[0].toString(),
      					ServletConfigUtil.COMPONENT_FRAMEWORK,
      					new Object[] { "Entity reference=" + entityReference, "instanceId="  },
      					"Error while checking if entity is converted",
      					error,
      					LogMinderDOMUtil.VALUE_MIC);
      		} finally {
      			try {
      				DBUtil.close(null, st, null);
      			} catch (Throwable error) {
      			}
      		}	
      		return isConverted;
      	}
      	
      	public static String checkMoratoriumMessage(Connection conn, String entityReference , String entityType ) throws Exception {
    		CallableStatement callStmt = null;
    		String moratoriumMessage=null;
    		try {
    			    			
				callStmt = conn.prepareCall("{?= call k_moratorium_management.f_get_moratorium_message(?, ?, ?, ?, ?, ?, ?)}");
      			callStmt.registerOutParameter(1, Types.INTEGER);
      			callStmt.setString(2, entityType);
      			callStmt.setString(3, entityReference);
      			callStmt.setString(4, "");
      			callStmt.setString(5, "Book");
      			callStmt.registerOutParameter(6, Types.VARCHAR);
      			callStmt.registerOutParameter(7, Types.VARCHAR);
      			callStmt.registerOutParameter(8, Types.VARCHAR);
				
				callStmt.executeUpdate();
												
				if (callStmt.getInt(1) != 0) {
	                throw new ServiceException(callStmt.getString(8), null);
	            }

				String message = callStmt.getString(6);
				if(null != message || !"".equalsIgnoreCase(message)){
					moratoriumMessage = message ;
				}
				
            } catch (Throwable error) {
            	LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
                                             WorkFlowService.class.getName(),
                                             new Exception().getStackTrace()[0].toString(),
                                             ServletConfigUtil.COMPONENT_FRAMEWORK,
                                             new Object[] { "Entity reference=" + entityReference, "instanceId="  },
                                             "Error checking Moratorium message",
                                             error,
                                             LogMinderDOMUtil.VALUE_MIC);
            } finally {
                try {
                    DBUtil.close(null, callStmt, null);
                } catch (Throwable error) {
                }
            }	
    	 return moratoriumMessage;
    	}

}
