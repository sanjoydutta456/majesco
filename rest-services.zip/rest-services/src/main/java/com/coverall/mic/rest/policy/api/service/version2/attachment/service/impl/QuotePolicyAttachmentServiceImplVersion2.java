package com.coverall.mic.rest.policy.api.service.version2.attachment.service.impl;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.map.ObjectMapper;

import com.coverall.mt.util.APIAuditTrailLog;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.factory.impl.PolicyAPIFactoryServiceImpl;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.impl.QuotePolicyAttachmentServiceImpl;
import com.coverall.mic.rest.policy.api.service.model.ConfirmationMessage;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyAttachmentRequest;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyAttachmentResponse;
import com.coverall.mic.rest.policy.api.service.model.SourceSystemInformationBean;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mic.rest.policy.api.service.util.WorkflowUtil;
import com.coverall.mic.rest.policy.api.service.version2.attachment.service.model.QuotePolicyAttachmentRequestListVersion2;
import com.coverall.mic.rest.policy.api.service.version2.attachment.service.model.QuotePolicyAttachmentRequestVersion2;
import com.coverall.mt.cms.FileCabinetAssociation;
import com.coverall.mt.http.User;
import com.coverall.mt.webservices.WebServiceLoggerUtil;

public class QuotePolicyAttachmentServiceImplVersion2 extends
		QuotePolicyAttachmentServiceImpl {
	
	private QuotePolicyAttachmentRequest updateCallAttachmentFile=null;
	
	public QuotePolicyAttachmentServiceImplVersion2(String entityReference,
			String entityType, HttpServletRequest request) {
		super(entityReference, entityType, request);
	}

	
	@Override
	public Object addQuotePolicyAttachmentFile()
			throws Exception {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		user = User.getUser(request);
		Connection conn = null;
		customerCode=getCustomerCodeFromUser(user).toUpperCase();
		List<QuotePolicyAttachmentResponse> filteredAttachmentList=new ArrayList<QuotePolicyAttachmentResponse>();
		ConfirmationMessage confirmationMessage=null;

		try{
			conn=requestContext.getConnection();

			if(checkSecurityFeatureInFileOperations(conn)){
				if(!WorkflowUtil.checkIfUserHasTheRequiredPermission(requestContext.getUser(), APIConstant.ATTACH_FILE_PERMISSION)) {
					String errMsg = user.getUserId()+" doesn't have permission to attach a file.";
					List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
					String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
					WebServiceLoggerUtil.logInfo("QuotePolicyAttachmentServiceImpl", "addQuotePolicyAttachmentFile", errMsg, new Object[] { errMsg });
					throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
				}
			}

			if(WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)){
				String folderObjectId=getFolderObjectIdFromEntityReference(conn,entityReference);
				List<QuotePolicyAttachmentRequest> fileRequestList=new ArrayList<QuotePolicyAttachmentRequest>();
				APIAuditTrailLog auditTrailLog=null;
				
				if(isUpdateCall){
					fileRequestList.add(updateCallAttachmentFile);
				}else{
				 ObjectMapper mapper=new ObjectMapper();
				 String inputJson=APIOperationUtil.fetchRequestBody(request);
				 QuotePolicyAttachmentRequestListVersion2 attachmentRequestListVersion2=mapper.readValue(inputJson, QuotePolicyAttachmentRequestListVersion2.class);
				 fileRequestList=convertQuotePolicyAttachmentRequestVerionedToWithoutVersion(attachmentRequestListVersion2);
				 //Auditing logic
				 auditTrailLog=requestContext.getAuditTrailLog();
				 APIOperationUtil.populateAPIAuditLog(auditTrailLog, attachmentRequestListVersion2.getSourceSystemCode(), attachmentRequestListVersion2.getSourceSystemUserId(), attachmentRequestListVersion2.getSourceSystemRequestNo(), RESOURCE_TYPE, PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
				}
			
				Set<String> listOfFilesAdded=new HashSet<String>();
				for(QuotePolicyAttachmentRequest fileInput: fileRequestList){
					validateFileInputs(fileInput);
					//File Data
					String fileData=fileInput.getFile();
					byte[] fileDataByte = Base64.decodeBase64(fileData);
					InputStream targetStream = new ByteArrayInputStream(fileDataByte);

					//File meta-data
					String fileName=fileInput.getFilename();
					String fileExtension=fileName.contains(".")?"."+((fileName.split("\\.")[1]).toLowerCase()):"";
					fileName=fileName.contains(".")?(fileName.split("\\.")[0]):fileName;


					FileCabinetAssociation fileCabAsso = new FileCabinetAssociation();
					fileCabAsso.setFolderObjectId(Long.parseLong(folderObjectId));
					//Temporary folder created for uploading file to sling
					String temporaryFolderLocation=getTemporaryFolderLocation();
					fileCabAsso.setTempDirPath(temporaryFolderLocation);
					fileCabAsso.setFileName(fileName);
					fileCabAsso.setFileExtension(fileExtension);
					fileCabAsso.setFilePath(FILE_CABINET_FOLDER+"/"+entityType.toUpperCase()+"/"+entityReference.toUpperCase());
					fileCabAsso.setFileDescription(fileInput.getFileDescription());
					fileCabAsso.setUserCreated(user.getFullName());
					fileCabAsso.setEntityType(entityType);
					fileCabAsso.setEntityReference(entityReference);
					fileCabAsso.setFileInputStream(targetStream);
					fileCabAsso.setFileSize(targetStream.available());
					fileCabAsso.setFileType(getMimeTypeForFile(conn,fileExtension));
					fileCabAsso.insert(user);
					String fileId=fileCabAsso.getFilePath().substring(fileCabAsso.getFilePath().lastIndexOf("/")+1);
					listOfFilesAdded.add(fileId);
					conn.commit();
					deleteTemporaryFolder(temporaryFolderLocation);
					if(!isUpdateCall){
					 //Adding specifics
					 APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, entityReference, fileId, "Added File");
					}

				}
				confirmationMessage=new ConfirmationMessage();
				confirmationMessage.setCode("Success");
				confirmationMessage.setDescription("Files added with Id: "+StringUtils.join(listOfFilesAdded, ','));
				for(String fieldId:listOfFilesAdded){
					filteredAttachmentList.add(getFileSpecificMetaDataForEntity(conn, folderObjectId,fieldId).get(0));
				}

			}else{
				String errMsg = entityType + " " + entityReference + " was not found. Please check input parameters.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("QuotePolicyAttachmentServiceImpl", "addQuotePolicyAttachmentFile", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
		}catch (APIException e) {
			WebServiceLoggerUtil.logError("QuotePolicyAttachmentServiceImpl", "addQuotePolicyAttachmentFile", e.getLocalizedMessage(), new Object[] { e.getErrorMessage() }, null);
			throw e;
		} catch (Exception e) {
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(e.getMessage()));

			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError("QuotePolicyAttachmentServiceImpl", "addQuotePolicyAttachmentFile", "Failed:", new Object[] { e.getMessage() }, e);
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,e);
		}
		if(isUpdateCall){
			return filteredAttachmentList;
		}else{
			return confirmationMessage;	
		}
	}

	@Override
	public Object updateQuotePolicyAttachmentFile(
			String fieldId) throws Exception {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();

		if(checkSecurityFeatureInFileOperations(requestContext.getConnection())){
		if(!WorkflowUtil.checkIfUserHasTheRequiredPermission(requestContext.getUser(), APIConstant.REMOVE_FILE_PERMISSION) && !WorkflowUtil.checkIfUserHasTheRequiredPermission(requestContext.getUser(), APIConstant.ATTACH_FILE_PERMISSION)){
			String errMsg = user.getUserId()+" doesn't have permission to both add and delete a file. Thus, update operation cannot be performed.";
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			WebServiceLoggerUtil.logInfo("QuotePolicyAttachmentServiceImpl", "updateQuotePolicyAttachmentFile", errMsg, new Object[] { errMsg });
			throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
		 }
		}
		isUpdateCall=true;
		QuotePolicyAttachmentRequest attachmentFile=null;
		try{
		 ObjectMapper mapper=new ObjectMapper();
		 String inputJson=APIOperationUtil.fetchRequestBody(request);
		 attachmentFile=mapper.readValue(inputJson, QuotePolicyAttachmentRequest.class);
		 updateCallAttachmentFile=attachmentFile;
		}catch(Exception exp){
		 String errMsg = "Invalid JSON. Please provide a valid single file object for updation.";
		 List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
		 String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
		 throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,exp);
		}
		//Auditing logic
		APIAuditTrailLog auditTrailLog=requestContext.getAuditTrailLog();
		APIOperationUtil.populateAPIAuditLog(auditTrailLog, attachmentFile.getSourceSystemCode(), attachmentFile.getSourceSystemUserId(), attachmentFile.getSourceSystemRequestNo(), RESOURCE_TYPE, PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
		//Adding specifics
		deleteQuotePolicyAttachmentFile(fieldId);
		APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, entityReference, fieldId, "Deleted File");
		
		Object filteredAttachmentList=addQuotePolicyAttachmentFile();
		APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, entityReference, attachmentFile.getFilename(), "Added File");
		
		ConfirmationMessage confirmationMessage=new ConfirmationMessage();
		confirmationMessage.setCode("200");
		confirmationMessage.setDescription(fieldId+" is replaced with file "+attachmentFile.getFilename());
		
		return confirmationMessage;
	}
	
	public List<QuotePolicyAttachmentRequest> convertQuotePolicyAttachmentRequestVerionedToWithoutVersion(QuotePolicyAttachmentRequestListVersion2 requestListVersion2){
		List<QuotePolicyAttachmentRequest> attachmentRequestList=new ArrayList<QuotePolicyAttachmentRequest>();
		for(QuotePolicyAttachmentRequestVersion2 requestVersion2:requestListVersion2.getAttachments()){
			QuotePolicyAttachmentRequest attachmentRequest=new QuotePolicyAttachmentRequest();
			attachmentRequest.setFile(requestVersion2.getFile());
			attachmentRequest.setFileCategory(requestVersion2.getFileCategory());
			attachmentRequest.setFileDescription(requestVersion2.getFileDescription());
			attachmentRequest.setFilename(requestVersion2.getFilename());
			attachmentRequestList.add(attachmentRequest);
		}
		return attachmentRequestList;
	}
}
