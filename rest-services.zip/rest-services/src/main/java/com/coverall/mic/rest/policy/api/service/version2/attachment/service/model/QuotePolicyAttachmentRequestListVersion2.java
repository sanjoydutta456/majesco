package com.coverall.mic.rest.policy.api.service.version2.attachment.service.model;

import java.util.List;

public class QuotePolicyAttachmentRequestListVersion2 {
	
	String sourceSystemUserId;	
	String sourceSystemCode;	
	long sourceSystemRequestNo;
	List<QuotePolicyAttachmentRequestVersion2> attachments;
	
	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}

	public void setSourceSystemUserId(String sourceSystemUserId) {
		this.sourceSystemUserId = sourceSystemUserId;
	}

	public String getSourceSystemCode() {
		return sourceSystemCode;
	}

	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}

	public long getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}

	public void setSourceSystemRequestNo(long sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}

	public List<QuotePolicyAttachmentRequestVersion2> getAttachments() {
		return attachments;
	}

	public void setAttachments(
			List<QuotePolicyAttachmentRequestVersion2> attachments) {
		this.attachments = attachments;
	}
}
