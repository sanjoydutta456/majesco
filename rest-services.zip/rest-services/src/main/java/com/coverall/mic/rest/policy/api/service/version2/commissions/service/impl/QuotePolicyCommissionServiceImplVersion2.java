package com.coverall.mic.rest.policy.api.service.version2.commissions.service.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.map.ObjectMapper;

import com.coverall.mt.util.APIAuditTrailLog;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.factory.impl.PolicyAPIFactoryServiceImpl;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.impl.QuotePolicyCommissionServiceImpl;
import com.coverall.mic.rest.policy.api.service.model.ConfirmationMessage;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyCommission;
import com.coverall.mic.rest.policy.api.service.model.QuotePolicyCommissionOverride;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mic.rest.policy.api.service.util.WorkflowUtil;
import com.coverall.mic.rest.policy.api.service.version2.commissions.service.model.QuotePolicyCommissionOverrideListVersion2;
import com.coverall.mic.rest.policy.api.service.version2.commissions.service.model.QuotePolicyCommissionOverrideVersion2;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.util.DBUtil;

public class QuotePolicyCommissionServiceImplVersion2 extends
		QuotePolicyCommissionServiceImpl {

	public QuotePolicyCommissionServiceImplVersion2(String entityReference,
			String entityType, HttpServletRequest request) {
		super(entityReference, entityType, request);
	}
	
	@Override
	public Object modifyCommissions() throws Exception {
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		ConfirmationMessage overrideResponse=new ConfirmationMessage();
		//Fetching JSON request as a MAP
		ObjectMapper mapper = null;
		String inputJson = null;
		QuotePolicyCommissionOverrideListVersion2 commissionsOverrideListVersion2=null;
		List<QuotePolicyCommissionOverride> listOfCommissionOverrides=null;
		Connection conn = requestContext.getConnection();
		CallableStatement callStmt=null;
		isCommissionOverride=true;

		try{
			mapper=new ObjectMapper();
			inputJson=IOUtils.toString(request.getInputStream(), "UTF-8");
			commissionsOverrideListVersion2=mapper.readValue(inputJson, QuotePolicyCommissionOverrideListVersion2.class);
			listOfCommissionOverrides=convertCommissionVerionListToWithoutVersion(commissionsOverrideListVersion2);
		}catch(Exception exp){
			String errMsg = "Invalid JSON. Please reverify the object structure.";
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,exp);
		}
		
		
		//Auditing logic
		APIAuditTrailLog auditTrailLog=requestContext.getAuditTrailLog();
		APIOperationUtil.populateAPIAuditLog(auditTrailLog, commissionsOverrideListVersion2.getSourceSystemCode(), commissionsOverrideListVersion2.getSourceSystemUserId(), commissionsOverrideListVersion2.getSourceSystemRequestNo(), RESOURCE_TYPE, PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
		
		List<QuotePolicyCommission> listOfExistingCommissionsForEntity=getListOfCommissionsForQuotePolicy(conn,requestContext.getUserName(),System.currentTimeMillis(),entityReference);
		
		for(QuotePolicyCommissionOverride overriddenCommission:listOfCommissionOverrides){
			boolean foundCommission=false;
			for(QuotePolicyCommission commissionInSystem:listOfExistingCommissionsForEntity){
				if(overriddenCommission.getCommissionId()==commissionInSystem.getCommissionId()){
					foundCommission=true;
					if(overriddenCommission.getOverrideCommission()<0){
						String errMsg = "Value of the overrideCommission cannot be less than 0.";
						List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
						String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
						throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
					}
				}
			}
			if(!foundCommission){
				String errMsg = "No commission with ID:"+overriddenCommission.getCommissionId()+" is found for "+entityType+":"+entityReference;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
		}

		try{

			if(!WorkflowUtil.checkIfUserHasTheRequiredPermission(requestContext.getUser(), APIConstant.OVERRIDE_COMMISSION_PERMISSION)) {
				String errMsg = user.getUserId()+" doesn't have permission to override commissions.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}

			if(!WorkflowUtil.checkIfUWRuleAndCommissionManagementWorkflowIsApplicable(user, conn,entityReference, entityType)){
				String errMsg = "Commission can not be for overridden for "+entityReference;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}

			ArrayList<String> commissionsNotOverridden=new ArrayList<String>();
			ArrayList<String> commissionsOverridden=new ArrayList<String>();

			for(QuotePolicyCommissionOverride overriddenCommission:listOfCommissionOverrides){
				try{
					callStmt = conn.prepareCall("{? = call K_COMMISSION_MANAGEMENT.f_override_commission(?, ?, ?, ?, ?)}");
					callStmt.registerOutParameter(1, Types.INTEGER);
					callStmt.setString(2, overriddenCommission.getCommissionId()+"");
					callStmt.setString(3, overriddenCommission.getOverrideCommission()+"");
					callStmt.setString(4, user.getFullDisplayName());
					callStmt.setString(5, "Y");
					callStmt.registerOutParameter(6, Types.VARCHAR);
					callStmt.execute();

					if (callStmt.getLong(1) != 0) {
						commissionsNotOverridden.add(overriddenCommission.getCommissionId()+"[Reason:"+callStmt.getString(6)+"]");
						APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, entityReference, overriddenCommission.getCommissionId()+"", "Commission Override Failed:"+"[Reason:"+callStmt.getString(6)+"]");
					}else{
						commissionsOverridden.add(overriddenCommission.getCommissionId()+"");
						APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, entityReference, overriddenCommission.getCommissionId()+"", "Overriden with value: "+overriddenCommission.getOverrideCommission());
					}
				}catch(Exception exp){
					commissionsNotOverridden.add(overriddenCommission.getCommissionId()+"");
				}finally{
					conn.commit();
					DBUtil.close(null, callStmt, null);	
				}
			}

			if(commissionsOverridden!=null && commissionsOverridden.size()>0){
				overrideResponse.setCode("SUCCESS");
				String descriptionString="Commissions sucessfully overriden: "+StringUtils.join(commissionsOverridden, ',');
				if(commissionsNotOverridden!=null && commissionsNotOverridden.size()>0){
					overrideResponse.setCode("PARTIAL SUCCESS");
					descriptionString+="There is some error while overridding commissions:"+StringUtils.join(commissionsNotOverridden, ',');
				}
				overrideResponse.setDescription(descriptionString);
				auditTrailLog.setStatusCode(200);
				//auditTrailLog.setStatusMessage((new ObjectMapper()).writeValueAsString(overrideResponse));
			}else{
				String errMsg = "Error overriding commissions: ";
				if(commissionsNotOverridden!=null && commissionsNotOverridden.size()>0){
					errMsg+=StringUtils.join(commissionsNotOverridden, ',');
				}
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
			
			processCommissionCalculation();
		} catch (APIException e) {
			WebServiceLoggerUtil.logError("QuotePolicyCommissioServiceImpl", "modifyCommissions", e.getLocalizedMessage(), new Object[] { e.getMessage() }, e);
			throw e;
		} catch (Exception exc) {
			WebServiceLoggerUtil.logError("QuotePolicyCommissioServiceImpl", "processCommissionCalculation", "Exception occurred while overridding commission", new Object[] { "K_COMMISSION_MANAGEMENT.f_override_commission" }, exc);
			String errMsg = null;
			List <Message> errorMessageList = null;
			String httpStatusCode = null;
			if(exc instanceof APIException){
				errMsg = ((APIException) exc).getErrorMessage();
				errorMessageList = ((APIException) exc).getErrorMessageList();
				httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			}else{
				errMsg = "Error overriding commission " + exc.getLocalizedMessage();
				errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			}
			
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);

		}

		return overrideResponse;
	}
	
	public List<QuotePolicyCommissionOverride> convertCommissionVerionListToWithoutVersion(QuotePolicyCommissionOverrideListVersion2 commissionOverrideListVersion2){
		
		List<QuotePolicyCommissionOverride> commissionOverrides=new ArrayList<QuotePolicyCommissionOverride>();
		for(QuotePolicyCommissionOverrideVersion2 commissionOverrideVersion2:commissionOverrideListVersion2.getCommissions()){
			 QuotePolicyCommissionOverride override=new QuotePolicyCommissionOverride();
			 override.setCommissionId(commissionOverrideVersion2.getCommissionId());
			 override.setOverrideCommission(commissionOverrideVersion2.getOverrideCommission());
			 commissionOverrides.add(override);
		 }
		return commissionOverrides;
	}

}
