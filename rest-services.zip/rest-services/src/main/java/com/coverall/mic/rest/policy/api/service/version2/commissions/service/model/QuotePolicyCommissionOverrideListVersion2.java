package com.coverall.mic.rest.policy.api.service.version2.commissions.service.model;

import java.util.List;

public class QuotePolicyCommissionOverrideListVersion2 {
	
	String sourceSystemUserId;
	String sourceSystemCode;
	long sourceSystemRequestNo;
	
	List<QuotePolicyCommissionOverrideVersion2> commissions;

	public List<QuotePolicyCommissionOverrideVersion2> getCommissions() {
		return commissions;
	}

	public void setCommissions(
			List<QuotePolicyCommissionOverrideVersion2> overrideCommissions) {
		this.commissions = overrideCommissions;
	}

	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}

	public void setSourceSystemUserId(String sourceSystemUserId) {
		this.sourceSystemUserId = sourceSystemUserId;
	}

	public String getSourceSystemCode() {
		return sourceSystemCode;
	}

	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}

	public long getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}

	public void setSourceSystemRequestNo(long sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}
	
	
}
