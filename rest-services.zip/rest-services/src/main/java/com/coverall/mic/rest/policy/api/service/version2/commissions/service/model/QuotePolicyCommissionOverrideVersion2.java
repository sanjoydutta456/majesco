package com.coverall.mic.rest.policy.api.service.version2.commissions.service.model;

public class QuotePolicyCommissionOverrideVersion2 {

	int commissionId;
	double overrideCommission;

	public int getCommissionId() {
		return commissionId;
	}
	public void setCommissionId(int commissionId) {
		this.commissionId = commissionId;
	}
	public double getOverrideCommission() {
		return overrideCommission;
	}
	public void setOverrideCommission(double overrideCommission) {
		this.overrideCommission = overrideCommission;
	}

}
