package com.coverall.mic.rest.policy.api.service.version2.forms.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import org.apache.commons.lang.StringUtils;
import org.apache.cxf.helpers.IOUtils;
import org.codehaus.jackson.map.ObjectMapper;

import com.coverall.mt.util.APIAuditTrailLog;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.factory.impl.PolicyAPIFactoryServiceImpl;
import com.coverall.mic.rest.policy.api.forms.model.Form;
import com.coverall.mic.rest.policy.api.forms.model.FormDeleteObj;
import com.coverall.mic.rest.policy.api.forms.model.FormVariable;
import com.coverall.mic.rest.policy.api.forms.model.FormVariables;
import com.coverall.mic.rest.policy.api.forms.model.Forms;
import com.coverall.mic.rest.policy.api.forms.service.impl.FormsServiceImpl;
import com.coverall.mic.rest.policy.api.service.APIRequestContext;
import com.coverall.mic.rest.policy.api.service.IAPIContext;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.forms.dao.FormVariableVo;
import com.coverall.mic.rest.policy.api.service.forms.util.FormUtil;
import com.coverall.mic.rest.policy.api.service.model.ConfirmationMessage;
import com.coverall.mic.rest.policy.api.service.model.SourceSystemInformationBean;
import com.coverall.mic.rest.policy.api.service.model.common.Items;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.api.service.util.APIOperationUtil;
import com.coverall.mic.rest.policy.api.service.util.WorkflowUtil;
import com.coverall.mic.rest.policy.api.service.version2.forms.service.model.FormVariableVersion2;
import com.coverall.mic.rest.policy.api.service.version2.forms.service.model.FormVariablesVersion2;
import com.coverall.mic.rest.policy.api.service.version2.forms.service.model.FormVersion2;
import com.coverall.mic.rest.policy.api.service.version2.forms.service.model.FormsVersion2;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.portal.dao.FormsAssociationDAO;
import com.coverall.portal.services.FormsWorkFlowService;
import com.coverall.security.authentication.User;
import com.coverall.util.DBUtil;

public class FormsServiceImplVersion2 extends FormsServiceImpl {
	
	public boolean isAddFormCall=false;
	
	public FormsServiceImplVersion2(String entityReference, String entityType, HttpServletRequest request) {
		super(entityReference,entityType,request);
	}
	
	@Override
	public Object updateFormVariables(String formId, HttpServletRequest request) {
		
		String occurance="0";
		long activityID = 0;
		boolean isBinder = false;

		boolean shouldExecute = false;
		Message message = new Message();
		ConfirmationMessage confirmMessage=new ConfirmationMessage();

		try {
			
			if(!FormUtil.validatFormIdFormat(formId)){
				String errMsg = formId+APIConstant.INVALID_FORM_ID_FORMAT;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "updateFormVariables", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}
			
			IAPIContext requestContext = APIRequestContext.getApiRequestContext();
			
			ObjectMapper mapper=new ObjectMapper();
			String inputJson=APIOperationUtil.fetchRequestBody(request);
			FormVariablesVersion2 formVariablesVersion2=mapper.readValue(inputJson, FormVariablesVersion2.class);
			
			//Auditing logic
			APIAuditTrailLog auditTrailLog=null;
			if(!isAddFormCall){
				auditTrailLog=requestContext.getAuditTrailLog();
			 APIOperationUtil.populateAPIAuditLog(auditTrailLog, formVariablesVersion2.getSourceSystemCode(), formVariablesVersion2.getSourceSystemUserId(), formVariablesVersion2.getSourceSystemRequestNo(), RESOURCE_TYPE, PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
			}
			
			
			FormVariables formVariables=convertVersionedFormVariableListToWithoutVersion(formVariablesVersion2);

			Connection conn = requestContext.getConnection();
			
			if(!WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)) {
				errorMessageList = new ArrayList<Message>();
				message.setMoreinfo(APIConstant.INVALID_REQUEST);
				errorMessageList.add(message);

				throw new APIException(APIConstant.POLICY_NOT_EXISTS_CODE,APIConstant.FAILED,errorMessageList,null);
			}
			
			String entityType = APIConstant.ENTITY_QUOTE;

			boolean isPolicyEntity = WorkflowUtil.getEntityType(conn, entityReference);
			isBinder = WorkflowUtil.checkIfBinder(conn, entityReference);

			if (isPolicyEntity) {
				entityType = APIConstant.ENTITY_POLICY;
			}
			
			occurance=formId.substring(formId.length()-3);
			formId=formId.substring(0, formId.length()-3);
			

			if (!WorkflowUtil.checkIfFormPresent(conn, entityReference,formId,occurance)) {
				errorMessageList = new ArrayList<Message>();
				message.setMoreinfo(APIConstant.WORKFLOW_NOT_EXISTS);
				errorMessageList.add(message);

				throw new APIException(APIConstant.WORKFLOW_NOT_EXISTS_CODE, APIConstant.FAILED, errorMessageList,
						new Throwable());
			}

			if (!WorkflowUtil.isWorkflowStageReached(conn, entityType, APIConstant.FORMSMANAGEMENT_TASK,
					entityReference)) {
				errorMessageList = new ArrayList<Message>();
				message.setMoreinfo(APIConstant.WORKFLOW_NOT_EXISTS);
				errorMessageList.add(message);

				throw new APIException(APIConstant.WORKFLOW_NOT_EXISTS_CODE, APIConstant.FAILED, errorMessageList,
						new Throwable());
			}

			if (isPolicyEntity) {
				if (WorkflowUtil.checkIfPolicyBooked(conn, entityReference)) {
					errorMessageList = new ArrayList<Message>();
					message.setMoreinfo(APIConstant.POLICY_BOOKED);
					errorMessageList.add(message);

					throw new APIException(APIConstant.POLICY_BOOKED_CODE, APIConstant.FAILED, errorMessageList,
							null);
				}
			} else {
				if (APIConstant.CONVERTED_TO_POLICY
						.equalsIgnoreCase(WorkflowUtil.getCurrentPolicyStatus(entityReference, entityType, conn))) {
					errorMessageList = new ArrayList<Message>();
					message.setMoreinfo(APIConstant.QUOTE_HAVING_NEW_REVISION);
					errorMessageList.add(message);

					throw new APIException(APIConstant.INVALID_REQUEST_CODE, APIConstant.FAILED,
							errorMessageList, null);
				}

			}

			if (null != formVariables && formVariables.getFormVariables().size() == 0) {
				errorMessageList = new ArrayList<Message>();
				message.setMoreinfo(APIConstant.FORM_VAR_NOT_EXISTS);
				errorMessageList.add(message);

				throw new APIException(APIConstant.FORM_VAR_NOT_EXISTS_CODE, APIConstant.FAILED, errorMessageList,
						new Throwable());
			} 
			
			if (!WorkflowUtil.hasFormModifyPermission(requestContext.getUser().getDomain(),
					requestContext.getUser().getUserId().substring(0,requestContext.getUser().getUserId().indexOf("@") ))) {
				errorMessageList = new ArrayList<Message>();
				message.setMoreinfo(APIConstant.USER_PERMISSION_NOT_EXISTS);
				errorMessageList.add(message);

				throw new APIException(APIConstant.USER_PERMISSION_NOT_EXISTS_CODE, APIConstant.FAILED,
						errorMessageList, null);

			}
			
			List <FormVariableVo> formVariableVO=new ArrayList<FormVariableVo>();
			//Validating if the variables and creating list of varialble VO
			for (int i = 0; i < formVariables.getFormVariables().size(); i++) {
				
				String formVariableOccurance=occurance;
				String providedVariableOccurnace=formVariables.getFormVariables().get(i).getVariableOccurrence();
				if(providedVariableOccurnace!=null && providedVariableOccurnace.trim().length() != 0){
					formVariableOccurance=providedVariableOccurnace;
				}
				
				if (!WorkflowUtil.checkIfFormVariableIsAvailable(conn, entityReference, Integer.parseInt(formId),
						formVariables.getFormVariables().get(i).getVariableName(),formVariableOccurance)) {
					errorMessageList = new ArrayList<Message>();
					message.setMoreinfo(APIConstant.FORM_VAR_DATA_INVALID);
					errorMessageList.add(message);

					throw new APIException(APIConstant.FORM_VAR_DATA_INVALID_CODE, APIConstant.FAILED, errorMessageList,
							null);
				}
				
				FormVariableVo variableVo = FormUtil.getFormVaraibleDetailData(conn, entityReference,
						Integer.parseInt(formId), formVariables.getFormVariables().get(i),
						entityType, isBinder, formVariableOccurance);
				
				// Validating Form Variables
				FormUtil.validateFormVariables(variableVo,
						formVariables.getFormVariables().get(i).getVariableValue());
				
				formVariableVO.add(variableVo);
			}

			for (int i = 0; i < formVariableVO.size(); i++) {
				
				FormVariableVo variableVo =formVariableVO.get(i);
				if(!isAddFormCall && auditTrailLog!=null){
				//Adding specifics
				APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, entityReference, formId, "Variable:"+variableVo.getFormVarName()+" value changed from ["+variableVo.getFormVarValue()+"] to ["+variableVo.getFormVarModifiedValue()+"]");
				}
					// Check the stage
					// Block the Stage

					activityID = WorkflowUtil.getActivityID(conn, entityType, entityReference,
							APIConstant.FORMSMANAGEMENT_TASK);

					// WorkflowUtil.getStageDesc(conn, policyReference, activityID);
					Map<String, String> status = WorkflowUtil.getCurrentWorkflowStatus(conn, entityType,
							entityReference, APIConstant.FORMSMANAGEMENT_TASK);

					if (null != status && !status.isEmpty()
							&& !status.get(APIConstant.TASK_STATUS).trim().toUpperCase().equalsIgnoreCase("BLOCK")) {
						WorkflowUtil.setBlocked(conn, activityID, status.get(APIConstant.TASK_STATUS));
						shouldExecute = true;
					} else {
						shouldExecute = true;

					}

					if (shouldExecute) {
						if (variableVo.getFormVarType().equalsIgnoreCase("RICHTEXT")) {
							FormUtil.updateFormRichTextVariable(conn, entityReference, variableVo,
									Integer.parseInt(formId),
									formVariableVO.get(i).getFormVarModifiedValue());
						} else {
							FormUtil.updateFormVariable(conn, entityReference, variableVo, Integer.parseInt(formId),
									formVariableVO.get(i).getFormVarModifiedValue());
						}

					}
				}

			if (FormUtil.isAnyVariableIncomplete(entityReference, entityType, conn)) {
				
				confirmMessage.setCode("200");
				confirmMessage.setDescription(APIConstant.PARTIALLY_SUCCESSFUL+":"+APIConstant.MANDATORY_VARIABLE_EXISTS);
//			    errorMessageList = new ArrayList<Message>();
//			    message.setMoreinfo(APIConstant.MANDATORY_VARIABLE_EXISTS);
//				errorMessageList.add(message);
//
//				throw new APIException(APIConstant.MANDATORY_VARIABLE_EXISTS_CODE, APIConstant.PARTIALLY_SUCCESSFUL,
//						errorMessageList, new Throwable());
			    

			} else {
			    
				WorkflowUtil.setComplete(activityID, conn, requestContext.getUser().getUserId());
//                Items item = new Items();
//                item.setSystemerrcode("Successful");
//                message.setItem(item);
//				message.setMoreinfo("Successfully updated the form variables and triggered the next workflow. ");
				confirmMessage.setCode("200");
				confirmMessage.setDescription("Successfully updated the form variables and triggered the next workflow.");
				

			}

		} catch (APIException e) {
			throw e;
		}catch (java.lang.Exception e) {
			errorMessageList = new ArrayList<Message>();
			message.setMoreinfo(e.getMessage());
			errorMessageList.add(message);

			throw new APIException(APIConstant.RUNTIME_EXCEPTION, APIConstant.FAILED, errorMessageList,
					e);

		} 
//		finally {
//
//			APIRequestContext.getApiRequestContext().releaseContext();
//		}

		return confirmMessage;

	}

	@Override
	public Object addFormToQuotePolicy() {
		ConfirmationMessage response=null;
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		User user=requestContext.getUser();
		long sourceSystemRequestNo=System.currentTimeMillis();
		isAddFormCall=true;
		try {
			Connection conn = requestContext.getConnection();

			if(!WorkflowUtil.checkIfUserHasTheRequiredPermission(user, APIConstant.FORM_MODIFY_PERMISSION)) {
				String errMsg = user.getUserId()+" doesn't have permission to delete the forms.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "addFormToQuotePolicy", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}

			if(!WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)) {
				String errMsg = entityReference+" doesn't exists please check input parameter.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "addFormToQuotePolicy", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}

			if (!WorkflowUtil.isWorkflowStageReached(conn, entityType, APIConstant.FORMSMANAGEMENT_TASK,
					entityReference)) {
				String errMsg = "Form Management stage is not yet reached for the "+entityReference+". Please check status of "+entityType;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "addFormToQuotePolicy", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}

			if (!WorkflowUtil.checkIfFormCanBeModifiedForTheEntity(user.getName(),conn, entityType, entityReference)) {
				String errMsg = "Forms under "+entityReference+" cannot be modified/deleted. Please check the status of the "+entityType;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "addFormToQuotePolicy", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}
			
			ObjectMapper mapper=new ObjectMapper();
			String inputJson=APIOperationUtil.fetchRequestBody(request);
			FormsVersion2 formsToBeAddedVersion2=mapper.readValue(inputJson, FormsVersion2.class);
			
			Forms formsToBeAdded=convertVersionedFormListToWithoutVersion(formsToBeAddedVersion2);
			
			//Auditing logic
			APIAuditTrailLog auditTrailLog=requestContext.getAuditTrailLog();
			APIOperationUtil.populateAPIAuditLog(auditTrailLog, formsToBeAddedVersion2.getSourceSystemCode(), formsToBeAddedVersion2.getSourceSystemUserId(), formsToBeAddedVersion2.getSourceSystemRequestNo(), RESOURCE_TYPE, PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
			
			List<Form> listOfFormsToBeAdded=new ArrayList<Form>();
			List<Form> listOfManuscriptsToBeAdded=new ArrayList<Form>();
			validateAndListFormsToBeAddedToQuotePolicy(user,conn,formsToBeAdded,sourceSystemRequestNo,listOfFormsToBeAdded,listOfManuscriptsToBeAdded);
			
			
			Map<String,Form> formMapWithIssues=new HashMap<String, Form>();
			Map<String,Form> formMapAddedSuccessfully=new HashMap<String, Form>();
			
			for(Form manuscriptForms:listOfManuscriptsToBeAdded){
				try{
					FormUtil.addFormToQuotePolicy(user, conn, entityType, entityReference, manuscriptForms, "Y");
					formMapAddedSuccessfully.put(manuscriptForms.getFormId()+"",manuscriptForms);
				}catch(APIException exp){
					formMapWithIssues.put(manuscriptForms.getFormId()+"",manuscriptForms);
				}
			}
			
			for(Form formToBeAdded:listOfFormsToBeAdded){
				try{
					FormUtil.addFormToQuotePolicy(user, conn, entityType, entityReference, formToBeAdded, "N");
					formMapAddedSuccessfully.put(formToBeAdded.getFormId()+"",formToBeAdded);
				}catch(APIException exp){
					formMapWithIssues.put(formToBeAdded.getFormId()+"",formToBeAdded);
					APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, entityReference, formToBeAdded.getFormId()+"", "Form failed while adding.");
				}
			}
			
			try{
			  Map emptyParamMap=new HashMap();
			  FormsWorkFlowService.updateFormExpressionVariables(conn,
					  entityReference,
					  com.coverall.mt.http.User.getUser(request),
					  emptyParamMap);
			}catch (Exception exc){
			    conn.rollback();
			  	String errMsg = "Error resolving form variable expressions:"+exc.getMessage()+". Changes will be rolledback.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "addFormToQuotePolicy", errMsg, new Object[] { exc.getStackTrace() });
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
		  
		  conn.commit();
		  FormUtil.reRankFormsForQuotePolicy(conn, entityReference);
		  boolean isBinder = WorkflowUtil.checkIfBinder(conn, entityReference);
		  
		  //boolean exceptionOccuredWhileAddingVariables=false;
		  response=new ConfirmationMessage();
		
		  
		  //Merging 2 lists
		  List<Form> combinedList=new ArrayList<Form>();
		  combinedList.addAll(listOfManuscriptsToBeAdded);
		  combinedList.addAll(listOfFormsToBeAdded);
		  List<String> varsWithIssues=new ArrayList<String>();
		  Map<String,Form> formMapFaliedWhileAddingVariable=new HashMap<String, Form>();

		  for(Form formInFocus:combinedList){
			  if(!formMapWithIssues.containsKey(formInFocus.getFormId()+"")){	  
				  FormVariables variableList=formInFocus.getFormVariables();
				  if(variableList != null && variableList.getFormVariables() != null) {
					  for(int i=0;i<variableList.getFormVariables().size();i++){
						  if(formInFocus.getFormVariables().getFormVariables().get(i).getVariableValue()!=null){
							  try{

								  String formId = formInFocus.getFormId()+"";
								  String occurance=formId.substring(formId.length()-3);
								  formId=formId.substring(0, formId.length()-3);


								  FormVariableVo variableVo = FormUtil.getFormVaraibleDetailData(conn, entityReference,
										  Integer.parseInt(formId), variableList.getFormVariables().get(i),
										  entityType, isBinder, occurance);
								  // Validating Form Variables
								  FormUtil.validateFormVariables(variableVo,
										  variableList.getFormVariables().get(i).getVariableValue());

								  if ("RICHTEXT".equalsIgnoreCase(variableVo.getFormVarType())) {
									  FormUtil.updateFormRichTextVariable(conn, entityReference, variableVo,
											  formInFocus.getFormId(),
											  variableList.getFormVariables().get(i).getVariableValue());

								  } else {
									  FormUtil.updateFormVariable(conn, entityReference, variableVo, formInFocus.getFormId(),
											  variableList.getFormVariables().get(i).getVariableValue());
								  }
								  formMapAddedSuccessfully.put(formInFocus.getFormId()+"",formInFocus);
							  }catch(Exception exp){
								  formMapFaliedWhileAddingVariable.put(formInFocus.getFormId()+"", formInFocus);
								  varsWithIssues.add(formInFocus.getFormVariables().getFormVariables().get(i).getVariableName()+" under "+formInFocus.getFormName());
								  formMapAddedSuccessfully.remove(formInFocus.getFormId()+"");
								  APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, entityReference, formInFocus.getFormId()+"", "Form failed while setting variable");
								  break;
								  //exceptionOccuredWhileAddingVariables=true;
							  }
						  }
					  }
				  }
			  }
		  }
		  
		  if (FormUtil.isAnyVariableIncomplete(entityReference, entityType, conn)) {
			  WorkflowUtil.setBlocked(conn, WorkflowUtil.getActivityID(conn, entityType, entityReference, APIConstant.FORMSMANAGEMENT_TASK), "Forms Management - User input required");
		  }
		  
		  for(Form addedForm:formMapAddedSuccessfully.values()){
			  APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, entityReference, addedForm.getFormId()+"", "Form added successfully");
		  }

		  if(formMapFaliedWhileAddingVariable.size()>0){
			  Object[] formIdsToBedeleted= formMapFaliedWhileAddingVariable.keySet().toArray();
			  String[] finalListToBeDeleted = new String[formIdsToBedeleted.length];
			  System.arraycopy(formIdsToBedeleted, 0, finalListToBeDeleted, 0, formIdsToBedeleted.length);
			  deleteFormFromQuotePolicy(finalListToBeDeleted);
		  }

		  String responseMessage="";
		  String code="200";
		  if(formMapAddedSuccessfully.size()>0){
			  responseMessage="Forms "+StringUtils.join(formMapAddedSuccessfully.keySet(), ',')+" added successfully.";
		  }

		  if(formMapWithIssues.size()>0){
			  responseMessage+=" There is an issue while adding "+StringUtils.join(formMapWithIssues.keySet(), ',')+" forms initially.";
		  }

		  if(formMapFaliedWhileAddingVariable.size()>0){
			  responseMessage+=" Forms failed while adding variables, listed are variables and corresponding forms :"+StringUtils.join(varsWithIssues, ','); 
		  }

		  if(formMapAddedSuccessfully.size()>0 && (formMapFaliedWhileAddingVariable.size()>0 || formMapWithIssues.size()>0)){
			  code+="- Partially Successful";
		  }else if(formMapAddedSuccessfully.size()==0){
			  code+="- No Form Added";
		  }

		  response.setCode(code);
		  response.setDescription(responseMessage);


		} catch (APIException e) {
			throw new APIException(e.getErrorCode(),e.getErrorMessage(),e.getErrorMessageList(),new Throwable());
		}catch (Exception e) {
			errorMessageList = new ArrayList<Message>();
			message.setMoreinfo(e.getLocalizedMessage());
			errorMessageList.add(message);
			throw new APIException(APIConstant.RUNTIME_EXCEPTION,APIConstant.FAILED,errorMessageList,new Throwable());	
		} 
//		finally {
//			APIRequestContext.getApiRequestContext().releaseContext();			
//		}
		return response;
	}
	
	@Override
	public Object deleteFormFromQuotePolicy(String[] formIds) throws Exception{
		ConfirmationMessage response=null;
		IAPIContext requestContext = APIRequestContext.getApiRequestContext();
		User user=requestContext.getUser();
		PreparedStatement pStmt=null;
		ResultSet rs=null;
		
		try {

			for(String formId:formIds){
				if(!FormUtil.validatFormIdFormat(formId)){
					String errMsg = formId+APIConstant.INVALID_FORM_ID_FORMAT;
					List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
					String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
					WebServiceLoggerUtil.logInfo("FormServiceImpl", "deleteFormFromQuotePolicy", errMsg, new Object[] { errMsg });
					throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
				}
			}

			Connection conn = requestContext.getConnection();

			if(!WorkflowUtil.checkIfUserHasTheRequiredPermission(user, APIConstant.FORM_DELETE_PERMISSION)) {
				String errMsg = user.getUserId()+" doesn't have permission to delete the forms.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "deleteFormFromQuotePolicy", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}

			if(!WorkflowUtil.checkIfPolicyExists(conn, entityReference, entityType)) {
				String errMsg = entityReference+" doesn't exists please check input parameter.";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "deleteFormFromQuotePolicy", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}

			if (!WorkflowUtil.isWorkflowStageReached(conn, entityType, APIConstant.FORMSMANAGEMENT_TASK,
					entityReference)) {
				String errMsg = "Form Management stage is not yet reached for the "+entityReference+". Please check status of "+entityType;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "deleteFormFromQuotePolicy", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}

			if (!WorkflowUtil.checkIfFormCanBeModifiedForTheEntity(user.getName(),conn, entityType, entityReference)) {
				String errMsg = "Forms under "+entityReference+" cannot be modified/deleted. Please check the status of the "+entityType;
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "deleteFormFromQuotePolicy", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}
			
			
			String sourceSystemCode=null;
			String sourceSystemUserId=null;
			long sourceSystemRequestNo=0;
			try{
				ObjectMapper mapper=new ObjectMapper();
				String inputJson=APIOperationUtil.fetchRequestBody(request);
				SourceSystemInformationBean sourceSystem=mapper.readValue(inputJson, SourceSystemInformationBean.class);
				sourceSystemCode=sourceSystem.getSourceSystemCode();
				sourceSystemUserId=sourceSystem.getSourceSystemUserId();
				sourceSystemRequestNo=sourceSystem.getSourceSystemRequestNo();
			}catch(Exception exp){
				//do nothing as this is not a mandatory part of request but needed for audit logging
			}		
			//Auditing logic
			APIAuditTrailLog auditTrailLog=null;
			if(!isAddFormCall){
			 auditTrailLog=requestContext.getAuditTrailLog();
			 APIOperationUtil.populateAPIAuditLog(auditTrailLog, sourceSystemCode, sourceSystemUserId, sourceSystemRequestNo, RESOURCE_TYPE, PolicyAPIFactoryServiceImpl.getVersionFromRequest(request));
			}
			
			String formIdListCommaSeparated=StringUtils.join(formIds, ','); 
			queryForGettingFormSpecifics+=formIdListCommaSeparated+")";
			//Array array = conn.createArrayOf("VARCHAR", new Object[]{"1", "2","3"});
			pStmt=conn.prepareStatement(queryForGettingFormSpecifics);
			pStmt.setString(1, entityReference);

			rs=pStmt.executeQuery();
			List<String> listofFormIds=new ArrayList<String>();
			List<FormDeleteObj> fileDeleteObjList=new ArrayList<FormDeleteObj>();

			while(rs.next()){
				FormDeleteObj formObj=new FormDeleteObj();
				listofFormIds.add(rs.getString("pdt_id"));
				formObj.setFormId(rs.getString("pdt_id"));
				formObj.setFormName(rs.getString("MFO_FORM_NUMBER"));
				formObj.setEntityReference(entityReference);
				formObj.setFormOccurance(rs.getString("MFO_OCCURRENCE"));
				formObj.setFormCoveragePartReference(rs.getString("MFO_COVERAGE_PART_REFERENCE"));
				formObj.setFormModifiedReference(entityReference);
				formObj.setFormModifiedCoverage(rs.getString("MFO_COVERAGE_PART_REFERENCE"));

				fileDeleteObjList.add(formObj);
			}

			String invalidFormId=null;
			for(String formId:formIds){
				String occurance=formId.substring(formId.length()-3);
				formId=formId!=null?formId.substring(0,formId.length()-3):null;
				if(!listofFormIds.contains(formId)){
					invalidFormId=formId+occurance;
					break;
				}
			}
			if(null!=invalidFormId){
				String errMsg = invalidFormId+APIConstant.FORM_ID_NOT_EXISTS+entityReference+".";
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.NOT_FOUND.getStatusCode());
				WebServiceLoggerUtil.logInfo("FormServiceImpl", "deleteFormFromQuotePolicy", errMsg, new Object[] { errMsg });
				throw new APIException(httpStatusCode, APIConstant.INVALID_REQUEST,errorMessageList,null);
			}
			for(FormDeleteObj formObject:fileDeleteObjList){

				FormsAssociationDAO formAssociationDao=new FormsAssociationDAO();
				HashMap<String, String> userData=new HashMap<String, String>();
				userData.put("MFO_POLICY_REFERENCE", entityReference);
				userData.put("MFO_COVERAGE_PART_REFERENCE", formObject.getFormCoveragePartReference());
				userData.put("MFO_FORM_NUMBER", formObject.getFormName());
				userData.put("MFO_OCCURRENCE", formObject.getFormOccurance());
				userData.put("MFO_REFERENCE_MODIFIED", formObject.getFormModifiedReference());
				userData.put("MFO_COVERAGE_MODIFIED", formObject.getFormModifiedCoverage());

				formAssociationDao.initialise(com.coverall.mt.http.User.getUser(request), userData);
				formAssociationDao.delete(conn);

			}
			response=new ConfirmationMessage();
			response.setCode("200");
			response.setDescription(formIdListCommaSeparated+" is/are deleted successfully for the "+entityType+" "+entityReference);
			//Adding specifics
			if(!isAddFormCall && auditTrailLog!=null){
			 for(String formId:formIds){
			  APIOperationUtil.populateAPISpecific(auditTrailLog, entityType, entityReference, formId, "Forms deleted");
			 }
			}

		} catch (APIException e) {
			throw new APIException(e.getErrorCode(),e.getErrorMessage(),e.getErrorMessageList(),null);
		}catch (Exception e) {
			errorMessageList = new ArrayList<Message>();
			message.setMoreinfo(e.getLocalizedMessage());
			errorMessageList.add(message);
			throw new APIException(APIConstant.RUNTIME_EXCEPTION,APIConstant.FAILED,errorMessageList,null);
		} finally {
			try {
				DBUtil.close(rs, pStmt);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return response;
	}
	
	public FormVariables convertVersionedFormVariableListToWithoutVersion(FormVariablesVersion2 formVariablesVersion2){
		if(formVariablesVersion2!=null){
			FormVariables formVariables=new FormVariables();

			List<FormVariable> variableList=new ArrayList<FormVariable>();
			for(FormVariableVersion2 variableVersion2:formVariablesVersion2.getFormVariables()){
				variableList.add(convertVersionedFormVariableToWithoutVersion(variableVersion2));
			}

			formVariables.setFormVariables(variableList);

			return formVariables;
		}
		return null;
	}
	
	public FormVariable convertVersionedFormVariableToWithoutVersion(FormVariableVersion2 formVariableVersion2){
		FormVariable variable=new FormVariable();
		
		variable.setVariableName(formVariableVersion2.getVariableName());
		variable.setVariableOccurrence(formVariableVersion2.getVariableOccurrence());
		variable.setVariableValue(formVariableVersion2.getVariableValue());
		variable.setRequired(formVariableVersion2.getRequired());
		return variable;
	}
	
	public Forms convertVersionedFormListToWithoutVersion(FormsVersion2 formsVersion2){
		Forms forms=new Forms();
		
		List<Form> formList=new ArrayList<Form>();
		for(FormVersion2 formVersion2:formsVersion2.getForms()){
			formList.add(convertVersionedFormToWithoutVersion(formVersion2));
		}
		
		forms.setForms(formList);
		
		return forms;
	}
	
	public Form convertVersionedFormToWithoutVersion(FormVersion2 formVersion2){
		Form form=new Form();
		
		form.setCoveragePart(formVersion2.getCoveragePart());
		form.setCoveragePartReference(formVersion2.getCoveragePartReference());
		form.setCustomEditionDate(formVersion2.getCustomEditionDate());
		form.setCustomFormNumber(formVersion2.getCustomFormNumber());
		form.setCustomTitle(formVersion2.getCustomTitle());
		form.setEditionDate(formVersion2.getEditionDate());
		form.setFormDescription(formVersion2.getFormDescription());
		form.setFormId(formVersion2.getFormId());
		form.setFormName(formVersion2.getFormName());
		form.setFormVariablePresent(formVersion2.getFormVariablePresent());
		form.setIsManualUpload(formVersion2.getIsManualUpload());
		form.setModifiedRevision(formVersion2.getModifiedRevision());
		form.setOccurrence(formVersion2.getOccurance());
		form.setRevision(formVersion2.getRevision());
		form.setStatus(formVersion2.getStatus());
		form.setUserOverride(formVersion2.getUserOverride());
		form.setFormVariables(convertVersionedFormVariableListToWithoutVersion(formVersion2.getFormVariables()));
		
		return form;
	}
}
