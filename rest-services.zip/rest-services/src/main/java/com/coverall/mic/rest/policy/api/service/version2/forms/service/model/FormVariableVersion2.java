package com.coverall.mic.rest.policy.api.service.version2.forms.service.model;

import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.coverall.mic.rest.policy.api.forms.model.FormVariable.requiredValues;

@XmlRootElement
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class FormVariableVersion2 {
	protected String variableName;
	protected String variableValue;
	protected String variableOccurrence;

	public  requiredValues required = requiredValues.N ;
	
	
	public requiredValues getRequired() {
		return required;
	}
	public void setRequired(requiredValues isRequired) {
		this.required = isRequired;
	}
	public String getVariableName() {
		return variableName;
	}
	public void setVariableName(String variableName) {
		this.variableName = variableName;
	}
	public String getVariableValue() {
		return variableValue;
	}
	public void setVariableValue(String variableValue) {
		this.variableValue = variableValue;
	}
	public String getVariableOccurrence() {
		return variableOccurrence;
	}
	public void setVariableOccurrence(String variableOccurrence) {
		this.variableOccurrence = variableOccurrence;
	}
	@Override
	public String toString() {
		return "FormVariable [variableName=" + variableName
				+ ", variableValue=" + variableValue + ", variableOccurrence=" + variableOccurrence + ", isRequired="
				+ required + "]";
	};
	
	
	
	

}
