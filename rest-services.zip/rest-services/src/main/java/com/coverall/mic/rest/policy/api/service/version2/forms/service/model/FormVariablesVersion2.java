package com.coverall.mic.rest.policy.api.service.version2.forms.service.model;

import java.util.List;
import java.util.ArrayList;

import javax.xml.bind.annotation.XmlRootElement;

import com.google.gson.Gson;
@XmlRootElement(name="formVariables")
public class FormVariablesVersion2 {
	
	protected String sourceSystemUserId;
	protected String sourceSystemCode;
	protected long sourceSystemRequestNo;
	
	private List <FormVariableVersion2> formVariables =  new ArrayList <FormVariableVersion2>() ;

	public List<FormVariableVersion2> getFormVariables() {
		return formVariables;
	}

	public void setFormVariables(List<FormVariableVersion2> formVariableList) { 
		this.formVariables = formVariableList; 
	}
	
	public FormVariablesVersion2() {
		super();
	}

	public FormVariablesVersion2(String json) {
		super();
		Gson gson = new Gson();
		FormVariablesVersion2 request = gson.fromJson(json, FormVariablesVersion2.class);
        this.formVariables = request.formVariables;
	}

	static FormVariablesVersion2 valueOf(String json) {
		Gson gson = new Gson();
        return gson.fromJson(json, FormVariablesVersion2.class);
	}

	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}

	public void setSourceSystemUserId(String sourceSystemUserId) {
		this.sourceSystemUserId = sourceSystemUserId;
	}

	public String getSourceSystemCode() {
		return sourceSystemCode;
	}

	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}

	public long getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}

	public void setSourceSystemRequestNo(long sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}
		
}
