package com.coverall.mic.rest.policy.api.service.version2.forms.service.model;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.coverall.mic.rest.policy.api.forms.model.Form.formVariableIsPresent;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class FormVersion2 {
	
	protected int formId ;
	protected String  formName;
	protected String formDescription;
	protected String occurance;
	protected String revision;
	protected String coveragePart;
	protected String coveragePartReference;
	protected String status;
	protected String modifiedRevision;
	protected String editionDate;
	protected String customFormNumber;
	protected String customTitle;
	protected String customEditionDate;
	protected String userOverride;
	protected String isManualUpload;
	
	
	protected formVariableIsPresent formVariablePresent = formVariableIsPresent.N;
	protected FormVariablesVersion2 formVariables;
	
	public formVariableIsPresent getFormVariablePresent() {
		return formVariablePresent;
	}
	public void setFormVariablePresent(formVariableIsPresent isVariablePresent) {
		this.formVariablePresent = isVariablePresent;
	}
	public int getFormId() {
		return formId;
	}
	public void setFormId(int formId) {
		this.formId = formId;
	}
	public String getFormName() {
		return formName;
	}
	public void setFormName(String formName) {
		this.formName = formName;
	}
	public String getFormDescription() {
		return formDescription;
	}
	public void setFormDescription(String formDescription) {
		this.formDescription = formDescription;
	}
	public String getRevision() {
		return revision;
	}
	public void setRevision(String revision) {
		this.revision = revision;
	}
	public String getCoveragePart() {
		return coveragePart;
	}
	public void setCoveragePart(String coveragePart) {
		this.coveragePart = coveragePart;
	}
	public String getCoveragePartReference() {
		return coveragePartReference;
	}
	public void setCoveragePartReference(String coveragePartReference) {
		this.coveragePartReference = coveragePartReference;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getOccurance() {
		return occurance;
	}
	public void setOccurance(String occurance) {
		this.occurance = occurance;
	}
	public String getModifiedRevision() {
		return modifiedRevision;
	}
	public void setModifiedRevision(String modifiedRevision) {
		this.modifiedRevision = modifiedRevision;
	}
	public String getEditionDate() {
		return editionDate;
	}
	public void setEditionDate(String editionDate) {
		this.editionDate = editionDate;
	}
	public FormVariablesVersion2 getFormVariables() {
		return formVariables;
	}
	public void setFormVariables(FormVariablesVersion2 formVariables) {
		this.formVariables = formVariables;
	}
	public String getCustomFormNumber() {
		return customFormNumber;
	}
	public void setCustomFormNumber(String customFormNumber) {
		this.customFormNumber = customFormNumber;
	}
	public String getCustomTitle() {
		return customTitle;
	}
	public void setCustomTitle(String customTitle) {
		this.customTitle = customTitle;
	}
	public String getUserOverride() {
		return userOverride;
	}
	public void setUserOverride(String userOverride) {
		this.userOverride = userOverride;
	}
	public String getCustomEditionDate() {
		return customEditionDate;
	}
	public void setCustomEditionDate(String customEditionDate) {
		this.customEditionDate = customEditionDate;
	}
	public String getIsManualUpload() {
		return isManualUpload;
	}
	public void setIsManualUpload(String isManualUpload) {
		this.isManualUpload = isManualUpload;
	}
	@Override
	public String toString() {
		return "Form [formId=" + formId
				+ ", formName=" + formName + ", formDescription="
				+ formDescription + ", revision=" + revision
				+ ", coveragePart=" + coveragePart + ", coveragePartReference="
				+ coveragePartReference + ", status=" + status
				+ ", modifiedRevision=" + modifiedRevision + ", editionDate="
				+ editionDate + ", customFormNumber=" + customFormNumber
				+ ", customTitle=" + customTitle + ", customEditionDate="
				+ customEditionDate + ", userOverride=" + userOverride
				+ ", isManualUpload=" + isManualUpload + ", isVariablePresent="
				+ formVariablePresent + ", formVariables=" + formVariables + "]";
	}

}
