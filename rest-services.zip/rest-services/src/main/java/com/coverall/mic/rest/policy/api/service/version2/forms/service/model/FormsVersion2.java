package com.coverall.mic.rest.policy.api.service.version2.forms.service.model;

import java.util.ArrayList;
import java.util.List;

public class FormsVersion2 {
	
	protected String sourceSystemUserId;
	protected String sourceSystemCode;
	protected long sourceSystemRequestNo;

	public List<FormVersion2> forms = new ArrayList<FormVersion2>();;

	public List<FormVersion2> getForms() {
		return forms;
	}

	public void setForms(List<FormVersion2> formList) {
		this.forms = formList;
	}

	public String getSourceSystemUserId() {
		return sourceSystemUserId;
	}

	public void setSourceSystemUserId(String sourceSystemUserId) {
		this.sourceSystemUserId = sourceSystemUserId;
	}

	public String getSourceSystemCode() {
		return sourceSystemCode;
	}

	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}

	public long getSourceSystemRequestNo() {
		return sourceSystemRequestNo;
	}

	public void setSourceSystemRequestNo(long sourceSystemRequestNo) {
		this.sourceSystemRequestNo = sourceSystemRequestNo;
	}
	
}
