package com.coverall.mic.rest.policy.api.servlet;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;

import org.apache.cxf.common.classloader.ClassLoaderUtils;
import org.apache.cxf.helpers.CastUtils;
import org.apache.cxf.jaxrs.servlet.CXFNonSpringJaxrsServlet;

public class APICXFNonSpringJaxrsServlet extends CXFNonSpringJaxrsServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String PROVIDERS_PARAM = "jaxrs.providers";
	private static final String API_EXCEPTION_PROVIDER = "com.coverall.mic.rest.policy.api.exception.APIExceptionHandler";
	
	protected List<?> getProviders(ServletConfig servletConfig) throws ServletException {
		String providersList = servletConfig.getInitParameter(PROVIDERS_PARAM);
		Class<?> clsExpProvider = loadClass(API_EXCEPTION_PROVIDER);
		List<Object> providers = new ArrayList<Object>();
		Map<String, String> ExpProviderProps = new HashMap<String, String>();
		providers.add(createSingletonInstance(clsExpProvider, ExpProviderProps, servletConfig));
		
		if (providersList == null) {
			return providers;
		}
		String[] classNames = providersList.split(" ");
		
		for (String cName : classNames) {
			Map<String, String> props = new HashMap<String, String>();
			String theName = getClassNameAndProperties(cName, props);
			if (theName.length() != 0) {
				Class<?> cls = loadClass(theName);
				providers.add(createSingletonInstance(cls, props, servletConfig));
			}
		}
		return providers;
	}

	private String getClassNameAndProperties(String cName, Map<String, String> props) {
		String theName = cName.trim();
		int ind = theName.indexOf("(");
		if (ind != -1 && theName.endsWith(")")) {
			props.putAll(CastUtils.cast(handleMapSequence(theName.substring(ind + 1, theName.length() - 1)), String.class, String.class));
			theName = theName.substring(0, ind).trim();
		}
		return theName;
	}

	private Class<?> loadClass(String cName) throws ServletException {
		return loadClass(cName, "Resource");
	}

	private Class<?> loadClass(String cName, String classType) throws ServletException {
		try {
			return ClassLoaderUtils.loadClass(cName, CXFNonSpringJaxrsServlet.class);
		} catch (ClassNotFoundException ex) {
			throw new ServletException("No " + classType + " class " + cName.trim() + " can be found", ex);
		}
	}
}
