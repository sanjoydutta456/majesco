package com.coverall.mic.rest.policy.dao;

import java.util.List;

import com.coverall.mic.rest.policy.service.model.PCTUploadStatus;
import com.coverall.mt.http.User;

public interface PCTUploadStatusDao {

	public void lockUploadStatus(PCTUploadStatus uploadStatus, User user)
			throws Exception;

	public void unlockUploadStatus(PCTUploadStatus uploadStatus, User user) throws Exception;
	
	public void saveUploadStatus(PCTUploadStatus uploadStatus, User user) throws Exception;
	
	public List<PCTUploadStatus> listUpdatedUploadStatus(User user) throws Exception;

	public void updateUploadStatus(PCTUploadStatus uploadStatus, User user) throws Exception;

	public PCTUploadStatus getUploadStatus(String entityType, String entityReference, User user) throws Exception;
}
