package com.coverall.mic.rest.policy.dao.impl;

import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import com.coverall.documents.util.DBUtil;
import com.coverall.mic.rest.policy.dao.PCTUploadStatusDao;
import com.coverall.mic.rest.policy.service.model.PCTUploadStatus;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;

public class PCTUploadStatusDaoImpl implements PCTUploadStatusDao {
	private static final String QUERY_LOCK_UPLOAD_STATUS = 
			  "DECLARE "
			+ "  v_entity_type varchar2(20) := ? ; "
			+ "  v_entity_reference varchar2(50) := ?; "
			+ "  v_org_entity_reference varchar2(50) := ?; "
			+ "  v_lock_process varchar2(20) := ?; "
			+ "  v_userId varchar2(60) := ?; "
			+ "  v_error varchar2(4000);"
			+ "  v_count number := 0; "
			+ "  v_id number := 0; "
			+ "BEGIN "
			+ "  BEGIN "
			+ "    UPDATE pct_rs_upload_status "
			+ "    SET pru_status = 'LOCK',"
			+ "        pru_process = v_lock_process, "
			+ "        pru_user_modified = v_userId "
			+ "    WHERE pru_entity_type = v_entity_type "
			+ "      AND pru_entity_reference = v_entity_reference "
			+ "      AND NVL(pru_status, 'XXXX') != 'LOCK'; "
			+ "  "
			+ "    v_count := SQL%ROWCOUNT; "
			+ "    IF v_count = 1 THEN "
			+ "      SELECT pru_id "
			+ "      INTO v_id "
			+ "      FROM pct_rs_upload_status "
			+ "      WHERE pru_entity_type = v_entity_type "
			+ "        AND pru_entity_reference = v_entity_reference "
			+ "        AND pru_status = 'LOCK'; "
			+ "    END IF; "
			+ "  "
			+ "    IF v_id = 0 THEN "
			+ "      SELECT COUNT(1) "
			+ "      INTO v_count "
			+ "      FROM pct_rs_upload_status "
			+ "      WHERE pru_entity_type = v_entity_type "
			+ "        AND pru_entity_reference = v_entity_reference; "
			+ "    "
			+ "      IF v_count = 0 THEN "
			+ "        IF v_lock_process = 'upload' THEN "
			+ "          INSERT INTO pct_rs_upload_status(pru_id, pru_entity_type, pru_entity_reference, pru_org_entity_reference, pru_process, pru_status, pru_user_created) "
			+ "          VALUES(s_pru_id_seq.nextval, v_entity_type, v_entity_reference, v_org_entity_reference, v_lock_process, 'LOCK', v_userId); "
			+ "  "
			+ "          SELECT pru_id "
			+ "          INTO v_id "
			+ "          FROM pct_rs_upload_status "
			+ "          WHERE pru_entity_type = v_entity_type "
			+ "            AND pru_entity_reference = v_entity_reference; "
			+ "        ELSIF v_lock_process = 'statusUpdate' THEN "
			+ "          v_error := 'No entry to lock for status update!'; "
			+ "        ELSE "
			+ "          v_error := 'Invalid process: ' || v_lock_process; " 
			+ "        END IF; "
			+ "      ELSE "
			+ "        v_error := 'Another process is locking the policy!'; "
			+ "      END IF; "
			+ "    END IF; "
			+ "  EXCEPTION "
			+ "    WHEN OTHERS THEN "
			+ "      v_id := 0; "
			+ "      v_error := SQLERRM; "
			+ "  END; "
			+ "  "
			+ "  ? := v_id; "
			+ "  ? := v_error; "
			+ "END;";
	
	private static final String QUERY_SAVE_UPLOAD_STATUS = 
			  "MERGE INTO pct_rs_upload_status d "
			+ "USING (SELECT wac_entity_type entityType, "
			+ "wac_entity_reference entityReference, "
			+ "? orgEntityReference, "
			+ "? process, "
			+ "? logLevel, "
			+ "? purgeExistingEntity, "
			+ "? rateEntity, "
			+ "? retainAuditFieldVals, "
			+ "? retainIdVals, "
			+ "? createNewEntity, "
			+ "? policyXML, "
			+ "? xmlZipped, "
			+ "? status, "
			+ "? statusCode, "
			+ "? errorMessage, "
			+ "? responseData, "
			+ "? returnRatedEntity, "
			+ "? userId, "
			+ "wac_stage ratingStatus "
			+ "FROM wfl_activities, wfl_tasks "
			+ "WHERE wac_entity_type = ? "
			+ "AND wac_entity_reference = ? "
			+ "AND wac_task_id = wta_id "
			+ "AND wta_name = 'RATING' "
			+ " ) s "
			+ "ON (d.pru_entity_type = s.entityType AND d.pru_entity_reference = s.entityReference) "
			+ "WHEN MATCHED THEN UPDATE SET d.pru_org_entity_reference = s.orgEntityReference, "
			+ "d.pru_process = s.process, "
			+ "d.pru_log_level = s.logLevel, "
			+ "d.pru_purge_existing_entity = s.purgeExistingEntity, "
			+ "d.pru_rate_entity = s.rateEntity, "
			+ "d.pru_retain_audit_field_vals = s.retainAuditFieldVals, "
			+ "d.pru_retain_id_vals = s.retainIdVals, "
			+ "d.pru_create_new_entity = s.createNewEntity, "
			+ "d.pru_policy_xml = s.policyXML, "
			+ "d.pru_xml_zipped = s.xmlZipped, "
			+ "d.pru_status = s.status, "
			+ "d.pru_status_code = s.statusCode, "
			+ "d.pru_error_message = s.errorMessage, "
			+ "d.pru_response_data = s.responseData, "
			+ "d.pru_return_rated_entity = s.returnRatedEntity, "
			+ "d.pru_user_modified = s.userId, "
			+ "d.pru_entity_status = s.ratingStatus "
			+ "WHEN NOT MATCHED THEN INSERT (d.pru_id, d.pru_entity_type, d.pru_entity_reference, d.pru_org_entity_reference, d.pru_process, d.pru_log_level, d.pru_purge_existing_entity, d.pru_rate_entity, d.pru_retain_audit_field_vals, d.pru_retain_id_vals,d.pru_create_new_entity, d.pru_policy_xml, d.pru_xml_zipped, d.pru_status, d.pru_status_code, d.pru_error_message, d.pru_response_data, d.pru_return_rated_entity, d.pru_user_created, d.pru_entity_status) "
			+ "VALUES (s_pru_id_seq.nextval, s.entityType, s.entityReference, s.orgEntityReference, s.process, s.logLevel, s.purgeExistingEntity, s.rateEntity, s.retainAuditFieldVals, s.retainIdVals, s.createNewEntity, s.policyXML, s.xmlZipped, s.status, s.statusCode, s.errorMessage, s.responseData, s.returnRatedEntity, s.userId, s.ratingStatus)";
	
	private static final String QUERY_UNLOCK_UPLOAD_STATUS = 
			  "UPDATE pct_rs_upload_status "
			+ "SET pru_status = ?,"
			+ "    pru_user_modified = ? "
			+ "WHERE pru_entity_type = ? "
			+ "AND pru_entity_reference = ?";	
	
	private static final String QUERY_LIST_UPDATED_UPLOAD_STATUS = 
			  "SELECT pru_id, "
			+ "pru_entity_type, "
			+ "pru_entity_reference,"
			+ "pru_org_entity_reference,"
			+ "pru_status,"
			+ "pru_status_code,"
			+ "pru_error_message,"
			+ "pru_entity_status "
			+ "FROM pct_rs_upload_status, wfl_activities, wfl_tasks "
			+ "WHERE pru_entity_type = wac_entity_type "
			+ "AND pru_entity_reference = wac_entity_reference "
			+ "AND wac_task_id = wta_id "
			+ "AND pru_status = 'FAILURE' "
			+ "AND wta_name= 'RATING' "
			+ "AND pru_rate_entity = 'true' "
			+ "AND pru_entity_status = 'SUSPENSE' "
			+ "AND wac_stage = 'COMPLETE' ";
	
	private static final String QUERY_UPDATE_UPLOAD_STATUS = 
			  "UPDATE pct_rs_upload_status "
			+ "SET pru_status = ?, "
			+ "    pru_status_code = ?, "
			+ "    pru_entity_status = ?, "
			+ "    pru_response_data = ?, "
			+ "    pru_user_modified = ? "
			+ "WHERE pru_entity_type = ? "
			+ "  AND pru_entity_reference = ? "
			+ "  AND pru_status = 'LOCK' "
			+ "  AND pru_entity_status = 'SUSPENSE' "
			+ "  AND pru_process = 'statusUpdate'";
	
	private static final String QUERY_GET_UPLOAD_STATUS = ""
			+ "SELECT pru_xml_zipped,"
			+ "		  pru_return_rated_entity "
			+ "FROM pct_rs_upload_status "
			+ "WHERE pru_entity_type = ? "
			+ "  AND pru_entity_reference = ? ";
	
	private static PCTUploadStatusDao statusDao = new PCTUploadStatusDaoImpl();
	
	public static PCTUploadStatusDao getInstance() {
		return statusDao;
	}	
	
	@Override
	public void lockUploadStatus(PCTUploadStatus uploadStatus, User user) throws Exception {
		Connection conn = null;
		CallableStatement cst = null;
		try {
			conn = ConnectionPool.getConnection(user);
			cst = conn.prepareCall(QUERY_LOCK_UPLOAD_STATUS);
			
			cst.setString(1, uploadStatus.getEntityType());
			cst.setString(2, uploadStatus.getEntityReference());
			cst.setString(3, uploadStatus.getOrgEntityReference());
			cst.setString(4, uploadStatus.getProcess());
			cst.setString(5, user.getFullName());

			cst.registerOutParameter(6, Types.INTEGER);
			cst.registerOutParameter(7, Types.VARCHAR);
			
			cst.executeUpdate();
			
			int id = cst.getInt(6);
			
			if(id == 0) {
				String error = cst.getString(7);
				throw new Exception(error);
			}
			
			conn.commit();
		} catch (Exception ex) {
			try {
				conn.rollback();
			} catch (Exception ex2) {
				ex2.printStackTrace();
			}
			throw ex;
		} finally {
			try {
				DBUtil.close(null, cst, conn);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}

	@Override
	public void unlockUploadStatus(PCTUploadStatus uploadStatus, User user) {
		Connection conn = null;
		PreparedStatement pst = null;
		try {
			conn = ConnectionPool.getConnection(user);
			pst = conn.prepareStatement(QUERY_UNLOCK_UPLOAD_STATUS);
			
			pst.setString(1, uploadStatus.getStatus());
			pst.setString(2, user.getFullName());
			pst.setString(3, uploadStatus.getEntityType());
			pst.setString(4, uploadStatus.getEntityReference());
			

			pst.executeUpdate();
			
			conn.commit();
		} catch (Exception ex) {
			try {
				conn.rollback();
			} catch (Exception ex2) {
				ex2.printStackTrace();
			}

			ex.printStackTrace();
			
		} finally {
			try {
				DBUtil.close(null, pst, conn);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}
	
	@Override
	public void saveUploadStatus(PCTUploadStatus uploadStatus, User user) {
		Connection conn = null;
		PreparedStatement pst = null;
		try {
			conn = ConnectionPool.getConnection(user);
			pst = conn.prepareStatement(QUERY_SAVE_UPLOAD_STATUS);
			
			pst.setString(1, uploadStatus.getOrgEntityReference());
			pst.setString(2, uploadStatus.getProcess());
			pst.setString(3, uploadStatus.getLogLevel());
			pst.setString(4, uploadStatus.getPurgeExistingEntity());
			pst.setString(5, uploadStatus.getRateEntity());
			pst.setString(6, uploadStatus.getRetainAuditFieldVals());
			pst.setString(7, uploadStatus.getRetainIDVals());
			pst.setString(8, uploadStatus.getCreateNewEntity());
			
			String policyXML = uploadStatus.getPolicyXML();
			if(policyXML != null) {
				Clob clob = conn.createClob();
				clob.setString(1, policyXML);
				pst.setClob(9, clob);
			} else {
				pst.setNull(9, Types.CLOB);
			}
			
			pst.setString(10, uploadStatus.getXmlZipped());
			pst.setString(11, uploadStatus.getStatus());
			pst.setInt(12, uploadStatus.getStatusCode());
			pst.setString(13, uploadStatus.getErrorMessage());
			
			String responseData = uploadStatus.getResponseData();
			if(responseData != null) {
				Clob clob = conn.createClob();
				clob.setString(1, responseData);
				pst.setClob(14, clob);
			} else {
				pst.setNull(14, Types.CLOB);
			}
			
			pst.setString(15, uploadStatus.getReturnRatedEntity());
			pst.setString(16, user.getFullName());
			
			pst.setString(17, uploadStatus.getEntityType());
			pst.setString(18, uploadStatus.getEntityReference());			

			pst.executeUpdate();
			
			conn.commit();
		} catch (Exception ex) {
			try {
				conn.rollback();
			} catch (Exception ex2) {
				ex2.printStackTrace();
			}
			ex.printStackTrace();
		} finally {
			try {
				DBUtil.close(null, pst, conn);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}

	@Override
	public List<PCTUploadStatus> listUpdatedUploadStatus(User user) throws Exception {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		
		List<PCTUploadStatus> updatedUploadStatus = new ArrayList<PCTUploadStatus>();
		
		try {
			conn = ConnectionPool.getConnection(user);
			pst = conn.prepareStatement(QUERY_LIST_UPDATED_UPLOAD_STATUS);
			
			rs = pst.executeQuery();
			while(rs.next()) {
				PCTUploadStatus uploadStatus = new PCTUploadStatus();
				uploadStatus.setId(rs.getLong(1));
				uploadStatus.setEntityType(rs.getString(2));
				uploadStatus.setEntityReference(rs.getString(3));
				uploadStatus.setOrgEntityReference(rs.getString(4));
				uploadStatus.setStatus(rs.getString(5));
				uploadStatus.setStatusCode(rs.getInt(6));
				uploadStatus.setErrorMessage(rs.getString(7));
				uploadStatus.setEntityStatus(rs.getString(8));
				
				updatedUploadStatus.add(uploadStatus);
			}
		} catch (Exception ex) {
			throw ex;
		} finally {
			try {
				DBUtil.close(rs, pst, conn);
			} catch (Exception ex2) {
				ex2.printStackTrace();
			}
		}
		
		return updatedUploadStatus;
	}

	@Override
	public void updateUploadStatus(PCTUploadStatus uploadStatus, User user) throws Exception {
		Connection conn = null;
		PreparedStatement pst = null;
		try {
			conn = ConnectionPool.getConnection(user);
			pst = conn.prepareStatement(QUERY_UPDATE_UPLOAD_STATUS);

			pst.setString(1, uploadStatus.getStatus());
			pst.setInt(2, uploadStatus.getStatusCode());
			pst.setString(3, uploadStatus.getEntityStatus());
			
			String responseData = uploadStatus.getResponseData();
			if(responseData != null) {
				Clob clob = conn.createClob();
				clob.setString(1, responseData);
				pst.setClob(4, clob);
			} else {
				pst.setNull(4, Types.CLOB);
			}			
			
			pst.setString(5, user.getFullName());
			pst.setString(6, uploadStatus.getEntityType());
			pst.setString(7, uploadStatus.getEntityReference());
			

			int rowCount = pst.executeUpdate();
			if(rowCount == 0) {
				throw new Exception("No status updated!");
			}
			
			conn.commit();
		} catch (Exception ex) {
			try {
				conn.rollback();
			} catch (Exception ex2) {
				ex2.printStackTrace();
			}
			throw ex;
		} finally {
			try {
				DBUtil.close(null, pst, conn);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}

	}	
	
	
	@Override
	public PCTUploadStatus getUploadStatus(String entityType, String entityReference, User user) throws Exception {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		
		PCTUploadStatus uploadStatus = null;
		
		try {
			conn = ConnectionPool.getConnection(user);
			pst = conn.prepareStatement(QUERY_GET_UPLOAD_STATUS);
			
			pst.setString(1, entityType);
			pst.setString(2,  entityReference);
			
			rs = pst.executeQuery();
			if(rs.next()) {
				uploadStatus = new PCTUploadStatus();
				uploadStatus.setXmlZipped(String.valueOf(rs.getString(1)));
				uploadStatus.setReturnRatedEntity((String.valueOf(rs.getString(2))));
			}
		} catch (Exception ex) {
			throw ex;
		} finally {
			try {
				DBUtil.close(rs, pst, conn);
			} catch (Exception ex2) {
				ex2.printStackTrace();
			}
		}
		
		return uploadStatus;
	}

}
