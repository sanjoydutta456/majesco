package com.coverall.mic.rest.policy.events;

import com.coverall.mt.webservices.rsupload.PCTRSUploadStatusRequest;
import com.coverall.mt.webservices.rsupload.PCTRSUploadStatusResponse;
import com.coverall.mt.webservices.rsupload.btis.BTISRSNotifyRequest;
import com.coverall.mt.webservices.rsupload.btis.BTISRSNotifyResponse;

public class BTISRSNotifyEventProcessor extends PCTUploadStatusEventProcessor {	
	@Override
	public PCTRSUploadStatusResponse getStatusResponse() {
		return new BTISRSNotifyResponse();
	}
	
	@Override
	public PCTRSUploadStatusRequest getStatusRequest() {
		return new BTISRSNotifyRequest();
	} 

}
