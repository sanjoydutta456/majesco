package com.coverall.mic.rest.policy.events;

import java.util.HashMap;
import java.util.Map;

import com.coverall.mic.rest.policy.dao.PCTUploadStatusDao;
import com.coverall.mic.rest.policy.dao.impl.PCTUploadStatusDaoImpl;
import com.coverall.mic.rest.policy.service.model.PCTUploadStatus;
import com.coverall.mt.events.EventProcessor;
import com.coverall.mt.events.EventResponse;
import com.coverall.mt.events.EventResponseDetails;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.util.ObjectStringMapper;
import com.coverall.mt.webservices.rsupload.PCTRSUploadStatusClient;
import com.coverall.mt.webservices.rsupload.PCTRSUploadStatusRequest;
import com.coverall.mt.webservices.rsupload.PCTRSUploadStatusResponse;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.pctv2.server.ws.client.upload.PCTUploadResponse;
import com.coverall.pctv2.server.ws.service.upload.PCTUploadRequest;
import com.coverall.pctv2.server.ws.service.upload.PolicyUpload;

public class PCTUploadStatusEventProcessor extends EventProcessor {	
	private static final String NAME_WEBSERVICE = 
		        "MIC - INTERNAL - WS - PCT - UPLOAD - STATUS - UPDATE - SERVICE";
	
	public static final String EVENT_PCT_UPLOAD_STATUS_UPDATE = "PCTUPLOADSTATUSUPDATE";
	
	private static final PCTUploadStatusDao statusDao = PCTUploadStatusDaoImpl.getInstance();

    public String gatherInput(int activityId, String entityType,
            String entityReference,
            HashMap params) throws Exception {
    	return null;
    }	
	
	public PCTRSUploadStatusClient getWSClient() {
		return new PCTRSUploadStatusClient();
	}
	
	public PCTRSUploadStatusResponse getStatusResponse() {
		return new PCTRSUploadStatusResponse();
	}
	
	public PCTRSUploadStatusRequest getStatusRequest() {
		return new PCTRSUploadStatusRequest();
	}	

	public void setStatusRequestData(PCTRSUploadStatusRequest request, String entityType, String entityReference, User user) {		
		request.setStatus(PCTUploadStatus.STATUS_SUCCESS);
		request.setStatusCode(PCTUploadResponse.STATUS_SUCCESS);
		request.setEntityReference(entityReference);
		
	    Map<String, String> policyData = getPolicyData(entityType, entityReference, user);
		request.setPolicyData(policyData);
		
		PCTUploadStatus uploadStatus = getUploadStatus(entityType, entityReference, user);
		
		boolean returnRatedEntity = false;
		if(uploadStatus != null) {
			String xmlZippedString = uploadStatus.getXmlZipped();
			if("true".equalsIgnoreCase(xmlZippedString)) {
				request.setXmlZipped(true);
			}
			String returnRatedEntityString = uploadStatus.getReturnRatedEntity();
			if("true".equalsIgnoreCase(returnRatedEntityString)) {
				returnRatedEntity = true;
			}
		}
		
		if(returnRatedEntity) {
			String xmlExtract = getXmlExtract(entityType, entityReference,
					request.isXmlZipped(), user);
			request.setXmlExtract(xmlExtract);
		}	
	}

    /**
     * Call the EFolder webservice and save the Documents to local directory.
     * 
     * @param inputXML webservice request data.
     * @param params parameters.
     * @return EventResponse.
     * @throws Exception
     */
    public EventResponse execute(String inputXML, HashMap params) throws Exception {

		EventResponseDetails eventResponse = new EventResponseDetails();

		int activityId = Integer.parseInt(params.get("WEA_ID").toString());

		User user = (User)params.get("User");
		String entityType = (String)params.get("WEA_ENTITY_TYPE");
		String entityReference = (String)params.get("WEA_ENTITY_REFERENCE");
		
		PCTRSUploadStatusResponse response = null;
		PCTRSUploadStatusRequest request = null;
		try {
			request = getStatusRequest();
			setStatusRequestData(request, entityType, entityReference, user);
			response = getStatusResponse();
			PCTRSUploadStatusClient wsClient = getWSClient();
			response = wsClient.callWebService(request, response, params);

			LogMinder.getLogMinder().log(
					LogEntry.SEVERITY_INFO,
					getClass().getName(),
					"execute",
					ServletConfigUtil.COMPONENT_FRAMEWORK,
					new Object[] {
							"Request="
									+ ObjectStringMapper
											.convertObjectToXmlString(request,
													request.getClass()),
							"ActivityId=" + String.valueOf(activityId) }, null,
					null, LogMinderDOMUtil.VALUE_MIC);
		} catch (Exception ex) {
			LogMinder.getLogMinder().log(
					LogEntry.SEVERITY_FATAL,
					getClass().getName(),
					"execute",
					ServletConfigUtil.COMPONENT_FRAMEWORK,
					new Object[] {
							"Request="
									+ ObjectStringMapper
											.convertObjectToXmlString(request,
													request.getClass()),
							"ActivityId=" + String.valueOf(activityId) },
					ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
			throw new Exception(ex);
		}

		String errMsg = response.getErrorMessage();
		String operStatus = response.getStatus();

		if ("SUCCESS".equalsIgnoreCase(operStatus)) {
			try {
				updateUploadStatus(entityType, entityReference, request, PCTUploadStatus.ENTITY_STATUS_COMPLETE, user);
			} catch (Exception ex) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
						getClass().getName(), "execute",
						ServletConfigUtil.COMPONENT_FRAMEWORK,
						new Object[] { params, "ActivityId=" + activityId },
						ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
				errMsg = errMsg + "\n " + ex.getMessage();
			}

			eventResponse.setIsSuccess(true);
			if ((errMsg != null) && (!"".equalsIgnoreCase(errMsg.trim()))) {
				eventResponse.setStoreDetails(true);
				eventResponse.setResponse(errMsg);
			} else {
				eventResponse.setStoreDetails(false);
			}

		} else {
			eventResponse.setIsSuccess(false);
			eventResponse.setStoreDetails(true);
			eventResponse.setResponse(errMsg);
		}

		return eventResponse;
    }
    
    private PCTUploadStatus getUploadStatus(String entityType, String entityReference, User user) {
		PCTUploadStatus uploadStatus = null;

		try {
			uploadStatus = statusDao.getUploadStatus(entityType, entityReference,
					user);
		} catch (Exception ex) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					getClass().getName(), "getUploadStatus",
					ServletConfigUtil.COMPONENT_FRAMEWORK,
					new Object[] { "entityReference=" + entityReference},
					ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
		}

		return uploadStatus;
    }
    
    private String getXmlExtract(String entityType, String entityReference, boolean xmlZipped, User user) {
    	String xmlExtract = null;
    	PolicyUpload upload = new PolicyUpload();
    	try {
    		PCTUploadRequest request = new PCTUploadRequest();
    		request.setUserName(user.getFullName());
    		xmlExtract = upload.getXMLExtract(request, entityType, entityReference, user);
    		if(xmlExtract != null) {
    			xmlExtract = upload.getXMLExtractAsBase64String(xmlExtract, entityReference, xmlZipped);
    		}
    	} catch (Exception ex) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					getClass().getName(), "getXmlExtract",
					ServletConfigUtil.COMPONENT_FRAMEWORK,
					new Object[] { "entityReference=" + entityReference, "xmlZipped=" + xmlZipped },
					ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
    	}
    	
    	return xmlExtract;
    }
    
    
	private Map<String,String> getPolicyData(String entityType, String entityReference, User user) {
		PCTUploadRequest request = new PCTUploadRequest();
		request.setUserName(user.getFullName());

		Map<String, String> policyData = null;
		try {
			policyData = new PolicyUpload().getPolicyData(request,
					entityReference,
					entityType,
					user);
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return policyData;	
	}	
    
	private void updateUploadStatus(String entityType, String entityReference,PCTRSUploadStatusRequest statusRequest, String entityStatus, User user) throws Exception {
		PCTUploadStatus uploadStatus = new PCTUploadStatus();
		uploadStatus.setProcess(PCTUploadStatus.PROCESS_STATUS_UPDATE);
		uploadStatus.setEntityType(entityType);
		uploadStatus.setEntityReference(entityReference);
		uploadStatus.setStatus(statusRequest.getStatus());
		uploadStatus.setStatusCode(statusRequest.getStatusCode());
		uploadStatus.setErrorMessage(statusRequest.getErrorMessage());
		
		Map<String, String> policyData = statusRequest.getPolicyData();
		
		if(policyData != null) {
			uploadStatus.setResponseData(policyData.toString());
		}
		
		uploadStatus.setEntityStatus(entityStatus);
		
		try {
			statusDao.updateUploadStatus(uploadStatus, user);
		} catch (Exception ex) {
			throw ex;
		}		
	}
	
	@Override
	public String getWebServiceName() {
		return NAME_WEBSERVICE;
	}

	@Override
	public void postProcessEvent(HashMap params, EventResponse response)
			throws Exception {	
	}	
}
