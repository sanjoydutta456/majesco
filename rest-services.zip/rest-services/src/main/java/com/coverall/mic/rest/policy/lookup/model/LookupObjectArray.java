package com.coverall.mic.rest.policy.lookup.model;

import java.util.ArrayList;
import java.util.Map;

public class LookupObjectArray {
	ArrayList<Map<String,String>> data=new ArrayList<Map<String,String>>();

	public ArrayList<Map<String, String>> getData() {
		return data;
	}

	public void setData(ArrayList<Map<String, String>> data) {
		this.data = data;
	}
}
