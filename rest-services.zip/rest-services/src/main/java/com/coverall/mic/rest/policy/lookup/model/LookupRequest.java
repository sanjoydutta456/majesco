package com.coverall.mic.rest.policy.lookup.model;

import java.util.ArrayList;
import java.util.Map;

public class LookupRequest {
	
	Map<String,String> params;
	Map<String,LookupObjectArray> complexParams;
	
	public Map<String, String> getParams() {
		return params;
	}
	public void setParams(Map<String, String> params) {
		this.params = params;
	}
	public Map<String, LookupObjectArray> getComplexParams() {
		return complexParams;
	}
	public void setComplexParams(Map<String, LookupObjectArray> complexParams) {
		this.complexParams = complexParams;
	}
}
