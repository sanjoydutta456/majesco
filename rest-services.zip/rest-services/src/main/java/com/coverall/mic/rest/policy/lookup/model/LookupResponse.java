package com.coverall.mic.rest.policy.lookup.model;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class LookupResponse implements Serializable, Cloneable, Comparable<LookupResponse> {
	
	Map<String,Map<String,String>> header;
	List<Map<String,String>> data;
	
	public Map<String, Map<String, String>> getHeader() {
		return header;
	}
	public void setHeader(Map<String, Map<String, String>> header) {
		this.header = header;
	}
	public List<Map<String, String>> getData() {
		return data;
	}
	public void setData(List<Map<String, String>> data) {
		this.data = data;
	}
	
	@Override
	public int compareTo(LookupResponse lookupResponse) {
		if(null == this.data
				|| null == this.header){
			if(null != this.data 
					&& this.data.equals(lookupResponse.data)){
				return 0;
			} else if(null != this.header 
					&& this.header.equals(lookupResponse.header)){
				return 0;
			} else if (null == this.data
					&& null == lookupResponse.data
					&& null == this.header
					&& null == lookupResponse.header){
				return 0;
			} else {
				return -1;
			}
		} else if(this.data.equals(lookupResponse.data) 
				&& this.header.equals(lookupResponse.header)) {
		    return 0; 
		} else  {
		    return -1;
		}
	}
}
