package com.coverall.mic.rest.policy.lookup.service;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;


@Path("/")
@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON , MediaType.MULTIPART_FORM_DATA })
@Produces({ MediaType.APPLICATION_JSON , MediaType.MULTIPART_FORM_DATA })
public interface LookupService {

	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@POST
	public Object getLookupData(@Context HttpServletRequest request) throws Exception;
	
	@Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
    @Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
    @Path("/cache")
    @GET
    public StringBuilder getLookupCacheStatus(@Context HttpServletRequest request,@QueryParam("product") String product);
	
	
	@Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
    @Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
    @Path("ping")
    @GET
    public String ping();
	
	@Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
    @Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
    @Path("/lookupResponseCache")
	@POST
    public StringBuilder getLookupResponseCache(@Context HttpServletRequest request);
	
}
