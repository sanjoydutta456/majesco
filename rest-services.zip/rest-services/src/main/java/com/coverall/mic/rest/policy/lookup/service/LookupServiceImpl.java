package com.coverall.mic.rest.policy.lookup.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import org.apache.commons.io.IOUtils;
import org.codehaus.jackson.map.ObjectMapper;

import com.coverall.el.Expression;
import com.coverall.el.FunctionResolver;
import com.coverall.el.VariableResolver;
import com.coverall.el.function.DefaultFunctionResolver;
import com.coverall.exceptions.ELException;
import com.coverall.exceptions.ELParseException;
import com.coverall.mic.rest.policy.api.exception.APIException;
import com.coverall.mic.rest.policy.api.service.constant.APIConstant;
import com.coverall.mic.rest.policy.api.service.model.common.Message;
import com.coverall.mic.rest.policy.lookup.model.LookupObjectArray;
import com.coverall.mic.rest.policy.lookup.model.LookupRequest;
import com.coverall.mic.rest.policy.lookup.model.LookupResponse;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.el.variable.VariableResolverImpl;
import com.coverall.mt.http.User;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.DOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.pctv2.server.cache.LookupCacheLoader;
import com.coverall.pctv2.server.cache.LookupEnhancedCacheLoader;
import com.coverall.pctv2.server.yaml.generation.LookupBean;
import com.coverall.pctv2.server.yaml.generation.LookupRequestParameters;
import com.coverall.pctv2.server.yaml.generation.LookupResponseParameters;
import com.coverall.pctv2.server.yaml.generation.YAMLConstants;
import com.coverall.pctv2.server.yaml.generation.YAMLGenUtil;
import com.coverall.util.DBUtil;
import com.coverall.util.GeneralUtil;

import oracle.ias.cache.CacheAccess;

public class LookupServiceImpl implements LookupService{

	private LookupBean currentLookupBean=null;
	private final String DISPLAY_ORDER="DisplayOrder";
	private final String HEADING="Heading";
	protected final String DISTINCT_CONDITION="SELECT  /*+ CURSOR_SHARING_EXACT */ * FROM (";
	protected final String DEFAULT_SORT_CONDITION=" ORDER BY 1 ASC";
	private final String DUAL_SQUOTE_TOKEN="~`~`~";
	private final String DO_NOT_SUBSTITUTE_DEFAULT="DoNotSubstituteDefault";

	User user;

	@Override
	public Object getLookupData(HttpServletRequest request) throws Exception{
		LookupResponse responseObject=new LookupResponse();
		
		user = User.getUser(request);
		String customerCode=getCustomerCodeFromUser(user).toUpperCase();
		
		//Fetching JSON request as a MAP
		ObjectMapper mapper = null;
		String inputJson = null;
		LookupRequest lookupRequestParameters = null;
		HashMap<String,String> inputParametersCopy=null;
		String keyForLookup = null;
		String productCode = null;
		Boolean isLookupCachingOn = false;
		try{
			mapper=new ObjectMapper();
			inputJson=IOUtils.toString(request.getInputStream(), "UTF-8");
			lookupRequestParameters=mapper.readValue(inputJson, LookupRequest.class);
			inputParametersCopy=new HashMap<String, String>();
		}catch(Exception exp){
			String errMsg = "Invalid JSON. Error while decoding input JSON file";
			WebServiceLoggerUtil.logError("LookupService","getLookupData",errMsg, new Object[] { inputJson},exp);
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,exp);
		}
		
		//Preparing copy for input params in order to have them worked
		for(String paramName:lookupRequestParameters.getParams().keySet()){
			inputParametersCopy.put(paramName, lookupRequestParameters.getParams().get(paramName));
		}
		
		boolean doNotSubstituteDefault=false;
		if(null!=inputParametersCopy.get(DO_NOT_SUBSTITUTE_DEFAULT) && "Y".equalsIgnoreCase(inputParametersCopy.get(DO_NOT_SUBSTITUTE_DEFAULT))) {
			doNotSubstituteDefault=true;
		}

		String cachedlookupId=null;
		if(inputParametersCopy.size()>0 && inputParametersCopy.containsKey("LookupId")){
			cachedlookupId=inputParametersCopy.get("LookupId");
		}else{
			String errMsg = "LookupId is missing from request. This is a required parameter.";
			WebServiceLoggerUtil.logError("LookupService","getLookupData",errMsg, new Object[] { inputJson},null);
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}

		if(verifyIfLookupExistInCache(customerCode,cachedlookupId)){
			//Preparing Response object
			//1.Caching changes start
			//UUID uuidForLookup=null;
			String lookupEnhancedProperty = CustomerConfigUtil.getInstance().getCustomerProperty(user.getDomain(), ServletConfigUtil.COMPONENT_FRAMEWORK, CustomerConfigUtil.LOOKUP_RESPONSE_CACHE);
			if("true".equalsIgnoreCase(lookupEnhancedProperty)){
				isLookupCachingOn = true;
				String overrideLookupResponseData = request.getHeader("overrideLookupResponseData");
				TreeMap<String, String> sortedMap = new TreeMap<String, String>(); 
				sortedMap.putAll(lookupRequestParameters.getParams());
				StringBuilder sortedParamString=new StringBuilder();
				for(String paramName:sortedMap.keySet()){
					sortedParamString.append(paramName+"~"+sortedMap.get(paramName)+",");
				}
				keyForLookup = cachedlookupId+"_"+sortedParamString.toString();
				if(null != inputParametersCopy && inputParametersCopy.containsKey("ProductCode")){
					productCode = inputParametersCopy.get("ProductCode");
				}
				if(null == productCode || productCode.isEmpty()){
					productCode = currentLookupBean.getProductCode();
				}
				if(null == productCode || productCode.isEmpty()){
					productCode = "OTHER";
				}
				LookupResponse cachedResponseObject = (LookupResponse) LookupEnhancedCacheLoader.get(currentLookupBean.getCustomerCode(), productCode, keyForLookup);
				if(null != cachedResponseObject && !"Y".equals(overrideLookupResponseData)){
					return cachedResponseObject;
				}
			}
			ArrayList<Map<String, String>> dataList=new ArrayList<Map<String, String>>();
			
			//Column data for lookup
			Map<String,Map<String,String>> headerMap=new HashMap<String, Map<String,String>>();
			//headerList.add(headerMap);
			responseObject.setHeader(headerMap);

			//data for lookup
			responseObject.setData(dataList);

			//Preparing query
			LookupBean lookupBean=currentLookupBean;

			//Checking if all required parameters are present in the request or not
			String listOfMissingParams="";


			for(LookupRequestParameters requestParam:lookupBean.getRequestParameters()){
				if("true".equalsIgnoreCase(requestParam.getIsRequired())){
					if(!requestParam.getParameterName().equalsIgnoreCase("LookupId") && !requestParam.getParameterSpecifics().equalsIgnoreCase("Special Array Object")){
						if(!inputParametersCopy.containsKey(requestParam.getParameterName()) || inputParametersCopy.get(requestParam.getParameterName())==null
								|| inputParametersCopy.get(requestParam.getParameterName()).equalsIgnoreCase("")){
							listOfMissingParams+=requestParam.getParameterName()+", ";
						}
					}else if(requestParam.getParameterSpecifics().equalsIgnoreCase("Special Array Object")){
						boolean objectArrayPresent=false;
						Map<String,LookupObjectArray> listOfObjects=lookupRequestParameters.getComplexParams();
						if(listOfObjects!=null && listOfObjects.size()>0){
							if(listOfObjects.containsKey(requestParam.getParameterName())){
								if(listOfObjects.get(requestParam.getParameterName())!=null && listOfObjects.get(requestParam.getParameterName()).getData()!=null && 
										listOfObjects.get(requestParam.getParameterName()).getData().size()>0){
									objectArrayPresent=true;
									continue;
								}

							}
						}
						if(!objectArrayPresent){
							listOfMissingParams+=requestParam.getParameterName()+",";
						}
					}
				}else if("false".equalsIgnoreCase(requestParam.getIsRequired()) && !inputParametersCopy.containsKey(requestParam.getParameterName())){
					if(!doNotSubstituteDefault) {
					    inputParametersCopy.put(requestParam.getParameterDisplayValue(), requestParam.getDefaultValue());
					}else {
						inputParametersCopy.put(requestParam.getParameterDisplayValue(), null);	
					}
				}
			}
			
			if(inputParametersCopy.containsKey("CustomPackVersion") || inputParametersCopy.containsKey("ProductVersion")){
				if(!inputParametersCopy.containsKey("ProductCode") && !listOfMissingParams.contains("ProductCode")){
					listOfMissingParams+="ProductCode"+",";
				}
			}
			
			if(!listOfMissingParams.equalsIgnoreCase("")){
				
				String errMsg = "One or more required parameters are missing (or null/empty) in request : "+listOfMissingParams.substring(0, listOfMissingParams.length()-2);
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				WebServiceLoggerUtil.logError("LookupService","getLookupData",errMsg, new Object[] { inputJson},null);
				String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
			
			
			preProcessInputParameters(inputParametersCopy,customerCode);

			String cachedLookupQuery=lookupBean.getQueryExpression();
			
			WebServiceLoggerUtil.logInfo("LookupService", "getLookupData", "Lookup parameters: ", new Object[] { cachedLookupQuery, inputParametersCopy, (lookupBean.getDlsExpressions()) });
			
			Map<String, Object> mapSQL = substituteRequestParametersInQuery(cachedLookupQuery,inputParametersCopy,lookupBean,lookupRequestParameters,lookupBean.getDlsExpressions());
			
			String updateLookupQuery=DISTINCT_CONDITION+ (String.valueOf(mapSQL.get("QUERY"))) +")"+DEFAULT_SORT_CONDITION;
			
			List<String> bindVariableList = (List<String>) (mapSQL.get("VARIABLE"));

			//From the cached lookup bean populating all column headers
			if(lookupBean.getResponseParameters()!=null && lookupBean.getResponseParameters().size()>0){
				for(LookupResponseParameters responseParam:lookupBean.getResponseParameters()){
					HashMap<String, String> property=new HashMap<String, String>();
					property.put(DISPLAY_ORDER, responseParam.getDisplayOrder());
					property.put(HEADING, responseParam.getDisplayHeader());
					headerMap.put(responseParam.getParamDisplayName(),property);
				}
			}else{
				String errMsg = "Lookup can't be decoded. This is a special lookup which is not yet implemented";
				WebServiceLoggerUtil.logError("LookupService","getLookupData",errMsg, new Object[] { inputJson},null);
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}
			//Firing Database Query for getting data section
			Connection conn = null;
			PreparedStatement ps=null;
			ResultSet rs=null;
			try {
				conn=ConnectionPool.getConnection(user);
				ps=conn.prepareStatement(updateLookupQuery);
				
				if (null != bindVariableList) {
					GeneralUtil.bindVariablesToStatement(bindVariableList, ps, 0);
				}
				
				rs=ps.executeQuery();
				ResultSetMetaData rsMetaData=rs.getMetaData();
				//boolean headerPopulated=false;
				WebServiceLoggerUtil.logInfo("LookupService", "getLookupData", "Lookup query executed successfully:", new Object[] { "SQL: ", updateLookupQuery, "Variables: ", bindVariableList });
				
				while(rs.next()){
					Map<String,String> dataMap=new HashMap<String, String>();
					for(int i=1;i<=rsMetaData.getColumnCount();i++){
						dataMap.put(YAMLGenUtil.getFormattedParamNamesInCamelCases(rsMetaData.getColumnName(i)), rs.getString(rsMetaData.getColumnName(i)));
					}
					dataList.add(dataMap);
				}
			} catch (Exception e) {
				String errMsg = "Lookup query execution failed. Error while execuing lookup expression :"+e.getLocalizedMessage();
				List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
				String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
				WebServiceLoggerUtil.logError("LookupService", "getLookupData", "Exception occurred while executing lookup query:", new Object[] { updateLookupQuery, bindVariableList, cachedLookupQuery, inputParametersCopy, (lookupBean.getDlsExpressions()) }, e);
				throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
			}finally{
				try {
					DBUtil.close(rs, ps, conn);
				} catch (SQLException e) {
					//Not needed
				}
			}
		}else{
			String errMsg = "Lookup not found. Please verify LookupId "+cachedlookupId+" in YAML file";
			WebServiceLoggerUtil.logError("LookupService","getLookupData",errMsg, new Object[] { inputJson},null);
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,null);
		}
		if(isLookupCachingOn){
			LookupEnhancedCacheLoader.put(currentLookupBean.getCustomerCode(), productCode, keyForLookup, responseObject);
		}
		return responseObject;

	}
	
	@Override
	public String ping() {
		return "Working";
	}

	protected Map<String, Object> substituteRequestParametersInQuery(String cachedLookupQuery,Map<String,String> inputParametersCopy,LookupBean bean,LookupRequest lookupRequestParameter, String dlsExpression){
		String bindVariableIdentifier = String.valueOf(System.currentTimeMillis());
		Map<String, String> parameterMap = new HashMap<String, String>();
		
		try {
			//Resolving issue with double quotes
			if(cachedLookupQuery.contains("''")){
				cachedLookupQuery=cachedLookupQuery.replace("''", DUAL_SQUOTE_TOKEN);
			}
			
			//Removing all comments of type -- from query
			Matcher matchCommentExp = Pattern.compile("--(.*?)\r",Pattern.DOTALL).matcher(cachedLookupQuery);
			cachedLookupQuery=matchCommentExp.replaceAll("");
			
			//Resolving loop expression
			//CP, TABLE: these will be converted to a SELECT FROM DUAL QUERY
			
			if(cachedLookupQuery.contains(YAMLConstants.lookupLoopidentifier)){

				Matcher matchLoopExp = Pattern.compile("(.*?)\\"+YAMLConstants.lookupLoopidentifier+"_(.*?):(.*?)WHERE(.*?)\\](.*?)",Pattern.DOTALL).matcher(cachedLookupQuery);

				while (matchLoopExp.find()) {
					String whereClause="WHERE"+matchLoopExp.group(4);
					StringBuilder newLoopExpressionQuery=new StringBuilder();
					Map<String,LookupObjectArray> listOfObjects=lookupRequestParameter.getComplexParams();
					String subQuery=matchLoopExp.group(3);
					boolean useDefault=false;
					if(listOfObjects!=null && listOfObjects.size()>0){
						LookupObjectArray objectData=listOfObjects.get(YAMLConstants.lookupLoopArray+YAMLConstants.Delimiter_Underscore+matchLoopExp.group(2));
						if(objectData!=null && objectData.getData().size()>0){
							for(int i=0;i<objectData.getData().size();i++){
								Map<String,String> dataRow=objectData.getData().get(i);

								for(String paramName:dataRow.keySet()){
									if(dataRow.get(paramName)!=null && !dataRow.get(paramName).equalsIgnoreCase("")){
										parameterMap.put((bindVariableIdentifier + "|" + paramName + "|" + bindVariableIdentifier), (dataRow.get(paramName)));
										
										String paramValue="'"+dataRow.get(paramName)+"'";
										subQuery=subQuery.replace(YAMLConstants.lookupParamidentifier+paramName+"}", (bindVariableIdentifier + "|" + paramName + "|" + bindVariableIdentifier));
									}else{
										if(dataRow.get(paramName)==null){
											subQuery=subQuery.replace(YAMLConstants.lookupParamidentifier+paramName+"}","null");	
										}else{
										 subQuery=subQuery.replace(YAMLConstants.lookupParamidentifier+paramName+"}", DUAL_SQUOTE_TOKEN);
										}
									}
								}
								newLoopExpressionQuery.append(subQuery+whereClause);
								if(i<objectData.getData().size()-1){
									newLoopExpressionQuery.append(" UNION ");
								}
								subQuery=matchLoopExp.group(3);
							}
						}else{
							useDefault=true;
						}
					}else{
						useDefault=true;
					}

					if(useDefault){
						Matcher matchLookupParam = Pattern.compile("(.*?)\\"+YAMLConstants.lookupParamidentifier+"(.*?)\\}(.*?)").matcher(subQuery);
						ArrayList<String> listOfParams=new ArrayList<String>();
						while (matchLookupParam.find()) {
							listOfParams.add(matchLookupParam.group(2));
						}
						for(String paramName:listOfParams){
							subQuery=subQuery.replace(YAMLConstants.lookupParamidentifier+paramName+"}", "'NA'");
						}
						//newLoopExpressionQuery.append(subQuery+ whereClause+" AND 1=2");
						newLoopExpressionQuery.append(subQuery+ whereClause);
					}
					cachedLookupQuery.contains(YAMLConstants.lookupLoopidentifier+YAMLConstants.Delimiter_Underscore+matchLoopExp.group(2)+":"+matchLoopExp.group(3)+whereClause+"]");
					cachedLookupQuery=cachedLookupQuery.replace(YAMLConstants.lookupLoopidentifier+YAMLConstants.Delimiter_Underscore+matchLoopExp.group(2)+":"+matchLoopExp.group(3)+whereClause+"]", newLoopExpressionQuery.toString()); 

				}

			}

			//Getting all parameters from the cache query
			HashSet<String> queryParameters = new HashSet<String>();
			//Replacing parameters
			Matcher m = Pattern.compile("(.*?)\\"+YAMLConstants.lookupParamidentifier+"(.*?)\\}(.*?)").matcher(cachedLookupQuery);
			while (m.find()) {
				queryParameters.add(m.group(2));
			}

			//Replacing that in the cached query from the input parameters
			for(String paramName:queryParameters){
				if(inputParametersCopy.containsKey(paramName)){
					String paramValue="'"+inputParametersCopy.get(paramName)+"'";
					if(inputParametersCopy.get(paramName)==null){
						cachedLookupQuery=cachedLookupQuery.replace(YAMLConstants.lookupParamidentifier+paramName+"}", "null");
					}else if (inputParametersCopy.get(paramName).equalsIgnoreCase("")){
						cachedLookupQuery=cachedLookupQuery.replace("'"+YAMLConstants.lookupParamidentifier+paramName+"}"+"'", DUAL_SQUOTE_TOKEN);
						cachedLookupQuery=cachedLookupQuery.replace(YAMLConstants.lookupParamidentifier+paramName+"}", DUAL_SQUOTE_TOKEN);
					}else{
						parameterMap.put((bindVariableIdentifier + "|" + paramName + "|" + bindVariableIdentifier), (inputParametersCopy.get(paramName)));
						
						cachedLookupQuery=cachedLookupQuery.replace(YAMLConstants.lookupParamidentifier+paramName+"}", (bindVariableIdentifier + "|" + paramName + "|" + bindVariableIdentifier)); 
					}
				}
			}
		} catch (Exception e) {
			String errMsg = "Lookup query creation failed. Error while creating lookup expression : ";
			
			if (("Veracode - Invalid Input Value: Input contains a Single Quote").equalsIgnoreCase(e.getLocalizedMessage())) {
				errMsg = errMsg + "Invalid Input value found";
			}
			
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
			WebServiceLoggerUtil.logError("LookupService", "getLookupData", "Exception occurred while creating lookup query", new Object[] {}, e);
			throw new APIException(httpStatusCode, APIConstant.FAILED, errorMessageList, null);
		}

		//Replacing all '' quotes with single quote

		String decodedQuery=cachedLookupQuery.replace("''", "'");
		decodedQuery=decodedQuery.replace(DUAL_SQUOTE_TOKEN, "''");
		decodedQuery=decodedQuery.replace("'null'", "null");
		if(dlsExpression!=null){
			String resolvedDLSExpression=resolveDLSExpression(dlsExpression);
			decodedQuery+=resolvedDLSExpression;
		}
		
		List<String> bindVariableList = GeneralUtil.generateBindVariableList(parameterMap, decodedQuery);
		
		if (null != bindVariableList) {
			for (int index = 0; index < (bindVariableList.size()); index++) {
				if ("null".equalsIgnoreCase(bindVariableList.get(index))) {
					bindVariableList.set(index, null);
				}
			}
		}
		
		for (String key : (parameterMap.keySet())) {
			decodedQuery = decodedQuery.replace(key, "?");
		}
		
		decodedQuery = decodedQuery.replace("'?'", "?");
		
		Map<String, Object> mapSQL = new HashMap<String, Object>();
		
		mapSQL.put("QUERY", decodedQuery);
		mapSQL.put("VARIABLE", bindVariableList);

		return mapSQL;
	}

	private String getCustomerCodeFromUser(User user){ 
		final CustomerConfigUtil ccu = CustomerConfigUtil.getInstance();
		String domain = user.getDomain();
		return ccu.getCustomerCode(domain);
	}

	private boolean verifyIfLookupExistInCache(String customerCode,String lookupId){
		if(customerCode!=null && lookupId!=null){
			String lookupKey=(customerCode+"_"+lookupId).toUpperCase();

			CacheAccess lookupRegion;
			try {
				lookupRegion = CacheAccess.getAccess(LookupCacheLoader.LOOKUP_CACHE_REGION);
				currentLookupBean=(LookupBean) lookupRegion.get(lookupKey);
				if(currentLookupBean!=null){
					return true;
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}

	public String verifyIfCacheGenerationTaskCompleted(String customerCode,String productCode){
		String responseFromCacheLoader=LookupCacheLoader.verifyIfLookupCacheLoadingTaskCompleted(customerCode, productCode);
		return responseFromCacheLoader;

	}

	public String resolveDLSExpression(String dlsExpressionString){
		String resolvedExpression=""; 
		HashMap variableMap = new HashMap();
		variableMap.put(VariableResolverImpl.USER_PARAMETER, user);
		variableMap.put(VariableResolverImpl.SESSION_PARAMETER, user);

		try {
			VariableResolver varResolver = new VariableResolverImpl(variableMap);
			FunctionResolver funcResolver = new DefaultFunctionResolver();

			HashMap expressionMap = new HashMap();


			Expression exp=null;

			exp = new Expression(
					dlsExpressionString,
					null,
					null,
					varResolver,
					funcResolver,
					DOMUtil.GET_MAPDIRECTION,
					expressionMap,
					true);
			resolvedExpression=exp.getValue();
		} catch (ELParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ELException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return resolvedExpression;
	}
	
	private List<Message> getErrorMessageList(List<String> strMessages)	{
		if(strMessages == null)	{
			return null;
		}
		List<Message> errorMessageList = new ArrayList<Message>(strMessages.size());
		for(String aMsg : strMessages)	{
			Message message = new Message();
			message.setMoreinfo(aMsg);
			errorMessageList.add(message);
		}
		return errorMessageList;
	}

	@Override
	public StringBuilder getLookupCacheStatus(HttpServletRequest request,String productCode) {
		StringBuilder responseString=new StringBuilder();
		user = User.getUser(request);
		String customerCode=getCustomerCodeFromUser(user).toUpperCase();
		//Verify if Cache Generation Task completed or not
		String responseFromCacheLoader=verifyIfCacheGenerationTaskCompleted(customerCode,productCode);
		responseString.append(responseFromCacheLoader);
		if(!responseFromCacheLoader.equalsIgnoreCase(LookupCacheLoader.CACHE_COMPLETED)){
			String issueWithCache="";
			if(responseFromCacheLoader.equalsIgnoreCase(LookupCacheLoader.CACHE_NOT_AVAILABLE)){
				issueWithCache="Cache not available for product "+productCode+". Please verify if product is loaded on startup and Microservice option is enabled for it.";
			}else if(responseFromCacheLoader.equalsIgnoreCase(LookupCacheLoader.CACHE_NOT_STARTED)){
				issueWithCache="Caching in Progress for "+productCode+" product. Please try after sometime";
			}else if(responseFromCacheLoader.startsWith(LookupCacheLoader.CACHE_IN_PROGRESS)){
				issueWithCache="Caching in Progress. Please try after sometime";
			}else if(responseFromCacheLoader.equalsIgnoreCase(LookupCacheLoader.CACHE_FAILED)){
				issueWithCache="Lookup Caching failed for "+productCode+".";
			}
			responseString.append(": "+issueWithCache);
		}
		return responseString;
	}
	
	private void preProcessInputParameters(HashMap<String, String> inputParametersCopy, String customerCode){
		String productCode=inputParametersCopy.get("ProductCode")==null?"":inputParametersCopy.get("ProductCode");
		String keyForVersion=(customerCode+"_"+productCode).toUpperCase();
		if(inputParametersCopy.containsKey("CustomPackVersion")){
		 String value=YAMLConstants.customPackVersionMap.get(keyForVersion);
		 inputParametersCopy.put("CustomPackVersion", value);	
		}
		if(inputParametersCopy.containsKey("ProductVersion")){
			String value=YAMLConstants.productVersionMap.get(keyForVersion);
			inputParametersCopy.put("ProductVersion", value);
		}
	}

	@Override
	public StringBuilder getLookupResponseCache(HttpServletRequest request) {
		StringBuilder responseString=new StringBuilder();
		user = User.getUser(request);
		String customerCode= getCustomerCodeFromUser(user).toUpperCase();
		//Verify if Cache Generation Task completed or not
		//Fetching JSON request as a MAP
		ObjectMapper mapper = null;
		String inputJson = null;
		LookupRequest lookupRequestParameters = null;
		Boolean shouldRemoveCache = false;
		Boolean shouldKeepOldCacheFiles = false;
		List<String> productCodeList = null;
		try{
			mapper=new ObjectMapper();
			inputJson=IOUtils.toString(request.getInputStream(), "UTF-8");
			lookupRequestParameters=mapper.readValue(inputJson, LookupRequest.class);
		}catch(Exception exp){
			String errMsg = "Invalid JSON. Error while decoding input JSON file";
			List <Message> errorMessageList = getErrorMessageList(Collections.singletonList(errMsg));
			String httpStatusCode = String.valueOf(Response.Status.BAD_REQUEST.getStatusCode());
			throw new APIException(httpStatusCode, APIConstant.FAILED,errorMessageList,exp);
		}
		for(String paramName:lookupRequestParameters.getParams().keySet()){
			if("removeCache".equals(paramName) && "Y".equals(lookupRequestParameters.getParams().get(paramName))){
				shouldRemoveCache = true;
			}
			if("productCode".equals(paramName) && null != lookupRequestParameters.getParams().get(paramName)){
				productCodeList = 
						new  ArrayList<String>(Arrays.asList(lookupRequestParameters.getParams().get(paramName).split(",")));
			}
			if("keepOldCacheFiles".equals(paramName) && "Y".equals(lookupRequestParameters.getParams().get(paramName))){
				shouldKeepOldCacheFiles = true;
			}
		}
		if(shouldRemoveCache){
			if(null == productCodeList || productCodeList.isEmpty()){
				LookupEnhancedCacheLoader.renameCacheFiles(customerCode, !shouldKeepOldCacheFiles);
				responseString.append(" Reponse cached data for Lookup Service is refreshed all product.");
			}else {
				for(String productCode: productCodeList){
					LookupEnhancedCacheLoader.renameCacheFiles(customerCode, productCode, !shouldKeepOldCacheFiles);
					responseString.append(" Reponse cached data for Lookup Service is refreshed for product " + productCode + ".");
				}
			}
		}
		return responseString;
	}
	
}
