package com.coverall.mic.rest.policy.service;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.coverall.mic.rest.policy.service.model.BTISRSNotifyRequest;
import com.coverall.mic.rest.policy.service.model.BTISRSNotifyResponse;

@Path("/BTISRSNotifyService/")
@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
public interface BTISRSNotifyService extends SupportsPing {

	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Path("process")
	@POST
	public BTISRSNotifyResponse processRequest(BTISRSNotifyRequest request);

	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Path("ping")
	@GET
	public boolean ping();
}
