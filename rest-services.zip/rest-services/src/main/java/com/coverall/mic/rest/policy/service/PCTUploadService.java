package com.coverall.mic.rest.policy.service;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.coverall.mic.rest.policy.service.model.PCTRSUploadRequest;
import com.coverall.mic.rest.policy.service.model.PCTRSUploadResponse;

@Path("/PCTRSUploadService/")
@Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
public interface PCTUploadService extends SupportsPing{

	@Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
    @Path("process")
    @POST
	public PCTRSUploadResponse processRequest(PCTRSUploadRequest request) ;

    @Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
    @Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
    @Path("ping")
    @GET
    public boolean ping();

    @Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
    @Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
    @Path("getPolicyData")
    @POST
    public PCTRSUploadResponse getPolicyData(PCTRSUploadRequest pctrsUploadRequest);


}
