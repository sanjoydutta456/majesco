package com.coverall.mic.rest.policy.service;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.coverall.mic.rest.policy.service.model.PolicyUTMResponse;

@Path("/")
@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON , MediaType.MULTIPART_FORM_DATA })
@Produces({ MediaType.APPLICATION_JSON , MediaType.MULTIPART_FORM_DATA })
public interface PolicyUTMService extends SupportsPing{
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("GetReferenceDetails")
	@GET
	public PolicyUTMResponse getReferenceDetails(@FormParam("referenceType") String referenceType, @FormParam("policyNumber") String  policyNumber,
			@FormParam("insuredName") String  insuredName, @Context HttpServletRequest request);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("GetContextDetails")
	@GET
	public PolicyUTMResponse getContextDetails(@FormParam("referenceType") String  referenceType,
			@FormParam("referenceNumber") String  referenceNumber, @FormParam("contextType") String  contextType,
			@Context HttpServletRequest request);
	
	
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@Produces({ 
		MediaType.APPLICATION_JSON, 
		MediaType.APPLICATION_XML ,
	    MediaType.MULTIPART_FORM_DATA})
	@Path("GetPolicySpecificAttributes")
	@GET
	public PolicyUTMResponse getPolicySpecificAttributes(@FormParam("referenceType") String  referenceType,
			@FormParam("referenceNumber") String  referenceNumber, @Context HttpServletRequest request);
	
	
    @Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
    @Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
    @Path("ping")
    @GET
    public boolean ping();

}
