package com.coverall.mic.rest.policy.service;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.coverall.mic.rest.policy.service.model.PolicyRSUploadRequest;
import com.coverall.mic.rest.policy.service.model.PolicyRSUploadResponse;

@Path("/PolicyRSUploadService/")
@Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
public interface PolicyUploadService extends SupportsPing{
	@Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
    @Path("processXml")
    @POST
	public PolicyRSUploadResponse processXml(PolicyRSUploadRequest request) ;
	
    @Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
    @Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
    @Path("ping")
    @GET
    public boolean ping();
}
