package com.coverall.mic.rest.policy.service;


public interface SupportsPing {
    public boolean ping();
}
