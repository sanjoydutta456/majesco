package com.coverall.mic.rest.policy.service;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.coverall.mic.rest.policy.service.model.TransactionRequest;
import com.coverall.mic.rest.policy.service.model.TransactionRequestStatus;

@Path("/TransactionProcessorService/")
public interface TransactionProcessorService extends SupportsPing{
    /**
     * Return the boolean value whether the call is successful or not
     *
     * @param transactionRequest
     * @return
     */

    @Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
    @Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
    @Path("process")
    @POST
    public TransactionRequestStatus process(TransactionRequest transactionRequest);

    @Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
    @Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
    @Path("ping")
    @GET
    public boolean ping();

    @Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
    @Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
    @Path("hasBookPermission/{domainName}/{userId}")
    @GET
    public boolean hasBookPermission(@PathParam("domainName") String domainName, @PathParam("userId")String userId);

    @Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
    @Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
    @Path("getTransactionRequestStatus")
    @POST
    public TransactionRequestStatus getTransactionRequestStatus(TransactionRequest transactionRequest);
}
