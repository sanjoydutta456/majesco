package com.coverall.mic.rest.policy.service.filter;

import java.io.IOException;
import java.util.StringTokenizer;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import com.coverall.mt.http.HTTPConstants;
import com.coverall.mt.http.User;
import com.coverall.mt.security.filters.BasicAuthenticationFilterImpl;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.security.authentication.NsNonInteractiveUserCredential;
import com.coverall.security.client.restimpl.noninteractive.NsCasNonInteractiveLogin;
import com.coverall.util.Base64;

public class RestServiceCredentialFilter extends BasicAuthenticationFilterImpl {
	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain filterChain) throws IOException, ServletException {
		
		User user = retrieveBasicCredential(request);
		if(user != null) {
			request.setAttribute(HTTPConstants.PARAM_USER, user);
		} else {
			request.removeAttribute(HTTPConstants.PARAM_USER);
		}
		
		filterChain.doFilter(request, response);
	}

	private User retrieveBasicCredential(ServletRequest request)  {
		User user = null;
		HttpServletRequest httpServletRequest = (HttpServletRequest)request;
		String basicAuthorization = httpServletRequest.getHeader(HTTPConstants.HEADER_RS_AUTHORIZATION);
		if(basicAuthorization != null) {
			basicAuthorization = basicAuthorization.replace(HTTPConstants.AUTHORIZATION_TYPE_BASIC, "");
			basicAuthorization = basicAuthorization.trim();
			
	        String usernameAndPassword = null;
	        try {
	            byte[] decodedBytes = Base64.base64ToByteArray(basicAuthorization);
	            usernameAndPassword = new String(decodedBytes, "UTF-8");
	            
	            final StringTokenizer tokenizer = new StringTokenizer(
	                    usernameAndPassword, ":");
	            
	    		final String username = tokenizer.nextToken();
	    		final String password = tokenizer.nextToken();
	    		
	            NsNonInteractiveUserCredential nsNonInteractiveUserCredential = createNonInteractiveUserCredential(
	                    username,
	                    password,
	                    this.casServerLoginUrl,
	                    (this.getService() != null?this.getService(): this.getServerName()));
	            NsCasNonInteractiveLogin.authenticate(nsNonInteractiveUserCredential);
	            user = new User(username, password);
	        } catch (Exception ex) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
						getClass().getName(), "retrieveBasicCredential",
						ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {},
						ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
	        }			
		}
		
		return user;
	}
}
