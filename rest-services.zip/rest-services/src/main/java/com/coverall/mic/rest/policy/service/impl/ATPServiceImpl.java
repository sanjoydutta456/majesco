package com.coverall.mic.rest.policy.service.impl;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;

import org.apache.cxf.jaxrs.ext.MessageContext;

import com.coverall.exceptions.SecurityException;
import com.coverall.mic.rest.policy.service.TransactionProcessorService;
import com.coverall.mic.rest.policy.service.model.TransactionRequest;
import com.coverall.mic.rest.policy.service.model.TransactionRequestStatus;
import com.coverall.mt.http.User;
import com.coverall.mt.security.AdminX;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.pctv2.server.exceptions.EntityNotFoundATPException;
import com.coverall.pctv2.server.service.AutomaticTransactionProcessor;

public class ATPServiceImpl implements TransactionProcessorService {

    @Context
    private MessageContext context;

    @Override
    public TransactionRequestStatus process(TransactionRequest transactionRequest) {
        String sourceEntityType = transactionRequest.getSourceEntityType();
        String sourceEntityReference = transactionRequest.getSourceEntityReference();
        String sourceTransactionName = transactionRequest.getTransactionName();
        String sourceSystem = transactionRequest.getSourceSystem();
        String sourceSystemId = transactionRequest.getSourceSystemId();
        String processingType = transactionRequest.getProcessingType();
        String shouldBook = transactionRequest.getShouldBook();
        String displayPolicyNumber = transactionRequest.getDisplayPolicyNumber();
        String policyRevisionNumber = transactionRequest.getPolicyRevisionNumber();
        Map<String, String> sourceTransParamMap = transactionRequest.getTransParamMap();
        HttpServletRequest request = context.getHttpServletRequest();
        User user = User.getUser(request);
        TransactionRequestStatus transactionRequestStatus = new TransactionRequestStatus();
        String renewalEntityType;
        String renewalEntityReference;
        long workloadJobId = -1;

        LogMinder.getLogMinder().log(
                LogEntry.SEVERITY_INFO,
                getClass().getName(),
                new Exception().getStackTrace()[0].toString(),
                ServletConfigUtil.COMPONENT_PORTAL,
                new Object[] { sourceEntityReference },
                "ATP Rest Service called for process with parmaters i.e. sourceEntityType " + sourceEntityType
                        + " sourceEntityReference " + sourceEntityReference + " sourceTransactionName "
                        + sourceTransactionName + " sourceSystem " + sourceSystem + " sourceSystemId " + sourceSystemId
                        + " processingType " + processingType + " shouldBook " + shouldBook + " displayPolicyNumber "
                        + displayPolicyNumber + " policyRevisionNumber " + policyRevisionNumber + " sourceDomainName "
                        + user.getFullName() + " sourceTransParamMap " + sourceTransParamMap,
                null,
                LogMinderDOMUtil.VALUE_MIC);
        AutomaticTransactionProcessor autoTransProcess = new AutomaticTransactionProcessor();
        try {
            workloadJobId = autoTransProcess.process(
                    sourceEntityType,
                    sourceEntityReference,
                    sourceTransactionName,
                    sourceSystem,
                    sourceSystemId,
                    processingType,
                    shouldBook,
                    displayPolicyNumber,
                    policyRevisionNumber,
                    user,
                    sourceTransParamMap);

            LogMinder.getLogMinder().log(
                    LogEntry.SEVERITY_INFO,
                    getClass().getName(),
                    new Exception().getStackTrace()[0].toString(),
                    ServletConfigUtil.COMPONENT_PORTAL,
                    new Object[] { null },
                    "ATP Rest Service called for process with parmaters i.e. sourceEntityType " + sourceEntityType
                            + " sourceEntityReference " + sourceEntityReference + " sourceTransactionName "
                            + sourceTransactionName + " sourceSystem " + sourceSystem + " sourceSystemId "
                            + sourceSystemId + " processingType " + processingType + " shouldBook " + shouldBook
                            + " displayPolicyNumber " + displayPolicyNumber + " policyRevisionNumber "
                            + policyRevisionNumber + " sourceDomainName " + user.getFullName()
                            + " sourceTransParamMap " + sourceTransParamMap + " has been succussfully completed",
                    null,
                    LogMinderDOMUtil.VALUE_MIC);
            if (workloadJobId != -1) {
                while (true) {
                    HashMap<String, String> mapStatusDetails = autoTransProcess.getCurrentStatus(workloadJobId, user);
                    String status = mapStatusDetails.get("STATUS");
                    String statusDetails = mapStatusDetails.get("STATUS_DETAIL");
                    renewalEntityType = mapStatusDetails.get("ENTITY_TYPE");
                    renewalEntityReference = mapStatusDetails.get("ENTITY_REFERENCE");
                    transactionRequestStatus.setStatusDetails(statusDetails);
                    LogMinder.getLogMinder().log(
                            LogEntry.SEVERITY_FATAL,
                            ATPServiceImpl.class.getName(),
                            new Exception().getStackTrace()[0].toString(),
                            ServletConfigUtil.COMPONENT_PORTAL,
                            new Object[] {},
                            "ATP Process status=" + status + ", statusDetails=" + statusDetails
                            + ", workloadJobId=" + workloadJobId
                            + ", renewalEntityReference=" + renewalEntityReference,
                            null,
                            LogMinderDOMUtil.VALUE_MIC);
                    if (null == status || "FAILED".equals(status) || "COMPLETED".equals(status)) {
                        transactionRequestStatus.setStatus(status);
                        if (null != status && "COMPLETED".equals(status)) {
                            transactionRequestStatus.setSuccessful(true);
                        } else {
                            transactionRequestStatus.setSuccessful(false);
                        }
                        break;
                    }
                    Thread.sleep(20000);
                }
                if (null != renewalEntityReference) {
                    Map<String, String> policyData = autoTransProcess.getPolicyData(
                            renewalEntityType,
                            renewalEntityReference,
                            user);
                    if (null != policyData) {
                        transactionRequestStatus.setPolicyData(policyData);
                    }
                }
            }
        } catch (InterruptedException exe) {
            LogMinder.getLogMinder().log(
                    LogEntry.SEVERITY_FATAL,
                    ATPServiceImpl.class.getName(),
                    new Exception().getStackTrace()[0].toString(),
                    ServletConfigUtil.COMPONENT_PORTAL,
                    new Object[] {},
                    "In side InterruptedException, An error occured during the process from rest webservice for sourceEntityType "
                            + sourceEntityType + " sourceEntityReference " + sourceEntityReference
                            + " sourceTransactionName " + sourceTransactionName + " sourceSystem " + sourceSystem
                            + " sourceSystemId " + sourceSystemId + " processingType " + processingType
                            + " shouldBook " + shouldBook + " displayPolicyNumber " + displayPolicyNumber
                            + " policyRevisionNumber " + policyRevisionNumber + " sourceDomainName "
                            + user.getFullName() + " sourceTransParamMap " + sourceTransParamMap,
                    exe,
                    LogMinderDOMUtil.VALUE_MIC);
            transactionRequestStatus.setErrorMessage(exe.getMessage());
            transactionRequestStatus.setStatusDetails("MIC Server is not responding");
            transactionRequestStatus.setSuccessful(false);
        } catch (Exception exe) {
            LogMinder.getLogMinder().log(
                    LogEntry.SEVERITY_INFO,
                    ATPServiceImpl.class.getName(),
                    new Exception().getStackTrace()[0].toString(),
                    ServletConfigUtil.COMPONENT_PORTAL,
                    new Object[] {},
                    "An error occured during the process from rest webservice for sourceEntityType " + sourceEntityType
                            + " sourceEntityReference " + sourceEntityReference + " sourceTransactionName "
                            + sourceTransactionName + " sourceSystem " + sourceSystem + " sourceSystemId "
                            + sourceSystemId + " processingType " + processingType + " shouldBook " + shouldBook
                            + " displayPolicyNumber " + displayPolicyNumber + " policyRevisionNumber "
                            + policyRevisionNumber + " sourceDomainName " + user.getFullName()
                            + " sourceTransParamMap " + sourceTransParamMap,
                    exe,
                    LogMinderDOMUtil.VALUE_MIC);
            transactionRequestStatus.setErrorMessage(exe.getMessage());
            transactionRequestStatus.setStatusDetails(exe.getMessage());
            transactionRequestStatus.setSuccessful(false);
        }
        return transactionRequestStatus;
    }

    @Override
    public boolean ping() {
        return true;
    }

    @Override
    public boolean hasBookPermission(String domainName, String userId) {
        AdminX adminX = null;
        boolean hasAutoBookPermission = false;

        try {
            adminX = new AdminX();
            hasAutoBookPermission = adminX.hasSubPermission(
                    domainName,
                    userId,
                    AdminX.USER_PRINCIPAL,
                    "Booking?Auto Book");
        } catch (SecurityException se) {
            LogMinder.getLogMinder().log(
                    LogEntry.SEVERITY_FATAL,
                    getClass().getName(),
                    new Exception().getStackTrace()[0].toString(),
                    ServletConfigUtil.COMPONENT_RI,
                    new Object[] {},
                    "In ATP Rest Service, could not obtain permissions for the user:" + userId + "@" + domainName,
                    se,
                    LogMinderDOMUtil.VALUE_MIC);
        }
        return hasAutoBookPermission;
    }

    public TransactionRequestStatus getTransactionRequestStatus(TransactionRequest transactionRequest) {
        TransactionRequestStatus transactionRequestStatus = new TransactionRequestStatus();
        String sourceSystem = transactionRequest.getSourceSystem();
        String sourceSystemId = transactionRequest.getSourceSystemId();
        HttpServletRequest request = context.getHttpServletRequest();
        User user = User.getUser(request);
        if (null == sourceSystem || sourceSystem.isEmpty()) {
            transactionRequestStatus.setStatusDetails("Source System is null or blank, Can't get status for this request");
            transactionRequestStatus.setSuccessful(false);
            return transactionRequestStatus;
        } else if (null == sourceSystemId || sourceSystemId.isEmpty()) {
            transactionRequestStatus.setStatusDetails("Source System Id is null or blank, Can't get status for this request");
            transactionRequestStatus.setSuccessful(false);
            return transactionRequestStatus;
        } else if (null == user) {
            transactionRequestStatus.setStatusDetails("User is null, Can't get status for this request");
            transactionRequestStatus.setSuccessful(false);
            return transactionRequestStatus;
        }

        AutomaticTransactionProcessor autoTransProcess = new AutomaticTransactionProcessor();
        String status;
        String statusDetails;
        String entityType;
        String entityReference;
        try {
            Map<String, String> mapSourceDetails = autoTransProcess.getCurrentStatusForSourceSystem(
                    sourceSystem,
                    sourceSystemId,
                    user);
            if (mapSourceDetails != null) {
                status = mapSourceDetails.get("STATUS");
                statusDetails = mapSourceDetails.get("STATUS_DETAILS");
                entityType = mapSourceDetails.get("ENTITY_TYPE");
                entityReference = mapSourceDetails.get("ENTITY_REFERENCE");

                transactionRequestStatus.setStatus(status);
                transactionRequestStatus.setStatusDetails(statusDetails);
                if (null != status && "COMPLETED".equals(status)) {
                    transactionRequestStatus.setSuccessful(true);
                } else {
                    transactionRequestStatus.setSuccessful(false);
                }

                Map<String, String> policyData = autoTransProcess.getPolicyData(entityType, entityReference, user);
                if (null != policyData) {
                    transactionRequestStatus.setPolicyData(policyData);
                }
            }else{
                LogMinder.getLogMinder().log(
                        LogEntry.SEVERITY_FATAL,
                        ATPServiceImpl.class.getName(),
                        new Exception().getStackTrace()[0].toString(),
                        ServletConfigUtil.COMPONENT_PORTAL,
                        new Object[] {},
                        "Method getCurrentStatusForSourceSystem return null for mapSourceDetails while getting details for source system "
                                + sourceSystem + " and source system id" + sourceSystemId,
                        null,
                        LogMinderDOMUtil.VALUE_MIC);
                transactionRequestStatus.setSuccessful(false);
            }
        } catch (Exception exe) {
        	if(!(exe instanceof EntityNotFoundATPException)){
            LogMinder.getLogMinder().log(
                    LogEntry.SEVERITY_FATAL,
                    ATPServiceImpl.class.getName(),
                    new Exception().getStackTrace()[0].toString(),
                    ServletConfigUtil.COMPONENT_PORTAL,
                    new Object[] {},
                    "An error occured in method getSourceSystemDetails while getting details for source system "
                            + sourceSystem + " and source system id" + sourceSystemId,
                    exe,
                    LogMinderDOMUtil.VALUE_MIC);
	            transactionRequestStatus.setErrorMessage(exe.getMessage());
	            transactionRequestStatus.setStatusDetails(exe.getMessage());
	            transactionRequestStatus.setSuccessful(false);
        	}else	{
        		transactionRequestStatus.setStatus("STOPPED");
                transactionRequestStatus.setErrorMessage("Transaction not found.");
                transactionRequestStatus.setStatusDetails(exe.getMessage());
                transactionRequestStatus.setSuccessful(false);
        		
        	}
        }

        return transactionRequestStatus;
    }

}
