package com.coverall.mic.rest.policy.service.impl;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;

import org.apache.cxf.jaxrs.ext.MessageContext;
import org.apache.cxf.transport.http.AbstractHTTPDestination;

import com.coverall.mic.rest.policy.service.BTISRSNotifyService;
import com.coverall.mic.rest.policy.service.model.BTISRSNotifyRequest;
import com.coverall.mic.rest.policy.service.model.BTISRSNotifyResponse;
import com.coverall.mic.rest.policy.service.model.PCTUploadStatus;
import com.coverall.mt.http.HTTPConstants;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.util.ObjectStringMapper;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.pctv2.server.ws.client.upload.PCTUploadResponse;
import com.coverall.util.Base64;

public class BTISRSNotifyServiceImpl implements BTISRSNotifyService {
	@Context 
	private MessageContext messageContext;
	
	@Override
	public boolean ping() {
		return true;
	}

	@Override
	public BTISRSNotifyResponse processRequest(BTISRSNotifyRequest btisRsNotifyRequest) {
		BTISRSNotifyResponse response = new BTISRSNotifyResponse();
		
		try {
			getUser(messageContext);
			response.setStatus(btisRsNotifyRequest.getStatus());
			response.setStatusCode(btisRsNotifyRequest.getStatusCode());
			response.setErrorMessage(btisRsNotifyRequest.getErrorMessage());
			
			String xmlExtract = btisRsNotifyRequest.getXmlExtract();
			boolean xmlZipped = btisRsNotifyRequest.isXmlZipped();
			
			if(xmlExtract != null) {
				xmlExtract = getDecodedXmlExtract(xmlExtract, xmlZipped);
				btisRsNotifyRequest.setXmlExtract(xmlExtract);
			}
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					getClass().getName(), "process",
					ServletConfigUtil.COMPONENT_PORTAL,
					new Object[] { ObjectStringMapper.convertObjectToXmlString(btisRsNotifyRequest, btisRsNotifyRequest.getClass()) },
					null, null, LogMinderDOMUtil.VALUE_MIC);				
		} catch (Exception ex) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					getClass().getName(), "process",
					ServletConfigUtil.COMPONENT_PORTAL,
					new Object[] {  btisRsNotifyRequest.getEntityReference() },
					ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);			
			response.setStatus(PCTUploadStatus.STATUS_FAILURE);
			response.setStatusCode(PCTUploadResponse.STATUS_OTHER_ERRORS);
			response.setErrorMessage(ex.getMessage());			
		}
		return response;
	}
	
	private User getUser(MessageContext messageContext) throws Exception {
		User user = null;
		if(messageContext != null) {
			HttpServletRequest request = (HttpServletRequest)messageContext.get(AbstractHTTPDestination.HTTP_REQUEST);
			
			if(request != null) {
				user = (User)request.getAttribute(HTTPConstants.PARAM_USER);
			}
		}

		if(user == null) {
			throw new  Exception("Credential is invalid!");
		} else {
			return user;
		}
	}
	
	private String getDecodedXmlExtract(String xmlExtract, boolean isZipped) throws Exception {
		try {
			if(isZipped) {
				return extractZippedPolicyXML(xmlExtract);
			} else {
				return extractPolicyXML(xmlExtract);
			}
			
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	   /**
     * Gets the Base64 decoded policyXML string value for this PCTUploadXmlStringRequest.
     *
     * @return policyXML
     */
	private java.lang.String extractPolicyXML(String xmlExtract) throws Exception {
		
		byte[] base64DecodedArr = Base64.base64ToByteArray(xmlExtract);
		String value = null;
		try {
			value = new String(base64DecodedArr, "UTF-8");
		} catch (Exception e) {
			throw e;
		}
		return value;
	}
	
    /**
     * Gets the decompressed policyXML string value for this PCTUploadXmlZipStringRequest.
     *
     * @return policyXML
     */
    private java.lang.String extractZippedPolicyXML(String xmlExtract) throws Exception {
    	final int BUFFER_SIZE = 4096;
		ZipInputStream zis = null;
		ByteArrayOutputStream output = null;
		String value = null;
	    try {
			byte[] base64DecodedArr = Base64.base64ToByteArray(xmlExtract);
			output = new ByteArrayOutputStream();
			zis = new ZipInputStream(new ByteArrayInputStream(base64DecodedArr));
	        ZipEntry entry = null;
	        final byte[] bytes = new byte[BUFFER_SIZE];
			while ((entry = zis.getNextEntry()) != null) {
			    if (!entry.isDirectory()) {
			    	//get only the first file in the zip stream
	                int count = 0;
	                while ((count = zis.read(bytes, 0, BUFFER_SIZE)) != -1) {
	                    output.write(bytes, 0, count);
	                }
	                output.flush();
	                output.close();
	                value = new String(output.toByteArray(), "UTF-8");
	                break;
			    }
			    zis.closeEntry();
			}
		} catch (IOException e) {
			throw e;
		}
	    if (zis != null) {
	        try {
				zis.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
	    }
	    if (output != null) {
	        try {
				output.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
	    }	    
	    return value;   
    }    	
}
