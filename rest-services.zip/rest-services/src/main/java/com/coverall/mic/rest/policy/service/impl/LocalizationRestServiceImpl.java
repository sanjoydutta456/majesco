package com.coverall.mic.rest.policy.service.impl;

import javax.servlet.http.HttpServletRequest;
import com.coverall.localization.services.api.ILocalizationService;
import com.coverall.mic.rest.policy.service.LocalizationRestService;
import com.coverall.mt.http.User;
import com.coverall.site.framework.api.helper.SpringContextHelper;


public class LocalizationRestServiceImpl implements LocalizationRestService {

	@Override
	public boolean ping() {
		return false;
	}

	@Override
	public String translateText(String q,HttpServletRequest request) {
		try{
			if(q!=null && !q.equalsIgnoreCase("")){

				User userObj=User.getUser(request);	
				ILocalizationService locService = (ILocalizationService)SpringContextHelper.getBean(ILocalizationService.BEAN_ID);

				return locService.localizeText(q, userObj.getLocalizationParams());
			}else{
				return q;
			}
		}catch(Exception exp){
			return q;
		}
	}

}
