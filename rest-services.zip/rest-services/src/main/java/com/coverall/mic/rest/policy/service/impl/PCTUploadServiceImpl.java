package com.coverall.mic.rest.policy.service.impl;

import java.rmi.RemoteException;
import java.util.Map;

import com.coverall.mic.rest.policy.service.PCTUploadService;
import com.coverall.mic.rest.policy.service.model.PCTRSUploadRequest;
import com.coverall.mic.rest.policy.service.model.PCTRSUploadResponse;
import com.coverall.pctv2.server.ws.service.upload.PCTClassicUploadRequest;
import com.coverall.pctv2.server.ws.service.upload.PCTClassicUploadResponse;
import com.coverall.pctv2.server.ws.service.upload.PCTUploadResponse;
import com.coverall.pctv2.server.ws.service.upload.PCTWSUpload;

public class PCTUploadServiceImpl implements PCTUploadService {


	@Override
	public PCTRSUploadResponse processRequest(PCTRSUploadRequest restRequest) {
		PCTClassicUploadRequest request = new PCTClassicUploadRequest();
		request.setEntityReference(restRequest.getEntityReference());
		request.setUserName(restRequest.getUserName());
		request.setPassword(restRequest.getPassword());
		request.setPolicyXML(restRequest.getPolicyXML());
		request.setRetainAuditFieldVals(restRequest.isRetainAuditFieldVals());
		request.setRetainIDVals(restRequest.isRetainIDVals());
		request.setEvaluateAll(restRequest.isEvaluateAll());
		request.setSourceSystem(restRequest.getSourceSystem());
		request.setSourceSystemId(restRequest.getSourceSystemId());
		PCTWSUpload upload = new PCTWSUpload();
		PCTRSUploadResponse pctrsUploadResponse = new PCTRSUploadResponse();
		PCTClassicUploadResponse response = null;
		try {
				response = upload.processClassicConversionRequest(request);
		} catch (RemoteException e) {
			pctrsUploadResponse.setStatusCode(PCTUploadResponse.STATUS_EXCEPTION);
			pctrsUploadResponse.setStatus(PCTUploadResponse.FAILURE);
			pctrsUploadResponse.setErrorMessage(e.getMessage());
			return pctrsUploadResponse;
		}

		pctrsUploadResponse.setErrorMessage(response.getMessage());
		pctrsUploadResponse.setStatus(response.getStatus());
		pctrsUploadResponse.setStatusCode(response.getStatusCode());
		pctrsUploadResponse.setEntityReference(response.getEntityReference());
		return pctrsUploadResponse;
	}

    @Override
    public boolean ping() {
        return true;
    }

    @Override
    public PCTRSUploadResponse getPolicyData(PCTRSUploadRequest pctrsUploadRequest) {
        Map<String,String> plicyDetailsMap = null;

        PCTClassicUploadRequest request = new PCTClassicUploadRequest();
        request.setEntityReference(pctrsUploadRequest.getEntityReference());
        request.setUserName(pctrsUploadRequest.getUserName());
        request.setPassword(pctrsUploadRequest.getPassword());
        request.setEntityType(pctrsUploadRequest.getEntityType());
        PCTRSUploadResponse pctrsUploadResponse = new PCTRSUploadResponse();
        PCTWSUpload upload = new PCTWSUpload();
        try {
            plicyDetailsMap = upload.getPolicyData(request,
                    pctrsUploadRequest.getEntityReference(),pctrsUploadRequest.getEntityType());
            System.out.println();
        } catch (Exception e) {
            pctrsUploadResponse.setErrorMessage(e.getMessage());
        }

        pctrsUploadResponse.setPolicyData(plicyDetailsMap);
        return pctrsUploadResponse;
    }

}
