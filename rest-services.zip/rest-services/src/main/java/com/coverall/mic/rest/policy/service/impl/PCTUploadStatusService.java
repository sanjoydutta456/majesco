package com.coverall.mic.rest.policy.service.impl;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Document;

import com.coverall.licensing.util.LicenseManager;
import com.coverall.mic.rest.policy.dao.PCTUploadStatusDao;
import com.coverall.mic.rest.policy.dao.impl.PCTUploadStatusDaoImpl;
import com.coverall.mic.rest.policy.events.PCTUploadStatusEventProcessor;
import com.coverall.mic.rest.policy.service.model.PCTUploadStatus;
import com.coverall.mt.events.EventProcessorUtility;
import com.coverall.mt.http.User;
import com.coverall.mt.services.SchedulableService;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServicesDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;

public class PCTUploadStatusService extends SchedulableService {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final PCTUploadStatusDao statusDao = PCTUploadStatusDaoImpl.getInstance();
	
	public PCTUploadStatusService() throws RemoteException {}

	@Override
	public String getComponentName() {
		return ServletConfigUtil.COMPONENT_PORTAL;
	}
	
	public Document process(Document request, String logName) throws Throwable {
		ServicesDOMUtil
				.setResponseParameter(request, ServicesDOMUtil.PARAM_STATUS,
						ServicesDOMUtil.VALUE_STATUS_FAIL);

		User user = (User) ServicesDOMUtil.getUser(request);

		/*
		 * Check for MIC - Portal license here. If it is not licensed return
		 * without processing request and log error
		 */
		LicenseManager licenseManager = LicenseManager.getLicenseManager();
        ArrayList<String> customers           = new ArrayList<String>();
        String customerCode           = CustomerConfigUtil.getInstance()
                                                          .getCustomerCode(user.getDomain());
        customers.add(customerCode);
		
        if (licenseManager.isPortalLicensed(customers)) {
        	try {
        		queuePCTUploadStatusEvents(user);
        	} catch (Throwable error) {
                LogMinder.getLogMinder().log(com.coverall.mt.util.LogEntry.SEVERITY_FATAL,
                        getClass().getName(), "process",
                        ServletConfigUtil.COMPONENT_PORTAL,
                        new Object[] { request, logName }, "Error Queuing the pct upload status events.",
                        error, logName);
                throw error;
        	}
        } else {
            LogMinder.getLogMinder().log(com.coverall.mt.util.LogEntry.SEVERITY_INFO,
                    getClass().getName(), "process",
                    ServletConfigUtil.COMPONENT_PORTAL,
                    new Object[] { request, user, customers },
                    "MIC - Portal is not licensed.", null, logName);
                throw new Exception("MIC - Portal is not licensed.");        	
        }
        
		return request;
	}
	
	
	private void queuePCTUploadStatusEvents(User user) throws Exception {
		List<PCTUploadStatus> updatedUploadStatus = statusDao.listUpdatedUploadStatus(user);
		
		for(PCTUploadStatus uploadStatus : updatedUploadStatus) {
			addPCTUploadStatusUpdateEvent(uploadStatus, user);
		}
	}

	private void addPCTUploadStatusUpdateEvent(PCTUploadStatus uploadStatus,
			User user) {
		uploadStatus.setProcess(PCTUploadStatus.PROCESS_STATUS_UPDATE);
		boolean locked = lockUploadStatus(uploadStatus, user);

		if (locked) {
			try {
				String entityType = uploadStatus.getEntityType();
				String entityReference = uploadStatus.getEntityReference();

				EventProcessorUtility
						.deleteCompletedActivity(
								entityType,
								entityReference,
								PCTUploadStatusEventProcessor.EVENT_PCT_UPLOAD_STATUS_UPDATE,
								user);
				EventProcessorUtility
						.addActivity(
								entityType,
								entityReference,
								PCTUploadStatusEventProcessor.EVENT_PCT_UPLOAD_STATUS_UPDATE,
								user);

			} catch (Exception ex) {
				uploadStatus.setStatus(PCTUploadStatus.STATUS_FAILURE);
				unlockUploadStatus(uploadStatus, user);
				LogMinder.getLogMinder().log(
						LogEntry.SEVERITY_FATAL,
						getClass().getName(),
						"addPCTUploadStatusUpdateEvent",
						ServletConfigUtil.COMPONENT_PORTAL,
						new Object[] {},
						ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
			}
		} else {
			LogMinder.getLogMinder().log(
					LogEntry.SEVERITY_FATAL,
					getClass().getName(),
					"addPCTUploadStatusUpdateEvent",
					ServletConfigUtil.COMPONENT_PORTAL,
					new Object[] {},
					"Unable to lock the upload status for  "
							+ uploadStatus.getEntityReference(), null,
					LogMinderDOMUtil.VALUE_MIC);			
		}
	}
	
	private boolean lockUploadStatus(PCTUploadStatus uploadStatus, User user) {
		boolean locked = false;
		
		uploadStatus.setProcess(PCTUploadStatus.PROCESS_STATUS_UPDATE);
		
		try {
			statusDao.lockUploadStatus(uploadStatus, user);
			locked = true;
		} catch(Exception ex) {
			LogMinder.getLogMinder().log(
					LogEntry.SEVERITY_FATAL,
					getClass().getName(),
					"lockUploadStatus",
					ServletConfigUtil.COMPONENT_PORTAL,
					new Object[] {},
					ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
		}
		
		return locked;
	}
	
	
	private void unlockUploadStatus(PCTUploadStatus uploadStatus, User user) {
		try {
			statusDao.unlockUploadStatus(uploadStatus, user);
		} catch(Exception ex) {
			LogMinder.getLogMinder().log(
					LogEntry.SEVERITY_FATAL,
					getClass().getName(),
					"unlockUploadStatus",
					ServletConfigUtil.COMPONENT_PORTAL,
					new Object[] {},
					ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
		}		
	}
}
