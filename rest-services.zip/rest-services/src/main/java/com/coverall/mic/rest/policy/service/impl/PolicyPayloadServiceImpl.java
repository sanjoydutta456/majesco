package com.coverall.mic.rest.policy.service.impl;

import static com.coverall.security.util.constants.SSOConstants.NS_USER;

import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import com.coverall.mic.rest.policy.service.PolicyPayloadService;
import com.coverall.mic.rest.policy.service.model.PolicyPayloadResponse;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.util.CustomXMLFeed;
import com.coverall.mt.utmcache.UTMCache;
import com.coverall.mt.utmcache.UTMCacheProvider;
import com.coverall.util.DBUtil;
import com.coverall.security.authentication.User;

public class PolicyPayloadServiceImpl implements PolicyPayloadService{
	
	@Override
	public PolicyPayloadResponse getPolicyPayload(String entityReference,String entityType, String  eventName, HttpServletRequest request) {
		PolicyPayloadResponse response = null;
		User user = null;
		try {
			user = (User) request.getSession().getAttribute(NS_USER);
			String customerCode=user.getCustomercode();	
			String domain = user.getDomain();
			response = getPolicyPayloadXML(entityReference, entityType , eventName, customerCode, domain);
		} catch (Exception e) {
			response = new PolicyPayloadResponse();
			response.setStatus("Expectation Failed");
			response.setStatusCode(417);
			response.setErrorMessage(e.getMessage());
			return response;
		}
		response.setStatus("OK");
		response.setStatusCode(200);
		response.setErrorMessage("");
		return response;
	}
	
	public PolicyPayloadResponse getPolicyPayloadXML(String entityReference,
            String entityType, String  eventName, String customerCode, String domain) throws Exception {
		PolicyPayloadResponse response = new PolicyPayloadResponse();
    	Connection conn = null;
    	String inputPayload = "";
    	String outputPayload = "";
		CustomXMLFeed xmlPayloadGenerator= new CustomXMLFeed();
        Map<Object, Object> parameters =  new HashMap<Object, Object>();
        inputPayload = getInputPayload(eventName);
    	parameters.put("SORT_ORDER", "DESC");
    	parameters.put("CUSTOMER_CODE", customerCode);
    	parameters.put("ENTITY_REFERENCE", entityReference);
    	parameters.put("PAYLOAD_XML_IN_MEMORY", "true");
    	parameters.put("PAYLOAD_XML", inputPayload);
    	parameters.put("USE_POOL_CONNECTION", "Y");
    	parameters.put("domain", domain);
		try {
			conn = ConnectionPool.getConnection(domain);
			outputPayload = xmlPayloadGenerator.process(parameters, conn);
			response.setPolicyPayloadXML(outputPayload);
		} catch (Exception ex) {
				ex.printStackTrace();
				throw ex;
		} finally {
				try {
					DBUtil.close(conn);
				} catch (Exception ex) {
					ex.printStackTrace();
					// suppress
				}
		}
		return response;
	}
	
	private String getInputPayload(String eventName) {
		String payloadInputXML = null;
		UTMCacheProvider utmCacheProvider = new UTMCacheProvider();
		UTMCache utmCache = utmCacheProvider.getUTMCacheObject();
		payloadInputXML = utmCache.getPayloadXML(eventName);
		return payloadInputXML;
	}
	
	@Override
	public boolean ping() {
		return false;
	}	
}
