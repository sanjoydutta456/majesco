package com.coverall.mic.rest.policy.service.impl;

import static com.coverall.security.util.constants.SSOConstants.NS_USER;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import com.coverall.mic.rest.policy.service.PolicyUTMService;
import com.coverall.mic.rest.policy.service.model.PolicyUTMResponse;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.security.authentication.User;
import com.coverall.util.DBUtil;

public class PolicyUTMServiceImpl implements PolicyUTMService{

	@Override
	public PolicyUTMResponse getReferenceDetails(String referenceType, String policyNumber, 
			String insuredName, HttpServletRequest request) {
		PolicyUTMResponse response = null;
		User user = null;
		if(referenceType == null) {
			response =  new PolicyUTMResponse();
			response.setStatus("Input Validation Failed");
			response.setStatusCode(417);
			response.setErrorMessage("Invalid referenceType.");
			return response;
		}
		if(policyNumber == null && insuredName == null) {
			response =  new PolicyUTMResponse();
			response.setStatus("Input Validation Failed");
			response.setStatusCode(417);
			response.setErrorMessage("Invalid policyNumber or insuredName.");
			return response;
		}
		try {
			user = (User) request.getSession().getAttribute(NS_USER);
			String domain = user.getDomain();
			response = getPolicyReferenceDetails(referenceType, policyNumber, insuredName, domain);
		} catch (Exception e) {
			response =  new PolicyUTMResponse();
			response.setStatus("Expectation Failed");
			response.setStatusCode(417);
			response.setErrorMessage(e.getMessage());
			return response;
		}
		response.setStatus("OK");
		response.setStatusCode(200);
		response.setErrorMessage("");
		return response;
	}

	@Override
	public PolicyUTMResponse getContextDetails(String referenceType, String referenceNumber, 
			String contextType, HttpServletRequest request) {
		PolicyUTMResponse response = null;
		User user = null;
		
		if(referenceType == null || referenceNumber == null) {
			response =  new PolicyUTMResponse();
			response.setStatus("Input Validation Failed");
			response.setStatusCode(417);
			response.setErrorMessage("Invalid referenceType or referenceNumber.");
			return response;
		}

		if(contextType == null || !"Transaction number".equalsIgnoreCase(contextType)) {
			response =  new PolicyUTMResponse();
			response.setStatus("Input Validation Failed");
			response.setStatusCode(417);
			response.setErrorMessage("Invalid contextType.");
			return response;
		}
		
		try {
			user = (User) request.getSession().getAttribute(NS_USER);
			String domain = user.getDomain();
			response = getPolicyContextDetails(referenceType, referenceNumber, contextType, domain);
		} catch (Exception e) {
			response = new PolicyUTMResponse();
			response.setStatus("Expectation Failed");
			response.setStatusCode(417);
			response.setErrorMessage(e.getMessage());
			return response;
		}
		response.setStatus("OK");
		response.setStatusCode(200);
		response.setErrorMessage("");
		return response;
	}
	
	@Override
	public PolicyUTMResponse getPolicySpecificAttributes(String referenceType, String referenceNumber, 
			HttpServletRequest request) {
		PolicyUTMResponse response = null;
		User user = null;
		if(referenceType == null || referenceNumber == null) {
			response =  new PolicyUTMResponse();
			response.setStatus("Input Validation Failed");
			response.setStatusCode(417);
			response.setErrorMessage("Invalid referenceType or referenceNumber.");
			return response;
		}
		try {
			user = (User) request.getSession().getAttribute(NS_USER);
			String domain = user.getDomain();
			response = getPolicySpecificAttributes(referenceType, referenceNumber, domain);
		} catch (Exception e) {
			response = new PolicyUTMResponse();
			response.setStatus("Expectation Failed");
			response.setStatusCode(417);
			response.setErrorMessage(e.getMessage());
			return response;
		}
		response.setStatus("OK");
		response.setStatusCode(200);
		response.setErrorMessage("");
		return response;
	}
	
	@Override
	public boolean ping() {
		return false;
	}

	private PolicyUTMResponse getPolicyReferenceDetails(String referenceType, 
			String policyNumber, String insuredName, String domain) throws Exception {
		if("SUBMISSION".equalsIgnoreCase(referenceType)) {
			PolicyUTMResponse response = getSubmissionReferenceDetails(referenceType, 
					policyNumber, insuredName, domain);
			return response;
		}
		Connection conn = null;
		PreparedStatement ps = null;
		String sql = null;
		ResultSet rs = null;
		PolicyUTMResponse response =  new PolicyUTMResponse();
		ArrayList<HashMap<String,String>> referenceDetails = new ArrayList<HashMap<String,String>>();
		try {
			conn = ConnectionPool.getConnection(domain);
			if(policyNumber != null && insuredName != null) {
				sql = "SELECT  pol.DISPLAY_POLICY_NUMBER DISPLAY_POLICY_NUMBER," +
						" RTRIM(ins.BUSINESS_NAME) INSURED_NAME," +
						" pol.EFFECTIVE_DATE EFFECTIVE_DATE," +
						" pol.EXPIRATION_DATE EXPIRATION_DATE FROM VW_MIS_QUOTE_POLICIES pol," +
						" VW_MIS_INSUREDS ins" +
						" WHERE UPPER(pol.DISPLAY_POLICY_NUMBER) LIKE UPPER(?) " +
						" AND UPPER(pol.ENTITY_TYPE)  LIKE UPPER(?) " + 
						" AND UPPER(ins.BUSINESS_NAME) LIKE UPPER(?) AND ins.POLICY_INSURED = pol.GID " +
						" AND pol.revision_number = ( SELECT MAX(revision_number)" +
						" FROM ev_mis_quote_policies" +
						" WHERE policy_quote_indicator = pol.policy_quote_indicator" +
						" AND company_code = pol.company_code" +
						" AND product_code  = pol.product_code " +
						" AND policy_number = pol.policy_number" +
						" AND renewal_counter = pol.renewal_counter" +
						")";
			} else if(policyNumber != null) {
				sql = "SELECT  pol.DISPLAY_POLICY_NUMBER DISPLAY_POLICY_NUMBER," +
						" RTRIM(ins.BUSINESS_NAME) INSURED_NAME," +
						" pol.EFFECTIVE_DATE EFFECTIVE_DATE," +
						" pol.EXPIRATION_DATE EXPIRATION_DATE FROM VW_MIS_QUOTE_POLICIES pol," +
						" VW_MIS_INSUREDS ins" +
						" WHERE pol.DISPLAY_POLICY_NUMBER LIKE UPPER(?) " +
						" AND UPPER(pol.ENTITY_TYPE)  LIKE UPPER(?) " + 
						" AND ins.POLICY_INSURED = pol.GID " +
						" AND pol.revision_number = ( SELECT MAX(revision_number)" +
						" FROM ev_mis_quote_policies" +
						" WHERE policy_quote_indicator = pol.policy_quote_indicator" +
						" AND company_code = pol.company_code" +
						" AND product_code  = pol.product_code " +
						" AND policy_number = pol.policy_number" +
						" AND renewal_counter = pol.renewal_counter" +
						")";
			} else if(insuredName != null) {
				sql = "SELECT  pol.DISPLAY_POLICY_NUMBER DISPLAY_POLICY_NUMBER," +
						" RTRIM(ins.BUSINESS_NAME) INSURED_NAME," +
						" pol.EFFECTIVE_DATE EFFECTIVE_DATE," +
						" pol.EXPIRATION_DATE EXPIRATION_DATE FROM VW_MIS_QUOTE_POLICIES pol," + 
						" VW_MIS_INSUREDS ins" +
						" WHERE upper(ins.BUSINESS_NAME) LIKE  UPPER(?) " +
						" AND UPPER(pol.ENTITY_TYPE)  LIKE UPPER(?) " + 
						" AND ins.POLICY_INSURED = pol.GID " +
						" AND pol.revision_number = ( SELECT MAX(revision_number)" +
						" FROM ev_mis_quote_policies" +
						" WHERE policy_quote_indicator = pol.policy_quote_indicator" +
						" AND company_code = pol.company_code" +
						" AND product_code  = pol.product_code " +
						" AND policy_number = pol.policy_number" +
						" AND renewal_counter = pol.renewal_counter" +
						")";
			}
			
			ps = conn.prepareStatement(sql);
			if (policyNumber != null && insuredName != null) {
				ps.setString(1, "%" + policyNumber + "%");
				ps.setString(2, "%" + referenceType + "%");
				ps.setString(3, "%" + insuredName + "%");
			} else if (policyNumber != null) {
				ps.setString(1, "%" + policyNumber + "%");
				ps.setString(2, "%" + referenceType + "%");
			} else if (insuredName != null) {
				ps.setString(1, "%" + insuredName + "%");
				ps.setString(2, "%" + referenceType + "%");
			}
			rs = ps.executeQuery();
			
			while(rs.next()) {
				HashMap<String,String> policyReferenceDetails = new HashMap<String,String>();
				policyReferenceDetails.put("PolicyNumber", rs.getString("DISPLAY_POLICY_NUMBER"));
				policyReferenceDetails.put("InsuredName", rs.getString("INSURED_NAME"));
				policyReferenceDetails.put("EffectiveDate", rs.getString("EFFECTIVE_DATE"));
				policyReferenceDetails.put("ExpirationDate", rs.getString("EXPIRATION_DATE"));
				referenceDetails.add(policyReferenceDetails);
			}
			response.setReferenceDetails(referenceDetails);
		} catch (Exception ex) {
				ex.printStackTrace();
				throw ex;
		} finally {
				try {
					DBUtil.close(rs,ps,conn);
				} catch (Exception ex) {
					ex.printStackTrace();
					// suppress
				}
		}
		return response;
	}
	
	private PolicyUTMResponse getSubmissionReferenceDetails(String referenceType, 
			String policyNumber, String insuredName, String domain) throws Exception {
		Connection conn = null;
		PreparedStatement ps = null;
		String sql = null;
		ResultSet rs = null;
		PolicyUTMResponse response =  new PolicyUTMResponse();
		ArrayList<HashMap<String,String>> referenceDetails = new ArrayList<HashMap<String,String>>();
		try {
			conn = ConnectionPool.getConnection(domain);
			if(policyNumber != null && insuredName != null) {
				sql = "SELECT  sub.DISPLAY_SUBMISSION_NUMBER DISPLAY_POLICY_NUMBER," +
						" RTRIM(cus.FULL_NAME) INSURED_NAME," +
						" sub.SUB_EFFECTIVE_DATE EFFECTIVE_DATE," +
						" sub.SUB_EXPIRATION_DATE EXPIRATION_DATE " + 
						" FROM VW_MIS_SUBMISSIONS_NEW sub, VW_MIS_CUSTOMERS cus" +
						" WHERE UPPER(sub.DISPLAY_SUBMISSION_NUMBER) LIKE UPPER(?) " +
						" AND UPPER(sub.ENTITY_TYPE)  LIKE UPPER(?) " + 
						" AND UPPER(cus.FULL_NAME) LIKE  UPPER(?) " + 
						" AND cus.SUBMISSION_NEW_CUST_INFO = sub.GID ";
			} else if(policyNumber != null) {
				sql = "SELECT  sub.DISPLAY_SUBMISSION_NUMBER DISPLAY_POLICY_NUMBER," +
						" RTRIM(cus.FULL_NAME) INSURED_NAME," +
						" sub.SUB_EFFECTIVE_DATE EFFECTIVE_DATE," +
						" sub.SUB_EXPIRATION_DATE EXPIRATION_DATE " + 
						" FROM VW_MIS_SUBMISSIONS_NEW sub, VW_MIS_CUSTOMERS cus" +
						" WHERE UPPER(sub.DISPLAY_SUBMISSION_NUMBER) LIKE UPPER(?) " +
						" AND UPPER(sub.ENTITY_TYPE)  LIKE UPPER(?) " + 
						" AND cus.SUBMISSION_NEW_CUST_INFO = sub.GID ";
			} else if(insuredName != null) {
				sql = "SELECT  sub.DISPLAY_SUBMISSION_NUMBER DISPLAY_POLICY_NUMBER," +
						" RTRIM(cus.FULL_NAME) INSURED_NAME," +
						" sub.SUB_EFFECTIVE_DATE EFFECTIVE_DATE," +
						" sub.SUB_EXPIRATION_DATE EXPIRATION_DATE " + 
						" FROM VW_MIS_SUBMISSIONS_NEW sub, VW_MIS_CUSTOMERS cus" +
						" WHERE UPPER(cus.FULL_NAME) LIKE UPPER(?) " +
						" AND UPPER(sub.ENTITY_TYPE)  LIKE UPPER(?) " + 
						" AND cus.SUBMISSION_NEW_CUST_INFO = sub.GID ";
			}
			ps = conn.prepareStatement(sql);
			if (policyNumber != null && insuredName != null) {
				ps.setString(1, "%" + policyNumber + "%");
				ps.setString(2, "%" + referenceType + "%");
				ps.setString(3, "%" + insuredName + "%");
			} else if (policyNumber != null) {
				ps.setString(1, "%" + policyNumber + "%");
				ps.setString(2, "%" + referenceType + "%");

			} else if (insuredName != null) {
				ps.setString(1, "%" + insuredName + "%");
				ps.setString(2, "%" + referenceType + "%");
			}
			rs = ps.executeQuery();
			
			while(rs.next()) {
				HashMap<String,String> policyReferenceDetails = new HashMap<String,String>();
				policyReferenceDetails.put("PolicyNumber", rs.getString("DISPLAY_POLICY_NUMBER"));
				policyReferenceDetails.put("InsuredName", rs.getString("INSURED_NAME"));
				policyReferenceDetails.put("EffectiveDate", rs.getString("EFFECTIVE_DATE"));
				policyReferenceDetails.put("ExpirationDate", rs.getString("EXPIRATION_DATE"));
				referenceDetails.add(policyReferenceDetails);
			}
			response.setReferenceDetails(referenceDetails);
		} catch (Exception ex) {
				ex.printStackTrace();
				throw ex;
		} finally {
				try {
					DBUtil.close(rs,ps,conn);
				} catch (Exception ex) {
					ex.printStackTrace();
					// suppress
				}
		}
		return response;
	}


	private PolicyUTMResponse getPolicyContextDetails(
			String referenceType, String referenceNumber, String contextType, String domain) throws Exception {
		Connection conn = null;
		PreparedStatement ps = null;
		String sql = null;
		ResultSet rs = null;
		PolicyUTMResponse response =  new PolicyUTMResponse();
		ArrayList<HashMap<String,String>> referenceDetails = new ArrayList<HashMap<String,String>>();
		try {
			conn = ConnectionPool.getConnection(domain);
			if(contextType != null && "Transaction number".equalsIgnoreCase(contextType)) {
				sql = "SELECT pol.ENTITY_REFERENCE ENTITY_REFERENCE," +
						" K_WORKFLOW_ACTIVITY_MANAGEMENT.F_GET_STATUS(pol.ENTITY_TYPE,  POL.ENTITY_REFERENCE) STATUS," +
						" pol.TRANSACTION_ACTION TRANSACTION_ACTION," +
						" NVL(pol.TRANS_EFFECTIVE_DATE,  pol.EFFECTIVE_DATE) EFFECTIVE_DATE," + 
						" pol.ID ID, pol.RENEWAL_COUNTER RENEWAL_COUNTER" +
						" FROM VW_MIS_QUOTE_POLICIES pol" +
						" WHERE UPPER(pol.DISPLAY_POLICY_NUMBER) =UPPER(?) " +
						" AND UPPER(pol.ENTITY_TYPE)  = UPPER(?) ";
			}
			ps = conn.prepareStatement(sql);
			ps.setString(1, referenceNumber);
			ps.setString(2, referenceType);
			rs = ps.executeQuery();
			while(rs.next()) {
				HashMap<String,String> policyReferenceDetails = new HashMap<String,String>();
				policyReferenceDetails.put("TransactionNumber", rs.getString("ENTITY_REFERENCE"));
				policyReferenceDetails.put("TransactionStatus", rs.getString("STATUS"));
				policyReferenceDetails.put("TransactionName", rs.getString("TRANSACTION_ACTION"));
				policyReferenceDetails.put("TransactionEffectiveDate", rs.getString("EFFECTIVE_DATE"));
				policyReferenceDetails.put("EntityId", rs.getString("ID"));
				policyReferenceDetails.put("RenewalCounter", rs.getString("RENEWAL_COUNTER"));
				referenceDetails.add(policyReferenceDetails);
			}
			response.setReferenceDetails(referenceDetails);
		} catch (Exception ex) {
				ex.printStackTrace();
				throw ex;
		} finally {
				try {
					DBUtil.close(rs,ps,conn);
				} catch (Exception ex) {
					ex.printStackTrace();
					// suppress
				}
		}
		return response;
	}
	


	private PolicyUTMResponse getPolicySpecificAttributes(
			String referenceType, String referenceNumber, String domain) throws Exception {
		if("SUBMISSION".equalsIgnoreCase(referenceType)) {
			PolicyUTMResponse response = getSubmissionSpecificAttributes(referenceType, 
					referenceNumber, domain);
			return response;
		}
		Connection conn = null;
		PreparedStatement ps = null;
		String sql = null;
		ResultSet rs = null;
		PolicyUTMResponse response =  new PolicyUTMResponse();
		ArrayList<HashMap<String,String>> referenceDetails = new ArrayList<HashMap<String,String>>();
		try {
			conn = ConnectionPool.getConnection(domain);
				sql = "SELECT PRODUCT_CODE PRODUCT_CODE," +
						" mp.MPO_AGENT_ID PRODUCER_CODE," +
						" pol.PROGRAM_CODE PROGRAM_CODE," + 
						" mp.MPO_POLICY_STATE STATE," +
						" (SELECT PRODUCER_CODE FROM VW_MIS_PRODUCERS WHERE ENTITY_REFERENCE = pol.ENTITY_REFERENCE AND" +
						" ENTITY_TYPE = pol.ENTITY_TYPE AND PRODUCER_OF_RECORD = 'N') SUB_PRODUCER_CODE," +
						" pol.UNDERWRITER_CODE UNDERWRITER," +
						" pol.ID ID, pol.RENEWAL_COUNTER RENEWAL_COUNTER," +
						" pol.COMPANY_CODE COMPANY" +
						" FROM VW_MIS_QUOTE_POLICIES pol," +
						" mis_policies mp" +
						" WHERE UPPER(pol.DISPLAY_POLICY_NUMBER) = UPPER(?) " +
						" AND UPPER(pol.ENTITY_TYPE)  = UPPER(?) " + 
						" AND mp.mpo_policy_reference (+) = pol.entity_reference" +
						" AND pol.revision_number = ( SELECT MAX(revision_number)" +
						" FROM ev_mis_quote_policies" +
						" WHERE policy_quote_indicator = pol.policy_quote_indicator" +
						" AND company_code = pol.company_code" +
						" AND product_code  = pol.product_code " +
						" AND policy_number = pol.policy_number" +
						" AND renewal_counter = pol.renewal_counter" +
						")";
			ps = conn.prepareStatement(sql);
			ps.setString(1, referenceNumber);
			ps.setString(2, referenceType);
			rs = ps.executeQuery();
			while(rs.next()) {
				HashMap<String,String> policyReferenceDetails = new HashMap<String,String>();
				policyReferenceDetails.put("Branch", rs.getString("PRODUCT_CODE"));
				policyReferenceDetails.put("Producer", rs.getString("PRODUCER_CODE"));
				policyReferenceDetails.put("ProgramCode", rs.getString("PROGRAM_CODE"));
				policyReferenceDetails.put("State", rs.getString("STATE"));
				policyReferenceDetails.put("SubProducer", rs.getString("SUB_PRODUCER_CODE"));
				policyReferenceDetails.put("Underwriter", rs.getString("UNDERWRITER"));
				policyReferenceDetails.put("EntityId", rs.getString("ID"));
				policyReferenceDetails.put("RenewalCounter", rs.getString("RENEWAL_COUNTER"));
				policyReferenceDetails.put("Company", rs.getString("COMPANY"));
				referenceDetails.add(policyReferenceDetails);
			}
			response.setReferenceDetails(referenceDetails);
		} catch (Exception ex) {
				ex.printStackTrace();
				throw ex;
		} finally {
				try {
					DBUtil.close(rs,ps,conn);
				} catch (Exception ex) {
					ex.printStackTrace();
					// suppress
				}
		}
		return response;
	}
	
	private PolicyUTMResponse getSubmissionSpecificAttributes(
			String referenceType, String referenceNumber, String domain) throws Exception {
		Connection conn = null;
		PreparedStatement ps = null;
		String sql = null;
		ResultSet rs = null;
		PolicyUTMResponse response =  new PolicyUTMResponse();
		ArrayList<HashMap<String,String>> referenceDetails = new ArrayList<HashMap<String,String>>();
		try {
			conn = ConnectionPool.getConnection(domain);
				sql = "SELECT PRODUCT_CODE PRODUCT_CODE," +
						" (SELECT PRODUCER_CODE FROM VW_MIS_PRODUCERS WHERE ENTITY_REFERENCE = sub.ENTITY_REFERENCE AND" +
						" ENTITY_TYPE = sub.ENTITY_TYPE AND PRODUCER_OF_RECORD = 'Y') PRODUCER_CODE, " +
						" sub.ID ID," +
						" (SELECT PRODUCER_CODE FROM VW_MIS_PRODUCERS WHERE ENTITY_REFERENCE = sub.ENTITY_REFERENCE AND" +
						" ENTITY_TYPE = sub.ENTITY_TYPE AND PRODUCER_OF_RECORD = 'N') SUB_PRODUCER_CODE " +
						" FROM VW_MIS_SUBMISSIONS_NEW sub" +
						" WHERE UPPER(sub.DISPLAY_SUBMISSION_NUMBER) = UPPER(?) " +
						" AND UPPER(sub.ENTITY_TYPE)  = UPPER(?) ";
			
			ps = conn.prepareStatement(sql);
			ps.setString(1, referenceNumber);
			ps.setString(2, referenceType);
			rs = ps.executeQuery();
			while(rs.next()) {
				HashMap<String,String> policyReferenceDetails = new HashMap<String,String>();
				policyReferenceDetails.put("Branch", rs.getString("PRODUCT_CODE"));
				policyReferenceDetails.put("Producer", rs.getString("PRODUCER_CODE"));
				policyReferenceDetails.put("ProgramCode", null);
				policyReferenceDetails.put("State", null);
				policyReferenceDetails.put("SubProducer", rs.getString("SUB_PRODUCER_CODE"));
				policyReferenceDetails.put("Underwriter", null);
				policyReferenceDetails.put("EntityId", rs.getString("ID"));
				policyReferenceDetails.put("RenewalCounter", null);
				policyReferenceDetails.put("Company", null);
				referenceDetails.add(policyReferenceDetails);
			}
			response.setReferenceDetails(referenceDetails);
		} catch (Exception ex) {
				ex.printStackTrace();
				throw ex;
		} finally {
				try {
					DBUtil.close(rs,ps,conn);
				} catch (Exception ex) {
					ex.printStackTrace();
					// suppress
				}
		}
		return response;
	}

}

