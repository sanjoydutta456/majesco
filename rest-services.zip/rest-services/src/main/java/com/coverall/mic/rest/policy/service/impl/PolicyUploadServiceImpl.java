package com.coverall.mic.rest.policy.service.impl;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;

import org.apache.cxf.jaxrs.ext.MessageContext;
import org.apache.cxf.transport.http.AbstractHTTPDestination;

import com.coverall.mic.rest.policy.dao.PCTUploadStatusDao;
import com.coverall.mic.rest.policy.dao.impl.PCTUploadStatusDaoImpl;
import com.coverall.mic.rest.policy.service.PolicyUploadService;
import com.coverall.mic.rest.policy.service.model.PCTUploadStatus;
import com.coverall.mic.rest.policy.service.model.PolicyRSUploadRequest;
import com.coverall.mic.rest.policy.service.model.PolicyRSUploadResponse;
import com.coverall.mt.http.HTTPConstants;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.pctv2.server.util.EntityReferenceGenerator;
import com.coverall.pctv2.server.ws.service.upload.PCTUploadRequest;
import com.coverall.pctv2.server.ws.service.upload.PCTUploadResponse;
import com.coverall.pctv2.server.ws.service.upload.PCTUploadXmlStringRequest;
import com.coverall.pctv2.server.ws.service.upload.PCTUploadXmlZipStringRequest;
import com.coverall.pctv2.server.ws.service.upload.PolicyUpload;

public class PolicyUploadServiceImpl implements PolicyUploadService {
	private static final PCTUploadStatusDao statusDao =  PCTUploadStatusDaoImpl.getInstance();
	
	@Context 
	private MessageContext messageContext;


    @Override
    public boolean ping() {
        return true;
    }

	@Override
	public PolicyRSUploadResponse processXml(PolicyRSUploadRequest policyUploadRequest) {
		User user = null;
		PolicyRSUploadResponse pctrsUploadResponse = null;
		
		long startTime = System.currentTimeMillis();
		long intermediateTime = startTime;
		long endTime = 0;
		
		try {
			user = getUser(messageContext);
		} catch (Exception ex) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					getClass().getName(), "processXml",
					ServletConfigUtil.COMPONENT_PORTAL,
					new Object[] { policyUploadRequest.getEntityReference() },
					ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
			pctrsUploadResponse = new PolicyRSUploadResponse();
			pctrsUploadResponse
					.setStatusCode(PCTUploadResponse.STATUS_OTHER_ERRORS);
			pctrsUploadResponse.setStatus(PCTUploadResponse.FAILURE);
			pctrsUploadResponse.setErrorMessage(ex.getMessage());

			return pctrsUploadResponse;
		}
		
		PCTUploadRequest request =  null;
		
		try {
			request = getPCTUploadRequest(policyUploadRequest, user);
			
			endTime = System.currentTimeMillis();
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_ERROR,
					getClass().getName(), "processXml",
					ServletConfigUtil.COMPONENT_PORTAL,
					new Object[] { policyUploadRequest.getEntityReference() },
					"Time taken to get user information and prepare PCTUploadRequest is : " + (endTime - intermediateTime) + " milliseconds.", null, LogMinderDOMUtil.VALUE_MIC);
		} catch (Exception ex) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					getClass().getName(), "processXml",
					ServletConfigUtil.COMPONENT_PORTAL,
					new Object[] { policyUploadRequest.getEntityReference() },
					ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
			pctrsUploadResponse = new PolicyRSUploadResponse();
			pctrsUploadResponse
					.setStatusCode(PCTUploadResponse.STATUS_EXCEPTION);
			pctrsUploadResponse.setStatus(PCTUploadResponse.FAILURE);
			pctrsUploadResponse.setErrorMessage(ex.getMessage());
			return pctrsUploadResponse;
		}
		
		intermediateTime = System.currentTimeMillis();
		
		PCTUploadStatus uploadStatus = new PCTUploadStatus();
		setPCTUploadStatus(uploadStatus, policyUploadRequest, request, null);
		
		pctrsUploadResponse = lockUploadStatus(uploadStatus, user);
		if(pctrsUploadResponse != null) {
			return pctrsUploadResponse;
		}
		
		endTime = System.currentTimeMillis();
		LogMinder.getLogMinder().log(LogEntry.SEVERITY_ERROR,
				getClass().getName(), "processXml",
				ServletConfigUtil.COMPONENT_PORTAL,
				new Object[] { policyUploadRequest.getEntityReference() },
				"Time taken to setUploadStatus and lockUploadStatus the request is : " + (endTime - intermediateTime) + " milliseconds.", null, LogMinderDOMUtil.VALUE_MIC);
		
		LogMinder.getLogMinder().log(LogEntry.SEVERITY_ERROR,
				getClass().getName(), "processXml",
				ServletConfigUtil.COMPONENT_PORTAL,
				new Object[] { policyUploadRequest.getEntityReference() },
				"Initiating the process for creating the transaction.", null, LogMinderDOMUtil.VALUE_MIC);
		
		intermediateTime = System.currentTimeMillis();
		
		pctrsUploadResponse = process(request, uploadStatus, user);
		
		endTime = System.currentTimeMillis();
		LogMinder.getLogMinder().log(LogEntry.SEVERITY_ERROR,
				getClass().getName(), "processXml",
				ServletConfigUtil.COMPONENT_PORTAL,
				new Object[] { policyUploadRequest.getEntityReference() },
				"Time taken to process the request is : " + (endTime - intermediateTime) + " milliseconds.", null, LogMinderDOMUtil.VALUE_MIC);
		
		intermediateTime = System.currentTimeMillis();
		
		setPCTUploadStatus(uploadStatus, null, null, pctrsUploadResponse);
		saveUploadStatus(uploadStatus, user);
		
		endTime = System.currentTimeMillis();
		LogMinder.getLogMinder().log(LogEntry.SEVERITY_ERROR,
				getClass().getName(), "processXml",
				ServletConfigUtil.COMPONENT_PORTAL,
				new Object[] { policyUploadRequest.getEntityReference() },
				"Time taken after processing the request and to setUploadStatus and saveUploadStatus is : " + (endTime - intermediateTime) + " milliseconds.", null, LogMinderDOMUtil.VALUE_MIC);
		
		
		endTime = System.currentTimeMillis();
		
		LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG,
				getClass().getName(), "processXml",
				ServletConfigUtil.COMPONENT_PORTAL,
				new Object[] { policyUploadRequest.getEntityReference() },
				"Total time taken to process this transaction is : " + (endTime - startTime) + " milliseconds.", null, LogMinderDOMUtil.VALUE_MIC);
		
		return pctrsUploadResponse;			
	}
	
	private void  setPCTUploadStatus(PCTUploadStatus uploadStatus, PolicyRSUploadRequest pctrsUploadRequest, PCTUploadRequest request, PolicyRSUploadResponse response) {
		uploadStatus.setProcess(PCTUploadStatus.PROCESS_UPLOAD);
		
		if(pctrsUploadRequest != null) {
			uploadStatus.setEntityType(pctrsUploadRequest.getEntityType());
			uploadStatus.setOrgEntityReference(pctrsUploadRequest.getEntityReference());
			uploadStatus.setLogLevel(pctrsUploadRequest.getLogLevel());
			uploadStatus.setPurgeExistingEntity(String.valueOf(pctrsUploadRequest.isPurgeExistingEntity()));
			uploadStatus.setRateEntity(String.valueOf(pctrsUploadRequest.isRateEntity()));
			uploadStatus.setRetainAuditFieldVals(String.valueOf(pctrsUploadRequest.isRetainAuditFieldVals()));
			uploadStatus.setRetainIDVals(String.valueOf(pctrsUploadRequest.isRetainIDVals()));
			uploadStatus.setCreateNewEntity(String.valueOf(pctrsUploadRequest.isCreateNewEntity()));
			uploadStatus.setXmlZipped(String.valueOf(pctrsUploadRequest.isXmlZipped()));
			uploadStatus.setReturnRatedEntity(String.valueOf(pctrsUploadRequest.isReturnRatedEntity()));
		}
		
		if(request != null) {
			uploadStatus.setEntityReference(request.getEntityReference());
			uploadStatus.setPolicyXML(request.getPolicyXML());
		}
		
		if(response != null) {
			uploadStatus.setStatus(response.getStatus());
			uploadStatus.setStatusCode(response.getStatusCode());
			uploadStatus.setErrorMessage(response.getErrorMessage());
			
			Map<String, String> policyData = response.getPolicyData();
			if(policyData != null) {
				uploadStatus.setResponseData(policyData.toString());
			}
		}
	}
	
	private PolicyRSUploadResponse lockUploadStatus(PCTUploadStatus uploadStatus, User user) {
		PolicyRSUploadResponse policyUploadResponse = null;
		try {
			statusDao.lockUploadStatus(uploadStatus, user);
		} catch (Exception ex) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					getClass().getName(), "lockUploadStatus",
					ServletConfigUtil.COMPONENT_PORTAL,
					new Object[] { uploadStatus.getEntityReference() },
					ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
			policyUploadResponse = new PolicyRSUploadResponse();
			policyUploadResponse
					.setStatusCode(PCTUploadResponse.STATUS_EXCEPTION);
			policyUploadResponse.setStatus(PCTUploadResponse.FAILURE);
			policyUploadResponse.setErrorMessage(ex.getMessage());
		}
		
		return policyUploadResponse;		
	}
	
	private void saveUploadStatus(PCTUploadStatus uploadStatus, User user) {
		try {
			statusDao.saveUploadStatus(uploadStatus, user);
		} catch (Exception ex) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					getClass().getName(), "saveUploadStatus",
					ServletConfigUtil.COMPONENT_PORTAL,
					new Object[] { uploadStatus.getEntityReference() },
					ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
		}		
	}
	
	
	private PolicyRSUploadResponse process(PCTUploadRequest request, PCTUploadStatus uploadStatus, User user) {
		PolicyRSUploadResponse policyUploadResponse = new PolicyRSUploadResponse();

		PolicyUpload upload = new PolicyUpload();
		PCTUploadResponse response = null;

		policyUploadResponse.setEntityReference(uploadStatus.getEntityReference());
		try {
			response = upload.processRequest(request, user);
		} catch (Exception ex) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					getClass().getName(), "process",
					ServletConfigUtil.COMPONENT_PORTAL,
					new Object[] { uploadStatus.getEntityReference() },
					ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
			policyUploadResponse
					.setStatusCode(PCTUploadResponse.STATUS_EXCEPTION);
			policyUploadResponse.setStatus(PCTUploadResponse.FAILURE);
			policyUploadResponse.setErrorMessage(ex.getMessage());

			return policyUploadResponse;
		}

		try {
			upload.updateNullDisplayPolicyNumber(request,
					request.getEntityReference(),
					uploadStatus.getEntityType(),
					user);
		} catch (Exception ex) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					getClass().getName(), "process",
					ServletConfigUtil.COMPONENT_PORTAL,
					new Object[] { uploadStatus.getEntityReference() },
					ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
		}

		try {
			Map<String, String> policyDetailsMap = upload.getPolicyData(
					request, 
					request.getEntityReference(),
					uploadStatus.getEntityType(),
					user);
			policyUploadResponse.setPolicyData(policyDetailsMap);
		} catch (Exception ex) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					getClass().getName(), "process",
					ServletConfigUtil.COMPONENT_PORTAL,
					new Object[] { uploadStatus.getEntityReference() },
					ex.getMessage(), ex, LogMinderDOMUtil.VALUE_MIC);
		}

		if (PCTUploadResponse.SUCCESS.equalsIgnoreCase(response.getStatus())) {
			policyUploadResponse.setErrorMessage("");
		} else {
			policyUploadResponse.setErrorMessage(response.getMessage());
		}

		String xmlExtract = response.getXmlString();
		String xmlZippedValue = uploadStatus.getXmlZipped();
		boolean xmlZipped = "true".equalsIgnoreCase(xmlZippedValue) ? true : false;
		
		if(xmlExtract != null) {
			xmlExtract = new PolicyUpload().getXMLExtractAsBase64String(
					xmlExtract, 
					request.getEntityReference(),
					xmlZipped
					);
		}
		policyUploadResponse.setXmlExtract(xmlExtract);
		policyUploadResponse.setXmlZipped(xmlZipped);
		policyUploadResponse.setStatus(response.getStatus());
		policyUploadResponse.setStatusCode(response.getStatusCode());
		return policyUploadResponse;
	}

	private PCTUploadRequest getPCTUploadRequest(
			PolicyRSUploadRequest policyUploadRequest, User user) throws Exception {
		PCTUploadRequest request = null;
		PolicyUpload upload = new PolicyUpload();

		boolean zipped = policyUploadRequest.isXmlZipped();
		if (zipped) {
			PCTUploadXmlZipStringRequest xmlZipRequest = new PCTUploadXmlZipStringRequest();
			xmlZipRequest.setPolicyZipBase64XML(policyUploadRequest.getPolicyXML());
			xmlZipRequest.setLogLevel(policyUploadRequest.getLogLevel());
			xmlZipRequest.setPurgeExistingEntity(policyUploadRequest
					.isPurgeExistingEntity());
			xmlZipRequest.setRateEntity(policyUploadRequest.isRateEntity());
			xmlZipRequest.setRetainAuditFieldVals(policyUploadRequest
					.isRetainAuditFieldVals());
			xmlZipRequest.setReturnRatedEntity(policyUploadRequest.isReturnRatedEntity());
			xmlZipRequest.setRetainIDVals(policyUploadRequest.isRetainIDVals());

			request = upload.convertRequest(xmlZipRequest);
		} else {
			PCTUploadXmlStringRequest xmlRequest = new PCTUploadXmlStringRequest();
			xmlRequest.setPolicyXML(policyUploadRequest.getPolicyXML());
			xmlRequest.setLogLevel(policyUploadRequest.getLogLevel());
			xmlRequest.setPurgeExistingEntity(policyUploadRequest
					.isPurgeExistingEntity());
			xmlRequest.setRateEntity(policyUploadRequest.isRateEntity());
			xmlRequest.setRetainAuditFieldVals(policyUploadRequest
					.isRetainAuditFieldVals());
			xmlRequest.setRetainIDVals(policyUploadRequest.isRetainIDVals());
			xmlRequest.setReturnRatedEntity(policyUploadRequest.isReturnRatedEntity());
			request = upload.convertRequest(xmlRequest);
		}

		request.setUserName(user.getFullName());
		
		boolean createNewEntity = policyUploadRequest.isCreateNewEntity();
		String oriEntityReference = policyUploadRequest.getEntityReference();
		request.setEntityReference(oriEntityReference);
		if (createNewEntity) {
			try {
				String newEntityReference = getNewEntityReference(
						oriEntityReference, user);
				request.setEntityReference(newEntityReference);
				request.setPurgeExistingEntity(false);
			} catch (Exception ex) {
				throw new Exception("Failed to get new EntityReference: " + ex.getMessage(), ex);
			}
		}
		
		return request;
	}
	
	private User getUser(MessageContext messageContext) throws Exception {
		User user = null;
		if(messageContext != null) {
			HttpServletRequest request = (HttpServletRequest)messageContext.get(AbstractHTTPDestination.HTTP_REQUEST);
			
			if(request != null) {
				user = (User)request.getAttribute(HTTPConstants.PARAM_USER);
			}
		}

		if(user == null) {
			throw new  Exception("Credential is invalid!");
		} else {
			return user;
		}
	}
	
	private String getNewEntityReference(String oriEntityReference, User user) throws Exception {
        String entType = oriEntityReference.substring(0, 1);
        if (entType.equalsIgnoreCase("P")) {
            entType = "POLICY";
        } else {
            entType = "QUOTE";
        }        	
        String compCode = oriEntityReference.substring(1, 3);
        String ProductCode = oriEntityReference.substring(3, 5);
        String policyNumber = "0";
        String renewalCounter = oriEntityReference.substring(14, 15);
        String newEntityReference = EntityReferenceGenerator.generateEntityReference(
                user,
                entType,
                policyNumber,
                compCode,
                ProductCode,
                renewalCounter,
                null,
                null,
                null);
        if ("-1".equals(newEntityReference)) {
            throw new Exception("Policy Can not be Imported.");
        }
        
        return newEntityReference;
	}
}