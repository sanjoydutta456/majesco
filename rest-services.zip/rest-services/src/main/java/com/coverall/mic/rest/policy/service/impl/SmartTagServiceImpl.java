package com.coverall.mic.rest.policy.service.impl;

import static com.coverall.security.util.constants.SSOConstants.NS_USER;

import java.io.File;
import java.io.FileFilter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.coverall.el.FunctionResolver;
import com.coverall.el.InlineExpression;
import com.coverall.el.VariableResolver;
import com.coverall.el.function.DefaultFunctionResolver;
import com.coverall.exceptions.DocxProcessingException;
import com.coverall.exceptions.ELException;
import com.coverall.exceptions.ELParseException;
import com.coverall.mic.rest.policy.service.SmartTagService;
import com.coverall.mic.rest.policy.service.model.SmartTagRequest;
import com.coverall.mic.rest.policy.service.model.SmartTagResponse;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.el.variable.VariableResolverImpl;
import com.coverall.mt.mailmerge.docxprocessor.WNodeUtil;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.util.ResourceManager;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.DOMUtil;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;
import com.coverall.util.XMLUtil;
import com.coverall.util.validators.SQLInjectionValidator;
import com.coverall.security.authentication.User;

public class SmartTagServiceImpl implements SmartTagService{
	
	private static final String COMPONENT = "framework";
	private static final String QUERIES_FILE = "SmartQueries.xml";
	private static HashMap<String,String> dateFormatMap = new HashMap<String,String>();
	private static final String PRODUCT_OPTION_DOCUMENT_DATE_FORMAT = "DOCUMENT_DATE_FORMAT";
	
	@Override
	public SmartTagResponse getSmartTagValue(String entityReference,String entityType, HttpServletRequest request) {
		SmartTagResponse response = null;
		User user = null;
		try {
			SQLInjectionValidator.validateEntityType(entityType);
			SQLInjectionValidator.validateEntityReference(entityReference);
			
			user = (User) request.getSession().getAttribute(NS_USER);
			String customerCode=user.getCustomercode();	
			String domain = user.getDomain();
			response = getSmartTagValue(entityReference, entityType , customerCode, domain);
		} catch (Exception e) {
			response.setStatus("Expectation Failed");
			response.setStatusCode(417);
			response.setErrorMessage(e.getMessage());
			return response;
		}
		response.setStatus("OK");
		response.setStatusCode(200);
		response.setErrorMessage("");
		return response;
	}
	
	public SmartTagResponse getSmartTagValue(String entityReference,
            String entityType, String customerCode, String domain) throws Exception {
		SmartTagResponse response = new SmartTagResponse();
		Map<String, HashMap<String, String>> customerMap = null;
		Map<String, HashMap<String, String>> resolvedQueryMap = null;		
		customerMap = loadCustomerQueries();
		
		resolvedQueryMap = resolveSmartQueries(customerMap, entityReference, entityType, customerCode,domain);
		getSmartTagValueMap(resolvedQueryMap, response, domain, customerCode);
		
		return response;
	}
	
	private void getSmartTagValueMap(Map<String, HashMap<String, String>> resolvedQueryMap,  SmartTagResponse response, String domain, String cust) throws DocxProcessingException, ELException, ELParseException, SQLException {
		Iterator<Entry<String, HashMap<String, String>>> it= resolvedQueryMap.entrySet().iterator();
		Map.Entry<String, HashMap<String, String>> me = (Map.Entry<String, HashMap<String, String>>) it.next();
		String customerCode = (String) me.getKey();
		HashMap<String, String> smartTagValueMap = new HashMap<String, String>();
		if (cust.equals(customerCode)) {
			HashMap<String, String> smartQueriesMap = (HashMap<String, String>) me.getValue();
			Iterator<Entry<String, String>> queryIt = smartQueriesMap.entrySet().iterator();
			while (queryIt.hasNext()) {
				Map.Entry<String, String> qme = (Map.Entry<String, String>) queryIt.next();
				String type = (String)qme.getKey();
				String query = (String) qme.getValue();
				HashMap<String, String> smartTagTypeValueMap = executeSmartQuery(type, query, domain);
				smartTagValueMap.putAll(smartTagTypeValueMap);
			}
			
			response.setSmartTagMap(smartTagValueMap);
			
		}
		
	}

	private synchronized Map<String, HashMap<String, String>> loadCustomerQueries()
			throws Exception {
		Map<String, HashMap<String, String>> customerMap = new HashMap<String, HashMap<String, String>>();

		String componentPath = null;
		componentPath = ResourceManager.locateConfDir(COMPONENT);

		File confDir = new File(componentPath);
		File[] custFiles = confDir.listFiles(new FileFilter() {
			public boolean accept(File file) {
				return (file.isDirectory() && new File(file, QUERIES_FILE)
						.exists());
			}
		});

		for (int i = 0; i < custFiles.length; ++i) {
			String customerCode = custFiles[i].getName();
			String customerCodePath = ResourceManager.locateConfDir(COMPONENT,
					customerCode, QUERIES_FILE);

			Document document = DOMUtil.create(QUERIES_FILE, customerCodePath);

			customerMap
					.put(customerCode, getSmartQueriesFromDocument(document));
		}
		
		try {
			ArrayList customerList = CustomerConfigUtil.getInstance().getCustomers();
        	
        	for (int i = 0; i < customerList.size(); i++) {
                String customer_code = CustomerConfigUtil.getInstance().getCustomerCode((String)customerList.get(i));
				if(!customerMap.containsKey(customer_code)) {
					customerMap.put(customer_code, customerMap.get("base"));
	            }
        	}
          }  catch (Exception e) {
        	  LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
        			 SmartTagServiceImpl.class.getName(),
                     "loadCustomerQueries()",
                     "mt",
                     new Object[] { "Error in Loading customermap: " +
                     e.getMessage() },
                     "loadCustomerQueries Queries XML.",
                     e, LogMinderDOMUtil.VALUE_MIC);;
          }

		if (customerMap.size() == 0) {
			throw new DocxProcessingException("No smart queries found",
						new Throwable());
		}
		return customerMap;
	}

	private HashMap<String, String> getSmartQueriesFromDocument(Document document)
			throws ELException, ELParseException {
		HashMap<String, String> smartQueriesMap = new HashMap<String, String>();
		NodeList smartQueryList = document.getElementsByTagName("SMARTQUERY");

		for (int i = 0; i < smartQueryList.getLength(); i++) {
			Element smartQuery = (Element) smartQueryList.item(i);
			String queryType = smartQuery.getAttribute("type");
			String query = XMLUtil.getElementValue(smartQuery);
			smartQueriesMap.put(queryType, query);
		}

		return smartQueriesMap;
	}

	public HashMap<String, HashMap<String, String>> resolveSmartQueries(Map<String, HashMap<String, String>> customerMap, 
            String entityReference,
            String entityType,
			String cust,
			String domain)
			throws ELException, ELParseException {
		/* Resolve the Smart Queries and put it in a map */
		HashMap<String, HashMap<String, String>> resolvedCustomerMap = new HashMap<String, HashMap<String, String>>();
		Iterator<Entry<String, HashMap<String, String>>> it = customerMap.entrySet().iterator();
		HashMap<String, HashMap<String, String>> variableMap = new HashMap<String, HashMap<String, String>>();
		HashMap<String, String> requestParams = new HashMap<String, String>();
	
		String dateFormat = CustomerConfigUtil.getInstance().getCustomerProperty(domain,
                ServletConfigUtil.COMPONENT_PORTAL,
                CustomerConfigUtil.USE_DATE_FORMAT);      
		boolean overrideFormatting = "true".equalsIgnoreCase(CustomerConfigUtil.getInstance().getCustomerProperty(domain,
                ServletConfigUtil.COMPONENT_PORTAL,
                CustomerConfigUtil.OVERRIDE_FORMATTING));
        if(overrideFormatting){
        	requestParams.put("dateformat", dateFormat);
        } else {
        	String documentDateFormat = null;
        	Connection conn = null;
        	try {
        		conn = ConnectionPool.getConnection(domain);
        		documentDateFormat = WNodeUtil.getProductOptionSelectedValue(conn, entityReference, PRODUCT_OPTION_DOCUMENT_DATE_FORMAT);
        	}catch(Exception e){
        		
        	}finally {
        		try{
        			DBUtil.close(conn);
        		}catch(Exception e){
        		}
        	}
        	if (documentDateFormat != null){
        		requestParams.put("dateformat", documentDateFormat);
        	}
        }
		requestParams.put("entityReference", entityReference);
		requestParams.put("entityType", entityType);
		variableMap.put(VariableResolverImpl.REQUESTPARAMS_PARAMETER,
				requestParams);
		while (it.hasNext()) {
			Map.Entry<String, HashMap<String, String>> me = (Map.Entry<String, HashMap<String, String>>) it.next();
			String customerCode = (String) me.getKey();
			if (cust.equals(customerCode)) {
				HashMap<String, String> smartQueriesMap = (HashMap<String, String>) me.getValue();
				HashMap<String, String> resolvedSmartQueriesMap = new HashMap<String, String>();
				Iterator<Entry<String, String>> queryIt = smartQueriesMap.entrySet().iterator();
				while (queryIt.hasNext()) {
					Map.Entry<String, String> qme = (Map.Entry<String, String>) queryIt.next();
					String query = (String) qme.getValue();
					String resolvedquery = resolveExpression(query, variableMap);
					resolvedSmartQueriesMap.put((String) qme.getKey(),
							resolvedquery);
				}
				resolvedCustomerMap.put(customerCode, resolvedSmartQueriesMap);
			}
		}
		return resolvedCustomerMap;

	}

	public String resolveExpression(String data, HashMap<String, HashMap<String, String>> variableMap)
			throws ELException, ELParseException {

		VariableResolver varResolver = new VariableResolverImpl(variableMap);
		FunctionResolver funcResolver = new DefaultFunctionResolver();
		InlineExpression expression = new InlineExpression(data, varResolver,
				funcResolver);
		return expression.getValue();
	}
	
	public static void main(String[] args) {
		//SmartTagServiceImpl smartTagServiceImpl = new SmartTagServiceImpl();
		SmartTagRequest request = new SmartTagRequest();
		System.setProperty("mic.j2ee.home", "D:\\cover-all\\mic\\micj2eehome");
		request.setEntityReference("P20CA0000002443001");
		request.setEntityType("POLICY");
		//smartTagServiceImpl.getSmartTagValue(request);
	}
	
	private HashMap<String, String> executeSmartQuery(String smartTagType, String smartQuery,
			String domain) throws ELException, ELParseException, SQLException,
			DocxProcessingException {

		HashMap<String, String> smartData = new HashMap<String, String>();
		Connection conn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		ResultSetMetaData resultSetMetaData = null;

		try {
			conn = ConnectionPool.getConnection(domain);
			statement = conn.createStatement();
			resultSet = statement.executeQuery(smartQuery);
			if (resultSet != null) {
				resultSetMetaData = resultSet.getMetaData();
				int columnCount = resultSetMetaData.getColumnCount();

				if (resultSet.next()) {
					for (int i = 1; i <= columnCount; i++) {
						String columnName = resultSetMetaData.getColumnName(i);
						String columnValue = resultSet.getString(i);
						smartData.put(columnName.toUpperCase(), columnValue);
					}
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			// suppress
		} finally {
			try {
				DBUtil.close(resultSet, statement, conn);
			} catch (Exception ex) {
				// suppress
			}
		}
		return smartData;
	}

	@Override
	public boolean ping() {
		return false;
	}	
}
