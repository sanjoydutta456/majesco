package com.coverall.mic.rest.policy.service.model;

import java.io.Serializable;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.core.MediaType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
public class BTISRSNotifyRequest implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String status;
	private int statusCode;
	private String errorMessage;
	private String entityReference;

	private Map<String,String> policyData;
	private String xmlExtract;
	private boolean xmlZipped;
	
	public boolean isXmlZipped() {
		return xmlZipped;
	}
	public void setXmlZipped(boolean xmlZipped) {
		this.xmlZipped = xmlZipped;
	}
	
	public String getXmlExtract() {
		return xmlExtract;
	}
	public void setXmlExtract(String xmlExtract) {
		this.xmlExtract = xmlExtract;
	}
	
	public String getEntityReference() {
		return entityReference;
	}
	public void setEntityReference(String entityReference) {
		this.entityReference = entityReference;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public Map<String, String> getPolicyData() {
		return policyData;
	}
	public void setPolicyData(Map<String, String> policyData) {
		this.policyData = policyData;
	}
}
