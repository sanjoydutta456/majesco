package com.coverall.mic.rest.policy.service.model;

import java.io.Serializable;

import javax.ws.rs.Consumes;
import javax.ws.rs.core.MediaType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
public class PCTRSUploadRequest implements Serializable {

    private java.lang.String entityReference;

    private java.lang.String policyXML;

    private boolean retainAuditFieldVals = true;

    private boolean retainIDVals = true;

    private java.lang.String password;

    private java.lang.String userName;

    private boolean evaluateAll;

    private String sourceSystem;

    private String sourceSystemId;

    private String entityType;

    public String getEntityType() {
        return entityType;
    }

    public void setEntityType(String entityType) {
        this.entityType = entityType;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public String getSourceSystemId() {
        return sourceSystemId;
    }

    public void setSourceSystemId(String sourceSystemId) {
        this.sourceSystemId = sourceSystemId;
    }

	public java.lang.String getEntityReference() {
		return entityReference;
	}

	public void setEntityReference(java.lang.String entityReference) {
		this.entityReference = entityReference;
	}

	public java.lang.String getPolicyXML() {
		return policyXML;
	}

	public void setPolicyXML(java.lang.String policyXML) {
		this.policyXML = policyXML;
	}

	public boolean isRetainAuditFieldVals() {
		return retainAuditFieldVals;
	}

	public void setRetainAuditFieldVals(boolean retainAuditFieldVals) {
		this.retainAuditFieldVals = retainAuditFieldVals;
	}

	public boolean isRetainIDVals() {
		return retainIDVals;
	}

	public void setRetainIDVals(boolean retainIDVals) {
		this.retainIDVals = retainIDVals;
	}

	public java.lang.String getPassword() {
		return password;
	}

	public void setPassword(java.lang.String password) {
		this.password = password;
	}

	public java.lang.String getUserName() {
		return userName;
	}

	public void setUserName(java.lang.String userName) {
		this.userName = userName;
	}

	public boolean isEvaluateAll() {
		return evaluateAll;
	}

	public void setEvaluateAll(boolean evaluateAll) {
		this.evaluateAll = evaluateAll;
	}

}
