package com.coverall.mic.rest.policy.service.model;

public class PCTUploadStatus {
	public static final String PROCESS_UPLOAD = "upload";
	public static final String PROCESS_STATUS_UPDATE = "statusUpdate";
	
	public static final String STATUS_LOCK = "LOCK";
	public static final String STATUS_FAILURE = "FAILURE";
	public static final String STATUS_SUCCESS = "SUCCESS";
	
	public static final String ENTITY_STATUS_COMPLETE = "COMPLETE";
	public static final String ENTITY_STATUS_SUSPENSE = "SUSPENSE";
	public static final String ENTITY_STATUS_READY = "READY";
	public static final String ENTITY_STATUS_IN_PROGRESS = "IN PROGRESS";
	public static final String ENTITY_STATUS_BLOCK = "BLOCK";

	private long id;
    private String entityType;
    private String entityReference;
    private String orgEntityReference;
    private String process;
    private String logLevel;
    private String purgeExistingEntity;
    private String rateEntity;
    private String retainAuditFieldVals;
	private String retainIDVals;
    private String createNewEntity;
    private String policyXML;
    private String xmlZipped;
    private String status;
    private int statusCode;
    private String errorMessage;
    private String responseData;
    private String responseXml;
    private String returnRatedEntity;

	private String entityStatus;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getEntityType() {
		return entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	public String getEntityReference() {
		return entityReference;
	}

	public void setEntityReference(String entityReference) {
		this.entityReference = entityReference;
	}

	public String getOrgEntityReference() {
		return orgEntityReference;
	}

	public void setOrgEntityReference(String orgEntityReference) {
		this.orgEntityReference = orgEntityReference;
	}

	public String getProcess() {
		return process;
	}

	public void setProcess(String process) {
		this.process = process;
	}

	public String getLogLevel() {
		return logLevel;
	}

	public void setLogLevel(String logLevel) {
		this.logLevel = logLevel;
	}

	public String getPurgeExistingEntity() {
		return purgeExistingEntity;
	}

	public void setPurgeExistingEntity(String purgeExistingEntity) {
		this.purgeExistingEntity = purgeExistingEntity;
	}

	public String getRateEntity() {
		return rateEntity;
	}

	public void setRateEntity(String rateEntity) {
		this.rateEntity = rateEntity;
	}

	public String getRetainAuditFieldVals() {
		return retainAuditFieldVals;
	}

	public void setRetainAuditFieldVals(String retainAuditFieldVals) {
		this.retainAuditFieldVals = retainAuditFieldVals;
	}

	public String getRetainIDVals() {
		return retainIDVals;
	}

	public void setRetainIDVals(String retainIDVals) {
		this.retainIDVals = retainIDVals;
	}

	public String getCreateNewEntity() {
		return createNewEntity;
	}

	public void setCreateNewEntity(String createNewEntity) {
		this.createNewEntity = createNewEntity;
	}

	public String getPolicyXML() {
		return policyXML;
	}

	public void setPolicyXML(String policyXML) {
		this.policyXML = policyXML;
	}
	
    public String getXmlZipped() {
		return xmlZipped;
	}	
    
	public void setXmlZipped(String xmlZipped) {
		this.xmlZipped = xmlZipped;		
	} 
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getResponseData() {
		return responseData;
	}

	public void setResponseData(String responseData) {
		this.responseData = responseData;
	}

    public String getResponseXml() {
		return responseXml;
	}

	public void setResponseXml(String responseXml) {
		this.responseXml = responseXml;
	}
	
	public String getReturnRatedEntity() {
		return returnRatedEntity;
	}

	public void setReturnRatedEntity(String returnRatedEntity) {
		this.returnRatedEntity = returnRatedEntity;
	}	
	
	public String getEntityStatus() {
		return entityStatus;
	}

	public void setEntityStatus(String entityStatus) {
		this.entityStatus = entityStatus;
	}
}
