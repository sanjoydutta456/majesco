package com.coverall.mic.rest.policy.service.model;

import javax.ws.rs.Consumes;
import javax.ws.rs.core.MediaType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
public class PolicyRSUploadRequest extends PCTRSUploadRequest {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
   
	private boolean xmlZipped = false;
    
    private java.lang.String logLevel;
    
    private boolean purgeExistingEntity = false;
    
    private boolean rateEntity = false;
    
    private boolean returnRatedEntity = false; 
    
    private boolean createNewEntity = false;
    
    public boolean isCreateNewEntity() {
		return createNewEntity;
	}

	public void setCreateNewEntity(boolean createNewEntity) {
		this.createNewEntity = createNewEntity;
	}

	public boolean isReturnRatedEntity() {
		return returnRatedEntity;
	}

	public void setReturnRatedEntity(boolean returnRatedEntity) {
		this.returnRatedEntity = returnRatedEntity;
	}

	public boolean isRateEntity() {
		return rateEntity;
	}

	public void setRateEntity(boolean rateEntity) {
		this.rateEntity = rateEntity;
	}

	public boolean isPurgeExistingEntity() {
		return purgeExistingEntity;
	}

	public void setPurgeExistingEntity(boolean purgeExistingEntity) {
		this.purgeExistingEntity = purgeExistingEntity;
	}

	public java.lang.String getLogLevel() {
		return logLevel;
	}

	public void setLogLevel(java.lang.String logLevel) {
		this.logLevel = logLevel;
	}

    public boolean isXmlZipped() {
		return xmlZipped;
	}

	public void setXmlZipped(boolean xmlZipped) {
		this.xmlZipped = xmlZipped;
	}	
}
