
package com.coverall.mic.rest.policy.service.model;

import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
public class PolicyRSUploadResponse extends PCTRSUploadResponse {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;


    private String xmlExtract;
    
    private boolean xmlZipped;
    
	public boolean isXmlZipped() {
		return xmlZipped;
	}

	public void setXmlZipped(boolean xmlZipped) {
		this.xmlZipped = xmlZipped;
	}

	public String getXmlExtract() {
		return xmlExtract;
	}

	public void setXmlExtract(String xmlExtract) {
		this.xmlExtract = xmlExtract;
	}
}