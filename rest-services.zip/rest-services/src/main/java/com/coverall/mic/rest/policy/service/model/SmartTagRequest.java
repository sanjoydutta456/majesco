package com.coverall.mic.rest.policy.service.model;

import java.io.Serializable;

import javax.ws.rs.Consumes;
import javax.ws.rs.core.MediaType;
import javax.xml.bind.annotation.XmlRootElement;

import com.google.gson.Gson;

@XmlRootElement
@Consumes( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
public class SmartTagRequest implements Serializable {	
	private static final long serialVersionUID = 1L;
	
	private String entityReference;
	private String entityType;

	public SmartTagRequest(String json) {
		super();
		System.out.println("Generating from json \n" + json);
		Gson gson = new Gson();
		SmartTagRequest request = gson.fromJson(json, SmartTagRequest.class);
		this.entityReference = request.entityReference;
		this.entityType = request.entityType;
	}

	public SmartTagRequest() {
		super();
	}	
	public String getEntityReference() {
		return entityReference;
	}
	public void setEntityReference(String entityReference) {
		this.entityReference = entityReference;
	}
	public String getEntityType() {
		return entityType;
	}
	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}
}
