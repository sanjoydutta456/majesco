package com.coverall.mic.rest.policy.service.model;

import java.io.Serializable;
import java.util.Map;

public final class TransactionRequest implements Serializable {
    /**
     *
     */
    private static final long serialVersionUID = 1L;

    /**
     * An identifier that shows the entity reference on that the transaction
     * will perform
     */
    private String sourceEntityReference;

    /**
     * An identifier that shows the source entity type, in ATP it always be
     * POLICY
     */
    private String sourceEntityType;

    /**
     * An identifier that shows the name of the automated transaction name that
     * will perform by ATP
     */
    private String transactionName;

    /**
     * An identifier that shows whether to suspend it or complete transaction
     */
    private String processingType;

    /**
     * An identifier that states to book a transaction or not
     *
     */
    private String shouldBook;

    /**
     * An identifier that shows the source system of the transaction that will
     * perform by ATP
     */
    private String sourceSystem;

    /**
     * An identifier which is unqiure for each transaction performed by ATP.
     */
    private String sourceSystemId;
    /**
     * An identifier that store some extra information
     */

    private String displayPolicyNumber;

    private String policyRevisionNumber;

    private Map<String, String> transParamMap;

    public TransactionRequest() {
    }

    public TransactionRequest(String sourceEntityReference, String sourceEntityType, String transactionName,
            String sourceSystemId, String processingType, String shouldBook, String displayPolicyNumber,
            String policyRevisionNumber, String sourceSystem, Map<String, String> transParamMap) {
        super();
        this.sourceEntityReference = sourceEntityReference;
        this.sourceEntityType = sourceEntityType;
        this.transactionName = transactionName;
        this.sourceSystem = sourceSystem;
        this.sourceSystemId = sourceSystemId;
        this.processingType = processingType;
        this.shouldBook = shouldBook;
        this.displayPolicyNumber = displayPolicyNumber;
        this.policyRevisionNumber = policyRevisionNumber;
        this.transParamMap = transParamMap;
    }

    public String getSourceEntityReference() {
        return sourceEntityReference;
    }

    public void setSourceEntityReference(String sourceEntityReference) {
        this.sourceEntityReference = sourceEntityReference;
    }

    public String getSourceEntityType() {
        return sourceEntityType;
    }

    public void setSourceEntityType(String sourceEntityType) {
        this.sourceEntityType = sourceEntityType;
    }

    public String getTransactionName() {
        return transactionName;
    }

    public void setTransactionName(String transactionName) {
        this.transactionName = transactionName;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public Map<String, String> getTransParamMap() {
        return transParamMap;
    }

    public void setTransParamMap(Map<String, String> transParamMap) {
        this.transParamMap = transParamMap;
    }

    public String getSourceSystemId() {
        return sourceSystemId;
    }

    public void setSourceSystemId(String sourceSystemId) {
        this.sourceSystemId = sourceSystemId;
    }

    public String getProcessingType() {
        return processingType;
    }

    public void setProcessingType(String processingType) {
        this.processingType = processingType;
    }

    public String getShouldBook() {
        return shouldBook;
    }

    public void setShouldBook(String shouldBook) {
        this.shouldBook = shouldBook;
    }

    public String getDisplayPolicyNumber() {
        return displayPolicyNumber;
    }

    public void setDisplayPolicyNumber(String displayPolicyNumber) {
        this.displayPolicyNumber = displayPolicyNumber;
    }

    public String getPolicyRevisionNumber() {
        return policyRevisionNumber;
    }

    public void setPolicyRevisionNumber(String policyRevisionNumber) {
        this.policyRevisionNumber = policyRevisionNumber;
    }

    @Override
    public String toString() {
        return "TransactionRequest [sourceEntityReference= " + sourceEntityReference + ", sourceEntityType= "
                + sourceEntityType + ", transactionName= " + transactionName + ", sourceSystem= " + sourceSystem
                + ", transParamMap= " + transParamMap + ", sourceSystemId= " + sourceSystemId + ", processingType= "
                + processingType + ", shouldBook= " + shouldBook + ", displayPolicyNumber= " + displayPolicyNumber
                + ", policyRevisionNumber= " + policyRevisionNumber + " ]";
    }

}
