package com.coverall.mic.rest.policy.service.model;

import java.util.Map;

public class TransactionRequestStatus {

    private String errorMessage;
    private boolean isSuccessful;
    private String statusDetails;
    private String status;
    private Map<String, String> policyData;

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public boolean isSuccessful() {
        return isSuccessful;
    }

    public void setSuccessful(boolean isSuccessful) {
        this.isSuccessful = isSuccessful;
    }

    public String getStatusDetails() {
        return statusDetails;
    }

    public void setStatusDetails(String statusDetails) {
        this.statusDetails = statusDetails;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Map<String, String> getPolicyData() {
        return policyData;
    }

    public void setPolicyData(Map<String, String> policyData) {
        this.policyData = policyData;
    }

}
