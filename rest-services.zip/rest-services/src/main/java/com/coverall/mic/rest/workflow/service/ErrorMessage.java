package com.coverall.mic.rest.workflow.service;

import java.util.Map;

public class ErrorMessage {
	private String jasonPath;
	private String message;
	private String messageType;
	protected Map<String,String> additionalInformation;
	
	public ErrorMessage(){
		
	}
	
    public ErrorMessage(String jasonPath, String  message,String messageType ){
		this.jasonPath = jasonPath;
		this.message = message;
		this.messageType =messageType;
	}
	
	public String getJasonPath() {
		return jasonPath;
	}
	public void setJasonPath(String jasonPath) {
		this.jasonPath = jasonPath;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getMessageType() {
		return messageType;
	}
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}
	/*@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((jasonPath == null) ? 0 : jasonPath.hashCode());
		result = prime * result + ((message == null) ? 0 : message.hashCode());
		result = prime * result + ((messageType == null) ? 0 : messageType.hashCode());
		return result;
	}*/
	
	public Map<String, String> getAdditionalInformation() {
		return additionalInformation;
	}

	public void setAdditionalInformation(Map<String, String> additionalInformation) {
		this.additionalInformation = additionalInformation;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ErrorMessage other = (ErrorMessage) obj;
		if (jasonPath == null) {
			if (other.jasonPath != null)
				return false;
		} else if (!jasonPath.equals(other.jasonPath))
			return false;
		if (message == null) {
			if (other.message != null)
				return false;
		} else if (!message.equals(other.message))
			return false;
		if (messageType == null) {
			if (other.messageType != null)
				return false;
		} else if (!messageType.equals(other.messageType))
			return false;
		return true;
	}
	
}
