package com.coverall.mic.rest.workflow.service;

public class FieldMetaData {
	
	private String hidden;
	private String required;
	private String updatable;
	private String lookUp;
	
	public String getHidden() {
		return hidden;
	}
	public void setHidden(String hidden) {
		this.hidden = hidden;
	}
	public String getRequired() {
		return required;
	}
	public void setRequired(String required) {
		this.required = required;
	}
	public String getUpdatable() {
		return updatable;
	}
	public void setUpdatable(String updatable) {
		this.updatable = updatable;
	}
	public String getLookUp() {
		return lookUp;
	}
	public void setLookUp(String lookUp) {
		this.lookUp = lookUp;
	}

}
