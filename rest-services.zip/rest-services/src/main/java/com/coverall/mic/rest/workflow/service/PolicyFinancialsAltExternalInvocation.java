package com.coverall.mic.rest.workflow.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Map;

import com.coverall.exceptions.ExceptionImpl;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;

public class PolicyFinancialsAltExternalInvocation implements RestExternalInvocationInterface {
	private static final String CONST_IMPORT = "IMPORT";
    private static final String CONST_EXPORT = "EXPORT";
    //private static final String DB_DELETE_PROCEDURE = "{? = call k_producer_management.f_del_producer_authorities(?,?,?,?)}";
    //private static final String PRODUCER_ASSIGNMENTS_DB_DELETE_PROCEDURE =   "{? = call k_producer_management.f_del_producer_assignments(?,?,?,?)}";
	//private static final String DB_PROCEDURE_ARR []  = {"{? = call k_producer_management.f_del_producer_authorities(?,?,?,?)}", "{? = call k_producer_management.f_del_producer_assignments(?,?,?,?)}"};
    private static Logger logger = new Logger();

    private String mode; // = "Import/Export";
    private String user;
   // private Connection conn;

	PolicyFinancialsAltExternalInvocation(){
		 System.out.println(" Inside PolicyFinancialsAltExternalInvocation()");
	}
	PolicyFinancialsAltExternalInvocation(String mode, Connection conn){
		this.mode = mode;
		//this.conn = conn;
		
		 System.out.println(" Inside PolicyFinancialsAltExternalInvocation() mode "+mode+"  conn "+conn);
		
	}
	 
	public void execute(String[] args, Connection conn) throws ExceptionImpl {
		  System.out.println("Test execute PolicyFinancialsAltExternalInvocation");
		
	}
	
	public boolean validate(Map args, Connection conn) throws ExceptionImpl {
       System.out.println("Test Return False PolicyFinancialsAltExternalInvocation validate");
      try {
		Map columnsData = (Map) args.get("columnsData");
		Map params = (Map) args.get("customParams");
		String[] tempArray = (String[]) args.get("arguments");
		
		Map validateParams = (Map) params.get("validate");
		
		String entityReference = (String) validateParams.get("MNL_POLICY_REFERENCE");
		
		Boolean isEntityReferencePresent = isEntityReferencePresent(entityReference,conn);
		
		log(LogEntry.SEVERITY_FATAL, LogEntry.SEVERITY_FATAL, null, "Error in validate: " +
                " Class Name " + this.getClass() + "-" + "Entity Reference "+entityReference+ " not found in System.");
		
		
		if(!isEntityReferencePresent){			
			throw new ExceptionImpl(ExceptionImpl.FATAL, "Entity Reference "+entityReference+ " not found in System.", null);
		}
		
		System.out.println("columnsData " + columnsData);
		System.out.println("params " + params);
		System.out.println("tempArray " + tempArray);
		System.out.println("validateParams " + validateParams);
		//throw new Exception(" Policy Reference not present");
	} catch (Exception e) {

        String errorString = e.getMessage();
        /* Get all the exceptions thrown in the invoked class */
        if (errorString == null) {
            Throwable cause = e.getCause();
            while (cause != null) {
                errorString += " - " + cause.getMessage();
                cause = cause.getCause();
            }
        }
        log(LogEntry.SEVERITY_FATAL, LogEntry.SEVERITY_FATAL, e, "Error in validate: " +
                                " Class Name " + this.getClass() + "-" + errorString);
        throw new ExceptionImpl(ExceptionImpl.FATAL,
                                "Error in processInvocation: " +
                                " Class Name " + this.getClass() + "-" + errorString,
                e);
    
		
	} catch (Throwable e) {
		 log(LogEntry.SEVERITY_FATAL, LogEntry.SEVERITY_FATAL, (Exception) e, "Error in validate: " +
                 " Class Name " + this.getClass() + "-" + e.getMessage());
		 
		 throw new ExceptionImpl(ExceptionImpl.FATAL,
                 "Error in processInvocation: " +
                 " Class Name " + this.getClass() + "-" + e.getMessage(),
 e);
	}
		return false;
    }
	
	private Boolean isEntityReferencePresent(String entityReference,
			Connection conn) throws Throwable {
		boolean isEntityReferencePresent = false;
		 PreparedStatement pst = null;
	     ResultSet rs = null;
	     int count = 0;
		if(conn != null){
			String sql = "select count(*) count from mis_quote_policies where mqp_entity_reference= ? ";
			pst = conn.prepareCall(sql);
			pst.setString(1, entityReference);
			rs = pst.executeQuery();
			while(rs.next()){
				count = rs.getInt("count");
			}
			if(count > 0){
				isEntityReferencePresent = true;
			}
		}
		else {
			log(LogEntry.SEVERITY_FATAL, LogEntry.SEVERITY_FATAL, null, "Error in validate isEntityReferencePresent: " +
                    " Class Name " + this.getClass() + "-" + "Connection conn input parameter is null");
throw new ExceptionImpl(ExceptionImpl.FATAL,
                    "Error in processInvocation: " +
                    " Class Name " + this.getClass() + "-" + "Connection conn input parameter is null",
    null);
		}
		
		
		return isEntityReferencePresent;
	}
	private void log(int severity, int logLevel, Exception e, String message) {
        logger.log(severity, logLevel, e, message);
        if(e != null)
        message = message + e.getMessage();
        LogMinder.getLogMinder().log(severity,
                 getClass().getName(), "",
                 ServletConfigUtil.COMPONENT_PORTAL,
                 new Object[] {  }, message, e,
                 LogMinderDOMUtil.VALUE_MIC);
    }

	public void execute(Map args, Connection conn) throws ExceptionImpl {
	}
	
    public void setMode(String param) {
        this.mode = param;
    }

    public String getMode() {
        return mode;
    }

    public void setUser(String param) { 
        this.user = param;
    }

    public String getUser() {
        return user;
    }

    
    public static class Logger {
        public void log(int severity, int logLevel, Exception e, String message) {
            if (severity >= logLevel) {
                if (e != null) {
                    e.printStackTrace();
                }
                System.out.println(message);
            }
        }
    }
}
