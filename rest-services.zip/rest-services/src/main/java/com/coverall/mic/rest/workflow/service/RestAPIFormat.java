package com.coverall.mic.rest.workflow.service;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.core.MediaType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@Consumes({ MediaType.APPLICATION_JSON })
public class RestAPIFormat implements Serializable {

	// private java.lang.String userName;

	// private java.lang.String password;

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String entityType;

	private Map<String, Map<String, String>> objectFieldValues;

	// private List<Map<String,Map<String,String>>> objectFieldValuesList;

	private Map<String, String> objectFieldValues1;

	private List<Map<String, Object>> objectFieldValuesList;

	private List<ErrorMessage> errors;

	private String restEndPoint;

	private String transactionName;

	private String productName;

	private String transactionID;

	private String logLevel;

	private String clientID;

	private String sendHiddenAttributes;

	private Map<String, String> systemColumns;

	private Map<String, String> premiumColumns;

	private Map<String, FieldMetaData> fieldMetaData;

	public String getEntityType() {
		return entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	/*
	 * public java.lang.String getPassword() { return password; }
	 * 
	 * public void setPassword(java.lang.String password) { this.password =
	 * password; }
	 * 
	 * 
	 * public java.lang.String getUserName() { return userName; }
	 * 
	 * public void setUserName(java.lang.String userName) { this.userName =
	 * userName; }
	 */

	public Map<String, Map<String, String>> getObjectFieldValues() {
		return objectFieldValues;
	}

	public void setObjectFieldValues(Map<String, Map<String, String>> objectFieldValues) {
		this.objectFieldValues = objectFieldValues;
	}

	public List<ErrorMessage> getErrors() {
		return errors;
	}

	public void setErrors(List<ErrorMessage> errors) {
		this.errors = errors;
	}

	public String getRestEndPoint() {
		return restEndPoint;
	}

	public void setRestEndPoint(String restEndPoint) {
		this.restEndPoint = restEndPoint;
	}

	public String getTransactionName() {
		return transactionName;
	}

	public void setTransactionName(String transactionName) {
		this.transactionName = transactionName;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}

	public String getLogLevel() {
		return logLevel;
	}

	public void setLogLevel(String logLevel) {
		this.logLevel = logLevel;
	}

	public String getClientID() {
		return clientID;
	}

	public void setClientID(String clientID) {
		this.clientID = clientID;
	}

	public String getSendHiddenAttributes() {
		return sendHiddenAttributes;
	}

	public void setSendHiddenAttributes(String sendHiddenAttributes) {
		this.sendHiddenAttributes = sendHiddenAttributes;
	}

	/*
	 * public List<Map<String, Map<String, String>>> getObjectFieldValuesList()
	 * { return objectFieldValuesList; }
	 * 
	 * public void setObjectFieldValuesList( List<Map<String, Map<String,
	 * String>>> objectFieldValuesList) { this.objectFieldValuesList =
	 * objectFieldValuesList; }
	 */

	public Map<String, String> getObjectFieldValues1() {
		return objectFieldValues1;
	}

	public void setObjectFieldValues1(Map<String, String> objectFieldValues1) {
		this.objectFieldValues1 = objectFieldValues1;
	}

	public List<Map<String, Object>> getObjectFieldValuesList() {
		return objectFieldValuesList;
	}

	public void setObjectFieldValuesList(List<Map<String, Object>> objectFieldValuesList) {
		this.objectFieldValuesList = objectFieldValuesList;
	}

	public Map<String, String> getSystemColumns() {
		return systemColumns;
	}

	public void setSystemColumns(Map<String, String> systemColumns) {
		this.systemColumns = systemColumns;
	}

	public Map<String, String> getPremiumColumns() {
		return premiumColumns;
	}

	public void setPremiumColumns(Map<String, String> premiumColumns) {
		this.premiumColumns = premiumColumns;
	}

	public Map<String, FieldMetaData> getFieldMetaData() {
		return fieldMetaData;
	}

	public void setFieldMetaData(Map<String, FieldMetaData> fieldMetaData) {
		this.fieldMetaData = fieldMetaData;
	}

}
