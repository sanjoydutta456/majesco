package com.coverall.mic.rest.workflow.service;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringReader;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.Attributes;

import com.coverall.el.FunctionResolver;
import com.coverall.el.InlineExpression;
import com.coverall.el.VariableResolver;
import com.coverall.el.function.DefaultFunctionResolver;
import com.coverall.exceptions.DOMCreationException;
import com.coverall.exceptions.ELException;
import com.coverall.exceptions.ELParseException;
import com.coverall.exceptions.ExceptionImpl;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.el.variable.VariableResolverImpl;
import com.coverall.mt.http.User;
import com.coverall.mt.interfaces.ExternalInvocationInterface;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.ResourceManager;
import com.coverall.mt.xml.DOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;
import com.coverall.util.XMLUtil;

public class RestEntityExport {
	
	 private Document configDoc = null;
	    private String overwrite = "";
	    private HashMap customParams = null;
	    private HashMap tableTagInfo = null;
	    private String insertSQL = "";
	    private String updateSQL = "";
	    private String insertSQLPart1 = "";
	    private String insertSQLPart2 = "";
	    private String updateSQLPart1 = "";
	    private String updateSQLPart2 = "";
	    private String tableBeingProcessed = "";
	    private String columnBeingProcessed = "";
	    private Connection conn = null;
	    private LinkedList processedTableList = null;
	    private ArrayList updateInParams = null;
	    private LinkedHashMap updateOutParams = null;
	    private ArrayList insertInParams = null;
	    private LinkedHashMap insertOutParams = null;
	    private LinkedHashMap columnsData = null;
	    private HashMap descUniqueKeyValues = null;
	    private HashMap columnCustomAttributes = null;
	    private LinkedList columnsInInsertSQL = null;
	    private LinkedList columnsInUpdateSQL = null;
	    private HashMap foreignKeyValues = null;
	    private HashMap targetTablesInfoMap = null;
	    private boolean procedurePresent = false;
	    private boolean readingCDATASection = false;
	    private boolean processingEntityElem = false;
	    private String CDATAString = "";
	    private String failOnError = "true";
	    private String stateColumn = "";
	    private String customerCodeColumn = "";
	    private String parentTable = null;
	    private String clearOldData = null;
	    private static int entityParentNodeTracker = 0;
	    private boolean continueEntityProcessing = true;
	    private HashMap importedDataReport = null;
	    private LinkedList importedDataDetailsList = null;
	    private int totalAdded = 0;
	    private int totalUpdated = 0;
	    private int totalFailed = 0;
	    private HashMap invokedMethods = null;
	    private User user = null;
	    private Map<String, String> dbColumnNameMap = null;
	    private StringBuffer sb = new StringBuffer();
	    private Map<String, String> attributeNameValueMap = null;

	 private static int logLevel = LogEntry.SEVERITY_INFO;

	    private Logger logger = new Logger();

	    private static final String ROOT_ELEM = "ENTITY";
	    private static final String STRUCTURE_ELEM = "STRUCTURE";
	    private static final String TABLE_ELEM = "TABLE";
	    private static final String INSERT_ELEM = "INSERT";
	    private static final String UPDATE_ELEM = "UPDATE";
	    private static final String COLUMN_ELEM = "COLUMN";
	    private static final String COLUMNS_ELEM = "COLUMNS";
	    private static final String QUERY_ELEM = "QUERY";
	    private static final String ROW_PRESENT_CHECK_QUERY_ELEM = "ROW_PRESENT_CHECK_QUERY";
	    private static final String OUT_PARAMS_ELEM = "OUT-PARAMS";
	    private static final String OUT_PARAM_ELEM = "OUT-PARAM";
	    private static final String INVOCATION_ELEM = "INVOCATION";
	    private static final String CLASS_NAME_ELEM = "CLASS_NAME";
	    private static final String IN_PARAMS_ELEM = "IN-PARAMS";
	    private static final String IN_PARAM_ELEM = "IN-PARAM";
	    private static final String METHODS_ELEM = "METHODS";
	    private static final String METHOD_ELEM = "METHOD";
	    private static final String CONST_MODE = "MODE";
	    private static final String CONST_IMPORT = "IMPORT";
	    private static final String OVERWRITE = "overwrite";
	    private static final String LOGLEVEL = "logLevel";

	    private static final String TYPE_ELEM = "type";
	    private static final String SYSDATE = "SYSDATE";
	    private static final String CONST_S_PERSIST_TABLE_ROW = "persistTableRow";
	    private static final String CONST_S_ROW_PRESENT_CHECK_QUERY = "rowPresentCheckQuery";
	    private static final String CONST_S_COLUMNS_DATA = "columnsData";
	    private static final String CONST_S_CUSTOM_PARAMS = "customParams";
	    private static final String CONST_S_ARGUMENTS = "arguments";
	    
	    private static final String CONST_S_INVOCATION_INFO = "invocationInfo";
	    private static final String CONST_S_METHOD_BASE = "methodBase";
	    private static final String CONST_S_BEFORE_INSERT = "beforeInsert";
	    private static final String CONST_S_EACH_ROW = "eachRow";
	    
	    private static final String CONST_S_CLASS_NAME = "className";
	    private static final String CONST_S_IN_PARAMS = "inParams";
	    private static final String CONST_S_METHODS = "methods";
	    private static final String CONST_S_IN_PARAMS_START = ":";
	    private static final String CONST_S_TABLE_COLUMN = "tableColumn";
	    private static final String CONST_S_COLUMN_ATTRIBUTE = "columnAttribute";
	    private static final String CONST_S_USAGE = "usage";
	    private static final String CONST_S_DEFAULT = "default";
	    private static final String CONST_S_TABLE_KEYS = "tableKeys";
	    private static final String CONST_S_TABLE_NAME = "tableName";
	    private static final String CONST_S_ROOT_ELEMENT = "rootElement";
	    private static final String CONST_S_ENTITY_IDENTIFIER_COLUMNS = "entityIdentifierColumns";
	    private static final String CONST_S_TABLE_TAG_NAME = "tableTagName";
	    private static final String CONST_S_ROW_TAG_NAME = "rowTagName";
	    private static final String CONST_S_FAIL_ON_ERROR = "failOnError";
	    private static final String CONST_S_CUSTOMER_CODE = "customerCode";
	    private static final String CONST_S_CUSTOMER_CODES = "customerCodes";
	    private static final String CONST_S_STATE = "stateCode";
	    private static final String CONST_S_STATES = "stateCodes";
	    private static final String CONST_S_NO_DATA_FOUND_OK = "noDataFoundOk";
	    private static final String CONST_S_ID = "id";
	    private static final String CONST_S_PK = "pk";
	    private static final String CONST_S_PK1 = "pk1";
	    private static final String CONST_S_FK = "fk";
	    private static final String CONST_S_UK = "uk";
	    private static final String CONST_CASE_SENSITIVE = "caseSensitive";
	    private static final String CONST_IN_CASE_SENSITIVE = "inCaseSensitive";
	    private static final String CONST_S_PRIMARY_KEY = "PK";
	    private static final String CONST_S_UNIQUE_KEY = "UK";
	    private static final String CONST_S_REMEMBER = "remember";
	    private static final String CONST_S_RETURN = "return";
	    private static final String CONST_S_NAME = "name";
	    private static final String CONST_S_DATATYPE = "datatype";
	    private static final String CONST_S_VALUE = "VALUE";
	    private static final String CONST_S_COMMA = ",";
	    private static final String CONST_S_P_SAVE = "p_save";
	    private static final String CONST_S_UNIQUE_KEYS = "UNIQUE_KEYS";
	    private static final String CONST_S_AND = "AND";
	    private static final String CONST_S_CUSTOM = "CUSTOM: ";
	    private static final String CONST_S_SELECT = "SELECT ";
	    private static final String CONST_S_COLUMN_NAMES = "columnNames";
	    private static final String CONST_S_BOUND_VALUES = "boundValues";
	    private static final String CONST_S_NEW_LINE_CHAR =
	    System.getProperty("line.separator");
	    private static final String CONST_S_USER_CREATED = "USER_CREATED";
	    private static final String CONST_S_USER_MODIFIED = "USER_MODIFIED";
	    private static final String CONST_S_DATE_CREATED = "DATE_CREATED";
	    private static final String CONST_S_DATE_MODIFIED = "DATE_MODIFIED";
	    private static final String CONST_S_FOREIGN_KEY_START = "${fk:";
	    private static final String CONST_S_FOREIGN_KEY_END = "}";
	    private static final String CONST_S_SQL_ON_IMPORT_START = "${sqlOnImport:";
	    private static final String CONST_S_SQL_ON_IMPORT_END = "}";
	    private static final String CONST_S_CLEAR_OLD_DATA = "clearOldData";
	    private static final String CONST_S_TRIM_DATA = "trimData";
	    private static final String CONST_S_INVOKED_METHODS = "invokedMethods";
	    
	    private static final String CALL_INVOCATION = "callInvocation";
	
	public static void main(String[] args) throws Throwable {
		
		
		System.setProperty(DOMUtil.MIC_J2EE_HOME, "D:\\2015\\tomcat-deployment\\target\\mic-tomcat\\micj2eehome");
		String jdbcURL = "jdbc:oracle:thin:@xxxx:xxxx:xxxx";

	        String driverName = "oracle.jdbc.driver.OracleDriver";
	        //this.importedDataReport = importedDataReport;
	        Connection conn = null;
              try {
				Class.forName(driverName);
      conn = DriverManager.getConnection(jdbcURL, "MIC_XX", "MIC_XX");
      
      HashMap params = new HashMap();
		params.put("mode", "EXPORT");
		params.put("configFilePath", "");
		params.put("exportXMLPath", "");
		params.put("overwrite", "true");
		params.put(CONST_S_CUSTOMER_CODE, "SE");
		params.put("logLevel", LogEntry.SEVERITY_INFO + "");
		params.put("entityType", "Supplement");
		params.put("failOnError", "false");
		params.put("sinkException", "true");
		params.put("searchid", "65");
		params.put("transactionID", "Q20CA0017092117000");
		params.put("descriptor_name", "Supplement_descriptor.xml");
		User user = null;
		
		String customerCode =(String) params.get(CONST_S_CUSTOMER_CODE);
		String configFilePath = ResourceManager.locateConfDir(ServletConfigUtil.COMPONENT_FRAMEWORK, 
    			customerCode, "Supplement_descriptor.xml") + "Supplement_descriptor.xml";
		

			RestEntityExport processor = new RestEntityExport(conn, params, user);
			
			//processor.exportEntity(driverName, jdbcURL,  "MIC_QB", "MIC_QB", "D:\\temp\\temp1\\export.xml", configFilePath, params, params, user);
			
			StringBuffer sb = processor.exportJsonEntity(conn, null, params, user);
			System.out.println(""+sb.toString());
			} catch (Exception e) {
				e.printStackTrace();
				throw new Exception("Exception is : "+ e.getMessage());
				
				
			}
              finally{
            	  conn.close();
              }
	}
	
	public RestEntityExport(Connection conn2, HashMap customParams, User user) {
		
		this.processedTableList = new LinkedList();
        this.insertInParams = new ArrayList();
        this.insertOutParams = new LinkedHashMap();
        this.updateInParams = new ArrayList();
        this.updateOutParams = new LinkedHashMap();
        this.columnsData = new LinkedHashMap();
        this.descUniqueKeyValues = new HashMap();
        this.columnCustomAttributes = new HashMap();
        this.targetTablesInfoMap = new HashMap();
        this.columnsInInsertSQL = new LinkedList();
        this.columnsInUpdateSQL = new LinkedList();
        this.invokedMethods = new HashMap();
        this.importedDataReport = new HashMap();
        this.user = user;
        this.conn =conn2;
        this.customParams = customParams;
        this.attributeNameValueMap = new HashMap();
	}
	
	/**
     * Entry point to export an entity from the database to an XML when the exportXMLPath is specified.
     * To be used with a command line invocation. (The descriptor cannot contain variables like var:sqlExecute)
     * - Obtains the DB connection.
     * - Forms the descriptor Document Object.
     * - Calls the function down the line to export the entity.
     * @param driverName oracle driver name
     * @param jdbcURL jdbc url
     * @param userId DB Userid
     * @param password DB password
     * @param exportXMLPath Path where the exported file is to be stored
     * @param configFilePath Path where the entity descriptor is present
     * @param params Contains parameter values passed through the request
     * @param user Application user logged in
     * @throws ExceptionImpl thrown in case of any error
     */
    public   StringBuffer exportJsonEntity( Connection con,
            PrintWriter out, HashMap params, User user) throws ExceptionImpl {
        /* Variable declaration.*/
        if (null == params) {
            params = new HashMap<String,Object>();
        }
        String configFilePath = null;

        try {
            /*Get connection */
            if (null == con) {
               
                con = ConnectionPool.getConnection(user);
            }

            /* Get Log Level */
            String logLevelStr = (String)customParams.get(LOGLEVEL);
            if (null != logLevelStr){
                logLevel = Integer.parseInt(logLevelStr);
            }

            /* Get PrintWriter to the write the Export XML */
           
            
         	
            /* Obtain the descriptor Document */
            Document configDoc = null;
            String customerCode =(String) params.get(CONST_S_CUSTOMER_CODE);
            String descriptor_name = (String) params.get("descriptor_name");
            configFilePath = ResourceManager.locateConfDir(ServletConfigUtil.COMPONENT_FRAMEWORK, 
        			customerCode, descriptor_name) + descriptor_name;
    				
    		configDoc = XMLUtil.createDom(new File(configFilePath));

            /* Create the export XML */
            exportEntity(configDoc, con, out, params, params, user);
            
            

            /* Flush the XML generated */
           // out.flush();
            return sb;
        } catch (DOMCreationException dce) {
            log(LogEntry.SEVERITY_FATAL, logLevel, dce,
                "Descriptor at path " + configFilePath + " is invalid or does not exist.");
            throw new ExceptionImpl(ExceptionImpl.FATAL,
                                    "Descriptor at path " + configFilePath +
                                    " is invalid or does not exist.", dce);
        } catch (Exception e) {
            log(LogEntry.SEVERITY_FATAL, logLevel, e, e.getMessage());
            throw new ExceptionImpl(ExceptionImpl.FATAL, e.getMessage(), e);
        } finally {
            try {
                if ((con != null) && (!con.isClosed())) {
                    con.close();
                }
            } catch (SQLException e) {
                log(LogEntry.SEVERITY_FATAL, logLevel, e, e.getMessage());
            }
           /* try {
                if (out != null) {
                    out.close();
                }
            } catch (Exception e) {
                log(LogEntry.SEVERITY_FATAL, logLevel, e, e.getMessage());
            }*/
        }

    }
    
    /**
     * Entry point to export an entity from the database to an XML when the exportXMLPath is specified.
     * To be used with a command line invocation. (The descriptor cannot contain variables like var:sqlExecute)
     * - Obtains the DB connection.
     * - Forms the descriptor Document Object.
     * - Calls the function down the line to export the entity.
     * @param driverName oracle driver name
     * @param jdbcURL jdbc url
     * @param userId DB Userid
     * @param password DB password
     * @param exportXMLPath Path where the exported file is to be stored
     * @param configFilePath Path where the entity descriptor is present
     * @param params Contains parameter values passed through the request
     * @param user Application user logged in
     * @throws ExceptionImpl thrown in case of any error
     */
    public   PrintWriter exportEntity(String driverName, String jdbcURL, String userId,
                             String password, String exportXMLPath,
                             String configFilePath, HashMap params,
                             HashMap customParams, User user) throws ExceptionImpl {
        /* Variable declaration.*/
        Connection con = null;
        PrintWriter out = null;
        if (null == params) {
            params = new HashMap<String,Object>();
        }

        try {
            /*Get connection */
            if (null == user) {
                Class.forName(driverName);
                con = DriverManager.getConnection(jdbcURL, userId, password);
            } else {
                con = ConnectionPool.getConnection(user);
            }

            params.put("conn",con);

            /* Get Log Level */
            String logLevelStr = (String)customParams.get(LOGLEVEL);
            if (null != logLevelStr){
                logLevel = Integer.parseInt(logLevelStr);
            }

            /* Get PrintWriter to the write the Export XML */
            if(out == null)
            out = new PrintWriter(new BufferedWriter(new FileWriter(exportXMLPath, true)));

            /* Obtain the descriptor Document */
            Document configDoc = XMLUtil.createDom(new File(configFilePath));

            /* Create the export XML */
            exportEntity(configDoc, con, out, params, customParams, user);

            /* Flush the XML generated */
           // out.flush();
            return out;
        } catch (DOMCreationException dce) {
            log(LogEntry.SEVERITY_FATAL, logLevel, dce,
                "Descriptor at path " + configFilePath + " is invalid or does not exist.");
            throw new ExceptionImpl(ExceptionImpl.FATAL,
                                    "Descriptor at path " + configFilePath +
                                    " is invalid or does not exist.", dce);
        } catch (Exception e) {
            log(LogEntry.SEVERITY_FATAL, logLevel, e, e.getMessage());
            throw new ExceptionImpl(ExceptionImpl.FATAL, e.getMessage(), e);
        } finally {
            try {
                if ((con != null) && (!con.isClosed())) {
                    con.close();
                }
            } catch (SQLException e) {
                log(LogEntry.SEVERITY_FATAL, logLevel, e, e.getMessage());
            }
            try {
                if (out != null) {
                    out.close();
                }
            } catch (Exception e) {
                log(LogEntry.SEVERITY_FATAL, logLevel, e, e.getMessage());
            }
        }

    }
    
    /**
     * Entry point for entity export from the database to an XML.
     * To be used with invocation from the MIC Application.
     * This methods generates the Export XML.
     * @param configDoc A Document object of the entity Descriptor.
     * @param con A connection to the database.
     * @param out The Printwriter object wrapped over the response. Used to write the export XML.
     * @param params Contains parameter values passed through the request
     * @param user Application user logged in
     * @throws ExceptionImpl
     */
    public void exportEntity(Document configDoc, Connection con,
                             PrintWriter out, HashMap params,
                             HashMap customParams, User user) throws ExceptionImpl {

        Element rootElement = null;
        Element structureElem = null;
        Element tableElem = null;

        String entityType = "";
        int indentCount = 1;
        HashMap foreignKeys = null;

        try {
            /* Set the Log Level */
            String logLevelStr = (String)customParams.get(LOGLEVEL);
            if (null != logLevelStr){
                logLevel = Integer.parseInt(logLevelStr);
            }

            /* Obtain the root value and the entity type */
            rootElement = configDoc.getDocumentElement();
            entityType = rootElement.getAttribute(TYPE_ELEM);

            /* Obtain the structure Element */
            structureElem =
                    XMLUtil.getChildElementByTagName(rootElement, STRUCTURE_ELEM);
            
          setDBColumnNameMap(configDoc);

            if (structureElem == null) {
                throw new ExceptionImpl(ExceptionImpl.FATAL,
                                        "Invalid XML Format: Tag " +
                                        STRUCTURE_ELEM +
                                        " is missing in the descriptor.",
                                        null);
            } else {
                /* Process all the child table elements for the structure element */
            	
            	 tableElem =
                         XMLUtil.getChildElementByTagName(structureElem,
                         TABLE_ELEM);
            	
            	 /* tableElem =
                          XMLUtil.getElementByNameAndAttribute(structureElem,
                          TABLE_ELEM,
                          CONST_S_TABLE_TAG_NAME,
                          "Supplement");*/
            	processTable(entityType, tableElem, out, con, params,
                              customParams, foreignKeys, indentCount, user);
            }

            indentCount--;
            printTab(out, indentCount);
            //out.print("</" + ROOT_ELEM + ">");
            //out.print("}");
            //sb.append("}");

        } catch (Exception e) {
            throw new ExceptionImpl(ExceptionImpl.FATAL, e.getMessage(), e);
        }
    }
    
public int deleteEntity(Document configDoc, Connection con,
		            PrintWriter out, HashMap params,
		            HashMap customParams, User user) throws ExceptionImpl {
		
		Element rootElement = null;
		Element structureElem = null;
		Element tableElem = null;
		int rowsDeleted = 0;
		String entityType = "";
		int indentCount = 1;
		HashMap foreignKeys = null;
		
		try {
		/* Set the Log Level */
		String logLevelStr = (String)customParams.get(LOGLEVEL);
		if (null != logLevelStr){
		logLevel = Integer.parseInt(logLevelStr);
		}
		
		/* Obtain the root value and the entity type */
		rootElement = configDoc.getDocumentElement();
		entityType = rootElement.getAttribute(TYPE_ELEM);
		
		/* Obtain the structure Element */
		structureElem =
		   XMLUtil.getChildElementByTagName(rootElement, STRUCTURE_ELEM);
		
		setDBColumnNameMap(configDoc);
		
		if (structureElem == null) {
		throw new ExceptionImpl(ExceptionImpl.FATAL,
		                       "Invalid XML Format: Tag " +
		                       STRUCTURE_ELEM +
		                       " is missing in the descriptor.",
		                       null);
		} else {
		/* Process all the child table elements for the structure element */
		
		tableElem =
		        XMLUtil.getChildElementByTagName(structureElem,
		        TABLE_ELEM);
		
		/* tableElem =
		         XMLUtil.getElementByNameAndAttribute(structureElem,
		         TABLE_ELEM,
		         CONST_S_TABLE_TAG_NAME,
		         "Supplement");*/
		rowsDeleted = deleteTable(tableElem,  con, params,
		             customParams,   user);
		}
		
		//indentCount--;
		//printTab(out, indentCount);
		//out.print("</" + ROOT_ELEM + ">");
		//out.print("}");
		//sb.append("}");
		
		} catch (Exception e) {
		throw new ExceptionImpl(ExceptionImpl.FATAL, e.getMessage(), e);
		}
		return rowsDeleted;
		}
    
	private Map<String, String> setDBColumnNameMap(Document configDoc) throws Exception {
		dbColumnNameMap =   new HashMap<String, String>();
				
		try {
			//Document configDoc = XMLUtil.createDom(new File(configFile));
	        configDoc.getDocumentElement().normalize();
	        NodeList nList = configDoc.getElementsByTagName("COLUMN");
	        for (int temp = 0; temp < nList.getLength(); temp++) {
	     		Node nNode = nList.item(temp);
	     		Element eElement = (Element) nNode;
	     		String colName = eElement.getAttribute("attributename");
	     		String dbColumnName = eElement.getAttribute("id");
	            dbColumnNameMap.put(dbColumnName,colName);	     		
	     	}
		} catch (Exception e) {
			e.printStackTrace();
			 log(LogEntry.SEVERITY_FATAL, logLevel, e, "Errorin setDBColumnNameMap :" + e.getMessage());
			throw new Exception(" Exception in setDBColumnNameMap : "+ e.getMessage());
		}
		return dbColumnNameMap;
	}
	
	private HashMap getTableTagInfo(Element tableElem) throws ExceptionImpl {

        HashMap tableTagInfo = new HashMap();
        HashMap tableKeys = new HashMap();

        Node tableNameNode = null;
        Node tableTagNode = null;
        Node rowTagNode = null;
        Node tableAttribNode = null;

        Element invocationElem = null;
        Element classNameElem = null;
        Element inParamsElem = null;
        Element inParamElem = null;
        Element methodsElem = null;
        Element methodElem = null;
        Element rowPresentCheckQueryElem = null;

        NodeList inParamsList = null;
        NodeList methodList = null;

        try {
            /* Get all the Attribute Values */
            NamedNodeMap tableAttribs = tableElem.getAttributes();

            /* Table Name is mandatory */
            tableNameNode = tableAttribs.getNamedItem(CONST_S_TABLE_NAME);
            if (tableNameNode == null || "".equals(tableNameNode.getNodeValue()) ||
                tableNameNode.getNodeValue() == null) {
                throw new ExceptionImpl(ExceptionImpl.FATAL,
                                        "Invalid XML Format: Atribute " +
                                        CONST_S_TABLE_NAME +
                                        " is missing for a table, in the descriptor.",
                        null);
            } else {
                tableTagInfo.put(CONST_S_TABLE_NAME, tableNameNode.getNodeValue());
            }

            /* Get table data trim flag value */
            tableTagNode = tableAttribs.getNamedItem(CONST_S_TRIM_DATA);
            if (tableTagNode == null || "".equals(tableTagNode.getNodeValue()) ||
                tableTagNode.getNodeValue() == null) {
                tableTagInfo.put(CONST_S_TABLE_TAG_NAME,
                                 tableNameNode.getNodeValue());
            } else {
                tableTagInfo.put(CONST_S_TRIM_DATA,
                                 tableTagNode.getNodeValue());
            }

            /* Get tableTagName value */
            tableTagNode = tableAttribs.getNamedItem(CONST_S_TABLE_TAG_NAME);
            if (tableTagNode == null || "".equals(tableTagNode.getNodeValue()) ||
                tableTagNode.getNodeValue() == null) {
                tableTagInfo.put(CONST_S_TABLE_TAG_NAME,
                                 tableNameNode.getNodeValue());
            } else {
                tableTagInfo.put(CONST_S_TABLE_TAG_NAME,
                                 tableTagNode.getNodeValue());
            }

            /* Get rowTagName value */
            rowTagNode = tableAttribs.getNamedItem(CONST_S_ROW_TAG_NAME);
            if (rowTagNode == null || "".equals(rowTagNode.getNodeValue()) ||
                rowTagNode.getNodeValue() == null) {
                tableTagInfo.put(CONST_S_ROW_TAG_NAME,
                                 (String)tableTagInfo.get(CONST_S_TABLE_TAG_NAME) +
                                 "_");
            } else {
                tableTagInfo.put(CONST_S_ROW_TAG_NAME, rowTagNode.getNodeValue());
            }

            /* Loop through the remaining attributes */
            for (int attribIndex = 0; attribIndex < tableAttribs.getLength();
                 attribIndex++) {
                tableAttribNode = tableAttribs.item(attribIndex);

                if (tableAttribNode.getNodeName().equals(CONST_S_TABLE_NAME) ||
                    tableAttribNode.getNodeName().equals(CONST_S_TABLE_TAG_NAME) ||
                    tableAttribNode.getNodeName().equals(CONST_S_ROW_TAG_NAME)) {
                    continue;
                }

                if (tableAttribNode.getNodeName().equals(CONST_S_FAIL_ON_ERROR)) {
                    if (tableAttribNode.getNodeValue() != null &&
                        !"".equals(tableAttribNode.getNodeValue())) {
                        tableTagInfo.put(CONST_S_FAIL_ON_ERROR,
                                         tableAttribNode.getNodeValue());
                        continue;
                    }
                }

                if (tableAttribNode.getNodeName().startsWith(CONST_S_PK) ||
                    tableAttribNode.getNodeName().startsWith(CONST_S_FK)) {
                    if (null == tableKeys.get(tableAttribNode.getNodeName())) {
                        if (tableAttribNode.getNodeValue() != null &&
                            !"".equals(tableAttribNode.getNodeValue())) {
                            tableKeys.put(tableAttribNode.getNodeName(),
                                    tableAttribNode.getNodeValue());
                            continue;
                        } else {
                            throw new ExceptionImpl(ExceptionImpl.FATAL,
                                                    "Invalid XML Format: Attribute " +
                                                    tableAttribNode.getNodeName() +
                                                    " does not have a value specified for table " +
                                                    (String)tableTagInfo.get(CONST_S_TABLE_NAME) +
                                                    ".", null);
                        }
                    }
                }else{
                    tableTagInfo.put(tableAttribNode.getNodeName(),
                            tableAttribNode.getNodeValue());
                }
            }
            tableTagInfo.put(CONST_S_TABLE_KEYS, tableKeys);

            /* Check if ROW_PRESENT_CHECK_QUERY tag is present for the table */
            rowPresentCheckQueryElem = XMLUtil.getChildElementByTagName(tableElem, ROW_PRESENT_CHECK_QUERY_ELEM);
            String queryText = "";
            if (rowPresentCheckQueryElem != null) {
                if (null == rowPresentCheckQueryElem.getFirstChild()) {
                   throw new ExceptionImpl(ExceptionImpl.FATAL,
                                           "Invalid XML Format: Tag " +
                                           rowPresentCheckQueryElem.getNodeName() +
                                           " for table " +
                                            (String)tableTagInfo.get(CONST_S_TABLE_NAME) +
                                           " does not have a query value specified. ", null);
                } else {
                   queryText = rowPresentCheckQueryElem.getFirstChild().getNodeValue();
                   tableTagInfo.put(CONST_S_ROW_PRESENT_CHECK_QUERY, queryText);
                }
            }

            /* Check if a custom invocation is specified for the table */
            //if((clearOldData==null) || (!clearOldData.equals("false"))) { 
                invocationElem = XMLUtil.getChildElementByTagName(tableElem, INVOCATION_ELEM);
            HashMap invocationInfo = null;
            LinkedHashMap inParamsInfo = null;
            HashMap inParamInfo = null;
            String inParamName = "";
            NamedNodeMap invocationAttribs = null;
            if (invocationElem != null) {
                invocationInfo = new HashMap();

                /* Get all the attributes of the INVOCATION tag */
                invocationAttribs = invocationElem.getAttributes();
                for (int i = 0; i < invocationAttribs.getLength(); i++) {
                    Node attrib = invocationAttribs.item(i);
                        invocationInfo.put(attrib.getNodeName(), attrib.getNodeValue());
                }

                /* Get the CLASS_NAME tag */
                    classNameElem = XMLUtil.getChildElementByTagName(invocationElem, CLASS_NAME_ELEM);

                /* CLASS_NAME tag must have a value specified */
                if (!(classNameElem != null && classNameElem.getFirstChild() != null)) {
                        throw new ExceptionImpl(ExceptionImpl.FATAL,
                                                "Invalid XML Format: Tag " +
                                                invocationElem.getNodeName() +
                                                " for table " +
                                                 (String)tableTagInfo.get(CONST_S_TABLE_NAME) +
                                                " does not have a Class Name value specified. ", null);
                }
                    invocationInfo.put(CONST_S_CLASS_NAME, classNameElem.getFirstChild().getNodeValue());

                /* Get the IN-PARAMS tag */
                    inParamsElem = XMLUtil.getChildElementByTagName(invocationElem, IN_PARAMS_ELEM);

                if (inParamsElem != null) {
                    /* Get the list of all IN-PARAM tags */
                        inParamsList = inParamsElem.getElementsByTagName(IN_PARAM_ELEM);
                    inParamsInfo = new LinkedHashMap();
                    NamedNodeMap inParamAttribs = null;
                        for (int inParamIndex = 0; inParamIndex < inParamsList.getLength();
                             inParamIndex++) {
                        inParamElem = (Element) inParamsList.item(inParamIndex);

                        /* Get the attributes of the IN-PARAM tag */
                        inParamAttribs = inParamElem.getAttributes();
                        inParamInfo = new HashMap();
                        for (int i = 0; i < inParamAttribs.getLength(); i++) {
                            Node attrib = inParamAttribs.item(i);
                                inParamInfo.put(attrib.getNodeName(), attrib.getNodeValue());
                        }

                        if (inParamElem.getFirstChild() != null) {
                            /* Get the name of the IN-PARAM tag */
                                inParamName = inParamElem.getFirstChild().getNodeValue();
                        } else {
                                throw new ExceptionImpl(ExceptionImpl.FATAL,
                                                        "Invalid XML Format: Tag " +
                                                        inParamElem.getNodeName() +
                                                        " for table " +
                                                         (String)tableTagInfo.get(CONST_S_TABLE_NAME) +
                                                        " at index " + (inParamIndex + 1) +
                                                        " does not have a Parameter Name specified. ", null);
                        }
                        inParamsInfo.put(inParamName, inParamInfo);
                    }

                    invocationInfo.put(CONST_S_IN_PARAMS, inParamsInfo);
                }

	                /* Get the running methods */
	                methodsElem = XMLUtil.getChildElementByTagName(invocationElem, METHODS_ELEM);
	                if (methodsElem != null) {
	                    /* Get the list of all IN-PARAM tags */
	                    methodList = methodsElem.getElementsByTagName(METHOD_ELEM);
	                    TreeMap methodsInfo = new TreeMap();
	                    NamedNodeMap methodAttribs = null;
	                    String methodName = null;
	                    String methodId = null;
	                    for (int methodIndex = 0; methodIndex < methodList.getLength();
	                             methodIndex++) {
	                        methodElem = (Element) methodList.item(methodIndex);
	
	                        /* Get the attributes of the IN-PARAM tag */
	                        methodAttribs = methodElem.getAttributes();
	                        HashMap methodInfo = new HashMap();
	                        for (int i = 0; i < methodAttribs.getLength(); i++) {
	                            Node attrib = methodAttribs.item(i);
	                            String nodeName = attrib.getNodeName();
	                            String nodeValue = attrib.getNodeValue();
	                            methodInfo.put(nodeName, nodeValue);
	                            
	                            if(CONST_S_NAME.equalsIgnoreCase(nodeName)) {
	                            	methodName = nodeName;
	                            }
	                        }
	                        
	                        if(methodName == null || "".equalsIgnoreCase(methodName)) {
                                throw new ExceptionImpl(ExceptionImpl.FATAL,
                                        "Invalid XML Format: Tag " +
                                        methodElem.getNodeName() +
                                        " for table " +
                                         (String)tableTagInfo.get(CONST_S_TABLE_NAME) +
                                        " at index " + (methodIndex + 1) +
                                        " does not have a method Name specified. ", null);
	                        }
	                        
	                        methodId = (String)methodInfo.get(CONST_S_ID);
	                        if(methodId == null || "".equalsIgnoreCase(methodId)) {
                                throw new ExceptionImpl(ExceptionImpl.FATAL,
                                        "Invalid XML Format: Tag " +
                                        methodName +
                                        " for table " +
                                         (String)tableTagInfo.get(CONST_S_TABLE_NAME) +
                                        " at index " + (methodIndex + 1) +
                                        " does not have a method id specified. ", null);
	                        }	                        

	                        if(methodsInfo.containsKey(methodId)) {
                                throw new ExceptionImpl(ExceptionImpl.FATAL,
                                        "Invalid XML Format: Tag " +
                                        methodName +
                                        " for table " +
                                         (String)tableTagInfo.get(CONST_S_TABLE_NAME) +
                                        " at index " + (methodIndex + 1) +
                                        " has a duplicate method id. ", null);	                        	
	                        }
	                        methodsInfo.put(methodId, methodInfo);
	                    }
	
	                    invocationInfo.put(CONST_S_METHODS, methodsInfo);                                       
	                }
                

                tableTagInfo.put(CONST_S_INVOCATION_INFO, invocationInfo);
            }
            //}
        } catch (ExceptionImpl e) {
            log(LogEntry.SEVERITY_FATAL, logLevel, null,
                    "Error getting TABLE tag information :" + e.getMessage());
            throw e;
        }

        return tableTagInfo;
    }
	
	 public static class Logger {
	        public void log(int severity, int logLevel, Exception e, String message) {
	            if (severity >= logLevel) {
	                if (e != null) {
	                    e.printStackTrace();
	                }
	                System.out.println(message);
	            }
	        }
	    }

	    /**
	     * Set customized logger
	     * @param logger new logger
	     */
	    public void setLogger(Logger logger) {
	        this.logger = logger;
	    }

	    /**
	     * Private method to display Exceptions.
	     * @param e object of Exception class.
	     * @param message Exception message.
	     */
	    private void log(int severity, int logLevel, Exception e, String message) {
	        logger.log(severity, logLevel, e, message);
	    }
	    
	    /**
	     * This method logs information about the table row about to be imported.
	     * It includes table name, column names and their values.
	     * @throws Exception
	     */
	    private void logImportTableInfo() throws Exception {
	        Map.Entry entry = null;
	        String columnName = "";
	        String colValue = "";
	        String tableName = "";
	        LinkedHashMap targetTableUniqueKeys = null;
	        String rowPresentCheckQuery = null;
	        Iterator uniqueKeysIt = null;
	        ArrayList keyList = null;
	        String logMessage = "";

	        log(LogEntry.SEVERITY_INFO, logLevel, null, "Importing a row");
	        log(LogEntry.SEVERITY_INFO, logLevel, null, "---------------");

	        tableName = (String) tableTagInfo.get(CONST_S_TABLE_NAME);
	        targetTableUniqueKeys =
	                (LinkedHashMap)((HashMap)targetTablesInfoMap.get(tableName)).get(CONST_S_UNIQUE_KEYS);
	        rowPresentCheckQuery = (String)tableTagInfo.get(CONST_S_ROW_PRESENT_CHECK_QUERY);

	        /* Log which row is attempted to be imported */
	        if (null == rowPresentCheckQuery || "".equals(rowPresentCheckQuery)) {

	            logMessage = "\nProcessing a row with key values ";
	            /* If unique keys are specified in the descriptor (descUniqueKeyValues), use the information. Else, use the physical unique key
	             * information obtained(targetTableUniqueKeys) */
	            if (descUniqueKeyValues != null && descUniqueKeyValues.size() > 0) {
	                uniqueKeysIt = descUniqueKeyValues.entrySet().iterator();
	                entry = (Map.Entry) uniqueKeysIt.next();
	                Set set = ((HashMap)entry.getValue()).keySet();
	                ArrayList tempKeyList = new ArrayList();
	                tempKeyList.addAll(set);
	                if(tempKeyList.size() > 0) {
	                    keyList = tempKeyList;
	                }
	            } else {
	                uniqueKeysIt = targetTableUniqueKeys.entrySet().iterator();
	                while (uniqueKeysIt.hasNext()) {
	                    entry = (Map.Entry) uniqueKeysIt.next();
	                    if (((String) entry.getKey()).indexOf(CONST_S_UNIQUE_KEY) != -1) {
	                        keyList = (ArrayList) entry.getValue();
	                        break;
	                    }
	                }
	            }

	            if (keyList == null || keyList.size() == 0) {
	                 throw new ExceptionImpl(ExceptionImpl.FATAL, "No unique key(s) found for table " + tableName + ". A select query, to decide whether to insert or update, cannot be run. Please check the target database or the descriptor.", null);
	            } else {
	                for (int columnIndex = 0; columnIndex < keyList.size();
	                     columnIndex++) {

	                    columnName = (String) keyList.get(columnIndex);
	                    HashMap columnValues = (HashMap)columnsData.get(columnName);
	                    if (columnValues != null) {
	                        colValue = (String) columnValues.get(CONST_S_VALUE);
	                    } else {
	                        colValue = "";
	                    }

	                    logMessage += columnName + "=[";
	                    if (colValue != null && !"".equals(colValue)) {
	                        if (!colValue.startsWith(CONST_S_CUSTOM)) {
	                            logMessage += colValue;
	                        } else {
	                            logMessage += "Value to be obtained from target database";
	                        }
	                    }
	                    logMessage += "],";
	                }
	            }
	            logMessage += " in table " + tableName;
	        } else {
	            logMessage = "\nProcessing a row in table " + tableName + ". There are no keys specified for this table.";
	        }

	        log(LogEntry.SEVERITY_INFO, logLevel, null, logMessage);
	    }
	    
	    /**
	     * This method sets the target table information in the variable targetTablesInfoMap.
	     * The information contains
	     * - The column names and the types.
	     * - The Unique Keys - A map with the key as index name and the value as the list of columns in that index.
	     * (Includes primary key and unique key indexes)
	     * @param tableName
	     * @return
	     */
	    private void setTargetTableInfo(String tableName) throws ExceptionImpl {

	        PreparedStatement pst = null;
	        ResultSet targetTableColumnInfoRS = null;
	        ResultSet targetTableIndexInfoRS = null;
	        HashMap targetTableInfoMap = null;
	        LinkedHashMap targetTableUniqueKeys = null;
	        ArrayList uniqueKeyColumns = null;
	        String indexInfoQuery = null;

	        try {
	            if (!targetTablesInfoMap.containsKey(tableName)) {
	                targetTableColumnInfoRS =
	                        conn.getMetaData().getColumns(null, null, tableName,
	                        null);
	                targetTableInfoMap = new HashMap();
	                while (targetTableColumnInfoRS.next()) {
	                    targetTableInfoMap.put(targetTableColumnInfoRS.getString("COLUMN_NAME"),
	                                           targetTableColumnInfoRS.getString("TYPE_NAME"));
	                }

	                indexInfoQuery =
	                        "SELECT INDEX_NAME, COLUMN_NAME FROM ALL_IND_COLUMNS WHERE TABLE_NAME = ? ORDER BY INDEX_NAME";
	                pst = conn.prepareStatement(indexInfoQuery);
	                pst.setString(1, tableName);

	                targetTableIndexInfoRS = pst.executeQuery();

	                targetTableUniqueKeys = new LinkedHashMap();
	                while (targetTableIndexInfoRS.next()) {
	                    String indexName =
	                        targetTableIndexInfoRS.getString("INDEX_NAME");
	                    String indexColumnName =
	                        targetTableIndexInfoRS.getString("COLUMN_NAME");
	                    if (null != indexName) {
	                        if (targetTableUniqueKeys.size() == 0 ||
	                            targetTableUniqueKeys.get(indexName) == null) {
	                            uniqueKeyColumns = new ArrayList();
	                        } else {
	                            uniqueKeyColumns =
	                                    (ArrayList)targetTableUniqueKeys.get(indexName);
	                        }
	                        uniqueKeyColumns.add(indexColumnName);
	                        targetTableUniqueKeys.put(indexName, uniqueKeyColumns);
	                    }
	                }
	                targetTableInfoMap.put(CONST_S_UNIQUE_KEYS,
	                        targetTableUniqueKeys);
	                targetTablesInfoMap.put(tableName, targetTableInfoMap);
	            }
	        } catch (Exception e) {
	            log(LogEntry.SEVERITY_FATAL, logLevel, e, "Error setting Target Table Information for table " + tableName + ":" + e.getMessage());
	            throw new ExceptionImpl(ExceptionImpl.FATAL,
	                                    "Error setting Target Table Information for table " +
	                                    tableName, e);
	        } finally {
	            try {
	                DBUtil.close(targetTableColumnInfoRS, null);
	            } catch (SQLException e) {
	                log(LogEntry.SEVERITY_FATAL, logLevel, e, e.getMessage());
	            }
	            try {
	                DBUtil.close(targetTableIndexInfoRS, pst);
	            } catch (SQLException e) {
	                log(LogEntry.SEVERITY_FATAL, logLevel, e, e.getMessage());
	            }
	        }
	    }
	    
	    /**
	     * The method sets information about a table. The method updates the map descUniqueKeyValues
	     * with the unique key name(e.g uk1) as the key and a list of columns in the key, as the value.
	     * It uses the unique key information from the descriptor, if present.
	     * @param tableElem The table element for which the data is required.
	     * @throws ExceptionImpl to be thrown in case of any error.
	     */
	    private void setTableUniqueKeys(Element tableElem) throws ExceptionImpl {

	        //ArrayList uniqueKeyColumns = null;
	        HashMap uniqueKeyColumns = null;
	        HashMap customAttributes = new HashMap();

	        Element columnsElem = null;
	        Element columnElem = null;

	        NodeList columnList = null;
	        NamedNodeMap columnAttribs = null;

	        String columnName = null;
	        String tableName = (String) tableTagInfo.get(CONST_S_TABLE_NAME);

	        /* Get the unique key information from the descriptor */
	        columnsElem =
	                XMLUtil.getChildElementByTagName(tableElem, COLUMNS_ELEM);
	        if (columnsElem != null) {
	            columnList = columnsElem.getElementsByTagName(COLUMN_ELEM);
	            for (int colsIndex = 0; colsIndex < columnList.getLength();
	                 colsIndex++) {
	                columnElem = (Element) columnList.item(colsIndex);

	                columnAttribs = columnElem.getAttributes();
	                for (int i = 0; i < columnAttribs.getLength(); i++) {
	                    Node attrib = columnAttribs.item(i);
	                    columnName = columnElem.getAttribute(CONST_S_ID);
	                    if ((attrib.getNodeName().startsWith(CONST_S_UK)) || (attrib.getNodeName().startsWith(CONST_CASE_SENSITIVE))) {
	                        uniqueKeyColumns = (HashMap)descUniqueKeyValues.get(attrib.getNodeName());
	                        if (uniqueKeyColumns == null) {
	                            uniqueKeyColumns = new HashMap();
	                        }
	                        String caseSensitiveValue = columnElem.getAttribute(CONST_CASE_SENSITIVE);
	                        if (columnName != null && !"".equals(columnName)) {
	                            if(isColumnToTreatCaseSensitive(caseSensitiveValue)) {
	                                uniqueKeyColumns.put(columnElem.getAttribute(CONST_S_ID), CONST_CASE_SENSITIVE);
	                            } else {
	                                uniqueKeyColumns.put(columnElem.getAttribute(CONST_S_ID), CONST_IN_CASE_SENSITIVE);
	                            }
	                        } else {
	                            throw new ExceptionImpl(ExceptionImpl.FATAL,
	                                                    "Invalid XML Format: Attribute " +
	                                                    CONST_S_ID +
	                                                    " is missing for a column in table " +
	                                                    tableName +
	                                                    " , in the descriptor.", null);
	                        }
	                        descUniqueKeyValues.put(attrib.getNodeName(), uniqueKeyColumns);
	                    }else if (attrib.getNodeName().equals(CONST_S_STATE) &&
	                              "true".equals(attrib.getNodeValue())){
	                        stateColumn = columnName; // attrib.getNodeName();
	                    }else if (attrib.getNodeName().equals(CONST_S_CUSTOMER_CODE) &&
	                              "true".equals(attrib.getNodeValue())){
	                        customerCodeColumn = columnName;
	                    } else if (attrib.getNodeName().equals(
	                            CONST_S_NO_DATA_FOUND_OK)
	                        && "true".equals(attrib.getNodeValue())) {
	                        customAttributes.put(CONST_S_NO_DATA_FOUND_OK, "true");
	                        columnCustomAttributes.put(columnName, customAttributes);
	                    }
	                }
	            }
	        } else {
	            throw new ExceptionImpl(ExceptionImpl.FATAL,
	                                    "Invalid XML Format: Tag " +
	                                    COLUMNS_ELEM +
	                                    " is missing for the table " +
	                                    tableName + " , in the descriptor.",
	                    null);
	        }
	    }
	    
	    private boolean isColumnToTreatCaseSensitive(String caseSensitiveAttributeValue) {
	        if((null != caseSensitiveAttributeValue) && !("null".equals(caseSensitiveAttributeValue))
	            && ("false".equals(caseSensitiveAttributeValue))) {
	            return false;
	        }
	        return true;
	    }
	    
	    /**
	     * This method checks whether, for the table, an SQL needs to be called or
	     * an stored procedure has been specified in the descriptor.
	     * It calls appropriate methods depending on the case.
	     * @param tableElem The table element, row of which has been encountered.
	     * @param tableTagInfo The info about the table element.
	     * @throws ExceptionImpl to be thrown in case of any error.
	     */
	    private void processTableRow(Element tableElem,
	                                 HashMap tableTagInfo) throws ExceptionImpl {

	        Element insertElem = null;
	        Element updateElem = null;
	        String tableName = "";

	        /* See if an insert & update procedure is specified */
	        insertElem = XMLUtil.getChildElementByTagName(tableElem, INSERT_ELEM);
	        updateElem = XMLUtil.getChildElementByTagName(tableElem, UPDATE_ELEM);
	        tableName = (String) tableTagInfo.get(CONST_S_TABLE_NAME);
	        if (insertElem == null || updateElem == null) {
	            /* Persist using Insert/Update SQL */
	            insertSQLPart1 = "INSERT INTO " + tableName + "(";
	            insertSQLPart2 = ") VALUES (";
	            /* Form the update SQL, in case it's needed */
	            updateSQLPart1 = "UPDATE " + tableName + " SET ";
	        } else {
	            /* Persist using Insert/Update Procedure */
	            procedurePresent = true;
	            processProcedure(insertElem);
	            /* Process Update Procedure, in case it's needed */
	            processProcedure(updateElem);
	        }
	    }
	    
	    /**
	     * This method reads the stored procedure info from the descriptor using the procedureElem and
	     * forms the call string to be used to make a call. It then sets it in the member variable insertSQL or updateSQL.
	     * eg { ? = call xxxxxxx(?,?,?,?)}
	     * @param procedureElem The insert or update element in the descriptor
	     * @throws ExceptionImpl to be thrown in case of any error.
	     */
	    private void processProcedure(Element procedureElem) throws ExceptionImpl {

	        /* Handle Insert/Update Procedure here */
	        HashMap procedureInfo = null;
	        NamedNodeMap procedureAttribs = null;
	        Element procedureTextElem = null;
	        Element outParamsElem = null;
	        NodeList outParamsList = null;
	        Element outParam = null;
	        ArrayList inParams = new ArrayList();
	        LinkedHashMap outParams = new LinkedHashMap();
	        StringBuffer procedureTextValue = new StringBuffer("{ call ");

	        /* Gather Procedure information from the descriptor */
	        procedureInfo = new HashMap();
	        procedureAttribs = procedureElem.getAttributes();
	        for (int insertAttribIndex = 0;
	             insertAttribIndex < procedureAttribs.getLength();
	             insertAttribIndex++) {
	            procedureInfo.put(procedureAttribs.item(insertAttribIndex).getNodeName(),
	                              procedureAttribs.item(insertAttribIndex).getNodeValue());
	        }

	        procedureTextElem =
	                XMLUtil.getChildElementByTagName(procedureElem, QUERY_ELEM);
	        if (procedureTextElem == null) {
	            throw new ExceptionImpl(ExceptionImpl.FATAL,
	                                    "QUERY Element not present in the " +
	                                    procedureElem.getNodeName() +
	                                    " tag in the descriptor for table " +
	                                    tableBeingProcessed, null);
	        } else {
	            procedureTextValue.append(procedureTextElem.getFirstChild().getNodeValue());
	            procedureTextValue.insert(procedureTextValue.lastIndexOf(")"),
	                    CONST_S_COMMA);
	        }

	        /* Get information about the In-Params */
	        int inParamStartIndex =
	            procedureTextValue.indexOf(CONST_S_IN_PARAMS_START);
	        int inParamEndIndex = procedureTextValue.indexOf(CONST_S_COMMA);
	        while (procedureTextValue.indexOf(CONST_S_IN_PARAMS_START) != -1) {
	            inParams.add(procedureTextValue.substring(inParamStartIndex,
	                    inParamEndIndex));
	            procedureTextValue.replace(inParamStartIndex, inParamEndIndex,
	                                       " ?");
	            inParamStartIndex =
	                    procedureTextValue.indexOf(CONST_S_IN_PARAMS_START);
	            inParamEndIndex =
	                    procedureTextValue.indexOf(CONST_S_COMMA, inParamStartIndex);
	        }

	        /* Get information about the Out-Params */
	        outParamsElem =
	                XMLUtil.getChildElementByTagName(procedureElem, OUT_PARAMS_ELEM);
	        outParamsList = outParamsElem.getChildNodes();
	        String paramType = "";
	        HashMap outParamInfo = null;
	        boolean returnProcessed = false;
	        for (int outParamIndex = 0; outParamIndex < outParamsList.getLength();
	             outParamIndex++) {
	            if (outParamsList.item(outParamIndex).getNodeName().equals(OUT_PARAM_ELEM)) {
	                outParamInfo = new HashMap();
	                outParam = (Element) outParamsList.item(outParamIndex);
	                /* datatype attribute */
	                outParamInfo.put(CONST_S_DATATYPE,
	                                 outParam.getAttribute(CONST_S_DATATYPE));
	                /* remember attribute */
	                if (outParam.getAttribute(CONST_S_REMEMBER) != null) {
	                    outParamInfo.put(CONST_S_REMEMBER,
	                                     outParam.getAttribute(CONST_S_REMEMBER));
	                }
	                /* type attribute */
	                paramType = outParam.getAttribute(TYPE_ELEM);
	                if (paramType != null && paramType.equals(CONST_S_RETURN)) {
	                    outParamInfo.put(TYPE_ELEM, paramType);
	                    if (!returnProcessed) {
	                        /* Append to the Procedure call string to be formed */
	                        procedureTextValue.insert(procedureTextValue.indexOf("{") +
	                                                  1, " ? = ");
	                        returnProcessed = true;
	                    } else {
	                        throw new ExceptionImpl(ExceptionImpl.FATAL,
	                                                "Return parameter for the " +
	                                                procedureElem.getNodeName() +
	                                                " procedure for table " +
	                                                tableBeingProcessed +
	                                                " already processed", null);
	                    }
	                } else {
	                    /* Append to the insert Procedure call string to be formed */
	                    procedureTextValue.insert(procedureTextValue.lastIndexOf(")"),
	                                              " ?" + CONST_S_COMMA);
	                }
	                /* Store all attribute values against the out-param name */
	                outParams.put(outParam.getFirstChild().getNodeValue(),
	                        outParamInfo);
	            }
	        }
	        procedureTextValue.deleteCharAt(procedureTextValue.lastIndexOf(CONST_S_COMMA));
	        if (procedureElem.getNodeName().equalsIgnoreCase(INSERT_ELEM)) {
	            insertSQL = procedureTextValue.toString() + " } ";
	            insertInParams = inParams;
	            insertOutParams = outParams;
	        } else {
	            updateSQL = procedureTextValue.toString() + " } ";
	            updateInParams = inParams;
	            updateOutParams = outParams;
	        }
	    }
	    
	    /**
	     * This method validates the table row to be imported on the basis of the customer code and state code list
	     * passed as control values.
	     * It sets a flag in customParams giving whether the row can be imported or not.
	     * @param customParams
	     * @return
	     */
	    private void validateRow(HashMap customParams) throws Exception {

	        String tableName = null;
	        boolean persistTableRow = false;

	        tableName = (String) tableTagInfo.get(CONST_S_TABLE_NAME);

	        // Get the column information for STATE_CODE and CUSTOMER_CODE columns
	        // Hashmap if parent node is being iterated
	        if ((entityParentNodeTracker <= 1)) {
	            if (isValidRow(tableName)) {
	                persistTableRow = true;
	            } else {
	                continueEntityProcessing = false;
	                persistTableRow = false;
	            }
	        } else {
	            if (continueEntityProcessing) {
	                persistTableRow = true;
	            } else {
	               log(LogEntry.SEVERITY_INFO, logLevel, null, "---------------------------------------------");
	               log(LogEntry.SEVERITY_INFO, logLevel, null, "SKIPPING TABLE ROW AS PARENT ROW NOT IMPORTED ");
	               log(LogEntry.SEVERITY_INFO, logLevel, null, "---------------------------------------------");
	            }
	        }

	        customParams.put(CONST_S_PERSIST_TABLE_ROW, Boolean.valueOf(persistTableRow));
	    }

	    private boolean isValidRow(String tableName) throws Exception {
	        String stateValue = null;
	        String custCodeValue = null;
	        String validStatesList = "";
	        String validCustomerCodeList = "";
	        HashMap columnInfo = null;

	        validStatesList = (String) customParams.get(CONST_S_STATES);
	        validCustomerCodeList =  (String)customParams.get(CONST_S_CUSTOMER_CODES);

	        if (validStatesList != null) {
	            columnInfo = (HashMap) columnsData.get(stateColumn);
	            validStatesList = validStatesList == null ? "" : validStatesList;
	            if (columnInfo != null) {
	                stateValue = (String) columnInfo.get(CONST_S_VALUE);
	                stateValue = stateValue == null ? "" : stateValue;
	            } else {
	                log(LogEntry.SEVERITY_INFO, logLevel, null, "Error - Table " + tableName +
	                          " can not be imported. Licensed state(s) specified but STATE_CODE column missing in table.");
	                validStatesList = null;
	            }
	        }
	        if (validCustomerCodeList != null) {
	            columnInfo = (HashMap) columnsData.get(customerCodeColumn);
	            validCustomerCodeList = validCustomerCodeList == null ? "" : validCustomerCodeList;
	            if (columnInfo != null) {
	                custCodeValue = (String) columnInfo.get(CONST_S_VALUE);
	                custCodeValue = custCodeValue == null ? "" : custCodeValue;
	            } else {
	                log(LogEntry.SEVERITY_INFO, logLevel, null, "Error - Table " + tableName +
	                          " can not be imported. Customer Code(s) specified but CUSTOMER_CODE column missing in table.");
	                validCustomerCodeList = null;
	            }
	        }

	        if (validStatesList == null && validCustomerCodeList == null) {
	            return true;
	        }

	        if ((validStatesList != null) && (validCustomerCodeList != null)) {
	            if (("".equals(stateValue) || "".equals(validStatesList) ||
	                    validStatesList.indexOf(stateValue) != -1) &&
	                    ("".equals(custCodeValue) || "".equals(validCustomerCodeList) ||
	                     validCustomerCodeList.indexOf(custCodeValue) != -1)) {
	                return true;
	            }
	        } else if ((validStatesList != null) && (validCustomerCodeList == null)) {
	            if (("".equals(stateValue) || "".equals(validStatesList) ||
	                    validStatesList.indexOf(stateValue) != -1)) {
	                return true;
	            }
	        } else if ((validStatesList == null) && (validCustomerCodeList != null)) {
	            if (("".equals(custCodeValue) || "".equals(validCustomerCodeList) ||
	                     validCustomerCodeList.indexOf(custCodeValue) != -1)) {
	                return true;
	            }
	        }

	        log(LogEntry.SEVERITY_INFO, logLevel, null, "---------------------------------------------------------------");
	        log(LogEntry.SEVERITY_INFO, logLevel, null, "SKIPPING TABLE ROW AS CUSTOMER CODE/STATE CODE CRITERIA FAILED ");
	        log(LogEntry.SEVERITY_INFO, logLevel, null, " Control Customer Code Value(s) = " + validCustomerCodeList);
	        log(LogEntry.SEVERITY_INFO, logLevel, null, " Entity Customer Code Value = " + custCodeValue);
	        log(LogEntry.SEVERITY_INFO, logLevel, null, " Control State Value(s) = " + validStatesList);
	        log(LogEntry.SEVERITY_INFO, logLevel, null, " Entity State Value = " + stateValue);
	        log(LogEntry.SEVERITY_INFO, logLevel, null, "---------------------------------------------------------------");
	        return false;
	    }
	    
	    /**
	     * This method reinitializes the member variables to enable handling of the next table.
	     * @throws ExceptionImpl to be thrown in case of any error.
	     */
	    private void reInitialize() throws ExceptionImpl {
	        columnsData = new LinkedHashMap();
	        descUniqueKeyValues = new HashMap();
	        columnCustomAttributes = new HashMap();
	        insertInParams = new ArrayList();
	        updateInParams = new ArrayList();
	        procedurePresent = false;
	        insertSQL = "";
	        insertSQLPart1 = "";
	        insertSQLPart2 = "";
	        updateSQL = "";
	        updateSQLPart1 = "";
	        updateSQLPart2 = "";
	        insertOutParams = new LinkedHashMap();
	        updateOutParams = new LinkedHashMap();
	        tableTagInfo = null;
	        columnsInInsertSQL = new LinkedList();
	        columnsInUpdateSQL = new LinkedList();
	    }
	    
	    private void processData(Map invocationInfo) throws ExceptionImpl {
	    	String className = (String) invocationInfo.get(CONST_S_CLASS_NAME);
	    	boolean methodBase = "true".equalsIgnoreCase((String)invocationInfo.get(CONST_S_METHOD_BASE)); 
	        boolean persistTableRow = ((Boolean)customParams.get(CONST_S_PERSIST_TABLE_ROW)).booleanValue();
	        boolean callInvocation = !"N".equalsIgnoreCase((String)customParams.get(CALL_INVOCATION));
	                
	    	if(methodBase) {            
	    		Map methodsInfo =(Map)invocationInfo.get(CONST_S_METHODS);
	    		Iterator it = methodsInfo.keySet().iterator();
	    		
	    		ArrayList invokedMethodList = (ArrayList)invokedMethods.get(className);
	    		if(invokedMethodList == null) {
	    			invokedMethodList = new ArrayList();
	    		}
	    		
	    		if(persistTableRow) {
		    		while(it.hasNext()) {
		    			String methodId = (String)it.next();
		    			Map methodAttrs = (Map)methodsInfo.get(methodId);
		    			String methodName = (String)methodAttrs.get(CONST_S_NAME);
		                boolean invokeBeforeInsert = "true".equalsIgnoreCase((String)methodAttrs.get(CONST_S_BEFORE_INSERT));
		                boolean invokeForEachRow = "true".equalsIgnoreCase((String)methodAttrs.get(CONST_S_EACH_ROW));
		
						if (invokeBeforeInsert && callInvocation) {
							if (invokeForEachRow ||  !invokedMethodList.contains(methodName)) {
								processInvocation(invocationInfo, customParams,
										foreignKeyValues, methodName);
								invokedMethodList.add(methodName);
							}					
						}
		    		}    		
	    		}
	    		persistRow();
	            
	            it = methodsInfo.keySet().iterator();
	            if(persistTableRow) {
		            while(it.hasNext()) {
		    			String methodId = (String)it.next();
		    			Map methodAttrs = (Map)methodsInfo.get(methodId);
		    			String methodName = (String)methodAttrs.get(CONST_S_NAME);
		                boolean invokeBeforeInsert = "true".equalsIgnoreCase((String)methodAttrs.get(CONST_S_BEFORE_INSERT));
		                boolean invokeForEachRow = "true".equalsIgnoreCase((String)methodAttrs.get(CONST_S_EACH_ROW));
		
						if (!invokeBeforeInsert && callInvocation) {
							if (invokeForEachRow ||  !invokedMethodList.contains(methodName)) {
								processInvocation(invocationInfo, customParams,
										foreignKeyValues, methodName);
								invokedMethodList.add(methodName);
							}					
						}
		    		}
	            }
				invokedMethods.put(className, invokedMethodList);
	    	} else {                                    	
	            boolean invokeBeforeInsert = "true".equalsIgnoreCase((String)((Map)tableTagInfo.get(CONST_S_INVOCATION_INFO)).get(CONST_S_BEFORE_INSERT));
	            String clearOldDataValue = (String)customParams.get(CONST_S_CLEAR_OLD_DATA);
	            boolean clearOldData = false;
	            
	            if(clearOldDataValue == null || !"false".equalsIgnoreCase(clearOldDataValue)) {
	            	clearOldData = true;
	            }
	            
	            if(clearOldData && callInvocation && invokeBeforeInsert){
	            	if(persistTableRow) {
	            		processInvocation(invocationInfo, customParams, foreignKeyValues, null);
	            	}
	            	customParams.put(CALL_INVOCATION,"N");
	            }
	            persistRow();
	            
	            if (clearOldData && !invokeBeforeInsert) {
	            	if(persistTableRow) {
	            		processInvocation(invocationInfo, customParams, foreignKeyValues, null);
	            	}
	            }
	    	}    	
	    }

	    /**
	     * This method inserts or updates the row using either a insert/Update SQL OR an insert/update procedure.
	     * It updates if the overwrite flag is true and the row already exists.
	     * It also reinitializes the member variables to handle the next table.
	     * @throws ExceptionImpl
	     */
	    private void persistRow() throws ExceptionImpl {
	        CallableStatement cst = null;
	        Map.Entry entry = null;
	        String columnName = "";
	        String colValue = "";
	        String tableName = "";
	        String rowTagName = "";
	        String isRootElement = "";
	        String entityIdentifierColumns = "";
	        String entityIdentifierValue = "";
	        String primaryKeyColumn = "";
	        Iterator keyIt = null;
	        LinkedHashMap targetTableUniqueKeys = null;
	        HashMap primaryKeyValues = null;
	        String rowPresentCheckQuery = null;
	        boolean persistTableRow = false;
	        HashMap importedDataDetailsMap = new HashMap();
	        String failedMsg = "";
	        try {
	            /* Behaviour is
	                 * Overwrite    Row Exists  Result
	                 *  true          true      update
	                 *  true          false     insert
	                 *  false         true      Skip (No error thrown)
	                 *  false         false     insert
	             */

	            tableName = (String) tableTagInfo.get(CONST_S_TABLE_NAME);
	            rowTagName = (String) tableTagInfo.get(CONST_S_ROW_TAG_NAME);
	            isRootElement = (String)tableTagInfo.get(CONST_S_ROOT_ELEMENT);
	            primaryKeyColumn = (String)tableTagInfo.get(CONST_S_PK1);
	            entityIdentifierColumns = (String)tableTagInfo.get(CONST_S_ENTITY_IDENTIFIER_COLUMNS);
	            if (null != entityIdentifierColumns && !"".equals(entityIdentifierColumns)){
	                if (importedDataDetailsList == null){
	                    importedDataDetailsList = new LinkedList();
	                }
	                String[] columnsList = entityIdentifierColumns.split(",");
	                columnName = "";
	                for (int i=0; i < columnsList.length; i++){
	                    columnName = columnsList[i].trim();
	                    HashMap columnValues = (HashMap)columnsData.get(columnName);
	                    if (columnValues != null) {
	                        entityIdentifierValue = (String) columnValues.get(CONST_S_VALUE);
	                    } else {
	                        entityIdentifierValue = "";
	                    }
	                    importedDataDetailsMap.put(columnName, entityIdentifierValue);
	                }
	            }
	            targetTableUniqueKeys =
	                    (LinkedHashMap)((HashMap)targetTablesInfoMap.get(tableName)).get(CONST_S_UNIQUE_KEYS);
	            rowPresentCheckQuery = (String)tableTagInfo.get(CONST_S_ROW_PRESENT_CHECK_QUERY);

	            persistTableRow = ((Boolean)customParams.get(CONST_S_PERSIST_TABLE_ROW)).booleanValue();

	            if (persistTableRow) {
	                primaryKeyValues =
	                        runSelectOnCurrentRow(tableName, targetTableUniqueKeys, rowPresentCheckQuery);
	                if (primaryKeyValues != null && primaryKeyValues.size() > 0) {
	                    log(LogEntry.SEVERITY_INFO, logLevel, null, "Row already exists");
	                    /* Row exists */
	                    /* Save the primary key values to be used later as foreign keys */
	                    keyIt = primaryKeyValues.entrySet().iterator();
	                    while (keyIt.hasNext()) {
	                        entry = (Map.Entry) keyIt.next();
	                        columnName = (String) entry.getKey();
	                        colValue = (String) entry.getValue();
	                        if (foreignKeyValues == null) {
	                            foreignKeyValues = new HashMap();
	                        }
	                        foreignKeyValues.put(columnName, colValue);
	                    }

	                    /* Update if flag is true */
	                    if ("true".equalsIgnoreCase(overwrite) &&
	                       (null == rowPresentCheckQuery || "".equals(rowPresentCheckQuery))) {
	                        /* If a table has a query to check the presence of the row, it doesn't have unique keys and
	                        * cannot be updated */
	                        if (!procedurePresent) {
	                            /* If Insert/Update SQL is to be used */
	                            updateRowThruSQL(tableName, targetTableUniqueKeys);
	                        } else {
	                            /* PL/SQL Procedure is to be used. updateSQL contains the procedure call string. */
	                            updateRowThruProcedure(tableName, primaryKeyValues);
	                        }
	                        if ("true".equalsIgnoreCase(isRootElement)){
	                            importedDataDetailsMap.put("status", "UPDATED");
	                            totalUpdated++;
	                        }
	                    }
	                } else {
	                    log(LogEntry.SEVERITY_INFO, logLevel, null, "Row does not exist.");
	                    /* Row does not exist. Insert */
	                    if (!procedurePresent) {
	                        /* If Insert/Update SQL is to be used */
	                        insertRowThruSQL(tableName);
	                    } else {
	                        /* PL/SQL Procedure is to be used. insertSQL contains the procedure call string. */
	                        insertRowThruProcedure(tableName);
	                    }
	                    if ("true".equalsIgnoreCase(isRootElement)){
	                        importedDataDetailsMap.put("status", "ADDED");
	                        totalAdded++;
	                    }
	                }
	            }

	        } catch (Exception e) {
	            totalFailed++;
	            failedMsg +=  e.getMessage();
	            log(LogEntry.SEVERITY_FATAL, logLevel, e, "Import failed: " + CONST_S_NEW_LINE_CHAR +
	                                    e.getMessage());
	            throw new ExceptionImpl(ExceptionImpl.FATAL,
	                                    "Import failed: " + CONST_S_NEW_LINE_CHAR +
	                                    e.getMessage(), e.getCause());
	        } finally {
	        	
	            try {
	                DBUtil.close(null, cst);
	            } catch (SQLException e) {
	                log(LogEntry.SEVERITY_FATAL, logLevel, e, e.getMessage());
	                
	            }

	            if ((null != entityIdentifierColumns && !"".equals(entityIdentifierColumns)) || totalFailed != 0){
	                if (!importedDataReport.containsKey("entityType")){
	                    importedDataReport.put("entityType", rowTagName);
	                }

	                /* Something failed. Need to find if the parent was being updated or added and reduce the count accordingly.
	                 * Also, need to update the status as FAILED.
	                 */
	                if (totalFailed != 0){
	                    // The root parent for current table is the one that was last imported
	                    if (importedDataDetailsList.size() > 0){
	                        importedDataDetailsMap = (HashMap)importedDataDetailsList.get(importedDataDetailsList.size() - 1);
	                    }
	                    String attemptedOperation = (String)importedDataDetailsMap.get("status");
	                    if ("UPDATED".equals(attemptedOperation)){
	                        totalUpdated--;
	                    }else if ("ADDED".equals(attemptedOperation)){
	                        totalAdded--;
	                    }
	                    importedDataDetailsMap.put("status", "FAILED");
	                    importedDataDetailsMap.put("failedMsg", importedDataReport.get("failedMsg"));
	                    importedDataDetailsMap.put("failedErrorCode", importedDataReport.get("failedErrorCode"));
	                    if (importedDataDetailsList.size() > 0){
	                        importedDataDetailsList.remove(importedDataDetailsList.size() - 1);
	                    }
	                }
	                importedDataDetailsList.add(importedDataDetailsMap);
//	                importedDataDetailsMap.put("failedMsg", "");
	                importedDataReport.put("totalAdded", totalAdded + "");
	                importedDataReport.put("totalUpdated", totalUpdated + "");
	                importedDataReport.put("totalFailed", totalFailed + "");
	                importedDataReport.put("LogDetails", importedDataDetailsList);
//	                importedDataReport.put("failedMsg", failedMsg);
	            }
	        }
	    }
	    
	    /**
	     * This method inserts a new row into the DB using a SQL statement.
	     * @param tableName
	     * @throws ExceptionImpl
	     */
	    private void insertRowThruSQL(String tableName) throws ExceptionImpl {

	        PreparedStatement pst = null;
	        ResultSet rs = null;
	        LinkedList boundValues = null;
	        LinkedList columnNames = null;
	        HashMap boundData = null;

	        try {
	            log(LogEntry.SEVERITY_INFO, logLevel, null, "\n\nInserting a row through SQL statement");

	            /* Form the insert SQL */
	            insertSQL =
	                    insertSQLPart1.substring(0, insertSQLPart1.lastIndexOf(CONST_S_COMMA)) +
	                    insertSQLPart2.substring(0,
	                                             insertSQLPart2.lastIndexOf(CONST_S_COMMA)) +
	                    ")";

	            pst = conn.prepareStatement(insertSQL);

	            /* Bind column variables */
	            boundData =
	                    bindSQLColumnVariables(pst, tableName, columnsInInsertSQL);

	            try {
	                pst.execute();
	            } catch (Exception e) {
	                /* Log what was the insert statement attempted, with the values */
	                String errorString =
	                    "Error in inserting a row in table " + tableName;
	                errorString +=
	                        "<BR><TABLE border=1 width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" class\"OraTableColumnHeaderIconButton\">";
	                // Get column names
	                columnNames =
	                        (LinkedList)boundData.get(CONST_S_COLUMN_NAMES);

	                if (columnNames != null && columnNames.size() > 0) {
	                    Iterator itr = columnNames.iterator();
	                    errorString += "<TR>";
	                    while (itr.hasNext()) {
	                        errorString +=
	                                "<TD align=\"center\" class=\"OraTableColumnHeaderIconButton\">" +
	                                (String)itr.next() + "</TD>";
	                    }
	                    errorString += "</TR>";
	                }

	                boundValues =
	                        (LinkedList)boundData.get(CONST_S_BOUND_VALUES);
	                if (boundValues != null && boundValues.size() > 0) {
	                    // get column values
	                    Iterator it = boundValues.iterator();
	                    errorString += "<TR>";
	                    String value = "";
	                    while (it.hasNext()) {
	                        value = (String) it.next();
	                        value = (value == null ? "" : value);
	                        errorString +=
	                                "<TD class=\"OraTableCellText\">" + value +
	                                "</TD>";
	                    }
	                    errorString += "</TR>";
	                }
	                errorString += "</TABLE>";

	                // throw error with formated message.
	                log(LogEntry.SEVERITY_FATAL, logLevel, e, CONST_S_NEW_LINE_CHAR +  errorString);
	                throw new ExceptionImpl(ExceptionImpl.FATAL,
	                                        CONST_S_NEW_LINE_CHAR +
	                                        errorString, e);
	            }
	        } catch (Exception e) {
	            log(LogEntry.SEVERITY_FATAL, logLevel, e, e.getMessage());
	            throw new ExceptionImpl(ExceptionImpl.FATAL, "Error in insertRowThruSQL for table " + tableName + ":" + e.getMessage(), e);
	        } finally {
	            try {
	                DBUtil.close(rs, pst);
	            } catch (SQLException e) {
	                log(LogEntry.SEVERITY_FATAL, logLevel, e, e.getMessage());
	            }
	        }
	    }

	    /**
	     * This method updates the row using an SQL statement.
	     * @param tableName
	     * @param targetTableUniqueKeys
	     * @throws ExceptionImpl
	     */
	    private void updateRowThruSQL(String tableName,
	            LinkedHashMap targetTableUniqueKeys) throws ExceptionImpl {
	        PreparedStatement pst = null;
	        LinkedList boundValues = null;
	        LinkedList columnNames = null;
	        HashMap boundData = null;
	        String whereClause = null;
	        int rowsUpdated = 0;
	        ArrayList keyList = null;
	        Map.Entry entry = null;
	        Iterator uniqueKeysIt = null;
	        String columnName = "";
	        String colValue = "";

	        try {
	            log(LogEntry.SEVERITY_INFO, logLevel, null, "\n\nUpdating a row through SQL Statement");

	            /* Form the update SQL */
	            updateSQL =
	                    updateSQLPart1 + updateSQLPart2.substring(0, updateSQLPart2.lastIndexOf(CONST_S_COMMA));

	            /* Form the where clause on unique keys */
	            /* If unique keys are specified in the descriptor (descUniqueKeyValues), use the information. Else, use the physical unique key
	             * information obtained(targetTableUniqueKeys) */
	            if (descUniqueKeyValues != null && descUniqueKeyValues.size() > 0) {
	                uniqueKeysIt = descUniqueKeyValues.entrySet().iterator();
	                entry = (Map.Entry) uniqueKeysIt.next();
	                Set set = ((HashMap)entry.getValue()).keySet();
	                ArrayList tempKeyList = new ArrayList();
	                tempKeyList.addAll(set);
	                if(tempKeyList.size() > 0) {
	                    keyList = tempKeyList;
	                }
	            } else {
	                uniqueKeysIt = targetTableUniqueKeys.entrySet().iterator();
	                while (uniqueKeysIt.hasNext()) {
	                    entry = (Map.Entry) uniqueKeysIt.next();
	                    if (((String) entry.getKey()).indexOf(CONST_S_UNIQUE_KEY) != -1) {
	                        keyList = (ArrayList) entry.getValue();
	                        break;
	                    }
	                }
	            }

	            if (keyList == null || keyList.size() == 0) {
	                throw new ExceptionImpl(ExceptionImpl.FATAL, "No unique key(s) found for table " + tableName + ". The update SQL query cannot be run. Please check the target database or the descriptor.", null);
	            } else {
	                whereClause = " WHERE ";
	                for (int columnIndex = 0; columnIndex < keyList.size();
	                     columnIndex++) {

	                    columnName = (String) keyList.get(columnIndex);
	                    HashMap columnValues = (HashMap)columnsData.get(columnName);
	                    if (columnValues != null) {
	                        colValue = (String) columnValues.get(CONST_S_VALUE);
	                    } else {
	                        colValue = "";
	                    }

	                    if (colValue == null || "".equals(colValue)) {
	                        whereClause += keyList.get(columnIndex) + " IS NULL AND ";
	                    } else {
	                        whereClause += keyList.get(columnIndex) + " = ? AND ";
	                        columnsInUpdateSQL.add(keyList.get(columnIndex));
	                    }
	                }
	            }

	            updateSQL +=
	                    whereClause.substring(0, whereClause.lastIndexOf(CONST_S_AND));

	            pst = conn.prepareStatement(updateSQL);

	            /* Bind column variables */
	            boundData =
	                    bindSQLColumnVariables(pst, tableName, columnsInUpdateSQL);

	            try {
	                rowsUpdated = pst.executeUpdate();
	            } catch (Exception e) {
	                /* Log what was the update statement attempted, with the values */
	                String errorString =
	                    "Error in updating a row in table " + tableName;
	                errorString +=
	                        "<BR><TABLE border=1 width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" class\"OraTableColumnHeaderIconButton\">";
	                // Get column names
	                int columnCount = 0;
	                columnNames = (LinkedList) boundData.get(CONST_S_COLUMN_NAMES);
	                if (columnNames != null && columnNames.size() > 0) {
	                    Iterator itr = columnNames.iterator();
	                    errorString += "<TR>";
	                    String colName = "";
	                    while (itr.hasNext()) {
	                        colName = (String) itr.next();
	                        if (errorString.indexOf(colName) == -1) {
	                            errorString +=
	                                    "<TD align=\"center\" class=\"OraTableColumnHeaderIconButton\">" +
	                                    colName + "</TD>";
	                            columnCount++;
	                        }
	                    }
	                    errorString += "</TR>";
	                }

	                // get column values
	                int colIndex = 0;
	                boundValues = (LinkedList) boundData.get(CONST_S_BOUND_VALUES);
	                if (boundValues != null && boundValues.size() > 0) {
	                    Iterator it = boundValues.iterator();
	                    errorString += "<TR>";
	                    String value = "";
	                    while (it.hasNext()) {
	                        value = (String) it.next();
	                        value = (value == null ? "" : value);
	                        if (colIndex < columnCount) {
	                            errorString +=
	                                    "<TD class=\"OraTableCellText\">" + value +
	                                    "</TD>";
	                            colIndex++;
	                        }
	                    }
	                    errorString += "</TR>";
	                }
	                errorString += "</TABLE>";
	                // throw error with formated message.
	                log(LogEntry.SEVERITY_FATAL, logLevel, e, CONST_S_NEW_LINE_CHAR + errorString);
	                throw new ExceptionImpl(ExceptionImpl.FATAL,
	                        CONST_S_NEW_LINE_CHAR + errorString,
	                        e);
	            }

	        } catch (Exception e) {
	            log(LogEntry.SEVERITY_FATAL, logLevel, e, e.getMessage());
	            throw new ExceptionImpl(ExceptionImpl.FATAL, "Error in updateRowThruSQL for table " + tableName + ":" + e.getMessage(), e);
	        } finally {
	            try {
	                DBUtil.close(null, pst);
	            } catch (SQLException e) {
	                log(LogEntry.SEVERITY_FATAL, logLevel, e, e.getMessage());
	            }
	        }
	    }

	    /**
	     * Runs a select query using the unique keys. Used to determine if the row already exists.
	     * @param tableName
	     * @param targetTableUniqueKeys
	     * @return
	     */
	    private HashMap runSelectOnCurrentRow(String tableName,
	                                          LinkedHashMap targetTableUniqueKeys,
	                                          String rowPresentCheckQuery) throws ExceptionImpl {

	        PreparedStatement pst = null;
	        ResultSet rs = null;
	        String selectSQL = null;
	        String whereClause = null;
	        LinkedList columnsInSelectSQL = new LinkedList();
	        HashMap primaryKeyValues = null;
	        ArrayList keyList = null;
	        ArrayList valueList = new ArrayList();
	        Map.Entry entry = null;
	        HashMap boundData = null;
	        LinkedList boundValues = null;
	        LinkedList columnNames = null;
	        Iterator uniqueKeysIt = null;

	        try {
	            /* No specific query has been specified to check if the row exists. Use the Unique Keys */
	            if (null == rowPresentCheckQuery || "".equals(rowPresentCheckQuery)) {

	                uniqueKeysIt =
	                    targetTableUniqueKeys.entrySet().iterator();

	                /* Form the Select SQL */
	                selectSQL = "SELECT ";

	                /* Look for Primary Key(s) */
	                while (uniqueKeysIt.hasNext()) {
	                    entry = (Map.Entry) uniqueKeysIt.next();
	                    if (((String) entry.getKey()).indexOf(CONST_S_PRIMARY_KEY) != -1) {
	                        keyList = (ArrayList) entry.getValue();
	                        break;
	                    }
	                }

	                if (keyList == null || keyList.size() == 0) {
	                    throw new ExceptionImpl(ExceptionImpl.FATAL, "No primary key(s) found for table " + tableName + ". A select query, to decide whether to insert or update, cannot be run. Please check the target database.", null);
	                } else {
	                    for (int columnIndex = 0; columnIndex < keyList.size();
	                         columnIndex++) {
	                        selectSQL += " " + (String)keyList.get(columnIndex) + " ,";
	                    }
	                }

	                selectSQL =
	                        selectSQL.substring(0, selectSQL.lastIndexOf(CONST_S_COMMA));
	                selectSQL += " FROM " + tableName;
	                whereClause = " WHERE ";

	                /* Form the where clause on unique keys */
	                /* If unique keys are specified in the descriptor (descUniqueKeyValues), use the information. Else, use the physical unique key
	                 * information obtained(targetTableUniqueKeys) */
	                if (descUniqueKeyValues != null && descUniqueKeyValues.size() > 0){
	                    uniqueKeysIt = descUniqueKeyValues.entrySet().iterator();
	                    entry = (Map.Entry) uniqueKeysIt.next();
	                    Set keySet = ((HashMap)entry.getValue()).keySet();
	                    ArrayList tempKeyList = new ArrayList();
	                    tempKeyList.addAll(keySet);
	                    if(tempKeyList.size() > 0) {
	                        keyList = tempKeyList;
	                        valueList.addAll(((HashMap)entry.getValue()).values());
	                    }
	                } else {
	                    uniqueKeysIt = targetTableUniqueKeys.entrySet().iterator();
	                    while (uniqueKeysIt.hasNext()) {
	                        entry = (Map.Entry) uniqueKeysIt.next();
	                        if (((String)entry.getKey()).indexOf(CONST_S_UNIQUE_KEY) != -1) {
	                            keyList = (ArrayList) entry.getValue();
	                            break;
	                        }
	                    }
	                }

	                if (keyList == null || keyList.size() == 0) {
	                    throw new ExceptionImpl(ExceptionImpl.FATAL, "No unique key(s) found for table " + tableName + ". A select query, to decide whether to insert or update, cannot be run. Please check the target database or the descriptor.", null);
	                } else {
	                    String columnName = "";
	                    String colValue = "";
	                    for (int columnIndex = 0; columnIndex < keyList.size();
	                         columnIndex++) {

	                        columnName = (String) keyList.get(columnIndex);
	                        HashMap columnValues = (HashMap)columnsData.get(columnName);
	                        if (columnValues != null) {
	                            colValue = (String) columnValues.get(CONST_S_VALUE);
	                        } else {
	                            colValue = "";
	                        }

	                        if (colValue == null || "".equals(colValue)) {
	                            whereClause += keyList.get(columnIndex) + " IS NULL AND ";
	                        } else {
	                            if((null != valueList) && (valueList.size() > 0)) {
	                                if(((String)valueList.get(columnIndex)).equals(CONST_IN_CASE_SENSITIVE)) {
	                                    whereClause += "UPPER(" + keyList.get(columnIndex) + ") = UPPER(?) AND ";
	                                } else {
	                                    whereClause += keyList.get(columnIndex) + " = ? AND ";
	                                }
	                            } else {
	                                whereClause += keyList.get(columnIndex) + " = ? AND ";
	                            }
	                            columnsInSelectSQL.add(keyList.get(columnIndex));
	                        }
	                    }
	                }

	                selectSQL +=
	                        whereClause.substring(0, whereClause.lastIndexOf(CONST_S_AND));

	                log(LogEntry.SEVERITY_INFO, logLevel, null, "\n\nRunning Select query: " + selectSQL + " to determine if the row already exists");

	                pst = conn.prepareStatement(selectSQL);

	                /* Bind where clause variables */
	                boundData =
	                        bindSQLColumnVariables(pst, tableName, columnsInSelectSQL);

	                try {
	                    rs = pst.executeQuery();
	                    primaryKeyValues = new HashMap();
	                    ResultSetMetaData rsmd = null;
	                    if (rs.next()) {
	                        rsmd = rs.getMetaData();
	                        for (int j = 1; j <= rsmd.getColumnCount(); j++) {
	                            /* Get the primary column values */
	                            primaryKeyValues.put(rsmd.getColumnName(j),
	                                    getColumnValueAtIndex(rs, j));
	                        }
	                    }
	                } catch (Exception e) {
	                    /* Log what was the select statement attempted, with the values */
	                    String errorString =
	                        " Error running Select Query to determine if the row exists ";
	                    errorString +=
	                            "<BR><TABLE border=1 width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" class\"OraTableColumnHeaderIconButton\">";
	                    // Get column names
	                    columnNames = (LinkedList)boundData.get(CONST_S_COLUMN_NAMES);
	                    if (columnNames != null && columnNames.size() > 0) {
	                        Iterator itr = columnNames.iterator();
	                        errorString += "<TR>";
	                        while (itr.hasNext()) {
	                            errorString +=
	                                    "<TD align=\"center\" class=\"OraTableColumnHeaderIconButton\">" +
	                                    (String)itr.next() + "</TD>";
	                        }
	                        errorString += "</TR>";
	                    }

	                    // get column values
	                    boundValues = (LinkedList)boundData.get(CONST_S_BOUND_VALUES);
	                    if (boundValues != null && boundValues.size() > 0) {
	                        Iterator it = boundValues.iterator();
	                        errorString += "<TR>";
	                        String value = "";
	                        while (it.hasNext()) {
	                            value = (String) it.next();
	                            value = (value == null ? "" : value);
	                            errorString +=
	                                    "<TD class=\"OraTableCellText\">" + value +
	                                    "</TD>";
	                        }
	                        errorString += "</TR>";
	                    }
	                    errorString += "</TABLE>";
	                    // throw error with formated message.
	                    log(LogEntry.SEVERITY_FATAL, logLevel, e, CONST_S_NEW_LINE_CHAR + errorString + e.getMessage());
	                    throw new ExceptionImpl(ExceptionImpl.FATAL,
	                            CONST_S_NEW_LINE_CHAR + errorString,
	                            e);
	                }
	            } else {
	                /* rowPresentCheckQuery specified */
	                 log(LogEntry.SEVERITY_INFO, logLevel, null, "\n\nRunning rowPresentCheckQuery query " + rowPresentCheckQuery + " to determine whether to insert or update the row");

	                /* Handle all custom values present in the query, if any */
	                String colDataType = "";
	                int startIndex = 0;
	                int endIndex = 0;
	                String variableColumn = "";
	                StringBuffer variable = new StringBuffer("");
	                variable.append(rowPresentCheckQuery);

	                 /* Replace all values starting with '${fk:' and ending with '}', as they are foreign keys */
	                startIndex = variable.indexOf(CONST_S_FOREIGN_KEY_START);
	                 endIndex = variable.indexOf(CONST_S_FOREIGN_KEY_END, startIndex);
	                while (startIndex != -1) {
	                     variableColumn =
	                             variable.substring(startIndex + CONST_S_FOREIGN_KEY_START.length(), endIndex);
	                    if (foreignKeyValues.containsKey(variableColumn)) {
	                         colDataType =
	                                 (String)((HashMap)targetTablesInfoMap.get(tableName)).get(variableColumn);
	                         variable.replace(startIndex, endIndex + CONST_S_FOREIGN_KEY_END.length(),
	                                foreignKeyValues.get(variableColumn) + "");
	                    }
	                     startIndex = variable.indexOf(CONST_S_FOREIGN_KEY_START, endIndex);
	                     endIndex = variable.indexOf(CONST_S_FOREIGN_KEY_END, startIndex);
	                }
	                rowPresentCheckQuery = variable.toString();

	                pst = conn.prepareStatement(rowPresentCheckQuery);

	                try {
	                    rs = pst.executeQuery();
	                    primaryKeyValues = new HashMap();
	                    ResultSetMetaData rsmd = null;
	                    if (rs.next()) {
	                        rsmd = rs.getMetaData();
	                        for (int j = 1; j <= rsmd.getColumnCount(); j++) {
	                            /* Get the primary column values */
	                            primaryKeyValues.put(rsmd.getColumnName(j),
	                                    getColumnValueAtIndex(rs, j));
	                        }
	                    }
	                } catch (Exception e) {
	                    /* Log what was the select statement attempted, with the values */
	                    String errorString =
	                        " Error running Select Query to determine if the row exists: " + rowPresentCheckQuery;
	                    log(LogEntry.SEVERITY_FATAL, logLevel, e, errorString + e.getMessage());
	                    throw new ExceptionImpl(ExceptionImpl.FATAL,
	                            CONST_S_NEW_LINE_CHAR + errorString,
	                            e);
	                }
	            }
	        } catch (Exception e) {
	            log(LogEntry.SEVERITY_FATAL, logLevel, e, e.getMessage());
	            throw new ExceptionImpl(ExceptionImpl.FATAL, "Error in runSelectOnCurrentRow for table " + tableName + ":" + e.getMessage(), e);
	        } finally {
	            try {
	                DBUtil.close(rs, pst);
	            } catch (SQLException e) {
	                log(LogEntry.SEVERITY_FATAL, logLevel, e, e.getMessage());
	            }
	        }
	        return primaryKeyValues;

	    }
	    
	    /**
	     * This method returns the value of the column at the index specified from the resultset
	     * @param rs
	     * @param columnIndex
	     * @return
	     * @throws ExceptionImpl
	     */
	    private String getColumnValueAtIndex(ResultSet rs, int columnIndex) throws ExceptionImpl{
	        ResultSetMetaData rsmd = null;
	        String columnValue = null;
	        String columnName = null;
	        try {
	            rsmd = rs.getMetaData();
	            if (("varchar2").equalsIgnoreCase(rsmd.getColumnTypeName(columnIndex)) ||
	                ("char").equalsIgnoreCase(rsmd.getColumnTypeName(columnIndex))) {
	                columnValue = rs.getString(columnIndex);
	            } else if (("number").equalsIgnoreCase(rsmd.getColumnTypeName(columnIndex))) {
	                DecimalFormat formatter = new DecimalFormat("#.##########");
	                double d = rs.getDouble(columnIndex);
	                columnValue = "" + formatter.format(d);

	                if (rs.wasNull()){
	                    columnValue = "";
	                }
	            } else if (("date").equalsIgnoreCase(rsmd.getColumnTypeName(columnIndex))) {
	                columnValue = "" + rs.getDate(columnIndex);
	            } else if (("clob").equalsIgnoreCase(rsmd.getColumnTypeName(columnIndex))) {
	                columnValue =
	                        DBUtil.readClob(rs.getClob(columnIndex));
	            }
	            columnName = rsmd.getColumnName(columnIndex);
	        } catch (Exception e) {
	            throw new ExceptionImpl(ExceptionImpl.FATAL, "Error in obtaining the value for column: " + columnName, e);
	        }
	        return columnValue;
	    }
	    
	    /**
	     * This method is used to bind the variables in the SQL statement.
	     * The columns are specified in columnsInSQL and the values are in the columnsData variable.
	     * Handles a custom value specified through a query, a sequence or a foreign key.
	     * @param pst
	     * @param tableName
	     * @param columnsInSQL
	     * @throws ExceptionImpl
	     */
	    private HashMap bindSQLColumnVariables(PreparedStatement pst,
	                                           String tableName,
	                                           LinkedList columnsInSQL) throws ExceptionImpl {

	        HashMap columnInfo = null;
	        String colDataType = "";
	        String columnName = "";
	        String colValue = "";
	        String remember = "";
	        LinkedList boundValues = null;
	        LinkedList columnNames = null;
	        HashMap boundData = null;
	        int colIndex = 1;

	        try {
	            /* Loop through the columns in the SQL to bind the column values */
	            log(LogEntry.SEVERITY_INFO, logLevel, null, "Binding values");
	            Iterator columnsIt = columnsInSQL.iterator();
	            boundValues = new LinkedList();
	            columnNames = new LinkedList();
	            boundData = new HashMap();
	            while (columnsIt.hasNext()) {
	                columnName = (String) columnsIt.next();
	                /* If columnName is USER_MODIFIED and is blank, use USER_CREATED data */
	                columnInfo = (HashMap) columnsData.get(columnName);

	                if (null == columnInfo) {
	                    colDataType = "";
	                    colValue = null;
	                } else {
	                    colValue = (String) columnInfo.get(CONST_S_VALUE);
	                    remember = (String) columnInfo.get(CONST_S_REMEMBER);
	                    if (columnName.endsWith(CONST_S_USER_MODIFIED) && (null == colValue || "".equals(colValue))){
	                        columnInfo = (HashMap)columnsData.get(columnName.substring(0,columnName.indexOf(CONST_S_USER_MODIFIED)) + CONST_S_USER_CREATED);
	                        colValue = (String) columnInfo.get(CONST_S_VALUE);
	                    }
	                    colDataType =
	                            (String)((HashMap)targetTablesInfoMap.get(tableName)).get(columnName);

	                    /* Handle a custom value specified in the export XML */
	                    if (colValue != null && colValue.startsWith(CONST_S_CUSTOM)) {
	                        colValue = handleCustomValue(columnName, colValue);
	                    } else {
	                        /* Handle the situation where date_created is to be inserted */
	                        if (colValue != null && colValue.equals(SYSDATE)) {
	                            colValue = new Date(System.currentTimeMillis()) + "";
	                        }
	                    }

	                    /* Save values for columns which have remember=true */
	                    if (remember != null && "true".equals(remember)) {
	                        if (foreignKeyValues == null) {
	                            foreignKeyValues = new HashMap();
	                        }
	                        foreignKeyValues.put(columnName, colValue);
	                    }
	                }

	                columnNames.add(columnName);
	                boundValues.add(colValue);
	                setBindVariable(pst, colDataType, colValue, colIndex);
	                colIndex++;

	                log(LogEntry.SEVERITY_INFO, logLevel, null, columnName + "=" + colValue);
	            }
	            boundData.put(CONST_S_COLUMN_NAMES, columnNames);
	            boundData.put(CONST_S_BOUND_VALUES, boundValues);
	        } catch (Exception e) {
	            log(LogEntry.SEVERITY_INFO, logLevel, null, "Error binding column variables. Last column attempted:" + columnName);

	            /* Log what columns were attempted to be bound, with the values */
	            String errorString =
	                "Error binding column variables for table " + tableName;
	            errorString +=
	                    "<BR><TABLE border=1 width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" class\"OraTableColumnHeaderIconButton\">";
	            // Get column names
	            if (columnNames != null && columnNames.size() > 0) {
	                Iterator itr = columnNames.iterator();
	                errorString += "<TR>";
	                while (itr.hasNext()) {
	                    errorString +=
	                            "<TD align=\"center\" class=\"OraTableColumnHeaderIconButton\">" +
	                            (String)itr.next() + "</TD>";
	                }
	                errorString += "</TR>";
	            }

	            // get column values
	            if (boundValues != null && boundValues.size() > 0) {
	                Iterator it = boundValues.iterator();
	                errorString += "<TR>";
	                String value = "";
	                while (it.hasNext()) {
	                    value = (String) it.next();
	                    value = (value == null ? "" : value);
	                    errorString +=
	                            "<TD class=\"OraTableCellText\">" + value +
	                            "</TD>";
	                }
	                errorString += "</TR>";
	            }
	            errorString += "</TABLE>";
	            log(LogEntry.SEVERITY_FATAL, logLevel, e, e.getMessage());
	            // throw error with formated message.
	            log(LogEntry.SEVERITY_FATAL, logLevel, e, CONST_S_NEW_LINE_CHAR + errorString);
	            throw new ExceptionImpl(ExceptionImpl.FATAL,
	                                    CONST_S_NEW_LINE_CHAR + errorString, e);
	        }

	        return boundData;
	    }
	    
	    /**
	     * This method binds the value in the statement at the index passed using the dataType passed.
	     * @param st statement to be used for binding
	     * @param dataType type of the value passed
	     * @param value value to be bound.
	     * @param colIndex index at which the value is to be passed
	     * @throws Exception
	     */
	    private void setBindVariable(PreparedStatement st, String dataType,
	            String value, int colIndex) throws Exception {
	        if (("varchar2").equalsIgnoreCase(dataType) ||
	            ("char").equalsIgnoreCase(dataType)) {
	            st.setString(colIndex, value);
	        } else if (("number").equalsIgnoreCase(dataType)) {
	            if (null == value || "".equals(value)) {
	                st.setNull(colIndex, Types.NUMERIC);
	            } else {
	                st.setDouble(colIndex, Double.parseDouble(value));
	            }
	        } else if (("date").equalsIgnoreCase(dataType)) {
	            st.setDate(colIndex,
	                       (value != null ? Date.valueOf(value.trim()) : null));
	        } else if (("clob").equalsIgnoreCase(dataType)) {
	            if (null != value) {
	                st.setCharacterStream(colIndex, new StringReader(value));
	                /*oracle.sql.CLOB clob =
	                    oracle.sql.CLOB.createTemporary(conn, true, oracle.sql.CLOB.DURATION_SESSION);
	                Writer writer = clob.getCharacterOutputStream();
	                writer.write(value);
	                writer.close();
	                st.setClob(colIndex, clob);*/
	            } else {
	                st.setNull(colIndex, Types.CLOB);
	            }

	        } else {
	            st.setString(colIndex, value);
	        }
	    }

	    /**
	     * This method registers the out parameter using the passed parameters
	     * @param cst The callable statement into which the parameter is registered.
	     * @param dataType The type of the parameter
	     * @param colIndex The index at which it is to be registered.
	     * @throws Exception
	     */
	    private void registerOutParameter(CallableStatement cst, String dataType,
	            int colIndex) throws Exception {
	        if (("varchar2").equalsIgnoreCase(dataType)) {
	            cst.registerOutParameter(colIndex, Types.VARCHAR);
	        } else if (("char").equalsIgnoreCase(dataType)) {
	            cst.registerOutParameter(colIndex, Types.CHAR);
	        } else if (("number").equalsIgnoreCase(dataType)) {
	            cst.registerOutParameter(colIndex, Types.BIGINT);
	        } else if (("date").equalsIgnoreCase(dataType)) {
	            cst.registerOutParameter(colIndex, Types.DATE);
	        } else if (("clob").equalsIgnoreCase(dataType)) {
	            cst.registerOutParameter(colIndex, Types.CLOB);
	        }
	    }
	    
	    /**
	     * This method handles the exported values starting with CUSTOM:
	     * It resolves SELECT queries, {fk: values and ${sqlOnImport: values.
	     * @param colValue
	     * @return
	     * @throws ExceptionImpl
	     */
	    private String handleCustomValue(String columnName, String colValue) throws ExceptionImpl {
	        int startIndex = 0;
	        int endIndex = 0;
	        String variableColumn = "";
	        StringBuffer variable = new StringBuffer("");
	        colValue = colValue.substring(CONST_S_CUSTOM.length());
	        variable.append(colValue);

	        /* Replace all values starting with '${fk:' and ending with '}', as they are foreign keys */
	        startIndex = variable.indexOf(CONST_S_FOREIGN_KEY_START);
	        endIndex = variable.indexOf(CONST_S_FOREIGN_KEY_END, startIndex);
	        while (startIndex != -1) {
	            variableColumn =
	                    variable.substring(startIndex + CONST_S_FOREIGN_KEY_START.length(), endIndex);
	            if (foreignKeyValues.containsKey(variableColumn)) {
	                variable.replace(startIndex, endIndex + CONST_S_FOREIGN_KEY_END.length(),
	                                 foreignKeyValues.get(variableColumn) + "");
	            }
	            startIndex = variable.indexOf(CONST_S_FOREIGN_KEY_START, endIndex);
	            endIndex = variable.indexOf(CONST_S_FOREIGN_KEY_END, startIndex);
	        }
	        colValue = variable.toString();

	        /* Replace all values starting with '${sqlOnImport:' and ending with '}'. Run the query specified to get the value */
	        variable = new StringBuffer("");
	        variable.append(colValue);
	        String query = "";
	        startIndex = variable.indexOf(CONST_S_SQL_ON_IMPORT_START);
	        endIndex = variable.indexOf(CONST_S_SQL_ON_IMPORT_END, startIndex);
	        while (startIndex != -1) {
	            query =
	                    variable.substring(startIndex + CONST_S_SQL_ON_IMPORT_START.length(), endIndex);
	            variable.replace(startIndex, endIndex + CONST_S_SQL_ON_IMPORT_END.length(),
	                             getValueFromDB(query) + "");
	            startIndex = variable.indexOf(CONST_S_SQL_ON_IMPORT_START, endIndex);
	            endIndex = variable.indexOf(CONST_S_SQL_ON_IMPORT_END, startIndex);
	        }
	        colValue = variable.toString();

	        if (colValue.indexOf(CONST_S_SELECT) != -1) {
	            colValue = getValueFromDB(columnName, colValue);
	        }

	        return colValue;
	    }
	    
	    /**
	     * This method inserts a row in the table using the insert stored procedure specified in the descriptor.
	     * Handles a custom value specified through a query, a sequence or a foreign key, while binding.
	     * If the insert is successful, it stores the key values for subsequent use.
	     * @throws ExceptionImpl
	     */
	    private void insertRowThruProcedure(String tableName) throws ExceptionImpl {

	        CallableStatement cst = null;
	        Map.Entry entry = null;
	        HashMap columnInfo = null;
	        HashMap tableKeys = null;
	        String colDataType = "";
	        String columnName = "";
	        String colValue = "";
	        String remember = "";
	        Iterator keyIt = null;
	        LinkedList boundValues = null;
	        LinkedList columnNames = null;
	        HashMap boundData = null;

	        try {

	            log(LogEntry.SEVERITY_INFO, logLevel, null, "\n\nInserting a row using stored procedure");

	            boundValues = new LinkedList();
	            columnNames = new LinkedList();
	            boundData = new HashMap();

	            cst = conn.prepareCall(insertSQL);
	            int outParamIndex = 0;
	            int inParamIndex = 1;
	            long errorCode = 0;
	            String errorString = "";
	            Iterator outParamIt = null;
	            HashMap outParamInfo = null;

	            if (insertSQL.startsWith("{ ?")) {
	                outParamIndex = insertInParams.size() + 2;
	                inParamIndex++;
	            } else {
	                outParamIndex = insertInParams.size() + 1;
	            }

	            /* Bind the out parameters */
	            outParamIt = insertOutParams.entrySet().iterator();
	            while (outParamIt.hasNext()) {
	                entry = (Map.Entry) outParamIt.next();
	                outParamInfo = (HashMap) entry.getValue();

	                colDataType = (String) outParamInfo.get(CONST_S_DATATYPE);
	                if (outParamInfo.containsValue(CONST_S_RETURN)) {
	                    registerOutParameter(cst, colDataType, 1);
	                } else {
	                    registerOutParameter(cst, colDataType, outParamIndex);
	                    outParamIndex++;
	                }
	            }

	            log(LogEntry.SEVERITY_INFO, logLevel, null, "Binding values");

	            try {
	                /* Bind the in parameters */
	                for (int i = 0; i < insertInParams.size(); i++) {
	                    columnName = (String) insertInParams.get(i);
	                    columnName =
	                            columnName.substring(columnName.indexOf(CONST_S_IN_PARAMS_START) +
	                                                 1).trim();

	                    /* The in-param is p_save */
	                    if (CONST_S_P_SAVE.equals(columnName)) {
	                        colValue = "N";
	                        colDataType = "VARCHAR2";
	                    } else {
	                        columnInfo = (HashMap) columnsData.get(columnName);
	                        if (null == columnInfo) {
	                            colDataType = "";
	                            colValue = null;
	                        } else {
	                            colDataType = (String)columnInfo.get(CONST_S_DATATYPE);
	                            colValue = (String) columnInfo.get(CONST_S_VALUE);
	                            remember = (String)columnInfo.get(CONST_S_REMEMBER);

	                            if (colValue != null &&
	                                colValue.startsWith(CONST_S_CUSTOM)) {
	                                int startIndex = 0;
	                                int endIndex = 0;
	                                String variableColumn = "";
	                                StringBuffer variable = new StringBuffer("");
	                                colValue = colValue.substring(CONST_S_CUSTOM.length());
	                                variable.append(colValue);
	                                /* Replace all values starting with '${fk:' and ending with '}', as they are foreign keys */
	                                startIndex = variable.indexOf(CONST_S_FOREIGN_KEY_START);
	                                endIndex = variable.indexOf(CONST_S_FOREIGN_KEY_END, startIndex);
	                                while (startIndex != -1) {
	                                    variableColumn =
	                                            variable.substring(startIndex + CONST_S_FOREIGN_KEY_START.length(), endIndex);
	                                    if (foreignKeyValues.containsKey(variableColumn)) {
	                                        variable.replace(startIndex, endIndex + CONST_S_FOREIGN_KEY_END.length(),
	                                                         foreignKeyValues.get(variableColumn) + "");
	                                    }
	                                    startIndex = variable.indexOf(CONST_S_FOREIGN_KEY_START, endIndex);
	                                    endIndex = variable.indexOf(CONST_S_FOREIGN_KEY_END, startIndex);
	                                }
	                                colValue = variable.toString();

	                                /* Replace all values starting with '${sqlOnImport:' and ending with '}'. Run the query specified to get the value */
	                                variable = new StringBuffer("");
	                                variable.append(colValue);
	                                String query = "";
	                                startIndex = variable.indexOf(CONST_S_SQL_ON_IMPORT_START);
	                                endIndex = variable.indexOf(CONST_S_SQL_ON_IMPORT_END, startIndex);
	                                while (startIndex != -1) {
	                                    query =
	                                            variable.substring(startIndex + CONST_S_SQL_ON_IMPORT_START.length(), endIndex);
	                                    variable.replace(startIndex, endIndex + CONST_S_SQL_ON_IMPORT_END.length(),
	                                            getValueFromDB(query) + "");
	                                    startIndex = variable.indexOf(CONST_S_SQL_ON_IMPORT_START, endIndex);
	                                    endIndex = variable.indexOf(CONST_S_SQL_ON_IMPORT_END, startIndex);
	                                }
	                                colValue = variable.toString();

	                                if (colValue.indexOf(CONST_S_SELECT) != -1) {
	                                    colValue = getValueFromDB(columnName, colValue);
	                                }
	                            } else {
	                                /* Handle the situation where date_created is to be inserted */
	                                if (colValue != null && colValue.equals(SYSDATE)) {
	                                    colValue =
	                                            new Date(System.currentTimeMillis()) + "";
	                                }
	                            }

	                            /* Save values for columns which have remember=true */
	                            if (remember != null && "true".equals(remember)) {
	                                if (foreignKeyValues == null) {
	                                    foreignKeyValues = new HashMap();
	                                }
	                                foreignKeyValues.put(columnName, colValue);
	                            }
	                        }
	                    }

	                    columnNames.add(columnName);
	                    boundValues.add(colValue);
	                    setBindVariable(cst, colDataType, colValue, i + inParamIndex);
	                    log(LogEntry.SEVERITY_INFO, logLevel, null, columnName + "=" + colValue+" "+inParamIndex);
	                }
	                boundData.put(CONST_S_COLUMN_NAMES, columnNames);
	                boundData.put(CONST_S_BOUND_VALUES, boundValues);
	            } catch (Exception e) {
	                log(LogEntry.SEVERITY_INFO, logLevel, null, "Error binding column variables. Last column attempted:" + columnName);
	                throw e;
	            }

	            cst.execute();

	            if (insertSQL.startsWith("{ ?")) {
	                outParamIndex = insertInParams.size() + 2;
	                errorCode = cst.getLong(1);
	            } else {
	                outParamIndex = insertInParams.size() + 1;
	            }
	            errorString =
	                    cst.getString(insertInParams.size() + insertOutParams.size());
	            errorString = (errorString == null ? "" : errorString);

	            if (errorCode == 0) {
	                /* Save the primary key values to be used as foreign keys later */
	                tableKeys = (HashMap) tableTagInfo.get(CONST_S_TABLE_KEYS);
	                keyIt = tableKeys.entrySet().iterator();
	                while (keyIt.hasNext()) {
	                    entry = (Map.Entry) keyIt.next();
	                    if (((String) entry.getKey()).startsWith(CONST_S_PK)) {
	                        columnName = (String) entry.getValue();
	                        if (insertOutParams.containsKey(columnName)) {
	                            outParamInfo =
	                                    (HashMap)insertOutParams.get(columnName);
	                            colDataType =
	                                    (String)outParamInfo.get(CONST_S_DATATYPE);
	                            if (foreignKeyValues == null) {
	                                foreignKeyValues = new HashMap();
	                            }
	                            if (("varchar2").equalsIgnoreCase(colDataType) ||
	                                ("char").equalsIgnoreCase(colDataType)) {
	                                colValue = cst.getString(outParamIndex);
	                            } else if (("number").equalsIgnoreCase(colDataType)) {
	                                colValue = cst.getLong(outParamIndex) + "";
	                            }
	                            foreignKeyValues.put(columnName, colValue);
	                            outParamIndex++;
	                        }
	                    }
	                }
	            } else {
	            	 importedDataReport.put("failedMsg", errorString);
	            	 importedDataReport.put("failedErrorCode", errorCode);
	                /* Log what was the insert statement attempted, with the values */
	                errorString +=
	                    " Error Code: " + errorCode;
	                errorString += CONST_S_NEW_LINE_CHAR +
	                    " Error in inserting a row in table " + tableName;
	                errorString +=
	                        "<BR><TABLE border=1 width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" class\"OraTableColumnHeaderIconButton\">";
	                // Get column names
	                columnNames =
	                        (LinkedList)boundData.get(CONST_S_COLUMN_NAMES);

	                if (columnNames != null && columnNames.size() > 0) {
	                    Iterator itr = columnNames.iterator();
	                    errorString += "<TR>";
	                    while (itr.hasNext()) {
	                        errorString +=
	                                "<TD align=\"center\" class=\"OraTableColumnHeaderIconButton\">" +
	                                (String)itr.next() + "</TD>";
	                    }
	                    errorString += "</TR>";
	                }

	                boundValues =
	                        (LinkedList)boundData.get(CONST_S_BOUND_VALUES);
	                if (boundValues != null && boundValues.size() > 0) {
	                    // get column values
	                    Iterator it = boundValues.iterator();
	                    errorString += "<TR>";
	                    String value = "";
	                    while (it.hasNext()) {
	                        value = (String) it.next();
	                        value = (value == null ? "" : value);
	                        errorString +=
	                                "<TD class=\"OraTableCellText\">" + value +
	                                "</TD>";
	                    }
	                    errorString += "</TR>";
	                }
	                errorString += "</TABLE>";

	                // throw error with formated message.
	                log(LogEntry.SEVERITY_FATAL, logLevel, null, CONST_S_NEW_LINE_CHAR + errorString);
	                throw new ExceptionImpl(ExceptionImpl.FATAL,
	                                        CONST_S_NEW_LINE_CHAR +
	                                        errorString, null);
	            }

	        } catch (Exception e) {
	            log(LogEntry.SEVERITY_FATAL, logLevel, e, e.getMessage());
	            throw new ExceptionImpl(ExceptionImpl.FATAL, e.getMessage(), e);
	        } finally {
	            try {
	                DBUtil.close(null, cst);
	            } catch (SQLException e) {
	                log(LogEntry.SEVERITY_FATAL, logLevel, e, e.getMessage());
	            }
	        }

	    }
	    
	    /**
	     * This method gets the value from the database if the value is a SQL query string.
	     * @param colValue
	     * @return the result of the column value
	     * @throws ExceptionImpl to be thrown in case of any error.
	     */
	    private String getValueFromDB(String columnName, String colValue) throws ExceptionImpl {
	        Statement st = null;
	        ResultSet rs = null;
	        ResultSetMetaData rsmd = null;
	        String result = "";
	        try {
	            st = conn.createStatement();
	            rs = st.executeQuery(colValue);
	            rsmd = rs.getMetaData();
	            if (rs != null && rs.next()) {
	                if (rsmd.getColumnCount() > 1) {
	                    throw new ExceptionImpl(ExceptionImpl.FATAL,
	                                            "More than one column data found for insertion in table " +
	                                            (String)tableTagInfo.get(CONST_S_TABLE_NAME) + " using query: " +
	                                            colValue,
	                            null);
	                }
	                result = getColumnValueAtIndex(rs, 1);
	            } else {
	                /*
	                 * Check if noDataFoundOk is specified in the descriptor for
	                 * this column
	                 */
	                HashMap customAttributes = (HashMap) columnCustomAttributes
	                        .get(columnName);
	                String noDataFoundOk = "";
	                if (customAttributes != null) {
	                    noDataFoundOk = (String) customAttributes
	                            .get(CONST_S_NO_DATA_FOUND_OK);
	                }
	                if ("true".equals(noDataFoundOk)) {
	                    log(
	                            LogEntry.SEVERITY_INFO,
	                            logLevel,
	                            null,
	                            "This query returned no value:\n" + colValue + "\n");
	                } else {
	                    throw new ExceptionImpl(
	                            ExceptionImpl.FATAL,
	                            "No data found for the query " + colValue,
	                            null);
	                }
	            }

	        } catch (Exception e) {
	            throw new ExceptionImpl(ExceptionImpl.FATAL,
	                                    "Column value could not be obtained for inserting a row into table " +
	                                    (String)tableTagInfo.get(CONST_S_TABLE_NAME) +
	                                    ". The query attempted was:" + colValue,
	                    e);

	        } finally {
	            try {
	                DBUtil.close(rs, st);
	            } catch (SQLException sqle) {
	                log(LogEntry.SEVERITY_FATAL, logLevel, sqle, sqle.getMessage());
	            }
	        }
	        return result;
	    }

	    /**
	     * This method gets the value from the database if the value is a SQL query
	     * string.
	     *
	     * @param colValue
	     * @return the result of the column value
	     * @throws ExceptionImpl
	     *             to be thrown in case of any error.
	     */
	    private String getValueFromDB(String colValue) throws ExceptionImpl {
	        return getValueFromDB("", colValue);
	    }

	    /**
	     * This method updates the row in the table using the update procedure specified in the decriptor.
	     * Handles a custom value specified through a query, a sequence or a foreign key, while binding.
	     *
	     * @param primaryKeyValues
	     * @throws ExceptionImpl
	     */
	    private void updateRowThruProcedure(String tableName, HashMap primaryKeyValues) throws ExceptionImpl {
	        CallableStatement cst = null;
	        Map.Entry entry = null;
	        HashMap columnInfo = null;
	        String colDataType = "";
	        String columnName = "";
	        String colValue = "";
	        String remember = "";
	        LinkedList boundValues = null;
	        LinkedList columnNames = null;
	        HashMap boundData = null;

	        try {

	            log(LogEntry.SEVERITY_INFO, logLevel, null, "\n\nUpdating a row using stored procedure");

	            boundValues = new LinkedList();
	            columnNames = new LinkedList();
	            boundData = new HashMap();

	            cst = conn.prepareCall(updateSQL);
	            int outParamIndex = 0;
	            int inParamIndex = 1;
	            long errorCode = 0;
	            String errorString = "";
	            Iterator outParamIt = null;
	            HashMap outParamInfo = null;

	            if (updateSQL.startsWith("{ ?")) {
	                outParamIndex = updateInParams.size() + 2;
	                inParamIndex++;
	            } else {
	                outParamIndex = updateInParams.size() + 1;
	            }

	            /* Bind the out parameters */
	            outParamIt = updateOutParams.entrySet().iterator();
	            while (outParamIt.hasNext()) {
	                entry = (Map.Entry) outParamIt.next();
	                outParamInfo = (HashMap) entry.getValue();

	                colDataType = (String) outParamInfo.get(CONST_S_DATATYPE);
	                if (outParamInfo.containsValue(CONST_S_RETURN)) {
	                    registerOutParameter(cst, colDataType, 1);
	                } else {
	                    registerOutParameter(cst, colDataType, outParamIndex);
	                    outParamIndex++;
	                }
	            }

	            log(LogEntry.SEVERITY_INFO, logLevel, null, "Binding values");
	            /* Bind the in parameters */

	            try {
	                for (int i = 0; i < updateInParams.size(); i++) {
	                    columnName = (String) updateInParams.get(i);
	                    columnName =
	                            columnName.substring(columnName.indexOf(CONST_S_IN_PARAMS_START) +
	                                                 1).trim();
	                    columnInfo = (HashMap) columnsData.get(columnName);

	                    if (null == columnInfo && !CONST_S_P_SAVE.equals(columnName)){
	                        colDataType = "";
	                        colValue = null;
	                    } else {
	                        if (primaryKeyValues.containsKey(columnName)) {
	                            /* If the column is a primary key, use the current value */
	                            colValue = (String)primaryKeyValues.get(columnName);
	                            colDataType = (String)columnInfo.get(CONST_S_DATATYPE);
	                        } else if (CONST_S_P_SAVE.equals(columnName)) {
	                            /* The in-param is p_save */
	                            colValue = "N";
	                            colDataType = "VARCHAR2";
	                        } else {
	                            colDataType = (String)columnInfo.get(CONST_S_DATATYPE);
	                            colValue = (String) columnInfo.get(CONST_S_VALUE);
	                            remember = (String)columnInfo.get(CONST_S_REMEMBER);

	                            if (colValue != null &&
	                                colValue.startsWith(CONST_S_CUSTOM)) {
	                                int startIndex = 0;
	                                int endIndex = 0;
	                                String variableColumn = "";
	                                StringBuffer variable = new StringBuffer("");
	                                colValue = colValue.substring(CONST_S_CUSTOM.length());
	                                variable.append(colValue);
	                                /* Replace all values starting with '${fk:' and ending with '}', as they are foreign keys */
	                                startIndex = variable.indexOf(CONST_S_FOREIGN_KEY_START);
	                                endIndex = variable.indexOf(CONST_S_FOREIGN_KEY_END, startIndex);
	                                while (startIndex != -1) {
	                                    variableColumn =
	                                            variable.substring(startIndex + CONST_S_FOREIGN_KEY_START.length(), endIndex);
	                                    if (foreignKeyValues.containsKey(variableColumn)) {
	                                        variable.replace(startIndex, endIndex + CONST_S_FOREIGN_KEY_END.length(),
	                                                         foreignKeyValues.get(variableColumn) + "");
	                                    }
	                                    startIndex = variable.indexOf(CONST_S_FOREIGN_KEY_START, endIndex);
	                                    endIndex = variable.indexOf(CONST_S_FOREIGN_KEY_END, startIndex);
	                                }

	                                colValue = variable.toString();

	                                /* Replace all values starting with '${sqlOnImport:' and ending with '}'. Run the query specified to get the value */
	                                variable = new StringBuffer("");
	                                variable.append(colValue);
	                                String query = "";
	                                startIndex = variable.indexOf(CONST_S_SQL_ON_IMPORT_START);
	                                endIndex = variable.indexOf(CONST_S_SQL_ON_IMPORT_END, startIndex);
	                                while (startIndex != -1) {
	                                    query =
	                                            variable.substring(startIndex + CONST_S_SQL_ON_IMPORT_START.length(), endIndex);
	                                    variable.replace(startIndex, endIndex + CONST_S_SQL_ON_IMPORT_END.length(),
	                                            getValueFromDB(query) + "");
	                                    startIndex = variable.indexOf(CONST_S_SQL_ON_IMPORT_START, endIndex);
	                                    endIndex = variable.indexOf(CONST_S_SQL_ON_IMPORT_END, startIndex);
	                                }
	                                colValue = variable.toString();

	                                if (colValue.indexOf(CONST_S_SELECT) != -1) {
	                                    colValue = getValueFromDB(columnName, colValue);
	                                }
	                            } else {
	                                /* Handle the situation where date_created is to be inserted */
	                                if (colValue != null && colValue.equals(SYSDATE)) {
	                                    colValue =
	                                            new Date(System.currentTimeMillis()) + "";
	                                }
	                            }

	                            /* Save values for columns which have remember=true */
	                            if (remember != null && "true".equals(remember)) {
	                                if (foreignKeyValues == null) {
	                                    foreignKeyValues = new HashMap();
	                                }
	                                foreignKeyValues.put(columnName, colValue);
	                            }
	                        }
	                    }

	                    columnNames.add(columnName);
	                    boundValues.add(colValue);
	                    setBindVariable(cst, colDataType, colValue, i + inParamIndex);
	                    log(LogEntry.SEVERITY_INFO, logLevel, null, columnName + "=" + colValue);
	                }
	                boundData.put(CONST_S_COLUMN_NAMES, columnNames);
	                boundData.put(CONST_S_BOUND_VALUES, boundValues);
	            } catch (Exception e) {
	                log(LogEntry.SEVERITY_INFO, logLevel, e, "Error binding column variables. Last column attempted:" + columnName);
	                throw e;
	            }

	            cst.execute();

	            if (updateSQL.startsWith("{ ?")) {
	                outParamIndex = updateInParams.size() + 2;
	                errorCode = cst.getLong(1);
	            } else {
	                outParamIndex = updateInParams.size() + 1;
	            }
	            errorString =
	                    cst.getString(updateInParams.size() + updateOutParams.size());
	            errorString = (errorString == null ? "" : errorString);

	            if (errorCode != 0) {
	             importedDataReport.put("failedMsg", errorString);
	           	 importedDataReport.put("failedErrorCode", errorCode);
	                /* Log what was the update statement attempted, with the values */
	                errorString +=
	                     " Error Code: " + errorCode;
	                errorString += CONST_S_NEW_LINE_CHAR +
	                    " Error in updating a row in table " + tableName;
	                errorString +=
	                        "<BR><TABLE border=1 width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" class\"OraTableColumnHeaderIconButton\">";
	                // Get column names
	                int columnCount = 0;
	                columnNames = (LinkedList) boundData.get(CONST_S_COLUMN_NAMES);
	                if (columnNames != null && columnNames.size() > 0) {
	                    Iterator itr = columnNames.iterator();
	                    errorString += "<TR>";
	                    String colName = "";
	                    while (itr.hasNext()) {
	                        colName = (String) itr.next();
	                        if (errorString.indexOf(colName) == -1) {
	                            errorString +=
	                                    "<TD align=\"center\" class=\"OraTableColumnHeaderIconButton\">" +
	                                    colName + "</TD>";
	                            columnCount++;
	                        }
	                    }
	                    errorString += "</TR>";
	                }

	                // get column values
	                int colIndex = 0;
	                boundValues = (LinkedList) boundData.get(CONST_S_BOUND_VALUES);
	                if (boundValues != null && boundValues.size() > 0) {
	                    Iterator it = boundValues.iterator();
	                    errorString += "<TR>";
	                    String value = "";
	                    while (it.hasNext()) {
	                        value = (String) it.next();
	                        value = (value == null ? "" : value);
	                        if (colIndex < columnCount) {
	                            errorString +=
	                                    "<TD class=\"OraTableCellText\">" + value +
	                                    "</TD>";
	                            colIndex++;
	                        }
	                    }
	                    errorString += "</TR>";
	                }
	                errorString += "</TABLE>";
	                // throw error with formated message.
	                log(LogEntry.SEVERITY_FATAL, logLevel, null, CONST_S_NEW_LINE_CHAR + errorString);
	                throw new ExceptionImpl(ExceptionImpl.FATAL,
	                        CONST_S_NEW_LINE_CHAR + errorString,
	                        null);
	            }
	        } catch (Exception e) {
	            log(LogEntry.SEVERITY_FATAL, logLevel, e, e.getMessage());
	            throw new ExceptionImpl(ExceptionImpl.FATAL, e.getMessage(), e);
	        } finally {
	            try {
	                DBUtil.close(null, cst);
	            } catch (SQLException e) {
	                log(LogEntry.SEVERITY_FATAL, logLevel, e, e.getMessage());
	            }
	        }
	    }
	    
	    /**
	     * This method calls the invocation class with the specified parameters
	     * @param tableTagInfo
	     * @param customParams
	     * @param foreignKeyValues
	     * @throws ExceptionImpl
	     */
	    private void processInvocation(Map invocationInfo, HashMap customParams, HashMap foreignKeyValues, String executeMethod) throws ExceptionImpl {
	        String className = "";
	        Class invocationClass = null;
	        ExternalInvocationInterface externalHandlerRef = null;
	        String[] args = null;
	        
	    	try {
	          	args = getInvocationArgs(invocationInfo, customParams, foreignKeyValues);	
	    		
	        	int argsSize = args.length;
	        	
	        	className = (String) invocationInfo.get(CONST_S_CLASS_NAME);      	

	                invocationClass = Class.forName(className);
				externalHandlerRef = (ExternalInvocationInterface) invocationClass
						.newInstance();
				
				if(executeMethod == null) {
	                externalHandlerRef.execute(args, conn);
				} else {
					Map<String, Object> newArgs = new HashMap<String, Object>();
					
					String[] tempArray = new String[argsSize + 1];
					System.arraycopy(args, 0, tempArray, 0, argsSize);
					tempArray[argsSize] = executeMethod;

					newArgs.put(CONST_S_ARGUMENTS, tempArray);
					newArgs.put(CONST_S_COLUMNS_DATA, columnsData);
					newArgs.put(CONST_S_CUSTOM_PARAMS, customParams);
					externalHandlerRef.execute(newArgs, conn);
	            }

				log(LogEntry.SEVERITY_INFO, logLevel, null,
						"\nExternal invocation successful");
	        } catch (Exception e) {
	            String errorString = e.getMessage();
	            /* Get all the exceptions thrown in the invoked class */
	            if (errorString == null) {
	                Throwable cause = e.getCause();
	                while (cause != null) {
	                    errorString += " - " + cause.getMessage();
	                    cause = cause.getCause();
	                }
	            }
	            log(LogEntry.SEVERITY_FATAL, logLevel, e, "Error in processInvocation: " +
	                                    " Class Name " + className + " , Table: " +
	                                    (String)tableTagInfo.get(CONST_S_TABLE_NAME)+ "-" + errorString);
	            throw new ExceptionImpl(ExceptionImpl.FATAL,
	                                    "Error in processInvocation: " +
	                                    " Class Name " + className + " , Table: " +
	                                    (String)tableTagInfo.get(CONST_S_TABLE_NAME)+ "-" + errorString,
	                    e);
	        }
	    }
	    
	    /**
	     * This method calls the invocation class with the specified parameters
	     * @param tableTagInfo
	     * @param customParams
	     * @param foreignKeyValues
	     * @throws ExceptionImpl
	     */
	    private String[] getInvocationArgs(Map invocationInfo, HashMap customParams, HashMap foreignKeyValues) throws ExceptionImpl {
	        LinkedHashMap inParamsInfo = null;
	        String className = "";
	        ExternalInvocationInterface externalHandlerRef = null;
	        Iterator inParamIt = null;
	        String[] args = null;
	        Map.Entry entry = null;
	        String paramName = "";
	        HashMap paramInfo = null;
	        int argIndex = 0;
	        HashMap columnInfo = null;
	        boolean persistTableRow = false;

	        try {
	            persistTableRow = ((Boolean)customParams.get(CONST_S_PERSIST_TABLE_ROW)).booleanValue();

	            if (persistTableRow) {
	                className = (String) invocationInfo.get(CONST_S_CLASS_NAME);
	                inParamsInfo = (LinkedHashMap)invocationInfo.get(CONST_S_IN_PARAMS);

	                log(LogEntry.SEVERITY_INFO, logLevel, null, "\nProcessing external invocation. Calling class " + className);

	                /* Process In-Params. Form the parameter array */
	                inParamIt = inParamsInfo.entrySet().iterator();
	                args = new String[inParamsInfo.size()];

	                while (inParamIt.hasNext()) {
	                    entry = (Map.Entry) inParamIt.next();
	                    paramName = (String) entry.getKey();
	                    paramInfo = (HashMap) entry.getValue();
	                    paramName = paramName.substring(CONST_S_IN_PARAMS_START.length());

	                    if (!(paramInfo.get(CONST_S_USAGE) != null &&
	                          ("export".equalsIgnoreCase((String)paramInfo.get(CONST_S_USAGE))))){

	                        if (CONST_MODE.equalsIgnoreCase(paramName)) {
	                            args[argIndex] = CONST_IMPORT;
	                            argIndex++;
	                            continue;
	                        }

	                        // If the custom parameter wasn't passed, check if it is defaulted in the Desc
	                        if (customParams.get(paramName) == null) {
	                            String paramDefault = (String)paramInfo.get(CONST_S_DEFAULT);
	                            customParams.put(paramName, paramDefault);
	                        }

	                        if (customParams.get(paramName) != null) {
	                            args[argIndex] = (String)customParams.get(paramName);
	                            argIndex++;
	                            continue;
	                        }else if("true".equalsIgnoreCase((String)paramInfo.get(CONST_S_TABLE_COLUMN))){
	                            String columnAttributeFlag = "";
	                            String colValue = "";

	                            columnAttributeFlag = (String)paramInfo.get(CONST_S_COLUMN_ATTRIBUTE);
	                            if (null != columnAttributeFlag && "true".equals(columnAttributeFlag)){
	                                String columnAttributeName = "";
	                                String columnAttributeValue = "";
	                                String columnName = "";
	                                int startIndex = 0;
	                                int endIndex = 0;

	                                /* Get the attribute value for the column, if specified */
	                                startIndex = paramName.indexOf("(");
	                                endIndex = paramName.indexOf(")", startIndex);
	                                columnAttributeName = paramName.substring(startIndex + 1, endIndex);
	                                columnName = paramName.substring(0, startIndex);
	                                columnInfo = (HashMap)columnsData.get(columnName);

	                                if (!"".equals(columnAttributeName)) {
	                                    /* Get the attribute value for the column, if specified */
	                                    columnAttributeValue = (String)columnInfo.get(columnAttributeName);
	                                } else {
	                                    throw new ExceptionImpl(ExceptionImpl.FATAL,
	                                                            "Invalid XML Format: No column Attribute name found " +
	                                                            "when columnAttribute is true for " +
	                                                            "in-param " + paramName +
	                                                            " for invoking class " + className +" for table " +
	                                                            (String)tableTagInfo.get(CONST_S_TABLE_NAME) +
	                                                            " to handle table invocation.",
	                                            null);
	                                }
	                                if (!"".equals(columnAttributeValue)) {
	                                    args[argIndex] = columnAttributeValue;
	                                }
	                            /* The parameter is not a column attribute value. It's the column value itself */
	                            } else {
	                                colValue = (String)foreignKeyValues.get(paramName);
	                                if (null == colValue ||
	                                      "".equals(colValue.trim())){
	                                    /* The value is not available as a foreign key */
	                                    /* Resolve the value obtained from the exportedXML */
	                                    columnInfo = (HashMap)columnsData.get(paramName);
	                                    colValue = (String)columnInfo.get(CONST_S_VALUE);
	                                    if (colValue != null && colValue.startsWith(CONST_S_CUSTOM)) {
	                                        colValue = handleCustomValue(paramName,colValue);
	                                    }
	                                }

	                                args[argIndex] = colValue;
	                            }
	                            argIndex++;
	                            continue;
	                        } else {
	                            throw new ExceptionImpl(ExceptionImpl.FATAL,
	                                                    "Invalid XML Format: No value found for in-param " + paramName +
	                                                    " for invoking class " + className +" for table " +
	                                                    (String)tableTagInfo.get(CONST_S_TABLE_NAME) +
	                                                    " to handle table invocation.",
	                                    null);
	                        }

	                    } else {
	                        args[argIndex] = "";
	                        argIndex++;
	                        continue;
	                    }
	                }
	            }
	            
	            return args;
	        } catch (Exception e) {
	            String errorString = e.getMessage();
	            /* Get all the exceptions thrown in the invoked class */
	            if (errorString == null) {
	                Throwable cause = e.getCause();
	                while (cause != null) {
	                    errorString += " - " + cause.getMessage();
	                    cause = cause.getCause();
	                }
	            }
	            log(LogEntry.SEVERITY_FATAL, logLevel, e, "Error in processInvocation: " +
	                                    " Class Name " + className + " , Table: " +
	                                    (String)tableTagInfo.get(CONST_S_TABLE_NAME)+ "-" + errorString);
	            throw new ExceptionImpl(ExceptionImpl.FATAL,
	                                    "Error in processInvocation: " +
	                                    " Class Name " + className + " , Table: " +
	                                    (String)tableTagInfo.get(CONST_S_TABLE_NAME)+ "-" + errorString,
	                    e);
	        }
	    }
	    
	    /**
	     * This method extracts the column tag information from the exported XML and uses it to
	     * form the insert/update SQL query. It also stores the information into the member variable
	     * columnsData.
	     * @param attributes columns tag attributes.
	     * @throws ExceptionImpl
	     */
	    private void processTableColumn(Attributes attributes) throws ExceptionImpl {
	        HashMap exportColumnInfo = null;
	        String attributeName = "";
	        /* Get the exported column information */
	        exportColumnInfo = new HashMap();
	        for (int colAttribIndex = 0; colAttribIndex < attributes.getLength();
	             colAttribIndex++) {
	            attributeName = attributes.getLocalName(colAttribIndex);
	            if (!attributeName.equals(CONST_S_NAME)) {
	                exportColumnInfo.put(attributeName,
	                                     attributes.getValue(colAttribIndex));
	            }
	        }	        
	        columnsData.put(attributes.getValue(attributes.getIndex(CONST_S_NAME)),
	                exportColumnInfo);
	        columnBeingProcessed =
	                attributes.getValue(attributes.getIndex(CONST_S_NAME));

	        /* If insert/update SQL(and not a procedure) is to be used, use the column to form the SQL */
	        if (!procedurePresent) {
	            /* Insert SQL */
	            /* Do not include USER_MODIFIED, DATE_MODIFIED for Insert */
	             if (!(columnBeingProcessed.endsWith(CONST_S_USER_MODIFIED) || columnBeingProcessed.endsWith(CONST_S_DATE_MODIFIED))){
	                insertSQLPart1 += columnBeingProcessed + ", ";
	                insertSQLPart2 += " ?,";
	                columnsInInsertSQL.add(columnBeingProcessed);
	            }

	            /* Update SQL */
	            /* Do not include Primary key for update */
	            LinkedHashMap targetTableUniqueKeys =
	                (LinkedHashMap)((HashMap)targetTablesInfoMap.get((String)tableTagInfo.get(CONST_S_TABLE_NAME))).get(CONST_S_UNIQUE_KEYS);

	            Iterator uniqueKeysIt =
	                targetTableUniqueKeys.entrySet().iterator();
	            ArrayList keyList = null;
	            Map.Entry entry = null;
	            boolean isColumnUniqueKey = false;
	            while (uniqueKeysIt.hasNext()) {
	                entry = (Map.Entry) uniqueKeysIt.next();
	                if (((String) entry.getKey()).indexOf(CONST_S_PRIMARY_KEY) != -1) {
	                    keyList = (ArrayList) entry.getValue();
	                    if (keyList.contains(columnBeingProcessed)) {
	                        isColumnUniqueKey = true;
	                        break;
	                    }
	                }
	            }

	            /* Do not include USER_CREATED, DATE_CREATED for Update */
	            if (!isColumnUniqueKey && !(columnBeingProcessed.endsWith(CONST_S_USER_CREATED)
	                                     || columnBeingProcessed.endsWith(CONST_S_DATE_CREATED))){
	                updateSQLPart2 += columnBeingProcessed + " = ?, ";
	                columnsInUpdateSQL.add(columnBeingProcessed);
	            }
	        }
	    }
	    
	    
	    /**
	     *
	     * @param tableElem The table element, from the descriptor, being processed
	     * @param out Printwriter used to write the export XML
	     * @param con Connection reference to the database
	     * @param params Contains parameter values passed through the request
	     * @param foreignKeys Contains all the foreign keys for the table to be processed, and their values.
	     * @param indentCount Used to keep track of the tabbing/indentation in the generated XML
	     * @param user Application user logged in
	     * @throws ExceptionImpl thrown in case of any error
	     */
	    private void processTable(String entityType, Element tableElem,
	                              PrintWriter out, Connection con, HashMap params,
	                              HashMap customParams, HashMap foreignKeys, int indentCount,
	                              User user) throws ExceptionImpl {

	        Element whereElem = null;
	        Element columnsElem = null;
	        Element columnElem = null;
	        Element relationElem = null;

	        NodeList columnList = null;
	        Map.Entry entry = null;
	        Iterator keyIt = null;

	        String tableQuery = "";
	        String orderBy = "";
	        String tableName = "";
	        String tableTagName = "";
	        String rowTagName = "";
	        StringBuffer whereClauses = null;
	        String tableKeyColumnName = "";
	        String tableKey = "";
	        String keyIndex = "";
	        String foreignKeyColumn = "";
	        String dataValue = "";

	        HashMap tableKeys = null;
	        HashMap tableTagInfo = null;
	        Map exportColumns = null;
	        SortedMap exportColumnsOrderBy = null;
	        Map exportColumnDetails = null;
	        int rowCount = 0;
	        boolean foreignKeysInTable = false;

	        Statement st = null;
	        ResultSet rs = null;
	        ResultSetMetaData rsmd = null;
	        String toBeSearchedID = "";
	        Map<String, String> dbColumnNameMap = null;
	        try {

	            exportColumns = new LinkedHashMap();
	            exportColumnsOrderBy = new TreeMap();
	            tableQuery = CONST_S_SELECT;
	            rowCount = 0;
	            foreignKeysInTable = false;

	            /* Get information about the table */
	            tableTagInfo = getTableTagInfo(tableElem);
	            tableName = (String)tableTagInfo.get(CONST_S_TABLE_NAME);
	            tableTagName = (String)tableTagInfo.get(CONST_S_TABLE_TAG_NAME);
	            rowTagName = (String)tableTagInfo.get(CONST_S_ROW_TAG_NAME);
	            tableKeys = (HashMap)tableTagInfo.get(CONST_S_TABLE_KEYS);

	            log(LogEntry.SEVERITY_INFO, logLevel, null, "STARTING Export of table:" + tableName);
	            log(LogEntry.SEVERITY_INFO, logLevel, null, "***********************************************************");

	            /* Get all column metadata to be exported. */
	            columnsElem =
	                    XMLUtil.getChildElementByTagName(tableElem, COLUMNS_ELEM);
	            String orderByPosition = "";
	            if (columnsElem != null) {
	                columnList = columnsElem.getElementsByTagName(COLUMN_ELEM);
	                for (int colsIndex = 0; colsIndex < columnList.getLength();
	                     colsIndex++) {
	                    columnElem = (Element)columnList.item(colsIndex);

	                    exportColumnDetails = getColumnTagInfo(columnElem);

	                    if ((String)exportColumnDetails.get(CONST_S_ID) != null) {
	                        exportColumns.put(columnElem.getAttribute(CONST_S_ID),
	                                          exportColumnDetails);
	                        orderByPosition = (String)exportColumnDetails.get(CONST_S_ORDERBY);
	                        if (orderByPosition != null && !"".equals(orderByPosition.trim())) {
	                            Integer orderby = null;
	                            try {
	                                orderby = new Integer(orderByPosition);
	                            }catch(NumberFormatException nfe) {
	                                    log(LogEntry.SEVERITY_INFO, logLevel, null,
	                                            "Invalid XML Format: Attribute " +
	                                            CONST_S_ORDERBY +
	                                            " for column " + columnElem.getAttribute(CONST_S_ID) +
	                                            " must be a number, in the descriptor.");
	                            }
	                            exportColumnsOrderBy.put(orderby,columnElem.getAttribute(CONST_S_ID));
	                        }
	                    } else {
	                        throw new ExceptionImpl(ExceptionImpl.FATAL,
	                                                "Invalid XML Format: Attribute " +
	                                                CONST_S_ID +
	                                                " is missing for a column in table " +
	                                                tableName +
	                                                " , in the descriptor.", null);
	                    }
	                }
	            } else {
	                throw new ExceptionImpl(ExceptionImpl.FATAL,
	                                        "Invalid XML Format: Tag " +
	                                        COLUMNS_ELEM +
	                                        " is missing for the table " +
	                                        tableName + " , in the descriptor.",
	                                        null);
	            }

	            /* Get the where clause information, if any */
	            whereElem =
	                    XMLUtil.getChildElementByTagName(tableElem, WHERE_ELEM);
	            if (whereElem != null) {
	                whereClauses =
	                        new StringBuffer(whereElem.getFirstChild().getNodeValue());
	                String varString = "";
	                String convertedString = "";
	                int varStartindex = whereClauses.indexOf(CONST_S_VAR_START);
	                int varEndindex = whereClauses.indexOf(CONST_S_VAR_END);
	                while (varStartindex != -1 && varEndindex != -1) {
	                    varString =
	                            whereClauses.substring(varStartindex, varEndindex +
	                                                   1);
	                    convertedString =
	                            "'" + convertVariable(varString, params, user) +
	                            "'";
	                   // toBeSearchedID = convertVariable(varString, params, user);

	                    whereClauses.replace(varStartindex, varEndindex + 1,
	                                         convertedString);
	                    varStartindex = whereClauses.indexOf(CONST_S_VAR_START);
	                    varEndindex = whereClauses.indexOf(CONST_S_VAR_END);
	                }

	                HashMap variableMap = new HashMap();
	                variableMap.put(VariableResolverImpl.REQUESTPARAMS_PARAMETER,
	                        customParams);

	                varResolver = new VariableResolverImpl(variableMap);

	                funcResolver = new DefaultFunctionResolver();
	                whereClauses =  resolveExpression(whereClauses,varResolver,funcResolver) ;

	            }

	            /* Form the query to be executed */

	            /* Append all the columns to be queried */
	            Iterator it = exportColumns.keySet().iterator();
	            while (it.hasNext()) {
	                tableQuery += (String)it.next() + ", ";
	            }
	            tableQuery = tableQuery.substring(0, tableQuery.lastIndexOf(","));

	            /* Append the table name */
	            tableQuery += " FROM " + tableName;

	            /* Find foreign keys specified, if any */
	            keyIt = tableKeys.keySet().iterator();
	            while (keyIt.hasNext()) {
	                tableKey = (String)keyIt.next();
	                if (tableKey.startsWith(CONST_S_FK)) {
	                    foreignKeysInTable = true;
	                    break;
	                }
	            }

	            /* Handle where clause, foreign keys and update the query. */
	            if ((!"".equals(whereClauses) && null != whereClauses) ||
	                foreignKeysInTable) {
	                tableQuery += " WHERE ";

	                /* Append the where clause to the query */
	                if ((!"".equals(whereClauses) && null != whereClauses)) {
	                    tableQuery +=
	                            whereClauses.toString().trim() + " " + CONST_S_AND;
	                }

	                /* Append foreign keys and values, if any */
	                keyIt = tableKeys.entrySet().iterator();
	                while (keyIt.hasNext()) {
	                    entry = (Map.Entry)keyIt.next();
	                    tableKey = (String)entry.getKey();
	                    tableKeyColumnName = (String)entry.getValue();
	                    if (tableKey.startsWith(CONST_S_FK)) {
	                        tableQuery += " " + tableKeyColumnName + "=";
	                        keyIndex = tableKey.substring(CONST_S_FK.length());
	                        foreignKeyColumn =
	                                (String)foreignKeys.get(CONST_S_PK + keyIndex +
	                                                        "");
	                        if (foreignKeyColumn != null) {
	                            tableQuery +=
	                                    (String)params.get(foreignKeyColumn) +
	                                    " AND ";
	                        } else {
	                            throw new ExceptionImpl(ExceptionImpl.FATAL,
	                                                    "Invalid XML Format: Foreign Key " +
	                                                    tableKey + " for table " +
	                                                    tableName +
	                                                    " does not have a corresponding primary key in the parent table , in the descriptor.",
	                                                    null);
	                        }

	                    }
	                    if (tableKey.startsWith(CONST_S_PK1)) {
	                    	String searchid =
	                                (String)customParams.get("searchid");
	                    	if (searchid != null) {
	                        tableQuery += " " + tableKeyColumnName + "=";
	                        keyIndex = tableKey.substring(CONST_S_FK.length());
	                        
	                        
	                            tableQuery +=
	                            		searchid +
	                                    " AND ";
	                        }
	                    	
	                    	String transactionID =
	                                (String)customParams.get("transactionID");
	                    	if (transactionID != null) {
	                    		tableKeyColumnName = getDBColumnName("PolicyReference");
	                    		tableQuery += " " + tableKeyColumnName + "='";
	                            tableQuery +=	transactionID + "' AND ";
	                        }
	                    }
	                }

	                /* Form the final query to be executed */
	                tableQuery =
	                        tableQuery.substring(0, tableQuery.lastIndexOf(" AND"));
	            }

	            /* Handle order by condition and update the query. */
	            /* Get values for Order By*/
	            Collection list = exportColumnsOrderBy.values();
	            if(list.size()>0) {
	                Iterator itx = list.iterator();
	                while (itx.hasNext()) {
	                    orderBy += (String)itx.next() + ", ";
	                }
	                orderBy = orderBy.substring(0, orderBy.lastIndexOf(","));
	            }
	            if (!"".equals(orderBy)) {
	                tableQuery += " ORDER BY " + orderBy;
	            }

	            /* Execute the query */
	            log(LogEntry.SEVERITY_INFO, logLevel, null, "Running Select Query " + tableQuery + " to get table data.\n");
	            st = con.createStatement();
	            rs = st.executeQuery(tableQuery);
	            rsmd = rs.getMetaData();
	            int checkCounter = 0;
	            /* Process the result */
	            sb.append("\r\n{");
	            if (rs.next()) {

	                log(LogEntry.SEVERITY_INFO, logLevel, null, "Row(s) found.\n");

	                /* Process Invocation Tag if present */
	                if (tableTagInfo.get(CONST_S_INVOCATION_INFO) != null){
	                    processInvocation(tableTagInfo, customParams, rs);
	                }

	                if (checkCounter == 0 && null != entityType) {
	                    //out.print("\r\n<" + ROOT_ELEM + " type=\"" + entityType + "\">");
	                	//out.print("\r\n{");
	                	 //sb.append("\r\n{");
	                    checkCounter++;
	                }
	                /* Write the table tag */
	                printTab(out, indentCount);
	                //out.print("\"" + rowTagName + "\": {");
	                sb.append("\"" + rowTagName + "\": [");
	                indentCount++;

	                /* Process each row of the result */
	                do {
	                	/* Write the table tag */
		                printTab(out, indentCount);
		                //out.print("\"" + rowTagName + "\": {");
		                sb.append("{");
		                indentCount++;
	                    log(LogEntry.SEVERITY_INFO, logLevel, null, "Adding row data to the exported XML");
	                    rowCount++;
	                    /* Write the row tag */
	                    printTab(out, indentCount);
	                    if (rowTagName.endsWith("_")) {
	                        //out.print("<" + rowTagName + rowCount + ">");
	                    } else {
	                       // out.print("<" + rowTagName + ">");
	                    }
	                    indentCount++;

	                    /* Write data of the required columns */
	                    StringBuffer dataValueBuffer = null;
	                    String convertedString = "";
	                    for (int j = 1; j <= rsmd.getColumnCount(); j++) {
	                        String columnName = rsmd.getColumnName(j);
	                        String tempColumnData = "";

	                        printTab(out, indentCount);

	                        /* Get the data value */
	                        dataValue = getColumnValueAtIndex(rs, j);
	                        String objectColumnName = this.dbColumnNameMap.get(columnName);
	                        if(objectColumnName == null){
	                        	throw new Exception("DB Column name not found in Descriptor : "+columnName);
	                        }
	                        /* Write the column tag */
	                       /* out.print("<COLUMN " + CONST_S_NAME + "=\"" +
	                                  columnName + "\" " + CONST_S_DATATYPE +
	                                  "=\"" + rsmd.getColumnTypeName(j) + "\"");*/
	                        //out.print("\""+objectColumnName + "\":");
	                        sb.append("\""+objectColumnName + "\":");
	                        HashMap colDetailsTemp =
	                            (HashMap)exportColumns.get(columnName);
	                        if (colDetailsTemp != null){
	                            String attribName = "";
	                            String attribValue = "";
	                            keyIt = colDetailsTemp.entrySet().iterator();
	                            while (keyIt.hasNext()) {
	                                entry = (Map.Entry)keyIt.next();
	                                attribName = (String)entry.getKey();
	                                attribValue = (String)entry.getValue();
	                                if (attribName.equalsIgnoreCase(CONST_S_REMEMBER)){
	                                  /*  out.print(" remember=\"" +
	                                              attribValue +
	                                              "\"");*/
	                                }else if (attribName.equalsIgnoreCase(CONST_S_REPOSITORY_FILEPATH)){
	                                    if (attribValue != null &&
	                                        "true".equalsIgnoreCase(attribValue)){

	                                        /* dataValue should contain the path at which to find the exported file.
	                                         * Currently, the file is at the root of the zip or directly under the workingDirectory.
	                                         * Hence, filePath = fileName */
	                                        /* Extract the ifs file name from the file path */
	                                        dataValue = dataValue.substring(dataValue.lastIndexOf("/") + 1);

	                                        /* Remove the prefix from the name. e.g 33_AK-12345 should be AK-12345 */
	                                        dataValue = dataValue.substring(dataValue.lastIndexOf("_") + 1);

	                                        if ("".equals(dataValue.trim())){
	                                            /* No value found in the file path DB column.
	                                             * Get the value from the DB column specified under exportIFSFileName */
	                                            String tempColumnName = (String) colDetailsTemp.get(CONST_S_REPOSITORY_FILENAME);
	                                            if (null == tempColumnName || "".equals(tempColumnName)) {
	                                                log(LogEntry.SEVERITY_FATAL, logLevel, null,
	                                                "No data found in DB for column:" + columnName + ". Also, either attribute " + CONST_S_REPOSITORY_FILENAME
	                                                + " is not present OR does not have a value specified, in the descriptor");
	                                            } else {
	                                                int colVarStartIndex = tempColumnName.indexOf(CONST_S_COLVAR_START);
	                                                int colVarEndIndex = tempColumnName.indexOf(CONST_S_COLVAR_END,  colVarStartIndex);
	                                                tempColumnName =
	                                                            tempColumnName.substring(colVarStartIndex + CONST_S_COLVAR_START.length(), colVarEndIndex);
	                                                dataValue = getColumnValue(rs, tempColumnName);
	                                            }
	                                        }

	                                        if ("".equals(dataValue.trim())) {
	                                            throw new ExceptionImpl(
	                                                    ExceptionImpl.FATAL,
	                                                    "No value available to export for the attribute "
	                                                            + CONST_S_REPOSITORY_FILEPATH + " for column " + columnName
	                                                            + ". Without the value, the import could fail.",
	                                                    null);
	                                        }

	                                        //out.print(" " + CONST_S_REPOSITORY_FILEPATH + "=\"" + dataValue + "\"");
	                                        sb.append(" " + CONST_S_REPOSITORY_FILEPATH + "=\"" + dataValue + "\"");

	                                        /*
	                                         * Update the customParams->repositoryFilesInfo
	                                         * list, to be used later for zipping
	                                         */
	                                        ArrayList repositoryFilesInfo = (ArrayList) customParams.get(CONST_S_REPOSITORY_FILES_LIST);
	                                        if (repositoryFilesInfo == null) {
	                                            repositoryFilesInfo = new ArrayList();
	                                        }
	                                        repositoryFilesInfo.add(dataValue);
	                                        customParams.put(CONST_S_REPOSITORY_FILES_LIST, repositoryFilesInfo);
	                                    }
	                                } else if (attribName.startsWith("uk")) {
	                                   // out.print(" " + attribName + "=\"" + attribValue + "\"");
	                                }
	                            }
	                        }
	                        //out.print("");
	                        sb.append("");
	                        indentCount++;

	                        /* If the value returned is "null", blank it */
	                        if ("null".equalsIgnoreCase(dataValue)) {
	                            dataValue = "";
	                        }

	                        /* If USER_CREATED value is not retreived, export a default value */
	                        if ((columnName.endsWith(CONST_S_USER_CREATED)) &&
	                            "".equals(dataValue)) {
	                            dataValue = USER_CREATED;
	                        }

	                         /* If DATE_CREATED or DATE_MODIFIED is being exported, export the value as 'SYSDATE' to aid import */
	                         if (columnName.endsWith(CONST_S_DATE_CREATED) || columnName.endsWith(CONST_S_DATE_MODIFIED)){
	                            //dataValue = SYSDATE;
	                        }

	                        tempColumnData = dataValue;
	                        /* If the column to be written is a foreign key, write the name of the column from the parent table as data */
	                        keyIt = tableKeys.entrySet().iterator();
	                        while (keyIt.hasNext()) {
	                            entry = (Map.Entry)keyIt.next();
	                            tableKey = (String)entry.getKey();
	                            if (tableKey.startsWith(CONST_S_FK) &&
	                                entry.getValue().equals(columnName)) {
	                                keyIndex =
	                                        tableKey.substring(CONST_S_FK.length());
	                                foreignKeyColumn =
	                                        (String)foreignKeys.get(CONST_S_PK +
	                                                                keyIndex + "");
	                                dataValue = CONST_S_CUSTOM + CONST_S_FOREIGN_KEY_START + foreignKeyColumn + CONST_S_FOREIGN_KEY_END;
	                                break;
	                            }
	                        }

	                        /* If the column to be written has a value specified in the replace attribute, set the value from teh attribute */
	                        /* If ignoreReplaceIfNull is true and the value is "", do not replace */
	                        /*if (colDetailsTemp != null &&
	                            colDetailsTemp.get(CONST_S_REPLACE) != null &&
	                            !("true".equals(colDetailsTemp.get(CONST_S_IGNORE_REPLACE_IF_NULL)) &&
	                             "".equals(tempColumnData))) {
	                            dataValue =
	                                    (String)colDetailsTemp.get(CONST_S_REPLACE);*/
	                            /* Try to handle all the EL variables in the replace portion here */

	                            /* If any column value for this table is to be used in the replace data, set the column data at the appropriate position */
	                           /* int colVarStartIndex = 0;
	                            int colVarEndIndex = 0;

	                            dataValueBuffer = new StringBuffer("");
	                            dataValueBuffer.append(dataValue);
	                            String variableColumn = "";
	                            colVarStartIndex = dataValueBuffer.indexOf(CONST_S_COLVAR_START);
	                            colVarEndIndex = dataValueBuffer.indexOf(CONST_S_COLVAR_END,  colVarStartIndex);
	                            String columnValue = "";
	                            while (colVarStartIndex != -1) {
	                                variableColumn =
	                                        dataValueBuffer.substring(colVarStartIndex + CONST_S_COLVAR_START.length(), colVarEndIndex);
	                                columnValue = getColumnValue(rs, variableColumn);
	                                columnValue = (columnValue == null ? ""
	                                        : columnValue);
	                                dataValueBuffer.replace(colVarStartIndex, colVarEndIndex + CONST_S_COLVAR_END.length(),
	                                                 columnValue);

	                                colVarStartIndex = dataValueBuffer
	                                        .indexOf(CONST_S_COLVAR_START);
	                                colVarEndIndex = dataValueBuffer.indexOf(
	                                        CONST_S_COLVAR_END,
	                                        colVarStartIndex);
	                            }
	                            dataValue = dataValueBuffer.toString();

	                            int varStartIndex = 0;
	                            int varEndIndex = 0;
	                            StringBuffer variable = new StringBuffer("");
	                            String isChild = "";
	                            HashMap<String,String> variableInfo = new HashMap<String,String>();
	                            int startIndex = 0;
	                            int endIndex = 0;
	                            while (dataValueBuffer.indexOf(CONST_S_VAR_START) !=
	                                   -1) {
	                                variableInfo =
	                                        getVariable(dataValueBuffer.toString());
	                                variable.append((String)variableInfo.get(CONST_S_VAR));
	                                isChild =
	                                        (String)variableInfo.get(CONST_S_IS_CHILD);*/

	                                /* If the current column data is to be used in the replace data, set the column data at the appropriate position */
	                                /*startIndex =
	                                        variable.indexOf(":" + columnName);
	                                endIndex =
	                                        variable.indexOf(":" + columnName) + columnName.length() +
	                                        1;
	                                while (startIndex != -1) {
	                                    variable.replace(startIndex, endIndex,
	                                                     "\\'" + tempColumnData +
	                                                     "\\'");
	                                    startIndex =
	                                            variable.indexOf(":" + columnName);
	                                    endIndex =
	                                            variable.indexOf(":" + columnName) +
	                                            columnName.length() + 1;
	                                }

	                                varStartIndex =
	                                        Integer.parseInt((String)variableInfo.get("varStartIndex"));
	                                varEndIndex =
	                                        Integer.parseInt((String)variableInfo.get("varEndIndex"));
	                                if (isChild.equalsIgnoreCase("true")) {
	                                    convertedString =
	                                            "\\'" + convertVariable(variable.toString(),
	                                                                    params,
	                                                                    user) +
	                                            "\\'";
	                                } else {

	                                    convertedString =
	                                            "'" + convertVariable(variable.toString(),
	                                                                  params,
	                                                                  user) + "'";
	                                }
	                                dataValueBuffer.replace(varStartIndex,
	                                                        varEndIndex,
	                                                        convertedString);
	                                variable.delete(0, variable.length());
	                            }
	                            dataValue = dataValueBuffer.toString();
	                            dataValue = CONST_S_CUSTOM + dataValue;
	                        }*/

	                       // printTab(out, indentCount);
	                        /* Write the data for the column */
	                       /* if (null != dataValue) {
	                            out.print("<![CDATA[" + dataValue + "]]>");
	                        } else {
	                            out.print("<![CDATA[]]>");
	                        }*/
	                        
	                        if (null != dataValue) {
	                           // out.print("\"" + dataValue + "\",");
	                            sb.append("\"" + dataValue + "\",");
	                        } else {
	                            //out.print("\"\"");
	                            sb.append("\"\",");
	                        }

	                        indentCount--;
	                        //printTab(out, indentCount);
	                        //out.print("</COLUMN>");
	                    }
	                    sb.replace(sb.length()-1, sb.length(), "");

	                    /* Process Relation(Child) tables */
	                    relationElem =
	                            XMLUtil.getChildElementByTagName(tableElem, RELATION_ELEM);
	                    if (relationElem != null) {
	                        keyIt = tableKeys.entrySet().iterator();
	                        if (!keyIt.hasNext()) {
	                            throw new ExceptionImpl(ExceptionImpl.FATAL,
	                                                    "Invalid XML Format: No primary keys specified in the descriptor, for table " +
	                                                    tableName +
	                                                    " to handle table relations.",
	                                                    null);
	                        }
	                        /* Set all the primary keys to be used in the chuld table processing */
	                        while (keyIt.hasNext()) {
	                            entry = (Map.Entry)keyIt.next();
	                            tableKey = (String)entry.getKey();
	                            tableKeyColumnName = (String)entry.getValue();
	                            params.put(tableKeyColumnName,
	                                       rs.getString(tableKeyColumnName));
	                        }
	                        /* Process all the child tables */
	                       // processTables(null, relationElem, out, con, params, customParams,tableKeys, indentCount, user);
	                    }

	                    indentCount--;
	                    printTab(out, indentCount);
	                    /* Write the end of row tag */
	                    if (rowTagName.endsWith("_")) {
	                       // out.print("}");
	                        sb.append("},");
	                    } else {
	                        //out.print("}");
	                        sb.append("},");
	                    }
	                    //indentCount--;
		                //printTab(out, indentCount);
	                } while (rs.next());
	                sb.replace(sb.length()-1, sb.length(), "");
	                indentCount--;
	                printTab(out, indentCount);
	                /* Write the end of table tag */
	               // out.print("\"" + tableTagName + "\"");
	                sb.append("]");
	               
	            }else{
	                log(LogEntry.SEVERITY_INFO, logLevel, null, "No Row(s) found.\n");
	            }
	            sb.append("}");

	            log(LogEntry.SEVERITY_INFO, logLevel, null, "COMPLETING Export of table:" + tableName);
	            log(LogEntry.SEVERITY_INFO, logLevel, null, "***********************************************************\n");

	        } catch (Exception e) {
	            throw new ExceptionImpl(ExceptionImpl.FATAL, toBeSearchedID, e);
	        } finally {
	            try {
	                DBUtil.close(rs, st);
	            } catch (SQLException sqle) {
	                log(LogEntry.SEVERITY_FATAL, logLevel, sqle, sqle.getMessage());
	            }
	        }
	    }
	    
	    private int deleteTable(Element tableElem,Connection con, HashMap params,
                HashMap customParams,User user) throws ExceptionImpl {
	    		int rowsDeleted = 0;				
				Map.Entry entry = null;
				Iterator keyIt = null;				
				String tableQuery = "";			
				String tableName = "";
				String tableKeyColumnName = "";
				String tableKey = "";
				HashMap tableKeys = null;
				HashMap tableTagInfo = null;
				Statement st = null;
				ResultSet rs = null;				
				String toBeSearchedID = "";			
				try {		
				tableQuery = "";
				/* Get information about the table */
				tableTagInfo = getTableTagInfo(tableElem);
				tableName = (String)tableTagInfo.get(CONST_S_TABLE_NAME);
				tableKeys = (HashMap)tableTagInfo.get(CONST_S_TABLE_KEYS);
				
				log(LogEntry.SEVERITY_INFO, logLevel, null, "STARTING Delete of table:" + tableName);
				log(LogEntry.SEVERITY_INFO, logLevel, null, "***********************************************************");
				/* Append the table name */
				tableQuery += "delete FROM " + tableName;
				  tableQuery += " WHERE ";
				
				  /* Append foreign keys and values, if any */
				  keyIt = tableKeys.entrySet().iterator();
				  while (keyIt.hasNext()) {
				      entry = (Map.Entry)keyIt.next();
				      tableKey = (String)entry.getKey();
				      tableKeyColumnName = (String)entry.getValue();
				     
				      if (tableKey.startsWith(CONST_S_PK1)) {
				      	String searchid =
				                  (String)customParams.get("searchid");
				      	if (searchid != null) {
				          tableQuery += " " + tableKeyColumnName + "=";
				          
				              tableQuery +=
				              		searchid +
				                      " AND ";
				          }
				      	
				      	String transactionID =
				                  (String)customParams.get("transactionID");
				      	if (transactionID != null) {
				      		tableKeyColumnName = getDBColumnName("PolicyReference");
				      		tableQuery += " " + tableKeyColumnName + "='";
				              tableQuery +=	transactionID + "' AND ";
				          }
				      }
				  }				
				  /* Form the final query to be executed */
				  tableQuery =
				          tableQuery.substring(0, tableQuery.lastIndexOf(" AND"));	
				
				/* Execute the query */
				log(LogEntry.SEVERITY_INFO, logLevel, null, "Running Delete Query " + tableQuery + " to delete table data.\n");
				st = con.createStatement();
				rowsDeleted = st.executeUpdate(tableQuery);
				con.commit();
				log(LogEntry.SEVERITY_INFO, logLevel, null, "COMPLETING Delete of table row:" + tableName);
				log(LogEntry.SEVERITY_INFO, logLevel, null, "*******************************tableQuery**************************** "+tableQuery);
				
				} catch (Exception e) {
				throw new ExceptionImpl(ExceptionImpl.FATAL, toBeSearchedID, e);
				} finally {
				try {
				  DBUtil.close(rs, st);
				} catch (SQLException sqle) {
				  log(LogEntry.SEVERITY_FATAL, logLevel, sqle, sqle.getMessage());
				}
				}
				return rowsDeleted;
}
	    
	    private String getDBColumnName(String value) {
	    	
	    	if(value != null && dbColumnNameMap != null){
	    	
	    	for(Map.Entry entry: dbColumnNameMap.entrySet()){

	            if(value.equals(entry.getValue())){

	                return (String) entry.getKey();
	            }
	        }
	    	}
			return null;
		}

		/**
	     * This method prints out indentCount number of tabs, on a new line, in the export XML.
	     * @param out Printwriter used to write the export XML
	     * @param indentCount Used to keep track of the tabbing/indentation in the generated XML
	     */
	    private void printTab(PrintWriter out, int indentCount) {
	        int indentIndex = 0;
	        String indentTab = "    ";
	        indentIndex = indentCount;
	        //out.println("");
	        sb.append("");
	        while (indentIndex != 0) {
	            //out.print(indentTab);
	            sb.append(indentTab);
	            indentIndex--;
	        }
	    }
	    
	    /**
	     * This method resolves the variable passed and returns back the value.
	     * eg. var:request, var:sqlExecute kind of variables.
	     * @param inputString The variable string
	     * @param params Parameters that contain the value for the variable to be resolved.
	     * @param user The application user logged in.
	     * @return The variable resolved value
	     * @throws ExceptionImpl to be thrown in case of any error
	     */
	    private String convertVariable(String inputString, Map params,
	                                   User user) throws ExceptionImpl {
	        Document doc = null;
	        Element tempElem = null;
	        Node tempTextNode = null;
	        String convertedString = null;
	        try {
	            doc = XMLUtil.createNewDOM();
	            tempElem = doc.createElement("tempElem");
	            tempTextNode = doc.createTextNode("tempTextNode");
	            tempTextNode.setNodeValue(inputString);
	            tempElem.appendChild(tempTextNode);
	            HashMap variableMap = new HashMap();
	            variableMap.put(VariableResolverImpl.USER_PARAMETER, user);
	            variableMap.put(VariableResolverImpl.REQUESTPARAMS_PARAMETER,
	                            params);
	            variableMap.put(VariableResolverImpl.DOCUMENT_PARAMETER, tempElem);
	            variableMap.put(VariableResolverImpl.CONNECTION_PARAMETER, params.get(VariableResolverImpl.CONNECTION_PARAMETER));

	            VariableResolver varResolver =
	                new VariableResolverImpl(variableMap);
	            FunctionResolver funcResolver = new DefaultFunctionResolver();

	            DOMUtil.mapDataToElement(tempElem, varResolver, funcResolver);

	            if (tempElem != null && tempElem.getFirstChild() != null){
	                convertedString = tempElem.getFirstChild().getNodeValue();
	            }else{
	                convertedString = "";
	            }
	        } catch (Exception e) {
	            throw new ExceptionImpl(ExceptionImpl.FATAL,
	                                    "Invalid XML Format: Variable to be converted is invalid: " +
	                                    inputString, e);
	        }
	        return convertedString;
	    }
	    
	    /**
	     * This method returns the information about the left innermost variable to be resolved.
	     * eg. var:sqlExecute('xxxx var:request('A') yyy var:request('B') xxx') returns back info about
	     * var:request('A').
	     * The information includes the variable, whether it is a child, the start and the end index in the inputString
	     * @param inputString The string which contains the variable
	     * @return HashMap The Map containing the returned information.
	     */
	    private HashMap<String,String> getVariable(String inputString) {

	        HashMap<String,String> result = new HashMap<String,String>();
	        result.put("isChild", "false");
	        int varStartIndex = inputString.indexOf(CONST_S_VAR_START);
	        int varEndIndex = inputString.indexOf(CONST_S_VAR_END);

	        String leftMostVar =
	            inputString.substring(varStartIndex, varEndIndex + 1);
	        if (leftMostVar.indexOf(CONST_S_VAR_START,
	                                CONST_S_VAR_START.length()) != -1) {
	            varStartIndex +=
	                    leftMostVar.indexOf(CONST_S_VAR_START, CONST_S_VAR_START.length());
	            leftMostVar =
	                    leftMostVar.substring(leftMostVar.indexOf(CONST_S_VAR_START,
	                                                              CONST_S_VAR_START.length()));
	            result.put("isChild", "true");
	        }
	        result.put("variable", leftMostVar);
	        result.put("varStartIndex", varStartIndex + "");
	        result.put("varEndIndex", varEndIndex + 1 + "");

	        return result;
	    }
	    
	    /**
	     * This method returns the value for the specified column from the resultset
	     * @param rs
	     * @param columnName
	     * @return
	     * @throws ExceptionImpl
	     */
	    private String getColumnValue(ResultSet rs, String columnName) throws ExceptionImpl{
	        ResultSetMetaData rsmd = null;
	        String columnValue = null;
	        try{

	            rsmd = rs.getMetaData();
	            for (int j = 1; j <= rsmd.getColumnCount(); j++) {
	                if (columnName.equalsIgnoreCase(rsmd.getColumnName(j))){
	                    /* Get the column value */
	                    columnValue = getColumnValueAtIndex(rs, j);
	                    break;
	                }
	            }
	        }catch(Exception e){
	            throw new ExceptionImpl(ExceptionImpl.FATAL, "Error in obtaining the value for column: " + columnName, e);
	        }
	        return columnValue;
	    }
	    
	    /**
	    *
	    * This method is used to resolve the Where clause in the WHERE element of the table in
	    * the descriptor
	    * @param where clause string from whereElem of the table , from the descriptor, being processed
	    * @param VariableResolver
	    * @param FunctionResolver
	    * @throws ELParseException, ELException thrown in case of any error
	    */
	    private StringBuffer resolveExpression(StringBuffer whereClauses, VariableResolver varResolver, FunctionResolver funcResolver2) throws ELParseException, ELException {
	        InlineExpression expression = new InlineExpression(whereClauses.toString(), varResolver, funcResolver2);
	        whereClauses = new StringBuffer(expression.getValue());
	        return whereClauses;
	    }


	    /**
	     * This method calls the invocation class with the specified parameters
	     * @param tableTagInfo
	     * @param customParams
	     * @param rs
	     * @throws ExceptionImpl
	     */
	    private void processInvocation(HashMap tableTagInfo, HashMap customParams, ResultSet rs) throws ExceptionImpl {
	        HashMap invocationInfo = null;
	        LinkedHashMap inParamsInfo = null;
	        String className = "";
	        Class invocationClass = null;
	        ExternalInvocationInterface externalHandlerRef = null;
	        Iterator inParamIt = null;
	        String[] args;
	        Map.Entry entry = null;
	        String paramName = "";
	        HashMap paramInfo = null;
	        int argIndex  = 0;

	        try{
	            invocationInfo = (HashMap)tableTagInfo.get(CONST_S_INVOCATION_INFO);
	            className = (String)invocationInfo.get(CONST_S_CLASS_NAME);
	            inParamsInfo = (LinkedHashMap)invocationInfo.get(CONST_S_IN_PARAMS);

	            log(LogEntry.SEVERITY_INFO, logLevel, null, "Processing external invocation. Calling class " + className);

	            /* Process In-Params. Form the parameter array */
	            inParamIt = inParamsInfo.entrySet().iterator();
	            args = new String[inParamsInfo.size()];

	            while (inParamIt.hasNext()){
	                entry = (Map.Entry)inParamIt.next();
	                paramName = (String)entry.getKey();
	                paramInfo = (HashMap)entry.getValue();
	                paramName = paramName.substring(CONST_S_IN_PARAMS_START.length());

	                if (!(paramInfo.get(CONST_S_USAGE) != null &&
	                      ("import".equalsIgnoreCase((String)paramInfo.get(CONST_S_USAGE))))){

	                    if (CONST_MODE.equalsIgnoreCase(paramName)){
	                        args[argIndex] = CONST_EXPORT;
	                        argIndex++;
	                        continue;
	                    }

	                    if (customParams.get(paramName) != null){
	                        args[argIndex] = (String)customParams.get(paramName);
	                        argIndex++;
	                        continue;
	                    }else if("true".equalsIgnoreCase((String)paramInfo.get(CONST_S_TABLE_COLUMN))){
	                        /* Param is a column value */
	                        args[argIndex] = getColumnValue(rs, paramName);
	                        argIndex++;
	                        continue;
	                    }else{
	                        throw new ExceptionImpl(ExceptionImpl.FATAL,
	                                                "Invalid XML Format: No value found for in-param " + paramName +
	                                                " for invoking class " + className +" for table " +
	                                                (String)tableTagInfo.get(CONST_S_TABLE_NAME) +
	                                                " to handle table invocation.",
	                                                null);
	                    }

	                }else{
	                    args[argIndex] = "";
	                    argIndex++;
	                    continue;
	                }
	            }

	            invocationClass = Class.forName(className);
	            externalHandlerRef = (ExternalInvocationInterface)invocationClass.newInstance();
	            externalHandlerRef.execute(args, null);

	            log(LogEntry.SEVERITY_INFO, logLevel, null, "External invocation successful");

	        }catch(Exception e){
	            String errorString = e.getMessage();
	            /* Get all the exceptions thrown in the invoked class */
	            if (errorString == null){
	                Throwable cause = e.getCause();
	                while (cause != null){
	                    errorString += " - " + cause.getMessage();
	                    cause = cause.getCause();
	                }
	            }
	            log(LogEntry.SEVERITY_FATAL, logLevel, e, "Error in processInvocation: " +
	                                    " Class Name " + className + " , Table: " +
	                                    (String)tableTagInfo.get(CONST_S_TABLE_NAME)+ "-" + errorString);
	            throw new ExceptionImpl(ExceptionImpl.FATAL,
	                                    "Error in processInvocation: " +
	                                    " Class Name " + className + " , Table: " +
	                                    (String)tableTagInfo.get(CONST_S_TABLE_NAME)+ "-" + errorString,
	                                    e);
	        }
	    }
	    
	    /**
	     * This method returns all the information about a column tag.
	     * The information includes
	     * - Id value
	     * - replace attribute value
	     * - remember attribute value
	     * @param columnElem The column tag element for which the data is required.
	     * @return HashMap containing the data
	     * @throws ExceptionImpl to be thrwon in case of any error.
	     */
	    private HashMap getColumnTagInfo(Element columnElem) throws ExceptionImpl {

	        HashMap columnTagInfo = new HashMap();

	        NamedNodeMap columnAttribs = columnElem.getAttributes();
	        for (int i = 0; i < columnAttribs.getLength(); i++) {
	            Node attrib = columnAttribs.item(i);

	            if (attrib.getNodeName().equals(CONST_S_REPLACE)) {
	                columnTagInfo.put(CONST_S_REPLACE, attrib.getNodeValue());
	                continue;
	            }else if (attrib.getNodeName().equals(CONST_S_REMEMBER) &&
	                attrib.getNodeValue().equals("true")) {
	                columnTagInfo.put(CONST_S_REMEMBER, "true");
	                continue;
	            }else if (attrib.getNodeName().equals(CONST_S_ID)) {
	                columnTagInfo.put(CONST_S_ID, attrib.getNodeValue());
	                continue;
	            }else if (attrib.getNodeName().equals(CONST_S_ORDERBY)) {
	                columnTagInfo.put(CONST_S_ORDERBY, attrib.getNodeValue());
	                continue;
	            }else{
	                columnTagInfo.put(attrib.getNodeName(), attrib.getNodeValue());
	            }

	        }

	        return columnTagInfo;
	    }
	    
	    public   int deleteJsonEntity( Connection con,
	            PrintWriter out, HashMap params, User user) throws ExceptionImpl {
	        /* Variable declaration.*/
	    	int rowsDeleted = 0;
	        if (null == params) {
	            params = new HashMap<String,Object>();
	        }
	        String configFilePath = null;

	        try {
	            /*Get connection */
	            if (null == con) {
	               
	                con = ConnectionPool.getConnection(user);
	            }

	            /* Get Log Level */
	            String logLevelStr = (String)customParams.get(LOGLEVEL);
	            if (null != logLevelStr){
	                logLevel = Integer.parseInt(logLevelStr);
	            }

	            /* Get PrintWriter to the write the Export XML */
	           
	            
	         	
	            /* Obtain the descriptor Document */
	            Document configDoc = null;
	            String customerCode =(String) params.get(CONST_S_CUSTOMER_CODE);
	            String descriptor_name = (String) params.get("descriptor_name");
	            configFilePath = ResourceManager.locateConfDir(ServletConfigUtil.COMPONENT_FRAMEWORK, 
	        			customerCode, descriptor_name) + descriptor_name;
	    		
	    		configDoc = XMLUtil.createDom(new File(configFilePath));

	            /* Create the export XML */
	    		rowsDeleted = deleteEntity(configDoc, con, out, params, params, user);
	            
	            

	            /* Flush the XML generated */
	           // out.flush();
	           // return rowsDeleted;
	        } catch (DOMCreationException dce) {
	            log(LogEntry.SEVERITY_FATAL, logLevel, dce,
	                "Descriptor at path " + configFilePath + " is invalid or does not exist.");
	            throw new ExceptionImpl(ExceptionImpl.FATAL,
	                                    "Descriptor at path " + configFilePath +
	                                    " is invalid or does not exist.", dce);
	        } catch (Exception e) {
	            log(LogEntry.SEVERITY_FATAL, logLevel, e, e.getMessage());
	            throw new ExceptionImpl(ExceptionImpl.FATAL, e.getMessage(), e);
	        } finally {
	            try {
	                if ((con != null) && (!con.isClosed())) {
	                    con.close();
	                }
	            } catch (SQLException e) {
	                log(LogEntry.SEVERITY_FATAL, logLevel, e, e.getMessage());
	            }
	           /* try {
	                if (out != null) {
	                    out.close();
	                }
	            } catch (Exception e) {
	                log(LogEntry.SEVERITY_FATAL, logLevel, e, e.getMessage());
	            }*/
	        }
	        return rowsDeleted;

	    }

	    
	    /* Global variable and constants declaration.*/
	    private static final String USER_CREATED = "micadmin@mic.com";
	    private static final String WHERE_ELEM = "WHERE";
	    private static final String RELATION_ELEM = "RELATION";
	    private static final String ENTITY_START_ELEM = "<ENTITY type";
	    private static final String ENTITY_END_ELEM = "</ENTITY>";

	    private static final String NEWLINE = "\r\n";
	    private static final String WORKING_DIRECTORY = "workingDirectory";

	    private static final String CONST_S_REPLACE = "replace";
	    private static final String CONST_S_REPOSITORY_FILENAME = "exportRepositoryFileName";
	    private static final String CONST_S_REPOSITORY_FILEPATH = "exportRepositoryFilePath";
	    private static final String CONST_S_REPOSITORY_FILES_LIST = "repositoryFilesInfo";
	    private static final String CONST_S_VAR_START = "${var:";
	    private static final String CONST_S_VAR_END = "}";
	    private static final String CONST_S_COLVAR_START = "${col:";
	    private static final String CONST_S_COLVAR_END = "}";
	    private static final String CONST_S_VAR = "variable";
	    private static final String CONST_S_IS_CHILD = "isChild";
	    private static final String CONST_S_IGNORE_REPLACE_IF_NULL = "ignoreReplaceIfNull";
	    private static final String CONST_S_ORDERBY = "orderBy";

	    private static final String CONST_EXPORT = "EXPORT";
	    private static final String CONST_FILE_TYPE_GZIP = "gz";
	    private static final String CONST_FILE_TYPE_ZIP = "zip";
	    private static final String CONST_FILE_TYPE_XML = "xml";
	    private VariableResolver varResolver = null;
	    private FunctionResolver funcResolver = null;

}
