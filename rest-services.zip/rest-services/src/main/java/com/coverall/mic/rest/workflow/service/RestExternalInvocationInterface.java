package com.coverall.mic.rest.workflow.service;

import com.coverall.exceptions.ExceptionImpl;
import com.coverall.mt.interfaces.ExternalInvocationInterface;

import java.sql.Connection;
import java.util.Map;

public interface RestExternalInvocationInterface extends ExternalInvocationInterface {
    public boolean validate(Map args, Connection conn) throws ExceptionImpl;
}
