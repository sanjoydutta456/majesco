package com.coverall.mic.rest.workflow.service;


import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.coverall.exceptions.SecurityException;
import com.coverall.mt.http.User;
import com.coverall.mt.util.ResourceManager;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.DOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.pct.server.util.PCTGenUtils;
import static com.coverall.pctv2.server.rs.service.microservices.MessageConstants.loginPrevilegeError;
import static com.coverall.pctv2.server.rs.service.microservices.MessageConstants.fileNotFoundError;

public class RestYAMLDownloadServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final String EXPORT_PATH = System.getProperty("mic.system.home") + File.separator +"RestServicesAPI";

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {        
        doDownload(req, resp);       
    }
   
    private void doDownload(HttpServletRequest req, HttpServletResponse resp) throws IOException {
    	User user = User.getUser(req);
    	
        try {
			if (!(user.isAdmin() || user.isSuperAdmin())){
				//String msg = "User does not have privileges for downloading YAML file. Please login with Admin/SuperAdmin role";
			    generateErrorDocument(resp, loginPrevilegeError);
			    return;
			}
		} catch (SecurityException e) {
			// TODO Auto-generated catch block			
			PCTGenUtils.systemOutWithThreadInfo("Security Exception while downloading YAML and accessing the user roles {}");
			e.printStackTrace();
		}
        
        String customerCode = CustomerConfigUtil.getInstance().getCustomerCode(user.getDomain());
    	String yamlFilePath = ResourceManager.locateConfDir(ServletConfigUtil.COMPONENT_FRAMEWORK, 
    			customerCode, "RestServices_Description.yaml") + "RestServices_Description.yaml";
    	
        File f = new File(yamlFilePath);
        FileInputStream fis;
        try {
            fis = new FileInputStream(f);
        } catch (FileNotFoundException e) {
            //String msg = "File not found. Please generate the file again.";
            generateErrorDocument(resp, fileNotFoundError);
            return;
        }
        
        // return the content of the file
        ServletContext context = getServletConfig().getServletContext();
        String mimetype = context.getMimeType(yamlFilePath);

        resp.setContentType((mimetype != null) ? mimetype : "application/octet-stream");
        resp.setContentLength((int) f.length());
        resp.setHeader("Content-Disposition", "attachment; filename=\"RestServices_Description.yaml\"");

        byte[] bbuf = new byte[4 * 1024];
        ServletOutputStream op = null;
        DataInputStream in = null;
        try {
            op = resp.getOutputStream();
            in = new DataInputStream(fis);
            
            int bytesRead;
            while ((in != null) && ((bytesRead = in.read(bbuf)) != -1)) {
                    op.write(bbuf, 0, bytesRead);
            } 

            op.flush();
        } finally {
            if(in != null) {
                in.close();
            }
            if(op != null) {
                op.close();
            }
        }
    }
    

    private void generateErrorDocument(HttpServletResponse resp, String msg) throws IOException {
        resp.setContentType("text/plain");
        msg = (msg == null) ? "" : msg;
        resp.setContentLength(msg.length());
        resp.setHeader("Content-Disposition", "attachment; filename=\"" + "Error.txt" + "\"");

        PrintWriter out = null;
        try {
            out = resp.getWriter();
            out.println(msg);
        } finally {
            if(out != null) {
                out.close();
            }
        }
    }
}
