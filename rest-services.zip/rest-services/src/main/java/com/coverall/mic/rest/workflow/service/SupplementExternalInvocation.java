package com.coverall.mic.rest.workflow.service;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Map;

import com.coverall.exceptions.ExceptionImpl;
import com.coverall.mt.interfaces.ExternalInvocationInterface;
import com.coverall.util.DBUtil;

public class SupplementExternalInvocation implements ExternalInvocationInterface {
	private static final String CONST_IMPORT = "IMPORT";
    private static final String CONST_EXPORT = "EXPORT";
    //private static final String DB_DELETE_PROCEDURE = "{? = call k_producer_management.f_del_producer_authorities(?,?,?,?)}";
    //private static final String PRODUCER_ASSIGNMENTS_DB_DELETE_PROCEDURE =   "{? = call k_producer_management.f_del_producer_assignments(?,?,?,?)}";
	//private static final String DB_PROCEDURE_ARR []  = {"{? = call k_producer_management.f_del_producer_authorities(?,?,?,?)}", "{? = call k_producer_management.f_del_producer_assignments(?,?,?,?)}"};
    private static Logger logger = new Logger();

    private String mode; // = "Import/Export";
    private String user;
    private Connection conn;

	SupplementExternalInvocation(){
		 System.out.println(" Inside SupplementExternalInvocation()");
	}
	SupplementExternalInvocation(String mode, Connection conn){
		this.mode = mode;
		this.conn = conn;
		
		 System.out.println(" Inside SupplementExternalInvocation() mode "+mode+"  conn "+conn);
		
	}
	 
	public void execute(String[] args, Connection conn) throws ExceptionImpl {
		  System.out.println("Test execute");
		
	}
	
	public boolean validate(String[] args, Connection conn) throws ExceptionImpl {
       System.out.println("Test Return False");
		return false;
    }

	public void execute(Map args, Connection conn) throws ExceptionImpl {
	}

    
   


    public void setMode(String param) {
        this.mode = param;
    }

    public String getMode() {
        return mode;
    }

    public void setUser(String param) {
        this.user = param;
    }

    public String getUser() {
        return user;
    }

    public void setConn(Connection param) {
        this.conn = param;
    }

    public Connection getConn() {
        return conn;
    }
    
    public static class Logger {
        public void log(Exception e, String message) {
            if (e != null) {
                e.printStackTrace();
            }
            System.out.println(message);
        }
    }

    /**
     * Private method to display Exceptions.
     * @param e object of Exception class.
     * @param message Exception message.
     */
    private static void log(Exception e, String message) {
        logger.log(e, message);
    }
}
