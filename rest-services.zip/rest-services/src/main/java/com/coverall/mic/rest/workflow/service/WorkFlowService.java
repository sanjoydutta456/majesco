package com.coverall.mic.rest.workflow.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;

import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.db.DriverManagerUtil;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.util.ResourceManager;
import com.coverall.mt.webservices.producerupload.ProducerUploadConstants;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.DOMUtil;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.pctv2.server.yaml.generation.YAMLConstants;
import com.coverall.util.validators.SQLInjectionValidator;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

public class WorkFlowService extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	User user;

	protected void add(HttpServletRequest request, HttpServletResponse resp, HashMap<String, String> params) throws ServletException, IOException {
		params.put("REST_METHOD", "ADD");
		params.put("mode", "IMPORT");
	}

	protected void get(HttpServletRequest request, HttpServletResponse resp, HashMap<String, String> params) throws ServletException, IOException {
		params.put("REST_METHOD", "GET");
		params.put("mode", "EXPORT");
	}

	protected void update(HttpServletRequest request, HttpServletResponse resp, HashMap<String, String> params) throws ServletException, IOException {
		params.put("REST_METHOD", "UPDATE");
	}

	protected void delete(HttpServletRequest request, HttpServletResponse resp, HashMap<String, String> params) throws ServletException, IOException {
		params.put("REST_METHOD", "DELETE");
	}

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String mName="Service";
		validateRequestParams(request);
		List<ErrorMessage> errors = new ArrayList<ErrorMessage>();
		RestAPIFormat requestData = new RestAPIFormat();
		RestAPIFormat responseData = new RestAPIFormat();
		
		HashMap<String, String> params = new HashMap<String, String>();
		Map<String, Map<String, String>> instanceToBeMapped = new HashMap<String, Map<String, String>>();
		Map<String, Map<String, String>> responseObject = new HashMap<String, Map<String, String>>();
		params = initializeParams(requestData);
		instanceToBeMapped = getObjectFieldValues(request);
		wrapParamsForRestMethod(request, response, params);
		// Writing the Jason into response
		
		user = User.getUser(request);
		
		Connection conn = null;
			params.put("configFilePath", "");
			params.put("exportXMLPath", "");
			params.put("overwrite", "false");
			String customerCode = CustomerConfigUtil.getInstance().getCustomerCode(user.getDomain());
			params.put("customerCode", customerCode);
			params.put("logLevel", LogEntry.SEVERITY_INFO + "");
			//params.put("entityType", "POLICYFINANCIALSALT");
			params.put("failOnError", "true");
			params.put("sinkException", "true");
			String json = "";
		
		try {
			conn = ConnectionPool.getConnection(user);
			if (conn == null){
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
						getClass().getName(), "service",
						ServletConfigUtil.COMPONENT_FRAMEWORK,
						new Object[] { },
						"Failed to create database connection.", null,
						LogMinderDOMUtil.VALUE_PRODUCER_UPLOAD);
				throw new Exception("Could not get database connection object in WorkFlowService");
			}
			
			
			
			
			String method = request.getMethod();
			String restEndPoint = request.getPathInfo();
			String objectName = null;
			if(restEndPoint != null ){
			String[] items =restEndPoint.split("/");
			objectName=items[items.length-1];
			}
			String contextPath = request.getContextPath();
			String id = null;	
			String descriptor_name = getDescriptorName(objectName, customerCode);
			
			id= request.getParameter("id");
			String transactionID= request.getParameter("transactionID");
			String entityType= request.getParameter("entityType");
			if(id != null && id.length() > 0 && StringUtils.isNumeric(id)){
				params.put("searchid", id);
			}
			if(transactionID != null && transactionID.length() > 0){
				params.put("transactionID", transactionID);
			
			}
			if(descriptor_name != null && descriptor_name.length() > 0 ){
				params.put("descriptor_name", descriptor_name);
			}
			if(entityType != null && entityType.length() > 0 ){
				params.put("entity_type", entityType);
			}
			if ("GET".equalsIgnoreCase(method)) {
				StringBuffer sb = new StringBuffer();
				if((id != null && id.length() > 0 && StringUtils.isNumeric(id))||(transactionID != null && transactionID.length() > 0)){
					RestEntityExport processor = new RestEntityExport(conn, params, user);
					sb = processor.exportJsonEntity(conn, null, params, user);
				}
				else {
					throw new Exception("id or the transactionID parameter is required for get operation");
				}
				
				json  =sb.toString();
			}else if ("PUT".equalsIgnoreCase(method)) {
				params.put("searchid", id);
				RestEntityExport exportprocessor = new RestEntityExport(conn, params, user);
				StringBuffer sb = new StringBuffer();
				
				if((id != null && id.length() > 0 && StringUtils.isNumeric(id))){
				
					sb = exportprocessor.exportJsonEntity(conn, null, params, user);
				}
				else {
					throw new Exception("id parameter is required for update operation");
				}
				
				json  =sb.toString();
				
				
				
				instanceToBeMapped = updateInstanceToBeMapped(json, instanceToBeMapped,objectName,id);
				conn = ConnectionPool.getConnection(user);
				params.put("overwrite", "true");
				RestEntityProcessor processor = new RestEntityProcessor(conn,params,user);
				String newlyAddedId = processor.processEntity(instanceToBeMapped);
				if(newlyAddedId == null || newlyAddedId.length() < 1){
					throw new Exception("Exception in Update Please contact System Admisnistrator");
				}
				else {			
					Gson gson = new Gson(); 
					json = gson.toJson(instanceToBeMapped); 
				}
				
			} else if ("POST".equalsIgnoreCase(method)) {
				
				RestEntityProcessor processor = new RestEntityProcessor(conn,params,user);
				String newlyAddedId = processor.processEntity(instanceToBeMapped);
				if(newlyAddedId == null || newlyAddedId.length() < 1){
					throw new Exception("Exception in Insert Please contact System Admisnistrator");
				}
				else {
				params.put("searchid", newlyAddedId);
				RestEntityExport exportProcessor = new RestEntityExport(conn, params, user);
				StringBuffer sb = exportProcessor.exportJsonEntity(conn, null, params, user);
				json  =sb.toString();
				}
				
			} else if ("DELETE".equalsIgnoreCase(method)) {
				int rowsDeleted = 0;
				if((id != null && id.length() > 0 && StringUtils.isNumeric(id))||(transactionID != null && transactionID.length() > 0)){
					RestEntityExport processor = new RestEntityExport(conn, params, user);
					
					rowsDeleted = processor.deleteJsonEntity(conn, null, params, user);
				}
				else {
					throw new Exception("id or the transactionID parameter is required for delete operation");
				}
				
				
				json  ="{ \"Status\" :\""+rowsDeleted+" Record(s) deleted successfully\" }";
			
			}
			
		} catch (Throwable e1) {
			e1.printStackTrace();
			ErrorMessage error = new ErrorMessage();
			error.setMessage(e1.getMessage());
			errors.add(error);
			String jsonErrors = new Gson().toJson(errors);
			json = jsonErrors;
			
		}finally	{
			
				try {
					if(conn!=null && (!conn.isClosed())){
					conn.commit();
					DriverManagerUtil.close(conn);
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		
		response.setContentType("application/json;charset=UTF-8");
		response.getWriter().write(json);
		return;
	}
	
	

	private Map<String, Map<String, String>> updateInstanceToBeMapped(
			String json, Map<String, Map<String, String>> instanceToBeMapped, String objectName, String id) throws Throwable {
		 Map<String, Map<String, String>> updatedInstance =  new HashMap<String, Map<String, String>>();
		 
		 Map<String, Map<String, String>> inputMap = new Gson().fromJson(json, Map.class);
		 ArrayList inputValueList =(ArrayList) inputMap.get(objectName);
		 
		 if(inputValueList == null || inputValueList.size() == 0){
				throw new Exception("No Object Found for "+objectName +" and id = "+id);
			}
		 
		 Map<String, String> inputValueMap = (Map<String, String>) inputValueList.get(0);
		 
		 //ArrayList optputValueList =(ArrayList)instanceToBeMapped.get(objectName);
		 Map<String, String> valuesToBeMapped = instanceToBeMapped.get(objectName);
		 inputValueMap.putAll(valuesToBeMapped);
		
		 updatedInstance.put(objectName, inputValueMap);
		return updatedInstance;
	}

	private String getDescriptorName(String objectName, String customerCode) throws Exception {
		String descriptor = null;
		if(objectName != null){
			try {
			 String configFilePath = ResourceManager.locateConfDir(ServletConfigUtil.COMPONENT_FRAMEWORK, 
		    			customerCode, "entity_descriptor_mapping.xml") + "entity_descriptor_mapping.xml";
			
			Properties restAPIProps = new Properties();
			restAPIProps.loadFromXML(new FileInputStream(configFilePath));
			descriptor = restAPIProps.getProperty(objectName);
			}
			catch(Exception e){
				e.printStackTrace();
				throw new Exception("Descriptor name not found for Object name "+objectName+" and customerCode "+customerCode+". Exception is : "+ e.getMessage());
				
			}
			
		/* HashMap map = new HashMap();
		 map.put("PolicyFinancialsAlt", "PolicyFinancialsAlt_descriptor.xml");
		 map.put("Supplement", "Supplement_descriptor.xml");
		 descriptor = (String) map.get(objectName);*/
		}
		else {
			throw new Exception("Descriptor name not found for Object name "+objectName+" and customerCode "+customerCode);
		}
		return descriptor;
	}

	void wrapParamsForRestMethod(HttpServletRequest request, HttpServletResponse response, HashMap<String, String> params) throws ServletException,
			IOException {
		String method = request.getMethod();
		if ("GET".equalsIgnoreCase(method)) {
			get(request, response, params);
		} else if ("PUT".equalsIgnoreCase(method)) {
			update(request, response, params);
		} else if ("POST".equalsIgnoreCase(method)) {
			add(request, response, params);
		} else if ("DELETE".equalsIgnoreCase(method)) {
			delete(request, response, params);
		}
	}
	
	String getJasonStringFromRequest(HttpServletRequest request) throws IOException {
		StringBuffer jb = new StringBuffer();
		String line = null;
		BufferedReader reader = request.getReader();
		while ((line = reader.readLine()) != null)
			jb.append(line);
		return jb.toString();
	}

	Map<String, Map<String, String>> getObjectFieldValues(HttpServletRequest request) throws IOException {
		Map<String, Map<String, String>> instanceToBeMapped = new HashMap<String, Map<String, String>>();
		String jasonString = getJasonStringFromRequest(request);
		instanceToBeMapped = new Gson().fromJson(jasonString, Map.class);
		return instanceToBeMapped;
	}
	
	HashMap<String, String> initializeParams(RestAPIFormat requestData) {
		HashMap<String, String> params = new HashMap<String, String>();
		
		return params;
	}
	
	private void validateRequestParams(HttpServletRequest request) {
		try {
			SQLInjectionValidator.validateEntityType(request.getParameter("entityType"));
			SQLInjectionValidator.validateEntityReference(request.getParameter("id"));
			SQLInjectionValidator.validateEntityReference(request.getParameter("transactionID"));
		} catch (Exception e) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, "rest-services  WorkFlowService",
					"validateRequestParams", "",
					new Object[] { request.getParameter("transactionID"), request.getParameter("id") },
					"rest-services  WorkFlowService request param validation failed", e, LogMinderDOMUtil.VALUE_MIC);
			throw e;
		}
	}
}
