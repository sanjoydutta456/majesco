package com.coverall.mic.rest.workflow.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.coverall.el.function.DefaultFunctionResolver;
import com.coverall.exceptions.DOMCreationException;
import com.coverall.exceptions.ExceptionImpl;
import com.coverall.exceptions.InvalidCredentialsException;
import com.coverall.mic.rest.workflow.service.RestEntityExport.Logger;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.el.variable.VariableResolverImpl;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.DOMUtil;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.pct.server.util.PCTGenUtils;
import com.coverall.pctv2.server.rs.service.microservices.MicroServiceException;
import com.coverall.pctv2.server.yaml.generation.ObjectDefinition;
import com.coverall.pctv2.server.yaml.generation.Property;
import com.coverall.pctv2.server.yaml.generation.RestfulMethod;
import com.coverall.pctv2.server.yaml.generation.ServerDetailsUtil;
import com.coverall.pctv2.server.yaml.generation.YAMLConstants;
import com.coverall.pctv2.server.yaml.generation.YAMLGenUtil;
import com.coverall.util.DBUtil;
import com.coverall.util.XMLUtil;

public class YamlExport {

	private HashMap tableTagInfo = null;
	private Connection conn = null;
	private HashMap targetTablesInfoMap = null;
	private StringBuffer sb = new StringBuffer();
	private static int logLevel = LogEntry.SEVERITY_INFO;
	private Logger logger = new Logger();
	private static final String STRUCTURE_ELEM = "STRUCTURE";
	private static final String TABLE_ELEM = "TABLE";
	private static final String LOGLEVEL = "logLevel";
	private static final String TYPE_ELEM = "type";
	private static final String CONST_S_TABLE_KEYS = "tableKeys";
	private static final String CONST_S_TABLE_NAME = "tableName";
	private static final String CONST_S_ENTITY_IDENTIFIER_COLUMNS = "entityIdentifierColumns";
	private static final String CONST_S_TABLE_TAG_NAME = "tableTagName";
	private static final String CONST_S_ROW_TAG_NAME = "rowTagName";
	private static final String CONST_S_FAIL_ON_ERROR = "failOnError";
	private static final String CONST_S_CUSTOMER_CODE = "customerCode";
	private static final String CONST_S_PK = "pk";
	private static final String CONST_S_FK = "fk";
	private static final String CONST_S_UNIQUE_KEYS = "UNIQUE_KEYS";
	private static final String CONST_S_TRIM_DATA = "trimData";
	public YamlExport(Connection conn2) {
		this.conn = conn2;
		this.targetTablesInfoMap = new HashMap();

	}

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Connection conn = null;
		try {
			System.setProperty(DOMUtil.MIC_J2EE_HOME,
					"D:\\2015\\tomcat-deployment\\target\\mic-tomcat\\micj2eehome");
			System.setProperty("pct.use.hosted.application.url", "USA-30SR9Y1.majesco.com:9091");

			HashMap params = new HashMap();
			params.put("mode", "Export");
			params.put(CONST_S_CUSTOMER_CODE, "XX");
			params.put("logLevel", LogEntry.SEVERITY_INFO + "");
			params.put("descriptor_name", "PolicyFinancialsAlt_descriptor.xml");

			User user = null;

			String jdbcURL = "jdbc:oracle:thin:@xxxx:xxxx:xxxx";
			String driverName = "oracle.jdbc.driver.OracleDriver";

			Class.forName(driverName);
			conn = DriverManager.getConnection(jdbcURL, "MIC_XX", "MIC_XX");

			YamlExport yamlExport = new YamlExport(conn);
			boolean isSuccess = yamlExport.exportYaml(conn, params, user);
			System.out.println("isSuccess " + isSuccess);
		} catch (DOMCreationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidCredentialsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (conn != null)
				conn.close();
		}

	}

	public Boolean exportYaml(Connection conn, HashMap params, User user)
			throws Exception {
		boolean isSucess = false;
		String customerCode = (String) params.get(CONST_S_CUSTOMER_CODE);
		try {

			String configFilePath = System.getProperty(DOMUtil.MIC_J2EE_HOME)
					+ File.separator + "framework" + File.separator + "WEB-INF"
					+ File.separator + "conf" + File.separator + customerCode
					+ File.separator + "entity_descriptor_mapping.xml";

			Properties restAPIProps = new Properties();
			restAPIProps.loadFromXML(new FileInputStream(configFilePath));
			Set entitynames = restAPIProps.keySet();
			System.out.println(entitynames);
			List<ObjectDefinition> objectDefinitions = new ArrayList<ObjectDefinition>();
			List<RestfulMethod> restFullMethods = new ArrayList<RestfulMethod>();

			for (Iterator iterator = entitynames.iterator(); iterator.hasNext();) {

				String entityName = (String) iterator.next();
				String descriptor_name = restAPIProps.getProperty(entityName);				
				
				ObjectDefinition objdef = getObjectDefinition(entityName,params, customerCode,
						descriptor_name);
				objectDefinitions.add(objdef);
				
				RestfulMethod restMethod = new RestfulMethod();
				restMethod.setObjectName(entityName);
				restMethod.setEndPoint("/"+entityName);
				restMethod.setEndPointPost(" /"+entityName);
				restMethod.setXpathLoc(entityName);
				List<String> parameters = new ArrayList();
				parameters.add("id");
				parameters.add("transactionID");
				restMethod.setParameters(parameters );
				restMethod.setResponseRef(YAMLConstants.yamlDefinition.concat(entityName));
				restFullMethods.add(restMethod);
			}

			// exportJsonEntity(conn, params, user);
			
			String[] serverDetails= new String[2];
			serverDetails=getServerDetails();

			VelocityEngine ve = new VelocityEngine();

			Properties p = new Properties();
			p.setProperty("resource.loader", "class");
			p.setProperty("class.resource.loader.class",
					"org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
			ve.init(p);
			Template t = ve.getTemplate("/Entity.vm");
			// Setting the beans into velocity context so that velocity
			// templates will access
			String rootEntity = "PolicyFinancialsAlt";
			String rootEntityRef = "#/definitions/".concat(rootEntity);
			String yamlFilePath = System.getProperty(DOMUtil.MIC_J2EE_HOME)
					+ File.separator + "framework" + File.separator + "WEB-INF"
					+ File.separator + "conf" + File.separator + customerCode
					+ File.separator + "RestServices_Description.yaml";
			File filePath = new File(yamlFilePath);

			// String httpScheme=YAMLGenUtil.getHttpScheme();
			// String host=YAMLGenUtil.getHostName();
			VelocityContext context = new VelocityContext();
			context.put("restmethods", restFullMethods);
			context.put("definitions", objectDefinitions);
			context.put("entity", rootEntity);
			context.put("entityRef", rootEntityRef);
			context.put("host", serverDetails[0]);
			context.put("scheme", serverDetails[1]);
			StringWriter writer = new StringWriter();
			FileWriter fw = new FileWriter(filePath);
			// write to a file
			t.merge(context, writer);
			fw.write(writer.toString());
			fw.close();
			isSucess = true;
		} catch (Exception e) {
			PCTGenUtils
					.systemOutWithThreadInfo("Exception during YAML Generation :{}"
							+ e.getMessage());
			e.printStackTrace();
		}

		return isSucess;

	}

	private ObjectDefinition getObjectDefinition(String entityName, HashMap params, String customerCode,
			String descriptor_name) throws DOMCreationException, ExceptionImpl {
		ObjectDefinition objectDefinition = new ObjectDefinition();
		List<Property> properties = new ArrayList<Property>();
		List<String> required= new ArrayList<String>();
		Property property = null;
		String logLevelStr;
		String configFilePath;
		Document configDoc = null;
		try {
			configFilePath = System.getProperty(DOMUtil.MIC_J2EE_HOME)
					+ File.separator + "framework" + File.separator + "WEB-INF"
					+ File.separator + "conf" + File.separator + customerCode
					+ File.separator + descriptor_name;

			configDoc = XMLUtil.createDom(new File(configFilePath));

			Element rootElement = null;
			Element structureElem = null;
			Element tableElem = null;
			String tableName = "";
			String entityIdentifierColumns = "";
		    /* Set the Log Level */
			logLevelStr = (String) params.get(LOGLEVEL);
			if (null != logLevelStr) {
				logLevel = Integer.parseInt(logLevelStr);
			}

			/* Obtain the root value and the entity type */
			rootElement = configDoc.getDocumentElement();
			rootElement.getAttribute(TYPE_ELEM);

			/* Obtain the structure Element */
			structureElem = XMLUtil.getChildElementByTagName(rootElement,
					STRUCTURE_ELEM);

			if (structureElem == null) {
				throw new ExceptionImpl(ExceptionImpl.FATAL,
						"Invalid XML Format: Tag " + STRUCTURE_ELEM
								+ " is missing in the descriptor.", null);
			} else {
				Map<String, String> dbColumnNameMap = new HashMap<String, String>();
				dbColumnNameMap = setDBColumnNameMap(configDoc);

				tableElem = XMLUtil.getChildElementByTagName(structureElem,
						TABLE_ELEM);

				tableTagInfo = getTableTagInfo(tableElem);
				tableName = (String) tableTagInfo.get(CONST_S_TABLE_NAME);
				//(String)tableTagInfo.get(CONST_S_PK1);
	            entityIdentifierColumns = (String)tableTagInfo.get(CONST_S_ENTITY_IDENTIFIER_COLUMNS);
				setTargetTableInfo(tableName);
				System.out.println("targetTablesInfoMap " + targetTablesInfoMap);
				Map<String, String > colNameDataTypeMap = (Map<String, String>) targetTablesInfoMap.get(tableName);
				
				Iterator entries = dbColumnNameMap.entrySet().iterator();
				while (entries.hasNext()) {
				    Map.Entry entry = (Map.Entry) entries.next();
				    String key = (String)entry.getKey();
				    String value = (String)entry.getValue();
				    System.out.println("Key = " + key + ", Value = " + value);
				    if(entityIdentifierColumns.contains(value)){
				    	required.add(key);
				    }
				    property = new Property();
				    property.setAttributeName(key);
				    property.setDescription(key);
				    property.setType(colNameDataTypeMap.get(value).toLowerCase().equals("varchar2")?"string":colNameDataTypeMap.get(value).toLowerCase());
				    properties.add(property);
				}

			}
			objectDefinition.setObjectName(entityName);
			objectDefinition.setRequired(required);
			objectDefinition.setProperties(properties);

		} catch (Exception e) {
			throw new ExceptionImpl(ExceptionImpl.FATAL, e.getMessage(), e);
		}
		return objectDefinition;
	}

	private Map<String, String> setDBColumnNameMap(Document configDoc)
			throws Exception {
		HashMap<String, String> dbColumnNameMap = new HashMap<String, String>();

		try {
			// Document configDoc = XMLUtil.createDom(new File(configFile));
			configDoc.getDocumentElement().normalize();
			NodeList nList = configDoc.getElementsByTagName("COLUMN");
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				Element eElement = (Element) nNode;
				String colName = eElement.getAttribute("attributename");
				String dbColumnName = eElement.getAttribute("id");
				dbColumnNameMap.put(colName,dbColumnName);
			}
		} catch (Exception e) {
			e.printStackTrace();
			log(LogEntry.SEVERITY_FATAL, logLevel, e,
					"Errorin setDBColumnNameMap :" + e.getMessage());
			throw new Exception(" Exception in setDBColumnNameMap : "
					+ e.getMessage());
		}
		return dbColumnNameMap;
	}
	
	private HashMap getTableTagInfo(Element tableElem) throws ExceptionImpl {

		HashMap tableTagInfo = new HashMap();
		HashMap tableKeys = new HashMap();

		Node tableNameNode = null;
		Node tableTagNode = null;
		Node rowTagNode = null;
		Node tableAttribNode = null;

		try {
			/* Get all the Attribute Values */
			NamedNodeMap tableAttribs = tableElem.getAttributes();

			/* Table Name is mandatory */
			tableNameNode = tableAttribs.getNamedItem(CONST_S_TABLE_NAME);
			if (tableNameNode == null
					|| "".equals(tableNameNode.getNodeValue())
					|| tableNameNode.getNodeValue() == null) {
				throw new ExceptionImpl(
						ExceptionImpl.FATAL,
						"Invalid XML Format: Atribute " + CONST_S_TABLE_NAME
								+ " is missing for a table, in the descriptor.",
						null);
			} else {
				tableTagInfo.put(CONST_S_TABLE_NAME,
						tableNameNode.getNodeValue());
			}

			/* Get table data trim flag value */
			tableTagNode = tableAttribs.getNamedItem(CONST_S_TRIM_DATA);
			if (tableTagNode == null || "".equals(tableTagNode.getNodeValue())
					|| tableTagNode.getNodeValue() == null) {
				tableTagInfo.put(CONST_S_TABLE_TAG_NAME,
						tableNameNode.getNodeValue());
			} else {
				tableTagInfo
						.put(CONST_S_TRIM_DATA, tableTagNode.getNodeValue());
			}

			/* Get tableTagName value */
			tableTagNode = tableAttribs.getNamedItem(CONST_S_TABLE_TAG_NAME);
			if (tableTagNode == null || "".equals(tableTagNode.getNodeValue())
					|| tableTagNode.getNodeValue() == null) {
				tableTagInfo.put(CONST_S_TABLE_TAG_NAME,
						tableNameNode.getNodeValue());
			} else {
				tableTagInfo.put(CONST_S_TABLE_TAG_NAME,
						tableTagNode.getNodeValue());
			}

			/* Get rowTagName value */
			rowTagNode = tableAttribs.getNamedItem(CONST_S_ROW_TAG_NAME);
			if (rowTagNode == null || "".equals(rowTagNode.getNodeValue())
					|| rowTagNode.getNodeValue() == null) {
				tableTagInfo
						.put(CONST_S_ROW_TAG_NAME,
								(String) tableTagInfo
										.get(CONST_S_TABLE_TAG_NAME) + "_");
			} else {
				tableTagInfo.put(CONST_S_ROW_TAG_NAME,
						rowTagNode.getNodeValue());
			}

			/* Loop through the remaining attributes */
			for (int attribIndex = 0; attribIndex < tableAttribs.getLength(); attribIndex++) {
				tableAttribNode = tableAttribs.item(attribIndex);

				if (tableAttribNode.getNodeName().equals(CONST_S_TABLE_NAME)
						|| tableAttribNode.getNodeName().equals(
								CONST_S_TABLE_TAG_NAME)
						|| tableAttribNode.getNodeName().equals(
								CONST_S_ROW_TAG_NAME)) {
					continue;
				}

				if (tableAttribNode.getNodeName().equals(CONST_S_FAIL_ON_ERROR)) {
					if (tableAttribNode.getNodeValue() != null
							&& !"".equals(tableAttribNode.getNodeValue())) {
						tableTagInfo.put(CONST_S_FAIL_ON_ERROR,
								tableAttribNode.getNodeValue());
						continue;
					}
				}

				if (tableAttribNode.getNodeName().startsWith(CONST_S_PK)
						|| tableAttribNode.getNodeName().startsWith(CONST_S_FK)) {
					if (null == tableKeys.get(tableAttribNode.getNodeName())) {
						if (tableAttribNode.getNodeValue() != null
								&& !"".equals(tableAttribNode.getNodeValue())) {
							tableKeys.put(tableAttribNode.getNodeName(),
									tableAttribNode.getNodeValue());
							continue;
						} else {
							throw new ExceptionImpl(
									ExceptionImpl.FATAL,
									"Invalid XML Format: Attribute "
											+ tableAttribNode.getNodeName()
											+ " does not have a value specified for table "
											+ (String) tableTagInfo
													.get(CONST_S_TABLE_NAME)
											+ ".", null);
						}
					}
				} else {
					tableTagInfo.put(tableAttribNode.getNodeName(),
							tableAttribNode.getNodeValue());
				}
			}
			tableTagInfo.put(CONST_S_TABLE_KEYS, tableKeys);

			// }
		} catch (ExceptionImpl e) {
			log(LogEntry.SEVERITY_FATAL, logLevel, null,
					"Error getting TABLE tag information :" + e.getMessage());
			throw e;
		}

		return tableTagInfo;
	}

	/**
	 * This method sets the target table information in the variable
	 * targetTablesInfoMap. The information contains - The column names and the
	 * types. - The Unique Keys - A map with the key as index name and the value
	 * as the list of columns in that index. (Includes primary key and unique
	 * key indexes)
	 * 
	 * @param tableName
	 * @return
	 */
	private void setTargetTableInfo(String tableName) throws ExceptionImpl {

		PreparedStatement pst = null;
		ResultSet targetTableColumnInfoRS = null;
		ResultSet targetTableIndexInfoRS = null;
		HashMap targetTableInfoMap = null;
		LinkedHashMap targetTableUniqueKeys = null;
		ArrayList uniqueKeyColumns = null;
		String indexInfoQuery = null;

		try {
			if (!targetTablesInfoMap.containsKey(tableName)) {
				targetTableColumnInfoRS = conn.getMetaData().getColumns(null,
						null, tableName, null);
				targetTableInfoMap = new HashMap();
				while (targetTableColumnInfoRS.next()) {
					targetTableInfoMap.put(
							targetTableColumnInfoRS.getString("COLUMN_NAME"),
							targetTableColumnInfoRS.getString("TYPE_NAME"));
				}

				indexInfoQuery = "SELECT INDEX_NAME, COLUMN_NAME FROM ALL_IND_COLUMNS WHERE TABLE_NAME = ? ORDER BY INDEX_NAME";
				pst = conn.prepareStatement(indexInfoQuery);
				pst.setString(1, tableName);

				targetTableIndexInfoRS = pst.executeQuery();

				targetTableUniqueKeys = new LinkedHashMap();
				while (targetTableIndexInfoRS.next()) {
					String indexName = targetTableIndexInfoRS
							.getString("INDEX_NAME");
					String indexColumnName = targetTableIndexInfoRS
							.getString("COLUMN_NAME");
					if (null != indexName) {
						if (targetTableUniqueKeys.size() == 0
								|| targetTableUniqueKeys.get(indexName) == null) {
							uniqueKeyColumns = new ArrayList();
						} else {
							uniqueKeyColumns = (ArrayList) targetTableUniqueKeys
									.get(indexName);
						}
						uniqueKeyColumns.add(indexColumnName);
						targetTableUniqueKeys.put(indexName, uniqueKeyColumns);
					}
				}
				targetTableInfoMap.put(CONST_S_UNIQUE_KEYS,
						targetTableUniqueKeys);
				targetTablesInfoMap.put(tableName, targetTableInfoMap);
			}
		} catch (Exception e) {
			log(LogEntry.SEVERITY_FATAL, logLevel, e,
					"Error setting Target Table Information for table "
							+ tableName + ":" + e.getMessage());
			throw new ExceptionImpl(ExceptionImpl.FATAL,
					"Error setting Target Table Information for table "
							+ tableName, e);
		} finally {
			try {
				DBUtil.close(targetTableColumnInfoRS, null);
			} catch (SQLException e) {
				log(LogEntry.SEVERITY_FATAL, logLevel, e, e.getMessage());
			}
			try {
				DBUtil.close(targetTableIndexInfoRS, pst);
			} catch (SQLException e) {
				log(LogEntry.SEVERITY_FATAL, logLevel, e, e.getMessage());
			}
		}
	}
	
	String[] getServerDetails() throws UnknownHostException, Exception {
		String applicationUrl=System.getProperty("pct.use.hosted.application.url");
		String[] serverDetails= new String[2];	
		//For all env other than local this will be null. So fetch the server details from ADM Machine tables ADMIN schema
		if (applicationUrl ==null){			
			applicationUrl=ServerDetailsUtil.getServerInfo();
			if (applicationUrl ==null){
				throw new MicroServiceException("Could not get the server details. Verify the server details in ADM Machine");
			}
		}
		String replaceScheme=applicationUrl.contains(YAMLConstants.HTTP)?YAMLConstants.HTTP:YAMLConstants.HTTP_Secure;
		String scheme=null;
		if (applicationUrl.contains(YAMLConstants.HTTP)){
			 scheme="http";
		}else{
			 scheme="https";
		}		
		String host=applicationUrl.replace(replaceScheme, "");
		
		serverDetails[0]=host;
		serverDetails[1]=scheme;
		//scheme=httpScheme.replace(httpScheme, "://");
		return serverDetails;
	}

	private void log(int severity, int logLevel, Exception e, String message) {
		logger.log(severity, logLevel, e, message);		
		LogMinder.getLogMinder().log(severity,
                 getClass().getName(), "",
                 ServletConfigUtil.COMPONENT_PORTAL,
                 new Object[] {  }, message +               
                 e.getMessage(), e,
                 LogMinderDOMUtil.VALUE_MIC);
	}
}
