package com.coverall.mic.services.policy.transactionprocessing;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;

import com.coverall.util.DBUtil;

public class BookingStatusPolling extends Thread {

	private String entityReference;
	private Connection conn;
	private final int TIMEOUT_PERIOD = 300;
	private String pollingErrorMessage = "";
	private String[] statusArray = new String[]{"ERROR","COMPLETE","BLOCK"};
	private String statusQuery = "select WAC_STAGE, WAC_STAGE_DESC from WFL_ACTIVITIES where WAC_ENTITY_TYPE = 'POLICY'"+
	              " and WAC_TASK_ID = (select WTA_ID from WFL_TASKS where WTA_NAME = 'BOOKING') and WAC_ENTITY_REFERENCE= " +
	              "(select new_entity_reference from EV_MIS_QUOTE_POLICIES where entity_reference=?)";
	
	public BookingStatusPolling(String entityReference, Connection conn){
		this.entityReference = entityReference;
		this.conn = conn;
	}
	
	
	@Override
	public void run() {
		String bookingStatus = "";
		boolean timeoutHappened = false;
		int timeCounter = 0;

	    while(bookingStatus.equals("")){
	    	try {
	    		Thread.sleep(5*1000);// wait for 5 secs
	    		timeCounter = timeCounter + 5;
	    	} catch (InterruptedException e) {
	    		e.printStackTrace();
	    	} 	
	    	//access the db and get one row from the table by the status
	    	bookingStatus = getPolicyBookingStatus(entityReference, conn);
	    	timeoutHappened = timeCounter >= TIMEOUT_PERIOD?true:false;
	    	if(timeoutHappened && bookingStatus.equals(""))
	    		pollingErrorMessage = "Timeout happened.. No Booking status available";
	    	if(!bookingStatus.equals("") || timeoutHappened){
	    		break;
	    	}
	    }
	}
	
	public String getPolicyBookingStatus(String entityReference, Connection conn){
		String status = "";
		ResultSet rs = null;
		PreparedStatement stmt = null;
		try{
			stmt = conn.prepareStatement(statusQuery);
			stmt.setString(1, entityReference);
			rs = stmt.executeQuery();
			if(rs != null && rs.next()){
				String sts = rs.getString("WAC_STAGE");
				if(Arrays.asList(statusArray).contains(sts)){
					status = "BOOKING_CALL_DONE";
					pollingErrorMessage=!sts.equals("COMPLETE")?rs.getString("WAC_STAGE_DESC"):"";
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try {
				DBUtil.close(rs, stmt);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return status;
	}
	
	public String getPollingErrorMessage(){
		return this.pollingErrorMessage;
	}
	
	public void setPollingErrorMessage(String pollingErrorMessage){
		this.pollingErrorMessage = pollingErrorMessage;
	}
	

}
