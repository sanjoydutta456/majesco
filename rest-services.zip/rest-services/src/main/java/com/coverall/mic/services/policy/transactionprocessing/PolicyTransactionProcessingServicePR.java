package com.coverall.mic.services.policy.transactionprocessing;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.w3c.dom.Document;

import com.coverall.exceptions.SecurityException;
import com.coverall.mic.webservices.policytransaction.PTSBindingDriver;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;
import com.coverall.mt.security.AdminX;
import com.coverall.mt.services.SchedulableService;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServicesDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;
import com.coverall.mt.policytrans.*;
import com.coverall.pctv2.client.exceptions.ProductServiceException;

public class PolicyTransactionProcessingServicePR extends SchedulableService {

	private static final String WEBSERVICE_PARAMS_QUERY = 
			"    SELECT DISTINCT wwp_name," + "      wwp_value" +
					"    FROM ws_webservices," + "      ws_webserviceparameters" +
					"    WHERE wws_id = wwp_wsid" +
					"     AND wws_wsname = ?" +
					"     AND wwp_type = 'general'";

	private static final String ENTITY_REFERENCE_QUERY = 
					"	SELECT entity_reference " +
					"	FROM ev_mis_quote_policies emqp  " +
					"	WHERE entity_type         = 'POLICY'  " +
					"	AND booking_status        = 'COMPLETE'  " +
					"	AND display_policy_number = ?  " +
					"	AND effective_date        = ?  " +
					"	AND revision_number       =  " +
					"	(SELECT MAX(revision_number)  " +
					"	FROM ev_mis_quote_policies  " +
					"	WHERE org_entity_reference = emqp.org_entity_reference  " +
					"	)  ";

	private static final String REASON_CODE_QUERY =
			"SELECT REASON_CODE FROM IEL_MIC_CANCELLATION_FACTORS WHERE REASON_DESC = ? "+
					"AND PRODUCT_CODE = ?";
	
	private static final String POLICY_STATUS = " SELECT k_workflow_activity_management.f_get_status(entity_type,entity_reference) status " +
                                                " FROM vw_mis_quote_policies, mis_policies " +
                                                " WHERE entity_reference = mpo_policy_reference " +
                                                " and mpo_book_flag = 'Y' " +
                                                " and entity_reference = ? " ;
	
	
	

	private static final int POLICY_LENGTH = 13;//17;
	private static final int DATE_LENGTH = 8;
	private static final int RECORD_TYPE_LENGTH = 2;
	private static final int CANCEL_TYPE_LENGTH = 14;
	private static final int REINSTATE_TYPE_LENGTH = 15;
	private static final String HEADER = "01";
	private static final String RECORD = "00";
	private static final String FOOTER = "02";
	private Pattern fileNamePattern = Pattern.compile("((.*)_(.*)_(.*)_.*)");
	private static final String TRX_TYPE_CANCEL = "cancel";
	private static final String TRX_TYPE_REINSTATE = "reinstate";
	private static final String SUCCESS_MESSAGE = "Success";
	private static final String FAILURE_MESSAGE = "Failure";

	/**
	 * Creates a new TransactionProcessingService object.
	 *
	 * @throws RemoteException DOCUMENT ME!
	 */
	public PolicyTransactionProcessingServicePR() throws RemoteException {}

	public String getComponentName() {
		return ServletConfigUtil.COMPONENT_FRAMEWORK;
	}

	/**
	 *
	 * @param request
	 * @param logName
	 * @throws Throwable
	 */
	public Document queueTransaction(Document request, String logName) throws Throwable {
		String paramWebService = null;
		String paramTransactionType = null;
		User user = null;
		Map webServiceParams = null;
		Connection conn = null;
		HashMap transactionParams = null;
		try{
			paramWebService = (String) ServicesDOMUtil.getRequestParameter(request, ServicesDOMUtil.PARAM_WEB_SERVICE_ID);
			paramTransactionType = (String) ServicesDOMUtil.getRequestParameter(request, ServicesDOMUtil.PARAM_TRANSACTION_TYPE);
			user = ServicesDOMUtil.getUser(request);
			conn = ConnectionPool.getConnection(user);
			if(paramWebService != null && !paramWebService.equals("")){
				webServiceParams = getWebServiceParams(paramWebService, conn);
			}

			if(webServiceParams != null){
				/* New code added temp   */
				transactionParams = new HashMap();
				transactionParams.put("PROCESSING_TYPE", "COMPLETE");
				transactionParams.put("SOURCE_SYSTEM", "PolicyTransactionService");
				transactionParams.put("ENTITY_TYPE", "POLICY");
				/* New code added temp   */
				if(paramTransactionType.equalsIgnoreCase(TRX_TYPE_CANCEL)){
					transactionParams.put("CLASSICTRANSACTIONCODE", "04");
					transactionParams.put("ACTION", "cancellation");
					transactionParams.put("TRANSACTION_ACTION", "cancellation");
					processTransactions((String)webServiceParams.get("readFolderLocationCancel"), 
							(String)webServiceParams.get("archiveFolderLocationCancel"), conn, user, TRX_TYPE_CANCEL, transactionParams, webServiceParams);
				}else if(paramTransactionType.equalsIgnoreCase(TRX_TYPE_REINSTATE)){	   
					if(conn.isClosed()){
						conn = ConnectionPool.getConnection(user);
					}
					transactionParams.put("CLASSICTRANSACTIONCODE", "19");
					transactionParams.put("ACTION", "reinstatement");
					transactionParams.put("TRANSACTION_ACTION", "reinstatement");
					processTransactions((String)webServiceParams.get("readFolderLocationReinstate"), 
							(String)webServiceParams.get("archiveFolderLocationReinstate"), conn, user, TRX_TYPE_REINSTATE, transactionParams, webServiceParams);
				}	   
			}

		} catch (Exception ex) {
			ServicesDOMUtil.setResponseParameter(request,
					ServicesDOMUtil.PARAM_STATUS, ServicesDOMUtil.VALUE_STATUS_FAIL);
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,
					getClass().getName(), "queueTransaction",
					ServletConfigUtil.COMPONENT_FRAMEWORK,
					new Object[] { paramWebService},
					ex.getMessage(), ex, LogMinderDOMUtil.VALUE_INTERFACE_PROCESSING);
		}finally{
			if(conn != null && !conn.isClosed()){
				conn.close();
			}
		}
		return request;
	}

	private Map getWebServiceParams(String paramWebService, Connection conn) throws Exception{
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		HashMap webServiceParams = new HashMap();

		try {
			pstmt = conn.prepareStatement(WEBSERVICE_PARAMS_QUERY);
			pstmt.setString(1, paramWebService);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				webServiceParams.put(rs.getString("wwp_name"), rs.getString("wwp_value"));
			}
			if (webServiceParams.size() < 1) {
				throw new Exception("No Data found for Parameter Webservice");
			}
			return webServiceParams;

		} catch (Exception ex) {
			String errorMessage = "Error getting Webservice Parameters.";
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "getWebServiceParams", 
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { paramWebService}, errorMessage, ex,
					LogMinderDOMUtil.VALUE_INTERFACE_PROCESSING);
			throw new Exception(errorMessage, ex);
		} finally {
			try {
				DBUtil.close(rs, pstmt);
			} catch (Exception ex) {
				// Suppress
			}
		}
	}

	private void processTransactions(String readPath, String archivePath, Connection conn, User user, 
			String trxType, HashMap transactionParams, Map webServiceParams){

		File readDir = new File(readPath);
		File[] files = readDir.listFiles();
		File f = null;
		String type = null;
		ArrayList trnxList = null;
		PTSBindingDriver driver = null;
		PrintWriter statusWriter = null;
		String record = "";
		boolean fileFound = false;
		String transactionStatus = null;
		String userId = (String)webServiceParams.get("userId");
		String password = (String)webServiceParams.get("password");
		String statusForRecord = (String)webServiceParams.get("statusForRecord");
		boolean writeEachRecord = "true".equalsIgnoreCase(statusForRecord) ? true : false;  
		TransactionService transactionService = new TransactionService();
		List<PolicyTransactionDetailsVO> availableTransactionList = null;


		SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
		if(files != null && files.length > 0){
			for(int i=0; i<files.length; i++){
				f = files[i];
				type = "";
				String fileName = f.getName();
				Matcher matcher = fileNamePattern.matcher(fileName);
				if (matcher.find()) {
					type = matcher.group(4);
					try{
						if(type.equals(trxType)){
							fileFound = true;
							if(conn.isClosed()){
								conn = ConnectionPool.getConnection(user);
							}
							trnxList = getRecords(readPath, archivePath, f, trxType, conn);




							if(trnxList != null && !trnxList.isEmpty()){
								driver = new PTSBindingDriver();
								boolean hasBookPermission = driver.hasBookPermission(userId.substring(userId.indexOf("@")+1), userId.substring(0, userId.indexOf("@")));

								if(writeEachRecord) {
									statusWriter = getStatusWriter(readPath,trxType);
								}

								int requestCount = 0;
								for(int j=0; j<trnxList.size(); j++){									
									try {
										transactionStatus = "";

										if(conn.isClosed()){
											conn = ConnectionPool.getConnection(user);
										}
										transactionStatus = "";
										record = (String)trnxList.get(j);
										String[] recordVals = record.split("~");


										String cancelMsg = validateData(recordVals[0], recordVals[1], recordVals[3], conn);

										if(cancelMsg.equalsIgnoreCase("In Force")){
											String policyReference = getEntityReference(recordVals[0], recordVals[1], conn);
											String reasonCode = null;

											reasonCode = getReasonCode(recordVals[3],policyReference, conn);
											if(trxType.equals(TRX_TYPE_CANCEL)){
												if(transactionParams != null){
													if(reasonCode == null) {
														throw new Exception("Cancel reason code is null, check table IEL_MIC_CANCELLATION_FACTORS!");
													}

													try {
														String roles = user.getRoleList();
														availableTransactionList = transactionService.getAvailableTransactions(
																"POLICY",
																policyReference,
																user,
																"Y",
																roles,
																null);
													} catch (Exception e) {
														throw new ProductServiceException( 
																e,
																"There is problem while getting available transaction list for policy.");
													}
													if (null != availableTransactionList && availableTransactionList.size() > 0) {
														for (PolicyTransactionDetailsVO policyTransaction : availableTransactionList) {
															if ("cancellation".equalsIgnoreCase(policyTransaction.getTransactionAction())) {

																transactionParams.put("SHOULD_BOOK", hasBookPermission == true?"TRUE":"FALSE");
																transactionParams.put("ENTITY_REFERENCE", policyReference);
																transactionStatus = driver.queueCancellationRequest(policyReference,sdf.parse(recordVals[2]),recordVals[3],
																		reasonCode,userId, conn, transactionParams, password);

																if(transactionStatus != null && transactionStatus.indexOf("FAIL") < 0){
																	requestCount++;
																}	
															}

															else {

																if(writeEachRecord) {

																	if(statusWriter != null) {
																		statusWriter.println(fileName + "," + " Display Policy Number " + recordVals[0]  + FAILURE_MESSAGE + " " + " Policy Not Qualified for Cancel Process.");
																	} else {
																		LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "processTransactions", 
																				ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Exception Occured while Processing file "+f.getName() + ",record " + record
																				+", The status writer is null.", null,
																				LogMinderDOMUtil.VALUE_INTERFACE_PROCESSING);																								
																	}
																}		


															}
														}
													}







												}
											}
										}else {

											if(writeEachRecord) {

												if(statusWriter != null) {
													statusWriter.println(fileName + "," + " Display Policy Number " + recordVals[0]  + FAILURE_MESSAGE + " " + cancelMsg);
												} else {
													LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "processTransactions", 
															ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Exception Occured while Processing file "+f.getName() + ",record " + record
															+", The status writer is null.", null,
															LogMinderDOMUtil.VALUE_INTERFACE_PROCESSING);																								
												}
											}		

										}

										String reinstateMsg = validateData(recordVals[0], recordVals[1], recordVals[3], conn);
										if(reinstateMsg.equalsIgnoreCase("Cancelled")){
											String policyReference = getEntityReference(recordVals[0], recordVals[1], conn);
											String reasonCode = null;

											if(trxType.equals(TRX_TYPE_REINSTATE)){
												
												
												if(transactionParams != null){
													
													try {
														String roles = user.getRoleList();
														availableTransactionList = transactionService.getAvailableTransactions(
																"POLICY",
																policyReference,
																user,
																"Y",
																roles,
																null);
													} catch (Exception e) {
														throw new ProductServiceException(
																e,
																"There is problem while getting available transaction list for policy.");
													}
													
													if (null != availableTransactionList && availableTransactionList.size() > 0) {
														for (PolicyTransactionDetailsVO policyTransaction : availableTransactionList) {
															if ("reinstatement".equalsIgnoreCase(policyTransaction.getTransactionAction())) {

														
													transactionParams.put("SHOULD_BOOK", hasBookPermission == true?"TRUE":"FALSE");
													transactionParams.put("ENTITY_REFERENCE", policyReference);
													transactionStatus = driver.queueReinstatementRequest(policyReference,sdf.parse(recordVals[2]),recordVals[3],
															null,userId, conn, transactionParams, password);

													if(transactionStatus != null && transactionStatus.indexOf("FAIL") < 0){
														requestCount++;
													}													
												}
											else {

											if(writeEachRecord) {
												String msg = reinstateMsg;

												if(statusWriter != null) {
													statusWriter.println(fileName + "," + record + "," + FAILURE_MESSAGE + " " + msg);
												} else {
													LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "processTransactions", 
															ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Exception Occured while Processing file "+f.getName() + ",record " + record
															+", The status writer is null.", null,
															LogMinderDOMUtil.VALUE_INTERFACE_PROCESSING);																								
												}
											}		

										}
								}
						}
										
				}								
			}						
											
		}                                 
										
										if(writeEachRecord) {
											String msg = "";
											if(transactionStatus != null && transactionStatus.indexOf("FAIL") < 0) {
												msg = SUCCESS_MESSAGE;										
											} else {
												msg = FAILURE_MESSAGE;
											}											
											if(statusWriter != null) {
												statusWriter.println(fileName + "," + record + "," + msg);
											} else {
												LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "processTransactions", 
														ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Exception Occured while Processing file "+f.getName() + ",record " + record
														+", The status writer is null.", null,
														LogMinderDOMUtil.VALUE_INTERFACE_PROCESSING);																								
											}
										}											
									}catch(Exception e) {									
										LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "processTransactions", 
												ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Exception Occured while Processing file "+f.getName() + ",record " + record
												+",Exception is: "+ e.getMessage(), e,
												LogMinderDOMUtil.VALUE_INTERFACE_PROCESSING);

										if(writeEachRecord) {										
											statusWriter.println(fileName + "," + record + "," + FAILURE_MESSAGE);
										} else {
											throw new Exception(e);
										}
									} 																
								}

								if(requestCount > 0) {
									copyFile(f, archivePath);									
								}

								if(!writeEachRecord) {
									if(statusWriter != null) {
										statusWriter.close();
									}
									statusWriter = getStatusWriter(readPath,trxType);
									if(requestCount > 0) {
										statusWriter.println(SUCCESS_MESSAGE);
									} else {
										statusWriter.println(FAILURE_MESSAGE);
									}
								}								
							}
						}
					}catch(Exception e){
						LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "processTransactions", 
								ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Exception Occured while Processing file "+f.getName()
								+" Exception is "+e.getMessage(), e,
								LogMinderDOMUtil.VALUE_INTERFACE_PROCESSING);
					} finally {
						if(statusWriter != null) {
							try {
								statusWriter.close();
							}catch(Exception ex) {
								;
							}
						}
					}
				}
			}
			if(!fileFound){
				try {
					createStatusFiles(readPath,trxType,FAILURE_MESSAGE);
					LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "processTransactions", 
							ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "No files found for transaction type "+trxType, null,
							LogMinderDOMUtil.VALUE_INTERFACE_PROCESSING);
				} catch (IOException e) {
					LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "processTransactions", 
							ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Exception Occured while creating Failure acknowledgement file "
									+" Exception is "+e.getMessage(), e,
									LogMinderDOMUtil.VALUE_INTERFACE_PROCESSING);
				}
			}
		}else{
			try {
				createStatusFiles(readPath,trxType,FAILURE_MESSAGE);
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "processTransactions", 
						ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "No files found for transaction type "+trxType+ ". Folder is empty", null,
						LogMinderDOMUtil.VALUE_INTERFACE_PROCESSING);
			} catch (IOException e) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "processTransactions", 
						ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Exception Occured while creating Failure acknowledgement file "
								+" Exception is "+e.getMessage(), e,
								LogMinderDOMUtil.VALUE_INTERFACE_PROCESSING);
			}
		}
	}

	private void copyFile(File file, String archivePath) throws Exception{
		File copyDir = new File(archivePath);	   
		if(file != null){
			FileUtils.copyFileToDirectory(file, copyDir);
			file.delete();
		}
	}
	
	private void createStatusFiles(String readPath, String trxType, String message) throws IOException{
		PrintWriter pw = getStatusWriter(readPath, trxType);
		pw.println(message);
		if(pw != null){
			pw.close();
		}
	}
	
	private PrintWriter getStatusWriter(String readPath, String trxType) throws IOException{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmssSSS");
		String dateTime = sdf.format(new Date());
		String filePath = readPath+File.separator+"ncl_"+trxType+"_status_"+dateTime+".txt";
		LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG,
				getClass().getName(), "createStatusFiles",
				ServletConfigUtil.COMPONENT_FRAMEWORK,
				new Object[] { dateTime, filePath },
				null, null, LogMinderDOMUtil.VALUE_INTERFACE_PROCESSING);
		File file = new File(filePath);
		if(!file.exists()){
			file.createNewFile();
		}	   
		LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG,
				getClass().getName(), "createStatusFile",
				ServletConfigUtil.COMPONENT_FRAMEWORK,
				new Object[] { file.exists(), file.canWrite()},
				null, null, LogMinderDOMUtil.VALUE_INTERFACE_PROCESSING);

		PrintWriter pw = new PrintWriter(new FileOutputStream(file));		
		return pw;
	}
	
	private void logStatus(File statusFile, String record, String status, String message) throws IOException{
		PrintWriter pw = new PrintWriter(new FileOutputStream(statusFile));		
		pw.println(record + "," + status+ "," + message);
		
		if(pw != null){
			pw.close();
		}
	}	

	private ArrayList getRecords(String readPath, String archivePath, File file, String trxType, Connection conn) throws Exception{
		ArrayList list = new ArrayList();
		BufferedReader brd = null;
		boolean hasHeader = false;
		boolean hasFooter = false;
		boolean hasPolicyData = false;
		if(file != null){   
			brd = new BufferedReader(new FileReader(file));
			String policyNum = "";
			String reason = "";
			String transEffectiveDate = "";
			String policyEffectiveDate = "";
			String reasonCode = "";
			String line = "";
			while((line = brd.readLine()) != null){
				if(!line.equals("") && line.length() > 2){
					if(line.substring(0, RECORD_TYPE_LENGTH).equals(HEADER)){
						hasHeader = true;
					}else if(line.substring(0, RECORD_TYPE_LENGTH).equals(RECORD)){
						hasPolicyData = true;
						if(line.length() > POLICY_LENGTH+RECORD_TYPE_LENGTH+DATE_LENGTH+DATE_LENGTH){
							policyNum = line.substring(RECORD_TYPE_LENGTH, POLICY_LENGTH+RECORD_TYPE_LENGTH);
							policyEffectiveDate = line.substring(POLICY_LENGTH+RECORD_TYPE_LENGTH, POLICY_LENGTH+RECORD_TYPE_LENGTH+DATE_LENGTH);
							transEffectiveDate = line.substring(POLICY_LENGTH+RECORD_TYPE_LENGTH+DATE_LENGTH, POLICY_LENGTH+RECORD_TYPE_LENGTH+DATE_LENGTH+DATE_LENGTH);
							reason = line.substring(POLICY_LENGTH+RECORD_TYPE_LENGTH+DATE_LENGTH+DATE_LENGTH);
							list.add(policyNum+"~"+policyEffectiveDate+"~"+transEffectiveDate+"~"+reason);
							
						}else {
							
							LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "getRecords", 
									ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { line}, 
									" Records in " + file.getName() + " don't have minimum records to process " + trxType + "process.", null, LogMinderDOMUtil.VALUE_INTERFACE_PROCESSING);
						}
					}else if(line.substring(0, RECORD_TYPE_LENGTH).equals(FOOTER)){
						hasFooter = true;
						break;
					}
				}
			}
			if(brd != null){
				brd.close();
			}
			if(list.size() == 0){
				if(hasHeader && hasFooter && !hasPolicyData){
					copyFile(file, archivePath);
					createStatusFiles(readPath,trxType,SUCCESS_MESSAGE);
				}else{
					createStatusFiles(readPath,trxType,FAILURE_MESSAGE);
				}
			}else{
				if(!hasHeader || !hasFooter){
					createStatusFiles(readPath,trxType,FAILURE_MESSAGE);
					list = new ArrayList();
				}
			}    	  
		}
		if(brd != null){
			brd.close();
		}
		return list;		   
	}

	private String getEntityReference(String policyNum, String policyEffectiveDate, Connection conn){
		String entityRef = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Date effectiveDate = null;
		SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
		try {
			effectiveDate = sdf.parse(policyEffectiveDate);
			pstmt = conn.prepareStatement(ENTITY_REFERENCE_QUERY);
			pstmt.setString(1, policyNum);
			pstmt.setDate(2, new java.sql.Date(effectiveDate.getTime()));
			rs = pstmt.executeQuery();
			if (rs.next()) {
				entityRef = rs.getString("ENTITY_REFERENCE");
			}

		} catch (Exception ex) {
			String errorMessage = "Error getting Entity Reference.";
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "getEntityReference", 
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { policyNum, policyEffectiveDate}, errorMessage, ex,
					LogMinderDOMUtil.VALUE_INTERFACE_PROCESSING);
		} finally {
			try {
				DBUtil.close(rs, pstmt);
			} catch (Exception ex) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "getEntityReference", 
						ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { policyNum, policyEffectiveDate}, "Error closing resultset", ex,
						LogMinderDOMUtil.VALUE_INTERFACE_PROCESSING);
			}
		}
		return entityRef;
	}

	private String getReasonCode(String reason, String policyReference, Connection conn){
		String reasonCode = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String productCode = "";
		try {
			productCode = policyReference.substring(3, 5);
			pstmt = conn.prepareStatement(REASON_CODE_QUERY);
			pstmt.setString(1, reason);
			pstmt.setString(2, productCode);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				reasonCode = rs.getString("REASON_CODE");
			}

		} catch (Exception ex) {
			String errorMessage = "Error getting Reason Code.";
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "getReasonCode", 
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { policyReference, reason}, errorMessage, ex,
					LogMinderDOMUtil.VALUE_INTERFACE_PROCESSING);
		} finally {
			try {
				DBUtil.close(rs, pstmt);
			} catch (Exception ex) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "getReasonCode", 
						ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { policyReference, reason}, "Error closing resultset", ex,
						LogMinderDOMUtil.VALUE_INTERFACE_PROCESSING);
			}
		}
		return reasonCode;
	}
	
	
	private String getPolicyStatus(String policyReference, Connection conn){
		String policyStatus = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String productCode = "";
		try {
			pstmt = conn.prepareStatement(POLICY_STATUS);
			pstmt.setString(1, policyReference);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				policyStatus = rs.getString("status");
			}

		} catch (Exception ex) {
			String errorMessage = "Error getting Policy Status.";
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "getPolicyStatus", 
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { policyReference, policyStatus}, errorMessage, ex,
					LogMinderDOMUtil.VALUE_INTERFACE_PROCESSING);
		} finally {
			try {
				DBUtil.close(rs, pstmt);
			} catch (Exception ex) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, getClass().getName(), "getPolicyStatus", 
						ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] { policyReference, policyStatus}, "Error closing resultset", ex,
						LogMinderDOMUtil.VALUE_INTERFACE_PROCESSING);
			}
		}
		return policyStatus;
	}
	
	public String validateData(String displayPOlicyNumber, String effectiveDate,
			String reason, Connection con) {
		StringBuffer errorMessage = new StringBuffer("");
		SimpleDateFormat df = new SimpleDateFormat("mm/dd/yyyy");
		String policyReference = null;
		String policyStatus = null;
		String reasonCode = null;

		if (null != displayPOlicyNumber && null != effectiveDate) {
			policyReference = getEntityReference(displayPOlicyNumber,
					effectiveDate, con);

			if (null != policyReference) {
				if (null != reason) {

					reasonCode = getReasonCode(reason, policyReference, con);

					if (null != reasonCode) {

						policyStatus = getPolicyStatus(policyReference, con);

						if (null != policyStatus) {

							errorMessage.append(" Status of Policy "
									+ policyStatus);

						} else {
							errorMessage.append(" Policy is not Booked. ");

						}

					} else {

						errorMessage
						.append(" Cancel Reason Code is empty , Please check IEL_MIC_CANCELLATION_FACTORS table. ");

					}

				} else {

					errorMessage
					.append(" Cancallation Reason should not be empty. ");

				}

			} else {
				errorMessage
				.append(" Record does not exists - mismatch in coverall and Tronweb effective date. , Please correct the effective date to process. ");
			}

		} else {

			errorMessage
			.append(" Please correct the records before processing Cancellation Service. Record is not correct. ");

		}

		return errorMessage.toString();
	}

}
