package com.coverall.mic.services.policy.transactionprocessing;

import java.sql.Connection;
import java.util.HashMap;

import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.pctv2.server.service.PCTTransactions;
import com.coverall.util.DBUtil;

public class PolicyTransactionProcessor {
	
	private String transactionStatus;
	private String statusDetails;
	
	public String getTransactionStatus() {
		return transactionStatus;
	}
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	public String getStatusDetails() {
		return statusDetails;
	}
	public void setStatusDetails(String statusDetails) {
		this.statusDetails = statusDetails;
	}
	
	public void processTransaction(HashMap params, String userId, String password, String domain) throws Exception{
		
		User user =  new User(userId + "@" + domain,
					password);
				
		PCTTransactions pCTTransactions = new PCTTransactions(
				user,
                params,
                userId + "@" + domain,
                0);
		LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO, this.getClass().getName(),
                "processTransaction",
                ServletConfigUtil.COMPONENT_FRAMEWORK,
                new Object[] { }, "Processing "+params.get("TRANSACTION_ACTION")+ " for entity reference "+ params.get("ENTITY_REFERENCE"), null,
                LogMinderDOMUtil.VALUE_WEBSERVICES);
        pCTTransactions.start();
        pCTTransactions.join();
       
        this.statusDetails = pCTTransactions.getStatusDetails();
        this.transactionStatus = pCTTransactions.getItemStatus();
        
        LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO, this.getClass().getName(),
                "processTransaction",
                ServletConfigUtil.COMPONENT_FRAMEWORK,
                new Object[] { }, "Pre Booking status for "+ params.get("ENTITY_REFERENCE") + " is "+this.transactionStatus, null,
                LogMinderDOMUtil.VALUE_WEBSERVICES);
        LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO, this.getClass().getName(),
                "processTransaction",
                ServletConfigUtil.COMPONENT_FRAMEWORK,
                new Object[] { }, "Pre Booking status message for "+ params.get("ENTITY_REFERENCE") + " is "+this.statusDetails, null,
                LogMinderDOMUtil.VALUE_WEBSERVICES);
        
        if(this.transactionStatus.indexOf("FAIL") < 0){
        	Connection conn = null;
        	BookingStatusPolling bookingStatus = null;
        	try{
        		conn = ConnectionPool.getConnection(user);
        		bookingStatus = new BookingStatusPolling((String)params.get("ENTITY_REFERENCE"), conn);
        		bookingStatus.start();
        		bookingStatus.join();
        	}catch(Exception e){
        		LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, this.getClass().getName(),
        				"processTransaction",
        				ServletConfigUtil.COMPONENT_FRAMEWORK,
        				new Object[] { }, "Exception Occured while polling booking status for "+ params.get("ENTITY_REFERENCE"), e,
        				LogMinderDOMUtil.VALUE_WEBSERVICES);
        		throw e;
        	}finally{
        		DBUtil.close(conn);
        	}
        
        	if(!bookingStatus.getPollingErrorMessage().equals("")){
        		this.transactionStatus = "FAILED";
        		this.statusDetails = bookingStatus.getPollingErrorMessage();
        		
        		LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, this.getClass().getName(),
                        "processTransaction",
                        ServletConfigUtil.COMPONENT_FRAMEWORK,
                        new Object[] { }, "Failed to Book the transaction for "+ params.get("ENTITY_REFERENCE")+" transaction Status is "+this.transactionStatus + " Status Details : "+this.statusDetails, null,
                        LogMinderDOMUtil.VALUE_WEBSERVICES);
        	}
        	
        	LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO, this.getClass().getName(),
                    "processTransaction",
                    ServletConfigUtil.COMPONENT_FRAMEWORK,
                    new Object[] { }, "Post Booking status for "+ params.get("ENTITY_REFERENCE") + " is "+this.transactionStatus, null,
                    LogMinderDOMUtil.VALUE_WEBSERVICES);
            LogMinder.getLogMinder().log(LogEntry.SEVERITY_INFO, this.getClass().getName(),
                    "processTransaction",
                    ServletConfigUtil.COMPONENT_FRAMEWORK,
                    new Object[] { }, "Post Booking status message for "+ params.get("ENTITY_REFERENCE") + " is "+this.statusDetails, null,
                    LogMinderDOMUtil.VALUE_WEBSERVICES);
        }else{
        	// Log the Error
        	 LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL, this.getClass().getName(),
                     "processTransaction",
                     ServletConfigUtil.COMPONENT_FRAMEWORK,
                     new Object[] { }, "Transaction Creation failed for "+ params.get("ENTITY_REFERENCE")+" transaction Status is "+this.transactionStatus + " Status Details : "+this.statusDetails, null,
                     LogMinderDOMUtil.VALUE_WEBSERVICES);
        }
    }

}
