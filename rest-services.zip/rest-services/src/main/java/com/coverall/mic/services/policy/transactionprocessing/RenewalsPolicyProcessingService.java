package com.coverall.mic.services.policy.transactionprocessing;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.w3c.dom.Document;

import com.coverall.mic.webservices.policytransaction.PTSBindingDriver;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;
import com.coverall.mt.services.SchedulableService;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServicesDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;
import com.coverall.util.validators.FilePathValidator;

public class RenewalsPolicyProcessingService extends SchedulableService {
    

    private static final long serialVersionUID = 1L;
    
    private static final String WEBSERVICE_PARAMS_QUERY = 
            "    SELECT DISTINCT wwp_name," + "      wwp_value" +
            "    FROM ws_webservices," + "      ws_webserviceparameters" +
            "    WHERE wws_id = wwp_wsid" +
            "     AND wws_wsname = ?";  
    
    private static final String RENEWAL_QUALIFICATION_QUERY = 
            "    SELECT vmqp.entity_reference ENTITY_REFERENCE, vmqp.entity_type ENTITY_TYPE " +
            "           , vmqp.display_policy_number DISPLAY_NUMBER, vmqp.effective_date EFFECTIVE_DATE" +
            "    FROM vw_mis_quote_policies vmqp, mis_prerenewal_list mpl " +
            "    WHERE vmqp.entity_reference       = mpl.mpv_renewed_policy_ref " +
            "      AND vmqp.entity_type              = mpl.mpv_renewed_policy_type " + 
            "      AND NVL(mpl.mpv_renewal_flag,'N') = 'Y' " +
            "      AND vmqp.new_entity_reference is null " +
            "      AND sysdate                      >= vmqp.effective_date - ? " +
            "      AND (SELECT DECODE(COUNT(1),0,'N','Y') " +
            "           FROM wfl_activities " +
            "           WHERE wac_workflow_task_id = " +
            "             (SELECT task_id " +
            "              FROM " +
            "               (SELECT wwt_id task_id " +
            "                FROM wfl_workflow_tasks " +
            "                WHERE wwt_workflow_id = " +
            "                 (SELECT wwo_id FROM wfl_workflows WHERE upper(wwo_entity_type) = 'QUOTE') " +
            "                ORDER BY wwt_sequence DESC " +
            "               ) " +
            "              WHERE rownum < 2 " +
            "             ) " +
            "             AND NVL(wac_stage,'XXX') = 'COMPLETE' " +
            "             AND wac_entity_reference = vmqp.entity_reference " +
            "             AND wac_entity_type      = vmqp.entity_type) = 'Y' " ;

    
    private static final String DAYS_BEFORE_EXPIRATION = "daysBeforeExpiration";
    private static final String USERID = "userId";
    private static final String PASSWORD = "password";
    private static final String LOG_FILE_LOCATION = "logFileLocation";
    private static final String SUCCESS_MESSAGE = "Success";
    private static final String FAILURE_MESSAGE = "Failure";  
    private static final String STATUS_FOR_EACH_REC = "statusForEachRecord";
    private static final String Renewal_FAILURE_MESSAGE ="Success No policies to renew";
    PrintWriter taskLogWriter = null;
    
    
    public RenewalsPolicyProcessingService() throws RemoteException {
        super();
    }

    @Override
    public String getComponentName() {
        return ServletConfigUtil.COMPONENT_FRAMEWORK;
    }
    
    public Document queueTransaction(Document request, String logName) throws Throwable {
        
        String paramWebService = null;
        User user = null;
        Map<String, String> webServiceParams = null;
        Connection conn = null;
        HashMap<String, String> transactionParams = null;
        List<String> recordsList = null;
        PTSBindingDriver driver = null;
        String[] transactionStatus = null;
        int requestCount = 0;
        boolean hasBookPermission = false;
        String username = null;
        String logFileLocation = null;
        PrintWriter logFileWriter = null;
		String statusForEachRecord = null;
        try{
            paramWebService = (String) ServicesDOMUtil.getRequestParameter(request, ServicesDOMUtil.PARAM_WEB_SERVICE_ID);
            boolean writeStatusForEachRecord = false; 
            user = ServicesDOMUtil.getUser(request);
            
            if (user != null){
                conn = ConnectionPool.getConnection(user);
            }
            
            String taskLogFile = (String) ServicesDOMUtil.getRequestParameter(request,ServicesDOMUtil.PARAM_TASK_LOG_FILE);
            taskLogWriter = new PrintWriter(new FileWriter(new File(taskLogFile)));
            taskLogWriter.println("<table width=\"100%\">");
            setHeader(taskLogWriter, false); 
            
            if(paramWebService != null && !paramWebService.equals("")){
                try{
                    webServiceParams = getWebServiceParams(paramWebService, conn);
                }catch(Exception e){
                    e = new Exception("Error getting parameters for webservice: '" + paramWebService + "'. " + e.getMessage());
                    if (taskLogWriter != null ) {
                        taskLogWriter.println("<tr class=\"PrintDataText\"><td colspan=\"8\" style=\"color:RED\"> " + e.getMessage() + "</td></tr>");                        
                    }
                    throw e;
                 } 
            }

            if(webServiceParams != null){  
                try{
                    validateWebServiceParams(webServiceParams, conn);
                    LogMinder.getLogMinder().log(
                            LogEntry.SEVERITY_DEBUG,
                            getClass().getName(),
                            "queueTransaction",
                            ServletConfigUtil.COMPONENT_FRAMEWORK,
                            new Object[] { "request: " + request  },
                            "Renewal Webservice prameters list: " + webServiceParams,
                            null,
                            LogMinderDOMUtil.VALUE_ADMIN);                      
                }catch(Exception e){
                    e = new Exception("Error validating webservice parameters for webservice: '" + paramWebService + "'. " + e.getMessage());
                    LogMinder.getLogMinder().log(
                            LogEntry.SEVERITY_FATAL,
                            getClass().getName(),
                            "queueTransaction",
                            ServletConfigUtil.COMPONENT_FRAMEWORK,
                            new Object[] { request },
                            e.getMessage(),
                            e,
                            LogMinderDOMUtil.VALUE_ADMIN);                    
                    if (taskLogWriter != null ) {
                        taskLogWriter.println("<tr class=\"PrintDataText\"><td colspan=\"8\" style=\"color:RED\"> " + e.getMessage() + "</td></tr>");                        
                    }                    
                    throw e;
                }                
                
                transactionParams = new HashMap<String, String>();
                transactionParams.put("PROCESSING_TYPE", "COMPLETE");
                transactionParams.put("SOURCE_SYSTEM", "PolicyRenewalsTransactionService");
                transactionParams.put("CLASSICTRANSACTIONCODE", "14");
                transactionParams.put("ACTION", "convertQuote");
                transactionParams.put("TRANSACTION_ACTION", "convertQuote"); 
                
                
                recordsList = getRecordsToProcess(webServiceParams, conn);
                logFileLocation = webServiceParams.get(LOG_FILE_LOCATION);
                logFileWriter = getLogFileWriter(logFileLocation);
        		statusForEachRecord = (String)webServiceParams.get(STATUS_FOR_EACH_REC);        		
        		writeStatusForEachRecord = "true".equalsIgnoreCase(statusForEachRecord) ? true : false;                
                
                if (null != recordsList && !recordsList.isEmpty()){
                    LogMinder.getLogMinder().log(
                            LogEntry.SEVERITY_DEBUG,
                            getClass().getName(),
                            "queueTransaction",
                            ServletConfigUtil.COMPONENT_FRAMEWORK,
                            new Object[] { },
                            "Records list to Process: " + recordsList,
                            null,
                            LogMinderDOMUtil.VALUE_ADMIN);  
                    
                    driver = new PTSBindingDriver();
                    
                    username = webServiceParams.get(USERID);
                    hasBookPermission = driver.hasBookPermission(username.substring(username.indexOf("@")+1),username.substring(0, username.indexOf("@")));                    
                    transactionParams.put("SHOULD_BOOK", hasBookPermission == true?"TRUE":"FALSE");
                    
                    Iterator<String> iterator = recordsList.iterator();
                    while (iterator.hasNext()) {
                        String record = null;
                        try {
                            record = iterator.next();
                            if (null != record) {
                                String[] recordArray = record.split("~");
                                transactionParams.put("ENTITY_REFERENCE", recordArray[0]);
                                transactionParams.put("ENTITY_TYPE", recordArray[1]);
                                
                                LogMinder.getLogMinder().log(
                                        LogEntry.SEVERITY_DEBUG,
                                        getClass().getName(),
                                        "queueTransaction",
                                        ServletConfigUtil.COMPONENT_FRAMEWORK,
                                        new Object[] { record, transactionParams },
                                        "Initiating convert request for record : " + record + ". Transaction parameters: " + transactionParams,
                                        null,
                                        LogMinderDOMUtil.VALUE_ADMIN);                                 
                                transactionStatus = driver.queueConvertToBinderRequest(recordArray[0], conn, transactionParams, username, webServiceParams.get(PASSWORD));
                                LogMinder.getLogMinder().log(
                                        LogEntry.SEVERITY_DEBUG,
                                        getClass().getName(),
                                        "queueTransaction",
                                        ServletConfigUtil.COMPONENT_FRAMEWORK,
                                        new Object[] { },
                                        "Transaction status recieved after processing Quote with reference number: " + recordArray[0] + " is = " + transactionStatus ,
                                        null,
                                        LogMinderDOMUtil.VALUE_ADMIN);                                 
                                if (transactionStatus != null && transactionStatus.length > 0) {
                                    taskLogWriter.println(getLog(recordArray[2], recordArray[3], transactionStatus[0], transactionStatus[1]));
                                	if (logFileWriter != null) {
                                		if(null != recordsList && recordsList.isEmpty()){
                                			 if (writeStatusForEachRecord){
                                			logFileWriter.println(record + "," + Renewal_FAILURE_MESSAGE );
                                			 }
                                		}
                                		else{
	                                    if(transactionStatus[0] != null && transactionStatus[0].indexOf("FAIL") < 0) {
	                                        if (writeStatusForEachRecord){
	                                        	logFileWriter.println(record + "," + SUCCESS_MESSAGE );
	                                        }
	                                        requestCount++;
	                                    } else {
	                                    	if (writeStatusForEachRecord){
	                                    		logFileWriter.println(record + "," + FAILURE_MESSAGE  + "," + transactionStatus[1] );
	                                    	}
	                                    } 
                                		}
                                    }else {
                                        LogMinder.getLogMinder().log(
                                                LogEntry.SEVERITY_FATAL,
                                                getClass().getName(),
                                                "queueTransaction",
                                                ServletConfigUtil.COMPONENT_FRAMEWORK,
                                                new Object[] {},
                                                "Exception Occured while Processing record : " + record
                                                        + ", The status log writer is null.",
                                                null,
                                                LogMinderDOMUtil.VALUE_ADMIN);                                                                                              
                                    }   
                                }
                            }
                        } catch (Exception e) {
                            LogMinder.getLogMinder().log(
                                    LogEntry.SEVERITY_FATAL,
                                    getClass().getName(),
                                    "queueTransaction",
                                    ServletConfigUtil.COMPONENT_FRAMEWORK,
                                    new Object[] {},
                                    "Exception Occured while Processing record: " + record + ",Exception is: "
                                            + e.getMessage(),
                                    e,
                                    LogMinderDOMUtil.VALUE_ADMIN);
                            if(writeStatusForEachRecord && logFileWriter != null) {
                                logFileWriter.println(record + "," + FAILURE_MESSAGE + "," + e.getMessage());
                            }
                        }
                    }
                    if (!writeStatusForEachRecord && logFileWriter != null){
                    	
                    	if(null != recordsList && recordsList.isEmpty()){
                			logFileWriter.println( Renewal_FAILURE_MESSAGE );
                		}
                    	else{
                    	if(requestCount > 0){
                    		logFileWriter.println(SUCCESS_MESSAGE);
                    	}else{
                    		logFileWriter.println(FAILURE_MESSAGE);
                    	}
                    	}
                    }
                    if (taskLogWriter != null ) {
                        taskLogWriter.println("<tr class=\"PrintDataText\"><td colspan=\"8\" > Total No. of Policies selected for processing: " + recordsList.size() +"</td></tr>");                  
                        taskLogWriter.println("<tr class=\"PrintDataText\"><td colspan=\"8\" > Total No. of Policies processed successfully: " + requestCount +"</td></tr>");                        
                    }  
                } else{
                    if(logFileWriter != null) {
                    	if(null != recordsList && recordsList.isEmpty()){
                			logFileWriter.println(Renewal_FAILURE_MESSAGE );
                		}
                    	else{
                        if (writeStatusForEachRecord){
                        	logFileWriter.println(FAILURE_MESSAGE + "," + "Zero records selected for the run.");
                        }else{
                        	logFileWriter.println(FAILURE_MESSAGE);
                        }
                    	}
                    }
                    LogMinder.getLogMinder().log(
                            LogEntry.SEVERITY_DEBUG,
                            getClass().getName(),
                            "queueTransaction",
                            ServletConfigUtil.COMPONENT_FRAMEWORK,
                            new Object[] {webServiceParams, transactionParams, recordsList },
                            "Zero records selected for the run.",
                            null,
                            LogMinderDOMUtil.VALUE_ADMIN);                    
                }
            }
        } catch(Exception ex) {
            ServicesDOMUtil.setResponseParameter(
                    request,
                    ServicesDOMUtil.PARAM_STATUS,
                    ServicesDOMUtil.VALUE_STATUS_FAIL);
            LogMinder.getLogMinder().log(
                    LogEntry.SEVERITY_FATAL,
                    getClass().getName(),
                    "queueTransaction",
                    ServletConfigUtil.COMPONENT_FRAMEWORK,
                    new Object[] { paramWebService },
                    ex.getMessage(),
                    ex,
                    LogMinderDOMUtil.VALUE_ADMIN);            
        } finally {
            if (taskLogWriter != null ) {
                taskLogWriter.println("</table>");
                taskLogWriter.close();              
            }
            
            if(logFileWriter != null) {
                try {
                    logFileWriter.close();
                }catch(Exception ex) {
                }
            }            

            if(conn != null && !conn.isClosed()){
                conn.close();
            }            
        }
        return request;
    }
        
    private void setHeader(PrintWriter pw, boolean pageBreak) {
        if (pageBreak) {
            pw.println("<tr style=\"page-break-before: always\">");
        } else {
            pw.println("<tr>");
        }
        pw.println("<TD class=\"PrintTableSortableColumnHeader\"><FONT class=\"TaskLogTableRowHeader\">Pre-Renewal Policy Number</FONT></TD>");
        pw.println("<TD class=\"PrintTableSortableColumnHeader\"><FONT class=\"TaskLogTableRowHeader\">Effective Date</FONT></TD>");
        pw.println("<TD class=\"PrintTableSortableColumnHeader\" ><FONT class=\"TaskLogTableRowHeader\">Status</FONT></TD>");
        pw.println("<TD class=\"PrintTableSortableColumnHeader\" ><FONT class=\"TaskLogTableRowHeader\">Description</FONT></TD>");
        pw.println("</tr>");        
    }

    private Map<String,String> getWebServiceParams(String paramWebService, Connection conn) throws Exception {
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Map<String,String> webServiceParams = new HashMap<String,String>();

        try {
            pstmt = conn.prepareStatement(WEBSERVICE_PARAMS_QUERY);
            pstmt.setString(1, paramWebService);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                webServiceParams.put(rs.getString("wwp_name"), rs.getString("wwp_value"));
            }
            if (webServiceParams.size() < 1) {
                throw new Exception("No Data found for Parameter Webservice");
            }
            return webServiceParams;

        } catch (Exception ex) {
            String errorMessage = "Error getting Webservice Parameters.";
            LogMinder.getLogMinder().log(
                    LogEntry.SEVERITY_FATAL,
                    getClass().getName(),
                    "getWebServiceParams",
                    ServletConfigUtil.COMPONENT_FRAMEWORK,
                    new Object[] { paramWebService },
                    errorMessage,
                    ex,
                    LogMinderDOMUtil.VALUE_ADMIN);
            throw new Exception(errorMessage, ex);
        } finally {
            try {
                DBUtil.close(rs, pstmt);
            } catch (Exception ex) {
                // Suppress
            }
        }
    }
    
    private void validateWebServiceParams(Map<String, String> webServiceParams, Connection connection) throws Exception {
        String daysBeforeExpiration = null;
        String username = null;
        String password = null; 
        String logFileLocation = null;
        daysBeforeExpiration = webServiceParams.get(DAYS_BEFORE_EXPIRATION);
        if(null == daysBeforeExpiration || "".equalsIgnoreCase(daysBeforeExpiration.trim())){
            throw new Exception("Webservice Parameter: 'Number Of days Before Expiration Date' could not be blank.");
        }
        
        username = webServiceParams.get(USERID);
        if(null == username || "".equalsIgnoreCase(username.trim())){
            throw new Exception("Webservice Parameter: 'User Id' could not be blank.");
        }   
        
        password = webServiceParams.get(PASSWORD);
        if(null == password || "".equalsIgnoreCase(password.trim())){
            throw new Exception("Webservice Parameter: 'Password' could not be blank.");
        } 
        
        logFileLocation = webServiceParams.get(LOG_FILE_LOCATION);
        try{
            FilePathValidator.validate(LOG_FILE_LOCATION, logFileLocation);
        }catch(Exception e){
            throw e;
        }        
    }    
    
    private List<String> getRecordsToProcess(Map<String, String> webServiceParams, Connection conn) throws Exception {
        String daysBeforeExpiration = (String) webServiceParams.get(DAYS_BEFORE_EXPIRATION);
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<String> recordsList = new ArrayList<String>();
        try {
            pstmt = conn.prepareStatement(RENEWAL_QUALIFICATION_QUERY);
            pstmt.setString(1, daysBeforeExpiration);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                recordsList.add(rs.getString("ENTITY_REFERENCE") + "~" + rs.getString("ENTITY_TYPE") + "~" + rs.getString("DISPLAY_NUMBER") + "~" + rs.getString("EFFECTIVE_DATE"));
            }
            LogMinder.getLogMinder().log(
                    LogEntry.SEVERITY_DEBUG,
                    getClass().getName(),
                    "getRecordsToProcess",
                    ServletConfigUtil.COMPONENT_FRAMEWORK,
                    new Object[] { daysBeforeExpiration },
                    "Number of Days before Expiration Date: " + daysBeforeExpiration + ". Qualification Query: " + RENEWAL_QUALIFICATION_QUERY + ". Total No. of Policies selected for processing: " + recordsList.size(),
                    null,
                    LogMinderDOMUtil.VALUE_ADMIN);            
        } catch (Exception ex) {
            String errorMessage = "Error getting list of pre-renewal records.";
            LogMinder.getLogMinder().log(
                    LogEntry.SEVERITY_FATAL,
                    getClass().getName(),
                    "getRecordsToProcess",
                    ServletConfigUtil.COMPONENT_FRAMEWORK,
                    new Object[] { daysBeforeExpiration },
                    errorMessage,
                    ex,
                    LogMinderDOMUtil.VALUE_ADMIN);
            throw new Exception(errorMessage, ex);
        } finally {
            try {
                DBUtil.close(rs, pstmt);
            } catch (Exception ex) {
                // Suppress
            }
        }
        return recordsList;
    }
    
    private String getLog(String policyNumber, String effectiveDate, String policyStatus, String statusDescription) {
        String str = "<tr class=\"PrintTableCellTextBand\">";
        str += ("<td>" + policyNumber + "</td>");
        str += ("<td>" + effectiveDate + "</td>");
        str += ("<td>" + policyStatus + "</td>");
        str += ("<td>" + statusDescription + "</td>");
        str += "</tr>";
        return str;
    }  
    
    private PrintWriter getLogFileWriter(String logFileLocation) throws IOException{
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmssSSS");
        String dateTime = sdf.format(new Date());
        String filePath = logFileLocation+File.separator+"ncl_renewal_status_"+dateTime+".txt";
        LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG,
                getClass().getName(), "getLogFileWriter",
                ServletConfigUtil.COMPONENT_FRAMEWORK,
                new Object[] { dateTime, filePath },
                null, null, LogMinderDOMUtil.VALUE_ADMIN);
        File file = new File(filePath);
        if(!file.exists()){
            file.createNewFile();
        }      
        LogMinder.getLogMinder().log(LogEntry.SEVERITY_DEBUG,
                getClass().getName(), "getLogFileWriter",
                ServletConfigUtil.COMPONENT_FRAMEWORK,
                new Object[] { file.exists(), file.canWrite()},
                null, null, LogMinderDOMUtil.VALUE_ADMIN);

        PrintWriter pw = new PrintWriter(new FileOutputStream(file));       
        return pw;
    }    

}
