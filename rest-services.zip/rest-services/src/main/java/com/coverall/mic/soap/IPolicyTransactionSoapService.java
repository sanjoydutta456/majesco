/**
 * 
 */
package com.coverall.mic.soap;

import javax.jws.WebService;

/**
 * @author Harish.Gupta
 * @description This interface contains all the services to process the
 *              transactions using web service
 * @return com.coverall.mic.soap.ProcessTransactionResponse.java
 * @param com
 *            .coverall.mic.soap.ProcessTransactionRequest.java
 * 
 * 
 */
@WebService
public interface IPolicyTransactionSoapService {

	ProcessTransactionResponse processChangeProducerTransaction(ProcessTransactionRequest request);
	
	ProcessTransactionResponse processCancellationTransaction(ProcessTransactionRequest request);
	
	ProcessTransactionResponse processReinstatementTransaction(ProcessTransactionRequest request);
	
	ProcessTransactionResponse processRewriteTransaction(ProcessTransactionRequest request);

	BookingResponse processBooking(BookingRequest request);
	
	PurgeResponse processPurge(PurgeRequest request);
	
	ProcessTransactionResponse processIssuanceTransaction(IssuanceRequest request);

	
}
