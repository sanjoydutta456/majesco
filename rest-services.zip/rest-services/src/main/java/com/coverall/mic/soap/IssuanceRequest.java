/**
 * 
 */
package com.coverall.mic.soap;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Kaushik87149
 *
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class IssuanceRequest {

	@XmlElement(required = true)
	protected String policyReference;


	public String getPolicyReference() {
		return policyReference;
	}

	public void setPolicyReference(String policyReference) {
		this.policyReference = policyReference;
	}


}
