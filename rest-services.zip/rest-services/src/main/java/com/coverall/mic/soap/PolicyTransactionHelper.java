/**
 * 
 */
package com.coverall.mic.soap;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import org.apache.commons.lang.StringUtils;

import com.coverall.mic.services.policy.transactionprocessing.PolicyTransactionProcessor;
import com.coverall.mt.http.User;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;

/**
 * @author Harish.Gupta
 *
 */
public class PolicyTransactionHelper {
	
	private String sql_1 = "INSERT INTO WS_POLICY_TRANSACTION_REQUESTS (WBN_REQUEST_ID, WBN_REQUEST_TYPE, WBN_POLICY_REFERENCE, WBN_USER_CREATED) VALUES (S_WBN_REQUEST_ID_SEQ.NEXTVAL,?,?,?)";
	private String sql_2 = "INSERT INTO WS_POLICY_TRANSACTIONPARAMETER (WBP_PARAMETER_ID, WBP_REQUEST_ID, WBP_PARAMETER_NAME, WBP_PARAMETER_VALUE, WBP_USER_CREATED) VALUES (S_WBP_PARAMETER_ID_SEQ.NEXTVAL,?,?,?,?)";
	
	
	public String processChangeProducerTransaction(Connection conn, HashMap<String, String> transParamMap, ProcessTransactionRequest request, User user){
		String status = "FAILED";
		PolicyTransactionProcessor processor = null;
		
		try{
		conn.setAutoCommit(false);
		PreparedStatement ps_1 = null;
		PreparedStatement ps_2 = null;
		int req_id = 0;
		String generatedColumns[] = { "WBN_REQUEST_ID" };
		boolean retStatus = false;
		Date transEffectiveDate = null;
		String transEffectiveDatestr = null;
		
		try {
			
			if(null != request.getTransactionEffectiveDate()){
				transEffectiveDate = request.getTransactionEffectiveDate();
				SimpleDateFormat dateFormat = new SimpleDateFormat(IProcessTransactionConstants.DATE_FORMAT);
				transEffectiveDatestr = dateFormat.format(transEffectiveDate);
				}
			
			ps_1 = conn.prepareStatement(sql_1, generatedColumns);
			ps_1.setString(1, "POLICY_CHANGE_PRODUCER");
			ps_1.setString(2, request.getPolicyReference());
			ps_1.setString(3, user.getUserId());
			int rowCount = ps_1.executeUpdate();
			ResultSet rs = ps_1.getGeneratedKeys();
			if(rs != null){
				if(rs.next())
					req_id = rs.getInt(1);
			}
			if(req_id == 0){
				conn.rollback();
			}else if(rowCount > 0){
				ps_2 = conn.prepareStatement(sql_2);
				
				ps_2.setInt(1, req_id);
				ps_2.setString(2, "TRANS_EFFECTIVE_DATE");
				ps_2.setString(3, (transEffectiveDatestr));
				ps_2.setString(4, user.getUserId());
				ps_2.addBatch();
				
				ps_2.setInt(1, req_id);
				ps_2.setString(2, "PRODUCER_CODE");
				ps_2.setString(3, request.getTransactionParams().get(IProcessTransactionConstants.PRODUCER_CODE));
				ps_2.setString(4, user.getUserId());
				ps_2.addBatch();
				
				ps_2.setInt(1, req_id);
				ps_2.setString(2, "WRITING_COUNTY_CODE");
				ps_2.setString(3, request.getTransactionParams().get(IProcessTransactionConstants.WRITING_COUNTY_CODE));
				ps_2.setString(4, user.getUserId());
				ps_2.addBatch();
				
				ps_2.setInt(1, req_id);
				ps_2.setString(2, "AGENT_CODE");
				ps_2.setString(3, request.getTransactionParams().get(IProcessTransactionConstants.AGENT_CODE));
				ps_2.setString(4, user.getUserId());
				ps_2.addBatch();
				
				ps_2.executeBatch();
				conn.commit();
				retStatus = true;
			}else{
				conn.rollback();
				retStatus = false;
			}
		} catch (SQLException e) {
			conn.rollback();
			e.printStackTrace();
		}finally{
			ps_1.close();
			ps_2.close();
			conn.close();
		}
		
		if(retStatus){
			if(transParamMap != null){
				try{
					
					processor = new PolicyTransactionProcessor();
					processor.processTransaction(transParamMap, user.getUserId(), user.getPassword(), user.getDomain());
					status = processor.getTransactionStatus();
		    		status = status + " : "+processor.getStatusDetails();
				}catch(Exception e){
					status = "FAILED : "+e.getMessage();
					LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,"PolicyTransactionHelper", "processChangeProducerTransaction",
							ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Unknown error while processing change producer transaction"
							+ e.getMessage(), e, LogMinderDOMUtil.VALUE_WEBSERVICES);
				}
			}else{
				status = "SUCCESS";
			}
		}else{
			status = "FAILED";
		}
		}
		catch(Exception e)
		{
			status = "FAILED : "+e.getMessage();
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,"PolicyTransactionHelper", "processChangeProducerTransaction",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Unknown error while processing change producer transaction"
					+ e.getMessage(), e, LogMinderDOMUtil.VALUE_WEBSERVICES);
		}
		return status;
	
	}
	
	public String processCancellationTransaction(Connection conn, HashMap<String, String> transParamMap, ProcessTransactionRequest request, User user){
		String status = "FAILED";
		PolicyTransactionProcessor processor = null;
		
		try{
			conn.setAutoCommit(false);
			PreparedStatement ps_1 = null;
			PreparedStatement ps_2 = null;
			int req_id = 0;
			String generatedColumns[] = { "WBN_REQUEST_ID" };
			boolean retStatus = false;
			Date transEffectiveDate = null;
			String transEffectiveDatestr = null;
			try {
				
				if(null != request.getTransactionEffectiveDate()){
					transEffectiveDate = request.getTransactionEffectiveDate();
					SimpleDateFormat dateFormat = new SimpleDateFormat(IProcessTransactionConstants.DATE_FORMAT);
					transEffectiveDatestr = dateFormat.format(transEffectiveDate);
					}
				
				ps_1 = conn.prepareStatement(sql_1, generatedColumns);
				ps_1.setString(1, "POLICY_CANCELLATION");
				ps_1.setString(2, request.getPolicyReference());
				ps_1.setString(3, user.getUserId());
				int rowCount = ps_1.executeUpdate();
				ResultSet rs = ps_1.getGeneratedKeys();
				if(rs != null){
					if(rs.next())
						req_id = rs.getInt(1);
				}
				if(req_id == 0){
					conn.rollback();
				}else if(rowCount > 0){
					ps_2 = conn.prepareStatement(sql_2);
					ps_2.setInt(1, req_id);
					ps_2.setString(2, "CANCEL_METHOD");  
					ps_2.setString(3, request.getTransactionParams().get(IProcessTransactionConstants.CANCEL_DESCRIPTION));
					ps_2.setString(4, user.getUserId());
					ps_2.addBatch();
				
					ps_2.setInt(1, req_id);
					ps_2.setString(2, "TRANS_EFFECTIVE_DATE");
					ps_2.setString(3, (transEffectiveDatestr));
					ps_2.setString(4, user.getUserId());
					ps_2.addBatch();
						
					ps_2.executeBatch();
					conn.commit();
					retStatus = true;
				}else{
					conn.rollback();
					retStatus = false;
				}
			} catch (SQLException e) {
				conn.rollback();
				e.printStackTrace();
			}finally{
				ps_1.close();
				ps_2.close();
				conn.close();
			}
			
			if(retStatus){
				if(transParamMap != null){
					try{
						processor = new PolicyTransactionProcessor();
						processor.processTransaction(transParamMap, user.getUserId(), user.getPassword(), user.getDomain());
						status = processor.getTransactionStatus();
			    		status = status + " : "+processor.getStatusDetails();
					}catch(Exception e){
						status = "FAILED : "+e.getMessage();
						LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,"PolicyTransactionHelper", "processCancellationTransaction",
								ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Unknown error while processing cancellation transaction"
								+ e.getMessage(), e, LogMinderDOMUtil.VALUE_WEBSERVICES);
					}
				}else{
					status = "SUCCESS";
				}
			}else{
				status = "FAILED";
			}
			}
			catch(Exception e)
			{
				status = "FAILED : "+e.getMessage();
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,"PolicyTransactionHelper", "processCancellationTransaction",
						ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Unknown error while processing cancellation transaction"
						+ e.getMessage(), e, LogMinderDOMUtil.VALUE_WEBSERVICES);
			}
			return status;
	}
	
	public String processReinstatementTransaction(Connection conn, HashMap<String, String> transParamMap, ProcessTransactionRequest request, User user){
		String status = "FAILED";
		PolicyTransactionProcessor processor = null;
		
		try{
			conn.setAutoCommit(false);
			PreparedStatement ps_1 = null;
			PreparedStatement ps_2 = null;
			int req_id = 0;
			String generatedColumns[] = { "WBN_REQUEST_ID" };
			boolean retStatus = false;
			Date transEffectiveDate = null;
			String transEffectiveDatestr = null;
			try {
				
				if(null != request.getTransactionEffectiveDate()){
					transEffectiveDate = request.getTransactionEffectiveDate();
					SimpleDateFormat dateFormat = new SimpleDateFormat(IProcessTransactionConstants.DATE_FORMAT);
					transEffectiveDatestr = dateFormat.format(transEffectiveDate);
				}
				ps_1 = conn.prepareStatement(sql_1, generatedColumns);
				ps_1.setString(1, "POLICY_REINSTATEMENT");
				ps_1.setString(2, request.getPolicyReference());
				ps_1.setString(3, user.getUserId());
				int rowCount = ps_1.executeUpdate();
				ResultSet rs = ps_1.getGeneratedKeys();
				if(rs != null){
					if(rs.next())
						req_id = rs.getInt(1);
				}
				if(req_id == 0){
					conn.rollback();
				}else if(rowCount > 0){
					ps_2 = conn.prepareStatement(sql_2);
					
					ps_2.setInt(1, req_id);
					ps_2.setString(2, "LAPSE_POLICY");
					ps_2.setString(3, request.getTransactionParams().get(IProcessTransactionConstants.LAPSE_POLICY));
					ps_2.setString(4, user.getUserId());
					ps_2.addBatch();
					
					if(null != request.getTransactionEffectiveDate()){
						ps_2.setInt(1, req_id);
						ps_2.setString(2, "TRANS_EFFECTIVE_DATE");
						ps_2.setString(3, (transEffectiveDatestr));
						ps_2.setString(4, user.getUserId());
						ps_2.addBatch();
					}
					
					ps_2.executeBatch();
					conn.commit();
					retStatus = true;
				}else{
					conn.rollback();
					retStatus = false;
				}
			} catch (SQLException e) {
				conn.rollback();
				e.printStackTrace();
			}finally{
				ps_1.close();
				ps_2.close();
				conn.close();
			}
			
			if(retStatus){
				if(transParamMap != null){
					try{
						
						processor = new PolicyTransactionProcessor();
						processor.processTransaction(transParamMap, user.getUserId(), user.getPassword(), user.getDomain());
						status = processor.getTransactionStatus();
			    		status = status + " : "+processor.getStatusDetails();
					}catch(Exception e){
						status = "FAILED : "+e.getMessage();
						LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,"PolicyTransactionHelper", "processReinstatementTransaction",
								ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Unknown error while processing Reinstatement transaction"
								+ e.getMessage(), e, LogMinderDOMUtil.VALUE_WEBSERVICES);
					}
				}else{
					status = "SUCCESS";
				}
			}else{
				status = "FAILED";
			}
			}
			catch(Exception e)
			{
				status = "FAILED : "+e.getMessage();
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,"PolicyTransactionHelper", "processReinstatementTransaction",
						ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Unknown error while processing Reinstatement transaction"
						+ e.getMessage(), e, LogMinderDOMUtil.VALUE_WEBSERVICES);
			}
			return status;
	}
	
	public String processRewriteTransaction(Connection conn, HashMap<String, String> transParamMap, ProcessTransactionRequest request, User user){
		String status = "FAILED";
		PolicyTransactionProcessor processor = null;
		
		try{
			conn.setAutoCommit(false);
			PreparedStatement ps_1 = null;
			PreparedStatement ps_2 = null;
			int req_id = 0;
			String generatedColumns[] = { "WBN_REQUEST_ID" };
			boolean retStatus = false;
			Date transEffectiveDate = null;
			String transEffectiveDatestr = null;
			try {
				
				if(null != request.getTransactionEffectiveDate()){
					transEffectiveDate = request.getTransactionEffectiveDate();
					SimpleDateFormat dateFormat = new SimpleDateFormat(IProcessTransactionConstants.DATE_FORMAT);
					transEffectiveDatestr = dateFormat.format(transEffectiveDate);
				}
				ps_1 = conn.prepareStatement(sql_1, generatedColumns);
				ps_1.setString(1, "POLICY_REWRITE");
				ps_1.setString(2, request.getPolicyReference());
				ps_1.setString(3, user.getUserId());
				int rowCount = ps_1.executeUpdate();
				ResultSet rs = ps_1.getGeneratedKeys();
				if(rs != null){
					if(rs.next())
						req_id = rs.getInt(1);
				}
				if(req_id == 0){
					conn.rollback();
				}else if(rowCount > 0){
					if(null != request.getTransactionEffectiveDate()||(null != request.getTransactionParams() && null != request.getTransactionParams().keySet() && request.getTransactionParams().keySet().size()>0)){
						ps_2 = conn.prepareStatement(sql_2);
						
						if(null != request.getTransactionEffectiveDate()){
							ps_2.setInt(1, req_id);
							ps_2.setString(2, "TRANS_EFFECTIVE_DATE");
							ps_2.setString(3, (transEffectiveDatestr));
							ps_2.setString(4, user.getUserId());
							ps_2.addBatch();
						}
						
						if((null != request.getTransactionParams() && null != request.getTransactionParams().keySet() && request.getTransactionParams().keySet().size()>0)){
							for(String key : request.getTransactionParams().keySet()){
								ps_2.setInt(1, req_id);
								ps_2.setString(2, key);
								ps_2.setString(3, request.getTransactionParams().get(key));
								ps_2.setString(4, user.getUserId());
								ps_2.addBatch();
							}
						}
						ps_2.executeBatch();
						conn.commit();
						retStatus = true;
					}
					
				}else{
					conn.rollback();
					retStatus = false;
				}
			} catch (SQLException e) {
				conn.rollback();
				e.printStackTrace();
			}finally{
				ps_1.close();
				ps_2.close();
				conn.close();
			}
			
			if(retStatus){
				if(transParamMap != null){
					try{
						
						processor = new PolicyTransactionProcessor();
						processor.processTransaction(transParamMap, user.getUserId(), user.getPassword(), user.getDomain());
						status = processor.getTransactionStatus();
			    		status = status + " : "+processor.getStatusDetails();
					}catch(Exception e){
						status = "FAILED : "+e.getMessage();
						LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,"PolicyTransactionHelper", "processRewriteTransaction",
								ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Unknown error while processing Rewrite transaction"
								+ e.getMessage(), e, LogMinderDOMUtil.VALUE_WEBSERVICES);
					}
				}else{
					status = "SUCCESS";
				}
			}else{
				status = "FAILED";
			}
			}
			catch(Exception e)
			{
				status = "FAILED : "+e.getMessage();
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,"PolicyTransactionHelper", "processRewriteTransaction",
						ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Unknown error while processing Rewrite transaction"
						+ e.getMessage(), e, LogMinderDOMUtil.VALUE_WEBSERVICES);
			}
			return status;
	}

}
