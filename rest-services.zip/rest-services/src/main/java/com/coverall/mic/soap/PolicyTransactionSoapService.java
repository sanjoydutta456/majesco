/**
 * 
 */
package com.coverall.mic.soap;

import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.jws.WebService;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.cxf.phase.PhaseInterceptorChain;
import org.apache.cxf.transport.http.AbstractHTTPDestination;
import org.apache.soap.util.mime.ByteArrayDataSource;

import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;
import com.coverall.mt.security.permission.RIPermission;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.pctv2.server.util.BookEntity;
import com.coverall.pctv2.server.util.PurgeEntity;
import com.coverall.pctv2.server.ws.service.Request;
import com.coverall.pctv2.server.ws.service.upload.PCTUploadResponse;
import com.coverall.pctv2.server.ws.service.upload.PolicyUploadIntegration;
import com.coverall.util.DBUtil;

/**
 * @author Harish.Gupta
 *
 */
@WebService(endpointInterface = "com.coverall.mic.soap.IPolicyTransactionSoapService")
public class PolicyTransactionSoapService implements IPolicyTransactionSoapService {


	@Override
	public ProcessTransactionResponse processChangeProducerTransaction(ProcessTransactionRequest request) {
		ProcessTransactionResponse response = new ProcessTransactionResponse();
		String validationError = "";
		String policyReference = null;
		Connection conn = null;
		User user = null;
		String status= "";
		PolicyTransactionHelper helper = null;
		try{
			// Validate the request parameters for change producer transaction
			validationError = PolicyTransactionUtility.validateRequestForChangeProducerTransaction(request);
			if(null != StringUtils.stripToNull(validationError)){
				response.setFailure(validationError);
				return response;
			}
			
			HttpServletRequest httpServletRequest = (HttpServletRequest) PhaseInterceptorChain.getCurrentMessage().get(AbstractHTTPDestination.HTTP_REQUEST);
			
			//Get User from HTTPRequest
    		try {
    			user = User.getUser(httpServletRequest);
			} catch (Exception e1) {
				response.setFailure("Invalid UserName/Password");
				return response;
			}
			
			policyReference = request.getPolicyReference();
			
    		boolean hasTransactionPermission = user.hasPermission(new RIPermission(IProcessTransactionConstants.TRANSACTION_PERMISSION_NAME));
    		// Check for transaction permission
	        if(!hasTransactionPermission){
	        	response.setFailure("User does not has permission to perform change producer transaction");
				return response;
	        }
	        
	        // Getting connection
	        conn = ConnectionPool.getConnection(user.getDomain());
	        
	        boolean isValidPolicyReference = PolicyTransactionUtility.isValidPolicyReference(policyReference, conn);
	        
	        // Check for Policy Reference
	        if(!isValidPolicyReference){
	        	response.setFailure("Invalid Policy Reference Number");
				return response;
	        }
	        
	        // Check for book permission
	        boolean hasBookPermission = PolicyTransactionUtility.hasBookPermission(user.getDomain(), user.getUserId());
	        
	        HashMap<String, String> params = new HashMap<String, String>();
			params.put("PROCESSING_TYPE", "COMPLETE");
			params.put("SOURCE_SYSTEM", "PolicyTransactionService");
			params.put("SHOULD_BOOK", hasBookPermission == true?"TRUE":"FALSE");
			params.put("ENTITY_TYPE", "POLICY");
			params.put("ENTITY_REFERENCE", policyReference);
			params.put("CLASSICTRANSACTIONCODE", "15");
			params.put("ACTION", "changeProducer");
			params.put("TRANSACTION_ACTION", "changeProducer");
	
			helper = new PolicyTransactionHelper();
			status = helper.processChangeProducerTransaction(conn, params, request, user);
			
			if(status != null && status.toUpperCase().indexOf("FAIL") < 0){
				response.setSuccess();
			}else{
				response.setFailure(status);
			}
			
		}catch(Exception e){
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,"PolicyTransactionSoapService", "processChangeProducerTransaction",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Unknown error while processing change producer transaction"
					+ e.getMessage(), e, LogMinderDOMUtil.VALUE_WEBSERVICES);
			response.setFailure(e.getMessage());
		}
		finally{
				try {
				DBUtil.close(null, null, conn);
			} catch (Exception ex) {
				// suppress
			}
		}
		return response;
	}

	@Override
	public ProcessTransactionResponse processCancellationTransaction(ProcessTransactionRequest request){
		ProcessTransactionResponse response = new ProcessTransactionResponse();
		String validationError = "";
		String policyReference = null;
		Connection conn = null;
		User user = null;
		String status= "";
		PolicyTransactionHelper helper = null;
		try{
			
			// Validate the request parameters for cancellation transaction
			validationError = PolicyTransactionUtility.validateRequestForCancellationTransaction(request);
			if(null != StringUtils.stripToNull(validationError)){
				response.setFailure(validationError);
				return response;
			}
			
			HttpServletRequest httpServletRequest = (HttpServletRequest) PhaseInterceptorChain.getCurrentMessage().get(AbstractHTTPDestination.HTTP_REQUEST);
			
			//Get User from HTTPRequest
    		try {
    			user = User.getUser(httpServletRequest);
			} catch (Exception e1) {
				response.setFailure("Invalid UserName/Password");
				return response;
			}
			
			policyReference = request.getPolicyReference();
    		
    		boolean hasTransactionPermission = user.hasPermission(new RIPermission("Cancellation"));
    		// Check for transaction permission
	        if(!hasTransactionPermission){
	        	response.setFailure("User does not has permission to perform Cancellation transaction");
				return response;
	        }
	        
	        // Getting connection
	        conn = ConnectionPool.getConnection(user.getDomain());
	        
	        boolean isValidPolicyReference = PolicyTransactionUtility.isValidPolicyReference(policyReference, conn);
	        
	        // Check for Policy Reference
	        if(!isValidPolicyReference){
	        	response.setFailure("Invalid Policy Reference Number");
				return response;
	        }
	        
	        // Check for book permission
	        boolean hasBookPermission = PolicyTransactionUtility.hasBookPermission(user.getDomain(), user.getUserId());
	        
	        HashMap<String, String> params = new HashMap<String, String>();
			params.put("PROCESSING_TYPE", "COMPLETE");
			params.put("SOURCE_SYSTEM", "PolicyTransactionService");
			params.put("SHOULD_BOOK", hasBookPermission == true?"TRUE":"FALSE");
			params.put("ENTITY_TYPE", "POLICY");
			params.put("ENTITY_REFERENCE", policyReference);
			params.put("CLASSICTRANSACTIONCODE", "04");
			params.put("ACTION", "cancellation");
			params.put("TRANSACTION_ACTION", "cancellation");
	
			helper = new PolicyTransactionHelper();
			status = helper.processCancellationTransaction(conn, params, request, user);
			
			if(status != null && status.toUpperCase().indexOf("FAIL") < 0){
				response.setSuccess();
			}else{
				response.setFailure(status);
			}
		}catch(Exception e){
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,"PolicyTransactionSoapService", "processCancellationTransaction",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Unknown error while processing cancellation transaction"
					+ e.getMessage(), e, LogMinderDOMUtil.VALUE_WEBSERVICES);
			response.setFailure(e.getMessage());
		}
		finally{
			try {
			DBUtil.close(null, null, conn);
		} catch (Exception ex) {
			// suppress
		}
	}
		return response;
	}
	
	public ProcessTransactionResponse processReinstatementTransaction(ProcessTransactionRequest request){
		ProcessTransactionResponse response = new ProcessTransactionResponse();
		String validationError = "";
		String policyReference = null;
		Connection conn = null;
		User user = null;
		String status= "";
		PolicyTransactionHelper helper = null;
		try{
			
			// Validate the request parameters for reinstatement transaction
			validationError = PolicyTransactionUtility.validateRequestForReinstatementTransaction(request);
			if(null != StringUtils.stripToNull(validationError)){
				response.setFailure(validationError);
				return response;
			}
			
			HttpServletRequest httpServletRequest = (HttpServletRequest) PhaseInterceptorChain.getCurrentMessage().get(AbstractHTTPDestination.HTTP_REQUEST);
			
			//Get User from HTTPRequest
    		try {
    			user = User.getUser(httpServletRequest);
			} catch (Exception e1) {
				response.setFailure("Invalid UserName/Password");
				return response;
			}
			
			policyReference = request.getPolicyReference();
    		
    		boolean hasTransactionPermission = user.hasPermission(new RIPermission("Reinstatement"));
    		// Check for transaction permission
	        if(!hasTransactionPermission){
	        	response.setFailure("User does not has permission to perform reinstatement transaction");
				return response;
	        }
	        
	        // Getting connection
	        conn = ConnectionPool.getConnection(user.getDomain());
	        
	        boolean isValidPolicyReference = PolicyTransactionUtility.isValidPolicyReference(policyReference, conn);
	        
	        // Check for Policy Reference
	        if(!isValidPolicyReference){
	        	response.setFailure("Invalid Policy Reference Number");
				return response;
	        }
	        
	        // Check for book permission
	        boolean hasBookPermission = PolicyTransactionUtility.hasBookPermission(user.getDomain(), user.getUserId());
	        
	        HashMap<String, String> params = new HashMap<String, String>();
			params.put("PROCESSING_TYPE", "COMPLETE");
			params.put("SOURCE_SYSTEM", "PolicyTransactionService");
			params.put("SHOULD_BOOK", hasBookPermission == true?"TRUE":"FALSE");
			params.put("ENTITY_TYPE", "POLICY");
			params.put("ENTITY_REFERENCE", policyReference);
			params.put("CLASSICTRANSACTIONCODE", "19");
			params.put("ACTION", "reinstatement");
			params.put("TRANSACTION_ACTION", "reinstatement");
	
			helper = new PolicyTransactionHelper();
			status = helper.processReinstatementTransaction(conn, params, request, user);
			
			if(status != null && status.toUpperCase().indexOf("FAIL") < 0){
				response.setSuccess();
			}else{
				response.setFailure(status);
			}
		}catch(Exception e){
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,"PolicyTransactionSoapService", "processReinstatementTransaction",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Unknown error while processing reinstatement transaction"
					+ e.getMessage(), e, LogMinderDOMUtil.VALUE_WEBSERVICES);
			response.setFailure(e.getMessage());
		}
		finally{
			try {
			DBUtil.close(null, null, conn);
		} catch (Exception ex) {
			// suppress
		}
	}
		return response;
	}
	
	public ProcessTransactionResponse processRewriteTransaction(ProcessTransactionRequest request) {

		ProcessTransactionResponse response = new ProcessTransactionResponse();
		String validationError = "";
		String policyReference = null;
		Connection conn = null;
		User user = null;
		String status= "";
		PolicyTransactionHelper helper = null;
		try{
			
			HttpServletRequest httpServletRequest = (HttpServletRequest) PhaseInterceptorChain.getCurrentMessage().get(AbstractHTTPDestination.HTTP_REQUEST);
			
			//Get User from HTTPRequest
    		try {
    			user = User.getUser(httpServletRequest);
			} catch (Exception e1) {
				response.setFailure("Invalid UserName/Password");
				return response;
			}
			
			policyReference = request.getPolicyReference();
    		
    		boolean hasTransactionPermission = user.hasPermission(new RIPermission("Rewrite"));
    		// Check for transaction permission
	        if(!hasTransactionPermission){
	        	response.setFailure("User does not has permission to perform rewrite transaction");
				return response;
	        }
	        
	        // Getting connection
	        conn = ConnectionPool.getConnection(user.getDomain());
	        
	        boolean isValidPolicyReference = PolicyTransactionUtility.isValidPolicyReference(policyReference, conn);
	        
	        // Check for Policy Reference
	        if(!isValidPolicyReference){
	        	response.setFailure("Invalid Policy Reference Number");
				return response;
	        }
	        
	        // Check for book permission
	        boolean hasBookPermission = PolicyTransactionUtility.hasBookPermission(user.getDomain(), user.getUserId());
	        
	        HashMap<String, String> params = new HashMap<String, String>();
			params.put("PROCESSING_TYPE", "COMPLETE");
			params.put("SOURCE_SYSTEM", "PolicyTransactionService");
			params.put("SHOULD_BOOK", hasBookPermission == true?"TRUE":"FALSE");
			params.put("ENTITY_TYPE", "POLICY");
			params.put("ENTITY_REFERENCE", policyReference);
			params.put("CLASSICTRANSACTIONCODE", "01");
			params.put("ACTION", "rewrite");
			params.put("TRANSACTION_ACTION", "rewrite");
	
			helper = new PolicyTransactionHelper();
			status = helper.processRewriteTransaction(conn, params, request, user);
			
			if(status != null && status.toUpperCase().indexOf("FAIL") < 0){
				response.setSuccess();
			}else{
				response.setFailure(status);
			}
			
		}catch(Exception e){
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,"PolicyTransactionSoapService", "processRewriteTransaction",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Unknown error while processing rewrite transaction"
					+ e.getMessage(), e, LogMinderDOMUtil.VALUE_WEBSERVICES);
			response.setFailure(e.getMessage());
		}
		finally{
			try {
			DBUtil.close(null, null, conn);
		} catch (Exception ex) {
			// suppress
		}
	}
		return response;
	}

	@Override
	public BookingResponse processBooking(BookingRequest request) {
		
		BookingResponse response = new BookingResponse();
		User user = null;
		Connection conn = null;
		Map<String, String> stage = new HashMap<String, String>();
		HttpServletRequest httpServletRequest = (HttpServletRequest) PhaseInterceptorChain.getCurrentMessage().get(AbstractHTTPDestination.HTTP_REQUEST);
		
		//Get User from HTTPRequest
		try {
			user = User.getUser(httpServletRequest);
		} catch (Exception e1) {
			response.setFailure("Invalid UserName/Password");
			return response;
		}
		
		String policyReference = request.getPolicyReference();
		
		
        
		try {
			
			 // Getting connection
	        conn = ConnectionPool.getConnection(user.getDomain());
			
			BookingResponse res = validation(policyReference, user, conn);
			if(res != null && res.getResponseStatus().equals(IProcessTransactionConstants.STATUS_FAILURE)){
				return res;
			}
	        
			
			
			BookEntity.book(user, "POLICY", policyReference);
			
			stage = PolicyTransactionUtility.getWorkFlowStage(policyReference,IProcessTransactionConstants.STAGE_BOOKING,IProcessTransactionConstants.POLICY_ENTITY_TYPE, conn);
			
			if(stage != null && stage.get("WAC_STAGE").equalsIgnoreCase(IProcessTransactionConstants.STAGE_COMPLETE_STATUS)){
				
				response.setSuccess("Booked successfully");
				
				
				if(request.isReturnExtract()){
					PolicyUploadIntegration xml = new PolicyUploadIntegration();
				
					String xmlStr = xml.getXMLExtract(new Request(user.getUserId(),user.getPassword()), "POLICY", policyReference, user);
					
					PCTUploadResponse pctUploadResponse = new PCTUploadResponse();
					
					if(xmlStr!=null)	{
						
						pctUploadResponse.setXmlString(xmlStr);
						
						DataSource dataSource = new ByteArrayDataSource(pctUploadResponse.getXmlString(), "text/xml; charset=UTF-8");
						response.setXmlData(new DataHandler(dataSource));
					}
					
					
				}
				
			}else if(stage != null && !stage.get("WAC_STAGE").equalsIgnoreCase(IProcessTransactionConstants.STAGE_COMPLETE_STATUS) && null != stage.get("WAC_STAGE_DESC")){
				response.setFailure("Booking error:"+stage.get("WAC_STAGE_DESC"));
			}else{
				response.setFailure("Booking error. Please contact system administrator.");
			}

		} catch (Throwable e) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,"PolicyTransactionSoapService", "processBooking",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Unknown error while processing book transaction"
					+ e.getMessage(), e, LogMinderDOMUtil.VALUE_WEBSERVICES);
			response.setFailure(e.getMessage());
		}finally{
			try {
			DBUtil.close(null, null, conn);
				} catch (Exception ex) {
					// suppress
				}
			}
		return response;
	}
	
	
	@Override
	public PurgeResponse processPurge(PurgeRequest request) {
		
		PurgeResponse response = new PurgeResponse();
		User user = null;
		Connection conn = null;
		Map<String, String> stage = new HashMap<String, String>();
		HttpServletRequest httpServletRequest = (HttpServletRequest) PhaseInterceptorChain.getCurrentMessage().get(AbstractHTTPDestination.HTTP_REQUEST);
		
		response.setResponseStatus(IProcessTransactionConstants.STATUS_FAILURE);
		response.setFailure("Transaction Not Supported : The requested purge transaction is discontinued and is not supported through the service");
		if(response != null){
		   return response;
		}
		//Get User from HTTPRequest
		try {
			user = User.getUser(httpServletRequest);
		} catch (Exception e1) {
			response.setFailure("Invalid UserName/Password");
			return response;
		}
		
		String policyReference = request.getPolicyReference();
		
		
        
		try {
			
			 // Getting connection
	        conn = ConnectionPool.getConnection(user.getDomain());
			
	        PurgeResponse res = purgeValidation(policyReference, user, conn);
	       // res = null;
			if(res != null && res.getResponseStatus().equals(IProcessTransactionConstants.STATUS_FAILURE)){
				return res;
			}
			
			PurgeEntity.purge(user, "POLICY", policyReference);
			
			response.setSuccess("Purged successfully");
			

		} catch (Throwable e) {
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,"PolicyTransactionSoapService", "processPurge",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Unknown error while processing Purge transaction"
					+ e.getMessage(), e, LogMinderDOMUtil.VALUE_WEBSERVICES);
			response.setFailure(e.getMessage());
		}finally{
			try {
			DBUtil.close(null, null, conn);
				} catch (Exception ex) {
					// suppress
				}
			}
		return response;
	}
	
	
	public BookingResponse validation(String policyReference, User user, Connection conn){
		
		
		BookingResponse response = new BookingResponse();
		response.setResponseStatus(IProcessTransactionConstants.STATUS_SUCCESS);
		Map<String, String> stage = new HashMap<String, String>();
		Map<String, String> currentStage = new HashMap<String, String>();
		
		try{
		
			
			if(StringUtils.isBlank(policyReference)){
				response.setFailure("policyReference is empty");
				return response;
			}
			
			// Check for book permission
	        try {
				boolean hasBookPermission = PolicyTransactionUtility.hasBookPermission(user.getDomain(), user.getUserId(),"Booking");
				
				if(!hasBookPermission){
					response.setFailure("User does not has book permission");
					return response;
				}
				
				
			} catch (SecurityException e) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,"PolicyTransactionSoapService", "processBooking",
						ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Unknown error while processing book transaction"
						+ e.getMessage(), e, LogMinderDOMUtil.VALUE_WEBSERVICES);
				response.setFailure(e.getMessage());
			}
			

	        boolean isValidPolicyReference = PolicyTransactionUtility.isValidPolicyReferenceAndEntityType(policyReference, conn);
	        
	        // Check for Policy Reference
	        if(!isValidPolicyReference){
	        	response.setFailure("Invalid Policy Reference Number");
				return response;
	        }
	        
	        
	        stage = PolicyTransactionUtility.getWorkFlowStage(policyReference,IProcessTransactionConstants.STAGE_BOOKING,IProcessTransactionConstants.POLICY_ENTITY_TYPE, conn);
	        
	        if(stage == null){
	        	currentStage = PolicyTransactionUtility.getWorkFlowCurrentStage(policyReference, conn);
	        	if(currentStage != null && currentStage.get("WAC_STAGE_DESC") != null){
	        		response.setFailure(currentStage.get("WAC_STAGE_DESC"));
	        	}else{
	        		response.setFailure("Policy not ready for booking");
	        	}
	        	
				return response;
	        }else if(stage != null && stage.get("WAC_STAGE").equalsIgnoreCase(IProcessTransactionConstants.STAGE_COMPLETE_STATUS)){
	        	response.setFailure("Policy is already booked");
				return response;
	        }
        
		}catch(Exception e){
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,"PolicyTransactionSoapService", "processBooking",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Unknown error while processing validation on book transaction"
					+ e.getMessage(), e, LogMinderDOMUtil.VALUE_WEBSERVICES);
			response.setFailure("Policy not ready for booking");
		}
		
		
		return response;
		
	}
	
	public PurgeResponse purgeValidation(String policyReference, User user, Connection conn){
		
		
		PurgeResponse response = new PurgeResponse();
		response.setResponseStatus(IProcessTransactionConstants.STATUS_SUCCESS);
		Map<String, String> stage = new HashMap<String, String>();
		Map<String, String> currentStage = new HashMap<String, String>();
		
		try{
		
			
			if(StringUtils.isBlank(policyReference)){
				response.setFailure("policyReference is empty");
				return response;
			}
			
			// Check for purge permission
	        try {
				boolean hasBookPermission = PolicyTransactionUtility.hasBookPermission(user.getDomain(), user.getUserId(),"Purge Policy");
				
				if(!hasBookPermission){
					response.setFailure("User does not has purge permission");
					return response;
				}
				
				
			} catch (SecurityException e) {
				LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,"PolicyTransactionSoapService", "processPurge",
						ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Unknown error while processing purge transaction"
						+ e.getMessage(), e, LogMinderDOMUtil.VALUE_WEBSERVICES);
				response.setFailure(e.getMessage());
			}
			

	        boolean isValidPolicyReference = PolicyTransactionUtility.isValidPolicyReferenceAndEntityType(policyReference, conn);
	        
	        // Check for Policy Reference
	        if(!isValidPolicyReference){
	        	response.setFailure("Invalid Policy Reference Number");
				return response;
	        }
	        
	        
	       
        
		}catch(Exception e){
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL,"PolicyTransactionSoapService", "processPurge",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, "Unknown error while processing validation on purge transaction"
					+ e.getMessage(), e, LogMinderDOMUtil.VALUE_WEBSERVICES);
			response.setFailure("Policy not ready for purge");
		}
		
		
		return response;
		
	}
	
	
	@Override
	public ProcessTransactionResponse processIssuanceTransaction(IssuanceRequest request) {
		ProcessTransactionResponse response = new ProcessTransactionResponse();
		String validationError = "";
		String activityId = null;
	//	String policyReference = null;
		User user = null;
		String status= "";
		boolean isValidIssuanceReference = false;
		boolean hasTransactionPermission = false;
		boolean isIssuanceStageReached = false;
		boolean isValidPolicyReference = false;
		try{
	    	HttpServletRequest httpServletRequest = (HttpServletRequest) PhaseInterceptorChain.getCurrentMessage().get(AbstractHTTPDestination.HTTP_REQUEST);
	    	PolicyTransactionUtility utility = new PolicyTransactionUtility();
			//Get User from HTTPRequest
    		try {
    			user = User.getUser(httpServletRequest);
			} catch (Exception e1) {
				response.setFailure("Invalid UserName/Password");
				return response;
			}
			
	        
	        // Check for Policy Reference
	        isValidPolicyReference = PolicyTransactionUtility.isValidPolicyReference(request.getPolicyReference(), user);

	        if(!isValidPolicyReference){
	        	response.setFailure("Invalid Policy Reference Number  " + request.getPolicyReference() ); 
	        	
				return response;
	        }
	        
	        //Check if policy reference is valid for issuance
	        isValidIssuanceReference = utility.isValidPolicyReferenceForIssuance(request.getPolicyReference(), user);

	        if (!isValidIssuanceReference) {
	        	 response.setFailure(" Issuance Transaction is not allowed on given policy Reference. ");
	        	 return response;
	        } 
			
	        
	        //Check if Issuance Stage is reached
	        isIssuanceStageReached = utility.isIssuanceStageReached(request.getPolicyReference(), user);

	        if (!isIssuanceStageReached) {
	        	response.setFailure(" Issuance Transaction workflow stage is not reached. ");
	        	 return response;

	        }	        
	        
	        //Check if user has Permission

	        hasTransactionPermission = PolicyTransactionUtility.hasIssuancePermission(user.getDomain(), user.getUserId());
      
	        if (!hasTransactionPermission) {
	        	response.setFailure(" User does not has permission to perform Issuance Transaction. " );
	        	 return response; 

	        }
	        
	        
	        //Process Issuance
	        
	        PolicyTransactionUtility.bookIssuePolicy(user, user.getFullName(), request.getPolicyReference());
	        
        	response.setSuccess();
        	response.setResponseMessage("Policy Issued successfully - Current Status is " + utility.getCurrentPolicyStatus(request.getPolicyReference(), user));
        	   	
        	
        	return response; 

	        
		}catch(Exception e){
			LogMinder.getLogMinder().log(LogEntry.SEVERITY_FATAL," PolicyTransactionSoapService ", " processIssuanceTransaction ",
					ServletConfigUtil.COMPONENT_FRAMEWORK, new Object[] {}, " Unknown error while processing issuance transaction "
					+ e.getMessage(), e, LogMinderDOMUtil.VALUE_WEBSERVICES);
			response.setFailure( "Unable to process Request due to " +e.getMessage());

		}
		
		return response;
	}
}
