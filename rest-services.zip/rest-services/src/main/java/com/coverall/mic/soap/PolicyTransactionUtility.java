/**
 * 
 */
package com.coverall.mic.soap;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.coverall.exceptions.ExceptionImpl;
import com.coverall.exceptions.JDBCException;
import com.coverall.exceptions.SecurityException;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;
import com.coverall.mt.security.AdminX;
import com.coverall.util.DBUtil;

/**
 * @author Harish.Gupta
 *
 */
public class PolicyTransactionUtility {
	
	
	public static String validateRequestForChangeProducerTransaction(ProcessTransactionRequest request) throws Exception{
		String validationError = "";
		try{
			if(null == request){
				validationError = "Request cannot be null";
				return validationError;
			}
			if(null == StringUtils.stripToNull(request.getPolicyReference())){
				validationError = "Policy Reference is required";
				return validationError;
			}
			if(null ==request.getTransactionEffectiveDate()){
				validationError = "Transaction Effective Date is required";
				return validationError;
			}
			
			if(null == request.getTransactionParams() || request.getTransactionParams().isEmpty()){
				validationError = "Transaction Params is required";
				return validationError;
			}
			if(null == StringUtils.stripToNull((String)request.getTransactionParams().get(IProcessTransactionConstants.PRODUCER_CODE))){
				validationError = IProcessTransactionConstants.PRODUCER_CODE + " is a required transaction parameter";
				return validationError;
			}
			else if(null == StringUtils.stripToNull((String)request.getTransactionParams().get(IProcessTransactionConstants.AGENT_CODE))){
				validationError = IProcessTransactionConstants.AGENT_CODE + " is a required transaction parameter";
				return validationError;
			}
			else if(null == StringUtils.stripToNull((String)request.getTransactionParams().get(IProcessTransactionConstants.WRITING_COUNTY_CODE))){
				validationError = IProcessTransactionConstants.WRITING_COUNTY_CODE + " is a required transaction parameter";
				return validationError;
			}
			
		}
		catch(NullPointerException e){
			
			throw e;
		}
		return validationError;
	}
	
	/**
	 * @method: This method checks whether the user has book permission
	 * @param : Domain name
	 * @param: user Id
	 * @throws SecurityException */
	public static boolean hasBookPermission(String domainName, String userId) throws SecurityException {
	       AdminX adminX = null;
	       boolean hasAutoBookPermission = false;

	       try {
	           adminX = new AdminX();
	           hasAutoBookPermission = adminX.hasSubPermission(domainName, userId, AdminX.USER_PRINCIPAL, "Booking?Auto Book");
	       } catch (SecurityException se) {
	           throw se;
	       }
	       return hasAutoBookPermission;
	}
	
	
	/**
	 * @method: This method checks whether the policy number in request is valid or not
	 * @param : policyReference
	 * @param: connection*/
	public static boolean isValidPolicyReference(String policyReference,
			Connection conn) {
		boolean returnStatus = false;
		PreparedStatement ps = null;
		ResultSet rs = null;
		if(null == StringUtils.stripToNull(policyReference)){
			
			return returnStatus;
		}
		String sql_3 = "SELECT * from ev_mis_quote_policies where entity_reference = ? ";
		try {
			ps = conn.prepareStatement(sql_3);
			ps.setString(1, policyReference);
			rs = ps.executeQuery();

			if (rs != null && rs.next()) {
				returnStatus = true;
			}
		} catch (SQLException e) {
			returnStatus = false;
		}catch (Exception e) {
			returnStatus = false;

		}
		return returnStatus;
	}

	public static String validateRequestForCancellationTransaction(ProcessTransactionRequest request) throws Exception{
		String validationError = "";
		try{
			if(null == request){
				validationError = "Request cannot be null";
				return validationError;
			}
			if(null == StringUtils.stripToNull(request.getPolicyReference())){
				validationError = "Policy Reference is required";
				return validationError;
			}
			if(null == request.getTransactionParams() || request.getTransactionParams().isEmpty()){
				validationError = "Transaction Params is required";
				return validationError;
			}
			
			if(null == request.getTransactionEffectiveDate()){
				validationError = "Transaction Effective Date is required";
				return validationError;
			}
			
			if(null == StringUtils.stripToNull((String)request.getTransactionParams().get(IProcessTransactionConstants.CANCEL_DESCRIPTION))){
				validationError = IProcessTransactionConstants.CANCEL_DESCRIPTION + " is a required transaction parameter";
				return validationError;
			}
			
		}
		catch(Exception e){
			
			throw e;
		}
		return validationError;
	}
	
	public static String validateRequestForReinstatementTransaction(ProcessTransactionRequest request) throws Exception{
		String validationError = "";
		try{
			if(null == request){
				validationError = "Request cannot be null";
				return validationError;
			}
			if(null == StringUtils.stripToNull(request.getPolicyReference())){
				validationError = "Policy Reference is required";
				return validationError;
			}
			if(null == request.getTransactionParams() || request.getTransactionParams().isEmpty()){
				validationError = "Transaction Params is required";
				return validationError;
			}
			
			if(null == request.getTransactionEffectiveDate()){
				validationError = "Transaction Effective Date is required";
				return validationError;
			}
			
			if(null == StringUtils.stripToNull((String)request.getTransactionParams().get(IProcessTransactionConstants.LAPSE_POLICY))){
				validationError = IProcessTransactionConstants.LAPSE_POLICY + " is a required transaction parameter";
				return validationError;
			}
		}
		catch(Exception e){
			
			throw e;
		}
		return validationError;
	}
	
	/**
	 * @method: This method checks whether the policy number and entity type policy in request is valid or not
	 * @param : policyReference
	 * @param: connection*/
	public static boolean isValidPolicyReferenceAndEntityType(String policyReference,
			Connection con) {
		String sql_3 = "SELECT ENTITY_TYPE from ev_mis_quote_policies where entity_reference = ? ";
		boolean returnStatus = false;
		try {
			PreparedStatement ps = con.prepareStatement(sql_3);
			ps.setString(1, policyReference);
			ResultSet rs = ps.executeQuery();
			
			if (rs != null && rs.next()) {
				if (rs.getString(1).equalsIgnoreCase(IProcessTransactionConstants.POLICY_ENTITY_TYPE)) {
					returnStatus = true;
				}
			}
		} catch (SQLException e) {
			returnStatus = false;
		}
		return returnStatus;
	}
	
	
	/**
	 * @method: This method get stage and description
	 * @param : policyReference
	 * @param: taskName
	 * @param: entityType
	 * @param: connection*/
	public static Map<String, String> getWorkFlowStage(String policyReference,String taskName, String entityType,
			Connection con) {
		
		String sql_1 = "select WAC_STAGE, WAC_STAGE_DESC from WFL_ACTIVITIES where wac_entity_reference = ? "
				+ "and wac_task_id IN (select wwt_task_id from wfl_workflow_tasks where wwt_task_name = ?"
				+ "and wwt_workflow_id = (select wwo_id from wfl_workflows where wwo_entity_type = ? ))";
		
		Map<String, String> result = new HashMap<String, String>();
		try {
			PreparedStatement ps = con.prepareStatement(sql_1);
			ps.setString(1, policyReference);
			ps.setString(2, taskName);
			ps.setString(3, entityType);
			ResultSet rs = ps.executeQuery();

			if (rs != null && rs.next()) {
				result.put("WAC_STAGE", rs.getString(1));
				result.put("WAC_STAGE_DESC", rs.getString(2));
			} else {
				result = null;
			}
		} catch (SQLException e) {
			result = null;
		}
		return result;
	}
	
	/**
	 * @method: This method checks whether the user has book permission
	 * @param : Domain name
	 * @param: user Id
	 * @throws SecurityException */
	public static boolean hasBookPermission(String domainName, String userId, String permission) throws SecurityException {
	       AdminX adminX = null;
	       boolean hasBookPermission = false;

	       try {
	           adminX = new AdminX();
	           //hasBookPermission = adminX.hasSubPermission(domainName, userId, AdminX.USER_PRINCIPAL, adminX.getPermission(permission));
	           hasBookPermission =  adminX.hasPermission(domainName, userId, AdminX.USER_PRINCIPAL, adminX.getPermission(permission));
	           
	       } catch (SecurityException se) {
	           throw se;
	       }
	       return hasBookPermission;
	}
	
	/**
	 * @method: This method get stage and description
	 * @param : policyReference
	 * @param: taskName
	 * @param: entityType
	 * @param: connection*/
	public static Map<String, String> getWorkFlowCurrentStage(String policyReference,
			Connection con) {
		
		String sql_1 = "SELECT WAC_STAGE,WAC_STAGE_DESC FROM WFL_ACTIVITIES WHERE WAC_ENTITY_REFERENCE = ? "
				+ " AND WAC_ID = (SELECT MAX(WAC_ID) FROM WFL_ACTIVITIES where WAC_ENTITY_REFERENCE = ?)";
		
		Map<String, String> result = new HashMap<String, String>();
		try {
			PreparedStatement ps = con.prepareStatement(sql_1);
			ps.setString(1, policyReference);
			ps.setString(2, policyReference);
			ResultSet rs = ps.executeQuery();
			if (rs != null && rs.next()) {
				result.put("WAC_STAGE", rs.getString(1));
				result.put("WAC_STAGE_DESC", rs.getString(2));
			} else {
				result = null;
			}
		} catch (SQLException e) {
			result = null;
		}
		return result;
	}
	
	
	public  boolean isIssuanceStageReached(String policyReference, User user) {
		boolean isStageReached = false;
		
	    PreparedStatement pstmt = null;
		ResultSet rs = null;
		Connection conn = null;
		

		String sql_1 = " SELECT DECODE(COUNT(wac_id),0,'false','true') isStageReached " +
				" FROM wfl_activities " +
				" WHERE wac_workflow_task_id = " +
				" (SELECT wwt_id " +
				"  FROM wfl_workflow_tasks " +
				"  WHERE WWT_WORKFLOW_ID = " +
				"    (SELECT wwo_id FROM wfl_workflows WHERE upper(wwo_name) = 'POLICY WORKFLOW' " +
				"   ) " +
				" AND upper(wwt_task_name) = 'ISSUANCE' " +
				"  ) " +
				" AND wac_entity_reference = ? " +
				" AND wac_stage            = 'BLOCK' " ;

		try {
		    conn = ConnectionPool.getConnection(user);

			pstmt = conn.prepareStatement(sql_1);
			pstmt.setString(1, policyReference);
		    rs = pstmt.executeQuery();

			if (rs != null && rs.next()) {
				isStageReached = new Boolean( rs.getString("isStageReached") ).booleanValue();
			}

		} catch (SQLException e) {
			return isStageReached;
		} catch (Exception e) {
			return isStageReached;

		}finally{
			try {
			DBUtil.close(rs,pstmt,conn);
		} catch (Exception ex) {
			// suppress
		}
	}
		return isStageReached;
	}
	
	
	public static boolean hasIssuancePermission(String domainName, String userId) throws SecurityException {
	       AdminX adminX = null;
	       boolean hasAutoIssuePermission = false;

	       try {
	           adminX = new AdminX();

               /* Check Auto Issue permission */
               hasAutoIssuePermission =  adminX.hasPermission(domainName, userId, AdminX.USER_PRINCIPAL, adminX.getPermission("Issue&Book Policy"));

	       } catch (SecurityException se) {
	           throw se;
	       }
	       return hasAutoIssuePermission;
	}
	
	
	public  boolean isValidPolicyReferenceForIssuance(String policyReference,
			User user) {
		
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Connection conn = null;
		
		String sql_3 = " SELECT decode(count(gid),0,'false','true') isValidReference FROM vw_mis_quote_policies, mis_policies WHERE entity_reference =  ? " + 
				" AND binder_flag = 'Y' " + 
				" AND entity_reference = mpo_policy_reference " + 
				" AND nvl(booking_status,'XXX') = 'COMPLETE' " +
				 " AND mpo_book_flag = 'Y' ";
		boolean isValidReference = false;
		try {
		    conn = ConnectionPool.getConnection(user); 
			stmt =	conn.prepareStatement(sql_3);		
			stmt.setString(1, policyReference);
			rs = stmt.executeQuery();
			
			if(rs != null && rs.next()){     
				isValidReference = new Boolean( rs.getString("isValidReference") ).booleanValue();
			}
		} catch (SQLException e) {
			return isValidReference;
		} catch (Exception e) {
			return isValidReference;

		}finally{
			try {
			DBUtil.close(rs,stmt,conn);
		} catch (Exception ex) {
			// suppress
		}
	}
		return isValidReference;
	}
	
	
	 public static void bookIssuePolicy(User user, String userId, String entityReference) throws JDBCException { 
	       /*
	         FUNCTION f_issue_policy (
	           p_entity_reference    IN VARCHAR2,
	           p_user                IN VARCHAR2,
	           p_error_message       OUT VARCHAR2
	         ) RETURN NUMBER;
	       */
	       CallableStatement st = null;
	       Connection conn= null;

	        try {
	            //issue and book the binder
			    conn = ConnectionPool.getConnection(user);
	            st = conn.prepareCall("{ ? = call K_Workflow_Activity_Helper.f_issue_policy(?, ?, ?)}");
	            st.registerOutParameter(1, Types.INTEGER);
	            st.setString(2, entityReference);
	            st.setString(3, userId);
	            st.registerOutParameter(4, Types.VARCHAR);
	            st.execute();
	            if (st.getInt(1) != 0) {
	                throw new JDBCException("Error during Issuance.\n" + st.getString(4), null);
	            }
	        } catch (Throwable error) {
	            if (error instanceof JDBCException) {
	                throw (JDBCException)error;
	            } else {
	                throw new JDBCException(ExceptionImpl.FATAL, "Unexpected error occured when converting binder to a policy.", error);
	            }
	        } finally {
	            try {
	                DBUtil.close(null,st,conn);
	            } catch (Throwable error) {
	                if (error instanceof JDBCException) {
	                    throw (JDBCException)error;
	                } else {
	                    throw new JDBCException(ExceptionImpl.FATAL, "Error closing connection when converting binder to a policy.", error);
	                }
	            }
	        }
	    }
	 
	 


public  String getCurrentPolicyStatus(String policyReference,
		User user) throws JDBCException {
	String status = null;
	PreparedStatement st = null;
	Connection conn= null;
	ResultSet rs = null;
	try {
	     conn = ConnectionPool.getConnection(user);

		 st = conn.prepareStatement("select K_Workflow_Activity_Management.f_get_status_wrapper('POLICY', ? ) status from dual " );
		 st.setString(1, policyReference);
		 rs = st.executeQuery();

		if(rs != null && rs.next()){
			status = rs.getString("status");
		}
	}catch (Throwable error) {
		
		 if (error instanceof JDBCException) {
           throw (JDBCException)error;
       } else {
           throw new JDBCException(ExceptionImpl.FATAL, "Unexpected error occured while getting  getCurrentPolicyStatus.", error);
       }
	}finally {
		   try {
             DBUtil.close(rs,st,conn); 
         } catch (Throwable error) {
             if (error instanceof JDBCException) {
                 throw (JDBCException)error;
             } else {
                 throw new JDBCException(ExceptionImpl.FATAL, "Error closing statement getting getCurrentPolicyStatus.", error);
             }
         }
		
	}
	return status;
}


public static boolean isValidPolicyReference(String policyReference,
		User user) {
	boolean returnStatus = false;
    PreparedStatement ps=null;
	ResultSet rs = null;
	Connection conn = null;

	if(null == StringUtils.stripToNull(policyReference)){
		
		return returnStatus;
	}
	String sql_3 = "SELECT * from ev_mis_quote_policies where entity_reference = ?";
	try {
			conn = ConnectionPool.getConnection(user);
			ps = conn.prepareStatement(sql_3);
			ps.setString(1, policyReference);
			rs = ps.executeQuery();
			if (rs != null && rs.next()) {
				returnStatus = true;
			}
	} catch (SQLException e) {
		returnStatus = false;
	} catch (Exception e) {
		returnStatus = false;
	
	}finally{
		try {
		DBUtil.close(rs,ps,conn);
	} catch (Exception ex) {
		// suppress
	}
}
	return returnStatus;
}
	
}
