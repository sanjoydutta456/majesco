/**
 * 
 */
package com.coverall.mic.soap;

import java.util.Date;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Harish.Gupta
 * 
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class ProcessTransactionRequest {

	@XmlElement(required = true)
	protected String policyReference;

	@XmlElement(required = false)
	protected Date transactionEffectiveDate; 

	@XmlElement(required = true)
	protected Map<String, String> transactionParams;

	public String getPolicyReference() {
		return policyReference;
	}

	public void setPolicyReference(String policyReference) {
		this.policyReference = policyReference;
	}

	public Date getTransactionEffectiveDate() {
		return transactionEffectiveDate;
	}

	public void setTransactionEffectiveDate(Date transactionEffectiveDate) {
		this.transactionEffectiveDate = transactionEffectiveDate;
	}

	public Map<String, String> getTransactionParams() {
		return transactionParams;
	}

	public void setTransactionParams(Map<String, String> transactionParams) {
		this.transactionParams = transactionParams;
	}

}
