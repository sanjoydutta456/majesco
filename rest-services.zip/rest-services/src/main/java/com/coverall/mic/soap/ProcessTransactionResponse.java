/**
 * 
 */
package com.coverall.mic.soap;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Harish.Gupta
 * 
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class ProcessTransactionResponse {

	@XmlElement
	protected String responseStatus;

	@XmlElement
	protected String responseMessage;

	public String getResponseStatus() {
		return responseStatus;
	}

	public void setResponseStatus(String responseStatus) {
		this.responseStatus = responseStatus;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public void setSuccess() {
		this.responseStatus = IProcessTransactionConstants.STATUS_SUCCESS;
		this.responseMessage = "";
	}

	public void setFailure(String errorMessage) {
		this.responseStatus = IProcessTransactionConstants.STATUS_FAILURE;
		this.responseMessage = errorMessage;
	}

}
