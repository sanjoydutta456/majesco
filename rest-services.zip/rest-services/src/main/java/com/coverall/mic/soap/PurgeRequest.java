/**
 * 
 */
package com.coverall.mic.soap;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Kaushik87149
 *
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class PurgeRequest {

	@XmlElement(required = true)
	protected String policyReference;
	
	@XmlElement(required = false)
	protected boolean returnExtract;

	public String getPolicyReference() {
		return policyReference;
	}

	public void setPolicyReference(String policyReference) {
		this.policyReference = policyReference;
	}

	public boolean isReturnExtract() {
		return returnExtract;
	}

	public void setReturnExtract(boolean returnExtract) {
		this.returnExtract = returnExtract;
	} 
	
}
