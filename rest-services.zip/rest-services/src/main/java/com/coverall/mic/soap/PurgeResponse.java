/**
 * 
 */
package com.coverall.mic.soap;

import javax.activation.DataHandler;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlMimeType;

/**
 * @author Kaushik87149
 *
 */

public class PurgeResponse {


	private String responseStatus;


	private String responseMessage;
	
	
	private DataHandler xmlData;
	
	
	@XmlMimeType("text/xml")
	public DataHandler getXmlData() {
		return xmlData;
	}

	public void setXmlData(DataHandler xmlData) {
		this.xmlData = xmlData;
	}

	@XmlElement(required = true)
	public String getResponseStatus() {
		return responseStatus;
	}

	public void setResponseStatus(String responseStatus) {
		this.responseStatus = responseStatus;
	}

	@XmlElement(required = true)
	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public void setSuccess(String successMessage) {
		this.responseStatus = IProcessTransactionConstants.STATUS_SUCCESS;
		this.responseMessage = successMessage;
	}

	public void setFailure(String errorMessage) {
		this.responseStatus = IProcessTransactionConstants.STATUS_FAILURE;
		this.responseMessage = errorMessage;
	}

}
