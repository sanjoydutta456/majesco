package com.coverall.mic.soap.lookup;

public interface ILookupConstants {
	String CSV_FORMAT = ".csv";
	String SIMPLE_DATE_FORMATE = "MM/dd/yyyy";
}
