/**
 * 
 */
package com.coverall.mic.soap.lookup;

import javax.jws.WebService;

/**
 * @author Kaushik87149
 *
 */

@WebService
public interface ILookupDataService {
	
	LookupResponse getLookupData(LookupRequest request);
	
}
