/**
 * 
 */
package com.coverall.mic.soap.lookup;

import javax.activation.DataHandler;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlMimeType;

/**
 * @author Kaushik87149
 *
 */
public class LookupExclusionData {

	protected String columnName;
	protected DataHandler exclusionData;
	
	@XmlElement(required = true)
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	
	@XmlElement(required = true)
	@XmlMimeType("text/csv")
	public DataHandler getExclusionData() {
		return exclusionData;
	}
	public void setExclusionData(DataHandler exclusionData) {
		this.exclusionData = exclusionData;
	}
	
}
