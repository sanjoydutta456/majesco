/**
 * 
 */
package com.coverall.mic.soap.lookup;

import javax.xml.bind.annotation.XmlElement;

/**
 * @author Kaushik87149
 *
 */
public class LookupRequest {
	protected String lookupName;
	
	@XmlElement(required = true)
	public String getLookupName() {
		return lookupName;
	}
	public void setLookupName(String lookupName) {
		this.lookupName = lookupName;
	}
}
