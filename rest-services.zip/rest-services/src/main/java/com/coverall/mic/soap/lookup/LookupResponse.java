/**
 * 
 */
package com.coverall.mic.soap.lookup;

import java.util.List;

import javax.activation.DataHandler;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlMimeType;

/**
 * @author Kaushik87149
 *
 */
public class LookupResponse {

	private String responseCode;
	
	private String responseMessage;
	
	private List<LookupExclusionData> exclusions; 
	
	private DataHandler lookupData;

	@XmlMimeType("text/csv")
	@XmlElement(required = true)
	public DataHandler getLookupData() {
		return lookupData;
	}

	public void setLookupData(DataHandler lookupData) {
		this.lookupData = lookupData;
	}

	@XmlElement(required = true)
	public String getResponseCode() {
		return responseCode;
	}
	
	@XmlElement(required = true)
	public String getResponseMessage() {
		return responseMessage;
	}
	
	public void setSuccess(String message)	{
		responseCode = "SUCCESS";
		responseMessage = message;
	}
	
	public void setError(String message){
		responseCode = "FAILURE";
		responseMessage = message;
		
	}

	@XmlElement(required = false)
	public List<LookupExclusionData> getExclusions() {
		return exclusions;
	}

	public void setExclusions(List<LookupExclusionData> exclusions) {
		this.exclusions = exclusions;
	}
}

