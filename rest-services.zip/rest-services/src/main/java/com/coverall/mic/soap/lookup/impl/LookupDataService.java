/**
 * 
 */
package com.coverall.mic.soap.lookup.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.servlet.http.HttpServletRequest;

import org.apache.cxf.phase.PhaseInterceptorChain;
import org.apache.cxf.transport.http.AbstractHTTPDestination;

import com.coverall.mic.soap.lookup.ILookupConstants;
import com.coverall.mic.soap.lookup.ILookupDataService;
import com.coverall.mic.soap.lookup.LookupExclusionData;
import com.coverall.mic.soap.lookup.LookupRequest;
import com.coverall.mic.soap.lookup.LookupResponse;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.mt.xml.CustomerConfigUtil;
import com.coverall.mt.xml.DOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;
import com.coverall.util.DBUtil;
import com.coverall.util.validators.SQLInjectionValidator;
import com.mindprod.csv.CSVWriter;

/**
 * @author Kaushik87149
 *
 */
public class LookupDataService implements ILookupDataService {

	private static final String className = LookupDataService.class.getName();
	
	//list exclude
	List<LookupExclusionData> exclusions = null;
	/* (non-Javadoc)
	 * @see com.coverall.mt.webservices.lookup.ILookupDataService#getLookupData(com.coverall.mt.webservices.lookup.LookupRequest)
	 */
	@Override
	public LookupResponse getLookupData(LookupRequest request) {
		LookupResponse response = new LookupResponse();
		Connection conn = null;
		exclusions = new ArrayList<LookupExclusionData>();
		String query = null;
		PreparedStatement  preStmtLookup = null;
		PreparedStatement  preStmtLookCol = null;
		ResultSet rsLookup = null;
		ResultSet rslc = null;
		Statement stmtSql = null;
		ResultSet rsSql = null;
		int lookupID = 0;
		List<String> columnsNames = new ArrayList<String>();
		List<String> columnsNamesAvailable = new ArrayList<String>();

		String sql = null;
		
		
		
		HttpServletRequest httpServletRequest = (HttpServletRequest) PhaseInterceptorChain.getCurrentMessage().get(AbstractHTTPDestination.HTTP_REQUEST);
		User user = User.getUser(httpServletRequest);
		
		//Get User from HTTPRequest
		try {
			user = User.getUser(httpServletRequest);
		} catch (Exception e1) {
			response.setError("Invalid UserName/Password");
			return response;
		}
		
		//Validate request
		if (request == null) {
			response.setError("Request Data is missing.");
			return response;

		}
		
		//Validate table name
		if (request.getLookupName() == null
				|| (request.getLookupName().isEmpty())) {
			response.setError("Lookup Name is a mandatory parameter");
			return response;
		}
		
		
		
		CSVWriter cw = null;
		
		
		try {
			
			conn = ConnectionPool.getConnection(user);
			
			query = "select LUQ_LOOKUP_ID,LUQ_SQL from LOOKUP_QUERIES where upper(LUQ_LOOKUP_NAME) = upper(?) and LUQ_DATE_DELETED is null";
			preStmtLookup = conn.prepareStatement(query); 
			preStmtLookup.setString(1, request.getLookupName().trim() );
			rsLookup = preStmtLookup.executeQuery();
			while(rsLookup.next()){
				lookupID =  rsLookup.getInt(1);
				sql = rsLookup.getString(2);
			}
			
			//validation for invalid lookup name
			if(lookupID == 0 && null == sql){
				response.setError("Invalid Lookup name");
				return response;
			}
			
            String customerCode = CustomerConfigUtil.getInstance().getCustomerCode(user.getDomain());
            String tempDirName = System.getProperty(DOMUtil.MIC_SYSTEM_HOME) + File.separator
                    + ServletConfigUtil.COMPONENT_RI + File.separator + customerCode + File.separator + "temp";
            File tempDir = new File(tempDirName);
            if(!tempDir.exists() || !tempDir.isDirectory())	{
            	tempDirName = System.getProperty(DOMUtil.MIC_SYSTEM_HOME);
            }
			final String TMP_FILE_NAME = tempDirName+File.separator+request.getLookupName()+"_"+System.currentTimeMillis()+ILookupConstants.CSV_FORMAT;
			final File file =  new File(TMP_FILE_NAME);
			
//			cw = new CSVWriter(new FileWriter(file));
			
			//Retain Leading and Trailing spaces, last parameter trim = false
			cw = new CSVWriter( new FileWriter(file), 1, ',', '\"', false );
			
			query = "select LUQC_COLUMN_NAME,LUQC_DATATYPE,LUQC_DATA_FORMAT,LUQC_IS_KEY_COLUMN, LUQC_IS_DISPLAY_COLUMN, LUQC_IS_SPECIAL_VALUE_COLUMN, LUQC_EXCLUSION_QUERY from LOOKUP_COLUMNS where LUQC_LOOKUP_ID = ? and LUQC_DATE_DELETED is null ORDER BY LUQC_LOOKUP_COLUMN_ID ";
			preStmtLookCol = conn.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY); 
			preStmtLookCol.setInt(1, lookupID);
			rslc = preStmtLookCol.executeQuery();
			
			ResultSetMetaData resdata = rslc.getMetaData();
		
			//generating columns headers for csv file
			for (int i = 1; i <= resdata.getColumnCount(); i++) {
				while(rslc.next()){
					
					if( i == 1){
						columnsNames.add(rslc.getString(1));
	
						cw.put((null != rslc.getString(1) ? rslc.getString(1).trim():""));
					}else if(i == 2){
						cw.put((null != rslc.getString(2) ? rslc.getString(2).trim():""));
					}else if(i == 3){
						cw.put((null != rslc.getString(3) ? rslc.getString(3):""));
					}else if(i == 4){
						cw.put((null != rslc.getString(4) ? rslc.getString(4):"N"));
					}else if(i == 5){
						cw.put((null != rslc.getString(5) ? rslc.getString(5):"N"));
					}else if(i == 6){
						cw.put((null != rslc.getString(6) ? rslc.getString(6):"N"));
					}
					
				}
				//Moving the cursor to initial position in resultset
				if(i <= 6){
					rslc.beforeFirst();
					cw.nl();
				}
			}
			
			
			stmtSql = conn.createStatement(); 
			rsSql   = stmtSql.executeQuery(sql);

			WebServiceLoggerUtil.logInfo(className, "getLookupData", "info total columns", new Object[] { columnsNames });
			
			//generating columns data in csv file
			if(columnsNames != null && !columnsNames.isEmpty()){
				while(rsSql.next()){
					for(int i=0;i< columnsNames.size();i++){
						
	                    if(rsSql.getObject(columnsNames.get(i)) !=null)
	                    {
	                    	
	                    	Object obj = rsSql.getObject(columnsNames.get(i));
	                    	
	                    	if(obj instanceof java.sql.Timestamp || obj instanceof java.sql.Date ){
	                    		String dateData = getDateString(columnsNames.get(i),rsSql.getDate(columnsNames.get(i)));
	                    		cw.put(dateData);
	                    	}else{
	                    		cw.put(rsSql.getObject(columnsNames.get(i)).toString());
	                    	}
	                    	
	                    	columnsNamesAvailable.add(columnsNames.get(i));
	                    	
	                    }
	                    else
	                    {
	                        cw.put("");
	                    }	                     
	                }
					cw.nl();
				}
			}
			
			WebServiceLoggerUtil.logInfo(className, "getLookupData", "info total available columns", new Object[] { columnsNamesAvailable });
			
			rslc.beforeFirst();
			
			//call exclusion query
			while(rslc.next()){
				if(rslc.getInt(7) != 0 ){
					getListDataExclude(rslc.getInt(7), rslc.getString(1),conn);
				}
			}
			
			
			DataSource dataSource = new FileDataSource(file){
				
				@Override
				public String getContentType() {
					return "text/csv";
				}
				
				@Override
				public InputStream getInputStream() throws IOException {
					      return new FileInputStream(file){
					    	  
					    	  	@Override
					    	    public void close() throws IOException {
					    	        super.close();
					    	        if(file!=null)
					    	        	file.delete();
					    	    }
					      };
			     }

			};
			DataHandler dataHandler = new DataHandler(dataSource);
			response.setLookupData(dataHandler);
			response.setExclusions(exclusions);
			response.setSuccess("Exported csv files successfully"); 
			return response;
			
			} catch (Throwable e) {

				WebServiceLoggerUtil.logError(className, "getLookupData", "Exception occurred.", new Object[] { request,columnsNames, columnsNamesAvailable }, e);
				
				response.setError("look up failed because of exception occurred: "+e.getMessage());
				return response;
			}finally{
				try {
					DBUtil.close(conn);
					DBUtil.close(rsLookup,null);
					DBUtil.close(rsSql,null);
					DBUtil.close(rslc,null);
					DBUtil.close(null,stmtSql);
					DBUtil.close(null, preStmtLookup);
					DBUtil.close(null, preStmtLookCol);
				
					if (cw != null) {
						cw.close();
					}
					
				} catch (Throwable e) {
					// TODO Auto-generated catch block
					
				}
			}
	}

	private String getDateString(String column, Date date) {
		
		SimpleDateFormat dt = new SimpleDateFormat(ILookupConstants.SIMPLE_DATE_FORMATE);
		String formattedDate = dt.format(date);
		return formattedDate;

	}


	private void getListDataExclude(int exColLoopupId, String colName, Connection conn){
		
		
		String query = null;
		PreparedStatement  preStmtLookup = null;
		PreparedStatement  preStmtLookCol = null;
		ResultSet rsLookup = null;
		ResultSet rslc = null;
		Statement stmt = null;
		ResultSet rsSql = null;
		CSVWriter cw = null;
		int lookupID = 0;
		String lookupname = null;
		String sql = null;
		List<String> columnsNames = new ArrayList<String>();
		List<String> columnsNamesAvailable = new ArrayList<String>();
		
		
		
		try {

			query = "select LUQ_LOOKUP_ID,LUQ_SQL,LUQ_LOOKUP_NAME from LOOKUP_QUERIES where LUQ_LOOKUP_ID = ? and LUQ_DATE_DELETED is null ";
			preStmtLookup = conn.prepareStatement(query); 
			preStmtLookup.setInt(1, exColLoopupId );
			rsLookup = preStmtLookup.executeQuery();
			while(rsLookup.next()){
				lookupID =  rsLookup.getInt(1);
				sql = rsLookup.getString(2);
				lookupname = rsLookup.getString(3);
			}
			
			final String TMP_FILE_NAME = System.getProperty(DOMUtil.MIC_SYSTEM_HOME)+File.separator+lookupname+"_"+System.currentTimeMillis()+ILookupConstants.CSV_FORMAT;
			final File file =  new File(TMP_FILE_NAME);
			
			
			cw = new CSVWriter(new FileWriter(file));

			
			query = "select LUQC_COLUMN_NAME,LUQC_DATATYPE,LUQC_DATA_FORMAT,LUQC_IS_KEY_COLUMN, LUQC_IS_DISPLAY_COLUMN, LUQC_IS_SPECIAL_VALUE_COLUMN, LUQC_EXCLUSION_QUERY from LOOKUP_COLUMNS where LUQC_LOOKUP_ID = ? and LUQC_DATE_DELETED is null  ORDER BY LUQC_LOOKUP_COLUMN_ID ";
			preStmtLookCol = conn.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY); 
			preStmtLookCol.setInt(1, lookupID);
			rslc = preStmtLookCol.executeQuery();
			
			ResultSetMetaData resdata = rslc.getMetaData();
			//generating columns headers for csv file
			for (int i = 1; i <= resdata.getColumnCount(); i++) {
				while(rslc.next()){
					
					if( i == 1){
						columnsNames.add(rslc.getString(1));
	
						cw.put((null != rslc.getString(1) ? rslc.getString(1):""));
					}else if(i == 2){
						cw.put((null != rslc.getString(2) ? rslc.getString(2):""));
					}else if(i == 3){
						cw.put((null != rslc.getString(3) ? rslc.getString(3):""));
					}else if(i == 4){
						cw.put((null != rslc.getString(4) ? rslc.getString(4):"N"));
					}else if(i == 5){
						cw.put((null != rslc.getString(5) ? rslc.getString(5):"N"));
					}else if(i == 6){
						cw.put((null != rslc.getString(6) ? rslc.getString(6):"N"));
					}
					
				}
				//Moving the cursor to initial position in resultset
				if(i <= 6){
					rslc.beforeFirst();
					cw.nl();
				}
			}
			
			
			stmt = conn.createStatement(); 
			SQLInjectionValidator.validateSelectSQL(sql);
			rsSql   = stmt.executeQuery(sql);
			
			WebServiceLoggerUtil.logInfo(className, "getListDataExclude", "info total columns", new Object[] { columnsNames });
			
			//generating columns data in csv file
			if(columnsNames != null && !columnsNames.isEmpty()){
				while(rsSql.next()){
					for(int i=0;i< columnsNames.size();i++){
						
						
	                    if(rsSql.getObject(columnsNames.get(i)) !=null)
	                    {
	                    	
	                    	Object obj = rsSql.getObject(columnsNames.get(i));
	                    	
	                    	if(obj instanceof java.sql.Timestamp || obj instanceof java.sql.Date ){
	                    		String dateData = getDateString(columnsNames.get(i),rsSql.getDate(columnsNames.get(i)));
	                    		cw.put(dateData);
	                    	}else{
	                    		cw.put(rsSql.getObject(columnsNames.get(i)).toString());
	                    	}
	                    	
	                    	columnsNamesAvailable.add(columnsNames.get(i));
	                    }
	                    else
	                    {
	                        cw.put("");
	                    }	                     
	                }
					cw.nl();
				}
			}
			
			WebServiceLoggerUtil.logInfo(className, "getListDataExclude", "info total available columns  ", new Object[] { columnsNamesAvailable });
			
			DataSource dataSource = new FileDataSource(file){
				
				@Override
				public String getContentType() {
					return "text/csv";
				}
				
				@Override
				public InputStream getInputStream() throws IOException {
					      return new FileInputStream(file){
					    	  
					    	  	@Override
					    	    public void close() throws IOException {
					    	        super.close();
					    	        if(file!=null)
					    	        	file.delete();
					    	    }
					      };
			     }

			};
			DataHandler dataHandler = new DataHandler(dataSource);
			LookupExclusionData lookexcl = new LookupExclusionData();
			lookexcl.setColumnName(colName);
			lookexcl.setExclusionData(dataHandler);
			exclusions.add(lookexcl);
			
			
			/*rslc.beforeFirst();

			while(rslc.next()){
				if(rslc.getInt(7) != 0 ){
					getListDataExclude(rslc.getInt(7), rslc.getString(1), conn);
				}
			}*/
			
			
			} catch (Throwable e) {
				WebServiceLoggerUtil.logError(className, "getListDataExclude", "Exception occurred.", new Object[] { columnsNames, columnsNamesAvailable }, e);
				
			}finally{
				try {
					DBUtil.close(rsLookup,null);
					DBUtil.close(rsSql,null);
					DBUtil.close(rslc,null);
					DBUtil.close(null,stmt);
					DBUtil.close(null, preStmtLookup);
					DBUtil.close(null, preStmtLookCol);
					
					if (cw != null) {
						cw.close();
					}
					
				} catch (Throwable e) {
					// TODO Auto-generated catch block
					
				}
			}
	}
	
	

}