/**
 * 
 */
package com.coverall.mic.soap.policyupload;

/**
 * @author Kaushik87149
 *
 */
import javax.jws.WebService;

@WebService
public interface IPolicyUploadService {

	PolicyUploadResponse processXml(PolicyUploadRequest request);
	
}
