/**
 * 
 */
package com.coverall.mic.soap.policyupload;

import javax.activation.DataHandler;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlMimeType;

/**
 * @author Kaushik87149
 *
 */
public class PolicyUploadRequest {

	private String entityReference;
	
	private boolean purgeExistingEntity;
	
	private boolean rateEntity;
	
	private boolean retainAuditFieldValues;
	
	private boolean retainIDValues;
	
	private boolean returnExtract;
	
	private DataHandler xmlData;

	@XmlElement(required = true)
	public String getEntityReference() {
		return entityReference;
	}

	public void setEntityReference(String entityReference) {
		this.entityReference = entityReference;
	}

	@XmlElement(required = true)
	@XmlMimeType("text/xml")
	public DataHandler getXmlData() {
		return xmlData;
	}

	public void setXmlData(DataHandler xmlData) {
		this.xmlData = xmlData;
	}

	public boolean isPurgeExistingEntity() {
		return purgeExistingEntity;
	}

	public void setPurgeExistingEntity(boolean purgeExistingEntity) {
		this.purgeExistingEntity = purgeExistingEntity;
	}

	public boolean isRateEntity() {
		return rateEntity;
	}

	public void setRateEntity(boolean rateEntity) {
		this.rateEntity = rateEntity;
	}

	public boolean isRetainAuditFieldValues() {
		return retainAuditFieldValues;
	}

	public void setRetainAuditFieldValues(boolean retainAuditFieldValues) {
		this.retainAuditFieldValues = retainAuditFieldValues;
	}

	public boolean isRetainIDValues() {
		return retainIDValues;
	}

	public void setRetainIDValues(boolean retainIDValues) {
		this.retainIDValues = retainIDValues;
	}

	public boolean isReturnExtract() {
		return returnExtract;
	}

	public void setReturnExtract(boolean returnExtract) {
		this.returnExtract = returnExtract;
	}

	@Override
	public String toString() {
		return "PolicyUploadRequest [entityReference=" + entityReference + ", purgeExistingEntity="
				+ purgeExistingEntity + ", rateEntity=" + rateEntity + ", retainAuditFieldValues="
				+ retainAuditFieldValues + ", retainIDValues=" + retainIDValues + ", returnExtract=" + returnExtract
				+ ", xmlData=" + xmlData + "]";
	}
	
}
