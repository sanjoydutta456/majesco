/**
 * 
 */
package com.coverall.mic.soap.policyupload;

import java.util.List;

import javax.activation.DataHandler;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlMimeType;

/**
 * @author Kaushik87149
 *
 */
public class PolicyUploadResponse {

	private String responseCode;
	
	private String responseMessage;
	
	private List<ValidationError> invalidFields; 
	
	private DataHandler xmlData;

	@XmlMimeType("text/xml")
	public DataHandler getXmlData() {
		return xmlData;
	}

	public void setXmlData(DataHandler xmlData) {
		this.xmlData = xmlData;
	}

	@XmlElement(required = true)
	public String getResponseCode() {
		return responseCode;
	}
	
	@XmlElement(required = true)
	public String getResponseMessage() {
		return responseMessage;
	}
	
	public void setSuccess(String message)	{
		responseCode = "SUCCESS";
		responseMessage = message;
	}
	
	public void setError(String message){
		responseCode = "FAILURE";
		responseMessage = message;
		
	}

	@XmlElement(required = false)
	public List<ValidationError> getInvalidFields() {
		return invalidFields;
	}

	public void setInvalidFields(List<ValidationError> invalidFields) {
		this.invalidFields = invalidFields;
	}
}

