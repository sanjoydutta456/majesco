/**
 * 
 */
package com.coverall.mic.soap.policyupload;

import javax.xml.bind.annotation.XmlElement;

/**
 * @author Kaushik87149
 *
 */
public class ValidationError {
	
	public enum ErrorTypeEnum{
	    AUTO_LOOKUP, 
	    DEFAULT,
	    EXTERNAL_SOURCE,
	    CRITERIA,
	    REQUIRED,
	    LOOKUP,
	    RANGE,
	    OCCURRENCE,
	    ERROR_MESSAGES,
	    LABEL,
	    LOOKUP_VALUES,
	    FIELD_TYPE,
	    UPDATABLE,
	    FIELD_DEFINITION,
	    CUSTOMIZATION,
	    VALIDATION,
	    LISTENER,
	    AUTO_GENERATE,
	    CHILD,
	    TOOLBAR, 
	    INVALID_FORMAT,
	    FORMAT
	}
	
	
	private String fieldXPath;
	private long fieldGid;
	private ErrorTypeEnum errorType; 
	private String errorMessage;
	
	@XmlElement(required = true)
	public String getFieldXPath() {
		return fieldXPath;
	}
	public void setFieldXPath(String fieldXPath) {
		this.fieldXPath = fieldXPath;
	}
	@XmlElement(required = true)
	public long getFieldGid() {
		return fieldGid;
	}
	public void setFieldGid(long fieldGid) {
		this.fieldGid = fieldGid;
	}
	@XmlElement(required = true)
	public ErrorTypeEnum getErrorType() {
		return errorType;
	}
	public void setErrorType(ErrorTypeEnum errorType) {
		this.errorType = errorType;
	}
	@XmlElement(required = true)
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	@Override
	public String toString() {
		return "ValidationError [fieldXPath=" + fieldXPath + ", fieldGid=" + fieldGid + ", errorType=" + errorType
				+ ", errorMessage=" + errorMessage + "]";
	}
	
}
