/**
 * 
 */
package com.coverall.mic.soap.policyupload.impl;

import java.util.List;

import javax.jws.WebService;
import javax.servlet.http.HttpServletRequest;
import javax.xml.ws.soap.MTOM;

import org.apache.commons.lang.StringUtils;
import org.apache.cxf.phase.PhaseInterceptorChain;
import org.apache.cxf.transport.http.AbstractHTTPDestination;

import com.coverall.mic.soap.policyupload.IPolicyUploadService;
import com.coverall.mic.soap.policyupload.PolicyUploadRequest;
import com.coverall.mic.soap.policyupload.PolicyUploadResponse;
import com.coverall.mt.http.User;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.pctv2.server.ws.service.upload.PCTUploadRequest;
import com.coverall.pctv2.server.ws.service.upload.PCTUploadResponse;
import com.coverall.pctv2.server.ws.service.upload.PolicyUploadIntegration;

/**
 * @author Kaushik87149
 *
 */
@MTOM(enabled=true)
@WebService(endpointInterface = "com.coverall.mic.soap.policyupload.IPolicyUploadService")
public class PolicyUploadService implements IPolicyUploadService {
	private static final String className = PolicyUploadService.class.getName();
	
	@Override
	public PolicyUploadResponse processXml(PolicyUploadRequest request) {
		PolicyUploadResponse response = new PolicyUploadResponse();
		try {
			PolicyUploadServiceHelper helper = new PolicyUploadServiceHelper();
			
			List<String> validationMessages = helper.validateRequest(request);
			
			String policyXML = helper.readRequestXml(request);
			
			if(policyXML==null || policyXML.length()<=30){
				validationMessages.add("Policy xml is not attached or is invalid. Please check if MTOM is enabled for request.");
			}
			
			if(validationMessages!=null && !validationMessages.isEmpty()){
				response.setError(StringUtils.join(validationMessages, "\n"));
				
				return response;
			}
			
			HttpServletRequest httpServletRequest = (HttpServletRequest) PhaseInterceptorChain.getCurrentMessage().get(AbstractHTTPDestination.HTTP_REQUEST);
			User user = User.getUser(httpServletRequest);
			
			PolicyUploadIntegration policyUploadIntegration = new PolicyUploadIntegration();
		
			PCTUploadRequest pctUploadRequest = helper.convertRequest(request, user);
			pctUploadRequest.setPolicyXML(policyXML);
			
			PCTUploadResponse pctUploadResponse = policyUploadIntegration.processRequest(pctUploadRequest,user);
			response = helper.convertResponse(pctUploadResponse);
			
			if(request.isRateEntity() && 
					policyUploadIntegration.getUploadStatus().ordinal() >= PolicyUploadIntegration.UploadStatus.RATING_FAILED.ordinal())	{
				
				//Read Rating errors
				
	        	String entref = pctUploadRequest.getEntityReference();
	            String entType = entref.substring(0, 1);
	            if ("P".equalsIgnoreCase(entType)) {
	                entType = "POLICY";
	            } else {
	                entType = "QUOTE";
	            }	            
				try {
						response.setInvalidFields(helper.getInvalidExpressions(entType, entref, user));
				} catch (Exception e) {
					String errrorMessage = "Exception while getting rating errors." + e.getMessage();
					WebServiceLoggerUtil.logError(className, "processXml", "Exception occurred.", new Object[] { request }, e);
					pctUploadResponse.setFailure(true);
					pctUploadResponse.setMessage(pctUploadResponse.getMessage() + "\n" + errrorMessage);
				}
			}
			
			
		} catch (Throwable e) {
			
			WebServiceLoggerUtil.logError(className, "processXml", "Unhandled exception while processing request.", new Object[] { request }, e);
			response.setError("Unhandled exception while processing request." + e.getMessage());
			return response;
		}
		return response;
	}


}
