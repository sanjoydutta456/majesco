/**
 * 
 */
package com.coverall.mic.soap.policyupload.impl;

import java.io.IOException;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.naming.NamingException;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.soap.util.mime.ByteArrayDataSource;

import com.coverall.mic.soap.policyupload.PolicyUploadRequest;
import com.coverall.mic.soap.policyupload.PolicyUploadResponse;
import com.coverall.mic.soap.policyupload.ValidationError;
import com.coverall.mic.soap.policyupload.ValidationError.ErrorTypeEnum;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;
import com.coverall.mt.webservices.WebServiceLoggerUtil;
import com.coverall.pctv2.server.service.PCTRequestContext;
import com.coverall.pctv2.server.ws.service.upload.PCTUploadRequest;
import com.coverall.pctv2.server.ws.service.upload.PCTUploadResponse;
import com.coverall.policy.common.util.DBUtil;

/**
 * @author Kaushik87149
 *
 */
public class PolicyUploadServiceHelper {
	private static final String XPATH_DELIM = "/";
	private static final String className = PolicyUploadService.class.getName();
	
	public List<String> validateRequest(PolicyUploadRequest request){
		List<String> validationMessages = new ArrayList<String>();
		//Validate request
		if(request==null){
			validationMessages.add("Request Data is missing.");
		}else	{
			if(request.getEntityReference()==null){
				validationMessages.add("entityReference is required.");
			}
			if(request.getXmlData()==null)	{
				validationMessages.add("xmlData is required as MTOM attachment. ");
			}
		}
		
		return validationMessages;
	}
	
	public String readRequestXml(PolicyUploadRequest request){
		String policyXML = null;
		StringWriter writer = new StringWriter();
		try {
			IOUtils.copy(request.getXmlData().getInputStream(), writer, "UTF-8");
			policyXML = writer.toString();
		} catch (IOException e) {
			WebServiceLoggerUtil.logError(className, "readRequestXml", "Exception while reading request XML.", new Object[] { request }, e);
		}
		return policyXML;
		
	}
	
	public PCTUploadRequest convertRequest(PolicyUploadRequest request, User user) {
		PCTUploadRequest pctUploadRequest = new PCTUploadRequest();
		pctUploadRequest.setEntityReference(request.getEntityReference());
		pctUploadRequest.setPurgeExistingEntity(request.isPurgeExistingEntity());
		pctUploadRequest.setRateEntity(request.isRateEntity());
		pctUploadRequest.setRetainAuditFieldVals(request.isRetainAuditFieldValues());
		pctUploadRequest.setRetainIDVals(request.isRetainIDValues());
		pctUploadRequest.setReturnRatedEntity(request.isReturnExtract());
		
		pctUploadRequest.setSourceSystem(PCTRequestContext.SOURCE_SYSTEM_IMPORT_AS_IS);
		
		pctUploadRequest.setUserName(user.getFullName());
		pctUploadRequest.setPassword(user.getPassword());
		
		return pctUploadRequest;
	}
	
	public PolicyUploadResponse convertResponse(PCTUploadResponse pctUploadResponse) {	
		PolicyUploadResponse response = new PolicyUploadResponse();
		String xmlString = pctUploadResponse.getXmlString();
		if(xmlString!=null)	{
			DataSource dataSource = new ByteArrayDataSource(xmlString, "text/xml; charset=UTF-8");
			response.setXmlData(new DataHandler(dataSource));
		}
		
		if(pctUploadResponse.isFailure()){
			response.setError(pctUploadResponse.getMessage());
		}else	{
			response.setSuccess(pctUploadResponse.getMessage());
		}
		
		return response;
	}
	
	public List<ValidationError> getInvalidExpressions(String entityType, String entityReference, User user)	{
		List<ValidationError> validationErrors = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		Statement stmtXpath = null;
		ResultSet rs = null;
		ResultSet rsXpath = null;
		
		String sqlGetInvalidExp = "select PIE_ID, PIE_CONTEXT_PATH, PIE_GID, PIE_TYPE, PIE_EXPRESSION_TYPE, PIE_ERROR_MESSAGE " + 
				"from PCT_INVALID_EXPRESSIONS " + 
				"where PIE_ENTITY_REFERENCE in (select GID from EV_MIS_QUOTE_POLICIES where ENTITY_REFERENCE = ? ) "
				+ " and pie_entity_type = ? " + 
				"and PIE_ERROR_MESSAGE is not null";
		String sqlGetxpath = "select POF_ID, POF_NAME, POF_OBJECT_FIELD_ID, POF_XPATH_LOCATION, DECODE(NVL(DSR_LOB_CODE, DSR_PRODUCT_CODE), null, 'N', 'Y') IS_PRODUCT " + 
				"from PCT_OBJECT_FIELDS, DS_RESOURCE " + 
				"where DSR_GID = POF_ID " + 
				"and POF_ID = ANY ";
		try	{
			conn = ConnectionPool.getConnection(user);
			
			//Get invalid expressions
			pstmt = conn.prepareStatement(sqlGetInvalidExp);
			pstmt.setString(1, entityReference);
			pstmt.setString(2, entityType);
			rs = pstmt.executeQuery();
			validationErrors = new ArrayList<ValidationError>();
			Map<Long, String[]> errorIdToXpathMap = new HashMap<Long, String[]>();
			Map<Long, ValidationError> errorIdToObjectMap = new HashMap<Long, ValidationError>();
			Set<String> pofIdSet = new HashSet<String>();
			while(rs.next())	{
				ValidationError validationerror = new ValidationError();
				long errorId = rs.getLong("PIE_ID");
				String xpath = rs.getString("PIE_CONTEXT_PATH");
				validationerror.setFieldGid(rs.getLong("PIE_GID"));
				validationerror.setErrorType(ErrorTypeEnum.valueOf(rs.getString("PIE_EXPRESSION_TYPE")));
				validationerror.setErrorMessage(rs.getString("PIE_ERROR_MESSAGE"));
				
				errorIdToObjectMap.put(errorId, validationerror);
				
				String[] pofIdArray = StringUtils.split(xpath, XPATH_DELIM);
				errorIdToXpathMap.put(errorId, pofIdArray);
				
				pofIdSet.addAll(Arrays.asList(pofIdArray));
				validationErrors.add(validationerror);
			}
			
			if(validationErrors.isEmpty())	{
				return null;
			}
			
			//Get Xpath location for all pof ids
			String[] uniquePofIdArray = new ArrayList<String>(pofIdSet).toArray(new String[pofIdSet.size()]); 
			String sql = sqlGetxpath+ "( " + StringUtils.join(uniquePofIdArray, ", ") + " ) ";
			
			stmtXpath = conn.createStatement();
			rsXpath = stmtXpath.executeQuery(sql);
			Map<Long,PctObjectField> pofIdToXpathMap = new HashMap<Long, PctObjectField>();
			while(rsXpath.next())	{
				PctObjectField pctObjectField = new PctObjectField();
				pctObjectField.setId(rsXpath.getLong("POF_ID"));
				pctObjectField.setName(rsXpath.getString("POF_NAME"));
				pctObjectField.setProductLevelField("Y".equalsIgnoreCase(rsXpath.getString("IS_PRODUCT")));
				pctObjectField.setXpathLocation(rsXpath.getString("POF_XPATH_LOCATION"));
				pctObjectField.setObjectFieldIdNotNull(rsXpath.getObject("POF_OBJECT_FIELD_ID")!=null);
				
				pofIdToXpathMap.put(pctObjectField.getId(), pctObjectField);
				
			}
			
			//replace ids with values in context path
			for(Map.Entry<Long, ValidationError> entry : errorIdToObjectMap.entrySet())	{
				Long errorId = entry.getKey();
				ValidationError validationError = entry.getValue();
				String[] pofIdArray = errorIdToXpathMap.get(errorId);
				String fieldXPath = getXmlContextPath(pofIdArray, pofIdToXpathMap);
				validationError.setFieldXPath(fieldXPath);
			}
						
		} catch (NamingException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally	{
			try {
				DBUtil.close(rsXpath, stmtXpath);
				DBUtil.close(rs, pstmt, conn);
			} catch (SQLException e) {
			}
		}
		
				
		return validationErrors;
	}

	/**
	 * returns xml xpath matching with the tags in Policy Xml Extract. 
	 * @param pofIdArray
	 * @param pofIdToXpathMap
	 * @return
	 */
	private String getXmlContextPath(String[] pofIdArray, Map<Long, PctObjectField> pofIdToXpathMap) {
		List<String> xPathValueList = new ArrayList<String>();
		xPathValueList.add("QuotePolicyList");
		xPathValueList.add("QuotePolicy");
		
		//Add <Product> for product level attributes, those whose root element is a product level field
		Long rootElementId = Long.valueOf(pofIdArray[0]);
		PctObjectField rootPctObjectField  = pofIdToXpathMap.get(rootElementId);
		if(rootPctObjectField.isProductLevelField())	{	
			xPathValueList.add("Product");
		}
		
		//Handle each element 
		for(int i=0; i<pofIdArray.length; i++){
			Long pofId = Long.valueOf(pofIdArray[i]);
			PctObjectField pctObjectField  = pofIdToXpathMap.get(Long.valueOf(pofId));
			if(pctObjectField.isObjectFieldIdNotNull())	{
				//For Objects Add a xyzList tag 
				String xmlTag = pctObjectField.getXpathLocation();
				xPathValueList.add(xmlTag + "List");
				xPathValueList.add(xmlTag);
			}else	{
				//xpathLocation of fields will be NA, so use field-name in initCap
				String xmlTag = initCap(pctObjectField.getName());
				xPathValueList.add(xmlTag);
			}
		}
		String fieldXPath = XPATH_DELIM + StringUtils.join(xPathValueList, XPATH_DELIM);
		return fieldXPath;
	}
    
    private String initCap(String input) {
        StringBuffer ff = new StringBuffer();

        String strArray[] = input.split("_| ");
        for (int i = 0 ; i < strArray.length; i++ ) {
            String f = strArray[i];
            if (f != null &&  f.length() > 0 ) {
                ff.append(f.substring(0, 1).toUpperCase()).append(f.substring(1, f.length()).toLowerCase());
            }
        }

        return ff.toString();
    }
    
    class PctObjectField	{
    	private long id;
    	private String name;
    	private boolean productLevelField;
    	private boolean objectFieldIdNotNull;
    	private String xpathLocation;
		public long getId() {
			return id;
		}
		public void setId(long id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public boolean isProductLevelField() {
			return productLevelField;
		}
		public void setProductLevelField(boolean productLevelField) {
			this.productLevelField = productLevelField;
		}
		public boolean isObjectFieldIdNotNull() {
			return objectFieldIdNotNull;
		}
		public void setObjectFieldIdNotNull(boolean objectFieldIdNotNull) {
			this.objectFieldIdNotNull = objectFieldIdNotNull;
		}
		public String getXpathLocation() {
			return xpathLocation;
		}
		public void setXpathLocation(String xpathLocation) {
			this.xpathLocation = xpathLocation;
		}
		@Override
		public String toString() {
			return "PctObjectField [id=" + id + ", " + (name != null ? "name=" + name + ", " : "")
					+ "productLevelField=" + productLevelField + ", objectFieldIdNotNull=" + objectFieldIdNotNull + ", "
					+ (xpathLocation != null ? "xpathLocation=" + xpathLocation : "") + "]";
		}
    	
    }
    
}
