package com.coverall.mic.webservices.policytransaction;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import com.coverall.exceptions.SecurityException;
import com.coverall.mic.services.policy.transactionprocessing.PolicyTransactionProcessor;
import com.coverall.mt.security.AdminX;
import com.coverall.mt.util.LogEntry;
import com.coverall.mt.util.LogMinder;
import com.coverall.mt.xml.LogMinderDOMUtil;
import com.coverall.mt.xml.ServletConfigUtil;

public class PTSBindingDriver {
	
	private String sql_1 = "INSERT INTO WS_POLICY_TRANSACTION_REQUESTS (WBN_REQUEST_ID, WBN_REQUEST_TYPE, WBN_POLICY_REFERENCE, WBN_USER_CREATED) VALUES (S_WBN_REQUEST_ID_SEQ.NEXTVAL,?,?,?)";
	private String sql_2 = "INSERT INTO WS_POLICY_TRANSACTIONPARAMETER (WBP_PARAMETER_ID, WBP_REQUEST_ID, WBP_PARAMETER_NAME, WBP_PARAMETER_VALUE, WBP_USER_CREATED) VALUES (S_WBP_PARAMETER_ID_SEQ.NEXTVAL,?,?,?,?)";
	private String REQUEST_TYPE_1 = "POLICY_CANCELLATION";
	private String EFFECTIVE_DATE_STR = "CANCELLATION_EFFECTIVE_DATE";
	private String CANCELLATION_REASON_STR = "CANCELLATION_REASON";
	private String CANCELLATION_REASON_CODE = "CANCELLATION_REASON_CODE";
	private String REQUEST_TYPE_2 = "POLICY_REINSTATEMENT";
	private String REINSTATE_EFFECTIVE_DATE_STR = "REINSTATEMENT_EFFECTIVE_DATE";
	private String REINSTATEMENT_REASON_STR = "REINSTATEMENT_REASON";
	private String REINSTATEMENT_REASON_CODE = "REINSTATEMENT_REASON_CODE";
	
	public String validateData(String policyReference, Date effectiveDate,
			String reason, Connection con) {
		StringBuffer errorMessage = new StringBuffer("");
		SimpleDateFormat df = new SimpleDateFormat("mm/dd/yyyy");
		
		if(policyReference == null){
			errorMessage.append("Policy Reference cannot be null. ");			
		}else if(!isValidPolicyReference(policyReference, con)){
			errorMessage.append("Invalid Policy Reference. ");			
		}
		
		if(effectiveDate == null){
			errorMessage.append("Effective Date cannot be null. ");			
		}else if(df.format(effectiveDate) == null){
			errorMessage.append("Invalid Effective Date. ");			
		}
		
		if(reason == null){
			errorMessage.append("Reason cannot be null. ");			
		}else if(reason.trim().equals("")){
			errorMessage.append("Reason cannot be blank. ");			
		}
		
		return errorMessage.toString();
	}

	private boolean isValidPolicyReference(String policyReference,
			Connection con) {
		String sql_3 = "SELECT * from ev_mis_quote_policies where entity_reference = ?";
		boolean returnStatus = false;
		try {
			PreparedStatement st = con.prepareStatement(sql_3);
			st.setString(1, policyReference);
			ResultSet rs = st.executeQuery();
			if(rs != null && rs.next()){
				returnStatus = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			returnStatus = false;
		}
		return returnStatus;
	}

	public String queueCancellationRequest(String policyReference, Date effectiveDate, String reason, String reasonCode, String username,
			Connection conn, HashMap transactionParams, String password) throws SQLException{
		
		conn.setAutoCommit(false);
		PreparedStatement ps_1 = null;
		PreparedStatement ps_2 = null;
		int req_id = 0;
		String generatedColumns[] = { "WBN_REQUEST_ID" };
		boolean retStatus = false;
		String status = "FAILED";
		PolicyTransactionProcessor processor = null;
		try {
			ps_1 = conn.prepareStatement(sql_1, generatedColumns);
			ps_1.setString(1, REQUEST_TYPE_1);
			ps_1.setString(2, policyReference);
			ps_1.setString(3, username);
			int rowCount = ps_1.executeUpdate();
			ResultSet rs = ps_1.getGeneratedKeys();
			if(rs != null){
				if(rs.next())
					req_id = rs.getInt(1);
			}
			if(req_id == 0){
				conn.rollback();
			}else if(rowCount > 0){
				ps_2 = conn.prepareStatement(sql_2);
				ps_2.setInt(1, req_id);
				ps_2.setString(2, EFFECTIVE_DATE_STR);
				ps_2.setDate(3, new java.sql.Date(effectiveDate.getTime()));
				ps_2.setString(4, username);
				ps_2.addBatch();
				ps_2.setInt(1, req_id);
				ps_2.setString(2, CANCELLATION_REASON_STR);
				ps_2.setString(3, reason);
				ps_2.setString(4, username);
				ps_2.addBatch();
				if(reasonCode != null && !reasonCode.equals("")){
					ps_2.setInt(1, req_id);
					ps_2.setString(2, CANCELLATION_REASON_CODE);
					ps_2.setString(3, reasonCode);
					ps_2.setString(4, username);
					ps_2.addBatch();
				}
				ps_2.executeBatch();
				conn.commit();
				retStatus = true;
			}else{
				conn.rollback();
				retStatus = false;
			}
		} catch (SQLException e) {
			conn.rollback();
			e.printStackTrace();
		}finally{
			ps_1.close();
			ps_2.close();
			conn.close();
		}
		
		if(retStatus){
			if(transactionParams != null){
				try{
					processor = new PolicyTransactionProcessor();
					processor.processTransaction(transactionParams, username.substring(0, username.indexOf("@")), password, username.substring(username.indexOf("@")+1));
					status = processor.getTransactionStatus();
				}catch(Exception e){
					status = "FAILED : "+e.getMessage();
					e.printStackTrace();
				}
			}else{
				status = "SUCCESS";
			}
		}else{
			status = "FAILED";
		}
		return status;
	}
	
	public String queueReinstatementRequest(String policyReference, Date effectiveDate, String reason, String reasonCode, String username,
			Connection conn, HashMap transactionParams, String password) throws SQLException{
		
		conn.setAutoCommit(false);
		PreparedStatement ps_1 = null;
		PreparedStatement ps_2 = null;
		int req_id = 0;
		String generatedColumns[] = { "WBN_REQUEST_ID" };
		boolean retStatus = false;
		String status = "FAILED";
		PolicyTransactionProcessor processor = null;
		try {
			ps_1 = conn.prepareStatement(sql_1, generatedColumns);
			ps_1.setString(1, REQUEST_TYPE_2);
			ps_1.setString(2, policyReference);
			ps_1.setString(3, username);
			int rowCount = ps_1.executeUpdate();
			ResultSet rs = ps_1.getGeneratedKeys();
			if(rs != null){
				if(rs.next())
					req_id = rs.getInt(1);
			}
			if(req_id == 0){
				conn.rollback();
			}else if(rowCount > 0){
				ps_2 = conn.prepareStatement(sql_2);
				ps_2.setInt(1, req_id);
				ps_2.setString(2, REINSTATE_EFFECTIVE_DATE_STR);
				ps_2.setDate(3, new java.sql.Date(effectiveDate.getTime()));
				ps_2.setString(4, username);
				ps_2.addBatch();
				ps_2.setInt(1, req_id);
				ps_2.setString(2, REINSTATEMENT_REASON_STR);
				ps_2.setString(3, reason);
				ps_2.setString(4, username);
				ps_2.addBatch();
				if(reasonCode != null && !reasonCode.equals("")){
					ps_2.setInt(1, req_id);
					ps_2.setString(2, REINSTATEMENT_REASON_CODE);
					ps_2.setString(3, reasonCode);
					ps_2.setString(4, username);
					ps_2.addBatch();
				}
				ps_2.executeBatch();
				conn.commit();
				retStatus = true;
			}else{
				conn.rollback();
				retStatus = false;
			}
		} catch (SQLException e) {
			conn.rollback();
			e.printStackTrace();
		}finally{
			ps_1.close();
			ps_2.close();
			conn.close();
		}
		
		if(retStatus){
			if(transactionParams != null){
				try{
					processor = new PolicyTransactionProcessor();
					processor.processTransaction(transactionParams, username.substring(0, username.indexOf("@")), password, username.substring(username.indexOf("@")+1));
					status = processor.getTransactionStatus();
				}catch(Exception e){
					status = "FAILED : "+e.getMessage();
					e.printStackTrace();
				}
			}else{
				status = "SUCCESS";
			}
		}else{
			status = "FAILED";
		}
		return status;
	}
	
	public boolean hasBookPermission(String domainName, String userId) {
	       AdminX adminX = null;
	       boolean hasAutoBookPermission = false;

	       try {
	           adminX = new AdminX();
	           hasAutoBookPermission = adminX.hasSubPermission(
	                   domainName,
	                   userId,
	                   AdminX.USER_PRINCIPAL,
	                   "Booking?Auto Book");
	       } catch (SecurityException se) {
	           LogMinder.getLogMinder().log(
	                   LogEntry.SEVERITY_FATAL,
	                   getClass().getName(),
	                   new Exception().getStackTrace()[0].toString(),
	                   ServletConfigUtil.COMPONENT_FRAMEWORK,
	                   new Object[] {},
	                   "In ATP Rest Service, could not obtain permissions for the user:" + userId + "@" + domainName,
	                   se,
	                   LogMinderDOMUtil.VALUE_MIC);
	       }
	       return hasAutoBookPermission;
	}

    public String[] queueConvertToBinderRequest(String quoteEntityReference, Connection conn,
            HashMap<String, String> transactionParams, String userId, String password) throws SQLException {
        
        conn.setAutoCommit(false);
        PreparedStatement ps_1 = null;
        int req_id = 0;
        String generatedColumns[] = { "WBN_REQUEST_ID" };
        boolean retStatus = false;
        String status = "FAILED";
        PolicyTransactionProcessor processor = null;
        String statusDescription = null;
        String[] statusArray = null;
        try {
            ps_1 = conn.prepareStatement(sql_1, generatedColumns);
            ps_1.setString(1, "CONVERT_QUOTE");
            ps_1.setString(2, quoteEntityReference);
            ps_1.setString(3, userId);
            int rowCount = ps_1.executeUpdate();
            ResultSet rs = ps_1.getGeneratedKeys();
            if(rs != null){
                if(rs.next())
                    req_id = rs.getInt(1);
            }
            if(req_id == 0){
                conn.rollback();
            }else if(rowCount > 0){
                conn.commit();
                retStatus = true;
            }else{
                conn.rollback();
                retStatus = false;
            }
        } catch (SQLException e) {
            conn.rollback();
            e.printStackTrace();
        }finally{
            ps_1.close();
        }
        
        if(retStatus){
            if(transactionParams != null){
                try{
                    processor = new PolicyTransactionProcessor();
                    processor.processTransaction(transactionParams, userId.substring(0, userId.indexOf("@")), password, userId.substring(userId.indexOf("@")+1));
                    status = processor.getTransactionStatus();
                    statusDescription = processor.getStatusDetails();
                    statusArray = new String[2];
                    statusArray[0] = status;
                    statusArray[1] = statusDescription;
                }catch(Exception e){
                    status = "FAILED : "+e.getMessage();
                    e.printStackTrace();
                }
            }else{
                status = "SUCCESS";
            }
        }else{
            status = "FAILED";
        }
        return statusArray;
    }

}
