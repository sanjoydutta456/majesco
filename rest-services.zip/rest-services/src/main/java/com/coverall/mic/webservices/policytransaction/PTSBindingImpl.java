package com.coverall.mic.webservices.policytransaction;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;

import javax.naming.NamingException;

import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;
import com.coverall.mt.security.permission.RIPermission;
import com.coverall.mic.webservices.policytransaction.PTSBindingDriver;
import com.coverall.mic.webservices.policytransaction.PTSInput;
import com.coverall.mic.webservices.policytransaction.PTSPortType;
import com.coverall.util.DBUtil;

/**
 * 
 * @author paramvir
 *
 */

public class PTSBindingImpl implements PTSPortType{
	@Override	
	public String requestCancellation(PTSInput param0) throws java.rmi.RemoteException {
		
		String username = param0.getUsername();
		String password = param0.getPassword();
		String policyReference = param0.getPolicyReference();
		Date effectiveDate = param0.getEffectiveDate().getTime();
		String reason = param0.getReason();
		String retMessage = "";
		Connection conn = null;
		User user = null;
		String validationError = "";
		PTSBindingDriver driver = null;
		String errorMessage = "Invalid UserName/Password.";
		
		/** Authentication Of the User*/
        if((null == username || username.trim().length() < 1 ) || (null== password || password.trim().length() < 1)){
            throw new java.rmi.RemoteException("UserName and Password are mandatory.");
        }                 
        try {
            user = new User(username, password);
 			boolean hasCancellationPermission = user.hasPermission(new RIPermission("Cancellation"));
 			if(!hasCancellationPermission){
 				errorMessage = "User does not have permission for cancellation";
 				throw new java.rmi.RemoteException (errorMessage);
 			}
 		} catch (Exception ice) {                     
            throw new java.rmi.RemoteException (errorMessage);                        
        }
                
      	try {
			if((conn = ConnectionPool.getConnection(user.getDomain())) != null){
				driver = new PTSBindingDriver();
				if((validationError = driver.validateData(policyReference,effectiveDate,reason,conn)).equals("")){
					try {
						String status = driver.queueCancellationRequest(policyReference, effectiveDate, reason, null, username, conn, null, password);
						if(status.toUpperCase().indexOf("FAIL") < 0){
							retMessage = "SUCCESS: Cancellation request for policy "+policyReference+" queued successfully"; 
						}else{
							retMessage = "FAILURE: Unable to queue request for policy "+policyReference;
						}
					} catch (SQLException e) {
						retMessage = "FAILURE: Exception occured while writing data to database";
						e.printStackTrace();
					}
				}else{
					retMessage = validationError;
				}
			}else{
				retMessage = "FAILURE: Unable to get DB connection with supplied credentials";
			}
		} catch (NamingException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return retMessage;
	}
	
	@Override
	public String processTransaction(PTSInput param0, boolean isSynchronousProcessing, String transactionType) throws java.rmi.RemoteException {
		String username = param0.getUsername();
		String password = param0.getPassword();
		String policyReference = param0.getPolicyReference();
		Date effectiveDate = param0.getEffectiveDate().getTime();
		String reason = param0.getReason();
		String retMessage = "";
		Connection conn = null;
		User user = null;
		String validationError = "";
		PTSBindingDriver driver = null;
		HashMap params = null;
		String permissionName = transactionType.equals("cancellation")?"Cancellation":transactionType.equals("reinstatement")?"Reinstatement":"";
		String errorMessage = "Invalid UserName/Password.";
		
		/** Authentication Of the User*/
        if((null == username || username.trim().length() < 1 ) || (null== password || password.trim().length() < 1)){
            throw new java.rmi.RemoteException("UserName and Password are mandatory.");
        }                 
        try {
            user = new User(username, password);
            boolean hasTransactionPermission = user.hasPermission(new RIPermission(permissionName));
 			if(!hasTransactionPermission){
 				errorMessage = "User does not have permission for "+transactionType;
 				throw new java.rmi.RemoteException (errorMessage);
 			}	
 		} catch (Exception ice) {                     
            throw new java.rmi.RemoteException (errorMessage);                        
        }
                
      	try {
			if((conn = ConnectionPool.getConnection(user.getDomain())) != null){
				driver = new PTSBindingDriver();
				if(isSynchronousProcessing){
					boolean hasBookPermission = driver.hasBookPermission(username.substring(username.indexOf("@")+1), username.substring(0, username.indexOf("@")));
					params = new HashMap();
					params.put("PROCESSING_TYPE", "COMPLETE");
					params.put("SOURCE_SYSTEM", "PolicyTransactionService");
					params.put("SHOULD_BOOK", hasBookPermission == true?"TRUE":"FALSE");
					params.put("ENTITY_TYPE", "POLICY");
					params.put("ENTITY_REFERENCE", policyReference);
					if(transactionType.equals("cancellation")){	
						params.put("CLASSICTRANSACTIONCODE", "04");
						params.put("ACTION", "cancellation");
						params.put("TRANSACTION_ACTION", "cancellation");
					}else if(transactionType.equals("reinstatement")){
						params.put("CLASSICTRANSACTIONCODE", "19");
						params.put("ACTION", "reinstatement");
						params.put("TRANSACTION_ACTION", "reinstatement");
					}
				}
				if((validationError = driver.validateData(policyReference,effectiveDate,reason,conn)).equals("")){
					try {
						String status = null;
						if(transactionType.equals("cancellation")){
							status = driver.queueCancellationRequest(policyReference, effectiveDate, reason, null, username, conn, params, password);
						}else if(transactionType.equals("reinstatement")){
							status = driver.queueReinstatementRequest(policyReference, effectiveDate, reason, null, username, conn, params, password);
						}
						if(status != null && status.toUpperCase().indexOf("FAIL") < 0){
							retMessage = "SUCCESS: Cancellation request for policy "+policyReference+" queued successfully"; 
						}else{
							retMessage = "FAILURE: Unable to queue request for policy "+policyReference;
						}
					} catch (SQLException e) {
						retMessage = "FAILURE: Exception occured while writing data to database";
						e.printStackTrace();
					}
				}else{
					retMessage = validationError;
				}
			}else{
				retMessage = "FAILURE: Unable to get DB connection with supplied credentials";
			}
		} catch (NamingException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(!conn.isClosed()){
					try {
						DBUtil.close(conn);   
					} catch (SQLException e) {
						
					}
				}
			} catch (SQLException e) {
				
			}
		}
		return retMessage;
	}
}
