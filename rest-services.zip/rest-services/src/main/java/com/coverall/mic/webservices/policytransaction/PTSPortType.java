/**
 * PTSPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.coverall.mic.webservices.policytransaction;

public interface PTSPortType extends java.rmi.Remote {
    public java.lang.String requestCancellation(com.coverall.mic.webservices.policytransaction.PTSInput param0) throws java.rmi.RemoteException;
    public java.lang.String processTransaction(com.coverall.mic.webservices.policytransaction.PTSInput param0, boolean isSynchronousProcessing, java.lang.String transactionType) throws java.rmi.RemoteException;
}