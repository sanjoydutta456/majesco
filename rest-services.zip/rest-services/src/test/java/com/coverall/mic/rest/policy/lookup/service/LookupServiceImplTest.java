package com.coverall.mic.rest.policy.lookup.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import com.coverall.mic.rest.policy.lookup.model.LookupRequest;
import com.coverall.mt.db.ConnectionPool;
import com.coverall.mt.http.User;
import com.coverall.mt.xml.DOMUtil;
import com.coverall.pctv2.server.yaml.generation.LookupBean;
import com.coverall.pctv2.server.yaml.generation.YAMLGenUtil;
import com.coverall.util.GeneralUtil;
import com.coverall.util.JUnitConnectionUtil;

import edu.emory.mathcs.backport.java.util.Arrays;

public class LookupServiceImplTest {
	private static final String MIC_USER = "MIC_USER";
    private static String url = "jdbc:oracle:thin:@xxx.xxx.xxx.xxx:xxx:xxx";
	private static JUnitConnectionUtil connUtil = new JUnitConnectionUtil(url);
	static {
		connUtil.addUser(MIC_USER, "mic_99", "xxx");
	}
	
	@Mock
	private static User user;
	
	@BeforeClass
	public static void myBeforeClass() throws Throwable {
		System.setProperty(DOMUtil.MIC_J2EE_HOME, "C:\\deleteme");
        String micJ2eeHome = System.getProperty(DOMUtil.MIC_J2EE_HOME);
		
		user = mock(User.class);
		
		MockedStatic<ConnectionPool> cp = Mockito.mockStatic(ConnectionPool.class);
        cp.when(() -> ConnectionPool.getConnection(user)).thenAnswer(invocation -> {
            return connUtil.getConnection(MIC_USER);
        });		
	}
	
	@Test
    public void testSubstituteRequestParametersInQuery_Company_JSON() throws Throwable {
		String inputJSON = "{\"params\":{\"LookupId\":\"POLICY.COMPANYNAME#2D9C68B1D40A72C4E050FF0A2FF95D31\",\"ProductCode\":\"WK\",\"CompanyName\":\"M%\"}}";
		
		String queryExpression = "SELECT  DISTINCT(pcm_code || ' - ' || pcm_name) DESCRIPTION,   pcm_code COMPANY_CODE,   pcm_name COMPANY_NAME,   pcm_scm_naic_code NAIC_CODE FROM ps_companies,   ps_company_lob_authorities,   ds_resource dsr_comp,   ds_resource dsr_comp_lob WHERE dsr_comp.dsr_gid =  pcm_id AND dsr_comp_lob.dsr_gid = pcl_id AND pcl_company_code = pcm_code AND dsr_comp.dsr_date_deleted is null AND dsr_comp_lob.dsr_date_deleted is null AND dsr_comp_lob.dsr_product_code = '{lookupParam:ProductCode}' AND ('{lookupParam:CompanyName}' IS NULL OR UPPER(pcm_name) like UPPER('%'||'{lookupParam:CompanyName}'||'%'))";
		String dlsExpression = null;
		
		Map<String, String> extraParameterMap = new HashMap<String, String>();
		
		ArrayList<Map<String, String>> expectedDataList = new ArrayList<Map<String, String>>();
		
		Map<String,String> dataMap = new HashMap<String, String>();
		
		dataMap.put("CompanyName", "Majesco");
		dataMap.put("NaicCode", null);
		dataMap.put("Description", "01 - Majesco");
		dataMap.put("CompanyCode", "01");
		
		expectedDataList.add(dataMap);
		
		testSubstituteRequestParametersInQuery_Actual_JSON(inputJSON, queryExpression, dlsExpression, extraParameterMap, expectedDataList);
    }
	
	@Test
    public void testSubstituteRequestParametersInQuery_DBAInformation_JSON() throws Throwable {
		String inputJSON = "{\"params\": {\"LookupId\": \"DbaInformation.DbaNameType#EC32BCA9F38745EEE040FF0A25F939FE\",\"LobCode\": \"WK\",\"ProductCode\": \"WK\",\"CompanyCode\": \"01\",\"ControlDate\": \"10/10/2021\"}}";
		
		String queryExpression = "SELECT     name_type_desc DBA_NAME_TYPE   FROM     iel_mic_name_type iwnt   WHERE     ( NVL(iwnt.state_code, '@@') ={lookupParam:RiskState} OR NVL(iwnt.state_code, '@@') = '@@' )     AND( NVL(iwnt.company_code, '@@') = {lookupParam:CompanyCode} OR NVL(iwnt.company_code,'@@') = '@@' )     AND( NVL(iwnt.customer_code, '@@') = '99' OR NVL(iwnt.customer_code ,'@@') = '@@' )     AND( NVL(iwnt.program_code, '@@') = {lookupParam:ProgramCode} OR NVL(iwnt.program_code, '@@') = '@@' )     AND( NVL(iwnt.market_segment_code, '@@') = {lookupParam:MarketSegmentCode} OR NVL(iwnt.market_segment_code, '@@') = '@@' )     AND( NVL(iwnt.product_code, '@@') = {lookupParam:ProductCode} OR NVL(iwnt.product_code, '@@') = '@@' )     AND( k_rate_adoption_management.f_is_multistate_adopted({lookupParam:LobCode},{lookupParam:CompanyCode},{lookupParam:RiskState}, to_date({lookupParam:ControlDate}, 'MM/DD/YYYY'), NVL(iwnt.adoption_type,NULL),iwnt.multistate_version ) =  0 OR NVL(iwnt.multistate_version,'NA') = 'NA' )     AND( k_rate_adoption_management.f_is_multistate_adopted({lookupParam:LobCode},{lookupParam:CompanyCode},{lookupParam:RiskState},to_date({lookupParam:ControlDate}, 'MM/DD/YYYY'), NVL(iwnt.adoption_type,NULL),iwnt.exp_multistate_version ) <>  0 OR NVL(iwnt.exp_multistate_version,'NA') = 'NA' )     AND( TO_NUMBER(NVL2(iwnt.exp_product_version, iwnt.exp_product_version, 0)) >  NVL2(iwnt.customer_code,k_pct_management.f_get_formatted_version('{lookupParam:CustomPackVersion}'),k_pct_management.f_get_formatted_version('{lookupParam:ProductVersion}')) OR TO_NUMBER(NVL2(iwnt.exp_product_version, iwnt.exp_product_version, 0)) = 0)     AND( TO_NUMBER(NVL2(iwnt.product_version, iwnt.product_version, 0))<= NVL2(iwnt.customer_code,k_pct_management.f_get_formatted_version('{lookupParam:CustomPackVersion}'),k_pct_management.f_get_formatted_version('{lookupParam:ProductVersion}')))     AND( NVL(iwnt.effective_date, TO_DATE('01/01/1900', 'mm/dd/yyyy')) <= k_rate_adoption_management.f_get_effective_date({lookupParam:LobCode},{lookupParam:CompanyCode}, {lookupParam:RiskState}, to_date({lookupParam:ControlDate}, 'MM/DD/YYYY'), NVL(iwnt.adoption_type,NULL),iwnt.multistate_version))     AND( NVL(iwnt.expiration_date,TO_DATE('01/01/2000', 'mm/dd/yyyy')) > k_rate_adoption_management.f_get_effective_date({lookupParam:LobCode},{lookupParam:CompanyCode}, {lookupParam:RiskState}, to_date({lookupParam:ControlDate}, 'MM/DD/YYYY'), NVL(iwnt.adoption_type,NULL),iwnt.multistate_version) OR NVL(iwnt.expiration_date,TO_DATE('01/01/2000', 'mm/dd/yyyy')) = TO_DATE('01/01/2000', 'mm/dd/yyyy'))     AND iwnt.rowid = (SELECT rowid      FROM ieo_mic_name_type     WHERE ( NVL(state_code, '@@') = {lookupParam:RiskState} OR NVL(state_code, '@@') = '@@' )     AND( NVL(company_code, '@@') =  {lookupParam:CompanyCode} OR NVL(company_code,'@@') = '@@' )     AND( NVL(customer_code, '@@') = '99' OR NVL(customer_code ,'@@') = '@@' )     AND( NVL(program_code, '@@') = {lookupParam:ProgramCode} OR NVL(program_code,'@@') = '@@' )     AND( NVL(market_segment_code, '@@') = {lookupParam:MarketSegmentCode} OR NVL(market_segment_code,'@@') = '@@' )     AND( NVL(product_code, '@@') = {lookupParam:ProductCode} OR NVL(product_code,'@@') = '@@' )     AND( k_rate_adoption_management.f_is_multistate_adopted({lookupParam:LobCode},{lookupParam:CompanyCode},{lookupParam:RiskState}, to_date({lookupParam:ControlDate}, 'MM/DD/YYYY'), NVL(adoption_type,NULL),multistate_version) =  0 OR NVL(multistate_version,'NA') = 'NA' )     AND( k_rate_adoption_management.f_is_multistate_adopted({lookupParam:LobCode},{lookupParam:CompanyCode},{lookupParam:RiskState},to_date({lookupParam:ControlDate}, 'MM/DD/YYYY'), NVL(adoption_type,NULL),exp_multistate_version) <>  0 OR NVL(exp_multistate_version,'NA') = 'NA' )     AND( TO_NUMBER(NVL2(exp_product_version, exp_product_version, 0)) >  NVL2(customer_code,k_pct_management.f_get_formatted_version('{lookupParam:CustomPackVersion}'),k_pct_management.f_get_formatted_version('{lookupParam:ProductVersion}')) OR TO_NUMBER(NVL2(exp_product_version,exp_product_version, 0)) = 0)     AND( TO_NUMBER(NVL2(product_version, product_version, 0))<= NVL2(customer_code,k_pct_management.f_get_formatted_version('{lookupParam:CustomPackVersion}'),k_pct_management.f_get_formatted_version('{lookupParam:ProductVersion}')))     AND( NVL(effective_date, TO_DATE('01/01/1900', 'mm/dd/yyyy')) <= k_rate_adoption_management.f_get_effective_date({lookupParam:LobCode},{lookupParam:CompanyCode},{lookupParam:RiskState}, to_date({lookupParam:ControlDate}, 'MM/DD/YYYY'), NVL(adoption_type,NULL),multistate_version))     AND( NVL(expiration_date,TO_DATE('01/01/2000', 'mm/dd/yyyy')) > k_rate_adoption_management.f_get_effective_date({lookupParam:LobCode},{lookupParam:CompanyCode},{lookupParam:RiskState}, to_date({lookupParam:ControlDate}, 'MM/DD/YYYY'), NVL(adoption_type,NULL),multistate_version) OR NVL(expiration_date,TO_DATE('01/01/2000', 'mm/dd/yyyy')) = TO_DATE('01/01/2000', 'mm/dd/yyyy'))      AND (NVL(product_version, '-9.99999999999999999') = NVL(iwnt.product_version, '-9.99999999999999999') )     AND (NVL(market_segment_code, '-9.99999999999999999') = NVL(iwnt.market_segment_code, '-9.99999999999999999') )     AND (NVL(program_code, '-9.99999999999999999') = NVL(iwnt.program_code, '-9.99999999999999999') )     AND (NVL(name_type_desc, '-9.99999999999999999') = NVL(iwnt.name_type_desc, '-9.99999999999999999') )  AND rownum < 2)  AND ( {lookupParam:DbaNameType} IS NULL OR UPPER( NAME_TYPE_DESC ) like UPPER( {lookupParam:DbaNameType} ))";
		//String dlsExpression = "${var:user('DLSFILTER', ' AND ', '{company=PCM_CODE}')}";
		String dlsExpression = null;
		
		Map<String, String> extraParameterMap = new HashMap<String, String>();
		
		extraParameterMap.put("ProductVersion", "21.4.0");
		extraParameterMap.put("CustomPackVersion", "2104.0.0");
		extraParameterMap.put("ProgramCode", null);
		extraParameterMap.put("MarketSegmentCode", null);
		extraParameterMap.put("DbaNameType", "%");
		extraParameterMap.put("RiskState", null);
		extraParameterMap.put(null, "N");
		
		ArrayList<Map<String, String>> expectedDataList = new ArrayList<Map<String, String>>();
		
		Map<String,String> dataMap = new HashMap<String, String>();
		
		dataMap.put("DbaNameType", "Commercial");
		
		expectedDataList.add(dataMap);
		
		dataMap = new HashMap<String, String>();
		
		dataMap.put("DbaNameType", "Personal");
		
		expectedDataList.add(dataMap);
		
		testSubstituteRequestParametersInQuery_Actual_JSON(inputJSON, queryExpression, dlsExpression, extraParameterMap, expectedDataList);
    }

    private void testSubstituteRequestParametersInQuery_Actual_JSON(String inputJSON, String queryExpression, String dlsExpression, Map<String, String> extraParameterMap, ArrayList<Map<String, String>> expectedDataList) throws Throwable {
    	Connection connection = null;
    	PreparedStatement preparedStatement = null;
    	ResultSet resultSet = null;
    	
    	try {
			LookupBean lookupBean = new LookupBean();
			
			lookupBean.setQueryExpression(queryExpression);
			lookupBean.setDlsExpressions(dlsExpression);
			
			String cachedLookupQuery = lookupBean.getQueryExpression();
			
			LookupRequest lookupRequestParameter = (new ObjectMapper()).readValue(inputJSON, LookupRequest.class);
			
			Map<String, String> inputParametersCopy = new HashMap<String, String>();
			
			for(String paramName:lookupRequestParameter.getParams().keySet()){
				inputParametersCopy.put(paramName, lookupRequestParameter.getParams().get(paramName));
			}
			
			inputParametersCopy.putAll(extraParameterMap);
			
			LookupServiceImpl lookupServiceImpl = new LookupServiceImpl();
			
			lookupServiceImpl.user = user;
			
			Map<String, Object> mapSQL = lookupServiceImpl.substituteRequestParametersInQuery(cachedLookupQuery, inputParametersCopy, lookupBean, lookupRequestParameter, dlsExpression);
			
			String updateLookupQuery = (lookupServiceImpl.DISTINCT_CONDITION) + (String.valueOf(mapSQL.get("QUERY"))) +")" + (lookupServiceImpl.DEFAULT_SORT_CONDITION);
			
			List<String> bindVariableList = (List<String>) (mapSQL.get("VARIABLE"));
			
			connection = ConnectionPool.getConnection(user);
			
			preparedStatement = connection.prepareStatement(updateLookupQuery);
			
			if (null != bindVariableList) {
				GeneralUtil.bindVariablesToStatement(bindVariableList, preparedStatement, 0);
			}
			
			resultSet = preparedStatement.executeQuery();
			
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			
			ArrayList<Map<String, String>> actualDataList = new ArrayList<Map<String, String>>();
			
			while(resultSet.next()){
				Map<String,String> dataMap = new HashMap<String, String>();
				
				for(int i=1; i <= (resultSetMetaData.getColumnCount()); i++) {
					dataMap.put(YAMLGenUtil.getFormattedParamNamesInCamelCases(resultSetMetaData.getColumnName(i)), resultSet.getString(resultSetMetaData.getColumnName(i)));
				}
				
				actualDataList.add(dataMap);
			}
			
			assertEquals("Incorrect Look Up Service Data", expectedDataList, actualDataList);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (null != resultSet) {
					resultSet.close();
				}
				
				if (null != preparedStatement) {
					preparedStatement.close();
				}
				
				if (null != connection) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
    }
    
    @Test
    public void testSubstituteRequestParametersInQuery_DBAInformation_SQL() throws Throwable {
		String querySQL = "SELECT  /*+ CURSOR_SHARING_EXACT */ * FROM (SELECT     name_type_desc DBA_NAME_TYPE   FROM     iel_mic_name_type iwnt   WHERE     ( NVL(iwnt.state_code, '@@') =? OR NVL(iwnt.state_code, '@@') = '@@' )     AND( NVL(iwnt.company_code, '@@') = ? OR NVL(iwnt.company_code,'@@') = '@@' )     AND( NVL(iwnt.customer_code, '@@') = 'QB' OR NVL(iwnt.customer_code ,'@@') = '@@' )     AND( NVL(iwnt.program_code, '@@') = ? OR NVL(iwnt.program_code, '@@') = '@@' )     AND( NVL(iwnt.market_segment_code, '@@') = ? OR NVL(iwnt.market_segment_code, '@@') = '@@' )     AND( NVL(iwnt.product_code, '@@') = ? OR NVL(iwnt.product_code, '@@') = '@@' )     AND( k_rate_adoption_management.f_is_multistate_adopted(?,?,?, to_date(?, 'MM/DD/YYYY'), NVL(iwnt.adoption_type,NULL),iwnt.multistate_version ) =  0 OR NVL(iwnt.multistate_version,'NA') = 'NA' )     AND( k_rate_adoption_management.f_is_multistate_adopted(?,?,?,to_date(?, 'MM/DD/YYYY'), NVL(iwnt.adoption_type,NULL),iwnt.exp_multistate_version ) <>  0 OR NVL(iwnt.exp_multistate_version,'NA') = 'NA' )     AND( TO_NUMBER(NVL2(iwnt.exp_product_version, iwnt.exp_product_version, 0)) >  NVL2(iwnt.customer_code,k_pct_management.f_get_formatted_version(?),k_pct_management.f_get_formatted_version(?)) OR TO_NUMBER(NVL2(iwnt.exp_product_version, iwnt.exp_product_version, 0)) = 0)     AND( TO_NUMBER(NVL2(iwnt.product_version, iwnt.product_version, 0))<= NVL2(iwnt.customer_code,k_pct_management.f_get_formatted_version(?),k_pct_management.f_get_formatted_version(?)))     AND( NVL(iwnt.effective_date, TO_DATE('01/01/1900', 'mm/dd/yyyy')) <= k_rate_adoption_management.f_get_effective_date(?,?, ?, to_date(?, 'MM/DD/YYYY'), NVL(iwnt.adoption_type,NULL),iwnt.multistate_version))     AND( NVL(iwnt.expiration_date,TO_DATE('01/01/2000', 'mm/dd/yyyy')) > k_rate_adoption_management.f_get_effective_date(?,?, ?, to_date(?, 'MM/DD/YYYY'), NVL(iwnt.adoption_type,NULL),iwnt.multistate_version) OR NVL(iwnt.expiration_date,TO_DATE('01/01/2000', 'mm/dd/yyyy')) = TO_DATE('01/01/2000', 'mm/dd/yyyy'))     AND iwnt.rowid = (SELECT rowid      FROM ieo_mic_name_type     WHERE ( NVL(state_code, '@@') = ? OR NVL(state_code, '@@') = '@@' )     AND( NVL(company_code, '@@') =  ? OR NVL(company_code,'@@') = '@@' )     AND( NVL(customer_code, '@@') = 'QB' OR NVL(customer_code ,'@@') = '@@' )     AND( NVL(program_code, '@@') = ? OR NVL(program_code,'@@') = '@@' )     AND( NVL(market_segment_code, '@@') = ? OR NVL(market_segment_code,'@@') = '@@' )     AND( NVL(product_code, '@@') = ? OR NVL(product_code,'@@') = '@@' )     AND( k_rate_adoption_management.f_is_multistate_adopted(?,?,?, to_date(?, 'MM/DD/YYYY'), NVL(adoption_type,NULL),multistate_version) =  0 OR NVL(multistate_version,'NA') = 'NA' )     AND( k_rate_adoption_management.f_is_multistate_adopted(?,?,?,to_date(?, 'MM/DD/YYYY'), NVL(adoption_type,NULL),exp_multistate_version) <>  0 OR NVL(exp_multistate_version,'NA') = 'NA' )     AND( TO_NUMBER(NVL2(exp_product_version, exp_product_version, 0)) >  NVL2(customer_code,k_pct_management.f_get_formatted_version(?),k_pct_management.f_get_formatted_version(?)) OR TO_NUMBER(NVL2(exp_product_version,exp_product_version, 0)) = 0)     AND( TO_NUMBER(NVL2(product_version, product_version, 0))<= NVL2(customer_code,k_pct_management.f_get_formatted_version(?),k_pct_management.f_get_formatted_version(?)))     AND( NVL(effective_date, TO_DATE('01/01/1900', 'mm/dd/yyyy')) <= k_rate_adoption_management.f_get_effective_date(?,?,?, to_date(?, 'MM/DD/YYYY'), NVL(adoption_type,NULL),multistate_version))     AND( NVL(expiration_date,TO_DATE('01/01/2000', 'mm/dd/yyyy')) > k_rate_adoption_management.f_get_effective_date(?,?,?, to_date(?, 'MM/DD/YYYY'), NVL(adoption_type,NULL),multistate_version) OR NVL(expiration_date,TO_DATE('01/01/2000', 'mm/dd/yyyy')) = TO_DATE('01/01/2000', 'mm/dd/yyyy'))      AND (NVL(product_version, '-9.99999999999999999') = NVL(iwnt.product_version, '-9.99999999999999999') )     AND (NVL(market_segment_code, '-9.99999999999999999') = NVL(iwnt.market_segment_code, '-9.99999999999999999') )     AND (NVL(program_code, '-9.99999999999999999') = NVL(iwnt.program_code, '-9.99999999999999999') )     AND (NVL(name_type_desc, '-9.99999999999999999') = NVL(iwnt.name_type_desc, '-9.99999999999999999') )  AND rownum < 2)  AND ( ? IS NULL OR UPPER( NAME_TYPE_DESC ) like UPPER( ? )) ) ORDER BY 1 ASC";
		String bindVariables = "null, 01, null, null, WK, WK, 01, null, 10/10/2021, WK, 01, null, 10/10/2021, 2105.0.0, 20.11.0, 2105.0.0, 20.11.0, WK, 01, null, 10/10/2021, WK, 01, null, 10/10/2021, null, 01, null, null, WK, WK, 01, null, 10/10/2021, WK, 01, null, 10/10/2021, 2105.0.0, 20.11.0, 2105.0.0, 20.11.0, WK, 01, null, 10/10/2021, WK, 01, null, 10/10/2021, %, %";
		
		List<String> bindVariableList = Arrays.asList(bindVariables.split(", "));
		
		if (null != bindVariableList) {
			for (int index = 0; index < (bindVariableList.size()); index++) {
				if ("null".equalsIgnoreCase(bindVariableList.get(index))) {
					bindVariableList.set(index, null);
				}
			}
		}
		
		ArrayList<Map<String, String>> expectedDataList = new ArrayList<Map<String, String>>();
		
		Map<String,String> dataMap = new HashMap<String, String>();
		
		dataMap.put("DbaNameType", "Commercial");
		
		expectedDataList.add(dataMap);
		
		dataMap = new HashMap<String, String>();
		
		dataMap.put("DbaNameType", "Personal");
		
		expectedDataList.add(dataMap);
		
		testSubstituteRequestParametersInQuery_Actual_SQL(querySQL, bindVariableList, expectedDataList);
    }
    
    private static void testSubstituteRequestParametersInQuery_Actual_SQL(String querySQL, List<String> bindVariableList, ArrayList<Map<String, String>> expectedDataList) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		try {
			connection = ConnectionPool.getConnection(user);
			
			preparedStatement = connection.prepareStatement(querySQL);
			
			if (null != bindVariableList) {
				GeneralUtil.bindVariablesToStatement(bindVariableList, preparedStatement, 0);
			}
			
			resultSet = preparedStatement.executeQuery();
			
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			
			ArrayList<Map<String, String>> actualDataList = new ArrayList<Map<String, String>>();
			
			while(resultSet.next()){
				Map<String,String> dataMap = new HashMap<String, String>();
				
				for(int i=1; i <= (resultSetMetaData.getColumnCount()); i++) {
					dataMap.put(YAMLGenUtil.getFormattedParamNamesInCamelCases(resultSetMetaData.getColumnName(i)), resultSet.getString(resultSetMetaData.getColumnName(i)));
				}
				
				actualDataList.add(dataMap);
			}
			
			assertEquals("Incorrect Look Up Service Data", expectedDataList, actualDataList);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (null != resultSet) {
					resultSet.close();
				}
				
				if (null != preparedStatement) {
					preparedStatement.close();
				}
				
				if (null != connection) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
